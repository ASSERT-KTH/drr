import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        com.google.javascript.rhino.Node node0 = null;
        try {
            com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.block(node0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        com.google.javascript.jscomp.CheckLevel checkLevel3 = null;
        com.google.javascript.jscomp.DiagnosticType diagnosticType4 = null;
        java.lang.String[] strArray7 = new java.lang.String[] { "hi!", "hi!" };
        try {
            com.google.javascript.jscomp.JSError jSError8 = com.google.javascript.jscomp.JSError.make("", (int) (byte) 0, (int) (short) 100, checkLevel3, diagnosticType4, strArray7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(strArray7);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        com.google.javascript.jscomp.SourceAst sourceAst0 = null;
        try {
            com.google.javascript.jscomp.CompilerInput compilerInput2 = new com.google.javascript.jscomp.CompilerInput(sourceAst0, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        com.google.javascript.rhino.Node node0 = null;
        try {
            com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.breakNode(node0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        int int0 = com.google.javascript.rhino.Node.INPUT_ID;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 53 + "'", int0 == 53);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        boolean boolean1 = com.google.javascript.jscomp.NodeUtil.isValidQualifiedName("hi!");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        com.google.javascript.rhino.Node node0 = null;
        try {
            com.google.javascript.rhino.Node node1 = com.google.javascript.jscomp.NodeUtil.getFunctionParameters(node0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        com.google.javascript.rhino.Node node0 = null;
        com.google.javascript.rhino.Node node1 = null;
        try {
            com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.IR.getelem(node0, node1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile0 = null;
        try {
            com.google.javascript.jscomp.CompilerInput compilerInput2 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile0, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        com.google.javascript.rhino.Node node0 = null;
        com.google.javascript.rhino.Node node1 = null;
        try {
            com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.IR.comma(node0, node1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        com.google.javascript.jscomp.SourceFile sourceFile0 = null;
        try {
            com.google.javascript.jscomp.JsAst jsAst1 = new com.google.javascript.jscomp.JsAst(sourceFile0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        int int0 = com.google.javascript.rhino.Node.IS_CONSTANT_NAME;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 43 + "'", int0 == 43);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = null;
        com.google.javascript.jscomp.DiagnosticGroups.DEPRECATED = diagnosticGroup0;
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        com.google.javascript.rhino.Node node0 = null;
        try {
            com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.returnNode(node0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        int int0 = com.google.javascript.rhino.Node.FLAG_LOCAL_RESULTS;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 16 + "'", int0 == 16);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        int int0 = com.google.javascript.rhino.Node.SLASH_V;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 54 + "'", int0 == 54);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        com.google.javascript.rhino.Node node0 = null;
        try {
            com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.pos(node0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        java.util.logging.Logger logger0 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager1 = new com.google.javascript.jscomp.LoggerErrorManager(logger0);
        double double2 = loggerErrorManager1.getTypedPercent();
        com.google.javascript.jscomp.Compiler compiler3 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager1);
        try {
            java.util.Map<com.google.javascript.rhino.InputId, com.google.javascript.jscomp.CompilerInput> inputIdMap4 = compiler3.getInputsById();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        com.google.javascript.rhino.Node node0 = null;
        com.google.javascript.rhino.Node[] nodeArray1 = new com.google.javascript.rhino.Node[] {};
        try {
            com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.IR.switchNode(node0, nodeArray1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(nodeArray1);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        com.google.javascript.jscomp.SourceMap.Format format0 = com.google.javascript.jscomp.SourceMap.Format.V2;
        org.junit.Assert.assertNotNull(format0);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean2 = node1.isFor();
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean5 = node4.isFor();
        try {
            com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.IR.label(node1, node4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newString("hi!");
        com.google.javascript.rhino.Node node2 = node1.removeChildren();
        node1.setSourceEncodedPositionForTree(10);
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertNull(node2);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newString("hi!");
        try {
            com.google.javascript.rhino.Node node2 = node1.detachFromParent();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(node1);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        int int0 = com.google.javascript.rhino.Node.FREE_CALL;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 50 + "'", int0 == 50);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        double double0 = com.google.javascript.rhino.ScriptRuntime.NaN;
        org.junit.Assert.assertEquals((double) double0, Double.NaN, 0);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        double double0 = com.google.javascript.rhino.ScriptRuntime.negativeZero;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + (-0.0d) + "'", double0 == (-0.0d));
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = null;
        com.google.javascript.jscomp.DiagnosticGroups.UNDEFINED_VARIABLES = diagnosticGroup0;
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        com.google.javascript.rhino.Node[] nodeArray0 = null;
        try {
            com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.script(nodeArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newString("hi!");
        com.google.javascript.rhino.Node node2 = node1.removeChildren();
        try {
            boolean boolean3 = node2.isCase();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertNull(node2);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newString("hi!");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean4 = node3.isFor();
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean7 = node6.isFor();
        boolean boolean8 = node6.isExprResult();
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean11 = node10.isFor();
        com.google.javascript.rhino.Node node12 = node6.clonePropsFrom(node10);
        try {
            com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.IR.forIn(node1, node3, node6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(node12);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        java.util.logging.Logger logger0 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager1 = new com.google.javascript.jscomp.LoggerErrorManager(logger0);
        double double2 = loggerErrorManager1.getTypedPercent();
        com.google.javascript.jscomp.Compiler compiler3 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager1);
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray4 = new com.google.javascript.jscomp.JSSourceFile[] {};
        java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList5 = new java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile>();
        boolean boolean6 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList5, jSSourceFileArray4);
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray7 = new com.google.javascript.jscomp.JSSourceFile[] {};
        java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList8 = new java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile>();
        boolean boolean9 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList8, jSSourceFileArray7);
        com.google.javascript.jscomp.CompilerOptions compilerOptions10 = null;
        try {
            compiler3.init((java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList5, (java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList8, compilerOptions10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(jSSourceFileArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(jSSourceFileArray7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        com.google.javascript.rhino.InputId inputId1 = new com.google.javascript.rhino.InputId("");
        com.google.javascript.jscomp.DiagnosticType diagnosticType4 = com.google.javascript.jscomp.DiagnosticType.disabled("hi!", "hi!");
        boolean boolean5 = inputId1.equals((java.lang.Object) "hi!");
        org.junit.Assert.assertNotNull(diagnosticType4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newString("hi!");
        try {
            com.google.javascript.rhino.Node node2 = com.google.javascript.jscomp.NodeUtil.getFunctionParameters(node1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node1);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean2 = node1.isFor();
        boolean boolean3 = node1.isExprResult();
        java.lang.String str4 = node1.getString();
        try {
            com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.IR.block(node1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "hi!" + "'", str4.equals("hi!"));
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean2 = node1.isFor();
        boolean boolean3 = node1.isExprResult();
        java.lang.String str4 = node1.getString();
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean7 = node6.isFor();
        boolean boolean8 = node6.isExprResult();
        com.google.javascript.rhino.Node node9 = node1.clonePropsFrom(node6);
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean12 = node11.isFor();
        boolean boolean13 = node11.isExprResult();
        java.lang.String str14 = node11.getString();
        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean17 = node16.isFor();
        boolean boolean18 = node16.isExprResult();
        com.google.javascript.rhino.Node node19 = node11.clonePropsFrom(node16);
        int int20 = node6.getIndexOfChild(node11);
        try {
            node11.setDouble((double) 50);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: STRING hi! is not a string node");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "hi!" + "'", str4.equals("hi!"));
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "hi!" + "'", str14.equals("hi!"));
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean2 = node1.isFor();
        boolean boolean3 = node1.isExprResult();
        try {
            com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.IR.continueNode(node1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        int int0 = com.google.javascript.rhino.Node.SYNTHETIC_BLOCK_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 38 + "'", int0 == 38);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newString("hi!");
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.IR.voidNode(node1);
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean5 = node4.isFor();
        boolean boolean6 = node4.isExprResult();
        java.lang.String str7 = node4.getString();
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean10 = node9.isFor();
        boolean boolean11 = node9.isExprResult();
        com.google.javascript.rhino.Node node12 = node4.clonePropsFrom(node9);
        boolean boolean13 = node1.isEquivalentToTyped(node4);
        com.google.javascript.rhino.Node node14 = null;
        try {
            com.google.javascript.rhino.Node node15 = node4.useSourceInfoIfMissingFrom(node14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "hi!" + "'", str7.equals("hi!"));
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        java.lang.String str2 = com.google.javascript.jscomp.ProcessCommonJSModules.toModuleName("STRING hi!", "STRING hi!");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "module$STRING hi!" + "'", str2.equals("module$STRING hi!"));
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.ACCESS_CONTROLS;
        com.google.javascript.jscomp.DiagnosticGroups.UNDEFINED_NAMES = diagnosticGroup0;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean2 = node1.isFor();
        boolean boolean3 = node1.isExprResult();
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean6 = node5.isFor();
        com.google.javascript.rhino.Node node7 = node1.clonePropsFrom(node5);
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString("hi!");
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.IR.voidNode(node9);
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean13 = node12.isFor();
        boolean boolean14 = node12.isExprResult();
        java.lang.String str15 = node12.getString();
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean18 = node17.isFor();
        boolean boolean19 = node17.isExprResult();
        com.google.javascript.rhino.Node node20 = node12.clonePropsFrom(node17);
        boolean boolean21 = node9.isEquivalentToTyped(node12);
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean24 = node23.isFor();
        boolean boolean25 = node23.isExprResult();
        java.lang.String str26 = node23.getString();
        com.google.javascript.rhino.Node node28 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean29 = node28.isFor();
        boolean boolean30 = node28.isExprResult();
        com.google.javascript.rhino.Node node31 = node23.clonePropsFrom(node28);
        com.google.javascript.rhino.Node node33 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean34 = node33.isFor();
        boolean boolean35 = node33.hasChildren();
        com.google.javascript.rhino.Node node37 = com.google.javascript.rhino.Node.newString("hi!");
        com.google.javascript.rhino.Node node38 = com.google.javascript.rhino.IR.voidNode(node37);
        com.google.javascript.rhino.Node node40 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean41 = node40.isFor();
        boolean boolean42 = node40.isExprResult();
        com.google.javascript.rhino.Node node44 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean45 = node44.isFor();
        com.google.javascript.rhino.Node node46 = node40.clonePropsFrom(node44);
        com.google.javascript.rhino.Node[] nodeArray47 = new com.google.javascript.rhino.Node[] { node1, node12, node28, node33, node37, node46 };
        try {
            com.google.javascript.rhino.Node node48 = com.google.javascript.rhino.IR.objectlit(nodeArray47);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "hi!" + "'", str15.equals("hi!"));
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "hi!" + "'", str26.equals("hi!"));
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertNotNull(node33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(node37);
        org.junit.Assert.assertNotNull(node38);
        org.junit.Assert.assertNotNull(node40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(node44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(node46);
        org.junit.Assert.assertNotNull(nodeArray47);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        java.util.logging.Logger logger0 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager1 = new com.google.javascript.jscomp.LoggerErrorManager(logger0);
        double double2 = loggerErrorManager1.getTypedPercent();
        com.google.javascript.jscomp.Compiler compiler3 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager1);
        com.google.javascript.jscomp.Result result4 = compiler3.getResult();
        java.lang.String str5 = compiler3.getAstDotGraph();
        try {
            compiler3.processDefines();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(result4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.CHECK_PROVIDES;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newString("hi!");
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.IR.voidNode(node1);
        java.lang.String str6 = node1.toString(true, false, false);
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString("hi!");
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.IR.voidNode(node8);
        boolean boolean10 = node9.isBreak();
        try {
            com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.IR.tryFinally(node1, node9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "STRING hi!" + "'", str6.equals("STRING hi!"));
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.Node.newString("hi!");
        com.google.javascript.rhino.Node node3 = node2.removeChildren();
        com.google.javascript.rhino.Node node4 = null;
        try {
            com.google.javascript.rhino.Node node5 = new com.google.javascript.rhino.Node((-1), node3, node4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertNull(node3);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        java.util.logging.Logger logger0 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager1 = new com.google.javascript.jscomp.LoggerErrorManager(logger0);
        double double2 = loggerErrorManager1.getTypedPercent();
        com.google.javascript.jscomp.Compiler compiler3 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager1);
        com.google.javascript.jscomp.Result result4 = compiler3.getResult();
        java.lang.String str5 = compiler3.getAstDotGraph();
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray6 = null;
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray7 = null;
        com.google.javascript.jscomp.CompilerOptions compilerOptions8 = null;
        try {
            compiler3.init(jSSourceFileArray6, jSSourceFileArray7, compilerOptions8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(result4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        int int0 = com.google.javascript.rhino.Node.PARENTHESIZED_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 35 + "'", int0 == 35);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        java.util.logging.Logger logger0 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager1 = new com.google.javascript.jscomp.LoggerErrorManager(logger0);
        double double2 = loggerErrorManager1.getTypedPercent();
        com.google.javascript.jscomp.Compiler compiler3 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager1);
        com.google.javascript.jscomp.Result result4 = compiler3.getResult();
        try {
            boolean boolean5 = compiler3.hasErrors();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(result4);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        java.lang.String str0 = com.google.javascript.rhino.jstype.JSType.UNKNOWN_NAME;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "Unknown class name" + "'", str0.equals("Unknown class name"));
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.ACCESS_CONTROLS;
        com.google.javascript.jscomp.DiagnosticGroups.STRICT_MODULE_DEP_CHECK = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticGroups.FILEOVERVIEW_JSDOC = diagnosticGroup0;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.TYPE_INVALIDATION;
        com.google.javascript.jscomp.DiagnosticGroups.DUPLICATE_MESSAGE = diagnosticGroup0;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        com.google.javascript.jscomp.parsing.Config config1 = com.google.javascript.jscomp.parsing.ParserRunner.createConfig(true);
        org.junit.Assert.assertNotNull(config1);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        com.google.javascript.jscomp.SourceFile sourceFile1 = com.google.javascript.jscomp.SourceFile.fromFile("hi!");
        java.lang.String str2 = sourceFile1.getName();
        org.junit.Assert.assertNotNull(sourceFile1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hi!" + "'", str2.equals("hi!"));
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newString("hi!");
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.IR.voidNode(node1);
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean5 = node4.isFor();
        boolean boolean6 = node4.isExprResult();
        java.lang.String str7 = node4.getString();
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean10 = node9.isFor();
        boolean boolean11 = node9.isExprResult();
        com.google.javascript.rhino.Node node12 = node4.clonePropsFrom(node9);
        boolean boolean13 = node1.isEquivalentToTyped(node4);
        com.google.javascript.rhino.Node[] nodeArray14 = new com.google.javascript.rhino.Node[] {};
        try {
            com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.IR.call(node1, nodeArray14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: new child has existing parent");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "hi!" + "'", str7.equals("hi!"));
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(nodeArray14);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.thisNode();
        try {
            com.google.javascript.rhino.Node node1 = node0.detachFromParent();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(node0);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        int int0 = com.google.javascript.rhino.Node.SIDE_EFFECT_FLAGS;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 42 + "'", int0 == 42);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        java.util.logging.Level level0 = null;
        com.google.javascript.jscomp.Compiler.setLoggingLevel(level0);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        boolean boolean1 = com.google.javascript.jscomp.NodeUtil.isValidQualifiedName("");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        java.util.logging.Logger logger0 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager1 = new com.google.javascript.jscomp.LoggerErrorManager(logger0);
        double double2 = loggerErrorManager1.getTypedPercent();
        com.google.javascript.jscomp.Compiler compiler3 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager1);
        com.google.javascript.jscomp.Result result4 = compiler3.getResult();
        java.util.logging.Logger logger5 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager6 = new com.google.javascript.jscomp.LoggerErrorManager(logger5);
        double double7 = loggerErrorManager6.getTypedPercent();
        compiler3.setErrorManager((com.google.javascript.jscomp.ErrorManager) loggerErrorManager6);
        com.google.javascript.jscomp.NodeTraversal.Callback callback9 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal10 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler3, callback9);
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean13 = node12.isFor();
        boolean boolean14 = node12.isExprResult();
        boolean boolean15 = node12.isCase();
        try {
            nodeTraversal10.traverse(node12);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: INTERNAL COMPILER ERROR.\nPlease report this problem.\nnull");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(result4);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        com.google.javascript.rhino.Node node3 = new com.google.javascript.rhino.Node((int) (byte) 100, (int) (byte) 1, 54);
        boolean boolean4 = node3.wasEmptyNode();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean2 = node1.isFor();
        boolean boolean3 = node1.isExprResult();
        com.google.javascript.rhino.Node node4 = null;
        com.google.javascript.rhino.Node node5 = null;
        try {
            com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.IR.function(node1, node4, node5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        java.util.logging.Logger logger0 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager1 = new com.google.javascript.jscomp.LoggerErrorManager(logger0);
        double double2 = loggerErrorManager1.getTypedPercent();
        com.google.javascript.jscomp.Compiler compiler3 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager1);
        com.google.javascript.jscomp.Result result4 = compiler3.getResult();
        java.util.logging.Logger logger5 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager6 = new com.google.javascript.jscomp.LoggerErrorManager(logger5);
        double double7 = loggerErrorManager6.getTypedPercent();
        compiler3.setErrorManager((com.google.javascript.jscomp.ErrorManager) loggerErrorManager6);
        try {
            boolean boolean9 = compiler3.isTypeCheckingEnabled();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(result4);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newString("hi!");
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.IR.voidNode(node1);
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean5 = node4.isFor();
        boolean boolean6 = node4.isExprResult();
        java.lang.String str7 = node4.getString();
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean10 = node9.isFor();
        boolean boolean11 = node9.isExprResult();
        com.google.javascript.rhino.Node node12 = node4.clonePropsFrom(node9);
        boolean boolean13 = node1.isEquivalentToTyped(node4);
        try {
            node1.setDouble((double) 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: STRING hi! is not a string node");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "hi!" + "'", str7.equals("hi!"));
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newString("hi!");
        java.lang.Object obj3 = null;
        node1.putProp(50, obj3);
        com.google.javascript.rhino.jstype.StaticSourceFile staticSourceFile5 = node1.getStaticSourceFile();
        com.google.javascript.rhino.Node.SideEffectFlags sideEffectFlags6 = null;
        try {
            node1.setSideEffectFlags(sideEffectFlags6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertNull(staticSourceFile5);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        int int0 = com.google.javascript.rhino.Node.EMPTY_BLOCK;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 39 + "'", int0 == 39);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean2 = node1.isFor();
        boolean boolean3 = node1.isExprResult();
        java.lang.String str4 = node1.getString();
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean7 = node6.isFor();
        boolean boolean8 = node6.isExprResult();
        com.google.javascript.rhino.Node node9 = node1.clonePropsFrom(node6);
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.IR.pos(node1);
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean13 = node12.isFor();
        boolean boolean14 = node12.isExprResult();
        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean17 = node16.isFor();
        com.google.javascript.rhino.Node node18 = node12.clonePropsFrom(node16);
        boolean boolean19 = node12.isOnlyModifiesThisCall();
        com.google.javascript.rhino.Node[] nodeArray20 = new com.google.javascript.rhino.Node[] { node12 };
        try {
            com.google.javascript.rhino.Node node21 = com.google.javascript.rhino.IR.call(node1, nodeArray20);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: new child has existing parent");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "hi!" + "'", str4.equals("hi!"));
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(nodeArray20);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        java.util.logging.Logger logger0 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager1 = new com.google.javascript.jscomp.LoggerErrorManager(logger0);
        double double2 = loggerErrorManager1.getTypedPercent();
        com.google.javascript.jscomp.Compiler compiler3 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager1);
        com.google.javascript.jscomp.Result result4 = compiler3.getResult();
        com.google.javascript.jscomp.PassConfig passConfig5 = null;
        try {
            compiler3.setPassConfig(passConfig5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(result4);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        int int0 = com.google.javascript.rhino.Node.STATIC_SOURCE_FILE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 51 + "'", int0 == 51);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        com.google.javascript.rhino.Node node3 = new com.google.javascript.rhino.Node((int) (byte) 100, (int) (byte) 1, 54);
        try {
            com.google.javascript.rhino.JSDocInfo jSDocInfo4 = com.google.javascript.jscomp.NodeUtil.getFunctionJSDocInfo(node3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.UNDEFINED_VARIABLES;
        org.junit.Assert.assertNull(diagnosticGroup0);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newString("hi!");
        com.google.javascript.rhino.Node node2 = node1.removeChildren();
        try {
            node2.setSideEffectFlags((int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertNull(node2);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean2 = node1.isFor();
        boolean boolean3 = node1.isExprResult();
        java.lang.String str4 = node1.getString();
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean7 = node6.isFor();
        boolean boolean8 = node6.isExprResult();
        com.google.javascript.rhino.Node node9 = node1.clonePropsFrom(node6);
        boolean boolean10 = node9.isVar();
        node9.setSourceEncodedPositionForTree(16);
        java.lang.String str13 = node9.getQualifiedName();
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "hi!" + "'", str4.equals("hi!"));
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNull(str13);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        java.util.logging.Logger logger0 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager1 = new com.google.javascript.jscomp.LoggerErrorManager(logger0);
        double double2 = loggerErrorManager1.getTypedPercent();
        com.google.javascript.jscomp.Compiler compiler3 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager1);
        com.google.javascript.jscomp.Result result4 = compiler3.getResult();
        java.util.logging.Logger logger5 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager6 = new com.google.javascript.jscomp.LoggerErrorManager(logger5);
        double double7 = loggerErrorManager6.getTypedPercent();
        compiler3.setErrorManager((com.google.javascript.jscomp.ErrorManager) loggerErrorManager6);
        compiler3.disableThreads();
        try {
            com.google.javascript.jscomp.CompilerInput compilerInput11 = compiler3.newExternInput("module$STRING hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(result4);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        com.google.javascript.rhino.jstype.JSType jSType0 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType1 = com.google.javascript.rhino.jstype.JSType.toMaybeFunctionType(jSType0);
        org.junit.Assert.assertNull(functionType1);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        int int0 = com.google.javascript.rhino.Node.COLUMN_MASK;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4095 + "'", int0 == 4095);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean2 = node1.isFor();
        boolean boolean3 = node1.isExprResult();
        java.lang.String str4 = node1.getString();
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean7 = node6.isFor();
        boolean boolean8 = node6.isExprResult();
        com.google.javascript.rhino.Node node9 = node1.clonePropsFrom(node6);
        com.google.javascript.rhino.Node node10 = null;
        try {
            boolean boolean11 = node6.isEquivalentTo(node10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "hi!" + "'", str4.equals("hi!"));
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(node9);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        com.google.javascript.rhino.jstype.JSType jSType0 = null;
        com.google.javascript.rhino.jstype.JSType jSType1 = null;
        boolean boolean2 = com.google.javascript.rhino.jstype.JSType.isEquivalent(jSType0, jSType1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        java.io.InputStream inputStream1 = null;
        try {
            com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromInputStream("STRING hi!", inputStream1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        java.util.logging.Logger logger0 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager1 = new com.google.javascript.jscomp.LoggerErrorManager(logger0);
        double double2 = loggerErrorManager1.getTypedPercent();
        com.google.javascript.jscomp.Compiler compiler3 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager1);
        com.google.javascript.jscomp.Result result4 = compiler3.getResult();
        java.lang.String str5 = compiler3.getAstDotGraph();
        com.google.javascript.jscomp.JSError[] jSErrorArray6 = compiler3.getWarnings();
        try {
            compiler3.check();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(result4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertNotNull(jSErrorArray6);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy0 = com.google.javascript.jscomp.PropertyRenamingPolicy.OFF;
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy0 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.OFF + "'", propertyRenamingPolicy0.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.OFF));
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean3 = node2.isFor();
        boolean boolean4 = node2.isExprResult();
        java.lang.String str5 = node2.getString();
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean8 = node7.isFor();
        boolean boolean9 = node7.isExprResult();
        com.google.javascript.rhino.Node node10 = node2.clonePropsFrom(node7);
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean13 = node12.isFor();
        boolean boolean14 = node12.isExprResult();
        java.lang.String str15 = node12.getString();
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean18 = node17.isFor();
        boolean boolean19 = node17.isExprResult();
        com.google.javascript.rhino.Node node20 = node12.clonePropsFrom(node17);
        boolean boolean21 = node20.isVar();
        node20.setSourceEncodedPositionForTree(16);
        com.google.javascript.rhino.Node node24 = new com.google.javascript.rhino.Node(10, node7, node20);
        com.google.javascript.jscomp.SourceFile sourceFile26 = com.google.javascript.jscomp.SourceFile.fromFile("hi!");
        node24.setStaticSourceFile((com.google.javascript.rhino.jstype.StaticSourceFile) sourceFile26);
        com.google.javascript.rhino.Node node28 = com.google.javascript.rhino.IR.paramList();
        com.google.javascript.rhino.Node node29 = node24.srcref(node28);
        try {
            com.google.javascript.rhino.Node node30 = com.google.javascript.rhino.IR.breakNode(node28);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "hi!" + "'", str15.equals("hi!"));
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(sourceFile26);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertNotNull(node29);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean2 = node1.isFor();
        boolean boolean3 = node1.isExprResult();
        java.lang.String str4 = node1.getString();
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean7 = node6.isFor();
        boolean boolean8 = node6.isExprResult();
        com.google.javascript.rhino.Node node9 = node1.clonePropsFrom(node6);
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean12 = node11.isFor();
        boolean boolean13 = node11.isExprResult();
        java.lang.String str14 = node11.getString();
        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean17 = node16.isFor();
        boolean boolean18 = node16.isExprResult();
        com.google.javascript.rhino.Node node19 = node11.clonePropsFrom(node16);
        int int20 = node6.getIndexOfChild(node11);
        com.google.javascript.rhino.Node node21 = node6.cloneTree();
        com.google.javascript.rhino.Node node22 = com.google.javascript.rhino.IR.returnNode(node21);
        boolean boolean23 = node22.isAnd();
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "hi!" + "'", str4.equals("hi!"));
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "hi!" + "'", str14.equals("hi!"));
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        com.google.javascript.jscomp.SourceFile sourceFile1 = com.google.javascript.jscomp.SourceFile.fromFile("hi!");
        boolean boolean2 = sourceFile1.isExtern();
        com.google.javascript.jscomp.JsAst jsAst3 = new com.google.javascript.jscomp.JsAst(sourceFile1);
        try {
            java.lang.String str4 = sourceFile1.getCode();
            org.junit.Assert.fail("Expected exception of type java.io.FileNotFoundException; message: hi! (No such file or directory)");
        } catch (java.io.FileNotFoundException e) {
        }
        org.junit.Assert.assertNotNull(sourceFile1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        java.util.logging.Logger logger0 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager1 = new com.google.javascript.jscomp.LoggerErrorManager(logger0);
        double double2 = loggerErrorManager1.getTypedPercent();
        com.google.javascript.jscomp.Compiler compiler3 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager1);
        com.google.javascript.jscomp.Result result4 = compiler3.getResult();
        java.util.logging.Logger logger5 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager6 = new com.google.javascript.jscomp.LoggerErrorManager(logger5);
        double double7 = loggerErrorManager6.getTypedPercent();
        compiler3.setErrorManager((com.google.javascript.jscomp.ErrorManager) loggerErrorManager6);
        compiler3.disableThreads();
        try {
            java.util.Map<com.google.javascript.rhino.InputId, com.google.javascript.jscomp.CompilerInput> inputIdMap10 = compiler3.getInputsById();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(result4);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean2 = node1.isFor();
        boolean boolean3 = node1.isExprResult();
        java.lang.String str4 = node1.getString();
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean7 = node6.isFor();
        boolean boolean8 = node6.isExprResult();
        com.google.javascript.rhino.Node node9 = node1.clonePropsFrom(node6);
        boolean boolean10 = node9.isVar();
        com.google.javascript.rhino.Node node14 = new com.google.javascript.rhino.Node((int) (byte) 100, (int) (byte) 1, 54);
        boolean boolean15 = node14.isReturn();
        boolean boolean16 = node9.hasChild(node14);
        try {
            int int18 = node9.getExistingIntProp(42);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: missing prop: 42");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "hi!" + "'", str4.equals("hi!"));
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        java.util.logging.Logger logger0 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager1 = new com.google.javascript.jscomp.LoggerErrorManager(logger0);
        double double2 = loggerErrorManager1.getTypedPercent();
        com.google.javascript.jscomp.Compiler compiler3 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager1);
        com.google.javascript.jscomp.Result result4 = compiler3.getResult();
        java.lang.String str5 = compiler3.getAstDotGraph();
        try {
            java.lang.String[] strArray6 = compiler3.toSourceArray();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(result4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        java.util.logging.Logger logger0 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager1 = new com.google.javascript.jscomp.LoggerErrorManager(logger0);
        double double2 = loggerErrorManager1.getTypedPercent();
        com.google.javascript.jscomp.Compiler compiler3 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager1);
        com.google.javascript.jscomp.Result result4 = compiler3.getResult();
        java.util.logging.Logger logger5 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager6 = new com.google.javascript.jscomp.LoggerErrorManager(logger5);
        double double7 = loggerErrorManager6.getTypedPercent();
        compiler3.setErrorManager((com.google.javascript.jscomp.ErrorManager) loggerErrorManager6);
        compiler3.disableThreads();
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean12 = node11.isFor();
        boolean boolean13 = node11.isExprResult();
        java.lang.String str14 = node11.getString();
        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean17 = node16.isFor();
        boolean boolean18 = node16.isExprResult();
        com.google.javascript.rhino.Node node19 = node11.clonePropsFrom(node16);
        com.google.javascript.rhino.Node node21 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean22 = node21.isFor();
        boolean boolean23 = node21.isExprResult();
        java.lang.String str24 = node21.getString();
        com.google.javascript.rhino.Node node26 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean27 = node26.isFor();
        boolean boolean28 = node26.isExprResult();
        com.google.javascript.rhino.Node node29 = node21.clonePropsFrom(node26);
        int int30 = node16.getIndexOfChild(node21);
        com.google.javascript.rhino.Node node31 = node16.cloneTree();
        com.google.javascript.rhino.Node node32 = com.google.javascript.rhino.IR.returnNode(node31);
        com.google.javascript.jscomp.NodeTraversal.Callback callback33 = null;
        try {
            com.google.javascript.jscomp.NodeTraversal.traverse((com.google.javascript.jscomp.AbstractCompiler) compiler3, node32, callback33);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: INTERNAL COMPILER ERROR.\nPlease report this problem.\nnull");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(result4);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "hi!" + "'", str14.equals("hi!"));
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "hi!" + "'", str24.equals("hi!"));
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertNotNull(node32);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        try {
            java.lang.String str2 = com.google.javascript.rhino.ScriptRuntime.escapeString("module$STRING hi!", '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: unexpected quote char:4");
        } catch (java.lang.IllegalStateException e) {
        }
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.breakNode();
        boolean boolean1 = node0.isNumber();
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean3 = node2.isFor();
        boolean boolean4 = node2.isExprResult();
        java.lang.String str5 = node2.getString();
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean8 = node7.isFor();
        boolean boolean9 = node7.isExprResult();
        com.google.javascript.rhino.Node node10 = node2.clonePropsFrom(node7);
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean13 = node12.isFor();
        boolean boolean14 = node12.isExprResult();
        java.lang.String str15 = node12.getString();
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean18 = node17.isFor();
        boolean boolean19 = node17.isExprResult();
        com.google.javascript.rhino.Node node20 = node12.clonePropsFrom(node17);
        boolean boolean21 = node20.isVar();
        node20.setSourceEncodedPositionForTree(16);
        com.google.javascript.rhino.Node node24 = new com.google.javascript.rhino.Node(10, node7, node20);
        com.google.javascript.jscomp.SourceFile sourceFile26 = com.google.javascript.jscomp.SourceFile.fromFile("hi!");
        node24.setStaticSourceFile((com.google.javascript.rhino.jstype.StaticSourceFile) sourceFile26);
        com.google.javascript.rhino.Node node28 = null;
        try {
            com.google.javascript.rhino.Node node29 = node24.useSourceInfoFrom(node28);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "hi!" + "'", str15.equals("hi!"));
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(sourceFile26);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        com.google.javascript.jscomp.SourceFile.Builder builder0 = new com.google.javascript.jscomp.SourceFile.Builder();
        try {
            com.google.javascript.jscomp.SourceFile sourceFile2 = builder0.buildFromFile("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: a source must have a name");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        int int0 = com.google.javascript.rhino.Node.QUOTED_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 36 + "'", int0 == 36);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        java.util.logging.Logger logger0 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager1 = new com.google.javascript.jscomp.LoggerErrorManager(logger0);
        double double2 = loggerErrorManager1.getTypedPercent();
        com.google.javascript.jscomp.Compiler compiler3 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager1);
        com.google.javascript.jscomp.Result result4 = compiler3.getResult();
        java.util.logging.Logger logger5 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager6 = new com.google.javascript.jscomp.LoggerErrorManager(logger5);
        double double7 = loggerErrorManager6.getTypedPercent();
        compiler3.setErrorManager((com.google.javascript.jscomp.ErrorManager) loggerErrorManager6);
        com.google.javascript.jscomp.NodeTraversal.Callback callback9 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal10 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler3, callback9);
        com.google.javascript.rhino.Node node14 = new com.google.javascript.rhino.Node((int) (byte) 100, (int) (byte) 1, 54);
        boolean boolean15 = node14.hasOneChild();
        boolean boolean16 = node14.isWhile();
        try {
            nodeTraversal10.traverse(node14);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: INTERNAL COMPILER ERROR.\nPlease report this problem.\nnull");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(result4);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean3 = node2.isFor();
        boolean boolean4 = node2.isExprResult();
        java.lang.String str5 = node2.getString();
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean8 = node7.isFor();
        boolean boolean9 = node7.isExprResult();
        com.google.javascript.rhino.Node node10 = node2.clonePropsFrom(node7);
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean13 = node12.isFor();
        boolean boolean14 = node12.isExprResult();
        java.lang.String str15 = node12.getString();
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean18 = node17.isFor();
        boolean boolean19 = node17.isExprResult();
        com.google.javascript.rhino.Node node20 = node12.clonePropsFrom(node17);
        boolean boolean21 = node20.isVar();
        node20.setSourceEncodedPositionForTree(16);
        com.google.javascript.rhino.Node node24 = new com.google.javascript.rhino.Node(10, node7, node20);
        com.google.javascript.jscomp.SourceFile sourceFile26 = com.google.javascript.jscomp.SourceFile.fromFile("hi!");
        node24.setStaticSourceFile((com.google.javascript.rhino.jstype.StaticSourceFile) sourceFile26);
        com.google.javascript.rhino.Node node28 = com.google.javascript.rhino.IR.paramList();
        com.google.javascript.rhino.Node node29 = node24.srcref(node28);
        try {
            com.google.javascript.rhino.Node node30 = com.google.javascript.rhino.IR.block(node24);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "hi!" + "'", str15.equals("hi!"));
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(sourceFile26);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertNotNull(node29);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newString("hi!");
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.IR.voidNode(node1);
        java.lang.String str6 = node1.toString(true, false, false);
        com.google.javascript.rhino.Node node8 = node1.getChildAtIndex((int) (byte) -1);
        com.google.javascript.rhino.Node node12 = new com.google.javascript.rhino.Node((int) (byte) 100, (int) (byte) 1, 54);
        boolean boolean13 = node12.wasEmptyNode();
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.InputId inputId15 = com.google.javascript.jscomp.NodeUtil.getInputId(node14);
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean19 = node18.isFor();
        boolean boolean20 = node18.isExprResult();
        java.lang.String str21 = node18.getString();
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean24 = node23.isFor();
        boolean boolean25 = node23.isExprResult();
        com.google.javascript.rhino.Node node26 = node18.clonePropsFrom(node23);
        com.google.javascript.rhino.Node node28 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean29 = node28.isFor();
        boolean boolean30 = node28.isExprResult();
        java.lang.String str31 = node28.getString();
        com.google.javascript.rhino.Node node33 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean34 = node33.isFor();
        boolean boolean35 = node33.isExprResult();
        com.google.javascript.rhino.Node node36 = node28.clonePropsFrom(node33);
        boolean boolean37 = node36.isVar();
        node36.setSourceEncodedPositionForTree(16);
        com.google.javascript.rhino.Node node40 = new com.google.javascript.rhino.Node(10, node23, node36);
        com.google.javascript.rhino.Node node41 = node40.cloneTree();
        com.google.javascript.rhino.Node node43 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean44 = node43.isFor();
        boolean boolean45 = node43.isExprResult();
        java.lang.String str46 = node43.getString();
        com.google.javascript.rhino.Node node48 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean49 = node48.isFor();
        boolean boolean50 = node48.isExprResult();
        com.google.javascript.rhino.Node node51 = node43.clonePropsFrom(node48);
        com.google.javascript.rhino.Node node53 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean54 = node53.isFor();
        boolean boolean55 = node53.isExprResult();
        java.lang.String str56 = node53.getString();
        com.google.javascript.rhino.Node node58 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean59 = node58.isFor();
        boolean boolean60 = node58.isExprResult();
        com.google.javascript.rhino.Node node61 = node53.clonePropsFrom(node58);
        boolean boolean62 = node61.isVar();
        node61.setSourceEncodedPositionForTree(16);
        java.lang.String str65 = node61.getQualifiedName();
        com.google.javascript.rhino.Node node69 = new com.google.javascript.rhino.Node((int) (byte) 100, (int) (byte) 1, 54);
        boolean boolean70 = node69.hasOneChild();
        boolean boolean71 = node69.isWhile();
        com.google.javascript.rhino.Node[] nodeArray72 = new com.google.javascript.rhino.Node[] { node12, node14, node41, node48, node61, node69 };
        try {
            com.google.javascript.rhino.Node node73 = com.google.javascript.rhino.IR.newNode(node8, nodeArray72);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "STRING hi!" + "'", str6.equals("STRING hi!"));
        org.junit.Assert.assertNull(node8);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNull(inputId15);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "hi!" + "'", str21.equals("hi!"));
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "hi!" + "'", str31.equals("hi!"));
        org.junit.Assert.assertNotNull(node33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(node36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(node41);
        org.junit.Assert.assertNotNull(node43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "hi!" + "'", str46.equals("hi!"));
        org.junit.Assert.assertNotNull(node48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(node51);
        org.junit.Assert.assertNotNull(node53);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertTrue("'" + str56 + "' != '" + "hi!" + "'", str56.equals("hi!"));
        org.junit.Assert.assertNotNull(node58);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertNotNull(node61);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertNull(str65);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
        org.junit.Assert.assertNotNull(nodeArray72);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        java.util.logging.Logger logger0 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager1 = new com.google.javascript.jscomp.LoggerErrorManager(logger0);
        double double2 = loggerErrorManager1.getTypedPercent();
        com.google.javascript.jscomp.Compiler compiler3 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager1);
        com.google.javascript.jscomp.Result result4 = compiler3.getResult();
        java.util.logging.Logger logger5 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager6 = new com.google.javascript.jscomp.LoggerErrorManager(logger5);
        double double7 = loggerErrorManager6.getTypedPercent();
        compiler3.setErrorManager((com.google.javascript.jscomp.ErrorManager) loggerErrorManager6);
        try {
            compiler3.processDefines();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(result4);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        com.google.javascript.jscomp.AnonymousFunctionNamingPolicy anonymousFunctionNamingPolicy0 = com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF;
        char[] charArray1 = anonymousFunctionNamingPolicy0.getReservedCharacters();
        org.junit.Assert.assertTrue("'" + anonymousFunctionNamingPolicy0 + "' != '" + com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF + "'", anonymousFunctionNamingPolicy0.equals(com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF));
        org.junit.Assert.assertNull(charArray1);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        com.google.javascript.jscomp.CodingConvention codingConvention0 = com.google.javascript.jscomp.CodingConventions.getDefault();
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention1 = new com.google.javascript.jscomp.ClosureCodingConvention(codingConvention0);
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString("hi!");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.IR.voidNode(node3);
        try {
            boolean boolean5 = closureCodingConvention1.isPropertyTestFunction(node3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(codingConvention0);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(node4);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy0 = com.google.javascript.jscomp.PropertyRenamingPolicy.HEURISTIC;
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy0 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.HEURISTIC + "'", propertyRenamingPolicy0.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.HEURISTIC));
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        com.google.javascript.jscomp.SourceMap.LocationMapping locationMapping2 = new com.google.javascript.jscomp.SourceMap.LocationMapping("STRING hi! [jsdoc_info: JSDocInfo]", "");
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean3 = node2.isFor();
        boolean boolean4 = node2.isExprResult();
        java.lang.String str5 = node2.getString();
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean8 = node7.isFor();
        boolean boolean9 = node7.isExprResult();
        com.google.javascript.rhino.Node node10 = node2.clonePropsFrom(node7);
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean13 = node12.isFor();
        boolean boolean14 = node12.isExprResult();
        java.lang.String str15 = node12.getString();
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean18 = node17.isFor();
        boolean boolean19 = node17.isExprResult();
        com.google.javascript.rhino.Node node20 = node12.clonePropsFrom(node17);
        boolean boolean21 = node20.isVar();
        node20.setSourceEncodedPositionForTree(16);
        com.google.javascript.rhino.Node node24 = new com.google.javascript.rhino.Node(10, node7, node20);
        com.google.javascript.jscomp.SourceFile sourceFile26 = com.google.javascript.jscomp.SourceFile.fromFile("hi!");
        node24.setStaticSourceFile((com.google.javascript.rhino.jstype.StaticSourceFile) sourceFile26);
        com.google.javascript.rhino.Node node28 = com.google.javascript.rhino.IR.paramList();
        com.google.javascript.rhino.Node node29 = node24.srcref(node28);
        boolean boolean30 = node28.isVoid();
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "hi!" + "'", str15.equals("hi!"));
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(sourceFile26);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        boolean boolean1 = com.google.javascript.jscomp.NodeUtil.isValidSimpleName("hi!. hi! at (unknown source) line (unknown line) : (unknown column)");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        java.util.logging.Logger logger0 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager1 = new com.google.javascript.jscomp.LoggerErrorManager(logger0);
        double double2 = loggerErrorManager1.getTypedPercent();
        com.google.javascript.jscomp.Compiler compiler3 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager1);
        com.google.javascript.jscomp.Result result4 = compiler3.getResult();
        java.lang.String str5 = compiler3.getAstDotGraph();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile6 = null;
        java.nio.charset.Charset charset8 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile9 = com.google.javascript.jscomp.JSSourceFile.fromFile("hi!. hi! at (unknown source) line (unknown line) : (unknown column)", charset8);
        com.google.javascript.jscomp.CompilerOptions compilerOptions10 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel11 = compilerOptions10.reportMissingOverride;
        compilerOptions10.setAppNameStr("module$STRING hi!");
        boolean boolean14 = compilerOptions10.crossModuleMethodMotion;
        boolean boolean15 = compilerOptions10.computeFunctionSideEffects;
        compilerOptions10.locale = "module$STRING hi!";
        compilerOptions10.setComputeFunctionSideEffects(true);
        compilerOptions10.setAliasableGlobals("hi!");
        try {
            com.google.javascript.jscomp.Result result22 = compiler3.compile(jSSourceFile6, jSSourceFile9, compilerOptions10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(result4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertNotNull(jSSourceFile9);
        org.junit.Assert.assertTrue("'" + checkLevel11 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel11.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.GLOBAL_THIS;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        java.util.logging.Logger logger0 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager1 = new com.google.javascript.jscomp.LoggerErrorManager(logger0);
        double double2 = loggerErrorManager1.getTypedPercent();
        com.google.javascript.jscomp.Compiler compiler3 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager1);
        com.google.javascript.jscomp.Result result4 = compiler3.getResult();
        java.lang.String str5 = compiler3.getAstDotGraph();
        com.google.javascript.jscomp.JSError[] jSErrorArray6 = compiler3.getWarnings();
        try {
            java.lang.String[] strArray7 = compiler3.toSourceArray();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(result4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertNotNull(jSErrorArray6);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        java.util.logging.Logger logger0 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager1 = new com.google.javascript.jscomp.LoggerErrorManager(logger0);
        double double2 = loggerErrorManager1.getTypedPercent();
        com.google.javascript.jscomp.Compiler compiler3 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager1);
        com.google.javascript.jscomp.Result result4 = compiler3.getResult();
        java.util.logging.Logger logger5 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager6 = new com.google.javascript.jscomp.LoggerErrorManager(logger5);
        double double7 = loggerErrorManager6.getTypedPercent();
        compiler3.setErrorManager((com.google.javascript.jscomp.ErrorManager) loggerErrorManager6);
        com.google.javascript.jscomp.NodeTraversal.Callback callback9 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal10 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler3, callback9);
        com.google.javascript.rhino.Node node11 = nodeTraversal10.getEnclosingFunction();
        boolean boolean12 = nodeTraversal10.hasScope();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(result4);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNull(node11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.reportMissingOverride;
        compilerOptions0.setAppNameStr("module$STRING hi!");
        boolean boolean4 = compilerOptions0.crossModuleMethodMotion;
        boolean boolean5 = compilerOptions0.computeFunctionSideEffects;
        compilerOptions0.locale = "module$STRING hi!";
        compilerOptions0.setPreferLineBreakAtEndOfFile(true);
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        java.io.InputStream inputStream1 = null;
        try {
            com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromInputStream("Unknown class name", inputStream1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        com.google.javascript.jscomp.SourceFile.Builder builder0 = new com.google.javascript.jscomp.SourceFile.Builder();
        java.io.InputStream inputStream2 = null;
        try {
            com.google.javascript.jscomp.SourceFile sourceFile3 = builder0.buildFromInputStream("hi!", inputStream2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        int int0 = com.google.javascript.rhino.Node.DECR_FLAG;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.UNKNOWN_DEFINES;
        com.google.javascript.jscomp.DiagnosticGroups.DEBUGGER_STATEMENT_PRESENT = diagnosticGroup0;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        int int0 = com.google.javascript.rhino.Node.BRACELESS_TYPE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 41 + "'", int0 == 41);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        int int0 = com.google.javascript.rhino.Node.SOURCENAME_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 16 + "'", int0 == 16);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.ACCESS_CONTROLS;
        com.google.javascript.jscomp.DiagnosticGroups.STRICT_MODULE_DEP_CHECK = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticGroups.VISIBILITY = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticGroups.MISSING_PROPERTIES = diagnosticGroup0;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        java.util.logging.Logger logger0 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager1 = new com.google.javascript.jscomp.LoggerErrorManager(logger0);
        double double2 = loggerErrorManager1.getTypedPercent();
        com.google.javascript.jscomp.Compiler compiler3 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager1);
        try {
            boolean boolean4 = compiler3.isIdeMode();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean2 = node1.isFor();
        boolean boolean3 = node1.isExprResult();
        java.lang.String str4 = node1.getString();
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean7 = node6.isFor();
        boolean boolean8 = node6.isExprResult();
        com.google.javascript.rhino.Node node9 = node1.clonePropsFrom(node6);
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.IR.pos(node1);
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean13 = node12.isFor();
        boolean boolean14 = node12.isExprResult();
        java.lang.String str15 = node12.getString();
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean18 = node17.isFor();
        boolean boolean19 = node17.isExprResult();
        com.google.javascript.rhino.Node node20 = node12.clonePropsFrom(node17);
        com.google.javascript.jscomp.CompilerOptions compilerOptions21 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel22 = compilerOptions21.reportMissingOverride;
        java.lang.String[] strArray29 = new java.lang.String[] { "STRING hi!", "hi!. hi! at (unknown source) line (unknown line) : (unknown column)", "module$STRING hi!", "hi!", "", "STRING hi!" };
        java.util.LinkedHashSet<java.lang.String> strSet30 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean31 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet30, strArray29);
        compilerOptions21.setIdGenerators((java.util.Set<java.lang.String>) strSet30);
        node12.setDirectives((java.util.Set<java.lang.String>) strSet30);
        com.google.javascript.rhino.Node node35 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean36 = node35.isFor();
        boolean boolean37 = node35.isExprResult();
        java.lang.String str38 = node35.getString();
        com.google.javascript.rhino.Node node40 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean41 = node40.isFor();
        boolean boolean42 = node40.isExprResult();
        com.google.javascript.rhino.Node node43 = node35.clonePropsFrom(node40);
        com.google.javascript.rhino.Node node45 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean46 = node45.isFor();
        boolean boolean47 = node45.isExprResult();
        com.google.javascript.rhino.Node node49 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean50 = node49.isFor();
        com.google.javascript.rhino.Node node51 = node45.clonePropsFrom(node49);
        node49.addSuppression("module$STRING hi!");
        com.google.javascript.rhino.Node node55 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean56 = node55.isFor();
        boolean boolean57 = node55.isExprResult();
        java.lang.String str58 = node55.getString();
        com.google.javascript.rhino.Node node60 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean61 = node60.isFor();
        boolean boolean62 = node60.isExprResult();
        com.google.javascript.rhino.Node node63 = node55.clonePropsFrom(node60);
        com.google.javascript.rhino.Node node65 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean66 = node65.isFor();
        boolean boolean67 = node65.isExprResult();
        java.lang.String str68 = node65.getString();
        com.google.javascript.rhino.Node node70 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean71 = node70.isFor();
        boolean boolean72 = node70.isExprResult();
        com.google.javascript.rhino.Node node73 = node65.clonePropsFrom(node70);
        int int74 = node60.getIndexOfChild(node65);
        com.google.javascript.rhino.Node node75 = node60.cloneTree();
        com.google.javascript.rhino.Node node76 = com.google.javascript.rhino.IR.comma(node49, node75);
        com.google.javascript.rhino.Node node77 = com.google.javascript.rhino.IR.sheq(node35, node76);
        try {
            com.google.javascript.rhino.Node node78 = com.google.javascript.rhino.IR.forIn(node1, node12, node35);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "hi!" + "'", str4.equals("hi!"));
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "hi!" + "'", str15.equals("hi!"));
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertTrue("'" + checkLevel22 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel22.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(strArray29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "hi!" + "'", str38.equals("hi!"));
        org.junit.Assert.assertNotNull(node40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(node43);
        org.junit.Assert.assertNotNull(node45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(node49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(node51);
        org.junit.Assert.assertNotNull(node55);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "hi!" + "'", str58.equals("hi!"));
        org.junit.Assert.assertNotNull(node60);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertNotNull(node63);
        org.junit.Assert.assertNotNull(node65);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
        org.junit.Assert.assertTrue("'" + str68 + "' != '" + "hi!" + "'", str68.equals("hi!"));
        org.junit.Assert.assertNotNull(node70);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
        org.junit.Assert.assertNotNull(node73);
        org.junit.Assert.assertTrue("'" + int74 + "' != '" + (-1) + "'", int74 == (-1));
        org.junit.Assert.assertNotNull(node75);
        org.junit.Assert.assertNotNull(node76);
        org.junit.Assert.assertNotNull(node77);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        java.util.logging.Logger logger0 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager1 = new com.google.javascript.jscomp.LoggerErrorManager(logger0);
        double double2 = loggerErrorManager1.getTypedPercent();
        com.google.javascript.jscomp.Compiler compiler3 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager1);
        com.google.javascript.jscomp.Result result4 = compiler3.getResult();
        java.util.logging.Logger logger5 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager6 = new com.google.javascript.jscomp.LoggerErrorManager(logger5);
        double double7 = loggerErrorManager6.getTypedPercent();
        compiler3.setErrorManager((com.google.javascript.jscomp.ErrorManager) loggerErrorManager6);
        compiler3.disableThreads();
        try {
            compiler3.rebuildInputsFromModules();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(result4);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean2 = node1.isFor();
        boolean boolean3 = node1.isExprResult();
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean6 = node5.isFor();
        com.google.javascript.rhino.Node node7 = node1.clonePropsFrom(node5);
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean10 = node9.isFor();
        boolean boolean11 = node9.isExprResult();
        java.lang.String str12 = node9.getString();
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean15 = node14.isFor();
        boolean boolean16 = node14.isExprResult();
        com.google.javascript.rhino.Node node17 = node9.clonePropsFrom(node14);
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean20 = node19.isFor();
        boolean boolean21 = node19.isExprResult();
        java.lang.String str22 = node19.getString();
        com.google.javascript.rhino.Node node24 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean25 = node24.isFor();
        boolean boolean26 = node24.isExprResult();
        com.google.javascript.rhino.Node node27 = node19.clonePropsFrom(node24);
        int int28 = node14.getIndexOfChild(node19);
        com.google.javascript.rhino.Node node29 = node14.cloneTree();
        node14.setString("module$STRING hi!");
        com.google.javascript.rhino.Node node33 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean34 = node33.isFor();
        boolean boolean35 = node33.isExprResult();
        com.google.javascript.rhino.Node node37 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean38 = node37.isFor();
        com.google.javascript.rhino.Node node39 = node33.clonePropsFrom(node37);
        boolean boolean40 = node33.isOnlyModifiesThisCall();
        com.google.javascript.rhino.Node node42 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean43 = node42.isFor();
        boolean boolean44 = node42.isExprResult();
        java.lang.String str45 = node42.getString();
        com.google.javascript.rhino.Node node47 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean48 = node47.isFor();
        boolean boolean49 = node47.isExprResult();
        com.google.javascript.rhino.Node node50 = node42.clonePropsFrom(node47);
        boolean boolean51 = node50.isVar();
        com.google.javascript.rhino.Node node52 = node33.useSourceInfoFromForTree(node50);
        try {
            node1.replaceChildAfter(node14, node33);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: prev is not a child of this node.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "hi!" + "'", str12.equals("hi!"));
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "hi!" + "'", str22.equals("hi!"));
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(node27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1) + "'", int28 == (-1));
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNotNull(node33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(node37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(node39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(node42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "hi!" + "'", str45.equals("hi!"));
        org.junit.Assert.assertNotNull(node47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNotNull(node50);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertNotNull(node52);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.reportMissingOverride;
        compilerOptions0.setAppNameStr("module$STRING hi!");
        boolean boolean4 = compilerOptions0.crossModuleMethodMotion;
        boolean boolean5 = compilerOptions0.computeFunctionSideEffects;
        byte[] byteArray6 = compilerOptions0.inputVariableMapSerialized;
        compilerOptions0.checkMissingGetCssNameBlacklist = "hi!";
        boolean boolean9 = compilerOptions0.isExternExportsEnabled();
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(byteArray6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        int int0 = com.google.javascript.rhino.Node.FLAG_THIS_UNMODIFIED;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean3 = node2.isFor();
        boolean boolean4 = node2.isExprResult();
        java.lang.String str5 = node2.getString();
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean8 = node7.isFor();
        boolean boolean9 = node7.isExprResult();
        com.google.javascript.rhino.Node node10 = node2.clonePropsFrom(node7);
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean13 = node12.isFor();
        boolean boolean14 = node12.isExprResult();
        java.lang.String str15 = node12.getString();
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean18 = node17.isFor();
        boolean boolean19 = node17.isExprResult();
        com.google.javascript.rhino.Node node20 = node12.clonePropsFrom(node17);
        boolean boolean21 = node20.isVar();
        node20.setSourceEncodedPositionForTree(16);
        com.google.javascript.rhino.Node node24 = new com.google.javascript.rhino.Node(10, node7, node20);
        com.google.javascript.jscomp.SourceFile sourceFile26 = com.google.javascript.jscomp.SourceFile.fromFile("hi!");
        node24.setStaticSourceFile((com.google.javascript.rhino.jstype.StaticSourceFile) sourceFile26);
        try {
            java.io.Reader reader28 = sourceFile26.getCodeReader();
            org.junit.Assert.fail("Expected exception of type java.io.FileNotFoundException; message: hi! (No such file or directory)");
        } catch (java.io.FileNotFoundException e) {
        }
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "hi!" + "'", str15.equals("hi!"));
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(sourceFile26);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        int int0 = com.google.javascript.rhino.Node.IS_NAMESPACE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 46 + "'", int0 == 46);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        java.io.InputStream inputStream1 = null;
        try {
            com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromInputStream("// Input %num%", inputStream1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        com.google.javascript.rhino.jstype.ObjectType objectType0 = null;
        try {
            com.google.javascript.rhino.jstype.ObjectType objectType2 = com.google.javascript.rhino.jstype.FunctionType.getTopDefiningInterface(objectType0, "hi!. hi! at (unknown source) line (unknown line) : (unknown column)");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        com.google.javascript.rhino.Node node3 = new com.google.javascript.rhino.Node((int) (byte) 100, (int) (byte) 1, 54);
        boolean boolean4 = node3.hasOneChild();
        boolean boolean5 = node3.isWhile();
        node3.setLineno(50);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        com.google.javascript.jscomp.SourceFile sourceFile1 = com.google.javascript.jscomp.SourceFile.fromFile("hi!");
        boolean boolean2 = sourceFile1.isExtern();
        com.google.javascript.jscomp.JsAst jsAst3 = new com.google.javascript.jscomp.JsAst(sourceFile1);
        com.google.javascript.jscomp.CompilerInput compilerInput6 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) jsAst3, "// Input %num%", false);
        com.google.javascript.jscomp.AbstractCompiler abstractCompiler7 = null;
        try {
            com.google.javascript.rhino.Node node8 = compilerInput6.getAstRoot(abstractCompiler7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(sourceFile1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        long long0 = com.google.javascript.rhino.InputId.serialVersionUID;
        org.junit.Assert.assertTrue("'" + long0 + "' != '" + 1L + "'", long0 == 1L);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean2 = node1.isFor();
        boolean boolean3 = node1.isExprResult();
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean6 = node5.isFor();
        com.google.javascript.rhino.Node node7 = node1.clonePropsFrom(node5);
        node5.addSuppression("module$STRING hi!");
        java.lang.String str13 = node5.toString(true, true, false);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder14 = node5.new FileLevelJsDocBuilder();
        fileLevelJsDocBuilder14.append("goog.global");
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "STRING hi! [jsdoc_info: JSDocInfo]" + "'", str13.equals("STRING hi! [jsdoc_info: JSDocInfo]"));
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.NodeTraversal.Callback callback2 = null;
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean6 = node5.isFor();
        boolean boolean7 = node5.isExprResult();
        java.lang.String str8 = node5.getString();
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean11 = node10.isFor();
        boolean boolean12 = node10.isExprResult();
        com.google.javascript.rhino.Node node13 = node5.clonePropsFrom(node10);
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean16 = node15.isFor();
        boolean boolean17 = node15.isExprResult();
        java.lang.String str18 = node15.getString();
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean21 = node20.isFor();
        boolean boolean22 = node20.isExprResult();
        com.google.javascript.rhino.Node node23 = node15.clonePropsFrom(node20);
        boolean boolean24 = node23.isVar();
        node23.setSourceEncodedPositionForTree(16);
        com.google.javascript.rhino.Node node27 = new com.google.javascript.rhino.Node(10, node10, node23);
        com.google.javascript.rhino.Node node28 = node27.cloneTree();
        com.google.javascript.rhino.Node[] nodeArray29 = new com.google.javascript.rhino.Node[] { node28 };
        try {
            com.google.javascript.jscomp.NodeTraversal.traverseRoots((com.google.javascript.jscomp.AbstractCompiler) compiler1, callback2, nodeArray29);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: INTERNAL COMPILER ERROR.\nPlease report this problem.\nnull");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "hi!" + "'", str8.equals("hi!"));
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "hi!" + "'", str18.equals("hi!"));
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertNotNull(nodeArray29);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean2 = node1.isFor();
        boolean boolean3 = node1.isExprResult();
        java.lang.String str4 = node1.getString();
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean7 = node6.isFor();
        boolean boolean8 = node6.isExprResult();
        com.google.javascript.rhino.Node node9 = node1.clonePropsFrom(node6);
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean12 = node11.isFor();
        boolean boolean13 = node11.isExprResult();
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean16 = node15.isFor();
        com.google.javascript.rhino.Node node17 = node11.clonePropsFrom(node15);
        node15.addSuppression("module$STRING hi!");
        com.google.javascript.rhino.Node node21 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean22 = node21.isFor();
        boolean boolean23 = node21.isExprResult();
        java.lang.String str24 = node21.getString();
        com.google.javascript.rhino.Node node26 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean27 = node26.isFor();
        boolean boolean28 = node26.isExprResult();
        com.google.javascript.rhino.Node node29 = node21.clonePropsFrom(node26);
        com.google.javascript.rhino.Node node31 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean32 = node31.isFor();
        boolean boolean33 = node31.isExprResult();
        java.lang.String str34 = node31.getString();
        com.google.javascript.rhino.Node node36 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean37 = node36.isFor();
        boolean boolean38 = node36.isExprResult();
        com.google.javascript.rhino.Node node39 = node31.clonePropsFrom(node36);
        int int40 = node26.getIndexOfChild(node31);
        com.google.javascript.rhino.Node node41 = node26.cloneTree();
        com.google.javascript.rhino.Node node42 = com.google.javascript.rhino.IR.comma(node15, node41);
        com.google.javascript.rhino.Node node43 = com.google.javascript.rhino.IR.sheq(node1, node42);
        com.google.javascript.rhino.Node[] nodeArray44 = new com.google.javascript.rhino.Node[] { node42 };
        try {
            com.google.javascript.rhino.Node node45 = com.google.javascript.rhino.IR.arraylit(nodeArray44);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "hi!" + "'", str4.equals("hi!"));
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "hi!" + "'", str24.equals("hi!"));
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "hi!" + "'", str34.equals("hi!"));
        org.junit.Assert.assertNotNull(node36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(node39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + (-1) + "'", int40 == (-1));
        org.junit.Assert.assertNotNull(node41);
        org.junit.Assert.assertNotNull(node42);
        org.junit.Assert.assertNotNull(node43);
        org.junit.Assert.assertNotNull(nodeArray44);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        java.util.logging.Logger logger0 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager1 = new com.google.javascript.jscomp.LoggerErrorManager(logger0);
        double double2 = loggerErrorManager1.getTypedPercent();
        com.google.javascript.jscomp.Compiler compiler3 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager1);
        com.google.javascript.jscomp.Result result4 = compiler3.getResult();
        java.util.logging.Logger logger5 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager6 = new com.google.javascript.jscomp.LoggerErrorManager(logger5);
        double double7 = loggerErrorManager6.getTypedPercent();
        compiler3.setErrorManager((com.google.javascript.jscomp.ErrorManager) loggerErrorManager6);
        com.google.javascript.jscomp.NodeTraversal.Callback callback9 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal10 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler3, callback9);
        com.google.javascript.jscomp.Scope scope11 = compiler3.getTopScope();
        try {
            boolean boolean12 = compiler3.acceptConstKeyword();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(result4);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNull(scope11);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.breakNode();
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean3 = node2.isFor();
        boolean boolean4 = node2.isExprResult();
        java.lang.String str5 = node2.getString();
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean8 = node7.isFor();
        boolean boolean9 = node7.isExprResult();
        com.google.javascript.rhino.Node node10 = node2.clonePropsFrom(node7);
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean13 = node12.isFor();
        boolean boolean14 = node12.isExprResult();
        java.lang.String str15 = node12.getString();
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean18 = node17.isFor();
        boolean boolean19 = node17.isExprResult();
        com.google.javascript.rhino.Node node20 = node12.clonePropsFrom(node17);
        int int21 = node7.getIndexOfChild(node12);
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean24 = node23.isFor();
        boolean boolean25 = node23.isExprResult();
        java.lang.String str26 = node23.getString();
        com.google.javascript.rhino.Node node28 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean29 = node28.isFor();
        boolean boolean30 = node28.isExprResult();
        com.google.javascript.rhino.Node node31 = node23.clonePropsFrom(node28);
        com.google.javascript.rhino.Node node32 = com.google.javascript.rhino.IR.sheq(node7, node28);
        com.google.javascript.rhino.Node node34 = node7.getChildAtIndex(0);
        try {
            com.google.javascript.rhino.Node node35 = com.google.javascript.rhino.IR.tryCatch(node0, node34);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "hi!" + "'", str15.equals("hi!"));
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "hi!" + "'", str26.equals("hi!"));
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertNotNull(node32);
        org.junit.Assert.assertNull(node34);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        com.google.javascript.jscomp.DiagnosticType diagnosticType2 = com.google.javascript.jscomp.DiagnosticType.disabled("hi!", "");
        com.google.javascript.jscomp.CheckLevel checkLevel3 = diagnosticType2.defaultLevel;
        java.text.MessageFormat messageFormat4 = diagnosticType2.format;
        org.junit.Assert.assertNotNull(diagnosticType2);
        org.junit.Assert.assertTrue("'" + checkLevel3 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel3.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(messageFormat4);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.reportMissingOverride;
        compilerOptions0.setAppNameStr("module$STRING hi!");
        boolean boolean4 = compilerOptions0.crossModuleMethodMotion;
        boolean boolean5 = compilerOptions0.computeFunctionSideEffects;
        compilerOptions0.setDefineToBooleanLiteral("", false);
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.InputId inputId1 = com.google.javascript.jscomp.NodeUtil.getInputId(node0);
        java.lang.Appendable appendable2 = null;
        try {
            node0.appendStringTree(appendable2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertNull(inputId1);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean2 = node1.isFor();
        boolean boolean3 = node1.isExprResult();
        java.lang.String str4 = node1.getString();
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean7 = node6.isFor();
        boolean boolean8 = node6.isExprResult();
        com.google.javascript.rhino.Node node9 = node1.clonePropsFrom(node6);
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean12 = node11.isFor();
        boolean boolean13 = node11.isExprResult();
        java.lang.String str14 = node11.getString();
        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean17 = node16.isFor();
        boolean boolean18 = node16.isExprResult();
        com.google.javascript.rhino.Node node19 = node11.clonePropsFrom(node16);
        int int20 = node6.getIndexOfChild(node11);
        com.google.javascript.rhino.Node node21 = node6.cloneTree();
        try {
            double double22 = node6.getDouble();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: STRING hi! is not a number node");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "hi!" + "'", str4.equals("hi!"));
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "hi!" + "'", str14.equals("hi!"));
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
        org.junit.Assert.assertNotNull(node21);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.block();
        org.junit.Assert.assertNotNull(node0);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        java.util.logging.Logger logger0 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager1 = new com.google.javascript.jscomp.LoggerErrorManager(logger0);
        double double2 = loggerErrorManager1.getTypedPercent();
        com.google.javascript.jscomp.Compiler compiler3 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager1);
        com.google.javascript.jscomp.Result result4 = compiler3.getResult();
        java.util.logging.Logger logger5 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager6 = new com.google.javascript.jscomp.LoggerErrorManager(logger5);
        double double7 = loggerErrorManager6.getTypedPercent();
        compiler3.setErrorManager((com.google.javascript.jscomp.ErrorManager) loggerErrorManager6);
        com.google.javascript.jscomp.NodeTraversal.Callback callback9 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal10 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler3, callback9);
        try {
            compiler3.normalize();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(result4);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        com.google.javascript.jscomp.CodingConvention codingConvention0 = com.google.javascript.jscomp.CodingConventions.getDefault();
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention1 = new com.google.javascript.jscomp.ClosureCodingConvention(codingConvention0);
        boolean boolean4 = closureCodingConvention1.isExported("hi!", true);
        com.google.javascript.rhino.Node node5 = null;
        try {
            boolean boolean6 = closureCodingConvention1.isPropertyTestFunction(node5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(codingConvention0);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

//    @Test
//    public void test140() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test140");
//        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.ES5_STRICT;
//        com.google.javascript.jscomp.DiagnosticGroups.UNDEFINED_VARIABLES = diagnosticGroup0;
//        com.google.javascript.jscomp.DiagnosticGroups.EXTERNS_VALIDATION = diagnosticGroup0;
//        org.junit.Assert.assertNotNull(diagnosticGroup0);
//    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean2 = node1.isFor();
        boolean boolean3 = node1.isExprResult();
        java.lang.String str4 = node1.getString();
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean7 = node6.isFor();
        boolean boolean8 = node6.isExprResult();
        com.google.javascript.rhino.Node node9 = node1.clonePropsFrom(node6);
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.IR.pos(node1);
        java.lang.Class<?> wildcardClass11 = node10.getClass();
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "hi!" + "'", str4.equals("hi!"));
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(wildcardClass11);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean2 = node1.isFor();
        boolean boolean3 = node1.isExprResult();
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean6 = node5.isFor();
        com.google.javascript.rhino.Node node7 = node1.clonePropsFrom(node5);
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString("hi!");
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.IR.voidNode(node9);
        boolean boolean12 = node9.getBooleanProp(0);
        boolean boolean13 = node9.isExprResult();
        boolean boolean14 = node9.isDelProp();
        try {
            node1.addChildToFront(node9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        com.google.javascript.jscomp.SourceFile sourceFile1 = com.google.javascript.jscomp.SourceFile.fromFile("hi!");
        boolean boolean2 = sourceFile1.isExtern();
        com.google.javascript.jscomp.JsAst jsAst3 = new com.google.javascript.jscomp.JsAst(sourceFile1);
        java.util.logging.Logger logger4 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager5 = new com.google.javascript.jscomp.LoggerErrorManager(logger4);
        double double6 = loggerErrorManager5.getTypedPercent();
        com.google.javascript.jscomp.Compiler compiler7 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager5);
        com.google.javascript.jscomp.Result result8 = compiler7.getResult();
        java.util.logging.Logger logger9 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager10 = new com.google.javascript.jscomp.LoggerErrorManager(logger9);
        double double11 = loggerErrorManager10.getTypedPercent();
        compiler7.setErrorManager((com.google.javascript.jscomp.ErrorManager) loggerErrorManager10);
        com.google.javascript.jscomp.NodeTraversal.Callback callback13 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal14 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler7, callback13);
        com.google.javascript.jscomp.Scope scope15 = compiler7.getTopScope();
        com.google.javascript.rhino.Node node16 = jsAst3.getAstRoot((com.google.javascript.jscomp.AbstractCompiler) compiler7);
        com.google.javascript.jscomp.Compiler.IntermediateState intermediateState17 = null;
        try {
            compiler7.setState(intermediateState17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(sourceFile1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(result8);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNull(scope15);
        org.junit.Assert.assertNotNull(node16);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        java.lang.String str0 = com.google.javascript.jscomp.ProcessCommonJSModules.DEFAULT_FILENAME_PREFIX;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "./" + "'", str0.equals("./"));
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newString("hi!");
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.IR.voidNode(node1);
        boolean boolean4 = node1.getBooleanProp(0);
        boolean boolean5 = node1.isExprResult();
        boolean boolean6 = node1.isNew();
        java.util.logging.Logger logger7 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager8 = new com.google.javascript.jscomp.LoggerErrorManager(logger7);
        double double9 = loggerErrorManager8.getTypedPercent();
        com.google.javascript.jscomp.Compiler compiler10 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager8);
        com.google.javascript.jscomp.Result result11 = compiler10.getResult();
        java.util.logging.Logger logger12 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager13 = new com.google.javascript.jscomp.LoggerErrorManager(logger12);
        double double14 = loggerErrorManager13.getTypedPercent();
        compiler10.setErrorManager((com.google.javascript.jscomp.ErrorManager) loggerErrorManager13);
        com.google.javascript.jscomp.NodeTraversal.Callback callback16 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal17 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler10, callback16);
        com.google.javascript.rhino.Node[] nodeArray18 = new com.google.javascript.rhino.Node[] {};
        nodeTraversal17.traverseRoots(nodeArray18);
        try {
            com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.IR.newNode(node1, nodeArray18);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: new child has existing parent");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(result11);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNotNull(nodeArray18);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.DEPRECATED;
        org.junit.Assert.assertNull(diagnosticGroup0);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        java.util.logging.Logger logger0 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager1 = new com.google.javascript.jscomp.LoggerErrorManager(logger0);
        double double2 = loggerErrorManager1.getTypedPercent();
        com.google.javascript.jscomp.Compiler compiler3 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager1);
        com.google.javascript.jscomp.Result result4 = compiler3.getResult();
        java.util.logging.Logger logger5 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager6 = new com.google.javascript.jscomp.LoggerErrorManager(logger5);
        double double7 = loggerErrorManager6.getTypedPercent();
        compiler3.setErrorManager((com.google.javascript.jscomp.ErrorManager) loggerErrorManager6);
        com.google.javascript.jscomp.NodeTraversal.Callback callback9 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal10 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler3, callback9);
        java.util.List<com.google.javascript.rhino.Node> nodeList11 = null;
        try {
            nodeTraversal10.traverseRoots(nodeList11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(result4);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        java.util.logging.Logger logger0 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager1 = new com.google.javascript.jscomp.LoggerErrorManager(logger0);
        double double2 = loggerErrorManager1.getTypedPercent();
        com.google.javascript.jscomp.Compiler compiler3 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager1);
        com.google.javascript.jscomp.Result result4 = compiler3.getResult();
        java.util.logging.Logger logger5 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager6 = new com.google.javascript.jscomp.LoggerErrorManager(logger5);
        double double7 = loggerErrorManager6.getTypedPercent();
        compiler3.setErrorManager((com.google.javascript.jscomp.ErrorManager) loggerErrorManager6);
        com.google.javascript.jscomp.SourceFile.Generator generator10 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile11 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("goog.global", generator10);
        com.google.javascript.jscomp.SourceFile.Generator generator13 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile14 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("goog.global", generator13);
        com.google.javascript.jscomp.SourceFile.Generator generator16 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile17 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("goog.global", generator16);
        java.nio.charset.Charset charset19 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile20 = com.google.javascript.jscomp.JSSourceFile.fromFile("hi!. hi! at (unknown source) line (unknown line) : (unknown column)", charset19);
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray21 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile11, jSSourceFile14, jSSourceFile17, jSSourceFile20 };
        com.google.javascript.jscomp.SourceFile.Generator generator23 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile24 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("goog.global", generator23);
        com.google.javascript.jscomp.SourceFile.Generator generator26 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile27 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("goog.global", generator26);
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray28 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile24, jSSourceFile27 };
        com.google.javascript.jscomp.CompilerOptions compilerOptions29 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel30 = compilerOptions29.reportMissingOverride;
        compilerOptions29.setAppNameStr("module$STRING hi!");
        boolean boolean33 = compilerOptions29.crossModuleMethodMotion;
        boolean boolean34 = compilerOptions29.computeFunctionSideEffects;
        byte[] byteArray35 = compilerOptions29.inputVariableMapSerialized;
        compilerOptions29.checkMissingGetCssNameBlacklist = "hi!";
        compiler3.init(jSSourceFileArray21, jSSourceFileArray28, compilerOptions29);
        java.util.List<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList39 = null;
        com.google.javascript.jscomp.SourceFile.Generator generator41 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile42 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("goog.global", generator41);
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray43 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile42 };
        java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList44 = new java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile>();
        boolean boolean45 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList44, jSSourceFileArray43);
        com.google.javascript.jscomp.CompilerOptions compilerOptions46 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel47 = compilerOptions46.reportMissingOverride;
        compilerOptions46.setAppNameStr("module$STRING hi!");
        boolean boolean50 = compilerOptions46.foldConstants;
        boolean boolean51 = compilerOptions46.recordFunctionInformation;
        try {
            com.google.javascript.jscomp.Result result52 = compiler3.compile(jSSourceFileList39, (java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList44, compilerOptions46);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(result4);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(jSSourceFile11);
        org.junit.Assert.assertNotNull(jSSourceFile14);
        org.junit.Assert.assertNotNull(jSSourceFile17);
        org.junit.Assert.assertNotNull(jSSourceFile20);
        org.junit.Assert.assertNotNull(jSSourceFileArray21);
        org.junit.Assert.assertNotNull(jSSourceFile24);
        org.junit.Assert.assertNotNull(jSSourceFile27);
        org.junit.Assert.assertNotNull(jSSourceFileArray28);
        org.junit.Assert.assertTrue("'" + checkLevel30 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel30.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNull(byteArray35);
        org.junit.Assert.assertNotNull(jSSourceFile42);
        org.junit.Assert.assertNotNull(jSSourceFileArray43);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
        org.junit.Assert.assertTrue("'" + checkLevel47 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel47.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.reportMissingOverride;
        compilerOptions0.setAppNameStr("module$STRING hi!");
        boolean boolean4 = compilerOptions0.crossModuleMethodMotion;
        boolean boolean5 = compilerOptions0.computeFunctionSideEffects;
        byte[] byteArray6 = compilerOptions0.inputVariableMapSerialized;
        compilerOptions0.checkMissingGetCssNameBlacklist = "hi!";
        boolean boolean9 = compilerOptions0.jqueryPass;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap10 = null;
        compilerOptions0.cssRenamingMap = cssRenamingMap10;
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(byteArray6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = null;
        com.google.javascript.jscomp.DiagnosticGroups.TYPE_INVALIDATION = diagnosticGroup0;
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.reportMissingOverride;
        compilerOptions0.setAppNameStr("module$STRING hi!");
        boolean boolean4 = compilerOptions0.crossModuleMethodMotion;
        java.lang.String[] strArray15 = new java.lang.String[] { "// Input %num%", "InputId: ", "hi!", "STRING hi!", "./", "./", "STRING hi! [jsdoc_info: JSDocInfo]", "./", "hi!. hi! at (unknown source) line (unknown line) : (unknown column)" };
        java.util.ArrayList<java.lang.String> strList16 = new java.util.ArrayList<java.lang.String>();
        boolean boolean17 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strList16, strArray15);
        compilerOptions0.setReplaceStringsConfiguration("module$STRING hi!", (java.util.List<java.lang.String>) strList16);
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(strArray15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        java.util.logging.Logger logger0 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager1 = new com.google.javascript.jscomp.LoggerErrorManager(logger0);
        double double2 = loggerErrorManager1.getTypedPercent();
        com.google.javascript.jscomp.Compiler compiler3 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager1);
        com.google.javascript.jscomp.Result result4 = compiler3.getResult();
        int int5 = compiler3.getWarningCount();
        com.google.javascript.jscomp.PassConfig passConfig6 = null;
        try {
            compiler3.setPassConfig(passConfig6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(result4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        try {
            java.lang.String str1 = com.google.javascript.rhino.ScriptRuntime.getMessage0("hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property hi!");
        } catch (java.lang.RuntimeException e) {
        }
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        com.google.javascript.jscomp.CodingConvention codingConvention0 = com.google.javascript.jscomp.CodingConventions.getDefault();
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention1 = new com.google.javascript.jscomp.ClosureCodingConvention(codingConvention0);
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean5 = node4.isFor();
        boolean boolean6 = node4.isExprResult();
        java.lang.String str7 = node4.getString();
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean10 = node9.isFor();
        boolean boolean11 = node9.isExprResult();
        com.google.javascript.rhino.Node node12 = node4.clonePropsFrom(node9);
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean15 = node14.isFor();
        boolean boolean16 = node14.isExprResult();
        java.lang.String str17 = node14.getString();
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean20 = node19.isFor();
        boolean boolean21 = node19.isExprResult();
        com.google.javascript.rhino.Node node22 = node14.clonePropsFrom(node19);
        boolean boolean23 = node22.isVar();
        node22.setSourceEncodedPositionForTree(16);
        com.google.javascript.rhino.Node node26 = new com.google.javascript.rhino.Node(10, node9, node22);
        com.google.javascript.rhino.Node node27 = node26.cloneTree();
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable28 = node26.children();
        boolean boolean29 = closureCodingConvention1.isOptionalParameter(node26);
        try {
            node26.setDouble(0.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: BITXOR is not a string node");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(codingConvention0);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "hi!" + "'", str7.equals("hi!"));
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "hi!" + "'", str17.equals("hi!"));
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(node27);
        org.junit.Assert.assertNotNull(nodeIterable28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        com.google.javascript.rhino.Node.SideEffectFlags sideEffectFlags1 = new com.google.javascript.rhino.Node.SideEffectFlags((int) '4');
        sideEffectFlags1.setReturnsTainted();
        sideEffectFlags1.clearSideEffectFlags();
        sideEffectFlags1.clearAllFlags();
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        int int0 = com.google.javascript.rhino.Node.DIRECT_EVAL;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 49 + "'", int0 == 49);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        com.google.javascript.jscomp.JSModule[] jSModuleArray0 = new com.google.javascript.jscomp.JSModule[] {};
        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList1 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList1, jSModuleArray0);
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph3 = new com.google.javascript.jscomp.JSModuleGraph((java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList1);
        com.google.javascript.jscomp.JSModule jSModule4 = null;
        com.google.javascript.jscomp.JSModule jSModule5 = null;
        try {
            boolean boolean6 = jSModuleGraph3.dependsOn(jSModule4, jSModule5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jSModuleArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        java.util.logging.Logger logger0 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager1 = new com.google.javascript.jscomp.LoggerErrorManager(logger0);
        double double2 = loggerErrorManager1.getTypedPercent();
        com.google.javascript.jscomp.Compiler compiler3 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager1);
        com.google.javascript.jscomp.Result result4 = compiler3.getResult();
        int int5 = compiler3.getWarningCount();
        com.google.javascript.jscomp.SourceFile.Generator generator7 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile8 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("goog.global", generator7);
        jSSourceFile8.clearCachedSource();
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray10 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile8 };
        java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList11 = new java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile>();
        boolean boolean12 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList11, jSSourceFileArray10);
        java.util.List<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList13 = null;
        com.google.javascript.jscomp.CompilerOptions compilerOptions14 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel15 = compilerOptions14.reportMissingOverride;
        compilerOptions14.setAppNameStr("module$STRING hi!");
        boolean boolean18 = compilerOptions14.crossModuleMethodMotion;
        boolean boolean19 = compilerOptions14.computeFunctionSideEffects;
        compilerOptions14.locale = "module$STRING hi!";
        try {
            compiler3.init((java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList11, jSSourceFileList13, compilerOptions14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(result4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(jSSourceFile8);
        org.junit.Assert.assertNotNull(jSSourceFileArray10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + checkLevel15 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel15.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.reportMissingOverride;
        compilerOptions0.setAppNameStr("module$STRING hi!");
        boolean boolean4 = compilerOptions0.crossModuleMethodMotion;
        boolean boolean5 = compilerOptions0.computeFunctionSideEffects;
        compilerOptions0.setExportTestFunctions(true);
        compilerOptions0.preferLineBreakAtEndOfFile = false;
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean2 = node1.isFor();
        boolean boolean3 = node1.isExprResult();
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean6 = node5.isFor();
        com.google.javascript.rhino.Node node7 = node1.clonePropsFrom(node5);
        boolean boolean8 = node1.isOnlyModifiesThisCall();
        boolean boolean9 = node1.isAdd();
        com.google.javascript.rhino.InputId inputId10 = node1.getInputId();
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString("hi!");
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.IR.voidNode(node12);
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean16 = node15.isFor();
        boolean boolean17 = node15.isExprResult();
        java.lang.String str18 = node15.getString();
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean21 = node20.isFor();
        boolean boolean22 = node20.isExprResult();
        com.google.javascript.rhino.Node node23 = node15.clonePropsFrom(node20);
        boolean boolean24 = node12.isEquivalentToTyped(node15);
        com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.IR.getprop(node1, node15);
        try {
            java.lang.String str26 = node25.getString();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: GETPROP is not a string node");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(inputId10);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "hi!" + "'", str18.equals("hi!"));
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(node25);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        com.google.javascript.rhino.Node.SideEffectFlags sideEffectFlags1 = new com.google.javascript.rhino.Node.SideEffectFlags((int) '4');
        sideEffectFlags1.clearSideEffectFlags();
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        com.google.javascript.jscomp.SourceFile sourceFile1 = com.google.javascript.jscomp.SourceFile.fromFile("hi!");
        boolean boolean2 = sourceFile1.isExtern();
        com.google.javascript.jscomp.JsAst jsAst3 = new com.google.javascript.jscomp.JsAst(sourceFile1);
        com.google.javascript.jscomp.CompilerInput compilerInput6 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) jsAst3, "// Input %num%", false);
        com.google.javascript.jscomp.SourceAst sourceAst7 = compilerInput6.getSourceAst();
        java.lang.String str8 = compilerInput6.getName();
        try {
            java.lang.String str9 = compilerInput6.getCode();
            org.junit.Assert.fail("Expected exception of type java.io.FileNotFoundException; message: hi! (No such file or directory)");
        } catch (java.io.FileNotFoundException e) {
        }
        org.junit.Assert.assertNotNull(sourceFile1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(sourceAst7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "// Input %num%" + "'", str8.equals("// Input %num%"));
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean3 = node2.isFor();
        boolean boolean4 = node2.isExprResult();
        java.lang.String str5 = node2.getString();
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean8 = node7.isFor();
        boolean boolean9 = node7.isExprResult();
        com.google.javascript.rhino.Node node10 = node2.clonePropsFrom(node7);
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean13 = node12.isFor();
        boolean boolean14 = node12.isExprResult();
        java.lang.String str15 = node12.getString();
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean18 = node17.isFor();
        boolean boolean19 = node17.isExprResult();
        com.google.javascript.rhino.Node node20 = node12.clonePropsFrom(node17);
        boolean boolean21 = node20.isVar();
        node20.setSourceEncodedPositionForTree(16);
        com.google.javascript.rhino.Node node24 = new com.google.javascript.rhino.Node(10, node7, node20);
        java.lang.Object obj26 = node24.getProp(50);
        try {
            com.google.javascript.rhino.Node node27 = com.google.javascript.rhino.IR.var(node24);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "hi!" + "'", str15.equals("hi!"));
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNull(obj26);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.DUPLICATE_VARS;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        com.google.javascript.jscomp.DiagnosticGroup[] diagnosticGroupArray0 = new com.google.javascript.jscomp.DiagnosticGroup[] {};
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup1 = new com.google.javascript.jscomp.DiagnosticGroup(diagnosticGroupArray0);
        com.google.javascript.jscomp.DiagnosticGroups.CHECK_USELESS_CODE = diagnosticGroup1;
        org.junit.Assert.assertNotNull(diagnosticGroupArray0);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        com.google.javascript.jscomp.DiagnosticType diagnosticType2 = com.google.javascript.jscomp.DiagnosticType.warning("module$STRING hi!", "STRING hi! [jsdoc_info: JSDocInfo]");
        org.junit.Assert.assertNotNull(diagnosticType2);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.reportMissingOverride;
        compilerOptions0.setAppNameStr("module$STRING hi!");
        boolean boolean4 = compilerOptions0.crossModuleMethodMotion;
        boolean boolean5 = compilerOptions0.computeFunctionSideEffects;
        byte[] byteArray6 = compilerOptions0.inputVariableMapSerialized;
        compilerOptions0.setExternExports(false);
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(byteArray6);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.reportMissingOverride;
        compilerOptions0.setAppNameStr("module$STRING hi!");
        boolean boolean4 = compilerOptions0.crossModuleMethodMotion;
        boolean boolean5 = compilerOptions0.computeFunctionSideEffects;
        compilerOptions0.locale = "module$STRING hi!";
        java.lang.String str8 = compilerOptions0.inputDelimiter;
        boolean boolean9 = compilerOptions0.inlineGetters;
        boolean boolean10 = compilerOptions0.removeUnusedPrototypePropertiesInExterns;
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "// Input %num%" + "'", str8.equals("// Input %num%"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.reportMissingOverride;
        compilerOptions0.setAppNameStr("module$STRING hi!");
        boolean boolean4 = compilerOptions0.foldConstants;
        compilerOptions0.setCoalesceVariableNames(false);
        compilerOptions0.checkTypes = false;
        compilerOptions0.setExportTestFunctions(false);
        boolean boolean11 = compilerOptions0.reserveRawExports;
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean2 = node1.isFor();
        boolean boolean3 = node1.isExprResult();
        java.lang.String str4 = node1.getString();
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean7 = node6.isFor();
        boolean boolean8 = node6.isExprResult();
        com.google.javascript.rhino.Node node9 = node1.clonePropsFrom(node6);
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean12 = node11.isFor();
        boolean boolean13 = node11.isExprResult();
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean16 = node15.isFor();
        com.google.javascript.rhino.Node node17 = node11.clonePropsFrom(node15);
        node15.addSuppression("module$STRING hi!");
        com.google.javascript.rhino.Node node21 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean22 = node21.isFor();
        boolean boolean23 = node21.isExprResult();
        java.lang.String str24 = node21.getString();
        com.google.javascript.rhino.Node node26 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean27 = node26.isFor();
        boolean boolean28 = node26.isExprResult();
        com.google.javascript.rhino.Node node29 = node21.clonePropsFrom(node26);
        com.google.javascript.rhino.Node node31 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean32 = node31.isFor();
        boolean boolean33 = node31.isExprResult();
        java.lang.String str34 = node31.getString();
        com.google.javascript.rhino.Node node36 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean37 = node36.isFor();
        boolean boolean38 = node36.isExprResult();
        com.google.javascript.rhino.Node node39 = node31.clonePropsFrom(node36);
        int int40 = node26.getIndexOfChild(node31);
        com.google.javascript.rhino.Node node41 = node26.cloneTree();
        com.google.javascript.rhino.Node node42 = com.google.javascript.rhino.IR.comma(node15, node41);
        com.google.javascript.rhino.Node node43 = com.google.javascript.rhino.IR.sheq(node1, node42);
        boolean boolean44 = node1.isScript();
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "hi!" + "'", str4.equals("hi!"));
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "hi!" + "'", str24.equals("hi!"));
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "hi!" + "'", str34.equals("hi!"));
        org.junit.Assert.assertNotNull(node36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(node39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + (-1) + "'", int40 == (-1));
        org.junit.Assert.assertNotNull(node41);
        org.junit.Assert.assertNotNull(node42);
        org.junit.Assert.assertNotNull(node43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean2 = node1.isFor();
        boolean boolean3 = node1.isExprResult();
        java.lang.String str4 = node1.getString();
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean7 = node6.isFor();
        boolean boolean8 = node6.isExprResult();
        com.google.javascript.rhino.Node node9 = node1.clonePropsFrom(node6);
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean12 = node11.isFor();
        boolean boolean13 = node11.isExprResult();
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean16 = node15.isFor();
        com.google.javascript.rhino.Node node17 = node11.clonePropsFrom(node15);
        node15.addSuppression("module$STRING hi!");
        com.google.javascript.rhino.Node node21 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean22 = node21.isFor();
        boolean boolean23 = node21.isExprResult();
        java.lang.String str24 = node21.getString();
        com.google.javascript.rhino.Node node26 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean27 = node26.isFor();
        boolean boolean28 = node26.isExprResult();
        com.google.javascript.rhino.Node node29 = node21.clonePropsFrom(node26);
        com.google.javascript.rhino.Node node31 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean32 = node31.isFor();
        boolean boolean33 = node31.isExprResult();
        java.lang.String str34 = node31.getString();
        com.google.javascript.rhino.Node node36 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean37 = node36.isFor();
        boolean boolean38 = node36.isExprResult();
        com.google.javascript.rhino.Node node39 = node31.clonePropsFrom(node36);
        int int40 = node26.getIndexOfChild(node31);
        com.google.javascript.rhino.Node node41 = node26.cloneTree();
        com.google.javascript.rhino.Node node42 = com.google.javascript.rhino.IR.comma(node15, node41);
        com.google.javascript.rhino.Node node44 = com.google.javascript.rhino.Node.newString("hi!");
        com.google.javascript.rhino.Node node45 = com.google.javascript.rhino.IR.voidNode(node44);
        boolean boolean47 = node44.getBooleanProp(0);
        try {
            com.google.javascript.rhino.Node node48 = com.google.javascript.rhino.IR.forIn(node1, node15, node44);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "hi!" + "'", str4.equals("hi!"));
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "hi!" + "'", str24.equals("hi!"));
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "hi!" + "'", str34.equals("hi!"));
        org.junit.Assert.assertNotNull(node36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(node39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + (-1) + "'", int40 == (-1));
        org.junit.Assert.assertNotNull(node41);
        org.junit.Assert.assertNotNull(node42);
        org.junit.Assert.assertNotNull(node44);
        org.junit.Assert.assertNotNull(node45);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean2 = node1.isFor();
        boolean boolean3 = node1.isExprResult();
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean6 = node5.isFor();
        com.google.javascript.rhino.Node node7 = node1.clonePropsFrom(node5);
        boolean boolean8 = node1.isOnlyModifiesThisCall();
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean11 = node10.isFor();
        boolean boolean12 = node10.isExprResult();
        java.lang.String str13 = node10.getString();
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean16 = node15.isFor();
        boolean boolean17 = node15.isExprResult();
        com.google.javascript.rhino.Node node18 = node10.clonePropsFrom(node15);
        boolean boolean19 = node18.isVar();
        com.google.javascript.rhino.Node node20 = node1.useSourceInfoFromForTree(node18);
        com.google.javascript.rhino.jstype.JSType jSType21 = null;
        node20.setJSType(jSType21);
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.IR.paramList();
        boolean boolean24 = node23.isThrow();
        node20.addChildToBack(node23);
        com.google.javascript.rhino.Node node27 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean28 = node27.isFor();
        boolean boolean29 = node27.isExprResult();
        com.google.javascript.rhino.Node node31 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean32 = node31.isFor();
        com.google.javascript.rhino.Node node33 = node27.clonePropsFrom(node31);
        boolean boolean34 = node27.isOnlyModifiesThisCall();
        com.google.javascript.rhino.Node node36 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean37 = node36.isFor();
        boolean boolean38 = node36.isExprResult();
        java.lang.String str39 = node36.getString();
        com.google.javascript.rhino.Node node41 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean42 = node41.isFor();
        boolean boolean43 = node41.isExprResult();
        com.google.javascript.rhino.Node node44 = node36.clonePropsFrom(node41);
        boolean boolean45 = node44.isVar();
        com.google.javascript.rhino.Node node46 = node27.useSourceInfoFromForTree(node44);
        boolean boolean47 = node46.isLabelName();
        com.google.javascript.rhino.Node node48 = node20.useSourceInfoFromForTree(node46);
        com.google.javascript.rhino.Node node50 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean51 = node50.isFor();
        boolean boolean52 = node50.isExprResult();
        com.google.javascript.rhino.Node node54 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean55 = node54.isFor();
        com.google.javascript.rhino.Node node56 = node50.clonePropsFrom(node54);
        boolean boolean57 = node50.isOnlyModifiesThisCall();
        com.google.javascript.rhino.Node node59 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean60 = node59.isFor();
        boolean boolean61 = node59.isExprResult();
        java.lang.String str62 = node59.getString();
        com.google.javascript.rhino.Node node64 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean65 = node64.isFor();
        boolean boolean66 = node64.isExprResult();
        com.google.javascript.rhino.Node node67 = node59.clonePropsFrom(node64);
        boolean boolean68 = node67.isVar();
        com.google.javascript.rhino.Node node69 = node50.useSourceInfoFromForTree(node67);
        boolean boolean70 = node69.isLabelName();
        try {
            com.google.javascript.rhino.Node node71 = com.google.javascript.rhino.IR.propdef(node20, node69);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "hi!" + "'", str13.equals("hi!"));
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(node27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(node33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(node36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "hi!" + "'", str39.equals("hi!"));
        org.junit.Assert.assertNotNull(node41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(node44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(node46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(node48);
        org.junit.Assert.assertNotNull(node50);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertNotNull(node54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNotNull(node56);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertNotNull(node59);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertTrue("'" + str62 + "' != '" + "hi!" + "'", str62.equals("hi!"));
        org.junit.Assert.assertNotNull(node64);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertNotNull(node67);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertNotNull(node69);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        com.google.javascript.jscomp.SourceFile.Generator generator1 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("goog.global", generator1);
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2);
        org.junit.Assert.assertNotNull(jSSourceFile2);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.reportMissingOverride;
        compilerOptions0.setAppNameStr("module$STRING hi!");
        compilerOptions0.setDefineToBooleanLiteral("STRING hi!", false);
        com.google.javascript.jscomp.SourceMap.LocationMapping locationMapping9 = new com.google.javascript.jscomp.SourceMap.LocationMapping("STRING hi! [jsdoc_info: JSDocInfo]", "");
        com.google.javascript.jscomp.SourceMap.LocationMapping[] locationMappingArray10 = new com.google.javascript.jscomp.SourceMap.LocationMapping[] { locationMapping9 };
        java.util.ArrayList<com.google.javascript.jscomp.SourceMap.LocationMapping> locationMappingList11 = new java.util.ArrayList<com.google.javascript.jscomp.SourceMap.LocationMapping>();
        boolean boolean12 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.SourceMap.LocationMapping>) locationMappingList11, locationMappingArray10);
        compilerOptions0.sourceMapLocationMappings = locationMappingList11;
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(locationMappingArray10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.reportMissingOverride;
        compilerOptions0.setAppNameStr("module$STRING hi!");
        compilerOptions0.setOutputJsStringUsage(true);
        compilerOptions0.setRemoveDeadCode(true);
        boolean boolean8 = compilerOptions0.markNoSideEffectCalls;
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        com.google.javascript.rhino.Node node0 = null;
        java.lang.String str1 = com.google.javascript.jscomp.NodeUtil.getSourceName(node0);
        org.junit.Assert.assertNull(str1);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        com.google.javascript.jscomp.CodingConvention codingConvention0 = null;
        try {
            com.google.javascript.rhino.Node node2 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode(codingConvention0, "// Input %num%");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        boolean boolean1 = com.google.javascript.rhino.ScriptRuntime.isJSLineTerminator(38);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean2 = node1.isFor();
        boolean boolean3 = node1.isExprResult();
        java.lang.String str4 = node1.getString();
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean7 = node6.isFor();
        boolean boolean8 = node6.isExprResult();
        com.google.javascript.rhino.Node node9 = node1.clonePropsFrom(node6);
        boolean boolean10 = node9.isVar();
        com.google.javascript.rhino.Node node14 = new com.google.javascript.rhino.Node((int) (byte) 100, (int) (byte) 1, 54);
        boolean boolean15 = node14.isReturn();
        boolean boolean16 = node9.hasChild(node14);
        boolean boolean17 = node9.isThrow();
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "hi!" + "'", str4.equals("hi!"));
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean2 = node1.isFor();
        boolean boolean3 = node1.isExprResult();
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean6 = node5.isFor();
        com.google.javascript.rhino.Node node7 = node1.clonePropsFrom(node5);
        boolean boolean8 = node1.isOnlyModifiesThisCall();
        boolean boolean9 = node1.isAdd();
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean12 = node11.isFor();
        boolean boolean13 = node11.isExprResult();
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean16 = node15.isFor();
        com.google.javascript.rhino.Node node17 = node11.clonePropsFrom(node15);
        boolean boolean18 = node11.isOnlyModifiesThisCall();
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean21 = node20.isFor();
        boolean boolean22 = node20.isExprResult();
        java.lang.String str23 = node20.getString();
        com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean26 = node25.isFor();
        boolean boolean27 = node25.isExprResult();
        com.google.javascript.rhino.Node node28 = node20.clonePropsFrom(node25);
        boolean boolean29 = node28.isVar();
        com.google.javascript.rhino.Node node30 = node11.useSourceInfoFromForTree(node28);
        com.google.javascript.rhino.jstype.JSType jSType31 = null;
        node30.setJSType(jSType31);
        com.google.javascript.rhino.Node node33 = com.google.javascript.rhino.IR.paramList();
        boolean boolean34 = node33.isThrow();
        node30.addChildToBack(node33);
        com.google.javascript.rhino.Node node36 = com.google.javascript.rhino.IR.add(node1, node30);
        try {
            com.google.javascript.rhino.Node node38 = node1.getChildAtIndex(4095);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "hi!" + "'", str23.equals("hi!"));
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(node30);
        org.junit.Assert.assertNotNull(node33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(node36);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        java.io.InputStream inputStream1 = null;
        try {
            com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromInputStream("STRING hi! [jsdoc_info: JSDocInfo]", inputStream1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.CHECK_VARIABLES;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.reportMissingOverride;
        compilerOptions0.setAppNameStr("module$STRING hi!");
        boolean boolean4 = compilerOptions0.crossModuleMethodMotion;
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean7 = node6.isFor();
        boolean boolean8 = node6.isExprResult();
        java.lang.String str9 = node6.getString();
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean12 = node11.isFor();
        boolean boolean13 = node11.isExprResult();
        com.google.javascript.rhino.Node node14 = node6.clonePropsFrom(node11);
        com.google.javascript.jscomp.CompilerOptions compilerOptions15 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel16 = compilerOptions15.reportMissingOverride;
        java.lang.String[] strArray23 = new java.lang.String[] { "STRING hi!", "hi!. hi! at (unknown source) line (unknown line) : (unknown column)", "module$STRING hi!", "hi!", "", "STRING hi!" };
        java.util.LinkedHashSet<java.lang.String> strSet24 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean25 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet24, strArray23);
        compilerOptions15.setIdGenerators((java.util.Set<java.lang.String>) strSet24);
        node6.setDirectives((java.util.Set<java.lang.String>) strSet24);
        compilerOptions0.aliasableStrings = strSet24;
        compilerOptions0.recordFunctionInformation = false;
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "hi!" + "'", str9.equals("hi!"));
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertTrue("'" + checkLevel16 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel16.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(strArray23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        com.google.javascript.jscomp.JSModule[] jSModuleArray0 = new com.google.javascript.jscomp.JSModule[] {};
        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList1 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList1, jSModuleArray0);
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph3 = new com.google.javascript.jscomp.JSModuleGraph((java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList1);
        com.google.javascript.jscomp.JSModule[] jSModuleArray4 = new com.google.javascript.jscomp.JSModule[] {};
        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList5 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
        boolean boolean6 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList5, jSModuleArray4);
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph7 = new com.google.javascript.jscomp.JSModuleGraph((java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList5);
        try {
            com.google.javascript.jscomp.JSModule jSModule8 = jSModuleGraph3.getDeepestCommonDependencyInclusive((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList5);
            org.junit.Assert.fail("Expected exception of type java.util.NoSuchElementException; message: null");
        } catch (java.util.NoSuchElementException e) {
        }
        org.junit.Assert.assertNotNull(jSModuleArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(jSModuleArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean3 = node2.isFor();
        boolean boolean4 = node2.isExprResult();
        java.lang.String str5 = node2.getString();
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean8 = node7.isFor();
        boolean boolean9 = node7.isExprResult();
        com.google.javascript.rhino.Node node10 = node2.clonePropsFrom(node7);
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean13 = node12.isFor();
        boolean boolean14 = node12.isExprResult();
        java.lang.String str15 = node12.getString();
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean18 = node17.isFor();
        boolean boolean19 = node17.isExprResult();
        com.google.javascript.rhino.Node node20 = node12.clonePropsFrom(node17);
        boolean boolean21 = node20.isVar();
        node20.setSourceEncodedPositionForTree(16);
        com.google.javascript.rhino.Node node24 = new com.google.javascript.rhino.Node(10, node7, node20);
        com.google.javascript.rhino.Node node25 = node24.cloneTree();
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable26 = node24.children();
        try {
            com.google.javascript.rhino.Node node27 = com.google.javascript.rhino.IR.paramList(node24);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "hi!" + "'", str15.equals("hi!"));
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNotNull(nodeIterable26);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newString("hi!");
        com.google.javascript.rhino.Node node2 = node1.removeChildren();
        try {
            boolean boolean3 = node2.hasOneChild();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertNull(node2);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.reportMissingOverride;
        compilerOptions0.setAppNameStr("module$STRING hi!");
        compilerOptions0.setDefineToBooleanLiteral("STRING hi!", false);
        com.google.javascript.jscomp.AnonymousFunctionNamingPolicy anonymousFunctionNamingPolicy7 = com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF;
        compilerOptions0.anonymousFunctionNaming = anonymousFunctionNamingPolicy7;
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + anonymousFunctionNamingPolicy7 + "' != '" + com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF + "'", anonymousFunctionNamingPolicy7.equals(com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF));
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        int int0 = com.google.javascript.rhino.Node.MAX_COLUMN_NUMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4095 + "'", int0 == 4095);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        com.google.javascript.jscomp.SourceFile.Generator generator1 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("goog.global", generator1);
        jSSourceFile2.clearCachedSource();
        try {
            com.google.javascript.jscomp.Region region5 = jSSourceFile2.getRegion((int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile2);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        java.util.logging.Logger logger0 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager1 = new com.google.javascript.jscomp.LoggerErrorManager(logger0);
        double double2 = loggerErrorManager1.getTypedPercent();
        com.google.javascript.jscomp.Compiler compiler3 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager1);
        com.google.javascript.jscomp.Result result4 = compiler3.getResult();
        java.util.logging.Logger logger5 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager6 = new com.google.javascript.jscomp.LoggerErrorManager(logger5);
        double double7 = loggerErrorManager6.getTypedPercent();
        compiler3.setErrorManager((com.google.javascript.jscomp.ErrorManager) loggerErrorManager6);
        compiler3.disableThreads();
        com.google.javascript.jscomp.PerformanceTracker performanceTracker10 = compiler3.tracker;
        java.util.logging.Logger logger11 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager12 = new com.google.javascript.jscomp.LoggerErrorManager(logger11);
        double double13 = loggerErrorManager12.getTypedPercent();
        com.google.javascript.jscomp.Compiler compiler14 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager12);
        com.google.javascript.jscomp.Result result15 = compiler14.getResult();
        java.util.logging.Logger logger16 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager17 = new com.google.javascript.jscomp.LoggerErrorManager(logger16);
        double double18 = loggerErrorManager17.getTypedPercent();
        compiler14.setErrorManager((com.google.javascript.jscomp.ErrorManager) loggerErrorManager17);
        com.google.javascript.jscomp.SourceFile.Generator generator21 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile22 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("goog.global", generator21);
        com.google.javascript.jscomp.SourceFile.Generator generator24 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile25 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("goog.global", generator24);
        com.google.javascript.jscomp.SourceFile.Generator generator27 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile28 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("goog.global", generator27);
        java.nio.charset.Charset charset30 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile31 = com.google.javascript.jscomp.JSSourceFile.fromFile("hi!. hi! at (unknown source) line (unknown line) : (unknown column)", charset30);
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray32 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile22, jSSourceFile25, jSSourceFile28, jSSourceFile31 };
        com.google.javascript.jscomp.SourceFile.Generator generator34 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile35 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("goog.global", generator34);
        com.google.javascript.jscomp.SourceFile.Generator generator37 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile38 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("goog.global", generator37);
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray39 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile35, jSSourceFile38 };
        com.google.javascript.jscomp.CompilerOptions compilerOptions40 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel41 = compilerOptions40.reportMissingOverride;
        compilerOptions40.setAppNameStr("module$STRING hi!");
        boolean boolean44 = compilerOptions40.crossModuleMethodMotion;
        boolean boolean45 = compilerOptions40.computeFunctionSideEffects;
        byte[] byteArray46 = compilerOptions40.inputVariableMapSerialized;
        compilerOptions40.checkMissingGetCssNameBlacklist = "hi!";
        compiler14.init(jSSourceFileArray32, jSSourceFileArray39, compilerOptions40);
        com.google.javascript.jscomp.JSModule jSModule50 = null;
        com.google.javascript.jscomp.JSModule[] jSModuleArray51 = new com.google.javascript.jscomp.JSModule[] { jSModule50 };
        com.google.javascript.jscomp.CompilerOptions compilerOptions52 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel53 = compilerOptions52.reportMissingOverride;
        compilerOptions52.setAppNameStr("module$STRING hi!");
        compilerOptions52.setOutputJsStringUsage(true);
        compilerOptions52.resetWarningsGuard();
        compilerOptions52.setGenerateExports(false);
        try {
            compiler3.init(jSSourceFileArray39, jSModuleArray51, compilerOptions52);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(result4);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNull(performanceTracker10);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertNotNull(result15);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(jSSourceFile22);
        org.junit.Assert.assertNotNull(jSSourceFile25);
        org.junit.Assert.assertNotNull(jSSourceFile28);
        org.junit.Assert.assertNotNull(jSSourceFile31);
        org.junit.Assert.assertNotNull(jSSourceFileArray32);
        org.junit.Assert.assertNotNull(jSSourceFile35);
        org.junit.Assert.assertNotNull(jSSourceFile38);
        org.junit.Assert.assertNotNull(jSSourceFileArray39);
        org.junit.Assert.assertTrue("'" + checkLevel41 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel41.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNull(byteArray46);
        org.junit.Assert.assertNotNull(jSModuleArray51);
        org.junit.Assert.assertTrue("'" + checkLevel53 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel53.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean3 = node2.isFor();
        boolean boolean4 = node2.isExprResult();
        java.lang.String str5 = node2.getString();
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean8 = node7.isFor();
        boolean boolean9 = node7.isExprResult();
        com.google.javascript.rhino.Node node10 = node2.clonePropsFrom(node7);
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean13 = node12.isFor();
        boolean boolean14 = node12.isExprResult();
        java.lang.String str15 = node12.getString();
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean18 = node17.isFor();
        boolean boolean19 = node17.isExprResult();
        com.google.javascript.rhino.Node node20 = node12.clonePropsFrom(node17);
        boolean boolean21 = node20.isVar();
        node20.setSourceEncodedPositionForTree(16);
        com.google.javascript.rhino.Node node24 = new com.google.javascript.rhino.Node(10, node7, node20);
        com.google.javascript.jscomp.SourceFile sourceFile26 = com.google.javascript.jscomp.SourceFile.fromFile("hi!");
        node24.setStaticSourceFile((com.google.javascript.rhino.jstype.StaticSourceFile) sourceFile26);
        com.google.javascript.rhino.Node node28 = com.google.javascript.rhino.IR.paramList();
        com.google.javascript.rhino.Node node29 = node24.srcref(node28);
        com.google.javascript.rhino.Node node30 = node29.cloneNode();
        com.google.javascript.rhino.Node node32 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean33 = node32.isFor();
        boolean boolean34 = node32.isExprResult();
        com.google.javascript.rhino.Node node36 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean37 = node36.isFor();
        com.google.javascript.rhino.Node node38 = node32.clonePropsFrom(node36);
        node36.addSuppression("module$STRING hi!");
        java.lang.String str44 = node36.toString(true, true, false);
        com.google.javascript.rhino.Node node45 = com.google.javascript.rhino.IR.or(node30, node36);
        java.lang.String str46 = node36.getSourceFileName();
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "hi!" + "'", str15.equals("hi!"));
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(sourceFile26);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNotNull(node30);
        org.junit.Assert.assertNotNull(node32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(node36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(node38);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "STRING hi! [jsdoc_info: JSDocInfo]" + "'", str44.equals("STRING hi! [jsdoc_info: JSDocInfo]"));
        org.junit.Assert.assertNotNull(node45);
        org.junit.Assert.assertNull(str46);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        com.google.javascript.jscomp.SourceFile.Generator generator1 = null;
        com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromGenerator("STRING hi!", generator1);
        org.junit.Assert.assertNotNull(sourceFile2);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.DUPLICATE_MESSAGE;
        com.google.javascript.jscomp.DiagnosticGroups.ES5_STRICT = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticGroups.UNDEFINED_VARIABLES = diagnosticGroup0;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.CONSTANT_PROPERTY;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.reportMissingOverride;
        compilerOptions0.setAppNameStr("module$STRING hi!");
        com.google.javascript.jscomp.CompilerOptions.Reach reach4 = com.google.javascript.jscomp.CompilerOptions.Reach.ALL;
        compilerOptions0.setRemoveUnusedVariables(reach4);
        compilerOptions0.setExtractPrototypeMemberDeclarations(true);
        boolean boolean8 = compilerOptions0.crossModuleCodeMotion;
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + reach4 + "' != '" + com.google.javascript.jscomp.CompilerOptions.Reach.ALL + "'", reach4.equals(com.google.javascript.jscomp.CompilerOptions.Reach.ALL));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.ACCESS_CONTROLS;
        com.google.javascript.jscomp.DiagnosticGroups.STRICT_MODULE_DEP_CHECK = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticGroups.VISIBILITY = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticGroups.NON_STANDARD_JSDOC = diagnosticGroup0;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        java.lang.String str1 = closureCodingConvention0.getExportSymbolFunction();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "goog.exportSymbol" + "'", str1.equals("goog.exportSymbol"));
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        java.util.logging.Logger logger0 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager1 = new com.google.javascript.jscomp.LoggerErrorManager(logger0);
        double double2 = loggerErrorManager1.getTypedPercent();
        com.google.javascript.jscomp.Compiler compiler3 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager1);
        com.google.javascript.jscomp.Result result4 = compiler3.getResult();
        java.util.logging.Logger logger5 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager6 = new com.google.javascript.jscomp.LoggerErrorManager(logger5);
        double double7 = loggerErrorManager6.getTypedPercent();
        compiler3.setErrorManager((com.google.javascript.jscomp.ErrorManager) loggerErrorManager6);
        com.google.javascript.jscomp.SourceExcerptProvider.SourceExcerpt sourceExcerpt9 = null;
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter10 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler3, sourceExcerpt9);
        com.google.javascript.jscomp.SourceFile.Generator generator12 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile13 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("goog.global", generator12);
        jSSourceFile13.clearCachedSource();
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray15 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile13 };
        java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList16 = new java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile>();
        boolean boolean17 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList16, jSSourceFileArray15);
        com.google.javascript.jscomp.SourceFile.Generator generator19 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile20 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("goog.global", generator19);
        com.google.javascript.jscomp.CompilerInput compilerInput21 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile20);
        com.google.javascript.jscomp.SourceFile.Generator generator23 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile24 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("goog.global", generator23);
        com.google.javascript.jscomp.CompilerInput compilerInput25 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile24);
        java.nio.charset.Charset charset27 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile28 = com.google.javascript.jscomp.JSSourceFile.fromFile("hi!. hi! at (unknown source) line (unknown line) : (unknown column)", charset27);
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray29 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile20, jSSourceFile24, jSSourceFile28 };
        java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList30 = new java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile>();
        boolean boolean31 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList30, jSSourceFileArray29);
        com.google.javascript.jscomp.CompilerOptions compilerOptions32 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel33 = compilerOptions32.reportMissingOverride;
        compilerOptions32.setAppNameStr("module$STRING hi!");
        boolean boolean36 = compilerOptions32.crossModuleMethodMotion;
        boolean boolean37 = compilerOptions32.computeFunctionSideEffects;
        compilerOptions32.setRuntimeTypeCheckLogFunction("InputId: ");
        java.lang.String str40 = compilerOptions32.aliasStringsBlacklist;
        try {
            com.google.javascript.jscomp.Result result41 = compiler3.compile((java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList16, (java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList30, compilerOptions32);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(result4);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(jSSourceFile13);
        org.junit.Assert.assertNotNull(jSSourceFileArray15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(jSSourceFile20);
        org.junit.Assert.assertNotNull(jSSourceFile24);
        org.junit.Assert.assertNotNull(jSSourceFile28);
        org.junit.Assert.assertNotNull(jSSourceFileArray29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertTrue("'" + checkLevel33 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel33.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "" + "'", str40.equals(""));
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        java.util.logging.Logger logger0 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager1 = new com.google.javascript.jscomp.LoggerErrorManager(logger0);
        double double2 = loggerErrorManager1.getTypedPercent();
        com.google.javascript.jscomp.Compiler compiler3 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager1);
        com.google.javascript.jscomp.Result result4 = compiler3.getResult();
        java.util.logging.Logger logger5 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager6 = new com.google.javascript.jscomp.LoggerErrorManager(logger5);
        double double7 = loggerErrorManager6.getTypedPercent();
        compiler3.setErrorManager((com.google.javascript.jscomp.ErrorManager) loggerErrorManager6);
        com.google.javascript.jscomp.NodeTraversal.Callback callback9 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal10 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler3, callback9);
        com.google.javascript.rhino.Node node11 = nodeTraversal10.getEnclosingFunction();
        java.util.logging.Logger logger12 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager13 = new com.google.javascript.jscomp.LoggerErrorManager(logger12);
        double double14 = loggerErrorManager13.getTypedPercent();
        com.google.javascript.jscomp.Compiler compiler15 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager13);
        com.google.javascript.jscomp.Result result16 = compiler15.getResult();
        java.util.logging.Logger logger17 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager18 = new com.google.javascript.jscomp.LoggerErrorManager(logger17);
        double double19 = loggerErrorManager18.getTypedPercent();
        compiler15.setErrorManager((com.google.javascript.jscomp.ErrorManager) loggerErrorManager18);
        com.google.javascript.jscomp.NodeTraversal.Callback callback21 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal22 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler15, callback21);
        com.google.javascript.rhino.Node[] nodeArray23 = new com.google.javascript.rhino.Node[] {};
        nodeTraversal22.traverseRoots(nodeArray23);
        nodeTraversal10.traverseRoots(nodeArray23);
        try {
            com.google.javascript.jscomp.JSModule jSModule26 = nodeTraversal10.getModule();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(result4);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNull(node11);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNotNull(result16);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertNotNull(nodeArray23);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.reportMissingOverride;
        compilerOptions0.setAppNameStr("module$STRING hi!");
        boolean boolean4 = compilerOptions0.crossModuleMethodMotion;
        boolean boolean5 = compilerOptions0.computeFunctionSideEffects;
        compilerOptions0.reserveRawExports = false;
        compilerOptions0.setLocale("");
        java.lang.String str10 = compilerOptions0.sourceMapOutputPath;
        compilerOptions0.setDebugFunctionSideEffectsPath("InputId: ");
        com.google.javascript.jscomp.CodingConvention codingConvention13 = com.google.javascript.jscomp.CodingConventions.getDefault();
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention14 = new com.google.javascript.jscomp.ClosureCodingConvention(codingConvention13);
        boolean boolean16 = closureCodingConvention14.isExported("");
        java.lang.String str17 = closureCodingConvention14.getGlobalObject();
        compilerOptions0.setCodingConvention((com.google.javascript.jscomp.CodingConvention) closureCodingConvention14);
        compilerOptions0.devirtualizePrototypeMethods = false;
        com.google.javascript.jscomp.CompilerOptions compilerOptions21 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel22 = compilerOptions21.reportMissingOverride;
        compilerOptions21.setAppNameStr("module$STRING hi!");
        boolean boolean25 = compilerOptions21.crossModuleMethodMotion;
        com.google.javascript.rhino.Node node27 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean28 = node27.isFor();
        boolean boolean29 = node27.isExprResult();
        java.lang.String str30 = node27.getString();
        com.google.javascript.rhino.Node node32 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean33 = node32.isFor();
        boolean boolean34 = node32.isExprResult();
        com.google.javascript.rhino.Node node35 = node27.clonePropsFrom(node32);
        com.google.javascript.jscomp.CompilerOptions compilerOptions36 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel37 = compilerOptions36.reportMissingOverride;
        java.lang.String[] strArray44 = new java.lang.String[] { "STRING hi!", "hi!. hi! at (unknown source) line (unknown line) : (unknown column)", "module$STRING hi!", "hi!", "", "STRING hi!" };
        java.util.LinkedHashSet<java.lang.String> strSet45 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean46 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet45, strArray44);
        compilerOptions36.setIdGenerators((java.util.Set<java.lang.String>) strSet45);
        node27.setDirectives((java.util.Set<java.lang.String>) strSet45);
        compilerOptions21.aliasableStrings = strSet45;
        compilerOptions0.setReplaceStringsReservedStrings((java.util.Set<java.lang.String>) strSet45);
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertNotNull(codingConvention13);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "goog.global" + "'", str17.equals("goog.global"));
        org.junit.Assert.assertTrue("'" + checkLevel22 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel22.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(node27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "hi!" + "'", str30.equals("hi!"));
        org.junit.Assert.assertNotNull(node32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertTrue("'" + checkLevel37 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel37.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(strArray44);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.reportMissingOverride;
        compilerOptions0.setAppNameStr("module$STRING hi!");
        boolean boolean4 = compilerOptions0.crossModuleMethodMotion;
        boolean boolean5 = compilerOptions0.computeFunctionSideEffects;
        com.google.javascript.jscomp.CompilerOptions compilerOptions6 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel7 = compilerOptions6.reportMissingOverride;
        com.google.javascript.jscomp.CompilerOptions.LanguageMode languageMode8 = com.google.javascript.jscomp.CompilerOptions.LanguageMode.ECMASCRIPT5;
        compilerOptions6.setLanguageIn(languageMode8);
        compilerOptions0.setLanguageIn(languageMode8);
        compilerOptions0.deadAssignmentElimination = false;
        java.lang.String str13 = compilerOptions0.inputDelimiter;
        boolean boolean14 = compilerOptions0.convertToDottedProperties;
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + checkLevel7 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel7.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + languageMode8 + "' != '" + com.google.javascript.jscomp.CompilerOptions.LanguageMode.ECMASCRIPT5 + "'", languageMode8.equals(com.google.javascript.jscomp.CompilerOptions.LanguageMode.ECMASCRIPT5));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "// Input %num%" + "'", str13.equals("// Input %num%"));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.reportMissingOverride;
        compilerOptions0.setAppNameStr("module$STRING hi!");
        boolean boolean4 = compilerOptions0.crossModuleMethodMotion;
        boolean boolean5 = compilerOptions0.computeFunctionSideEffects;
        com.google.javascript.jscomp.CompilerOptions compilerOptions6 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel7 = compilerOptions6.reportMissingOverride;
        com.google.javascript.jscomp.CompilerOptions.LanguageMode languageMode8 = com.google.javascript.jscomp.CompilerOptions.LanguageMode.ECMASCRIPT5;
        compilerOptions6.setLanguageIn(languageMode8);
        compilerOptions0.setLanguageIn(languageMode8);
        compilerOptions0.deadAssignmentElimination = false;
        compilerOptions0.markAsCompiled = false;
        com.google.javascript.jscomp.SourceMap.Format format15 = null;
        compilerOptions0.setSourceMapFormat(format15);
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + checkLevel7 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel7.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + languageMode8 + "' != '" + com.google.javascript.jscomp.CompilerOptions.LanguageMode.ECMASCRIPT5 + "'", languageMode8.equals(com.google.javascript.jscomp.CompilerOptions.LanguageMode.ECMASCRIPT5));
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        java.util.logging.Logger logger0 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager1 = new com.google.javascript.jscomp.LoggerErrorManager(logger0);
        double double2 = loggerErrorManager1.getTypedPercent();
        com.google.javascript.jscomp.Compiler compiler3 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager1);
        com.google.javascript.jscomp.Result result4 = compiler3.getResult();
        java.util.logging.Logger logger5 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager6 = new com.google.javascript.jscomp.LoggerErrorManager(logger5);
        double double7 = loggerErrorManager6.getTypedPercent();
        compiler3.setErrorManager((com.google.javascript.jscomp.ErrorManager) loggerErrorManager6);
        com.google.javascript.jscomp.NodeTraversal.Callback callback9 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal10 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler3, callback9);
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean14 = node13.isFor();
        boolean boolean15 = node13.isExprResult();
        java.lang.String str16 = node13.getString();
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean19 = node18.isFor();
        boolean boolean20 = node18.isExprResult();
        com.google.javascript.rhino.Node node21 = node13.clonePropsFrom(node18);
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean24 = node23.isFor();
        boolean boolean25 = node23.isExprResult();
        java.lang.String str26 = node23.getString();
        com.google.javascript.rhino.Node node28 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean29 = node28.isFor();
        boolean boolean30 = node28.isExprResult();
        com.google.javascript.rhino.Node node31 = node23.clonePropsFrom(node28);
        boolean boolean32 = node31.isVar();
        node31.setSourceEncodedPositionForTree(16);
        com.google.javascript.rhino.Node node35 = new com.google.javascript.rhino.Node(10, node18, node31);
        com.google.javascript.jscomp.SourceFile sourceFile37 = com.google.javascript.jscomp.SourceFile.fromFile("hi!");
        node35.setStaticSourceFile((com.google.javascript.rhino.jstype.StaticSourceFile) sourceFile37);
        com.google.javascript.rhino.Node node39 = com.google.javascript.rhino.IR.paramList();
        com.google.javascript.rhino.Node node40 = node35.srcref(node39);
        com.google.javascript.rhino.Node node44 = new com.google.javascript.rhino.Node((int) (byte) 100, (int) (byte) 1, 54);
        boolean boolean45 = node44.isReturn();
        boolean boolean46 = node40.isEquivalentToTyped(node44);
        com.google.javascript.jscomp.CompilerOptions compilerOptions47 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel48 = compilerOptions47.reportMissingOverride;
        compilerOptions47.setAppNameStr("module$STRING hi!");
        boolean boolean51 = compilerOptions47.crossModuleMethodMotion;
        boolean boolean52 = compilerOptions47.computeFunctionSideEffects;
        compilerOptions47.locale = "module$STRING hi!";
        compilerOptions47.setComputeFunctionSideEffects(true);
        compilerOptions47.setAliasableGlobals("hi!");
        com.google.javascript.jscomp.CompilerOptions compilerOptions59 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel60 = compilerOptions59.reportMissingOverride;
        compilerOptions47.checkUnreachableCode = checkLevel60;
        com.google.javascript.jscomp.CompilerOptions compilerOptions62 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel63 = compilerOptions62.reportMissingOverride;
        compilerOptions62.setAppNameStr("module$STRING hi!");
        boolean boolean66 = compilerOptions62.crossModuleMethodMotion;
        boolean boolean67 = compilerOptions62.computeFunctionSideEffects;
        compilerOptions62.locale = "module$STRING hi!";
        compilerOptions62.setComputeFunctionSideEffects(true);
        compilerOptions62.setAliasableGlobals("hi!");
        com.google.javascript.jscomp.CompilerOptions compilerOptions74 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel75 = compilerOptions74.reportMissingOverride;
        compilerOptions62.checkUnreachableCode = checkLevel75;
        compilerOptions47.checkMissingGetCssNameLevel = checkLevel75;
        com.google.javascript.jscomp.DiagnosticType diagnosticType78 = com.google.javascript.jscomp.Compiler.MOTION_ITERATIONS_ERROR;
        java.lang.String[] strArray80 = new java.lang.String[] { "hi!. hi! at (unknown source) line (unknown line) : (unknown column)" };
        com.google.javascript.jscomp.JSError jSError81 = nodeTraversal10.makeError(node44, checkLevel75, diagnosticType78, strArray80);
        com.google.javascript.rhino.Node node82 = com.google.javascript.rhino.IR.returnNode();
        boolean boolean83 = node82.isSwitch();
        try {
            com.google.javascript.rhino.Node node84 = com.google.javascript.rhino.IR.eq(node44, node82);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(result4);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "hi!" + "'", str16.equals("hi!"));
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "hi!" + "'", str26.equals("hi!"));
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(sourceFile37);
        org.junit.Assert.assertNotNull(node39);
        org.junit.Assert.assertNotNull(node40);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + checkLevel48 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel48.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertTrue("'" + checkLevel60 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel60.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + checkLevel63 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel63.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
        org.junit.Assert.assertTrue("'" + checkLevel75 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel75.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(diagnosticType78);
        org.junit.Assert.assertNotNull(strArray80);
        org.junit.Assert.assertNotNull(jSError81);
        org.junit.Assert.assertNotNull(node82);
        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + false + "'", boolean83 == false);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newString("hi!");
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.IR.voidNode(node1);
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean5 = node4.isFor();
        boolean boolean6 = node4.isExprResult();
        java.lang.String str7 = node4.getString();
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean10 = node9.isFor();
        boolean boolean11 = node9.isExprResult();
        com.google.javascript.rhino.Node node12 = node4.clonePropsFrom(node9);
        boolean boolean13 = node1.isEquivalentToTyped(node4);
        try {
            com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.IR.pos(node1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: new child has existing parent");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "hi!" + "'", str7.equals("hi!"));
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean3 = node2.isFor();
        boolean boolean4 = node2.isExprResult();
        java.lang.String str5 = node2.getString();
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean8 = node7.isFor();
        boolean boolean9 = node7.isExprResult();
        com.google.javascript.rhino.Node node10 = node2.clonePropsFrom(node7);
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean13 = node12.isFor();
        boolean boolean14 = node12.isExprResult();
        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean17 = node16.isFor();
        com.google.javascript.rhino.Node node18 = node12.clonePropsFrom(node16);
        node16.addSuppression("module$STRING hi!");
        com.google.javascript.rhino.Node node22 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean23 = node22.isFor();
        boolean boolean24 = node22.isExprResult();
        java.lang.String str25 = node22.getString();
        com.google.javascript.rhino.Node node27 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean28 = node27.isFor();
        boolean boolean29 = node27.isExprResult();
        com.google.javascript.rhino.Node node30 = node22.clonePropsFrom(node27);
        com.google.javascript.rhino.Node node32 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean33 = node32.isFor();
        boolean boolean34 = node32.isExprResult();
        java.lang.String str35 = node32.getString();
        com.google.javascript.rhino.Node node37 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean38 = node37.isFor();
        boolean boolean39 = node37.isExprResult();
        com.google.javascript.rhino.Node node40 = node32.clonePropsFrom(node37);
        int int41 = node27.getIndexOfChild(node32);
        com.google.javascript.rhino.Node node42 = node27.cloneTree();
        com.google.javascript.rhino.Node node43 = com.google.javascript.rhino.IR.comma(node16, node42);
        com.google.javascript.rhino.Node node44 = com.google.javascript.rhino.IR.sheq(node2, node43);
        com.google.javascript.rhino.Node node47 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean48 = node47.isFor();
        boolean boolean49 = node47.isExprResult();
        java.lang.String str50 = node47.getString();
        com.google.javascript.rhino.Node node52 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean53 = node52.isFor();
        boolean boolean54 = node52.isExprResult();
        com.google.javascript.rhino.Node node55 = node47.clonePropsFrom(node52);
        com.google.javascript.rhino.Node node57 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean58 = node57.isFor();
        boolean boolean59 = node57.isExprResult();
        java.lang.String str60 = node57.getString();
        com.google.javascript.rhino.Node node62 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean63 = node62.isFor();
        boolean boolean64 = node62.isExprResult();
        com.google.javascript.rhino.Node node65 = node57.clonePropsFrom(node62);
        boolean boolean66 = node65.isVar();
        node65.setSourceEncodedPositionForTree(16);
        com.google.javascript.rhino.Node node69 = new com.google.javascript.rhino.Node(10, node52, node65);
        java.lang.Object obj71 = node69.getProp(50);
        try {
            com.google.javascript.rhino.Node node72 = new com.google.javascript.rhino.Node((int) (short) 1, node2, node69);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: first new child has existing parent");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "hi!" + "'", str25.equals("hi!"));
        org.junit.Assert.assertNotNull(node27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(node30);
        org.junit.Assert.assertNotNull(node32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "hi!" + "'", str35.equals("hi!"));
        org.junit.Assert.assertNotNull(node37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(node40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + (-1) + "'", int41 == (-1));
        org.junit.Assert.assertNotNull(node42);
        org.junit.Assert.assertNotNull(node43);
        org.junit.Assert.assertNotNull(node44);
        org.junit.Assert.assertNotNull(node47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "hi!" + "'", str50.equals("hi!"));
        org.junit.Assert.assertNotNull(node52);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNotNull(node55);
        org.junit.Assert.assertNotNull(node57);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertTrue("'" + str60 + "' != '" + "hi!" + "'", str60.equals("hi!"));
        org.junit.Assert.assertNotNull(node62);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertNotNull(node65);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertNull(obj71);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.reportMissingOverride;
        compilerOptions0.setAppNameStr("module$STRING hi!");
        boolean boolean4 = compilerOptions0.crossModuleMethodMotion;
        boolean boolean5 = compilerOptions0.computeFunctionSideEffects;
        compilerOptions0.reserveRawExports = false;
        boolean boolean8 = compilerOptions0.collapseAnonymousFunctions;
        boolean boolean9 = compilerOptions0.exportTestFunctions;
        com.google.javascript.jscomp.CheckLevel checkLevel10 = null;
        compilerOptions0.setCheckRequires(checkLevel10);
        compilerOptions0.renamePrefix = "hi!";
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean2 = node1.isFor();
        boolean boolean3 = node1.isExprResult();
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean6 = node5.isFor();
        com.google.javascript.rhino.Node node7 = node1.clonePropsFrom(node5);
        boolean boolean8 = node1.isOnlyModifiesThisCall();
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean11 = node10.isFor();
        boolean boolean12 = node10.isExprResult();
        java.lang.String str13 = node10.getString();
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean16 = node15.isFor();
        boolean boolean17 = node15.isExprResult();
        com.google.javascript.rhino.Node node18 = node10.clonePropsFrom(node15);
        boolean boolean19 = node18.isVar();
        com.google.javascript.rhino.Node node20 = node1.useSourceInfoFromForTree(node18);
        com.google.javascript.rhino.jstype.JSType jSType21 = null;
        node20.setJSType(jSType21);
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.IR.paramList();
        boolean boolean24 = node23.isThrow();
        node20.addChildToBack(node23);
        com.google.javascript.rhino.jstype.JSType jSType26 = node23.getJSType();
        node23.setSourceFileForTesting("goog.exportSymbol");
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "hi!" + "'", str13.equals("hi!"));
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNull(jSType26);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean2 = node1.isFor();
        com.google.javascript.rhino.Node node3 = null;
        try {
            com.google.javascript.rhino.Node node4 = node1.copyInformationFromForTree(node3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.reportMissingOverride;
        compilerOptions0.setAppNameStr("module$STRING hi!");
        com.google.javascript.jscomp.CompilerOptions.Reach reach4 = com.google.javascript.jscomp.CompilerOptions.Reach.ALL;
        compilerOptions0.setRemoveUnusedVariables(reach4);
        compilerOptions0.setExtractPrototypeMemberDeclarations(true);
        boolean boolean8 = compilerOptions0.flowSensitiveInlineVariables;
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + reach4 + "' != '" + com.google.javascript.jscomp.CompilerOptions.Reach.ALL + "'", reach4.equals(com.google.javascript.jscomp.CompilerOptions.Reach.ALL));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newNumber((double) ' ');
        org.junit.Assert.assertNotNull(node1);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        java.util.logging.Logger logger0 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager1 = new com.google.javascript.jscomp.LoggerErrorManager(logger0);
        double double2 = loggerErrorManager1.getTypedPercent();
        com.google.javascript.jscomp.Compiler compiler3 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager1);
        com.google.javascript.jscomp.Result result4 = compiler3.getResult();
        java.util.logging.Logger logger5 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager6 = new com.google.javascript.jscomp.LoggerErrorManager(logger5);
        double double7 = loggerErrorManager6.getTypedPercent();
        compiler3.setErrorManager((com.google.javascript.jscomp.ErrorManager) loggerErrorManager6);
        com.google.javascript.jscomp.NodeTraversal.Callback callback9 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal10 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler3, callback9);
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean14 = node13.isFor();
        boolean boolean15 = node13.isExprResult();
        java.lang.String str16 = node13.getString();
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean19 = node18.isFor();
        boolean boolean20 = node18.isExprResult();
        com.google.javascript.rhino.Node node21 = node13.clonePropsFrom(node18);
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean24 = node23.isFor();
        boolean boolean25 = node23.isExprResult();
        java.lang.String str26 = node23.getString();
        com.google.javascript.rhino.Node node28 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean29 = node28.isFor();
        boolean boolean30 = node28.isExprResult();
        com.google.javascript.rhino.Node node31 = node23.clonePropsFrom(node28);
        boolean boolean32 = node31.isVar();
        node31.setSourceEncodedPositionForTree(16);
        com.google.javascript.rhino.Node node35 = new com.google.javascript.rhino.Node(10, node18, node31);
        com.google.javascript.jscomp.SourceFile sourceFile37 = com.google.javascript.jscomp.SourceFile.fromFile("hi!");
        node35.setStaticSourceFile((com.google.javascript.rhino.jstype.StaticSourceFile) sourceFile37);
        com.google.javascript.rhino.Node node39 = com.google.javascript.rhino.IR.paramList();
        com.google.javascript.rhino.Node node40 = node35.srcref(node39);
        com.google.javascript.rhino.Node node44 = new com.google.javascript.rhino.Node((int) (byte) 100, (int) (byte) 1, 54);
        boolean boolean45 = node44.isReturn();
        boolean boolean46 = node40.isEquivalentToTyped(node44);
        com.google.javascript.jscomp.CompilerOptions compilerOptions47 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel48 = compilerOptions47.reportMissingOverride;
        compilerOptions47.setAppNameStr("module$STRING hi!");
        boolean boolean51 = compilerOptions47.crossModuleMethodMotion;
        boolean boolean52 = compilerOptions47.computeFunctionSideEffects;
        compilerOptions47.locale = "module$STRING hi!";
        compilerOptions47.setComputeFunctionSideEffects(true);
        compilerOptions47.setAliasableGlobals("hi!");
        com.google.javascript.jscomp.CompilerOptions compilerOptions59 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel60 = compilerOptions59.reportMissingOverride;
        compilerOptions47.checkUnreachableCode = checkLevel60;
        com.google.javascript.jscomp.CompilerOptions compilerOptions62 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel63 = compilerOptions62.reportMissingOverride;
        compilerOptions62.setAppNameStr("module$STRING hi!");
        boolean boolean66 = compilerOptions62.crossModuleMethodMotion;
        boolean boolean67 = compilerOptions62.computeFunctionSideEffects;
        compilerOptions62.locale = "module$STRING hi!";
        compilerOptions62.setComputeFunctionSideEffects(true);
        compilerOptions62.setAliasableGlobals("hi!");
        com.google.javascript.jscomp.CompilerOptions compilerOptions74 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel75 = compilerOptions74.reportMissingOverride;
        compilerOptions62.checkUnreachableCode = checkLevel75;
        compilerOptions47.checkMissingGetCssNameLevel = checkLevel75;
        com.google.javascript.jscomp.DiagnosticType diagnosticType78 = com.google.javascript.jscomp.Compiler.MOTION_ITERATIONS_ERROR;
        java.lang.String[] strArray80 = new java.lang.String[] { "hi!. hi! at (unknown source) line (unknown line) : (unknown column)" };
        com.google.javascript.jscomp.JSError jSError81 = nodeTraversal10.makeError(node44, checkLevel75, diagnosticType78, strArray80);
        boolean boolean82 = node44.isNew();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(result4);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "hi!" + "'", str16.equals("hi!"));
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "hi!" + "'", str26.equals("hi!"));
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(sourceFile37);
        org.junit.Assert.assertNotNull(node39);
        org.junit.Assert.assertNotNull(node40);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + checkLevel48 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel48.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertTrue("'" + checkLevel60 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel60.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + checkLevel63 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel63.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
        org.junit.Assert.assertTrue("'" + checkLevel75 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel75.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(diagnosticType78);
        org.junit.Assert.assertNotNull(strArray80);
        org.junit.Assert.assertNotNull(jSError81);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.reportMissingOverride;
        compilerOptions0.setAppNameStr("module$STRING hi!");
        boolean boolean4 = compilerOptions0.crossModuleMethodMotion;
        boolean boolean5 = compilerOptions0.computeFunctionSideEffects;
        compilerOptions0.reserveRawExports = false;
        compilerOptions0.closurePass = false;
        compilerOptions0.reserveRawExports = false;
        compilerOptions0.setAssumeClosuresOnlyCaptureReferences(false);
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newNumber(0.0d);
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.IR.returnNode(node1);
        boolean boolean3 = node2.isQuotedString();
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        com.google.javascript.jscomp.DiagnosticType diagnosticType2 = com.google.javascript.jscomp.DiagnosticType.disabled("hi!", "hi!");
        java.lang.String[] strArray4 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError5 = com.google.javascript.jscomp.JSError.make(diagnosticType2, strArray4);
        int int6 = jSError5.getNodeLength();
        java.lang.String str7 = jSError5.description;
        org.junit.Assert.assertNotNull(diagnosticType2);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(jSError5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "hi!" + "'", str7.equals("hi!"));
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean2 = node1.isFor();
        boolean boolean3 = node1.isExprResult();
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean6 = node5.isFor();
        com.google.javascript.rhino.Node node7 = node1.clonePropsFrom(node5);
        node5.addSuppression("module$STRING hi!");
        java.lang.String str13 = node5.toString(true, true, false);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder14 = node5.new FileLevelJsDocBuilder();
        boolean boolean15 = node5.hasChildren();
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "STRING hi! [jsdoc_info: JSDocInfo]" + "'", str13.equals("STRING hi! [jsdoc_info: JSDocInfo]"));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        com.google.javascript.jscomp.AbstractCompiler abstractCompiler0 = null;
        com.google.javascript.jscomp.NodeTraversal.Callback callback1 = null;
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean4 = node3.isFor();
        boolean boolean5 = node3.isExprResult();
        java.lang.String str6 = node3.getString();
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean9 = node8.isFor();
        boolean boolean10 = node8.isExprResult();
        com.google.javascript.rhino.Node node11 = node3.clonePropsFrom(node8);
        com.google.javascript.jscomp.CompilerOptions compilerOptions12 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel13 = compilerOptions12.reportMissingOverride;
        java.lang.String[] strArray20 = new java.lang.String[] { "STRING hi!", "hi!. hi! at (unknown source) line (unknown line) : (unknown column)", "module$STRING hi!", "hi!", "", "STRING hi!" };
        java.util.LinkedHashSet<java.lang.String> strSet21 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean22 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet21, strArray20);
        compilerOptions12.setIdGenerators((java.util.Set<java.lang.String>) strSet21);
        node3.setDirectives((java.util.Set<java.lang.String>) strSet21);
        com.google.javascript.rhino.Node node26 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean27 = node26.isFor();
        boolean boolean28 = node26.isExprResult();
        com.google.javascript.rhino.Node node30 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean31 = node30.isFor();
        com.google.javascript.rhino.Node node32 = node26.clonePropsFrom(node30);
        boolean boolean33 = node26.isOnlyModifiesThisCall();
        com.google.javascript.rhino.Node node35 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean36 = node35.isFor();
        boolean boolean37 = node35.isExprResult();
        java.lang.String str38 = node35.getString();
        com.google.javascript.rhino.Node node40 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean41 = node40.isFor();
        boolean boolean42 = node40.isExprResult();
        com.google.javascript.rhino.Node node43 = node35.clonePropsFrom(node40);
        boolean boolean44 = node43.isVar();
        com.google.javascript.rhino.Node node45 = node26.useSourceInfoFromForTree(node43);
        com.google.javascript.rhino.jstype.JSType jSType46 = null;
        node45.setJSType(jSType46);
        com.google.javascript.rhino.Node node48 = com.google.javascript.rhino.IR.paramList();
        boolean boolean49 = node48.isThrow();
        node45.addChildToBack(node48);
        com.google.javascript.rhino.jstype.JSType jSType51 = node48.getJSType();
        com.google.javascript.rhino.Node[] nodeArray52 = new com.google.javascript.rhino.Node[] { node3, node48 };
        try {
            com.google.javascript.jscomp.NodeTraversal.traverseRoots(abstractCompiler0, callback1, nodeArray52);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertTrue("'" + checkLevel13 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel13.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(strArray20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(node30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(node32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "hi!" + "'", str38.equals("hi!"));
        org.junit.Assert.assertNotNull(node40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(node43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(node45);
        org.junit.Assert.assertNotNull(node48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNull(jSType51);
        org.junit.Assert.assertNotNull(nodeArray52);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        com.google.javascript.jscomp.SourceFile sourceFile1 = com.google.javascript.jscomp.SourceFile.fromFile("hi!");
        boolean boolean2 = sourceFile1.isExtern();
        com.google.javascript.jscomp.JsAst jsAst3 = new com.google.javascript.jscomp.JsAst(sourceFile1);
        java.util.logging.Logger logger4 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager5 = new com.google.javascript.jscomp.LoggerErrorManager(logger4);
        double double6 = loggerErrorManager5.getTypedPercent();
        com.google.javascript.jscomp.Compiler compiler7 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager5);
        com.google.javascript.jscomp.Result result8 = compiler7.getResult();
        java.util.logging.Logger logger9 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager10 = new com.google.javascript.jscomp.LoggerErrorManager(logger9);
        double double11 = loggerErrorManager10.getTypedPercent();
        compiler7.setErrorManager((com.google.javascript.jscomp.ErrorManager) loggerErrorManager10);
        com.google.javascript.jscomp.NodeTraversal.Callback callback13 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal14 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler7, callback13);
        com.google.javascript.jscomp.Scope scope15 = compiler7.getTopScope();
        com.google.javascript.rhino.Node node16 = jsAst3.getAstRoot((com.google.javascript.jscomp.AbstractCompiler) compiler7);
        try {
            com.google.javascript.jscomp.CodingConvention codingConvention17 = compiler7.getCodingConvention();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(sourceFile1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(result8);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNull(scope15);
        org.junit.Assert.assertNotNull(node16);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean3 = node2.isFor();
        boolean boolean4 = node2.isExprResult();
        java.lang.String str5 = node2.getString();
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean8 = node7.isFor();
        boolean boolean9 = node7.isExprResult();
        com.google.javascript.rhino.Node node10 = node2.clonePropsFrom(node7);
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean13 = node12.isFor();
        boolean boolean14 = node12.isExprResult();
        java.lang.String str15 = node12.getString();
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean18 = node17.isFor();
        boolean boolean19 = node17.isExprResult();
        com.google.javascript.rhino.Node node20 = node12.clonePropsFrom(node17);
        boolean boolean21 = node20.isVar();
        node20.setSourceEncodedPositionForTree(16);
        com.google.javascript.rhino.Node node24 = new com.google.javascript.rhino.Node(10, node7, node20);
        com.google.javascript.jscomp.SourceFile sourceFile26 = com.google.javascript.jscomp.SourceFile.fromFile("hi!");
        node24.setStaticSourceFile((com.google.javascript.rhino.jstype.StaticSourceFile) sourceFile26);
        com.google.javascript.rhino.Node node28 = com.google.javascript.rhino.IR.paramList();
        com.google.javascript.rhino.Node node29 = node24.srcref(node28);
        com.google.javascript.rhino.Node node30 = node29.cloneNode();
        com.google.javascript.rhino.Node node32 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean33 = node32.isFor();
        boolean boolean34 = node32.isExprResult();
        com.google.javascript.rhino.Node node36 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean37 = node36.isFor();
        com.google.javascript.rhino.Node node38 = node32.clonePropsFrom(node36);
        node36.addSuppression("module$STRING hi!");
        java.lang.String str44 = node36.toString(true, true, false);
        com.google.javascript.rhino.Node node45 = com.google.javascript.rhino.IR.or(node30, node36);
        boolean boolean46 = node36.isContinue();
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "hi!" + "'", str15.equals("hi!"));
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(sourceFile26);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNotNull(node30);
        org.junit.Assert.assertNotNull(node32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(node36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(node38);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "STRING hi! [jsdoc_info: JSDocInfo]" + "'", str44.equals("STRING hi! [jsdoc_info: JSDocInfo]"));
        org.junit.Assert.assertNotNull(node45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.reportMissingOverride;
        compilerOptions0.setAppNameStr("module$STRING hi!");
        boolean boolean4 = compilerOptions0.crossModuleMethodMotion;
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean7 = node6.isFor();
        boolean boolean8 = node6.isExprResult();
        java.lang.String str9 = node6.getString();
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean12 = node11.isFor();
        boolean boolean13 = node11.isExprResult();
        com.google.javascript.rhino.Node node14 = node6.clonePropsFrom(node11);
        com.google.javascript.jscomp.CompilerOptions compilerOptions15 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel16 = compilerOptions15.reportMissingOverride;
        java.lang.String[] strArray23 = new java.lang.String[] { "STRING hi!", "hi!. hi! at (unknown source) line (unknown line) : (unknown column)", "module$STRING hi!", "hi!", "", "STRING hi!" };
        java.util.LinkedHashSet<java.lang.String> strSet24 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean25 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet24, strArray23);
        compilerOptions15.setIdGenerators((java.util.Set<java.lang.String>) strSet24);
        node6.setDirectives((java.util.Set<java.lang.String>) strSet24);
        compilerOptions0.aliasableStrings = strSet24;
        com.google.javascript.jscomp.CheckLevel checkLevel29 = com.google.javascript.jscomp.CheckLevel.OFF;
        compilerOptions0.setReportUnknownTypes(checkLevel29);
        java.util.Map<java.lang.String, com.google.javascript.rhino.Node> strMap31 = compilerOptions0.getTweakReplacements();
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "hi!" + "'", str9.equals("hi!"));
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertTrue("'" + checkLevel16 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel16.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(strArray23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + checkLevel29 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel29.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(strMap31);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        java.util.logging.Logger logger0 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager1 = new com.google.javascript.jscomp.LoggerErrorManager(logger0);
        double double2 = loggerErrorManager1.getTypedPercent();
        com.google.javascript.jscomp.Compiler compiler3 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager1);
        com.google.javascript.jscomp.Result result4 = compiler3.getResult();
        java.util.logging.Logger logger5 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager6 = new com.google.javascript.jscomp.LoggerErrorManager(logger5);
        double double7 = loggerErrorManager6.getTypedPercent();
        compiler3.setErrorManager((com.google.javascript.jscomp.ErrorManager) loggerErrorManager6);
        com.google.javascript.jscomp.NodeTraversal.Callback callback9 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal10 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler3, callback9);
        try {
            com.google.javascript.jscomp.JSModule jSModule11 = nodeTraversal10.getModule();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(result4);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean3 = node2.isFor();
        boolean boolean4 = node2.isExprResult();
        java.lang.String str5 = node2.getString();
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean8 = node7.isFor();
        boolean boolean9 = node7.isExprResult();
        com.google.javascript.rhino.Node node10 = node2.clonePropsFrom(node7);
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean13 = node12.isFor();
        boolean boolean14 = node12.isExprResult();
        java.lang.String str15 = node12.getString();
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean18 = node17.isFor();
        boolean boolean19 = node17.isExprResult();
        com.google.javascript.rhino.Node node20 = node12.clonePropsFrom(node17);
        boolean boolean21 = node20.isVar();
        node20.setSourceEncodedPositionForTree(16);
        com.google.javascript.rhino.Node node24 = new com.google.javascript.rhino.Node(10, node7, node20);
        boolean boolean25 = node20.isSetterDef();
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "hi!" + "'", str15.equals("hi!"));
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.reportMissingOverride;
        compilerOptions0.setAppNameStr("module$STRING hi!");
        boolean boolean4 = compilerOptions0.crossModuleMethodMotion;
        boolean boolean5 = compilerOptions0.computeFunctionSideEffects;
        com.google.javascript.jscomp.CompilerOptions compilerOptions6 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel7 = compilerOptions6.reportMissingOverride;
        com.google.javascript.jscomp.CompilerOptions.LanguageMode languageMode8 = com.google.javascript.jscomp.CompilerOptions.LanguageMode.ECMASCRIPT5;
        compilerOptions6.setLanguageIn(languageMode8);
        compilerOptions0.setLanguageIn(languageMode8);
        compilerOptions0.deadAssignmentElimination = false;
        java.lang.String str13 = compilerOptions0.inputDelimiter;
        com.google.javascript.jscomp.CompilerOptions compilerOptions14 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel15 = compilerOptions14.reportMissingOverride;
        java.lang.String[] strArray22 = new java.lang.String[] { "STRING hi!", "hi!. hi! at (unknown source) line (unknown line) : (unknown column)", "module$STRING hi!", "hi!", "", "STRING hi!" };
        java.util.LinkedHashSet<java.lang.String> strSet23 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean24 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet23, strArray22);
        compilerOptions14.setIdGenerators((java.util.Set<java.lang.String>) strSet23);
        compilerOptions0.setStripNamePrefixes((java.util.Set<java.lang.String>) strSet23);
        compilerOptions0.setRemoveClosureAsserts(false);
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + checkLevel7 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel7.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + languageMode8 + "' != '" + com.google.javascript.jscomp.CompilerOptions.LanguageMode.ECMASCRIPT5 + "'", languageMode8.equals(com.google.javascript.jscomp.CompilerOptions.LanguageMode.ECMASCRIPT5));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "// Input %num%" + "'", str13.equals("// Input %num%"));
        org.junit.Assert.assertTrue("'" + checkLevel15 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel15.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(strArray22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.Node.newString("Unknown class name");
        com.google.javascript.rhino.Node node5 = new com.google.javascript.rhino.Node(0, node2, 0, 54);
        org.junit.Assert.assertNotNull(node2);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        com.google.javascript.jscomp.CodingConvention codingConvention0 = com.google.javascript.jscomp.CodingConventions.getDefault();
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention1 = new com.google.javascript.jscomp.ClosureCodingConvention(codingConvention0);
        boolean boolean3 = closureCodingConvention1.isExported("");
        java.lang.String str4 = closureCodingConvention1.getGlobalObject();
        com.google.javascript.rhino.jstype.FunctionType functionType5 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType6 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType7 = null;
        closureCodingConvention1.applySubclassRelationship(functionType5, functionType6, subclassType7);
        java.util.Collection<com.google.javascript.jscomp.CodingConvention.AssertionFunctionSpec> assertionFunctionSpecCollection9 = closureCodingConvention1.getAssertionFunctions();
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.Node.newString("hi!");
        java.lang.Object obj13 = null;
        node11.putProp(50, obj13);
        com.google.javascript.rhino.jstype.StaticSourceFile staticSourceFile15 = node11.getStaticSourceFile();
        try {
            boolean boolean16 = closureCodingConvention1.isPropertyTestFunction(node11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(codingConvention0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "goog.global" + "'", str4.equals("goog.global"));
        org.junit.Assert.assertNotNull(assertionFunctionSpecCollection9);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertNull(staticSourceFile15);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        com.google.javascript.jscomp.SourceFile sourceFile1 = com.google.javascript.jscomp.SourceFile.fromFile("hi!");
        boolean boolean2 = sourceFile1.isExtern();
        com.google.javascript.jscomp.JsAst jsAst3 = new com.google.javascript.jscomp.JsAst(sourceFile1);
        java.util.logging.Logger logger4 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager5 = new com.google.javascript.jscomp.LoggerErrorManager(logger4);
        double double6 = loggerErrorManager5.getTypedPercent();
        com.google.javascript.jscomp.Compiler compiler7 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager5);
        com.google.javascript.jscomp.Result result8 = compiler7.getResult();
        java.util.logging.Logger logger9 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager10 = new com.google.javascript.jscomp.LoggerErrorManager(logger9);
        double double11 = loggerErrorManager10.getTypedPercent();
        compiler7.setErrorManager((com.google.javascript.jscomp.ErrorManager) loggerErrorManager10);
        com.google.javascript.jscomp.NodeTraversal.Callback callback13 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal14 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler7, callback13);
        com.google.javascript.jscomp.Scope scope15 = compiler7.getTopScope();
        com.google.javascript.rhino.Node node16 = jsAst3.getAstRoot((com.google.javascript.jscomp.AbstractCompiler) compiler7);
        try {
            java.lang.String str17 = node16.getString();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: SCRIPT [source_file: hi!] [input_id: InputId: hi!] is not a string node");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(sourceFile1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(result8);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNull(scope15);
        org.junit.Assert.assertNotNull(node16);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        com.google.javascript.jscomp.SourceFile.Generator generator1 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("goog.global", generator1);
        try {
            java.lang.String str4 = jSSourceFile2.getLine(35);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile2);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy0 = com.google.javascript.jscomp.VariableRenamingPolicy.LOCAL;
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy0 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.LOCAL + "'", variableRenamingPolicy0.equals(com.google.javascript.jscomp.VariableRenamingPolicy.LOCAL));
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        java.util.logging.Logger logger0 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager1 = new com.google.javascript.jscomp.LoggerErrorManager(logger0);
        double double2 = loggerErrorManager1.getTypedPercent();
        com.google.javascript.jscomp.Compiler compiler3 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager1);
        loggerErrorManager1.setTypedPercent((double) 1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        java.util.logging.Logger logger0 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager1 = new com.google.javascript.jscomp.LoggerErrorManager(logger0);
        double double2 = loggerErrorManager1.getTypedPercent();
        com.google.javascript.jscomp.Compiler compiler3 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager1);
        com.google.javascript.jscomp.Result result4 = compiler3.getResult();
        java.util.logging.Logger logger5 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager6 = new com.google.javascript.jscomp.LoggerErrorManager(logger5);
        double double7 = loggerErrorManager6.getTypedPercent();
        compiler3.setErrorManager((com.google.javascript.jscomp.ErrorManager) loggerErrorManager6);
        com.google.javascript.jscomp.NodeTraversal.Callback callback9 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal10 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler3, callback9);
        java.lang.String str11 = nodeTraversal10.getSourceName();
        com.google.javascript.jscomp.Compiler compiler12 = nodeTraversal10.getCompiler();
        try {
            compiler12.normalize();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(result4);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertNotNull(compiler12);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        boolean boolean1 = com.google.javascript.jscomp.NodeUtil.isValidSimpleName("goog.abstractMethod");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        java.util.logging.Logger logger0 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager1 = new com.google.javascript.jscomp.LoggerErrorManager(logger0);
        double double2 = loggerErrorManager1.getTypedPercent();
        com.google.javascript.jscomp.Compiler compiler3 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager1);
        com.google.javascript.jscomp.Result result4 = compiler3.getResult();
        java.util.logging.Logger logger5 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager6 = new com.google.javascript.jscomp.LoggerErrorManager(logger5);
        double double7 = loggerErrorManager6.getTypedPercent();
        compiler3.setErrorManager((com.google.javascript.jscomp.ErrorManager) loggerErrorManager6);
        com.google.javascript.jscomp.NodeTraversal.Callback callback9 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal10 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler3, callback9);
        java.lang.String str11 = nodeTraversal10.getSourceName();
        com.google.javascript.jscomp.Compiler compiler12 = nodeTraversal10.getCompiler();
        try {
            boolean boolean13 = compiler12.acceptEcmaScript5();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(result4);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertNotNull(compiler12);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = null;
        com.google.javascript.jscomp.DiagnosticGroups.CHECK_USELESS_CODE = diagnosticGroup0;
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = null;
        com.google.javascript.jscomp.DiagnosticGroups.DUPLICATE_MESSAGE = diagnosticGroup0;
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newString("hi!");
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.IR.voidNode(node1);
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean5 = node4.isFor();
        boolean boolean6 = node4.isExprResult();
        java.lang.String str7 = node4.getString();
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean10 = node9.isFor();
        boolean boolean11 = node9.isExprResult();
        com.google.javascript.rhino.Node node12 = node4.clonePropsFrom(node9);
        boolean boolean13 = node1.isEquivalentToTyped(node4);
        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean17 = node16.isFor();
        boolean boolean18 = node16.isExprResult();
        java.lang.String str19 = node16.getString();
        com.google.javascript.rhino.Node node21 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean22 = node21.isFor();
        boolean boolean23 = node21.isExprResult();
        com.google.javascript.rhino.Node node24 = node16.clonePropsFrom(node21);
        com.google.javascript.rhino.Node node26 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean27 = node26.isFor();
        boolean boolean28 = node26.isExprResult();
        java.lang.String str29 = node26.getString();
        com.google.javascript.rhino.Node node31 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean32 = node31.isFor();
        boolean boolean33 = node31.isExprResult();
        com.google.javascript.rhino.Node node34 = node26.clonePropsFrom(node31);
        boolean boolean35 = node34.isVar();
        node34.setSourceEncodedPositionForTree(16);
        com.google.javascript.rhino.Node node38 = new com.google.javascript.rhino.Node(10, node21, node34);
        boolean boolean39 = node34.isTrue();
        try {
            com.google.javascript.rhino.Node node40 = com.google.javascript.rhino.IR.caseNode(node1, node34);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "hi!" + "'", str7.equals("hi!"));
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "hi!" + "'", str19.equals("hi!"));
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "hi!" + "'", str29.equals("hi!"));
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(node34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        java.util.logging.Logger logger0 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager1 = new com.google.javascript.jscomp.LoggerErrorManager(logger0);
        double double2 = loggerErrorManager1.getTypedPercent();
        com.google.javascript.jscomp.Compiler compiler3 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager1);
        com.google.javascript.jscomp.Result result4 = compiler3.getResult();
        java.util.logging.Logger logger5 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager6 = new com.google.javascript.jscomp.LoggerErrorManager(logger5);
        double double7 = loggerErrorManager6.getTypedPercent();
        compiler3.setErrorManager((com.google.javascript.jscomp.ErrorManager) loggerErrorManager6);
        com.google.javascript.jscomp.NodeTraversal.Callback callback9 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal10 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler3, callback9);
        com.google.javascript.rhino.Node node11 = nodeTraversal10.getEnclosingFunction();
        try {
            com.google.javascript.jscomp.JSModule jSModule12 = nodeTraversal10.getModule();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(result4);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNull(node11);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.reportMissingOverride;
        compilerOptions0.setAppNameStr("module$STRING hi!");
        boolean boolean4 = compilerOptions0.crossModuleMethodMotion;
        boolean boolean5 = compilerOptions0.computeFunctionSideEffects;
        compilerOptions0.reserveRawExports = false;
        compilerOptions0.setLocale("");
        java.lang.String str10 = compilerOptions0.sourceMapOutputPath;
        compilerOptions0.setDebugFunctionSideEffectsPath("InputId: ");
        com.google.javascript.jscomp.CodingConvention codingConvention13 = com.google.javascript.jscomp.CodingConventions.getDefault();
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention14 = new com.google.javascript.jscomp.ClosureCodingConvention(codingConvention13);
        boolean boolean16 = closureCodingConvention14.isExported("");
        java.lang.String str17 = closureCodingConvention14.getGlobalObject();
        compilerOptions0.setCodingConvention((com.google.javascript.jscomp.CodingConvention) closureCodingConvention14);
        boolean boolean20 = closureCodingConvention14.isConstantKey("goog.global");
        com.google.javascript.rhino.Node node22 = com.google.javascript.rhino.Node.newString("hi!");
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.IR.voidNode(node22);
        boolean boolean24 = node23.isBreak();
        boolean boolean25 = node23.isNumber();
        int int26 = node23.getSourcePosition();
        com.google.javascript.jscomp.CodingConvention.Bind bind27 = closureCodingConvention14.describeFunctionBind(node23);
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertNotNull(codingConvention13);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "goog.global" + "'", str17.equals("goog.global"));
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
        org.junit.Assert.assertNull(bind27);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        com.google.javascript.jscomp.SourceFile sourceFile1 = com.google.javascript.jscomp.SourceFile.fromFile("hi!");
        boolean boolean2 = sourceFile1.isExtern();
        com.google.javascript.jscomp.JsAst jsAst3 = new com.google.javascript.jscomp.JsAst(sourceFile1);
        com.google.javascript.jscomp.CompilerInput compilerInput6 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) jsAst3, "// Input %num%", false);
        com.google.javascript.jscomp.SourceAst sourceAst7 = compilerInput6.getSourceAst();
        com.google.javascript.rhino.InputId inputId9 = new com.google.javascript.rhino.InputId("");
        com.google.javascript.jscomp.CompilerInput compilerInput11 = new com.google.javascript.jscomp.CompilerInput(sourceAst7, inputId9, true);
        try {
            int int13 = compilerInput11.getLineOffset(53);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Expected line number between 1 and 1\nActual: 53");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(sourceFile1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(sourceAst7);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        com.google.javascript.jscomp.CodingConvention codingConvention0 = com.google.javascript.jscomp.CodingConventions.getDefault();
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention1 = new com.google.javascript.jscomp.ClosureCodingConvention(codingConvention0);
        boolean boolean3 = closureCodingConvention1.isExported("");
        java.lang.String str4 = closureCodingConvention1.getGlobalObject();
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.IR.returnNode();
        boolean boolean6 = node5.isSwitch();
        boolean boolean7 = closureCodingConvention1.isVarArgsParameter(node5);
        int int8 = node5.getSourceOffset();
        org.junit.Assert.assertNotNull(codingConvention0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "goog.global" + "'", str4.equals("goog.global"));
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2147483647 + "'", int8 == 2147483647);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        java.util.logging.Logger logger0 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager1 = new com.google.javascript.jscomp.LoggerErrorManager(logger0);
        double double2 = loggerErrorManager1.getTypedPercent();
        com.google.javascript.jscomp.Compiler compiler3 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager1);
        com.google.javascript.jscomp.Result result4 = compiler3.getResult();
        java.lang.String str5 = compiler3.getAstDotGraph();
        com.google.javascript.jscomp.JSError[] jSErrorArray6 = compiler3.getWarnings();
        com.google.javascript.jscomp.JSError[] jSErrorArray7 = compiler3.getWarnings();
        com.google.javascript.jscomp.PerformanceTracker performanceTracker8 = null;
        compiler3.tracker = performanceTracker8;
        try {
            com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry10 = compiler3.getTypeRegistry();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(result4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertNotNull(jSErrorArray6);
        org.junit.Assert.assertNotNull(jSErrorArray7);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        java.lang.String str0 = com.google.javascript.rhino.jstype.JSType.NOT_A_CLASS;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "Not declared as a constructor" + "'", str0.equals("Not declared as a constructor"));
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        int int0 = com.google.javascript.rhino.Node.FLAG_NO_THROWS;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 8 + "'", int0 == 8);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean2 = node1.isFor();
        boolean boolean3 = node1.isExprResult();
        int int4 = node1.getSourcePosition();
        boolean boolean5 = node1.isTrue();
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean2 = node1.isFor();
        boolean boolean3 = node1.isExprResult();
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean6 = node5.isFor();
        com.google.javascript.rhino.Node node7 = node1.clonePropsFrom(node5);
        boolean boolean8 = node1.isOnlyModifiesThisCall();
        boolean boolean9 = node1.isAdd();
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean12 = node11.isFor();
        boolean boolean13 = node11.isExprResult();
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean16 = node15.isFor();
        com.google.javascript.rhino.Node node17 = node11.clonePropsFrom(node15);
        boolean boolean18 = node11.isOnlyModifiesThisCall();
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean21 = node20.isFor();
        boolean boolean22 = node20.isExprResult();
        java.lang.String str23 = node20.getString();
        com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean26 = node25.isFor();
        boolean boolean27 = node25.isExprResult();
        com.google.javascript.rhino.Node node28 = node20.clonePropsFrom(node25);
        boolean boolean29 = node28.isVar();
        com.google.javascript.rhino.Node node30 = node11.useSourceInfoFromForTree(node28);
        com.google.javascript.rhino.jstype.JSType jSType31 = null;
        node30.setJSType(jSType31);
        com.google.javascript.rhino.Node node33 = com.google.javascript.rhino.IR.paramList();
        boolean boolean34 = node33.isThrow();
        node30.addChildToBack(node33);
        com.google.javascript.rhino.Node node36 = com.google.javascript.rhino.IR.add(node1, node30);
        boolean boolean37 = node30.isWhile();
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "hi!" + "'", str23.equals("hi!"));
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(node30);
        org.junit.Assert.assertNotNull(node33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(node36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newString("hi!");
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.IR.voidNode(node1);
        java.lang.String str6 = node1.toString(true, false, false);
        com.google.javascript.rhino.Node node8 = node1.getChildAtIndex((int) (byte) -1);
        com.google.javascript.jscomp.CompilerOptions compilerOptions10 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel11 = compilerOptions10.reportMissingOverride;
        try {
            node8.putProp(0, (java.lang.Object) compilerOptions10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "STRING hi!" + "'", str6.equals("STRING hi!"));
        org.junit.Assert.assertNull(node8);
        org.junit.Assert.assertTrue("'" + checkLevel11 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel11.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        java.util.logging.Logger logger0 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager1 = new com.google.javascript.jscomp.LoggerErrorManager(logger0);
        double double2 = loggerErrorManager1.getTypedPercent();
        com.google.javascript.jscomp.Compiler compiler3 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager1);
        int int4 = compiler3.getWarningCount();
        try {
            java.lang.String str5 = compiler3.toSource();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        java.util.logging.Logger logger0 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager1 = new com.google.javascript.jscomp.LoggerErrorManager(logger0);
        double double2 = loggerErrorManager1.getTypedPercent();
        com.google.javascript.jscomp.Compiler compiler3 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager1);
        com.google.javascript.jscomp.Result result4 = compiler3.getResult();
        try {
            boolean boolean5 = compiler3.isTypeCheckingEnabled();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(result4);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.paramList();
        boolean boolean1 = node0.isParamList();
        boolean boolean2 = com.google.javascript.jscomp.NodeUtil.isSymmetricOperation(node0);
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString("hi!");
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.IR.voidNode(node4);
        boolean boolean6 = node5.isBreak();
        boolean boolean7 = node5.isNumber();
        boolean boolean8 = node0.isEquivalentTo(node5);
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.returnNode();
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder1 = node0.new FileLevelJsDocBuilder();
        fileLevelJsDocBuilder1.append("InputId: ");
        fileLevelJsDocBuilder1.append("./");
        org.junit.Assert.assertNotNull(node0);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean2 = node1.isFor();
        boolean boolean3 = node1.isExprResult();
        java.lang.String str4 = node1.getString();
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean7 = node6.isFor();
        boolean boolean8 = node6.isExprResult();
        com.google.javascript.rhino.Node node9 = node1.clonePropsFrom(node6);
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean12 = node11.isFor();
        boolean boolean13 = node11.isExprResult();
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean16 = node15.isFor();
        com.google.javascript.rhino.Node node17 = node11.clonePropsFrom(node15);
        node15.addSuppression("module$STRING hi!");
        com.google.javascript.rhino.Node node21 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean22 = node21.isFor();
        boolean boolean23 = node21.isExprResult();
        java.lang.String str24 = node21.getString();
        com.google.javascript.rhino.Node node26 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean27 = node26.isFor();
        boolean boolean28 = node26.isExprResult();
        com.google.javascript.rhino.Node node29 = node21.clonePropsFrom(node26);
        com.google.javascript.rhino.Node node31 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean32 = node31.isFor();
        boolean boolean33 = node31.isExprResult();
        java.lang.String str34 = node31.getString();
        com.google.javascript.rhino.Node node36 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean37 = node36.isFor();
        boolean boolean38 = node36.isExprResult();
        com.google.javascript.rhino.Node node39 = node31.clonePropsFrom(node36);
        int int40 = node26.getIndexOfChild(node31);
        com.google.javascript.rhino.Node node41 = node26.cloneTree();
        com.google.javascript.rhino.Node node42 = com.google.javascript.rhino.IR.comma(node15, node41);
        com.google.javascript.rhino.Node node43 = com.google.javascript.rhino.IR.sheq(node1, node42);
        boolean boolean44 = node43.isRegExp();
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "hi!" + "'", str4.equals("hi!"));
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "hi!" + "'", str24.equals("hi!"));
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "hi!" + "'", str34.equals("hi!"));
        org.junit.Assert.assertNotNull(node36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(node39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + (-1) + "'", int40 == (-1));
        org.junit.Assert.assertNotNull(node41);
        org.junit.Assert.assertNotNull(node42);
        org.junit.Assert.assertNotNull(node43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newNumber(0.0d);
        com.google.javascript.rhino.Node.AncestorIterable ancestorIterable2 = node1.getAncestors();
        boolean boolean3 = node1.isCatch();
        boolean boolean4 = node1.isWith();
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertNotNull(ancestorIterable2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        java.util.logging.Logger logger0 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager1 = new com.google.javascript.jscomp.LoggerErrorManager(logger0);
        double double2 = loggerErrorManager1.getTypedPercent();
        com.google.javascript.jscomp.Compiler compiler3 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager1);
        int int4 = compiler3.getWarningCount();
        java.util.List<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList5 = null;
        com.google.javascript.jscomp.JSModule[] jSModuleArray6 = new com.google.javascript.jscomp.JSModule[] {};
        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList7 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
        boolean boolean8 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList7, jSModuleArray6);
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph9 = new com.google.javascript.jscomp.JSModuleGraph((java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList7);
        com.google.javascript.jscomp.CompilerOptions compilerOptions10 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel11 = compilerOptions10.reportMissingOverride;
        compilerOptions10.recordFunctionInformation = false;
        try {
            compiler3.initModules(jSSourceFileList5, (java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList7, compilerOptions10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(jSModuleArray6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + checkLevel11 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel11.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        java.util.logging.Logger logger0 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager1 = new com.google.javascript.jscomp.LoggerErrorManager(logger0);
        double double2 = loggerErrorManager1.getTypedPercent();
        com.google.javascript.jscomp.Compiler compiler3 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager1);
        com.google.javascript.jscomp.Result result4 = compiler3.getResult();
        int int5 = compiler3.getErrorCount();
        try {
            compiler3.processDefines();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(result4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        java.util.logging.Logger logger0 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager1 = new com.google.javascript.jscomp.LoggerErrorManager(logger0);
        double double2 = loggerErrorManager1.getTypedPercent();
        com.google.javascript.jscomp.Compiler compiler3 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager1);
        com.google.javascript.jscomp.Result result4 = compiler3.getResult();
        java.lang.String str5 = compiler3.getAstDotGraph();
        com.google.javascript.jscomp.JSError[] jSErrorArray6 = compiler3.getWarnings();
        com.google.javascript.jscomp.JSError[] jSErrorArray7 = compiler3.getWarnings();
        try {
            boolean boolean8 = compiler3.acceptConstKeyword();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(result4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertNotNull(jSErrorArray6);
        org.junit.Assert.assertNotNull(jSErrorArray7);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        com.google.javascript.jscomp.DiagnosticType diagnosticType2 = com.google.javascript.jscomp.DiagnosticType.disabled("STRING hi!", "STRING hi!");
        org.junit.Assert.assertNotNull(diagnosticType2);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.reportMissingOverride;
        compilerOptions0.setAppNameStr("module$STRING hi!");
        boolean boolean4 = compilerOptions0.crossModuleMethodMotion;
        boolean boolean5 = compilerOptions0.computeFunctionSideEffects;
        compilerOptions0.reserveRawExports = false;
        compilerOptions0.setLocale("");
        java.lang.String str10 = compilerOptions0.sourceMapOutputPath;
        compilerOptions0.setProcessObjectPropertyString(true);
        compilerOptions0.setCollapseObjectLiterals(true);
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(str10);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CompilerOptions compilerOptions1 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel2 = compilerOptions1.reportMissingOverride;
        compilerOptions0.setAggressiveVarCheck(checkLevel2);
        com.google.javascript.jscomp.SourceMap.Format format4 = compilerOptions0.sourceMapFormat;
        boolean boolean5 = compilerOptions0.collapseVariableDeclarations;
        compilerOptions0.setAcceptConstKeyword(true);
        com.google.javascript.jscomp.CompilerOptions compilerOptions8 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel9 = compilerOptions8.reportMissingOverride;
        compilerOptions8.setAppNameStr("module$STRING hi!");
        com.google.javascript.jscomp.CompilerOptions compilerOptions12 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel13 = compilerOptions12.reportMissingOverride;
        compilerOptions12.setAppNameStr("module$STRING hi!");
        boolean boolean16 = compilerOptions12.crossModuleMethodMotion;
        boolean boolean17 = compilerOptions12.computeFunctionSideEffects;
        compilerOptions12.locale = "module$STRING hi!";
        compilerOptions12.setComputeFunctionSideEffects(true);
        boolean boolean22 = compilerOptions12.ambiguateProperties;
        boolean boolean23 = compilerOptions12.exportTestFunctions;
        com.google.javascript.jscomp.SourceMap.Format format24 = compilerOptions12.sourceMapFormat;
        compilerOptions8.setSourceMapFormat(format24);
        compilerOptions0.sourceMapFormat = format24;
        compilerOptions0.resetWarningsGuard();
        org.junit.Assert.assertTrue("'" + checkLevel2 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel2.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(format4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + checkLevel9 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel9.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + checkLevel13 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel13.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(format24);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.reportMissingOverride;
        compilerOptions0.setAppNameStr("module$STRING hi!");
        com.google.javascript.jscomp.CompilerOptions.Reach reach4 = com.google.javascript.jscomp.CompilerOptions.Reach.ALL;
        compilerOptions0.setRemoveUnusedVariables(reach4);
        compilerOptions0.setExtractPrototypeMemberDeclarations(true);
        com.google.javascript.jscomp.CompilerOptions compilerOptions8 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel9 = compilerOptions8.reportMissingOverride;
        compilerOptions8.setAppNameStr("module$STRING hi!");
        boolean boolean12 = compilerOptions8.crossModuleMethodMotion;
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean15 = node14.isFor();
        boolean boolean16 = node14.isExprResult();
        java.lang.String str17 = node14.getString();
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean20 = node19.isFor();
        boolean boolean21 = node19.isExprResult();
        com.google.javascript.rhino.Node node22 = node14.clonePropsFrom(node19);
        com.google.javascript.jscomp.CompilerOptions compilerOptions23 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel24 = compilerOptions23.reportMissingOverride;
        java.lang.String[] strArray31 = new java.lang.String[] { "STRING hi!", "hi!. hi! at (unknown source) line (unknown line) : (unknown column)", "module$STRING hi!", "hi!", "", "STRING hi!" };
        java.util.LinkedHashSet<java.lang.String> strSet32 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean33 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet32, strArray31);
        compilerOptions23.setIdGenerators((java.util.Set<java.lang.String>) strSet32);
        node14.setDirectives((java.util.Set<java.lang.String>) strSet32);
        compilerOptions8.aliasableStrings = strSet32;
        compilerOptions0.setStripTypes((java.util.Set<java.lang.String>) strSet32);
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap38 = null;
        compilerOptions0.setCssRenamingMap(cssRenamingMap38);
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + reach4 + "' != '" + com.google.javascript.jscomp.CompilerOptions.Reach.ALL + "'", reach4.equals(com.google.javascript.jscomp.CompilerOptions.Reach.ALL));
        org.junit.Assert.assertTrue("'" + checkLevel9 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel9.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "hi!" + "'", str17.equals("hi!"));
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertTrue("'" + checkLevel24 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel24.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(strArray31);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean2 = node1.isFor();
        boolean boolean3 = node1.isExprResult();
        java.lang.String str4 = node1.getString();
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean7 = node6.isFor();
        boolean boolean8 = node6.isExprResult();
        com.google.javascript.rhino.Node node9 = node1.clonePropsFrom(node6);
        boolean boolean10 = node9.isVar();
        com.google.javascript.rhino.Node node14 = new com.google.javascript.rhino.Node((int) (byte) 100, (int) (byte) 1, 54);
        boolean boolean15 = node14.isReturn();
        boolean boolean16 = node9.hasChild(node14);
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.Node.newNumber(0.0d);
        com.google.javascript.rhino.Node.AncestorIterable ancestorIterable19 = node18.getAncestors();
        boolean boolean20 = node18.isCatch();
        com.google.javascript.rhino.Node node22 = com.google.javascript.rhino.Node.newString("Unknown class name");
        try {
            com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.IR.tryCatchFinally(node9, node18, node22);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "hi!" + "'", str4.equals("hi!"));
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNotNull(ancestorIterable19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(node22);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        com.google.javascript.jscomp.SourceMap.Format format0 = com.google.javascript.jscomp.SourceMap.Format.V1;
        org.junit.Assert.assertNotNull(format0);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        java.lang.String str1 = com.google.javascript.jscomp.ProcessCommonJSModules.toModuleName("goog.global");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "module$goog.global" + "'", str1.equals("module$goog.global"));
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        java.lang.String str0 = com.google.javascript.rhino.jstype.JSType.NOT_A_TYPE;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "Not declared as a type name" + "'", str0.equals("Not declared as a type name"));
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        java.util.logging.Logger logger0 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager1 = new com.google.javascript.jscomp.LoggerErrorManager(logger0);
        double double2 = loggerErrorManager1.getTypedPercent();
        com.google.javascript.jscomp.Compiler compiler3 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager1);
        com.google.javascript.jscomp.Result result4 = compiler3.getResult();
        java.util.logging.Logger logger5 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager6 = new com.google.javascript.jscomp.LoggerErrorManager(logger5);
        double double7 = loggerErrorManager6.getTypedPercent();
        compiler3.setErrorManager((com.google.javascript.jscomp.ErrorManager) loggerErrorManager6);
        com.google.javascript.jscomp.NodeTraversal.Callback callback9 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal10 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler3, callback9);
        try {
            com.google.javascript.rhino.Node node11 = nodeTraversal10.getScopeRoot();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(result4);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        com.google.javascript.jscomp.DiagnosticGroups diagnosticGroups0 = new com.google.javascript.jscomp.DiagnosticGroups();
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean2 = node1.isFor();
        boolean boolean3 = node1.isExprResult();
        java.lang.String str4 = node1.getString();
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean7 = node6.isFor();
        boolean boolean8 = node6.isExprResult();
        com.google.javascript.rhino.Node node9 = node1.clonePropsFrom(node6);
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean12 = node11.isFor();
        boolean boolean13 = node11.isExprResult();
        java.lang.String str14 = node11.getString();
        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean17 = node16.isFor();
        boolean boolean18 = node16.isExprResult();
        com.google.javascript.rhino.Node node19 = node11.clonePropsFrom(node16);
        int int20 = node6.getIndexOfChild(node11);
        com.google.javascript.rhino.Node node22 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean23 = node22.isFor();
        boolean boolean24 = node22.isExprResult();
        java.lang.String str25 = node22.getString();
        com.google.javascript.rhino.Node node27 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean28 = node27.isFor();
        boolean boolean29 = node27.isExprResult();
        com.google.javascript.rhino.Node node30 = node22.clonePropsFrom(node27);
        com.google.javascript.rhino.Node node31 = com.google.javascript.rhino.IR.sheq(node6, node27);
        node31.setType((int) (short) 10);
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "hi!" + "'", str4.equals("hi!"));
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "hi!" + "'", str14.equals("hi!"));
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "hi!" + "'", str25.equals("hi!"));
        org.junit.Assert.assertNotNull(node27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(node30);
        org.junit.Assert.assertNotNull(node31);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.reportMissingOverride;
        compilerOptions0.setAppNameStr("module$STRING hi!");
        boolean boolean4 = compilerOptions0.foldConstants;
        compilerOptions0.setCoalesceVariableNames(false);
        boolean boolean7 = compilerOptions0.ambiguateProperties;
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        com.google.javascript.jscomp.JSModule[] jSModuleArray0 = new com.google.javascript.jscomp.JSModule[] {};
        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList1 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList1, jSModuleArray0);
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph3 = new com.google.javascript.jscomp.JSModuleGraph((java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList1);
        jSModuleGraph3.coalesceDuplicateFiles();
        com.google.javascript.jscomp.DependencyOptions dependencyOptions5 = null;
        com.google.javascript.jscomp.SourceFile sourceFile7 = com.google.javascript.jscomp.SourceFile.fromFile("hi!");
        boolean boolean8 = sourceFile7.isExtern();
        com.google.javascript.jscomp.JsAst jsAst9 = new com.google.javascript.jscomp.JsAst(sourceFile7);
        com.google.javascript.jscomp.CompilerInput compilerInput12 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) jsAst9, "// Input %num%", false);
        com.google.javascript.jscomp.SourceAst sourceAst13 = compilerInput12.getSourceAst();
        java.lang.String str14 = compilerInput12.getName();
        com.google.javascript.jscomp.SourceFile.Generator generator16 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile17 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("goog.global", generator16);
        com.google.javascript.jscomp.CompilerInput compilerInput18 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile17);
        com.google.javascript.jscomp.SourceFile sourceFile20 = com.google.javascript.jscomp.SourceFile.fromFile("hi!");
        boolean boolean21 = sourceFile20.isExtern();
        com.google.javascript.jscomp.JsAst jsAst22 = new com.google.javascript.jscomp.JsAst(sourceFile20);
        com.google.javascript.jscomp.CompilerInput compilerInput25 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) jsAst22, "// Input %num%", false);
        com.google.javascript.jscomp.SourceAst sourceAst26 = compilerInput25.getSourceAst();
        java.lang.String str27 = compilerInput25.getName();
        com.google.javascript.jscomp.SourceFile sourceFile29 = com.google.javascript.jscomp.SourceFile.fromFile("hi!");
        boolean boolean30 = sourceFile29.isExtern();
        com.google.javascript.jscomp.JsAst jsAst31 = new com.google.javascript.jscomp.JsAst(sourceFile29);
        com.google.javascript.jscomp.CompilerInput compilerInput34 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) jsAst31, "// Input %num%", false);
        com.google.javascript.jscomp.SourceAst sourceAst35 = compilerInput34.getSourceAst();
        int int36 = compilerInput34.getNumLines();
        com.google.javascript.jscomp.SourceFile.Generator generator38 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile39 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("goog.global", generator38);
        jSSourceFile39.clearCachedSource();
        com.google.javascript.jscomp.CompilerInput compilerInput41 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile39);
        com.google.javascript.jscomp.SourceFile sourceFile43 = com.google.javascript.jscomp.SourceFile.fromFile("hi!");
        boolean boolean44 = sourceFile43.isExtern();
        com.google.javascript.jscomp.JsAst jsAst45 = new com.google.javascript.jscomp.JsAst(sourceFile43);
        com.google.javascript.jscomp.CompilerInput compilerInput48 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) jsAst45, "// Input %num%", false);
        com.google.javascript.jscomp.SourceAst sourceAst49 = compilerInput48.getSourceAst();
        java.lang.String str50 = compilerInput48.getName();
        com.google.javascript.jscomp.SourceFile sourceFile52 = com.google.javascript.jscomp.SourceFile.fromFile("hi!");
        boolean boolean53 = sourceFile52.isExtern();
        com.google.javascript.jscomp.JsAst jsAst54 = new com.google.javascript.jscomp.JsAst(sourceFile52);
        com.google.javascript.jscomp.CompilerInput compilerInput57 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) jsAst54, "// Input %num%", false);
        com.google.javascript.jscomp.SourceFile sourceFile59 = com.google.javascript.jscomp.SourceFile.fromFile("hi!");
        boolean boolean60 = sourceFile59.isExtern();
        com.google.javascript.jscomp.JsAst jsAst61 = new com.google.javascript.jscomp.JsAst(sourceFile59);
        com.google.javascript.jscomp.CompilerInput compilerInput64 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) jsAst61, "// Input %num%", false);
        com.google.javascript.jscomp.CompilerInput[] compilerInputArray65 = new com.google.javascript.jscomp.CompilerInput[] { compilerInput12, compilerInput18, compilerInput25, compilerInput34, compilerInput41, compilerInput48, compilerInput57, compilerInput64 };
        java.util.ArrayList<com.google.javascript.jscomp.CompilerInput> compilerInputList66 = new java.util.ArrayList<com.google.javascript.jscomp.CompilerInput>();
        boolean boolean67 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.CompilerInput>) compilerInputList66, compilerInputArray65);
        try {
            java.util.List<com.google.javascript.jscomp.CompilerInput> compilerInputList68 = jSModuleGraph3.manageDependencies(dependencyOptions5, (java.util.List<com.google.javascript.jscomp.CompilerInput>) compilerInputList66);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Expected setErrorManager to be called first");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jSModuleArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(sourceFile7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(sourceAst13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "// Input %num%" + "'", str14.equals("// Input %num%"));
        org.junit.Assert.assertNotNull(jSSourceFile17);
        org.junit.Assert.assertNotNull(sourceFile20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(sourceAst26);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "// Input %num%" + "'", str27.equals("// Input %num%"));
        org.junit.Assert.assertNotNull(sourceFile29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(sourceAst35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
        org.junit.Assert.assertNotNull(jSSourceFile39);
        org.junit.Assert.assertNotNull(sourceFile43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(sourceAst49);
        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "// Input %num%" + "'", str50.equals("// Input %num%"));
        org.junit.Assert.assertNotNull(sourceFile52);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNotNull(sourceFile59);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertNotNull(compilerInputArray65);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + true + "'", boolean67 == true);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean3 = node2.isFor();
        boolean boolean4 = node2.isExprResult();
        java.lang.String str5 = node2.getString();
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean8 = node7.isFor();
        boolean boolean9 = node7.isExprResult();
        com.google.javascript.rhino.Node node10 = node2.clonePropsFrom(node7);
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean13 = node12.isFor();
        boolean boolean14 = node12.isExprResult();
        java.lang.String str15 = node12.getString();
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean18 = node17.isFor();
        boolean boolean19 = node17.isExprResult();
        com.google.javascript.rhino.Node node20 = node12.clonePropsFrom(node17);
        boolean boolean21 = node20.isVar();
        node20.setSourceEncodedPositionForTree(16);
        com.google.javascript.rhino.Node node24 = new com.google.javascript.rhino.Node(10, node7, node20);
        com.google.javascript.jscomp.SourceFile sourceFile26 = com.google.javascript.jscomp.SourceFile.fromFile("hi!");
        node24.setStaticSourceFile((com.google.javascript.rhino.jstype.StaticSourceFile) sourceFile26);
        com.google.javascript.rhino.Node node28 = com.google.javascript.rhino.IR.thisNode();
        node28.setOptionalArg(false);
        node24.addChildToFront(node28);
        boolean boolean32 = node24.isLabel();
        boolean boolean33 = node24.isAnd();
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "hi!" + "'", str15.equals("hi!"));
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(sourceFile26);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        com.google.javascript.jscomp.CompilerOptions.TweakProcessing tweakProcessing0 = com.google.javascript.jscomp.CompilerOptions.TweakProcessing.OFF;
        org.junit.Assert.assertTrue("'" + tweakProcessing0 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TweakProcessing.OFF + "'", tweakProcessing0.equals(com.google.javascript.jscomp.CompilerOptions.TweakProcessing.OFF));
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        com.google.javascript.jscomp.SourceFile sourceFile1 = com.google.javascript.jscomp.SourceFile.fromFile("hi!");
        boolean boolean2 = sourceFile1.isExtern();
        com.google.javascript.jscomp.JsAst jsAst3 = new com.google.javascript.jscomp.JsAst(sourceFile1);
        java.util.logging.Logger logger4 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager5 = new com.google.javascript.jscomp.LoggerErrorManager(logger4);
        double double6 = loggerErrorManager5.getTypedPercent();
        com.google.javascript.jscomp.Compiler compiler7 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager5);
        com.google.javascript.jscomp.Result result8 = compiler7.getResult();
        java.util.logging.Logger logger9 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager10 = new com.google.javascript.jscomp.LoggerErrorManager(logger9);
        double double11 = loggerErrorManager10.getTypedPercent();
        compiler7.setErrorManager((com.google.javascript.jscomp.ErrorManager) loggerErrorManager10);
        com.google.javascript.jscomp.NodeTraversal.Callback callback13 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal14 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler7, callback13);
        com.google.javascript.jscomp.Scope scope15 = compiler7.getTopScope();
        com.google.javascript.rhino.Node node16 = jsAst3.getAstRoot((com.google.javascript.jscomp.AbstractCompiler) compiler7);
        try {
            boolean boolean17 = compiler7.acceptEcmaScript5();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(sourceFile1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(result8);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNull(scope15);
        org.junit.Assert.assertNotNull(node16);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newString("hi!");
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.IR.voidNode(node1);
        java.lang.String str6 = node1.toString(true, false, false);
        com.google.javascript.rhino.Node node8 = node1.getChildAtIndex((int) (byte) -1);
        try {
            boolean boolean9 = node8.isDelProp();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "STRING hi!" + "'", str6.equals("STRING hi!"));
        org.junit.Assert.assertNull(node8);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup1 = com.google.javascript.jscomp.DiagnosticGroups.STRICT_MODULE_DEP_CHECK;
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup2 = com.google.javascript.jscomp.DiagnosticGroups.DUPLICATE_MESSAGE;
        com.google.javascript.jscomp.DiagnosticGroups.ES5_STRICT = diagnosticGroup2;
        com.google.javascript.jscomp.DiagnosticGroups.UNDEFINED_VARIABLES = diagnosticGroup2;
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup5 = com.google.javascript.jscomp.DiagnosticGroups.DUPLICATE_MESSAGE;
        com.google.javascript.jscomp.DiagnosticGroups.ES5_STRICT = diagnosticGroup5;
        com.google.javascript.jscomp.DiagnosticGroups.UNDEFINED_VARIABLES = diagnosticGroup5;
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup8 = com.google.javascript.jscomp.DiagnosticGroups.ACCESS_CONTROLS;
        com.google.javascript.jscomp.DiagnosticGroups.STRICT_MODULE_DEP_CHECK = diagnosticGroup8;
        com.google.javascript.jscomp.DiagnosticGroups.FILEOVERVIEW_JSDOC = diagnosticGroup8;
        com.google.javascript.jscomp.DiagnosticGroup[] diagnosticGroupArray11 = new com.google.javascript.jscomp.DiagnosticGroup[] { diagnosticGroup1, diagnosticGroup2, diagnosticGroup5, diagnosticGroup8 };
        try {
            com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup12 = new com.google.javascript.jscomp.DiagnosticGroup("STRING hi! [jsdoc_info: JSDocInfo]", diagnosticGroupArray11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(diagnosticGroup1);
        org.junit.Assert.assertNull(diagnosticGroup2);
        org.junit.Assert.assertNull(diagnosticGroup5);
        org.junit.Assert.assertNotNull(diagnosticGroup8);
        org.junit.Assert.assertNotNull(diagnosticGroupArray11);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        com.google.javascript.jscomp.SourceFile sourceFile1 = com.google.javascript.jscomp.SourceFile.fromFile("hi!");
        boolean boolean2 = sourceFile1.isExtern();
        com.google.javascript.jscomp.JsAst jsAst3 = new com.google.javascript.jscomp.JsAst(sourceFile1);
        com.google.javascript.jscomp.CompilerInput compilerInput6 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) jsAst3, "// Input %num%", false);
        com.google.javascript.jscomp.SourceAst sourceAst7 = compilerInput6.getSourceAst();
        int int8 = compilerInput6.getNumLines();
        try {
            java.lang.String str9 = compilerInput6.getPathRelativeToClosureBase();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: null");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(sourceFile1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(sourceAst7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        com.google.javascript.jscomp.CodingConvention codingConvention0 = com.google.javascript.jscomp.CodingConventions.getDefault();
        com.google.javascript.rhino.Node node2 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode(codingConvention0, "./");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention3 = new com.google.javascript.jscomp.ClosureCodingConvention(codingConvention0);
        com.google.javascript.rhino.Node node4 = null;
        try {
            boolean boolean5 = closureCodingConvention3.isPropertyTestFunction(node4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(codingConvention0);
        org.junit.Assert.assertNotNull(node2);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        com.google.javascript.rhino.Node.SideEffectFlags sideEffectFlags0 = new com.google.javascript.rhino.Node.SideEffectFlags();
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        java.nio.charset.Charset charset1 = null;
        com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromFile("goog.exportSymbol", charset1);
        java.lang.String str3 = sourceFile2.getName();
        org.junit.Assert.assertNotNull(sourceFile2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "goog.exportSymbol" + "'", str3.equals("goog.exportSymbol"));
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        com.google.javascript.jscomp.SourceFile.Generator generator1 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("goog.global", generator1);
        jSSourceFile2.clearCachedSource();
        com.google.javascript.jscomp.CompilerInput compilerInput4 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2);
        try {
            java.lang.String str5 = jSSourceFile2.getCode();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile2);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        com.google.javascript.jscomp.JSModule[] jSModuleArray0 = new com.google.javascript.jscomp.JSModule[] {};
        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList1 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList1, jSModuleArray0);
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph3 = new com.google.javascript.jscomp.JSModuleGraph((java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList1);
        jSModuleGraph3.coalesceDuplicateFiles();
        com.google.javascript.jscomp.JSModule jSModule5 = null;
        com.google.javascript.jscomp.JSModule jSModule6 = null;
        try {
            boolean boolean7 = jSModuleGraph3.dependsOn(jSModule5, jSModule6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jSModuleArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean4 = node3.isFor();
        boolean boolean5 = node3.isExprResult();
        java.lang.String str6 = node3.getString();
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean9 = node8.isFor();
        boolean boolean10 = node8.isExprResult();
        com.google.javascript.rhino.Node node11 = node3.clonePropsFrom(node8);
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean14 = node13.isFor();
        boolean boolean15 = node13.isExprResult();
        java.lang.String str16 = node13.getString();
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean19 = node18.isFor();
        boolean boolean20 = node18.isExprResult();
        com.google.javascript.rhino.Node node21 = node13.clonePropsFrom(node18);
        boolean boolean22 = node21.isVar();
        node21.setSourceEncodedPositionForTree(16);
        com.google.javascript.rhino.Node node25 = new com.google.javascript.rhino.Node(10, node8, node21);
        com.google.javascript.jscomp.SourceFile sourceFile27 = com.google.javascript.jscomp.SourceFile.fromFile("hi!");
        node25.setStaticSourceFile((com.google.javascript.rhino.jstype.StaticSourceFile) sourceFile27);
        com.google.javascript.rhino.Node node29 = com.google.javascript.rhino.IR.paramList();
        com.google.javascript.rhino.Node node30 = node25.srcref(node29);
        com.google.javascript.rhino.Node node34 = new com.google.javascript.rhino.Node((int) (byte) 100, (int) (byte) 1, 54);
        boolean boolean35 = node34.isReturn();
        boolean boolean36 = node30.isEquivalentToTyped(node34);
        try {
            boolean boolean37 = closureCodingConvention0.isPropertyTestFunction(node34);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "hi!" + "'", str16.equals("hi!"));
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(sourceFile27);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNotNull(node30);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.reportMissingOverride;
        compilerOptions0.setAppNameStr("module$STRING hi!");
        compilerOptions0.setOutputJsStringUsage(true);
        java.util.Set<java.lang.String> strSet6 = null;
        compilerOptions0.setStripTypes(strSet6);
        compilerOptions0.setProcessCommonJSModules(false);
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy10 = compilerOptions0.propertyRenaming;
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy10 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.OFF + "'", propertyRenamingPolicy10.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.OFF));
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        com.google.javascript.jscomp.SourceAst sourceAst0 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(sourceAst0, "hi!", false);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        com.google.javascript.jscomp.SourceFile.Builder builder0 = new com.google.javascript.jscomp.SourceFile.Builder();
        java.nio.charset.Charset charset1 = null;
        com.google.javascript.jscomp.SourceFile.Builder builder2 = builder0.withCharset(charset1);
        com.google.javascript.jscomp.SourceFile.Builder builder4 = builder0.withOriginalPath("./");
        org.junit.Assert.assertNotNull(builder2);
        org.junit.Assert.assertNotNull(builder4);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.reportMissingOverride;
        compilerOptions0.setAppNameStr("module$STRING hi!");
        boolean boolean4 = compilerOptions0.crossModuleMethodMotion;
        boolean boolean5 = compilerOptions0.computeFunctionSideEffects;
        compilerOptions0.reserveRawExports = false;
        boolean boolean8 = compilerOptions0.collapseAnonymousFunctions;
        boolean boolean9 = compilerOptions0.exportTestFunctions;
        boolean boolean10 = compilerOptions0.reserveRawExports;
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        java.lang.String str2 = com.google.javascript.jscomp.ProcessCommonJSModules.toModuleName("InputId: ", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "module$InputId: " + "'", str2.equals("module$InputId: "));
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        com.google.javascript.jscomp.DiagnosticType diagnosticType2 = com.google.javascript.jscomp.DiagnosticType.disabled("hi!", "");
        com.google.javascript.jscomp.DiagnosticType diagnosticType5 = com.google.javascript.jscomp.DiagnosticType.disabled("", "STRING hi!");
        com.google.javascript.jscomp.DiagnosticType diagnosticType8 = com.google.javascript.jscomp.DiagnosticType.disabled("hi!", "hi!");
        java.lang.String[] strArray10 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError11 = com.google.javascript.jscomp.JSError.make(diagnosticType8, strArray10);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup12 = com.google.javascript.jscomp.DiagnosticGroups.CONST;
        boolean boolean13 = jSError11.equals((java.lang.Object) diagnosticGroup12);
        com.google.javascript.jscomp.DiagnosticType diagnosticType14 = jSError11.getType();
        com.google.javascript.jscomp.DiagnosticType[] diagnosticTypeArray15 = new com.google.javascript.jscomp.DiagnosticType[] { diagnosticType2, diagnosticType5, diagnosticType14 };
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup16 = new com.google.javascript.jscomp.DiagnosticGroup(diagnosticTypeArray15);
        org.junit.Assert.assertNotNull(diagnosticType2);
        org.junit.Assert.assertNotNull(diagnosticType5);
        org.junit.Assert.assertNotNull(diagnosticType8);
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertNotNull(jSError11);
        org.junit.Assert.assertNotNull(diagnosticGroup12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(diagnosticType14);
        org.junit.Assert.assertNotNull(diagnosticTypeArray15);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        com.google.javascript.rhino.Node node3 = new com.google.javascript.rhino.Node((int) (byte) 100, (int) (byte) 1, 54);
        boolean boolean4 = node3.hasOneChild();
        boolean boolean5 = node3.isWhile();
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.Node.newString("STRING hi!");
        com.google.javascript.rhino.Node node8 = node3.srcref(node7);
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.IR.exprResult(node8);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNotNull(node9);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean2 = node1.isFor();
        boolean boolean3 = node1.isExprResult();
        java.lang.String str4 = node1.getString();
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean7 = node6.isFor();
        boolean boolean8 = node6.isExprResult();
        com.google.javascript.rhino.Node node9 = node1.clonePropsFrom(node6);
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.IR.pos(node1);
        boolean boolean11 = node1.isWhile();
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString("hi!");
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.IR.voidNode(node13);
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable15 = node14.children();
        com.google.javascript.rhino.Node node16 = node1.srcrefTree(node14);
        boolean boolean17 = node14.isVarArgs();
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "hi!" + "'", str4.equals("hi!"));
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNotNull(nodeIterable15);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean2 = node1.isFor();
        boolean boolean3 = node1.isExprResult();
        java.lang.String str4 = node1.getString();
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean7 = node6.isFor();
        boolean boolean8 = node6.isExprResult();
        com.google.javascript.rhino.Node node9 = node1.clonePropsFrom(node6);
        boolean boolean10 = node9.isVar();
        com.google.javascript.rhino.Node node14 = new com.google.javascript.rhino.Node((int) (byte) 100, (int) (byte) 1, 54);
        boolean boolean15 = node14.isReturn();
        boolean boolean16 = node9.hasChild(node14);
        node14.setSourceFileForTesting("hi!");
        try {
            node14.setSideEffectFlags((int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: setIsNoSideEffectsCall only supports CALL and NEW nodes, got OR");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "hi!" + "'", str4.equals("hi!"));
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newString("hi!");
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.IR.voidNode(node1);
        boolean boolean4 = node1.getBooleanProp(0);
        boolean boolean5 = node1.isExprResult();
        boolean boolean6 = node1.isDelProp();
        boolean boolean7 = node1.isDec();
        boolean boolean9 = node1.getBooleanProp(50);
        try {
            com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.IR.throwNode(node1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: new child has existing parent");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newString("hi!");
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.IR.voidNode(node1);
        boolean boolean4 = node1.getBooleanProp(0);
        java.lang.String str5 = com.google.javascript.jscomp.NodeUtil.getSourceName(node1);
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(str5);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.thisNode();
        node0.setOptionalArg(false);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder3 = node0.getJsDocBuilderForNode();
        boolean boolean4 = node0.isScript();
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.reportMissingOverride;
        compilerOptions0.setAppNameStr("module$STRING hi!");
        boolean boolean4 = compilerOptions0.inlineConstantVars;
        compilerOptions0.setSpecializeInitialModule(false);
        boolean boolean7 = compilerOptions0.smartNameRemoval;
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.reportMissingOverride;
        compilerOptions0.setAppNameStr("module$STRING hi!");
        boolean boolean4 = compilerOptions0.crossModuleMethodMotion;
        boolean boolean5 = compilerOptions0.computeFunctionSideEffects;
        compilerOptions0.locale = "module$STRING hi!";
        compilerOptions0.setComputeFunctionSideEffects(true);
        boolean boolean10 = compilerOptions0.ambiguateProperties;
        boolean boolean11 = compilerOptions0.exportTestFunctions;
        compilerOptions0.exportTestFunctions = true;
        boolean boolean14 = compilerOptions0.optimizeArgumentsArray;
        compilerOptions0.setInlineConstantVars(false);
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        boolean boolean1 = com.google.javascript.rhino.ScriptRuntime.isJSLineTerminator((int) ' ');
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        boolean boolean1 = com.google.javascript.jscomp.NodeUtil.isValidQualifiedName("Not declared as a type name");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.reportMissingOverride;
        compilerOptions0.setAppNameStr("module$STRING hi!");
        boolean boolean4 = compilerOptions0.inlineConstantVars;
        compilerOptions0.setSpecializeInitialModule(false);
        com.google.javascript.jscomp.CompilerOptions.LanguageMode languageMode7 = compilerOptions0.getLanguageOut();
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(languageMode7);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean2 = node1.isFor();
        boolean boolean3 = node1.isExprResult();
        java.lang.String str4 = node1.getString();
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean7 = node6.isFor();
        boolean boolean8 = node6.isExprResult();
        com.google.javascript.rhino.Node node9 = node1.clonePropsFrom(node6);
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean12 = node11.isFor();
        boolean boolean13 = node11.isExprResult();
        java.lang.String str14 = node11.getString();
        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean17 = node16.isFor();
        boolean boolean18 = node16.isExprResult();
        com.google.javascript.rhino.Node node19 = node11.clonePropsFrom(node16);
        int int20 = node6.getIndexOfChild(node11);
        com.google.javascript.rhino.Node node21 = node6.cloneTree();
        node6.setString("module$STRING hi!");
        boolean boolean24 = node6.isVarArgs();
        node6.setSourceEncodedPositionForTree((int) (byte) 0);
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "hi!" + "'", str4.equals("hi!"));
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "hi!" + "'", str14.equals("hi!"));
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        com.google.javascript.jscomp.SourceFile sourceFile1 = com.google.javascript.jscomp.SourceFile.fromFile("hi!");
        boolean boolean2 = sourceFile1.isExtern();
        com.google.javascript.jscomp.JsAst jsAst3 = new com.google.javascript.jscomp.JsAst(sourceFile1);
        com.google.javascript.jscomp.SourceFile.Generator generator5 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile6 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("goog.global", generator5);
        try {
            jsAst3.setSourceFile((com.google.javascript.jscomp.SourceFile) jSSourceFile6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(sourceFile1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(jSSourceFile6);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.reportMissingOverride;
        compilerOptions0.recordFunctionInformation = false;
        compilerOptions0.setRemoveUnusedLocalVars(true);
        compilerOptions0.setRemoveUnusedVars(false);
        compilerOptions0.setCheckCaja(true);
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.thisNode();
        node0.setOptionalArg(false);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder3 = node0.getJsDocBuilderForNode();
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean7 = node6.isFor();
        boolean boolean8 = node6.isExprResult();
        java.lang.String str9 = node6.getString();
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean12 = node11.isFor();
        boolean boolean13 = node11.isExprResult();
        com.google.javascript.rhino.Node node14 = node6.clonePropsFrom(node11);
        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean17 = node16.isFor();
        boolean boolean18 = node16.isExprResult();
        java.lang.String str19 = node16.getString();
        com.google.javascript.rhino.Node node21 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean22 = node21.isFor();
        boolean boolean23 = node21.isExprResult();
        com.google.javascript.rhino.Node node24 = node16.clonePropsFrom(node21);
        boolean boolean25 = node24.isVar();
        node24.setSourceEncodedPositionForTree(16);
        com.google.javascript.rhino.Node node28 = new com.google.javascript.rhino.Node(10, node11, node24);
        com.google.javascript.rhino.Node node29 = node28.cloneTree();
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable30 = node28.children();
        try {
            com.google.javascript.rhino.Node node31 = com.google.javascript.rhino.IR.assign(node0, node28);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder3);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "hi!" + "'", str9.equals("hi!"));
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "hi!" + "'", str19.equals("hi!"));
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNotNull(nodeIterable30);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        com.google.javascript.rhino.Node node3 = new com.google.javascript.rhino.Node((int) (byte) 100, (int) (byte) 1, 54);
        com.google.javascript.rhino.Node node4 = node3.getLastSibling();
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean7 = node6.isFor();
        boolean boolean8 = node6.isExprResult();
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean11 = node10.isFor();
        com.google.javascript.rhino.Node node12 = node6.clonePropsFrom(node10);
        boolean boolean13 = node6.isOnlyModifiesThisCall();
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean16 = node15.isFor();
        boolean boolean17 = node15.isExprResult();
        java.lang.String str18 = node15.getString();
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean21 = node20.isFor();
        boolean boolean22 = node20.isExprResult();
        com.google.javascript.rhino.Node node23 = node15.clonePropsFrom(node20);
        boolean boolean24 = node23.isVar();
        com.google.javascript.rhino.Node node25 = node6.useSourceInfoFromForTree(node23);
        com.google.javascript.rhino.jstype.JSType jSType26 = null;
        node25.setJSType(jSType26);
        com.google.javascript.rhino.Node node28 = com.google.javascript.rhino.IR.paramList();
        boolean boolean29 = node28.isThrow();
        node25.addChildToBack(node28);
        com.google.javascript.rhino.Node node32 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean33 = node32.isFor();
        boolean boolean34 = node32.isExprResult();
        com.google.javascript.rhino.Node node36 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean37 = node36.isFor();
        com.google.javascript.rhino.Node node38 = node32.clonePropsFrom(node36);
        boolean boolean39 = node32.isOnlyModifiesThisCall();
        com.google.javascript.rhino.Node node41 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean42 = node41.isFor();
        boolean boolean43 = node41.isExprResult();
        java.lang.String str44 = node41.getString();
        com.google.javascript.rhino.Node node46 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean47 = node46.isFor();
        boolean boolean48 = node46.isExprResult();
        com.google.javascript.rhino.Node node49 = node41.clonePropsFrom(node46);
        boolean boolean50 = node49.isVar();
        com.google.javascript.rhino.Node node51 = node32.useSourceInfoFromForTree(node49);
        boolean boolean52 = node51.isLabelName();
        com.google.javascript.rhino.Node node53 = node25.useSourceInfoFromForTree(node51);
        try {
            node3.removeChild(node25);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "hi!" + "'", str18.equals("hi!"));
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(node32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(node36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(node38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(node41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "hi!" + "'", str44.equals("hi!"));
        org.junit.Assert.assertNotNull(node46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(node49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(node51);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertNotNull(node53);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        java.util.logging.Logger logger0 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager1 = new com.google.javascript.jscomp.LoggerErrorManager(logger0);
        double double2 = loggerErrorManager1.getTypedPercent();
        com.google.javascript.jscomp.Compiler compiler3 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager1);
        com.google.javascript.jscomp.Result result4 = compiler3.getResult();
        java.lang.String str5 = compiler3.getAstDotGraph();
        com.google.javascript.jscomp.JSError[] jSErrorArray6 = compiler3.getWarnings();
        com.google.javascript.jscomp.JSError[] jSErrorArray7 = compiler3.getWarnings();
        com.google.javascript.jscomp.PerformanceTracker performanceTracker8 = null;
        compiler3.tracker = performanceTracker8;
        try {
            java.util.Map<com.google.javascript.rhino.InputId, com.google.javascript.jscomp.CompilerInput> inputIdMap10 = compiler3.getInputsById();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(result4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertNotNull(jSErrorArray6);
        org.junit.Assert.assertNotNull(jSErrorArray7);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CompilerOptions compilerOptions1 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel2 = compilerOptions1.reportMissingOverride;
        compilerOptions0.setAggressiveVarCheck(checkLevel2);
        com.google.javascript.jscomp.SourceMap.Format format4 = compilerOptions0.sourceMapFormat;
        boolean boolean5 = compilerOptions0.collapseVariableDeclarations;
        compilerOptions0.setAcceptConstKeyword(true);
        compilerOptions0.setAliasExternals(true);
        org.junit.Assert.assertTrue("'" + checkLevel2 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel2.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(format4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        com.google.javascript.rhino.Node node0 = null;
        try {
            com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.neg(node0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        com.google.javascript.rhino.Node node3 = new com.google.javascript.rhino.Node((int) (byte) 100, (int) (byte) 1, 54);
        com.google.javascript.rhino.Node node4 = node3.getNext();
        try {
            com.google.javascript.rhino.InputId inputId5 = node4.getInputId();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(node4);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        com.google.javascript.rhino.Node node0 = null;
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean3 = node2.isFor();
        boolean boolean4 = node2.isExprResult();
        java.lang.String str5 = node2.getString();
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean8 = node7.isFor();
        boolean boolean9 = node7.isExprResult();
        com.google.javascript.rhino.Node node10 = node2.clonePropsFrom(node7);
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean13 = node12.isFor();
        boolean boolean14 = node12.isExprResult();
        java.lang.String str15 = node12.getString();
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean18 = node17.isFor();
        boolean boolean19 = node17.isExprResult();
        com.google.javascript.rhino.Node node20 = node12.clonePropsFrom(node17);
        int int21 = node7.getIndexOfChild(node12);
        com.google.javascript.rhino.Node node22 = node7.cloneTree();
        node7.setString("module$STRING hi!");
        try {
            com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.IR.tryFinally(node0, node7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "hi!" + "'", str15.equals("hi!"));
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertNotNull(node22);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newString("hi!");
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.IR.voidNode(node1);
        boolean boolean4 = node1.getBooleanProp(0);
        boolean boolean5 = node1.isExprResult();
        boolean boolean6 = node1.isDelProp();
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString("STRING hi!");
        com.google.javascript.rhino.Node node9 = node1.useSourceInfoIfMissingFrom(node8);
        try {
            node8.setSideEffectFlags(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: setIsNoSideEffectsCall only supports CALL and NEW nodes, got STRING");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNotNull(node9);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CompilerOptions compilerOptions1 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel2 = compilerOptions1.reportMissingOverride;
        compilerOptions0.setAggressiveVarCheck(checkLevel2);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup4 = com.google.javascript.jscomp.DiagnosticGroups.ACCESS_CONTROLS;
        com.google.javascript.jscomp.CheckLevel checkLevel5 = null;
        compilerOptions0.setWarningLevel(diagnosticGroup4, checkLevel5);
        com.google.javascript.jscomp.DiagnosticGroups.INVALID_CASTS = diagnosticGroup4;
        org.junit.Assert.assertTrue("'" + checkLevel2 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel2.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(diagnosticGroup4);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup1 = com.google.javascript.jscomp.DiagnosticGroups.STRICT_MODULE_DEP_CHECK;
        com.google.javascript.jscomp.DiagnosticGroups.ACCESS_CONTROLS = diagnosticGroup1;
        try {
            java.lang.String str3 = com.google.javascript.rhino.ScriptRuntime.getMessage1("", (java.lang.Object) diagnosticGroup1);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property ");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(diagnosticGroup1);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newString("hi!");
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.IR.voidNode(node1);
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable3 = node2.children();
        boolean boolean4 = node2.hasMoreThanOneChild();
        boolean boolean5 = com.google.javascript.jscomp.NodeUtil.isSymmetricOperation(node2);
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertNotNull(nodeIterable3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean2 = node1.isFor();
        boolean boolean3 = node1.isExprResult();
        java.lang.String str4 = node1.getString();
        boolean boolean5 = node1.isGetterDef();
        int int6 = node1.getSourcePosition();
        boolean boolean7 = node1.isDec();
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "hi!" + "'", str4.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        java.util.logging.Logger logger0 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager1 = new com.google.javascript.jscomp.LoggerErrorManager(logger0);
        double double2 = loggerErrorManager1.getTypedPercent();
        loggerErrorManager1.setTypedPercent(0.0d);
        int int5 = loggerErrorManager1.getWarningCount();
        int int6 = loggerErrorManager1.getErrorCount();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        com.google.javascript.rhino.Node node0 = null;
        try {
            boolean boolean1 = com.google.javascript.jscomp.NodeUtil.isRelationalOperation(node0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.reportMissingOverride;
        compilerOptions0.setAppNameStr("module$STRING hi!");
        compilerOptions0.setOutputJsStringUsage(true);
        compilerOptions0.ideMode = true;
        compilerOptions0.reserveRawExports = true;
        compilerOptions0.setInlineLocalVariables(false);
        compilerOptions0.setInlineFunctions(false);
        java.lang.String[] strArray17 = new java.lang.String[] { "Not declared as a type name", "Unknown class name", "./" };
        java.util.ArrayList<java.lang.String> strList18 = new java.util.ArrayList<java.lang.String>();
        boolean boolean19 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strList18, strArray17);
        compilerOptions0.setManageClosureDependencies((java.util.List<java.lang.String>) strList18);
        boolean boolean21 = compilerOptions0.aliasKeywords;
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(strArray17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.reportMissingOverride;
        compilerOptions0.setAppNameStr("module$STRING hi!");
        boolean boolean4 = compilerOptions0.crossModuleMethodMotion;
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean7 = node6.isFor();
        boolean boolean8 = node6.isExprResult();
        java.lang.String str9 = node6.getString();
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean12 = node11.isFor();
        boolean boolean13 = node11.isExprResult();
        com.google.javascript.rhino.Node node14 = node6.clonePropsFrom(node11);
        com.google.javascript.jscomp.CompilerOptions compilerOptions15 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel16 = compilerOptions15.reportMissingOverride;
        java.lang.String[] strArray23 = new java.lang.String[] { "STRING hi!", "hi!. hi! at (unknown source) line (unknown line) : (unknown column)", "module$STRING hi!", "hi!", "", "STRING hi!" };
        java.util.LinkedHashSet<java.lang.String> strSet24 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean25 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet24, strArray23);
        compilerOptions15.setIdGenerators((java.util.Set<java.lang.String>) strSet24);
        node6.setDirectives((java.util.Set<java.lang.String>) strSet24);
        compilerOptions0.aliasableStrings = strSet24;
        boolean boolean29 = compilerOptions0.aliasKeywords;
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy30 = com.google.javascript.jscomp.PropertyRenamingPolicy.UNSPECIFIED;
        compilerOptions0.setPropertyRenaming(propertyRenamingPolicy30);
        com.google.javascript.jscomp.CompilerOptions.TracerMode tracerMode32 = null;
        compilerOptions0.setTracerMode(tracerMode32);
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "hi!" + "'", str9.equals("hi!"));
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertTrue("'" + checkLevel16 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel16.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(strArray23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy30 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.UNSPECIFIED + "'", propertyRenamingPolicy30.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.UNSPECIFIED));
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.reportMissingOverride;
        compilerOptions0.setAppNameStr("module$STRING hi!");
        boolean boolean4 = compilerOptions0.extractPrototypeMemberDeclarations;
        compilerOptions0.removeUnusedPrototypeProperties = false;
        java.lang.String str7 = compilerOptions0.instrumentationTemplate;
        com.google.javascript.jscomp.CompilerOptions.AliasTransformationHandler aliasTransformationHandler8 = compilerOptions0.getAliasTransformationHandler();
        compilerOptions0.setSyntheticBlockStartMarker("STRING hi! [jsdoc_info: JSDocInfo]");
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertNotNull(aliasTransformationHandler8);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newString("hi!");
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.IR.voidNode(node1);
        boolean boolean4 = node1.getBooleanProp(0);
        boolean boolean5 = node1.isExprResult();
        boolean boolean6 = node1.isDelProp();
        boolean boolean7 = node1.isDec();
        boolean boolean9 = node1.getBooleanProp(50);
        com.google.javascript.jscomp.CompilerOptions compilerOptions10 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel11 = compilerOptions10.reportMissingOverride;
        compilerOptions10.setAppNameStr("module$STRING hi!");
        boolean boolean14 = compilerOptions10.crossModuleMethodMotion;
        boolean boolean15 = compilerOptions10.computeFunctionSideEffects;
        compilerOptions10.locale = "module$STRING hi!";
        compilerOptions10.setComputeFunctionSideEffects(true);
        compilerOptions10.setAliasableGlobals("hi!");
        com.google.javascript.jscomp.CompilerOptions compilerOptions22 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel23 = compilerOptions22.reportMissingOverride;
        compilerOptions10.checkUnreachableCode = checkLevel23;
        com.google.javascript.jscomp.CompilerOptions compilerOptions25 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel26 = compilerOptions25.reportMissingOverride;
        compilerOptions25.setAppNameStr("module$STRING hi!");
        boolean boolean29 = compilerOptions25.crossModuleMethodMotion;
        boolean boolean30 = compilerOptions25.computeFunctionSideEffects;
        compilerOptions25.locale = "module$STRING hi!";
        compilerOptions25.setComputeFunctionSideEffects(true);
        compilerOptions25.setAliasableGlobals("hi!");
        com.google.javascript.jscomp.CompilerOptions compilerOptions37 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel38 = compilerOptions37.reportMissingOverride;
        compilerOptions25.checkUnreachableCode = checkLevel38;
        compilerOptions10.checkMissingGetCssNameLevel = checkLevel38;
        java.util.Set<java.lang.String> strSet41 = compilerOptions10.stripTypes;
        node1.setDirectives(strSet41);
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + checkLevel11 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel11.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + checkLevel23 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel23.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + checkLevel26 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel26.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + checkLevel38 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel38.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(strSet41);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean2 = node1.isFor();
        boolean boolean3 = node1.isExprResult();
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean6 = node5.isFor();
        com.google.javascript.rhino.Node node7 = node1.clonePropsFrom(node5);
        try {
            node1.setSideEffectFlags(16);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: setIsNoSideEffectsCall only supports CALL and NEW nodes, got STRING");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(node7);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        com.google.javascript.jscomp.SourceFile sourceFile1 = com.google.javascript.jscomp.SourceFile.fromFile("hi!");
        boolean boolean2 = sourceFile1.isExtern();
        com.google.javascript.jscomp.JsAst jsAst3 = new com.google.javascript.jscomp.JsAst(sourceFile1);
        com.google.javascript.jscomp.CompilerInput compilerInput6 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) jsAst3, "// Input %num%", false);
        com.google.javascript.jscomp.SourceAst sourceAst7 = compilerInput6.getSourceAst();
        com.google.javascript.jscomp.CompilerInput compilerInput10 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput6, "", false);
        compilerInput10.clearAst();
        org.junit.Assert.assertNotNull(sourceFile1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(sourceAst7);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        java.lang.String str0 = com.google.javascript.rhino.jstype.JSType.EMPTY_TYPE_COMPONENT;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "Named type with empty name component" + "'", str0.equals("Named type with empty name component"));
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.reportMissingOverride;
        compilerOptions0.setAppNameStr("module$STRING hi!");
        boolean boolean4 = compilerOptions0.crossModuleMethodMotion;
        boolean boolean5 = compilerOptions0.computeFunctionSideEffects;
        compilerOptions0.locale = "module$STRING hi!";
        compilerOptions0.rewriteFunctionExpressions = true;
        com.google.javascript.jscomp.CompilerOptions.TracerMode tracerMode10 = null;
        compilerOptions0.setTracerMode(tracerMode10);
        boolean boolean12 = compilerOptions0.labelRenaming;
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.reportMissingOverride;
        compilerOptions0.setAppNameStr("module$STRING hi!");
        compilerOptions0.setOutputJsStringUsage(true);
        java.util.Set<java.lang.String> strSet6 = null;
        compilerOptions0.setStripTypes(strSet6);
        com.google.javascript.jscomp.CompilerOptions compilerOptions8 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel9 = compilerOptions8.reportMissingOverride;
        compilerOptions8.setAppNameStr("module$STRING hi!");
        boolean boolean12 = compilerOptions8.crossModuleMethodMotion;
        boolean boolean13 = compilerOptions8.computeFunctionSideEffects;
        compilerOptions8.locale = "module$STRING hi!";
        compilerOptions8.setComputeFunctionSideEffects(true);
        compilerOptions8.setAliasableGlobals("hi!");
        com.google.javascript.jscomp.CompilerOptions compilerOptions20 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel21 = compilerOptions20.reportMissingOverride;
        compilerOptions8.checkUnreachableCode = checkLevel21;
        compilerOptions0.setCheckProvides(checkLevel21);
        boolean boolean24 = compilerOptions0.disambiguateProperties;
        compilerOptions0.setManageClosureDependencies(false);
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + checkLevel9 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel9.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + checkLevel21 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel21.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        com.google.javascript.jscomp.parsing.Config.LanguageMode languageMode1 = com.google.javascript.jscomp.parsing.Config.LanguageMode.ECMASCRIPT3;
        com.google.javascript.jscomp.parsing.Config config3 = com.google.javascript.jscomp.parsing.ParserRunner.createConfig(false, languageMode1, true);
        org.junit.Assert.assertTrue("'" + languageMode1 + "' != '" + com.google.javascript.jscomp.parsing.Config.LanguageMode.ECMASCRIPT3 + "'", languageMode1.equals(com.google.javascript.jscomp.parsing.Config.LanguageMode.ECMASCRIPT3));
        org.junit.Assert.assertNotNull(config3);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        com.google.javascript.jscomp.SourceFile sourceFile1 = com.google.javascript.jscomp.SourceFile.fromFile("hi!");
        boolean boolean2 = sourceFile1.isExtern();
        com.google.javascript.jscomp.JsAst jsAst3 = new com.google.javascript.jscomp.JsAst(sourceFile1);
        com.google.javascript.jscomp.CompilerInput compilerInput6 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) jsAst3, "// Input %num%", false);
        com.google.javascript.jscomp.SourceAst sourceAst7 = compilerInput6.getSourceAst();
        com.google.javascript.rhino.InputId inputId9 = new com.google.javascript.rhino.InputId("");
        com.google.javascript.jscomp.CompilerInput compilerInput11 = new com.google.javascript.jscomp.CompilerInput(sourceAst7, inputId9, true);
        com.google.javascript.rhino.InputId inputId12 = compilerInput11.getInputId();
        org.junit.Assert.assertNotNull(sourceFile1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(sourceAst7);
        org.junit.Assert.assertNotNull(inputId12);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean2 = node1.isFor();
        boolean boolean3 = node1.isExprResult();
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean6 = node5.isFor();
        com.google.javascript.rhino.Node node7 = node1.clonePropsFrom(node5);
        boolean boolean8 = node1.isOnlyModifiesThisCall();
        boolean boolean9 = node1.isAdd();
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean12 = node11.isFor();
        boolean boolean13 = node11.isExprResult();
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean16 = node15.isFor();
        com.google.javascript.rhino.Node node17 = node11.clonePropsFrom(node15);
        boolean boolean18 = node11.isOnlyModifiesThisCall();
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean21 = node20.isFor();
        boolean boolean22 = node20.isExprResult();
        java.lang.String str23 = node20.getString();
        com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean26 = node25.isFor();
        boolean boolean27 = node25.isExprResult();
        com.google.javascript.rhino.Node node28 = node20.clonePropsFrom(node25);
        boolean boolean29 = node28.isVar();
        com.google.javascript.rhino.Node node30 = node11.useSourceInfoFromForTree(node28);
        com.google.javascript.rhino.jstype.JSType jSType31 = null;
        node30.setJSType(jSType31);
        com.google.javascript.rhino.Node node33 = com.google.javascript.rhino.IR.paramList();
        boolean boolean34 = node33.isThrow();
        node30.addChildToBack(node33);
        com.google.javascript.rhino.Node node36 = com.google.javascript.rhino.IR.add(node1, node30);
        boolean boolean37 = node1.hasMoreThanOneChild();
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "hi!" + "'", str23.equals("hi!"));
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(node30);
        org.junit.Assert.assertNotNull(node33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(node36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean2 = node1.isFor();
        boolean boolean3 = node1.isExprResult();
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean6 = node5.isFor();
        com.google.javascript.rhino.Node node7 = node1.clonePropsFrom(node5);
        boolean boolean8 = node1.isOnlyModifiesThisCall();
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean11 = node10.isFor();
        boolean boolean12 = node10.isExprResult();
        java.lang.String str13 = node10.getString();
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean16 = node15.isFor();
        boolean boolean17 = node15.isExprResult();
        com.google.javascript.rhino.Node node18 = node10.clonePropsFrom(node15);
        boolean boolean19 = node18.isVar();
        com.google.javascript.rhino.Node node20 = node1.useSourceInfoFromForTree(node18);
        com.google.javascript.rhino.jstype.JSType jSType21 = null;
        node20.setJSType(jSType21);
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.IR.paramList();
        boolean boolean24 = node23.isThrow();
        node20.addChildToBack(node23);
        try {
            double double26 = node20.getDouble();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: STRING hi! is not a number node");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "hi!" + "'", str13.equals("hi!"));
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean2 = node1.isFor();
        boolean boolean3 = node1.isExprResult();
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean6 = node5.isFor();
        com.google.javascript.rhino.Node node7 = node1.clonePropsFrom(node5);
        boolean boolean8 = node1.isOnlyModifiesThisCall();
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean11 = node10.isFor();
        boolean boolean12 = node10.isExprResult();
        java.lang.String str13 = node10.getString();
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean16 = node15.isFor();
        boolean boolean17 = node15.isExprResult();
        com.google.javascript.rhino.Node node18 = node10.clonePropsFrom(node15);
        boolean boolean19 = node18.isVar();
        com.google.javascript.rhino.Node node20 = node1.useSourceInfoFromForTree(node18);
        boolean boolean21 = node1.isTypeOf();
        com.google.javascript.rhino.jstype.JSType jSType22 = null;
        node1.setJSType(jSType22);
        com.google.javascript.rhino.Node node24 = com.google.javascript.rhino.IR.thisNode();
        node24.setOptionalArg(false);
        com.google.javascript.rhino.Node node28 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean29 = node28.isFor();
        boolean boolean30 = node28.isExprResult();
        java.lang.String str31 = node28.getString();
        com.google.javascript.rhino.Node node33 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean34 = node33.isFor();
        boolean boolean35 = node33.isExprResult();
        com.google.javascript.rhino.Node node36 = node28.clonePropsFrom(node33);
        com.google.javascript.rhino.Node node38 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean39 = node38.isFor();
        boolean boolean40 = node38.isExprResult();
        java.lang.String str41 = node38.getString();
        com.google.javascript.rhino.Node node43 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean44 = node43.isFor();
        boolean boolean45 = node43.isExprResult();
        com.google.javascript.rhino.Node node46 = node38.clonePropsFrom(node43);
        int int47 = node33.getIndexOfChild(node38);
        com.google.javascript.rhino.Node node48 = node33.cloneTree();
        node33.setString("module$STRING hi!");
        try {
            com.google.javascript.rhino.Node node51 = com.google.javascript.rhino.IR.tryCatchFinally(node1, node24, node33);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "hi!" + "'", str13.equals("hi!"));
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "hi!" + "'", str31.equals("hi!"));
        org.junit.Assert.assertNotNull(node33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(node36);
        org.junit.Assert.assertNotNull(node38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "hi!" + "'", str41.equals("hi!"));
        org.junit.Assert.assertNotNull(node43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(node46);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + (-1) + "'", int47 == (-1));
        org.junit.Assert.assertNotNull(node48);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy0 = com.google.javascript.jscomp.VariableRenamingPolicy.ALL;
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy0 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.ALL + "'", variableRenamingPolicy0.equals(com.google.javascript.jscomp.VariableRenamingPolicy.ALL));
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean3 = node2.isFor();
        boolean boolean4 = node2.isExprResult();
        java.lang.String str5 = node2.getString();
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean8 = node7.isFor();
        boolean boolean9 = node7.isExprResult();
        com.google.javascript.rhino.Node node10 = node2.clonePropsFrom(node7);
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean13 = node12.isFor();
        boolean boolean14 = node12.isExprResult();
        java.lang.String str15 = node12.getString();
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean18 = node17.isFor();
        boolean boolean19 = node17.isExprResult();
        com.google.javascript.rhino.Node node20 = node12.clonePropsFrom(node17);
        boolean boolean21 = node20.isVar();
        node20.setSourceEncodedPositionForTree(16);
        com.google.javascript.rhino.Node node24 = new com.google.javascript.rhino.Node(10, node7, node20);
        com.google.javascript.jscomp.SourceFile sourceFile26 = com.google.javascript.jscomp.SourceFile.fromFile("hi!");
        node24.setStaticSourceFile((com.google.javascript.rhino.jstype.StaticSourceFile) sourceFile26);
        com.google.javascript.rhino.Node node28 = com.google.javascript.rhino.IR.paramList();
        com.google.javascript.rhino.Node node29 = node24.srcref(node28);
        com.google.javascript.rhino.Node node30 = node29.cloneNode();
        com.google.javascript.rhino.Node node31 = com.google.javascript.rhino.IR.pos(node30);
        boolean boolean32 = node30.isIn();
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "hi!" + "'", str15.equals("hi!"));
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(sourceFile26);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNotNull(node30);
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean2 = node1.isFor();
        boolean boolean3 = node1.isExprResult();
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean6 = node5.isFor();
        com.google.javascript.rhino.Node node7 = node1.clonePropsFrom(node5);
        node5.addSuppression("module$STRING hi!");
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean12 = node11.isFor();
        boolean boolean13 = node11.isExprResult();
        java.lang.String str14 = node11.getString();
        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean17 = node16.isFor();
        boolean boolean18 = node16.isExprResult();
        com.google.javascript.rhino.Node node19 = node11.clonePropsFrom(node16);
        com.google.javascript.rhino.Node node21 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean22 = node21.isFor();
        boolean boolean23 = node21.isExprResult();
        java.lang.String str24 = node21.getString();
        com.google.javascript.rhino.Node node26 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean27 = node26.isFor();
        boolean boolean28 = node26.isExprResult();
        com.google.javascript.rhino.Node node29 = node21.clonePropsFrom(node26);
        int int30 = node16.getIndexOfChild(node21);
        com.google.javascript.rhino.Node node31 = node16.cloneTree();
        com.google.javascript.rhino.Node node32 = com.google.javascript.rhino.IR.comma(node5, node31);
        boolean boolean33 = node5.isTypeOf();
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "hi!" + "'", str14.equals("hi!"));
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "hi!" + "'", str24.equals("hi!"));
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertNotNull(node32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newString("hi!");
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.IR.voidNode(node1);
        boolean boolean3 = node2.isBreak();
        boolean boolean4 = node2.isNumber();
        int int5 = node2.getSourcePosition();
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean8 = node7.isFor();
        boolean boolean9 = node7.isExprResult();
        java.lang.String str10 = node7.getString();
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean13 = node12.isFor();
        boolean boolean14 = node12.isExprResult();
        com.google.javascript.rhino.Node node15 = node7.clonePropsFrom(node12);
        boolean boolean16 = node15.isVar();
        com.google.javascript.rhino.Node node20 = new com.google.javascript.rhino.Node((int) (byte) 100, (int) (byte) 1, 54);
        boolean boolean21 = node20.isReturn();
        boolean boolean22 = node15.hasChild(node20);
        com.google.javascript.jscomp.CodingConvention codingConvention23 = com.google.javascript.jscomp.CodingConventions.getDefault();
        com.google.javascript.rhino.Node node25 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode(codingConvention23, "./");
        com.google.javascript.rhino.Node node26 = com.google.javascript.rhino.IR.throwNode(node25);
        node26.setSourceEncodedPosition(38);
        int int29 = node20.getIndexOfChild(node26);
        try {
            com.google.javascript.rhino.Node node30 = com.google.javascript.rhino.IR.tryFinally(node2, node20);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "hi!" + "'", str10.equals("hi!"));
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(codingConvention23);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        com.google.javascript.jscomp.SourceFile sourceFile1 = com.google.javascript.jscomp.SourceFile.fromFile("hi!");
        boolean boolean2 = sourceFile1.isExtern();
        com.google.javascript.jscomp.JsAst jsAst3 = new com.google.javascript.jscomp.JsAst(sourceFile1);
        java.util.logging.Logger logger4 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager5 = new com.google.javascript.jscomp.LoggerErrorManager(logger4);
        double double6 = loggerErrorManager5.getTypedPercent();
        com.google.javascript.jscomp.Compiler compiler7 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager5);
        com.google.javascript.jscomp.Result result8 = compiler7.getResult();
        java.util.logging.Logger logger9 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager10 = new com.google.javascript.jscomp.LoggerErrorManager(logger9);
        double double11 = loggerErrorManager10.getTypedPercent();
        compiler7.setErrorManager((com.google.javascript.jscomp.ErrorManager) loggerErrorManager10);
        com.google.javascript.jscomp.NodeTraversal.Callback callback13 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal14 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler7, callback13);
        com.google.javascript.jscomp.Scope scope15 = compiler7.getTopScope();
        com.google.javascript.rhino.Node node16 = jsAst3.getAstRoot((com.google.javascript.jscomp.AbstractCompiler) compiler7);
        java.lang.String str19 = compiler7.getSourceLine("// Input %num%", (-1));
        com.google.javascript.jscomp.SourceFile.Generator generator21 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile22 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("goog.global", generator21);
        jSSourceFile22.clearCachedSource();
        java.nio.charset.Charset charset25 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile26 = com.google.javascript.jscomp.JSSourceFile.fromFile("hi!. hi! at (unknown source) line (unknown line) : (unknown column)", charset25);
        java.lang.Class<?> wildcardClass27 = jSSourceFile26.getClass();
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray28 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile22, jSSourceFile26 };
        com.google.javascript.jscomp.JSModule[] jSModuleArray29 = new com.google.javascript.jscomp.JSModule[] {};
        com.google.javascript.jscomp.CompilerOptions compilerOptions30 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel31 = compilerOptions30.reportMissingOverride;
        com.google.javascript.jscomp.CompilerOptions.LanguageMode languageMode32 = com.google.javascript.jscomp.CompilerOptions.LanguageMode.ECMASCRIPT5;
        compilerOptions30.setLanguageIn(languageMode32);
        compiler7.init(jSSourceFileArray28, jSModuleArray29, compilerOptions30);
        try {
            java.lang.String str37 = compiler7.getSourceLine("goog.global", (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(sourceFile1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(result8);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNull(scope15);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertNull(str19);
        org.junit.Assert.assertNotNull(jSSourceFile22);
        org.junit.Assert.assertNotNull(jSSourceFile26);
        org.junit.Assert.assertNotNull(wildcardClass27);
        org.junit.Assert.assertNotNull(jSSourceFileArray28);
        org.junit.Assert.assertNotNull(jSModuleArray29);
        org.junit.Assert.assertTrue("'" + checkLevel31 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel31.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + languageMode32 + "' != '" + com.google.javascript.jscomp.CompilerOptions.LanguageMode.ECMASCRIPT5 + "'", languageMode32.equals(com.google.javascript.jscomp.CompilerOptions.LanguageMode.ECMASCRIPT5));
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean2 = node1.isFor();
        boolean boolean3 = node1.isExprResult();
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean6 = node5.isFor();
        com.google.javascript.rhino.Node node7 = node1.clonePropsFrom(node5);
        node5.addSuppression("module$STRING hi!");
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean12 = node11.isFor();
        boolean boolean13 = node11.isExprResult();
        java.lang.String str14 = node11.getString();
        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean17 = node16.isFor();
        boolean boolean18 = node16.isExprResult();
        com.google.javascript.rhino.Node node19 = node11.clonePropsFrom(node16);
        com.google.javascript.rhino.Node node21 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean22 = node21.isFor();
        boolean boolean23 = node21.isExprResult();
        java.lang.String str24 = node21.getString();
        com.google.javascript.rhino.Node node26 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean27 = node26.isFor();
        boolean boolean28 = node26.isExprResult();
        com.google.javascript.rhino.Node node29 = node21.clonePropsFrom(node26);
        int int30 = node16.getIndexOfChild(node21);
        com.google.javascript.rhino.Node node31 = node16.cloneTree();
        com.google.javascript.rhino.Node node32 = com.google.javascript.rhino.IR.comma(node5, node31);
        com.google.javascript.rhino.Node node33 = node32.removeFirstChild();
        boolean boolean34 = node32.isObjectLit();
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "hi!" + "'", str14.equals("hi!"));
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "hi!" + "'", str24.equals("hi!"));
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertNotNull(node32);
        org.junit.Assert.assertNotNull(node33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean3 = node2.isFor();
        boolean boolean4 = node2.isExprResult();
        java.lang.String str5 = node2.getString();
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean8 = node7.isFor();
        boolean boolean9 = node7.isExprResult();
        com.google.javascript.rhino.Node node10 = node2.clonePropsFrom(node7);
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean13 = node12.isFor();
        boolean boolean14 = node12.isExprResult();
        java.lang.String str15 = node12.getString();
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean18 = node17.isFor();
        boolean boolean19 = node17.isExprResult();
        com.google.javascript.rhino.Node node20 = node12.clonePropsFrom(node17);
        boolean boolean21 = node20.isVar();
        node20.setSourceEncodedPositionForTree(16);
        com.google.javascript.rhino.Node node24 = new com.google.javascript.rhino.Node(10, node7, node20);
        com.google.javascript.jscomp.SourceFile sourceFile26 = com.google.javascript.jscomp.SourceFile.fromFile("hi!");
        node24.setStaticSourceFile((com.google.javascript.rhino.jstype.StaticSourceFile) sourceFile26);
        com.google.javascript.rhino.Node node28 = com.google.javascript.rhino.IR.paramList();
        com.google.javascript.rhino.Node node29 = node24.srcref(node28);
        com.google.javascript.rhino.Node node30 = node29.cloneNode();
        com.google.javascript.rhino.Node node31 = com.google.javascript.rhino.IR.pos(node30);
        com.google.javascript.rhino.Node node33 = node30.getChildAtIndex(0);
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "hi!" + "'", str15.equals("hi!"));
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(sourceFile26);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNotNull(node30);
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertNull(node33);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        com.google.javascript.jscomp.SourceFile sourceFile1 = com.google.javascript.jscomp.SourceFile.fromFile("hi!");
        boolean boolean2 = sourceFile1.isExtern();
        com.google.javascript.jscomp.JsAst jsAst3 = new com.google.javascript.jscomp.JsAst(sourceFile1);
        com.google.javascript.jscomp.CompilerInput compilerInput6 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) jsAst3, "// Input %num%", false);
        com.google.javascript.jscomp.SourceAst sourceAst7 = compilerInput6.getSourceAst();
        com.google.javascript.jscomp.CompilerInput compilerInput10 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput6, "", false);
        java.lang.String str11 = compilerInput10.getName();
        boolean boolean12 = compilerInput10.isExtern();
        org.junit.Assert.assertNotNull(sourceFile1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(sourceAst7);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newString("hi!");
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.IR.voidNode(node1);
        java.lang.String str6 = node1.toString(true, false, false);
        com.google.javascript.rhino.Node node8 = node1.getChildAtIndex((int) (byte) -1);
        try {
            int int10 = node8.getExistingIntProp(0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "STRING hi!" + "'", str6.equals("STRING hi!"));
        org.junit.Assert.assertNull(node8);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        com.google.javascript.jscomp.SourceFile sourceFile1 = com.google.javascript.jscomp.SourceFile.fromFile("JSC_OPTIMIZE_LOOP_ERROR");
        org.junit.Assert.assertNotNull(sourceFile1);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean2 = node1.isFor();
        boolean boolean3 = node1.isExprResult();
        java.lang.String str4 = node1.getString();
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean7 = node6.isFor();
        boolean boolean8 = node6.isExprResult();
        com.google.javascript.rhino.Node node9 = node1.clonePropsFrom(node6);
        boolean boolean10 = node9.isVar();
        com.google.javascript.rhino.Node node14 = new com.google.javascript.rhino.Node((int) (byte) 100, (int) (byte) 1, 54);
        boolean boolean15 = node14.isReturn();
        boolean boolean16 = node9.hasChild(node14);
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean19 = node18.isFor();
        boolean boolean20 = node18.isExprResult();
        java.lang.String str21 = node18.getString();
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean24 = node23.isFor();
        boolean boolean25 = node23.isExprResult();
        com.google.javascript.rhino.Node node26 = node18.clonePropsFrom(node23);
        com.google.javascript.rhino.Node node28 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean29 = node28.isFor();
        boolean boolean30 = node28.isExprResult();
        java.lang.String str31 = node28.getString();
        com.google.javascript.rhino.Node node33 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean34 = node33.isFor();
        boolean boolean35 = node33.isExprResult();
        com.google.javascript.rhino.Node node36 = node28.clonePropsFrom(node33);
        int int37 = node23.getIndexOfChild(node28);
        com.google.javascript.rhino.Node node39 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean40 = node39.isFor();
        boolean boolean41 = node39.isExprResult();
        java.lang.String str42 = node39.getString();
        com.google.javascript.rhino.Node node44 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean45 = node44.isFor();
        boolean boolean46 = node44.isExprResult();
        com.google.javascript.rhino.Node node47 = node39.clonePropsFrom(node44);
        com.google.javascript.rhino.Node node48 = com.google.javascript.rhino.IR.sheq(node23, node44);
        com.google.javascript.rhino.Node node50 = node23.getChildAtIndex(0);
        com.google.javascript.rhino.Node node53 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean54 = node53.isFor();
        boolean boolean55 = node53.isExprResult();
        java.lang.String str56 = node53.getString();
        com.google.javascript.rhino.Node node58 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean59 = node58.isFor();
        boolean boolean60 = node58.isExprResult();
        com.google.javascript.rhino.Node node61 = node53.clonePropsFrom(node58);
        com.google.javascript.rhino.Node node63 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean64 = node63.isFor();
        boolean boolean65 = node63.isExprResult();
        java.lang.String str66 = node63.getString();
        com.google.javascript.rhino.Node node68 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean69 = node68.isFor();
        boolean boolean70 = node68.isExprResult();
        com.google.javascript.rhino.Node node71 = node63.clonePropsFrom(node68);
        boolean boolean72 = node71.isVar();
        node71.setSourceEncodedPositionForTree(16);
        com.google.javascript.rhino.Node node75 = new com.google.javascript.rhino.Node(10, node58, node71);
        com.google.javascript.jscomp.SourceFile sourceFile77 = com.google.javascript.jscomp.SourceFile.fromFile("hi!");
        node75.setStaticSourceFile((com.google.javascript.rhino.jstype.StaticSourceFile) sourceFile77);
        com.google.javascript.rhino.Node node79 = com.google.javascript.rhino.IR.paramList();
        com.google.javascript.rhino.Node node80 = node75.srcref(node79);
        com.google.javascript.rhino.Node node81 = node80.cloneNode();
        com.google.javascript.rhino.Node node83 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean84 = node83.isFor();
        boolean boolean85 = node83.isExprResult();
        com.google.javascript.rhino.Node node87 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean88 = node87.isFor();
        com.google.javascript.rhino.Node node89 = node83.clonePropsFrom(node87);
        node87.addSuppression("module$STRING hi!");
        java.lang.String str95 = node87.toString(true, true, false);
        com.google.javascript.rhino.Node node96 = com.google.javascript.rhino.IR.or(node81, node87);
        try {
            node9.replaceChildAfter(node23, node96);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: prev is not a child of this node.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "hi!" + "'", str4.equals("hi!"));
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "hi!" + "'", str21.equals("hi!"));
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "hi!" + "'", str31.equals("hi!"));
        org.junit.Assert.assertNotNull(node33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(node36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + (-1) + "'", int37 == (-1));
        org.junit.Assert.assertNotNull(node39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "hi!" + "'", str42.equals("hi!"));
        org.junit.Assert.assertNotNull(node44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(node47);
        org.junit.Assert.assertNotNull(node48);
        org.junit.Assert.assertNull(node50);
        org.junit.Assert.assertNotNull(node53);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertTrue("'" + str56 + "' != '" + "hi!" + "'", str56.equals("hi!"));
        org.junit.Assert.assertNotNull(node58);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertNotNull(node61);
        org.junit.Assert.assertNotNull(node63);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertTrue("'" + str66 + "' != '" + "hi!" + "'", str66.equals("hi!"));
        org.junit.Assert.assertNotNull(node68);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertNotNull(node71);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
        org.junit.Assert.assertNotNull(sourceFile77);
        org.junit.Assert.assertNotNull(node79);
        org.junit.Assert.assertNotNull(node80);
        org.junit.Assert.assertNotNull(node81);
        org.junit.Assert.assertNotNull(node83);
        org.junit.Assert.assertTrue("'" + boolean84 + "' != '" + false + "'", boolean84 == false);
        org.junit.Assert.assertTrue("'" + boolean85 + "' != '" + false + "'", boolean85 == false);
        org.junit.Assert.assertNotNull(node87);
        org.junit.Assert.assertTrue("'" + boolean88 + "' != '" + false + "'", boolean88 == false);
        org.junit.Assert.assertNotNull(node89);
        org.junit.Assert.assertTrue("'" + str95 + "' != '" + "STRING hi! [jsdoc_info: JSDocInfo]" + "'", str95.equals("STRING hi! [jsdoc_info: JSDocInfo]"));
        org.junit.Assert.assertNotNull(node96);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean2 = node1.isFor();
        boolean boolean3 = node1.isExprResult();
        java.lang.String str4 = node1.getString();
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean7 = node6.isFor();
        boolean boolean8 = node6.isExprResult();
        com.google.javascript.rhino.Node node9 = node1.clonePropsFrom(node6);
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean12 = node11.isFor();
        boolean boolean13 = node11.isExprResult();
        java.lang.String str14 = node11.getString();
        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean17 = node16.isFor();
        boolean boolean18 = node16.isExprResult();
        com.google.javascript.rhino.Node node19 = node11.clonePropsFrom(node16);
        int int20 = node6.getIndexOfChild(node11);
        com.google.javascript.rhino.Node node22 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean23 = node22.isFor();
        boolean boolean24 = node22.isExprResult();
        java.lang.String str25 = node22.getString();
        com.google.javascript.rhino.Node node27 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean28 = node27.isFor();
        boolean boolean29 = node27.isExprResult();
        com.google.javascript.rhino.Node node30 = node22.clonePropsFrom(node27);
        com.google.javascript.rhino.Node node31 = com.google.javascript.rhino.IR.sheq(node6, node27);
        boolean boolean32 = node27.isComma();
        com.google.javascript.rhino.Node node33 = node27.cloneNode();
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "hi!" + "'", str4.equals("hi!"));
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "hi!" + "'", str14.equals("hi!"));
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "hi!" + "'", str25.equals("hi!"));
        org.junit.Assert.assertNotNull(node27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(node30);
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(node33);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.reportMissingOverride;
        compilerOptions0.setAppNameStr("module$STRING hi!");
        boolean boolean4 = compilerOptions0.crossModuleMethodMotion;
        boolean boolean5 = compilerOptions0.computeFunctionSideEffects;
        compilerOptions0.locale = "module$STRING hi!";
        compilerOptions0.setComputeFunctionSideEffects(true);
        boolean boolean10 = compilerOptions0.ambiguateProperties;
        boolean boolean11 = compilerOptions0.exportTestFunctions;
        compilerOptions0.exportTestFunctions = true;
        boolean boolean14 = compilerOptions0.generateExports;
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        java.util.logging.Logger logger0 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager1 = new com.google.javascript.jscomp.LoggerErrorManager(logger0);
        double double2 = loggerErrorManager1.getTypedPercent();
        com.google.javascript.jscomp.Compiler compiler3 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager1);
        com.google.javascript.jscomp.Result result4 = compiler3.getResult();
        java.util.logging.Logger logger5 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager6 = new com.google.javascript.jscomp.LoggerErrorManager(logger5);
        double double7 = loggerErrorManager6.getTypedPercent();
        compiler3.setErrorManager((com.google.javascript.jscomp.ErrorManager) loggerErrorManager6);
        com.google.javascript.jscomp.SourceExcerptProvider.SourceExcerpt sourceExcerpt9 = null;
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter10 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler3, sourceExcerpt9);
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray11 = null;
        com.google.javascript.jscomp.JSModule jSModule12 = null;
        com.google.javascript.jscomp.JSModule[] jSModuleArray13 = new com.google.javascript.jscomp.JSModule[] { jSModule12 };
        com.google.javascript.jscomp.CompilerOptions compilerOptions14 = null;
        try {
            compiler3.init(jSSourceFileArray11, jSModuleArray13, compilerOptions14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(result4);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(jSModuleArray13);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.thisNode();
        node0.setOptionalArg(false);
        com.google.javascript.rhino.Node node6 = new com.google.javascript.rhino.Node((int) (byte) 100, (int) (byte) 1, 54);
        com.google.javascript.rhino.Node node7 = node6.getLastSibling();
        node0.addChildToBack(node7);
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertNotNull(node7);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        com.google.javascript.jscomp.SourceFile.Builder builder0 = new com.google.javascript.jscomp.SourceFile.Builder();
        com.google.javascript.jscomp.SourceFile.Builder builder2 = builder0.withOriginalPath("goog.global");
        java.nio.charset.Charset charset3 = null;
        com.google.javascript.jscomp.SourceFile.Builder builder4 = builder0.withCharset(charset3);
        org.junit.Assert.assertNotNull(builder2);
        org.junit.Assert.assertNotNull(builder4);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean3 = node2.isFor();
        boolean boolean4 = node2.isExprResult();
        java.lang.String str5 = node2.getString();
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean8 = node7.isFor();
        boolean boolean9 = node7.isExprResult();
        com.google.javascript.rhino.Node node10 = node2.clonePropsFrom(node7);
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean13 = node12.isFor();
        boolean boolean14 = node12.isExprResult();
        java.lang.String str15 = node12.getString();
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean18 = node17.isFor();
        boolean boolean19 = node17.isExprResult();
        com.google.javascript.rhino.Node node20 = node12.clonePropsFrom(node17);
        boolean boolean21 = node20.isVar();
        node20.setSourceEncodedPositionForTree(16);
        com.google.javascript.rhino.Node node24 = new com.google.javascript.rhino.Node(10, node7, node20);
        com.google.javascript.jscomp.SourceFile sourceFile26 = com.google.javascript.jscomp.SourceFile.fromFile("hi!");
        node24.setStaticSourceFile((com.google.javascript.rhino.jstype.StaticSourceFile) sourceFile26);
        com.google.javascript.rhino.Node node28 = com.google.javascript.rhino.IR.thisNode();
        node28.setOptionalArg(false);
        node24.addChildToFront(node28);
        try {
            double double32 = node24.getDouble();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: BITXOR [source_file: hi!] is not a number node");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "hi!" + "'", str15.equals("hi!"));
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(sourceFile26);
        org.junit.Assert.assertNotNull(node28);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean2 = node1.isFor();
        boolean boolean3 = node1.isExprResult();
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean6 = node5.isFor();
        com.google.javascript.rhino.Node node7 = node1.clonePropsFrom(node5);
        boolean boolean8 = node1.isOnlyModifiesThisCall();
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean11 = node10.isFor();
        boolean boolean12 = node10.isExprResult();
        java.lang.String str13 = node10.getString();
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean16 = node15.isFor();
        boolean boolean17 = node15.isExprResult();
        com.google.javascript.rhino.Node node18 = node10.clonePropsFrom(node15);
        boolean boolean19 = node18.isVar();
        com.google.javascript.rhino.Node node20 = node1.useSourceInfoFromForTree(node18);
        com.google.javascript.rhino.jstype.JSType jSType21 = null;
        node20.setJSType(jSType21);
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.IR.paramList();
        boolean boolean24 = node23.isThrow();
        node20.addChildToBack(node23);
        com.google.javascript.rhino.jstype.JSType jSType26 = node23.getJSType();
        try {
            double double27 = node23.getDouble();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: PARAM_LIST is not a number node");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "hi!" + "'", str13.equals("hi!"));
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNull(jSType26);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        java.util.logging.Logger logger0 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager1 = new com.google.javascript.jscomp.LoggerErrorManager(logger0);
        double double2 = loggerErrorManager1.getTypedPercent();
        com.google.javascript.jscomp.Compiler compiler3 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager1);
        com.google.javascript.jscomp.Result result4 = compiler3.getResult();
        java.util.logging.Logger logger5 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager6 = new com.google.javascript.jscomp.LoggerErrorManager(logger5);
        double double7 = loggerErrorManager6.getTypedPercent();
        compiler3.setErrorManager((com.google.javascript.jscomp.ErrorManager) loggerErrorManager6);
        com.google.javascript.jscomp.SourceFile.Generator generator10 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile11 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("goog.global", generator10);
        com.google.javascript.jscomp.SourceFile.Generator generator13 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile14 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("goog.global", generator13);
        com.google.javascript.jscomp.SourceFile.Generator generator16 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile17 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("goog.global", generator16);
        java.nio.charset.Charset charset19 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile20 = com.google.javascript.jscomp.JSSourceFile.fromFile("hi!. hi! at (unknown source) line (unknown line) : (unknown column)", charset19);
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray21 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile11, jSSourceFile14, jSSourceFile17, jSSourceFile20 };
        com.google.javascript.jscomp.SourceFile.Generator generator23 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile24 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("goog.global", generator23);
        com.google.javascript.jscomp.SourceFile.Generator generator26 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile27 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("goog.global", generator26);
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray28 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile24, jSSourceFile27 };
        com.google.javascript.jscomp.CompilerOptions compilerOptions29 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel30 = compilerOptions29.reportMissingOverride;
        compilerOptions29.setAppNameStr("module$STRING hi!");
        boolean boolean33 = compilerOptions29.crossModuleMethodMotion;
        boolean boolean34 = compilerOptions29.computeFunctionSideEffects;
        byte[] byteArray35 = compilerOptions29.inputVariableMapSerialized;
        compilerOptions29.checkMissingGetCssNameBlacklist = "hi!";
        compiler3.init(jSSourceFileArray21, jSSourceFileArray28, compilerOptions29);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile39 = null;
        java.util.logging.Logger logger40 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager41 = new com.google.javascript.jscomp.LoggerErrorManager(logger40);
        double double42 = loggerErrorManager41.getTypedPercent();
        com.google.javascript.jscomp.Compiler compiler43 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager41);
        com.google.javascript.jscomp.Result result44 = compiler43.getResult();
        java.lang.String str45 = compiler43.getAstDotGraph();
        com.google.javascript.jscomp.JSError[] jSErrorArray46 = compiler43.getWarnings();
        com.google.javascript.jscomp.JSError[] jSErrorArray47 = compiler43.getWarnings();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile49 = com.google.javascript.jscomp.JSSourceFile.fromFile("Unknown class name");
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray50 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile49 };
        java.nio.charset.Charset charset52 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile53 = com.google.javascript.jscomp.JSSourceFile.fromFile("hi!. hi! at (unknown source) line (unknown line) : (unknown column)", charset52);
        java.lang.Class<?> wildcardClass54 = jSSourceFile53.getClass();
        java.nio.charset.Charset charset56 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile57 = com.google.javascript.jscomp.JSSourceFile.fromFile("hi!. hi! at (unknown source) line (unknown line) : (unknown column)", charset56);
        java.nio.charset.Charset charset59 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile60 = com.google.javascript.jscomp.JSSourceFile.fromFile("hi!. hi! at (unknown source) line (unknown line) : (unknown column)", charset59);
        java.lang.String str62 = jSSourceFile60.getLine(43);
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray63 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile53, jSSourceFile57, jSSourceFile60 };
        com.google.javascript.jscomp.CompilerOptions compilerOptions64 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel65 = compilerOptions64.reportMissingOverride;
        compilerOptions64.setAppNameStr("module$STRING hi!");
        boolean boolean68 = compilerOptions64.crossModuleMethodMotion;
        boolean boolean69 = compilerOptions64.computeFunctionSideEffects;
        compilerOptions64.reserveRawExports = false;
        boolean boolean72 = compilerOptions64.collapseAnonymousFunctions;
        compilerOptions64.printInputDelimiter = true;
        boolean boolean75 = compilerOptions64.preferLineBreakAtEndOfFile;
        compiler43.init(jSSourceFileArray50, jSSourceFileArray63, compilerOptions64);
        com.google.javascript.jscomp.CompilerOptions compilerOptions77 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel78 = compilerOptions77.reportMissingOverride;
        java.lang.String[] strArray85 = new java.lang.String[] { "STRING hi!", "hi!. hi! at (unknown source) line (unknown line) : (unknown column)", "module$STRING hi!", "hi!", "", "STRING hi!" };
        java.util.LinkedHashSet<java.lang.String> strSet86 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean87 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet86, strArray85);
        compilerOptions77.setIdGenerators((java.util.Set<java.lang.String>) strSet86);
        compilerOptions77.renamePrefix = "";
        compilerOptions77.crossModuleMethodMotion = true;
        compilerOptions77.setCheckControlStructures(true);
        compilerOptions77.resetWarningsGuard();
        try {
            com.google.javascript.jscomp.Result result96 = compiler3.compile(jSSourceFile39, jSSourceFileArray63, compilerOptions77);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(result4);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(jSSourceFile11);
        org.junit.Assert.assertNotNull(jSSourceFile14);
        org.junit.Assert.assertNotNull(jSSourceFile17);
        org.junit.Assert.assertNotNull(jSSourceFile20);
        org.junit.Assert.assertNotNull(jSSourceFileArray21);
        org.junit.Assert.assertNotNull(jSSourceFile24);
        org.junit.Assert.assertNotNull(jSSourceFile27);
        org.junit.Assert.assertNotNull(jSSourceFileArray28);
        org.junit.Assert.assertTrue("'" + checkLevel30 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel30.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNull(byteArray35);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 0.0d + "'", double42 == 0.0d);
        org.junit.Assert.assertNotNull(result44);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "" + "'", str45.equals(""));
        org.junit.Assert.assertNotNull(jSErrorArray46);
        org.junit.Assert.assertNotNull(jSErrorArray47);
        org.junit.Assert.assertNotNull(jSSourceFile49);
        org.junit.Assert.assertNotNull(jSSourceFileArray50);
        org.junit.Assert.assertNotNull(jSSourceFile53);
        org.junit.Assert.assertNotNull(wildcardClass54);
        org.junit.Assert.assertNotNull(jSSourceFile57);
        org.junit.Assert.assertNotNull(jSSourceFile60);
        org.junit.Assert.assertNull(str62);
        org.junit.Assert.assertNotNull(jSSourceFileArray63);
        org.junit.Assert.assertTrue("'" + checkLevel65 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel65.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
        org.junit.Assert.assertTrue("'" + checkLevel78 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel78.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(strArray85);
        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + true + "'", boolean87 == true);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newString("hi!");
        com.google.javascript.rhino.Node node2 = node1.getFirstChild();
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertNull(node2);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        java.util.logging.Logger logger0 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager1 = new com.google.javascript.jscomp.LoggerErrorManager(logger0);
        double double2 = loggerErrorManager1.getTypedPercent();
        com.google.javascript.jscomp.Compiler compiler3 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager1);
        com.google.javascript.jscomp.PassConfig passConfig4 = null;
        try {
            compiler3.setPassConfig(passConfig4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean3 = node2.isFor();
        boolean boolean4 = node2.isExprResult();
        java.lang.String str5 = node2.getString();
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean8 = node7.isFor();
        boolean boolean9 = node7.isExprResult();
        com.google.javascript.rhino.Node node10 = node2.clonePropsFrom(node7);
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean13 = node12.isFor();
        boolean boolean14 = node12.isExprResult();
        java.lang.String str15 = node12.getString();
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean18 = node17.isFor();
        boolean boolean19 = node17.isExprResult();
        com.google.javascript.rhino.Node node20 = node12.clonePropsFrom(node17);
        boolean boolean21 = node20.isVar();
        node20.setSourceEncodedPositionForTree(16);
        com.google.javascript.rhino.Node node24 = new com.google.javascript.rhino.Node(10, node7, node20);
        com.google.javascript.jscomp.SourceFile sourceFile26 = com.google.javascript.jscomp.SourceFile.fromFile("hi!");
        node24.setStaticSourceFile((com.google.javascript.rhino.jstype.StaticSourceFile) sourceFile26);
        com.google.javascript.rhino.Node node28 = com.google.javascript.rhino.IR.thisNode();
        node28.setOptionalArg(false);
        node24.addChildToFront(node28);
        java.util.Collection<com.google.javascript.rhino.Node> nodeCollection32 = com.google.javascript.jscomp.NodeUtil.getVarsDeclaredInBranch(node24);
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "hi!" + "'", str15.equals("hi!"));
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(sourceFile26);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertNotNull(nodeCollection32);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        java.util.logging.Logger logger0 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager1 = new com.google.javascript.jscomp.LoggerErrorManager(logger0);
        double double2 = loggerErrorManager1.getTypedPercent();
        com.google.javascript.jscomp.Compiler compiler3 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager1);
        com.google.javascript.jscomp.Result result4 = compiler3.getResult();
        java.lang.String str5 = compiler3.getAstDotGraph();
        com.google.javascript.jscomp.JSError[] jSErrorArray6 = compiler3.getWarnings();
        com.google.javascript.jscomp.JSError[] jSErrorArray7 = compiler3.getWarnings();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile9 = com.google.javascript.jscomp.JSSourceFile.fromFile("Unknown class name");
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray10 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile9 };
        java.nio.charset.Charset charset12 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile13 = com.google.javascript.jscomp.JSSourceFile.fromFile("hi!. hi! at (unknown source) line (unknown line) : (unknown column)", charset12);
        java.lang.Class<?> wildcardClass14 = jSSourceFile13.getClass();
        java.nio.charset.Charset charset16 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile17 = com.google.javascript.jscomp.JSSourceFile.fromFile("hi!. hi! at (unknown source) line (unknown line) : (unknown column)", charset16);
        java.nio.charset.Charset charset19 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile20 = com.google.javascript.jscomp.JSSourceFile.fromFile("hi!. hi! at (unknown source) line (unknown line) : (unknown column)", charset19);
        java.lang.String str22 = jSSourceFile20.getLine(43);
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray23 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile13, jSSourceFile17, jSSourceFile20 };
        com.google.javascript.jscomp.CompilerOptions compilerOptions24 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel25 = compilerOptions24.reportMissingOverride;
        compilerOptions24.setAppNameStr("module$STRING hi!");
        boolean boolean28 = compilerOptions24.crossModuleMethodMotion;
        boolean boolean29 = compilerOptions24.computeFunctionSideEffects;
        compilerOptions24.reserveRawExports = false;
        boolean boolean32 = compilerOptions24.collapseAnonymousFunctions;
        compilerOptions24.printInputDelimiter = true;
        boolean boolean35 = compilerOptions24.preferLineBreakAtEndOfFile;
        compiler3.init(jSSourceFileArray10, jSSourceFileArray23, compilerOptions24);
        compilerOptions24.aliasKeywords = true;
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(result4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertNotNull(jSErrorArray6);
        org.junit.Assert.assertNotNull(jSErrorArray7);
        org.junit.Assert.assertNotNull(jSSourceFile9);
        org.junit.Assert.assertNotNull(jSSourceFileArray10);
        org.junit.Assert.assertNotNull(jSSourceFile13);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(jSSourceFile17);
        org.junit.Assert.assertNotNull(jSSourceFile20);
        org.junit.Assert.assertNull(str22);
        org.junit.Assert.assertNotNull(jSSourceFileArray23);
        org.junit.Assert.assertTrue("'" + checkLevel25 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel25.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.reportMissingOverride;
        compilerOptions0.setAppNameStr("module$STRING hi!");
        boolean boolean4 = compilerOptions0.crossModuleMethodMotion;
        boolean boolean5 = compilerOptions0.computeFunctionSideEffects;
        compilerOptions0.locale = "module$STRING hi!";
        java.lang.String str8 = compilerOptions0.inputDelimiter;
        com.google.javascript.jscomp.DiagnosticType diagnosticType9 = com.google.javascript.jscomp.Compiler.MOTION_ITERATIONS_ERROR;
        com.google.javascript.jscomp.CheckLevel checkLevel10 = com.google.javascript.jscomp.CheckLevel.WARNING;
        diagnosticType9.level = checkLevel10;
        compilerOptions0.checkMissingGetCssNameLevel = checkLevel10;
        compilerOptions0.setNameReferenceReportPath("Named type with empty name component");
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "// Input %num%" + "'", str8.equals("// Input %num%"));
        org.junit.Assert.assertNotNull(diagnosticType9);
        org.junit.Assert.assertTrue("'" + checkLevel10 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel10.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.reportMissingOverride;
        compilerOptions0.setAppNameStr("module$STRING hi!");
        boolean boolean4 = compilerOptions0.foldConstants;
        compilerOptions0.removeUnusedVars = true;
        com.google.common.collect.Multimap<com.google.javascript.jscomp.CustomPassExecutionTime, com.google.javascript.jscomp.CompilerPass> customPassExecutionTimeMultimap7 = compilerOptions0.customPasses;
        com.google.javascript.jscomp.CompilerOptions compilerOptions8 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel9 = compilerOptions8.reportMissingOverride;
        compilerOptions8.setAppNameStr("module$STRING hi!");
        compilerOptions8.setOutputJsStringUsage(true);
        java.util.Set<java.lang.String> strSet14 = null;
        compilerOptions8.setStripTypes(strSet14);
        com.google.javascript.jscomp.CompilerOptions compilerOptions16 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel17 = compilerOptions16.reportMissingOverride;
        compilerOptions16.setAppNameStr("module$STRING hi!");
        boolean boolean20 = compilerOptions16.crossModuleMethodMotion;
        boolean boolean21 = compilerOptions16.computeFunctionSideEffects;
        compilerOptions16.locale = "module$STRING hi!";
        compilerOptions16.setComputeFunctionSideEffects(true);
        compilerOptions16.setAliasableGlobals("hi!");
        com.google.javascript.jscomp.CompilerOptions compilerOptions28 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel29 = compilerOptions28.reportMissingOverride;
        compilerOptions16.checkUnreachableCode = checkLevel29;
        compilerOptions8.setCheckProvides(checkLevel29);
        compilerOptions0.checkUnreachableCode = checkLevel29;
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(customPassExecutionTimeMultimap7);
        org.junit.Assert.assertTrue("'" + checkLevel9 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel9.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + checkLevel17 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel17.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + checkLevel29 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel29.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.reportMissingOverride;
        java.lang.String[] strArray8 = new java.lang.String[] { "STRING hi!", "hi!. hi! at (unknown source) line (unknown line) : (unknown column)", "module$STRING hi!", "hi!", "", "STRING hi!" };
        java.util.LinkedHashSet<java.lang.String> strSet9 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean10 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet9, strArray8);
        compilerOptions0.setIdGenerators((java.util.Set<java.lang.String>) strSet9);
        compilerOptions0.setAliasExternals(false);
        com.google.javascript.jscomp.CompilerOptions.TracerMode tracerMode14 = null;
        compilerOptions0.setTracer(tracerMode14);
        boolean boolean16 = compilerOptions0.removeUnusedLocalVars;
        compilerOptions0.setCheckControlStructures(false);
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.reportMissingOverride;
        compilerOptions0.setAppNameStr("module$STRING hi!");
        boolean boolean4 = compilerOptions0.crossModuleMethodMotion;
        boolean boolean5 = compilerOptions0.computeFunctionSideEffects;
        compilerOptions0.reserveRawExports = false;
        compilerOptions0.setLocale("");
        compilerOptions0.gatherCssNames = true;
        boolean boolean12 = compilerOptions0.checkSymbols;
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        int int0 = com.google.javascript.rhino.Node.IS_DISPATCHER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 47 + "'", int0 == 47);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        java.lang.String str1 = com.google.javascript.jscomp.ProcessCommonJSModules.toModuleName("module$goog.global");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "module$module$goog.global" + "'", str1.equals("module$module$goog.global"));
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean3 = node2.isFor();
        boolean boolean4 = node2.isExprResult();
        java.lang.String str5 = node2.getString();
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean8 = node7.isFor();
        boolean boolean9 = node7.isExprResult();
        com.google.javascript.rhino.Node node10 = node2.clonePropsFrom(node7);
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean13 = node12.isFor();
        boolean boolean14 = node12.isExprResult();
        java.lang.String str15 = node12.getString();
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean18 = node17.isFor();
        boolean boolean19 = node17.isExprResult();
        com.google.javascript.rhino.Node node20 = node12.clonePropsFrom(node17);
        boolean boolean21 = node20.isVar();
        node20.setSourceEncodedPositionForTree(16);
        com.google.javascript.rhino.Node node24 = new com.google.javascript.rhino.Node(10, node7, node20);
        com.google.javascript.jscomp.SourceFile sourceFile26 = com.google.javascript.jscomp.SourceFile.fromFile("hi!");
        node24.setStaticSourceFile((com.google.javascript.rhino.jstype.StaticSourceFile) sourceFile26);
        com.google.javascript.rhino.Node node28 = com.google.javascript.rhino.IR.paramList();
        com.google.javascript.rhino.Node node29 = node24.srcref(node28);
        com.google.javascript.rhino.Node node30 = node29.cloneNode();
        com.google.javascript.rhino.Node node32 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean33 = node32.isFor();
        boolean boolean34 = node32.isExprResult();
        com.google.javascript.rhino.Node node36 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean37 = node36.isFor();
        com.google.javascript.rhino.Node node38 = node32.clonePropsFrom(node36);
        node36.addSuppression("module$STRING hi!");
        java.lang.String str44 = node36.toString(true, true, false);
        com.google.javascript.rhino.Node node45 = com.google.javascript.rhino.IR.or(node30, node36);
        com.google.javascript.rhino.Node node47 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean48 = node47.isFor();
        boolean boolean49 = node47.isExprResult();
        com.google.javascript.rhino.Node node51 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean52 = node51.isFor();
        com.google.javascript.rhino.Node node53 = node47.clonePropsFrom(node51);
        node51.addSuppression("module$STRING hi!");
        com.google.javascript.rhino.Node node57 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean58 = node57.isFor();
        boolean boolean59 = node57.isExprResult();
        java.lang.String str60 = node57.getString();
        com.google.javascript.rhino.Node node62 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean63 = node62.isFor();
        boolean boolean64 = node62.isExprResult();
        com.google.javascript.rhino.Node node65 = node57.clonePropsFrom(node62);
        com.google.javascript.rhino.Node node67 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean68 = node67.isFor();
        boolean boolean69 = node67.isExprResult();
        java.lang.String str70 = node67.getString();
        com.google.javascript.rhino.Node node72 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean73 = node72.isFor();
        boolean boolean74 = node72.isExprResult();
        com.google.javascript.rhino.Node node75 = node67.clonePropsFrom(node72);
        int int76 = node62.getIndexOfChild(node67);
        com.google.javascript.rhino.Node node77 = node62.cloneTree();
        com.google.javascript.rhino.Node node78 = com.google.javascript.rhino.IR.comma(node51, node77);
        boolean boolean79 = node30.hasChild(node77);
        com.google.javascript.rhino.jstype.JSType jSType80 = node77.getJSType();
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "hi!" + "'", str15.equals("hi!"));
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(sourceFile26);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNotNull(node30);
        org.junit.Assert.assertNotNull(node32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(node36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(node38);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "STRING hi! [jsdoc_info: JSDocInfo]" + "'", str44.equals("STRING hi! [jsdoc_info: JSDocInfo]"));
        org.junit.Assert.assertNotNull(node45);
        org.junit.Assert.assertNotNull(node47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNotNull(node51);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertNotNull(node53);
        org.junit.Assert.assertNotNull(node57);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertTrue("'" + str60 + "' != '" + "hi!" + "'", str60.equals("hi!"));
        org.junit.Assert.assertNotNull(node62);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertNotNull(node65);
        org.junit.Assert.assertNotNull(node67);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
        org.junit.Assert.assertTrue("'" + str70 + "' != '" + "hi!" + "'", str70.equals("hi!"));
        org.junit.Assert.assertNotNull(node72);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
        org.junit.Assert.assertNotNull(node75);
        org.junit.Assert.assertTrue("'" + int76 + "' != '" + (-1) + "'", int76 == (-1));
        org.junit.Assert.assertNotNull(node77);
        org.junit.Assert.assertNotNull(node78);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
        org.junit.Assert.assertNull(jSType80);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        java.util.logging.Logger logger0 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager1 = new com.google.javascript.jscomp.LoggerErrorManager(logger0);
        double double2 = loggerErrorManager1.getTypedPercent();
        com.google.javascript.jscomp.Compiler compiler3 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager1);
        com.google.javascript.jscomp.Result result4 = compiler3.getResult();
        java.util.logging.Logger logger5 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager6 = new com.google.javascript.jscomp.LoggerErrorManager(logger5);
        double double7 = loggerErrorManager6.getTypedPercent();
        compiler3.setErrorManager((com.google.javascript.jscomp.ErrorManager) loggerErrorManager6);
        com.google.javascript.jscomp.NodeTraversal.Callback callback9 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal10 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler3, callback9);
        com.google.javascript.jscomp.Scope scope11 = compiler3.getTopScope();
        com.google.javascript.jscomp.PassConfig passConfig12 = null;
        try {
            compiler3.setPassConfig(passConfig12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(result4);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNull(scope11);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.reportMissingOverride;
        compilerOptions0.setAppNameStr("module$STRING hi!");
        boolean boolean4 = compilerOptions0.crossModuleMethodMotion;
        boolean boolean5 = compilerOptions0.computeFunctionSideEffects;
        byte[] byteArray6 = compilerOptions0.inputVariableMapSerialized;
        byte[] byteArray7 = compilerOptions0.inputVariableMapSerialized;
        compilerOptions0.setReserveRawExports(false);
        boolean boolean10 = compilerOptions0.preferLineBreakAtEndOfFile;
        java.lang.String str11 = compilerOptions0.inputDelimiter;
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(byteArray6);
        org.junit.Assert.assertNull(byteArray7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "// Input %num%" + "'", str11.equals("// Input %num%"));
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        java.nio.charset.Charset charset1 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromFile("hi!. hi! at (unknown source) line (unknown line) : (unknown column)", charset1);
        java.lang.String str4 = jSSourceFile2.getLine(43);
        com.google.javascript.jscomp.parsing.Config.LanguageMode languageMode7 = com.google.javascript.jscomp.parsing.Config.LanguageMode.ECMASCRIPT5_STRICT;
        java.lang.String[] strArray11 = new java.lang.String[] { "Unknown class name", "" };
        java.util.LinkedHashSet<java.lang.String> strSet12 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean13 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet12, strArray11);
        com.google.javascript.jscomp.parsing.Config config14 = com.google.javascript.jscomp.parsing.ParserRunner.createConfig(false, languageMode7, false, (java.util.Set<java.lang.String>) strSet12);
        com.google.javascript.rhino.head.ErrorReporter errorReporter15 = null;
        java.util.logging.Logger logger16 = null;
        try {
            com.google.javascript.rhino.Node node17 = com.google.javascript.jscomp.parsing.ParserRunner.parse((com.google.javascript.rhino.jstype.StaticSourceFile) jSSourceFile2, "module$module$goog.global", config14, errorReporter15, logger16);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile2);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + languageMode7 + "' != '" + com.google.javascript.jscomp.parsing.Config.LanguageMode.ECMASCRIPT5_STRICT + "'", languageMode7.equals(com.google.javascript.jscomp.parsing.Config.LanguageMode.ECMASCRIPT5_STRICT));
        org.junit.Assert.assertNotNull(strArray11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(config14);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.reportMissingOverride;
        compilerOptions0.setAppNameStr("module$STRING hi!");
        compilerOptions0.setOutputJsStringUsage(true);
        java.util.Set<java.lang.String> strSet6 = compilerOptions0.stripTypePrefixes;
        compilerOptions0.lineBreak = false;
        compilerOptions0.setInlineFunctions(true);
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(strSet6);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        com.google.javascript.jscomp.CodingConvention codingConvention0 = com.google.javascript.jscomp.CodingConventions.getDefault();
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention1 = new com.google.javascript.jscomp.ClosureCodingConvention(codingConvention0);
        boolean boolean4 = closureCodingConvention1.isExported("hi!", true);
        boolean boolean7 = closureCodingConvention1.isExported("Unknown class name", false);
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean10 = node9.isFor();
        boolean boolean11 = node9.isExprResult();
        boolean boolean12 = node9.isCase();
        boolean boolean13 = closureCodingConvention1.isOptionalParameter(node9);
        org.junit.Assert.assertNotNull(codingConvention0);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.thisNode();
        node0.setOptionalArg(false);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder3 = node0.getJsDocBuilderForNode();
        fileLevelJsDocBuilder3.append("");
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder3);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        com.google.javascript.jscomp.CodingConvention codingConvention0 = com.google.javascript.jscomp.CodingConventions.getDefault();
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention1 = new com.google.javascript.jscomp.ClosureCodingConvention(codingConvention0);
        boolean boolean4 = closureCodingConvention1.isExported("hi!", true);
        boolean boolean6 = closureCodingConvention1.isConstant("module$goog.global");
        org.junit.Assert.assertNotNull(codingConvention0);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        java.nio.charset.Charset charset1 = null;
        com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromFile("STRING hi!", charset1);
        java.lang.String str3 = sourceFile2.toString();
        org.junit.Assert.assertNotNull(sourceFile2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "STRING hi!" + "'", str3.equals("STRING hi!"));
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        java.io.File file0 = null;
        java.nio.charset.Charset charset1 = null;
        try {
            com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromFile(file0, charset1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newString("hi!");
        java.lang.Object obj3 = null;
        node1.putProp(50, obj3);
        int int5 = node1.getLineno();
        boolean boolean6 = node1.wasEmptyNode();
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.reportMissingOverride;
        compilerOptions0.setAppNameStr("module$STRING hi!");
        com.google.javascript.jscomp.CompilerOptions.Reach reach4 = com.google.javascript.jscomp.CompilerOptions.Reach.ALL;
        compilerOptions0.setRemoveUnusedVariables(reach4);
        compilerOptions0.aliasAllStrings = true;
        java.util.Map<java.lang.String, com.google.javascript.rhino.Node> strMap8 = compilerOptions0.getDefineReplacements();
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + reach4 + "' != '" + com.google.javascript.jscomp.CompilerOptions.Reach.ALL + "'", reach4.equals(com.google.javascript.jscomp.CompilerOptions.Reach.ALL));
        org.junit.Assert.assertNotNull(strMap8);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        java.util.logging.Logger logger0 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager1 = new com.google.javascript.jscomp.LoggerErrorManager(logger0);
        double double2 = loggerErrorManager1.getTypedPercent();
        com.google.javascript.jscomp.Compiler compiler3 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager1);
        com.google.javascript.jscomp.Result result4 = compiler3.getResult();
        java.util.logging.Logger logger5 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager6 = new com.google.javascript.jscomp.LoggerErrorManager(logger5);
        double double7 = loggerErrorManager6.getTypedPercent();
        compiler3.setErrorManager((com.google.javascript.jscomp.ErrorManager) loggerErrorManager6);
        com.google.javascript.jscomp.SourceExcerptProvider.SourceExcerpt sourceExcerpt9 = null;
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter10 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler3, sourceExcerpt9);
        com.google.javascript.jscomp.DiagnosticType diagnosticType13 = com.google.javascript.jscomp.DiagnosticType.disabled("hi!", "hi!");
        java.lang.String[] strArray15 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError16 = com.google.javascript.jscomp.JSError.make(diagnosticType13, strArray15);
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean19 = node18.isFor();
        boolean boolean20 = node18.isExprResult();
        com.google.javascript.rhino.Node node22 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean23 = node22.isFor();
        com.google.javascript.rhino.Node node24 = node18.clonePropsFrom(node22);
        node18.putIntProp(53, (int) (byte) 100);
        boolean boolean28 = jSError16.equals((java.lang.Object) 53);
        java.lang.String str29 = jSError16.toString();
        java.lang.String str30 = jSError16.sourceName;
        com.google.javascript.jscomp.CheckLevel checkLevel31 = jSError16.level;
        try {
            java.lang.String str32 = lightweightMessageFormatter10.formatError(jSError16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(result4);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(diagnosticType13);
        org.junit.Assert.assertNotNull(strArray15);
        org.junit.Assert.assertNotNull(jSError16);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "hi!. hi! at (unknown source) line (unknown line) : (unknown column)" + "'", str29.equals("hi!. hi! at (unknown source) line (unknown line) : (unknown column)"));
        org.junit.Assert.assertNull(str30);
        org.junit.Assert.assertTrue("'" + checkLevel31 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel31.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        com.google.javascript.jscomp.SourceFile sourceFile1 = com.google.javascript.jscomp.SourceFile.fromFile("hi!");
        boolean boolean2 = sourceFile1.isExtern();
        com.google.javascript.jscomp.JsAst jsAst3 = new com.google.javascript.jscomp.JsAst(sourceFile1);
        java.util.logging.Logger logger4 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager5 = new com.google.javascript.jscomp.LoggerErrorManager(logger4);
        double double6 = loggerErrorManager5.getTypedPercent();
        com.google.javascript.jscomp.Compiler compiler7 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager5);
        com.google.javascript.jscomp.Result result8 = compiler7.getResult();
        java.util.logging.Logger logger9 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager10 = new com.google.javascript.jscomp.LoggerErrorManager(logger9);
        double double11 = loggerErrorManager10.getTypedPercent();
        compiler7.setErrorManager((com.google.javascript.jscomp.ErrorManager) loggerErrorManager10);
        com.google.javascript.jscomp.NodeTraversal.Callback callback13 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal14 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler7, callback13);
        com.google.javascript.jscomp.Scope scope15 = compiler7.getTopScope();
        com.google.javascript.rhino.Node node16 = jsAst3.getAstRoot((com.google.javascript.jscomp.AbstractCompiler) compiler7);
        java.lang.String str19 = compiler7.getSourceLine("// Input %num%", (-1));
        int int20 = compiler7.getErrorCount();
        org.junit.Assert.assertNotNull(sourceFile1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(result8);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNull(scope15);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertNull(str19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.reportMissingOverride;
        compilerOptions0.setAppNameStr("module$STRING hi!");
        boolean boolean4 = compilerOptions0.crossModuleMethodMotion;
        boolean boolean5 = compilerOptions0.computeFunctionSideEffects;
        compilerOptions0.reserveRawExports = false;
        compilerOptions0.setLocale("");
        compilerOptions0.gatherCssNames = true;
        compilerOptions0.setOptimizeParameters(true);
        boolean boolean14 = compilerOptions0.recordFunctionInformation;
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        java.util.logging.Logger logger0 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager1 = new com.google.javascript.jscomp.LoggerErrorManager(logger0);
        double double2 = loggerErrorManager1.getTypedPercent();
        com.google.javascript.jscomp.Compiler compiler3 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager1);
        com.google.javascript.jscomp.Result result4 = compiler3.getResult();
        java.util.logging.Logger logger5 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager6 = new com.google.javascript.jscomp.LoggerErrorManager(logger5);
        double double7 = loggerErrorManager6.getTypedPercent();
        compiler3.setErrorManager((com.google.javascript.jscomp.ErrorManager) loggerErrorManager6);
        com.google.javascript.jscomp.NodeTraversal.Callback callback9 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal10 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler3, callback9);
        java.lang.String str11 = nodeTraversal10.getSourceName();
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean14 = node13.isFor();
        boolean boolean15 = node13.isExprResult();
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean18 = node17.isFor();
        com.google.javascript.rhino.Node node19 = node13.clonePropsFrom(node17);
        com.google.javascript.jscomp.DiagnosticType diagnosticType22 = com.google.javascript.jscomp.DiagnosticType.disabled("hi!", "hi!");
        java.lang.String[] strArray25 = new java.lang.String[] { "./", "module$module$goog.global" };
        nodeTraversal10.report(node13, diagnosticType22, strArray25);
        java.lang.String str27 = diagnosticType22.toString();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(result4);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNotNull(diagnosticType22);
        org.junit.Assert.assertNotNull(strArray25);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "hi!: hi!" + "'", str27.equals("hi!: hi!"));
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.reportMissingOverride;
        compilerOptions0.setAppNameStr("module$STRING hi!");
        boolean boolean4 = compilerOptions0.foldConstants;
        boolean boolean5 = compilerOptions0.recordFunctionInformation;
        compilerOptions0.skipAllCompilerPasses();
        boolean boolean7 = compilerOptions0.removeTryCatchFinally;
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        com.google.javascript.rhino.Node node3 = new com.google.javascript.rhino.Node((int) (byte) 100, (int) (byte) 1, 54);
        boolean boolean4 = node3.hasOneChild();
        boolean boolean5 = node3.isWhile();
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.Node.newString("STRING hi!");
        com.google.javascript.rhino.Node node8 = node3.srcref(node7);
        boolean boolean9 = node3.isBreak();
        try {
            int int11 = node3.getExistingIntProp(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: missing prop: 0");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean2 = node1.isFor();
        boolean boolean3 = node1.isExprResult();
        java.lang.String str4 = node1.getString();
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean7 = node6.isFor();
        boolean boolean8 = node6.isExprResult();
        com.google.javascript.rhino.Node node9 = node1.clonePropsFrom(node6);
        boolean boolean10 = node6.isCatch();
        boolean boolean11 = node6.isLabelName();
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "hi!" + "'", str4.equals("hi!"));
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        com.google.javascript.jscomp.CodingConvention codingConvention0 = com.google.javascript.jscomp.CodingConventions.getDefault();
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention1 = new com.google.javascript.jscomp.ClosureCodingConvention(codingConvention0);
        boolean boolean4 = closureCodingConvention1.isExported("hi!", true);
        boolean boolean7 = closureCodingConvention1.isExported("Unknown class name", false);
        java.lang.String str8 = closureCodingConvention1.getAbstractMethodName();
        org.junit.Assert.assertNotNull(codingConvention0);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "goog.abstractMethod" + "'", str8.equals("goog.abstractMethod"));
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        java.lang.String str1 = com.google.javascript.rhino.ScriptRuntime.escapeString("hi!");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "hi!" + "'", str1.equals("hi!"));
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        java.util.logging.Logger logger0 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager1 = new com.google.javascript.jscomp.LoggerErrorManager(logger0);
        double double2 = loggerErrorManager1.getTypedPercent();
        com.google.javascript.jscomp.Compiler compiler3 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager1);
        com.google.javascript.jscomp.Result result4 = compiler3.getResult();
        java.util.logging.Logger logger5 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager6 = new com.google.javascript.jscomp.LoggerErrorManager(logger5);
        double double7 = loggerErrorManager6.getTypedPercent();
        compiler3.setErrorManager((com.google.javascript.jscomp.ErrorManager) loggerErrorManager6);
        com.google.javascript.jscomp.NodeTraversal.Callback callback9 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal10 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler3, callback9);
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean14 = node13.isFor();
        boolean boolean15 = node13.isExprResult();
        java.lang.String str16 = node13.getString();
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean19 = node18.isFor();
        boolean boolean20 = node18.isExprResult();
        com.google.javascript.rhino.Node node21 = node13.clonePropsFrom(node18);
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean24 = node23.isFor();
        boolean boolean25 = node23.isExprResult();
        java.lang.String str26 = node23.getString();
        com.google.javascript.rhino.Node node28 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean29 = node28.isFor();
        boolean boolean30 = node28.isExprResult();
        com.google.javascript.rhino.Node node31 = node23.clonePropsFrom(node28);
        boolean boolean32 = node31.isVar();
        node31.setSourceEncodedPositionForTree(16);
        com.google.javascript.rhino.Node node35 = new com.google.javascript.rhino.Node(10, node18, node31);
        com.google.javascript.jscomp.SourceFile sourceFile37 = com.google.javascript.jscomp.SourceFile.fromFile("hi!");
        node35.setStaticSourceFile((com.google.javascript.rhino.jstype.StaticSourceFile) sourceFile37);
        com.google.javascript.rhino.Node node39 = com.google.javascript.rhino.IR.paramList();
        com.google.javascript.rhino.Node node40 = node35.srcref(node39);
        com.google.javascript.rhino.Node node44 = new com.google.javascript.rhino.Node((int) (byte) 100, (int) (byte) 1, 54);
        boolean boolean45 = node44.isReturn();
        boolean boolean46 = node40.isEquivalentToTyped(node44);
        com.google.javascript.jscomp.CompilerOptions compilerOptions47 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel48 = compilerOptions47.reportMissingOverride;
        compilerOptions47.setAppNameStr("module$STRING hi!");
        boolean boolean51 = compilerOptions47.crossModuleMethodMotion;
        boolean boolean52 = compilerOptions47.computeFunctionSideEffects;
        compilerOptions47.locale = "module$STRING hi!";
        compilerOptions47.setComputeFunctionSideEffects(true);
        compilerOptions47.setAliasableGlobals("hi!");
        com.google.javascript.jscomp.CompilerOptions compilerOptions59 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel60 = compilerOptions59.reportMissingOverride;
        compilerOptions47.checkUnreachableCode = checkLevel60;
        com.google.javascript.jscomp.CompilerOptions compilerOptions62 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel63 = compilerOptions62.reportMissingOverride;
        compilerOptions62.setAppNameStr("module$STRING hi!");
        boolean boolean66 = compilerOptions62.crossModuleMethodMotion;
        boolean boolean67 = compilerOptions62.computeFunctionSideEffects;
        compilerOptions62.locale = "module$STRING hi!";
        compilerOptions62.setComputeFunctionSideEffects(true);
        compilerOptions62.setAliasableGlobals("hi!");
        com.google.javascript.jscomp.CompilerOptions compilerOptions74 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel75 = compilerOptions74.reportMissingOverride;
        compilerOptions62.checkUnreachableCode = checkLevel75;
        compilerOptions47.checkMissingGetCssNameLevel = checkLevel75;
        com.google.javascript.jscomp.DiagnosticType diagnosticType78 = com.google.javascript.jscomp.Compiler.MOTION_ITERATIONS_ERROR;
        java.lang.String[] strArray80 = new java.lang.String[] { "hi!. hi! at (unknown source) line (unknown line) : (unknown column)" };
        com.google.javascript.jscomp.JSError jSError81 = nodeTraversal10.makeError(node44, checkLevel75, diagnosticType78, strArray80);
        com.google.javascript.jscomp.CheckLevel checkLevel82 = diagnosticType78.defaultLevel;
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(result4);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "hi!" + "'", str16.equals("hi!"));
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "hi!" + "'", str26.equals("hi!"));
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(sourceFile37);
        org.junit.Assert.assertNotNull(node39);
        org.junit.Assert.assertNotNull(node40);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + checkLevel48 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel48.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertTrue("'" + checkLevel60 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel60.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + checkLevel63 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel63.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
        org.junit.Assert.assertTrue("'" + checkLevel75 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel75.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(diagnosticType78);
        org.junit.Assert.assertNotNull(strArray80);
        org.junit.Assert.assertNotNull(jSError81);
        org.junit.Assert.assertTrue("'" + checkLevel82 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel82.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.reportMissingOverride;
        compilerOptions0.setAppNameStr("module$STRING hi!");
        compilerOptions0.setOutputJsStringUsage(true);
        java.util.Set<java.lang.String> strSet6 = null;
        compilerOptions0.setStripTypes(strSet6);
        compilerOptions0.removeUnusedVars = false;
        compilerOptions0.setDefineToNumberLiteral("InputId: ", (int) 'a');
        compilerOptions0.aliasAllStrings = true;
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        com.google.javascript.jscomp.SourceFile sourceFile1 = com.google.javascript.jscomp.SourceFile.fromFile("hi!");
        boolean boolean2 = sourceFile1.isExtern();
        com.google.javascript.jscomp.JsAst jsAst3 = new com.google.javascript.jscomp.JsAst(sourceFile1);
        com.google.javascript.jscomp.CompilerInput compilerInput6 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) jsAst3, "// Input %num%", false);
        com.google.javascript.jscomp.SourceAst sourceAst7 = compilerInput6.getSourceAst();
        int int8 = compilerInput6.getNumLines();
        java.nio.charset.Charset charset10 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile11 = com.google.javascript.jscomp.JSSourceFile.fromFile("hi!. hi! at (unknown source) line (unknown line) : (unknown column)", charset10);
        java.lang.Class<?> wildcardClass12 = jSSourceFile11.getClass();
        try {
            compilerInput6.setSourceFile((com.google.javascript.jscomp.SourceFile) jSSourceFile11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(sourceFile1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(sourceAst7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(jSSourceFile11);
        org.junit.Assert.assertNotNull(wildcardClass12);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.reportMissingOverride;
        compilerOptions0.setAppNameStr("module$STRING hi!");
        boolean boolean4 = compilerOptions0.foldConstants;
        compilerOptions0.checkTypes = true;
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.reportMissingOverride;
        compilerOptions0.setAppNameStr("module$STRING hi!");
        boolean boolean4 = compilerOptions0.crossModuleMethodMotion;
        boolean boolean5 = compilerOptions0.computeFunctionSideEffects;
        byte[] byteArray6 = compilerOptions0.inputVariableMapSerialized;
        byte[] byteArray7 = compilerOptions0.inputVariableMapSerialized;
        java.util.Set<java.lang.String> strSet8 = compilerOptions0.stripTypePrefixes;
        boolean boolean9 = compilerOptions0.checkControlStructures;
        compilerOptions0.smartNameRemoval = true;
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(byteArray6);
        org.junit.Assert.assertNull(byteArray7);
        org.junit.Assert.assertNotNull(strSet8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.reportMissingOverride;
        compilerOptions0.setAppNameStr("module$STRING hi!");
        boolean boolean4 = compilerOptions0.crossModuleMethodMotion;
        boolean boolean5 = compilerOptions0.computeFunctionSideEffects;
        compilerOptions0.reserveRawExports = false;
        compilerOptions0.setLocale("");
        com.google.javascript.jscomp.AnonymousFunctionNamingPolicy anonymousFunctionNamingPolicy10 = null;
        compilerOptions0.anonymousFunctionNaming = anonymousFunctionNamingPolicy10;
        java.lang.Object obj12 = compilerOptions0.clone();
        compilerOptions0.setInlineLocalFunctions(false);
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(obj12);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        java.io.InputStream inputStream1 = null;
        try {
            com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromInputStream("module$InputId: ", inputStream1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.TYPE_INVALIDATION;
        com.google.javascript.jscomp.DiagnosticGroups.ES5_STRICT = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticGroups.EXTERNS_VALIDATION = diagnosticGroup0;
        org.junit.Assert.assertNull(diagnosticGroup0);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        com.google.javascript.rhino.Node node0 = null;
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean4 = node3.isFor();
        boolean boolean5 = node3.isExprResult();
        java.lang.String str6 = node3.getString();
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean9 = node8.isFor();
        boolean boolean10 = node8.isExprResult();
        com.google.javascript.rhino.Node node11 = node3.clonePropsFrom(node8);
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean14 = node13.isFor();
        boolean boolean15 = node13.isExprResult();
        java.lang.String str16 = node13.getString();
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean19 = node18.isFor();
        boolean boolean20 = node18.isExprResult();
        com.google.javascript.rhino.Node node21 = node13.clonePropsFrom(node18);
        boolean boolean22 = node21.isVar();
        node21.setSourceEncodedPositionForTree(16);
        com.google.javascript.rhino.Node node25 = new com.google.javascript.rhino.Node(10, node8, node21);
        com.google.javascript.jscomp.SourceFile sourceFile27 = com.google.javascript.jscomp.SourceFile.fromFile("hi!");
        node25.setStaticSourceFile((com.google.javascript.rhino.jstype.StaticSourceFile) sourceFile27);
        com.google.javascript.rhino.Node node29 = com.google.javascript.rhino.IR.paramList();
        com.google.javascript.rhino.Node node30 = node25.srcref(node29);
        boolean boolean31 = node25.isNot();
        com.google.javascript.rhino.Node node32 = node25.getParent();
        try {
            com.google.javascript.rhino.Node node33 = com.google.javascript.rhino.IR.tryCatch(node0, node32);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "hi!" + "'", str16.equals("hi!"));
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(sourceFile27);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNotNull(node30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNull(node32);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        com.google.javascript.jscomp.DiagnosticType diagnosticType3 = com.google.javascript.jscomp.Compiler.MOTION_ITERATIONS_ERROR;
        com.google.javascript.jscomp.DiagnosticType diagnosticType6 = com.google.javascript.jscomp.DiagnosticType.disabled("hi!", "hi!");
        java.lang.String[] strArray8 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError9 = com.google.javascript.jscomp.JSError.make(diagnosticType6, strArray8);
        com.google.javascript.jscomp.JSError jSError10 = com.google.javascript.jscomp.JSError.make("hi!. hi! at (unknown source) line (unknown line) : (unknown column)", (int) ' ', 0, diagnosticType3, strArray8);
        java.lang.String str11 = jSError10.sourceName;
        com.google.javascript.jscomp.CompilerOptions compilerOptions12 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel13 = compilerOptions12.reportMissingOverride;
        compilerOptions12.setAppNameStr("module$STRING hi!");
        boolean boolean16 = compilerOptions12.closurePass;
        boolean boolean17 = jSError10.equals((java.lang.Object) compilerOptions12);
        int int18 = jSError10.getNodeLength();
        org.junit.Assert.assertNotNull(diagnosticType3);
        org.junit.Assert.assertNotNull(diagnosticType6);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertNotNull(jSError9);
        org.junit.Assert.assertNotNull(jSError10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "hi!. hi! at (unknown source) line (unknown line) : (unknown column)" + "'", str11.equals("hi!. hi! at (unknown source) line (unknown line) : (unknown column)"));
        org.junit.Assert.assertTrue("'" + checkLevel13 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel13.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.reportMissingOverride;
        compilerOptions0.setAppNameStr("module$STRING hi!");
        compilerOptions0.setSyntheticBlockEndMarker("module$STRING hi!");
        compilerOptions0.setDisambiguateProperties(true);
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        java.util.logging.Logger logger0 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager1 = new com.google.javascript.jscomp.LoggerErrorManager(logger0);
        double double2 = loggerErrorManager1.getTypedPercent();
        loggerErrorManager1.setTypedPercent(0.0d);
        int int5 = loggerErrorManager1.getWarningCount();
        com.google.javascript.jscomp.JSError[] jSErrorArray6 = loggerErrorManager1.getErrors();
        loggerErrorManager1.setTypedPercent((-1.0d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(jSErrorArray6);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        com.google.javascript.jscomp.SourceFile.Builder builder0 = new com.google.javascript.jscomp.SourceFile.Builder();
        java.nio.charset.Charset charset1 = null;
        com.google.javascript.jscomp.SourceFile.Builder builder2 = builder0.withCharset(charset1);
        java.io.Reader reader4 = null;
        try {
            com.google.javascript.jscomp.SourceFile sourceFile5 = builder0.buildFromReader("", reader4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(builder2);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.reportMissingOverride;
        compilerOptions0.setAppNameStr("module$STRING hi!");
        boolean boolean4 = compilerOptions0.crossModuleMethodMotion;
        boolean boolean5 = compilerOptions0.computeFunctionSideEffects;
        compilerOptions0.reserveRawExports = false;
        compilerOptions0.setLocale("");
        compilerOptions0.generatePseudoNames = false;
        compilerOptions0.removeUnusedVars = true;
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean2 = node1.isFor();
        boolean boolean3 = node1.isExprResult();
        java.lang.String str4 = node1.getString();
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean7 = node6.isFor();
        boolean boolean8 = node6.isExprResult();
        com.google.javascript.rhino.Node node9 = node1.clonePropsFrom(node6);
        boolean boolean10 = node9.isVar();
        com.google.javascript.rhino.Node node14 = new com.google.javascript.rhino.Node((int) (byte) 100, (int) (byte) 1, 54);
        boolean boolean15 = node14.isReturn();
        boolean boolean16 = node9.hasChild(node14);
        com.google.javascript.jscomp.CodingConvention codingConvention17 = com.google.javascript.jscomp.CodingConventions.getDefault();
        com.google.javascript.rhino.Node node19 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode(codingConvention17, "./");
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.IR.throwNode(node19);
        node20.setSourceEncodedPosition(38);
        int int23 = node14.getIndexOfChild(node20);
        try {
            double double24 = node14.getDouble();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: OR 1 is not a number node");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "hi!" + "'", str4.equals("hi!"));
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(codingConvention17);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.UNDEFINED_NAMES;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean2 = node1.isFor();
        boolean boolean3 = node1.isExprResult();
        java.lang.String str4 = node1.getString();
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean7 = node6.isFor();
        boolean boolean8 = node6.isExprResult();
        com.google.javascript.rhino.Node node9 = node1.clonePropsFrom(node6);
        boolean boolean10 = node9.isVar();
        com.google.javascript.rhino.Node node14 = new com.google.javascript.rhino.Node((int) (byte) 100, (int) (byte) 1, 54);
        boolean boolean15 = node14.isReturn();
        boolean boolean16 = node9.hasChild(node14);
        try {
            com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.IR.block(node14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "hi!" + "'", str4.equals("hi!"));
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        long long1 = com.google.javascript.rhino.ScriptRuntime.testUint32String("Named type with empty name component");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1L) + "'", long1 == (-1L));
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.reportMissingOverride;
        compilerOptions0.setAppNameStr("module$STRING hi!");
        boolean boolean4 = compilerOptions0.extractPrototypeMemberDeclarations;
        compilerOptions0.removeUnusedPrototypeProperties = false;
        java.lang.String str7 = compilerOptions0.instrumentationTemplate;
        com.google.javascript.jscomp.CompilerOptions.AliasTransformationHandler aliasTransformationHandler8 = compilerOptions0.getAliasTransformationHandler();
        com.google.javascript.rhino.SourcePosition<com.google.javascript.jscomp.CompilerOptions.AliasTransformation> aliasTransformationSourcePosition10 = null;
        try {
            com.google.javascript.jscomp.CompilerOptions.AliasTransformation aliasTransformation11 = aliasTransformationHandler8.logAliasTransformation("STRING hi!", aliasTransformationSourcePosition10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertNotNull(aliasTransformationHandler8);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.reportMissingOverride;
        java.lang.String[] strArray8 = new java.lang.String[] { "STRING hi!", "hi!. hi! at (unknown source) line (unknown line) : (unknown column)", "module$STRING hi!", "hi!", "", "STRING hi!" };
        java.util.LinkedHashSet<java.lang.String> strSet9 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean10 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet9, strArray8);
        compilerOptions0.setIdGenerators((java.util.Set<java.lang.String>) strSet9);
        compilerOptions0.setAliasExternals(false);
        com.google.javascript.jscomp.CompilerOptions.TracerMode tracerMode14 = null;
        compilerOptions0.setTracer(tracerMode14);
        boolean boolean16 = compilerOptions0.removeUnusedLocalVars;
        com.google.javascript.jscomp.CheckLevel checkLevel17 = null;
        compilerOptions0.checkGlobalNamesLevel = checkLevel17;
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        int int0 = com.google.javascript.rhino.Node.IS_VAR_ARGS_PARAM;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 45 + "'", int0 == 45);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.reportMissingOverride;
        compilerOptions0.setAppNameStr("module$STRING hi!");
        boolean boolean4 = compilerOptions0.foldConstants;
        compilerOptions0.removeUnusedVars = true;
        java.lang.String str7 = compilerOptions0.aliasStringsBlacklist;
        com.google.javascript.jscomp.CompilerOptions.TracerMode tracerMode8 = com.google.javascript.jscomp.CompilerOptions.TracerMode.OFF;
        compilerOptions0.setTracerMode(tracerMode8);
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + tracerMode8 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TracerMode.OFF + "'", tracerMode8.equals(com.google.javascript.jscomp.CompilerOptions.TracerMode.OFF));
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newString("Unknown class name");
        com.google.javascript.rhino.Node.AncestorIterable ancestorIterable2 = node1.getAncestors();
        java.util.Iterator<com.google.javascript.rhino.Node> nodeItor3 = ancestorIterable2.iterator();
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertNotNull(ancestorIterable2);
        org.junit.Assert.assertNotNull(nodeItor3);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean3 = node2.isFor();
        boolean boolean4 = node2.isExprResult();
        java.lang.String str5 = node2.getString();
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean8 = node7.isFor();
        boolean boolean9 = node7.isExprResult();
        com.google.javascript.rhino.Node node10 = node2.clonePropsFrom(node7);
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean13 = node12.isFor();
        boolean boolean14 = node12.isExprResult();
        java.lang.String str15 = node12.getString();
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean18 = node17.isFor();
        boolean boolean19 = node17.isExprResult();
        com.google.javascript.rhino.Node node20 = node12.clonePropsFrom(node17);
        int int21 = node7.getIndexOfChild(node12);
        com.google.javascript.rhino.Node node22 = node7.cloneTree();
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.IR.returnNode(node22);
        com.google.javascript.rhino.Node node26 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean27 = node26.isFor();
        boolean boolean28 = node26.isExprResult();
        java.lang.String str29 = node26.getString();
        com.google.javascript.rhino.Node node31 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean32 = node31.isFor();
        boolean boolean33 = node31.isExprResult();
        com.google.javascript.rhino.Node node34 = node26.clonePropsFrom(node31);
        com.google.javascript.rhino.Node node36 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean37 = node36.isFor();
        boolean boolean38 = node36.isExprResult();
        java.lang.String str39 = node36.getString();
        com.google.javascript.rhino.Node node41 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean42 = node41.isFor();
        boolean boolean43 = node41.isExprResult();
        com.google.javascript.rhino.Node node44 = node36.clonePropsFrom(node41);
        boolean boolean45 = node44.isVar();
        node44.setSourceEncodedPositionForTree(16);
        com.google.javascript.rhino.Node node48 = new com.google.javascript.rhino.Node(10, node31, node44);
        com.google.javascript.rhino.Node node49 = node48.cloneTree();
        com.google.javascript.rhino.Node node50 = null;
        com.google.javascript.rhino.Node node52 = com.google.javascript.rhino.Node.newNumber(0.0d);
        com.google.javascript.rhino.Node node53 = com.google.javascript.rhino.IR.returnNode(node52);
        node53.setOptionalArg(true);
        try {
            com.google.javascript.rhino.Node node58 = new com.google.javascript.rhino.Node((int) (byte) 1, node23, node49, node50, node53, 16, (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "hi!" + "'", str15.equals("hi!"));
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "hi!" + "'", str29.equals("hi!"));
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(node34);
        org.junit.Assert.assertNotNull(node36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "hi!" + "'", str39.equals("hi!"));
        org.junit.Assert.assertNotNull(node41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(node44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(node49);
        org.junit.Assert.assertNotNull(node52);
        org.junit.Assert.assertNotNull(node53);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.reportMissingOverride;
        compilerOptions0.setAppNameStr("module$STRING hi!");
        boolean boolean4 = compilerOptions0.crossModuleMethodMotion;
        boolean boolean5 = compilerOptions0.computeFunctionSideEffects;
        compilerOptions0.locale = "module$STRING hi!";
        com.google.javascript.jscomp.CheckLevel checkLevel8 = null;
        compilerOptions0.aggressiveVarCheck = checkLevel8;
        java.lang.String str10 = compilerOptions0.syntheticBlockEndMarker;
        compilerOptions0.crossModuleCodeMotion = false;
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(str10);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray0 = new com.google.javascript.jscomp.WarningsGuard[] {};
        java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard> warningsGuardList1 = new java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList1, warningsGuardArray0);
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard3 = new com.google.javascript.jscomp.ComposeWarningsGuard((java.util.List<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList1);
        com.google.javascript.jscomp.DiagnosticType diagnosticType6 = com.google.javascript.jscomp.DiagnosticType.disabled("hi!", "hi!");
        java.lang.String[] strArray8 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError9 = com.google.javascript.jscomp.JSError.make(diagnosticType6, strArray8);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup10 = com.google.javascript.jscomp.DiagnosticGroups.CONST;
        boolean boolean11 = jSError9.equals((java.lang.Object) diagnosticGroup10);
        int int12 = jSError9.getNodeSourceOffset();
        com.google.javascript.jscomp.CheckLevel checkLevel13 = composeWarningsGuard3.level(jSError9);
        org.junit.Assert.assertNotNull(warningsGuardArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(diagnosticType6);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertNotNull(jSError9);
        org.junit.Assert.assertNotNull(diagnosticGroup10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertNull(checkLevel13);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        int int0 = com.google.javascript.rhino.Node.SIDE_EFFECTS_FLAGS_MASK;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 31 + "'", int0 == 31);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        com.google.javascript.jscomp.CodingConvention codingConvention0 = com.google.javascript.jscomp.CodingConventions.getDefault();
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention1 = new com.google.javascript.jscomp.ClosureCodingConvention(codingConvention0);
        boolean boolean3 = closureCodingConvention1.isExported("");
        java.lang.String str4 = closureCodingConvention1.getGlobalObject();
        boolean boolean7 = closureCodingConvention1.isExported("module$STRING hi!", true);
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean10 = node9.isFor();
        boolean boolean11 = node9.isExprResult();
        java.lang.String str12 = node9.getString();
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean15 = node14.isFor();
        boolean boolean16 = node14.isExprResult();
        com.google.javascript.rhino.Node node17 = node9.clonePropsFrom(node14);
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean20 = node19.isFor();
        boolean boolean21 = node19.isExprResult();
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean24 = node23.isFor();
        com.google.javascript.rhino.Node node25 = node19.clonePropsFrom(node23);
        node23.addSuppression("module$STRING hi!");
        com.google.javascript.rhino.Node node29 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean30 = node29.isFor();
        boolean boolean31 = node29.isExprResult();
        java.lang.String str32 = node29.getString();
        com.google.javascript.rhino.Node node34 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean35 = node34.isFor();
        boolean boolean36 = node34.isExprResult();
        com.google.javascript.rhino.Node node37 = node29.clonePropsFrom(node34);
        com.google.javascript.rhino.Node node39 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean40 = node39.isFor();
        boolean boolean41 = node39.isExprResult();
        java.lang.String str42 = node39.getString();
        com.google.javascript.rhino.Node node44 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean45 = node44.isFor();
        boolean boolean46 = node44.isExprResult();
        com.google.javascript.rhino.Node node47 = node39.clonePropsFrom(node44);
        int int48 = node34.getIndexOfChild(node39);
        com.google.javascript.rhino.Node node49 = node34.cloneTree();
        com.google.javascript.rhino.Node node50 = com.google.javascript.rhino.IR.comma(node23, node49);
        com.google.javascript.rhino.Node node51 = com.google.javascript.rhino.IR.sheq(node9, node50);
        com.google.javascript.jscomp.CodingConvention.SubclassRelationship subclassRelationship52 = closureCodingConvention1.getClassesDefinedByCall(node50);
        org.junit.Assert.assertNotNull(codingConvention0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "goog.global" + "'", str4.equals("goog.global"));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "hi!" + "'", str12.equals("hi!"));
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "hi!" + "'", str32.equals("hi!"));
        org.junit.Assert.assertNotNull(node34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(node37);
        org.junit.Assert.assertNotNull(node39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "hi!" + "'", str42.equals("hi!"));
        org.junit.Assert.assertNotNull(node44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(node47);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + (-1) + "'", int48 == (-1));
        org.junit.Assert.assertNotNull(node49);
        org.junit.Assert.assertNotNull(node50);
        org.junit.Assert.assertNotNull(node51);
        org.junit.Assert.assertNull(subclassRelationship52);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.reportMissingOverride;
        compilerOptions0.setAppNameStr("module$STRING hi!");
        boolean boolean4 = compilerOptions0.crossModuleMethodMotion;
        boolean boolean5 = compilerOptions0.computeFunctionSideEffects;
        com.google.javascript.jscomp.CompilerOptions compilerOptions6 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel7 = compilerOptions6.reportMissingOverride;
        com.google.javascript.jscomp.CompilerOptions.LanguageMode languageMode8 = com.google.javascript.jscomp.CompilerOptions.LanguageMode.ECMASCRIPT5;
        compilerOptions6.setLanguageIn(languageMode8);
        compilerOptions0.setLanguageIn(languageMode8);
        compilerOptions0.deadAssignmentElimination = false;
        compilerOptions0.markAsCompiled = false;
        com.google.javascript.jscomp.CompilerOptions compilerOptions15 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel16 = compilerOptions15.reportMissingOverride;
        compilerOptions15.setAppNameStr("module$STRING hi!");
        boolean boolean19 = compilerOptions15.crossModuleMethodMotion;
        boolean boolean20 = compilerOptions15.computeFunctionSideEffects;
        compilerOptions15.locale = "module$STRING hi!";
        compilerOptions15.setComputeFunctionSideEffects(true);
        compilerOptions15.setAliasableGlobals("hi!");
        com.google.javascript.jscomp.CompilerOptions compilerOptions27 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel28 = compilerOptions27.reportMissingOverride;
        compilerOptions15.checkUnreachableCode = checkLevel28;
        com.google.javascript.jscomp.CompilerOptions compilerOptions30 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel31 = compilerOptions30.reportMissingOverride;
        compilerOptions30.setAppNameStr("module$STRING hi!");
        boolean boolean34 = compilerOptions30.crossModuleMethodMotion;
        boolean boolean35 = compilerOptions30.computeFunctionSideEffects;
        compilerOptions30.locale = "module$STRING hi!";
        compilerOptions30.setComputeFunctionSideEffects(true);
        compilerOptions30.setAliasableGlobals("hi!");
        com.google.javascript.jscomp.CompilerOptions compilerOptions42 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel43 = compilerOptions42.reportMissingOverride;
        compilerOptions30.checkUnreachableCode = checkLevel43;
        compilerOptions15.checkMissingGetCssNameLevel = checkLevel43;
        compilerOptions0.checkUnreachableCode = checkLevel43;
        com.google.javascript.jscomp.CheckLevel checkLevel47 = com.google.javascript.jscomp.CheckLevel.OFF;
        compilerOptions0.brokenClosureRequiresLevel = checkLevel47;
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + checkLevel7 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel7.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + languageMode8 + "' != '" + com.google.javascript.jscomp.CompilerOptions.LanguageMode.ECMASCRIPT5 + "'", languageMode8.equals(com.google.javascript.jscomp.CompilerOptions.LanguageMode.ECMASCRIPT5));
        org.junit.Assert.assertTrue("'" + checkLevel16 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel16.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + checkLevel28 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel28.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + checkLevel31 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel31.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + checkLevel43 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel43.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + checkLevel47 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel47.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.reportMissingOverride;
        compilerOptions0.setAppNameStr("module$STRING hi!");
        boolean boolean4 = compilerOptions0.crossModuleMethodMotion;
        boolean boolean5 = compilerOptions0.computeFunctionSideEffects;
        boolean boolean6 = compilerOptions0.removeUnusedLocalVars;
        boolean boolean7 = compilerOptions0.foldConstants;
        com.google.javascript.jscomp.ErrorFormat errorFormat8 = com.google.javascript.jscomp.ErrorFormat.LEGACY;
        compilerOptions0.errorFormat = errorFormat8;
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(errorFormat8);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.CHECK_TYPES;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        com.google.javascript.jscomp.CodingConvention codingConvention0 = com.google.javascript.jscomp.CodingConventions.getDefault();
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention1 = new com.google.javascript.jscomp.ClosureCodingConvention(codingConvention0);
        boolean boolean4 = closureCodingConvention1.isExported("hi!", true);
        java.lang.String str5 = closureCodingConvention1.getDelegateSuperclassName();
        com.google.javascript.rhino.jstype.FunctionType functionType6 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType7 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType8 = null;
        closureCodingConvention1.applySubclassRelationship(functionType6, functionType7, subclassType8);
        org.junit.Assert.assertNotNull(codingConvention0);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(str5);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        com.google.javascript.jscomp.SourceFile sourceFile1 = com.google.javascript.jscomp.SourceFile.fromFile("hi!");
        boolean boolean2 = sourceFile1.isExtern();
        java.lang.String str4 = sourceFile1.getLine((int) (short) 0);
        try {
            java.lang.String str5 = sourceFile1.getCode();
            org.junit.Assert.fail("Expected exception of type java.io.FileNotFoundException; message: hi! (No such file or directory)");
        } catch (java.io.FileNotFoundException e) {
        }
        org.junit.Assert.assertNotNull(sourceFile1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.TYPE_INVALIDATION;
        com.google.javascript.jscomp.DiagnosticGroups.ES5_STRICT = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticGroups.TYPE_INVALIDATION = diagnosticGroup0;
        org.junit.Assert.assertNull(diagnosticGroup0);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.TWEAKS;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean3 = node2.isFor();
        boolean boolean4 = node2.isExprResult();
        java.lang.String str5 = node2.getString();
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean8 = node7.isFor();
        boolean boolean9 = node7.isExprResult();
        com.google.javascript.rhino.Node node10 = node2.clonePropsFrom(node7);
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean13 = node12.isFor();
        boolean boolean14 = node12.isExprResult();
        java.lang.String str15 = node12.getString();
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean18 = node17.isFor();
        boolean boolean19 = node17.isExprResult();
        com.google.javascript.rhino.Node node20 = node12.clonePropsFrom(node17);
        boolean boolean21 = node20.isVar();
        node20.setSourceEncodedPositionForTree(16);
        com.google.javascript.rhino.Node node24 = new com.google.javascript.rhino.Node(10, node7, node20);
        com.google.javascript.jscomp.SourceFile sourceFile26 = com.google.javascript.jscomp.SourceFile.fromFile("hi!");
        node24.setStaticSourceFile((com.google.javascript.rhino.jstype.StaticSourceFile) sourceFile26);
        com.google.javascript.rhino.Node node28 = com.google.javascript.rhino.IR.paramList();
        com.google.javascript.rhino.Node node29 = node24.srcref(node28);
        node28.detachChildren();
        boolean boolean31 = node28.isGetterDef();
        boolean boolean32 = node28.isIn();
        node28.putBooleanProp(10, false);
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "hi!" + "'", str15.equals("hi!"));
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(sourceFile26);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.reportMissingOverride;
        compilerOptions0.setAppNameStr("module$STRING hi!");
        boolean boolean4 = compilerOptions0.crossModuleMethodMotion;
        boolean boolean5 = compilerOptions0.computeFunctionSideEffects;
        byte[] byteArray6 = compilerOptions0.inputVariableMapSerialized;
        byte[] byteArray7 = compilerOptions0.inputVariableMapSerialized;
        compilerOptions0.setReserveRawExports(false);
        boolean boolean10 = compilerOptions0.optimizeReturns;
        com.google.javascript.jscomp.CompilerOptions compilerOptions11 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel12 = compilerOptions11.reportMissingOverride;
        compilerOptions11.setAppNameStr("module$STRING hi!");
        boolean boolean15 = compilerOptions11.crossModuleMethodMotion;
        boolean boolean16 = compilerOptions11.computeFunctionSideEffects;
        compilerOptions11.locale = "module$STRING hi!";
        compilerOptions11.setComputeFunctionSideEffects(true);
        compilerOptions11.setAliasableGlobals("hi!");
        com.google.javascript.jscomp.CompilerOptions compilerOptions23 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel24 = compilerOptions23.reportMissingOverride;
        compilerOptions11.checkUnreachableCode = checkLevel24;
        com.google.javascript.jscomp.CompilerOptions compilerOptions26 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel27 = compilerOptions26.reportMissingOverride;
        compilerOptions26.setAppNameStr("module$STRING hi!");
        boolean boolean30 = compilerOptions26.crossModuleMethodMotion;
        boolean boolean31 = compilerOptions26.computeFunctionSideEffects;
        compilerOptions26.locale = "module$STRING hi!";
        compilerOptions26.setComputeFunctionSideEffects(true);
        compilerOptions26.setAliasableGlobals("hi!");
        com.google.javascript.jscomp.CompilerOptions compilerOptions38 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel39 = compilerOptions38.reportMissingOverride;
        compilerOptions26.checkUnreachableCode = checkLevel39;
        compilerOptions11.checkMissingGetCssNameLevel = checkLevel39;
        java.util.Set<java.lang.String> strSet42 = compilerOptions11.stripTypes;
        compilerOptions0.setIdGenerators(strSet42);
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(byteArray6);
        org.junit.Assert.assertNull(byteArray7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + checkLevel12 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel12.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + checkLevel24 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel24.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + checkLevel27 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel27.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + checkLevel39 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel39.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(strSet42);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.reportMissingOverride;
        compilerOptions0.setAppNameStr("module$STRING hi!");
        compilerOptions0.setOutputJsStringUsage(true);
        java.util.Set<java.lang.String> strSet6 = null;
        compilerOptions0.setStripTypes(strSet6);
        compilerOptions0.checkMissingGetCssNameBlacklist = "";
        com.google.javascript.jscomp.CompilerOptions.TracerMode tracerMode10 = null;
        compilerOptions0.setTracerMode(tracerMode10);
        java.util.Set<java.lang.String> strSet12 = compilerOptions0.stripTypes;
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNull(strSet12);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setRewriteFunctionExpressions(true);
        compilerOptions0.setInstrumentationTemplate("// Input %num%");
        com.google.javascript.jscomp.CompilerOptions.TracerMode tracerMode5 = null;
        compilerOptions0.setTracer(tracerMode5);
        compilerOptions0.setMoveFunctionDeclarations(false);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newString("hi!");
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.IR.voidNode(node1);
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean5 = node4.isFor();
        boolean boolean6 = node4.isExprResult();
        java.lang.String str7 = node4.getString();
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean10 = node9.isFor();
        boolean boolean11 = node9.isExprResult();
        com.google.javascript.rhino.Node node12 = node4.clonePropsFrom(node9);
        boolean boolean13 = node1.isEquivalentToTyped(node4);
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean16 = node15.isFor();
        boolean boolean17 = node15.isExprResult();
        int int18 = node15.getSourcePosition();
        com.google.javascript.rhino.Node node19 = node1.useSourceInfoIfMissingFrom(node15);
        node15.setWasEmptyNode(false);
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "hi!" + "'", str7.equals("hi!"));
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertNotNull(node19);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        com.google.javascript.jscomp.SourceFile.Generator generator1 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("goog.global", generator1);
        jSSourceFile2.clearCachedSource();
        java.lang.String str4 = jSSourceFile2.getOriginalPath();
        org.junit.Assert.assertNotNull(jSSourceFile2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "goog.global" + "'", str4.equals("goog.global"));
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.reportMissingOverride;
        compilerOptions0.setAppNameStr("module$STRING hi!");
        boolean boolean4 = compilerOptions0.inlineConstantVars;
        java.util.Map<java.lang.String, java.lang.Object> strMap5 = null;
        compilerOptions0.setDefineReplacements(strMap5);
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile1 = com.google.javascript.jscomp.JSSourceFile.fromFile("goog.global");
        com.google.javascript.jscomp.Region region3 = jSSourceFile1.getRegion((int) (byte) 1);
        try {
            java.lang.String str4 = jSSourceFile1.getCode();
            org.junit.Assert.fail("Expected exception of type java.io.FileNotFoundException; message: goog.global (No such file or directory)");
        } catch (java.io.FileNotFoundException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile1);
        org.junit.Assert.assertNull(region3);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        java.util.logging.Logger logger0 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager1 = new com.google.javascript.jscomp.LoggerErrorManager(logger0);
        double double2 = loggerErrorManager1.getTypedPercent();
        com.google.javascript.jscomp.Compiler compiler3 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager1);
        com.google.javascript.jscomp.Result result4 = compiler3.getResult();
        java.lang.String str5 = compiler3.getAstDotGraph();
        com.google.javascript.jscomp.JSError[] jSErrorArray6 = compiler3.getWarnings();
        com.google.javascript.jscomp.JSError[] jSErrorArray7 = compiler3.getWarnings();
        com.google.javascript.jscomp.SourceMap sourceMap8 = compiler3.getSourceMap();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(result4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertNotNull(jSErrorArray6);
        org.junit.Assert.assertNotNull(jSErrorArray7);
        org.junit.Assert.assertNull(sourceMap8);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean2 = node1.isFor();
        boolean boolean3 = node1.isExprResult();
        java.lang.String str4 = node1.getString();
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean7 = node6.isFor();
        boolean boolean8 = node6.isExprResult();
        com.google.javascript.rhino.Node node9 = node1.clonePropsFrom(node6);
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.IR.pos(node1);
        com.google.javascript.rhino.Node node11 = null;
        try {
            com.google.javascript.rhino.Node node12 = node10.clonePropsFrom(node11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "hi!" + "'", str4.equals("hi!"));
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node10);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.reportMissingOverride;
        compilerOptions0.setAppNameStr("module$STRING hi!");
        boolean boolean4 = compilerOptions0.crossModuleMethodMotion;
        boolean boolean5 = compilerOptions0.computeFunctionSideEffects;
        compilerOptions0.reserveRawExports = false;
        compilerOptions0.setLocale("");
        java.lang.String str10 = compilerOptions0.sourceMapOutputPath;
        compilerOptions0.setDebugFunctionSideEffectsPath("InputId: ");
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap13 = null;
        compilerOptions0.cssRenamingMap = cssRenamingMap13;
        com.google.javascript.jscomp.CompilerOptions compilerOptions15 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel16 = compilerOptions15.reportMissingOverride;
        java.lang.String[] strArray23 = new java.lang.String[] { "STRING hi!", "hi!. hi! at (unknown source) line (unknown line) : (unknown column)", "module$STRING hi!", "hi!", "", "STRING hi!" };
        java.util.LinkedHashSet<java.lang.String> strSet24 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean25 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet24, strArray23);
        compilerOptions15.setIdGenerators((java.util.Set<java.lang.String>) strSet24);
        compilerOptions0.setExtraAnnotationNames((java.util.Set<java.lang.String>) strSet24);
        compilerOptions0.setAssumeStrictThis(false);
        compilerOptions0.setExternExports(true);
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertTrue("'" + checkLevel16 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel16.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(strArray23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.reportMissingOverride;
        compilerOptions0.setAppNameStr("module$STRING hi!");
        boolean boolean4 = compilerOptions0.crossModuleMethodMotion;
        boolean boolean5 = compilerOptions0.computeFunctionSideEffects;
        compilerOptions0.reserveRawExports = false;
        compilerOptions0.closurePass = false;
        compilerOptions0.reserveRawExports = false;
        compilerOptions0.setChainCalls(true);
        com.google.javascript.jscomp.CompilerOptions.TweakProcessing tweakProcessing14 = compilerOptions0.getTweakProcessing();
        boolean boolean15 = tweakProcessing14.shouldStrip();
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + tweakProcessing14 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TweakProcessing.OFF + "'", tweakProcessing14.equals(com.google.javascript.jscomp.CompilerOptions.TweakProcessing.OFF));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.reportMissingOverride;
        compilerOptions0.setAppNameStr("module$STRING hi!");
        compilerOptions0.setOutputJsStringUsage(true);
        compilerOptions0.resetWarningsGuard();
        compilerOptions0.setGenerateExports(false);
        com.google.javascript.jscomp.CompilerOptions compilerOptions9 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap10 = compilerOptions9.cssRenamingMap;
        com.google.javascript.jscomp.CompilerOptions compilerOptions11 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel12 = compilerOptions11.reportMissingOverride;
        compilerOptions11.setAppNameStr("module$STRING hi!");
        boolean boolean15 = compilerOptions11.crossModuleMethodMotion;
        boolean boolean16 = compilerOptions11.computeFunctionSideEffects;
        boolean boolean17 = compilerOptions11.removeUnusedLocalVars;
        com.google.javascript.jscomp.CompilerOptions compilerOptions18 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel19 = compilerOptions18.reportMissingOverride;
        compilerOptions11.setCheckUnreachableCode(checkLevel19);
        compilerOptions9.setCheckProvides(checkLevel19);
        compilerOptions0.setCheckProvides(checkLevel19);
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNull(cssRenamingMap10);
        org.junit.Assert.assertTrue("'" + checkLevel12 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel12.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + checkLevel19 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel19.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        com.google.javascript.jscomp.SourceFile sourceFile1 = com.google.javascript.jscomp.SourceFile.fromFile("hi!");
        boolean boolean2 = sourceFile1.isExtern();
        com.google.javascript.jscomp.JsAst jsAst3 = new com.google.javascript.jscomp.JsAst(sourceFile1);
        java.util.logging.Logger logger4 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager5 = new com.google.javascript.jscomp.LoggerErrorManager(logger4);
        double double6 = loggerErrorManager5.getTypedPercent();
        com.google.javascript.jscomp.Compiler compiler7 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager5);
        com.google.javascript.jscomp.Result result8 = compiler7.getResult();
        java.util.logging.Logger logger9 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager10 = new com.google.javascript.jscomp.LoggerErrorManager(logger9);
        double double11 = loggerErrorManager10.getTypedPercent();
        compiler7.setErrorManager((com.google.javascript.jscomp.ErrorManager) loggerErrorManager10);
        com.google.javascript.jscomp.NodeTraversal.Callback callback13 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal14 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler7, callback13);
        com.google.javascript.jscomp.Scope scope15 = compiler7.getTopScope();
        com.google.javascript.rhino.Node node16 = jsAst3.getAstRoot((com.google.javascript.jscomp.AbstractCompiler) compiler7);
        java.lang.String str19 = compiler7.getSourceLine("// Input %num%", (-1));
        double double20 = compiler7.getProgress();
        com.google.javascript.jscomp.PerformanceTracker performanceTracker21 = null;
        compiler7.tracker = performanceTracker21;
        com.google.javascript.jscomp.NodeTraversal.Callback callback23 = null;
        java.util.logging.Logger logger25 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager26 = new com.google.javascript.jscomp.LoggerErrorManager(logger25);
        double double27 = loggerErrorManager26.getTypedPercent();
        com.google.javascript.jscomp.Compiler compiler28 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager26);
        com.google.javascript.jscomp.Result result29 = compiler28.getResult();
        java.util.logging.Logger logger30 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager31 = new com.google.javascript.jscomp.LoggerErrorManager(logger30);
        double double32 = loggerErrorManager31.getTypedPercent();
        compiler28.setErrorManager((com.google.javascript.jscomp.ErrorManager) loggerErrorManager31);
        com.google.javascript.jscomp.NodeTraversal.Callback callback34 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal35 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler28, callback34);
        com.google.javascript.rhino.Node node36 = nodeTraversal35.getEnclosingFunction();
        java.util.logging.Logger logger37 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager38 = new com.google.javascript.jscomp.LoggerErrorManager(logger37);
        double double39 = loggerErrorManager38.getTypedPercent();
        com.google.javascript.jscomp.Compiler compiler40 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager38);
        com.google.javascript.jscomp.Result result41 = compiler40.getResult();
        java.util.logging.Logger logger42 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager43 = new com.google.javascript.jscomp.LoggerErrorManager(logger42);
        double double44 = loggerErrorManager43.getTypedPercent();
        compiler40.setErrorManager((com.google.javascript.jscomp.ErrorManager) loggerErrorManager43);
        com.google.javascript.jscomp.NodeTraversal.Callback callback46 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal47 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler40, callback46);
        com.google.javascript.rhino.Node[] nodeArray48 = new com.google.javascript.rhino.Node[] {};
        nodeTraversal47.traverseRoots(nodeArray48);
        nodeTraversal35.traverseRoots(nodeArray48);
        com.google.javascript.rhino.Node node51 = com.google.javascript.rhino.IR.block(nodeArray48);
        com.google.javascript.rhino.Node node52 = new com.google.javascript.rhino.Node((int) (byte) 10, nodeArray48);
        com.google.javascript.jscomp.NodeTraversal.traverseRoots((com.google.javascript.jscomp.AbstractCompiler) compiler7, callback23, nodeArray48);
        try {
            boolean boolean54 = compiler7.acceptConstKeyword();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(sourceFile1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(result8);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNull(scope15);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertNull(str19);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertNotNull(result29);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
        org.junit.Assert.assertNull(node36);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
        org.junit.Assert.assertNotNull(result41);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 0.0d + "'", double44 == 0.0d);
        org.junit.Assert.assertNotNull(nodeArray48);
        org.junit.Assert.assertNotNull(node51);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.reportMissingOverride;
        compilerOptions0.setAppNameStr("module$STRING hi!");
        boolean boolean4 = compilerOptions0.crossModuleMethodMotion;
        boolean boolean5 = compilerOptions0.computeFunctionSideEffects;
        boolean boolean6 = compilerOptions0.removeUnusedLocalVars;
        com.google.javascript.jscomp.CompilerOptions compilerOptions7 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel8 = compilerOptions7.reportMissingOverride;
        compilerOptions0.setCheckUnreachableCode(checkLevel8);
        com.google.javascript.jscomp.CompilerOptions compilerOptions10 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel11 = compilerOptions10.reportMissingOverride;
        compilerOptions10.setAppNameStr("module$STRING hi!");
        boolean boolean14 = compilerOptions10.crossModuleMethodMotion;
        boolean boolean15 = compilerOptions10.computeFunctionSideEffects;
        compilerOptions10.locale = "module$STRING hi!";
        compilerOptions10.setComputeFunctionSideEffects(true);
        compilerOptions10.setAliasableGlobals("hi!");
        com.google.javascript.jscomp.CompilerOptions compilerOptions22 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel23 = compilerOptions22.reportMissingOverride;
        compilerOptions10.checkUnreachableCode = checkLevel23;
        compilerOptions0.setReportMissingOverride(checkLevel23);
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + checkLevel8 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel8.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + checkLevel11 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel11.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + checkLevel23 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel23.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.reportMissingOverride;
        compilerOptions0.setAppNameStr("module$STRING hi!");
        boolean boolean4 = compilerOptions0.crossModuleMethodMotion;
        boolean boolean5 = compilerOptions0.computeFunctionSideEffects;
        byte[] byteArray6 = compilerOptions0.inputVariableMapSerialized;
        byte[] byteArray7 = compilerOptions0.inputVariableMapSerialized;
        compilerOptions0.setInstrumentationTemplate("goog.global");
        com.google.javascript.jscomp.CompilerOptions compilerOptions10 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel11 = compilerOptions10.reportMissingOverride;
        compilerOptions10.setAppNameStr("module$STRING hi!");
        boolean boolean14 = compilerOptions10.crossModuleMethodMotion;
        boolean boolean15 = compilerOptions10.computeFunctionSideEffects;
        compilerOptions10.reserveRawExports = false;
        compilerOptions10.setLocale("");
        java.util.List<com.google.javascript.jscomp.SourceMap.LocationMapping> locationMappingList20 = compilerOptions10.sourceMapLocationMappings;
        compilerOptions0.setSourceMapLocationMappings(locationMappingList20);
        boolean boolean22 = compilerOptions0.flowSensitiveInlineVariables;
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(byteArray6);
        org.junit.Assert.assertNull(byteArray7);
        org.junit.Assert.assertTrue("'" + checkLevel11 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel11.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(locationMappingList20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        com.google.javascript.jscomp.SourceFile sourceFile1 = com.google.javascript.jscomp.SourceFile.fromFile("hi!");
        boolean boolean2 = sourceFile1.isExtern();
        com.google.javascript.jscomp.JsAst jsAst3 = new com.google.javascript.jscomp.JsAst(sourceFile1);
        com.google.javascript.jscomp.CompilerInput compilerInput6 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) jsAst3, "// Input %num%", false);
        com.google.javascript.jscomp.SourceAst sourceAst7 = compilerInput6.getSourceAst();
        com.google.javascript.rhino.InputId inputId9 = new com.google.javascript.rhino.InputId("");
        com.google.javascript.jscomp.CompilerInput compilerInput11 = new com.google.javascript.jscomp.CompilerInput(sourceAst7, inputId9, true);
        com.google.javascript.jscomp.Region region13 = compilerInput11.getRegion((int) (byte) 1);
        com.google.javascript.jscomp.SourceAst sourceAst14 = compilerInput11.getSourceAst();
        org.junit.Assert.assertNotNull(sourceFile1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(sourceAst7);
        org.junit.Assert.assertNull(region13);
        org.junit.Assert.assertNotNull(sourceAst14);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.reportMissingOverride;
        compilerOptions0.setAppNameStr("module$STRING hi!");
        compilerOptions0.setOutputJsStringUsage(true);
        java.util.Set<java.lang.String> strSet6 = compilerOptions0.stripTypePrefixes;
        compilerOptions0.syntheticBlockEndMarker = "Named type with empty name component";
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(strSet6);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.reportMissingOverride;
        com.google.javascript.jscomp.CompilerOptions.LanguageMode languageMode2 = com.google.javascript.jscomp.CompilerOptions.LanguageMode.ECMASCRIPT5;
        compilerOptions0.setLanguageIn(languageMode2);
        compilerOptions0.aliasStringsBlacklist = "InputId: ";
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + languageMode2 + "' != '" + com.google.javascript.jscomp.CompilerOptions.LanguageMode.ECMASCRIPT5 + "'", languageMode2.equals(com.google.javascript.jscomp.CompilerOptions.LanguageMode.ECMASCRIPT5));
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        com.google.javascript.jscomp.SourceFile.Builder builder0 = com.google.javascript.jscomp.SourceFile.builder();
        java.io.File file1 = null;
        try {
            com.google.javascript.jscomp.SourceFile sourceFile2 = builder0.buildFromFile(file1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(builder0);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.reportMissingOverride;
        compilerOptions0.setAppNameStr("module$STRING hi!");
        boolean boolean4 = compilerOptions0.crossModuleMethodMotion;
        boolean boolean5 = compilerOptions0.computeFunctionSideEffects;
        byte[] byteArray6 = compilerOptions0.inputVariableMapSerialized;
        byte[] byteArray7 = compilerOptions0.inputVariableMapSerialized;
        compilerOptions0.setReserveRawExports(false);
        java.lang.String str10 = compilerOptions0.locale;
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(byteArray6);
        org.junit.Assert.assertNull(byteArray7);
        org.junit.Assert.assertNull(str10);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CompilerOptions compilerOptions1 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel2 = compilerOptions1.reportMissingOverride;
        compilerOptions0.setAggressiveVarCheck(checkLevel2);
        boolean boolean4 = compilerOptions0.printInputDelimiter;
        boolean boolean5 = compilerOptions0.shouldColorizeErrorOutput();
        byte[] byteArray6 = null;
        compilerOptions0.setInputPropertyMapSerialized(byteArray6);
        org.junit.Assert.assertTrue("'" + checkLevel2 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel2.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean3 = node2.isFor();
        boolean boolean4 = node2.isExprResult();
        java.lang.String str5 = node2.getString();
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean8 = node7.isFor();
        boolean boolean9 = node7.isExprResult();
        com.google.javascript.rhino.Node node10 = node2.clonePropsFrom(node7);
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean13 = node12.isFor();
        boolean boolean14 = node12.isExprResult();
        java.lang.String str15 = node12.getString();
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean18 = node17.isFor();
        boolean boolean19 = node17.isExprResult();
        com.google.javascript.rhino.Node node20 = node12.clonePropsFrom(node17);
        boolean boolean21 = node20.isVar();
        node20.setSourceEncodedPositionForTree(16);
        com.google.javascript.rhino.Node node24 = new com.google.javascript.rhino.Node(10, node7, node20);
        com.google.javascript.rhino.Node node25 = node24.cloneNode();
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable26 = node25.siblings();
        boolean boolean27 = node25.isLabelName();
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "hi!" + "'", str15.equals("hi!"));
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNotNull(nodeIterable26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.reportMissingOverride;
        compilerOptions0.setAppNameStr("module$STRING hi!");
        boolean boolean4 = compilerOptions0.crossModuleMethodMotion;
        boolean boolean5 = compilerOptions0.computeFunctionSideEffects;
        compilerOptions0.reserveRawExports = false;
        compilerOptions0.closurePass = false;
        compilerOptions0.setCollapsePropertiesOnExternTypes(false);
        compilerOptions0.setInlineFunctions(false);
        com.google.javascript.jscomp.CompilerOptions compilerOptions14 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel15 = compilerOptions14.reportMissingOverride;
        compilerOptions14.setAppNameStr("module$STRING hi!");
        boolean boolean18 = compilerOptions14.crossModuleMethodMotion;
        boolean boolean19 = compilerOptions14.computeFunctionSideEffects;
        compilerOptions14.setExportTestFunctions(true);
        com.google.javascript.jscomp.SourceMap.LocationMapping locationMapping24 = new com.google.javascript.jscomp.SourceMap.LocationMapping("STRING hi! [jsdoc_info: JSDocInfo]", "");
        com.google.javascript.jscomp.SourceMap.LocationMapping[] locationMappingArray25 = new com.google.javascript.jscomp.SourceMap.LocationMapping[] { locationMapping24 };
        java.util.ArrayList<com.google.javascript.jscomp.SourceMap.LocationMapping> locationMappingList26 = new java.util.ArrayList<com.google.javascript.jscomp.SourceMap.LocationMapping>();
        boolean boolean27 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.SourceMap.LocationMapping>) locationMappingList26, locationMappingArray25);
        compilerOptions14.sourceMapLocationMappings = locationMappingList26;
        compilerOptions0.sourceMapLocationMappings = locationMappingList26;
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + checkLevel15 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel15.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(locationMappingArray25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean2 = node1.isFor();
        boolean boolean3 = node1.isExprResult();
        java.lang.String str4 = node1.getString();
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean7 = node6.isFor();
        boolean boolean8 = node6.isExprResult();
        com.google.javascript.rhino.Node node9 = node1.clonePropsFrom(node6);
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.IR.pos(node1);
        boolean boolean11 = node1.isWhile();
        boolean boolean12 = node1.isParamList();
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "hi!" + "'", str4.equals("hi!"));
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.reportMissingOverride;
        compilerOptions0.setAppNameStr("module$STRING hi!");
        boolean boolean4 = compilerOptions0.crossModuleMethodMotion;
        boolean boolean5 = compilerOptions0.computeFunctionSideEffects;
        compilerOptions0.locale = "module$STRING hi!";
        java.lang.String str8 = compilerOptions0.inputDelimiter;
        boolean boolean9 = compilerOptions0.inlineGetters;
        com.google.javascript.jscomp.SourceMap.DetailLevel detailLevel10 = com.google.javascript.jscomp.SourceMap.DetailLevel.ALL;
        compilerOptions0.setSourceMapDetailLevel(detailLevel10);
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy12 = compilerOptions0.propertyRenaming;
        compilerOptions0.setUnaliasableGlobals("Unknown class name");
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "// Input %num%" + "'", str8.equals("// Input %num%"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(detailLevel10);
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy12 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.OFF + "'", propertyRenamingPolicy12.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.OFF));
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile0 = null;
        try {
            com.google.javascript.jscomp.CompilerInput compilerInput1 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        com.google.javascript.rhino.Node node0 = null;
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean4 = node3.isFor();
        boolean boolean5 = node3.isExprResult();
        java.lang.String str6 = node3.getString();
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean9 = node8.isFor();
        boolean boolean10 = node8.isExprResult();
        com.google.javascript.rhino.Node node11 = node3.clonePropsFrom(node8);
        boolean boolean12 = node11.isVar();
        com.google.javascript.rhino.Node node16 = new com.google.javascript.rhino.Node((int) (byte) 100, (int) (byte) 1, 54);
        boolean boolean17 = node16.isReturn();
        boolean boolean18 = node11.hasChild(node16);
        int int20 = node16.getIntProp((int) (byte) -1);
        com.google.javascript.rhino.Node node22 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean23 = node22.isFor();
        boolean boolean24 = node22.isExprResult();
        java.lang.String str25 = node22.getString();
        com.google.javascript.rhino.Node node27 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean28 = node27.isFor();
        boolean boolean29 = node27.isExprResult();
        com.google.javascript.rhino.Node node30 = node22.clonePropsFrom(node27);
        com.google.javascript.rhino.Node node32 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean33 = node32.isFor();
        boolean boolean34 = node32.isExprResult();
        java.lang.String str35 = node32.getString();
        com.google.javascript.rhino.Node node37 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean38 = node37.isFor();
        boolean boolean39 = node37.isExprResult();
        com.google.javascript.rhino.Node node40 = node32.clonePropsFrom(node37);
        int int41 = node27.getIndexOfChild(node32);
        com.google.javascript.rhino.Node node42 = new com.google.javascript.rhino.Node(46, node16, node32);
        try {
            com.google.javascript.rhino.Node node43 = com.google.javascript.rhino.IR.add(node0, node42);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "hi!" + "'", str25.equals("hi!"));
        org.junit.Assert.assertNotNull(node27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(node30);
        org.junit.Assert.assertNotNull(node32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "hi!" + "'", str35.equals("hi!"));
        org.junit.Assert.assertNotNull(node37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(node40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + (-1) + "'", int41 == (-1));
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        java.io.File file0 = null;
        try {
            com.google.javascript.jscomp.JSSourceFile jSSourceFile1 = com.google.javascript.jscomp.JSSourceFile.fromFile(file0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        com.google.javascript.jscomp.DiagnosticType diagnosticType2 = com.google.javascript.jscomp.DiagnosticType.error("goog.exportSymbol", "hi!. hi! at (unknown source) line (unknown line) : (unknown column)");
        org.junit.Assert.assertNotNull(diagnosticType2);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        java.util.logging.Logger logger0 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager1 = new com.google.javascript.jscomp.LoggerErrorManager(logger0);
        double double2 = loggerErrorManager1.getTypedPercent();
        com.google.javascript.jscomp.Compiler compiler3 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager1);
        com.google.javascript.jscomp.Result result4 = compiler3.getResult();
        java.util.logging.Logger logger5 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager6 = new com.google.javascript.jscomp.LoggerErrorManager(logger5);
        double double7 = loggerErrorManager6.getTypedPercent();
        compiler3.setErrorManager((com.google.javascript.jscomp.ErrorManager) loggerErrorManager6);
        com.google.javascript.jscomp.NodeTraversal.Callback callback9 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal10 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler3, callback9);
        com.google.javascript.jscomp.Scope scope11 = compiler3.getTopScope();
        com.google.javascript.rhino.Node node12 = compiler3.getRoot();
        compiler3.reportCodeChange();
        com.google.javascript.rhino.Node node14 = compiler3.getRoot();
        try {
            boolean boolean15 = compiler3.hasErrors();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(result4);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNull(scope11);
        org.junit.Assert.assertNull(node12);
        org.junit.Assert.assertNull(node14);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean3 = node2.isFor();
        boolean boolean4 = node2.isExprResult();
        java.lang.String str5 = node2.getString();
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean8 = node7.isFor();
        boolean boolean9 = node7.isExprResult();
        com.google.javascript.rhino.Node node10 = node2.clonePropsFrom(node7);
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean13 = node12.isFor();
        boolean boolean14 = node12.isExprResult();
        java.lang.String str15 = node12.getString();
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean18 = node17.isFor();
        boolean boolean19 = node17.isExprResult();
        com.google.javascript.rhino.Node node20 = node12.clonePropsFrom(node17);
        boolean boolean21 = node20.isVar();
        node20.setSourceEncodedPositionForTree(16);
        com.google.javascript.rhino.Node node24 = new com.google.javascript.rhino.Node(10, node7, node20);
        com.google.javascript.rhino.Node node25 = node24.cloneTree();
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable26 = node24.children();
        boolean boolean27 = node24.hasOneChild();
        boolean boolean28 = node24.isNot();
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "hi!" + "'", str15.equals("hi!"));
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNotNull(nodeIterable26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CompilerOptions compilerOptions1 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel2 = compilerOptions1.reportMissingOverride;
        compilerOptions0.setAggressiveVarCheck(checkLevel2);
        compilerOptions0.optimizeCalls = false;
        com.google.javascript.jscomp.MessageBundle messageBundle6 = null;
        compilerOptions0.messageBundle = messageBundle6;
        org.junit.Assert.assertTrue("'" + checkLevel2 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel2.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.reportMissingOverride;
        compilerOptions0.setAppNameStr("module$STRING hi!");
        boolean boolean4 = compilerOptions0.crossModuleMethodMotion;
        boolean boolean5 = compilerOptions0.computeFunctionSideEffects;
        compilerOptions0.setExportTestFunctions(true);
        com.google.javascript.jscomp.SourceMap.LocationMapping locationMapping10 = new com.google.javascript.jscomp.SourceMap.LocationMapping("STRING hi! [jsdoc_info: JSDocInfo]", "");
        com.google.javascript.jscomp.SourceMap.LocationMapping[] locationMappingArray11 = new com.google.javascript.jscomp.SourceMap.LocationMapping[] { locationMapping10 };
        java.util.ArrayList<com.google.javascript.jscomp.SourceMap.LocationMapping> locationMappingList12 = new java.util.ArrayList<com.google.javascript.jscomp.SourceMap.LocationMapping>();
        boolean boolean13 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.SourceMap.LocationMapping>) locationMappingList12, locationMappingArray11);
        compilerOptions0.sourceMapLocationMappings = locationMappingList12;
        com.google.javascript.jscomp.CompilerOptions compilerOptions15 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel16 = compilerOptions15.reportMissingOverride;
        compilerOptions15.setAppNameStr("module$STRING hi!");
        compilerOptions15.setOutputJsStringUsage(true);
        compilerOptions15.setRemoveDeadCode(true);
        byte[] byteArray29 = new byte[] { (byte) 100, (byte) 1, (byte) 0, (byte) 0, (byte) 0, (byte) 100 };
        compilerOptions15.inputVariableMapSerialized = byteArray29;
        compilerOptions0.inputVariableMapSerialized = byteArray29;
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(locationMappingArray11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + checkLevel16 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel16.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(byteArray29);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.reportMissingOverride;
        compilerOptions0.setAppNameStr("module$STRING hi!");
        boolean boolean4 = compilerOptions0.crossModuleMethodMotion;
        boolean boolean5 = compilerOptions0.computeFunctionSideEffects;
        compilerOptions0.reserveRawExports = false;
        compilerOptions0.setLocale("");
        java.util.List<com.google.javascript.jscomp.SourceMap.LocationMapping> locationMappingList10 = compilerOptions0.sourceMapLocationMappings;
        com.google.javascript.jscomp.CompilerOptions compilerOptions11 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel12 = compilerOptions11.reportMissingOverride;
        java.lang.String[] strArray19 = new java.lang.String[] { "STRING hi!", "hi!. hi! at (unknown source) line (unknown line) : (unknown column)", "module$STRING hi!", "hi!", "", "STRING hi!" };
        java.util.LinkedHashSet<java.lang.String> strSet20 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean21 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet20, strArray19);
        compilerOptions11.setIdGenerators((java.util.Set<java.lang.String>) strSet20);
        compilerOptions11.setAliasExternals(false);
        com.google.javascript.jscomp.CheckLevel checkLevel25 = compilerOptions11.reportMissingOverride;
        compilerOptions0.checkMissingGetCssNameLevel = checkLevel25;
        compilerOptions0.resetWarningsGuard();
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(locationMappingList10);
        org.junit.Assert.assertTrue("'" + checkLevel12 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel12.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(strArray19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + checkLevel25 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel25.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.TYPE_INVALIDATION;
        com.google.javascript.jscomp.DiagnosticGroups.ES5_STRICT = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticGroups.ACCESS_CONTROLS = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticGroups.CHECK_USELESS_CODE = diagnosticGroup0;
        org.junit.Assert.assertNull(diagnosticGroup0);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CompilerOptions compilerOptions1 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel2 = compilerOptions1.reportMissingOverride;
        compilerOptions0.setAggressiveVarCheck(checkLevel2);
        com.google.javascript.jscomp.SourceMap.Format format4 = compilerOptions0.sourceMapFormat;
        compilerOptions0.exportTestFunctions = true;
        compilerOptions0.skipAllCompilerPasses();
        compilerOptions0.setGeneratePseudoNames(true);
        compilerOptions0.setAliasAllStrings(false);
        org.junit.Assert.assertTrue("'" + checkLevel2 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel2.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(format4);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        java.util.logging.Logger logger0 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager1 = new com.google.javascript.jscomp.LoggerErrorManager(logger0);
        double double2 = loggerErrorManager1.getTypedPercent();
        com.google.javascript.jscomp.Compiler compiler3 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager1);
        com.google.javascript.jscomp.Result result4 = compiler3.getResult();
        java.util.logging.Logger logger5 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager6 = new com.google.javascript.jscomp.LoggerErrorManager(logger5);
        double double7 = loggerErrorManager6.getTypedPercent();
        compiler3.setErrorManager((com.google.javascript.jscomp.ErrorManager) loggerErrorManager6);
        com.google.javascript.jscomp.SourceFile.Generator generator10 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile11 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("goog.global", generator10);
        com.google.javascript.jscomp.SourceFile.Generator generator13 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile14 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("goog.global", generator13);
        com.google.javascript.jscomp.SourceFile.Generator generator16 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile17 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("goog.global", generator16);
        java.nio.charset.Charset charset19 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile20 = com.google.javascript.jscomp.JSSourceFile.fromFile("hi!. hi! at (unknown source) line (unknown line) : (unknown column)", charset19);
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray21 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile11, jSSourceFile14, jSSourceFile17, jSSourceFile20 };
        com.google.javascript.jscomp.SourceFile.Generator generator23 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile24 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("goog.global", generator23);
        com.google.javascript.jscomp.SourceFile.Generator generator26 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile27 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("goog.global", generator26);
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray28 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile24, jSSourceFile27 };
        com.google.javascript.jscomp.CompilerOptions compilerOptions29 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel30 = compilerOptions29.reportMissingOverride;
        compilerOptions29.setAppNameStr("module$STRING hi!");
        boolean boolean33 = compilerOptions29.crossModuleMethodMotion;
        boolean boolean34 = compilerOptions29.computeFunctionSideEffects;
        byte[] byteArray35 = compilerOptions29.inputVariableMapSerialized;
        compilerOptions29.checkMissingGetCssNameBlacklist = "hi!";
        compiler3.init(jSSourceFileArray21, jSSourceFileArray28, compilerOptions29);
        compilerOptions29.markAsCompiled = true;
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(result4);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(jSSourceFile11);
        org.junit.Assert.assertNotNull(jSSourceFile14);
        org.junit.Assert.assertNotNull(jSSourceFile17);
        org.junit.Assert.assertNotNull(jSSourceFile20);
        org.junit.Assert.assertNotNull(jSSourceFileArray21);
        org.junit.Assert.assertNotNull(jSSourceFile24);
        org.junit.Assert.assertNotNull(jSSourceFile27);
        org.junit.Assert.assertNotNull(jSSourceFileArray28);
        org.junit.Assert.assertTrue("'" + checkLevel30 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel30.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNull(byteArray35);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        java.util.logging.Logger logger0 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager1 = new com.google.javascript.jscomp.LoggerErrorManager(logger0);
        double double2 = loggerErrorManager1.getTypedPercent();
        com.google.javascript.jscomp.Compiler compiler3 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager1);
        com.google.javascript.jscomp.Result result4 = compiler3.getResult();
        java.util.logging.Logger logger5 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager6 = new com.google.javascript.jscomp.LoggerErrorManager(logger5);
        double double7 = loggerErrorManager6.getTypedPercent();
        compiler3.setErrorManager((com.google.javascript.jscomp.ErrorManager) loggerErrorManager6);
        com.google.javascript.jscomp.NodeTraversal.Callback callback9 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal10 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler3, callback9);
        com.google.javascript.jscomp.SourceFile sourceFile12 = com.google.javascript.jscomp.SourceFile.fromFile("hi!");
        boolean boolean13 = sourceFile12.isExtern();
        com.google.javascript.jscomp.JsAst jsAst14 = new com.google.javascript.jscomp.JsAst(sourceFile12);
        java.util.logging.Logger logger15 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager16 = new com.google.javascript.jscomp.LoggerErrorManager(logger15);
        double double17 = loggerErrorManager16.getTypedPercent();
        com.google.javascript.jscomp.Compiler compiler18 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager16);
        com.google.javascript.jscomp.Result result19 = compiler18.getResult();
        java.util.logging.Logger logger20 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager21 = new com.google.javascript.jscomp.LoggerErrorManager(logger20);
        double double22 = loggerErrorManager21.getTypedPercent();
        compiler18.setErrorManager((com.google.javascript.jscomp.ErrorManager) loggerErrorManager21);
        com.google.javascript.jscomp.NodeTraversal.Callback callback24 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal25 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler18, callback24);
        com.google.javascript.jscomp.Scope scope26 = compiler18.getTopScope();
        com.google.javascript.rhino.Node node27 = jsAst14.getAstRoot((com.google.javascript.jscomp.AbstractCompiler) compiler18);
        java.lang.String str30 = compiler18.getSourceLine("// Input %num%", (-1));
        com.google.javascript.jscomp.SourceFile.Generator generator32 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile33 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("goog.global", generator32);
        jSSourceFile33.clearCachedSource();
        java.nio.charset.Charset charset36 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile37 = com.google.javascript.jscomp.JSSourceFile.fromFile("hi!. hi! at (unknown source) line (unknown line) : (unknown column)", charset36);
        java.lang.Class<?> wildcardClass38 = jSSourceFile37.getClass();
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray39 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile33, jSSourceFile37 };
        com.google.javascript.jscomp.JSModule[] jSModuleArray40 = new com.google.javascript.jscomp.JSModule[] {};
        com.google.javascript.jscomp.CompilerOptions compilerOptions41 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel42 = compilerOptions41.reportMissingOverride;
        com.google.javascript.jscomp.CompilerOptions.LanguageMode languageMode43 = com.google.javascript.jscomp.CompilerOptions.LanguageMode.ECMASCRIPT5;
        compilerOptions41.setLanguageIn(languageMode43);
        compiler18.init(jSSourceFileArray39, jSModuleArray40, compilerOptions41);
        java.util.logging.Logger logger46 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager47 = new com.google.javascript.jscomp.LoggerErrorManager(logger46);
        double double48 = loggerErrorManager47.getTypedPercent();
        com.google.javascript.jscomp.Compiler compiler49 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager47);
        com.google.javascript.jscomp.Result result50 = compiler49.getResult();
        java.lang.String str51 = compiler49.getAstDotGraph();
        com.google.javascript.jscomp.JSError[] jSErrorArray52 = compiler49.getWarnings();
        com.google.javascript.jscomp.JSError[] jSErrorArray53 = compiler49.getWarnings();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile55 = com.google.javascript.jscomp.JSSourceFile.fromFile("Unknown class name");
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray56 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile55 };
        java.nio.charset.Charset charset58 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile59 = com.google.javascript.jscomp.JSSourceFile.fromFile("hi!. hi! at (unknown source) line (unknown line) : (unknown column)", charset58);
        java.lang.Class<?> wildcardClass60 = jSSourceFile59.getClass();
        java.nio.charset.Charset charset62 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile63 = com.google.javascript.jscomp.JSSourceFile.fromFile("hi!. hi! at (unknown source) line (unknown line) : (unknown column)", charset62);
        java.nio.charset.Charset charset65 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile66 = com.google.javascript.jscomp.JSSourceFile.fromFile("hi!. hi! at (unknown source) line (unknown line) : (unknown column)", charset65);
        java.lang.String str68 = jSSourceFile66.getLine(43);
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray69 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile59, jSSourceFile63, jSSourceFile66 };
        com.google.javascript.jscomp.CompilerOptions compilerOptions70 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel71 = compilerOptions70.reportMissingOverride;
        compilerOptions70.setAppNameStr("module$STRING hi!");
        boolean boolean74 = compilerOptions70.crossModuleMethodMotion;
        boolean boolean75 = compilerOptions70.computeFunctionSideEffects;
        compilerOptions70.reserveRawExports = false;
        boolean boolean78 = compilerOptions70.collapseAnonymousFunctions;
        compilerOptions70.printInputDelimiter = true;
        boolean boolean81 = compilerOptions70.preferLineBreakAtEndOfFile;
        compiler49.init(jSSourceFileArray56, jSSourceFileArray69, compilerOptions70);
        com.google.javascript.jscomp.CompilerOptions compilerOptions83 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel84 = compilerOptions83.reportMissingOverride;
        compilerOptions83.setAppNameStr("module$STRING hi!");
        boolean boolean87 = compilerOptions83.crossModuleMethodMotion;
        boolean boolean88 = compilerOptions83.computeFunctionSideEffects;
        compilerOptions83.locale = "module$STRING hi!";
        com.google.javascript.jscomp.CheckLevel checkLevel91 = null;
        compilerOptions83.aggressiveVarCheck = checkLevel91;
        try {
            com.google.javascript.jscomp.Result result93 = compiler3.compile(jSSourceFileArray39, jSSourceFileArray56, compilerOptions83);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: java.lang.NullPointerException");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(result4);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(sourceFile12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNotNull(result19);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNull(scope26);
        org.junit.Assert.assertNotNull(node27);
        org.junit.Assert.assertNull(str30);
        org.junit.Assert.assertNotNull(jSSourceFile33);
        org.junit.Assert.assertNotNull(jSSourceFile37);
        org.junit.Assert.assertNotNull(wildcardClass38);
        org.junit.Assert.assertNotNull(jSSourceFileArray39);
        org.junit.Assert.assertNotNull(jSModuleArray40);
        org.junit.Assert.assertTrue("'" + checkLevel42 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel42.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + languageMode43 + "' != '" + com.google.javascript.jscomp.CompilerOptions.LanguageMode.ECMASCRIPT5 + "'", languageMode43.equals(com.google.javascript.jscomp.CompilerOptions.LanguageMode.ECMASCRIPT5));
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 0.0d + "'", double48 == 0.0d);
        org.junit.Assert.assertNotNull(result50);
        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "" + "'", str51.equals(""));
        org.junit.Assert.assertNotNull(jSErrorArray52);
        org.junit.Assert.assertNotNull(jSErrorArray53);
        org.junit.Assert.assertNotNull(jSSourceFile55);
        org.junit.Assert.assertNotNull(jSSourceFileArray56);
        org.junit.Assert.assertNotNull(jSSourceFile59);
        org.junit.Assert.assertNotNull(wildcardClass60);
        org.junit.Assert.assertNotNull(jSSourceFile63);
        org.junit.Assert.assertNotNull(jSSourceFile66);
        org.junit.Assert.assertNull(str68);
        org.junit.Assert.assertNotNull(jSSourceFileArray69);
        org.junit.Assert.assertTrue("'" + checkLevel71 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel71.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + false + "'", boolean81 == false);
        org.junit.Assert.assertTrue("'" + checkLevel84 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel84.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + false + "'", boolean87 == false);
        org.junit.Assert.assertTrue("'" + boolean88 + "' != '" + false + "'", boolean88 == false);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.reportMissingOverride;
        compilerOptions0.setAppNameStr("module$STRING hi!");
        byte[] byteArray7 = new byte[] { (byte) -1, (byte) 0, (byte) -1 };
        compilerOptions0.setInputVariableMapSerialized(byteArray7);
        compilerOptions0.setDebugFunctionSideEffectsPath("STRING hi!");
        compilerOptions0.setCrossModuleMethodMotion(true);
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(byteArray7);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        com.google.javascript.rhino.Node.SideEffectFlags sideEffectFlags1 = new com.google.javascript.rhino.Node.SideEffectFlags((int) '4');
        sideEffectFlags1.setReturnsTainted();
        sideEffectFlags1.setMutatesArguments();
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.reportMissingOverride;
        compilerOptions0.setAppNameStr("module$STRING hi!");
        boolean boolean4 = compilerOptions0.crossModuleMethodMotion;
        boolean boolean5 = compilerOptions0.computeFunctionSideEffects;
        compilerOptions0.locale = "module$STRING hi!";
        compilerOptions0.setLineLengthThreshold(0);
        boolean boolean10 = compilerOptions0.collapseVariableDeclarations;
        com.google.javascript.jscomp.CompilerOptions compilerOptions11 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel12 = compilerOptions11.reportMissingOverride;
        compilerOptions11.setAppNameStr("module$STRING hi!");
        boolean boolean15 = compilerOptions11.crossModuleMethodMotion;
        boolean boolean16 = compilerOptions11.computeFunctionSideEffects;
        compilerOptions11.locale = "module$STRING hi!";
        compilerOptions11.setComputeFunctionSideEffects(true);
        boolean boolean21 = compilerOptions11.ambiguateProperties;
        boolean boolean22 = compilerOptions11.exportTestFunctions;
        com.google.javascript.jscomp.SourceMap.Format format23 = compilerOptions11.sourceMapFormat;
        compilerOptions0.sourceMapFormat = format23;
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + checkLevel12 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel12.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(format23);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean3 = node2.isFor();
        boolean boolean4 = node2.isExprResult();
        java.lang.String str5 = node2.getString();
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean8 = node7.isFor();
        boolean boolean9 = node7.isExprResult();
        com.google.javascript.rhino.Node node10 = node2.clonePropsFrom(node7);
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean13 = node12.isFor();
        boolean boolean14 = node12.isExprResult();
        java.lang.String str15 = node12.getString();
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean18 = node17.isFor();
        boolean boolean19 = node17.isExprResult();
        com.google.javascript.rhino.Node node20 = node12.clonePropsFrom(node17);
        boolean boolean21 = node20.isVar();
        node20.setSourceEncodedPositionForTree(16);
        com.google.javascript.rhino.Node node24 = new com.google.javascript.rhino.Node(10, node7, node20);
        com.google.javascript.rhino.Node node25 = node24.cloneTree();
        java.lang.String str26 = node25.getQualifiedName();
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "hi!" + "'", str15.equals("hi!"));
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNull(str26);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        com.google.javascript.jscomp.DiagnosticType diagnosticType0 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        org.junit.Assert.assertNotNull(diagnosticType0);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.reportMissingOverride;
        compilerOptions0.setAppNameStr("module$STRING hi!");
        compilerOptions0.setOutputJsStringUsage(true);
        java.util.Set<java.lang.String> strSet6 = compilerOptions0.stripTypePrefixes;
        compilerOptions0.setTransformAMDToCJSModules(true);
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(strSet6);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        com.google.javascript.jscomp.SourceFile sourceFile1 = com.google.javascript.jscomp.SourceFile.fromFile("hi!");
        boolean boolean2 = sourceFile1.isExtern();
        com.google.javascript.jscomp.JsAst jsAst3 = new com.google.javascript.jscomp.JsAst(sourceFile1);
        com.google.javascript.jscomp.CompilerInput compilerInput6 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) jsAst3, "// Input %num%", false);
        com.google.javascript.jscomp.SourceAst sourceAst7 = compilerInput6.getSourceAst();
        com.google.javascript.jscomp.JSModule jSModule8 = null;
        compilerInput6.setModule(jSModule8);
        com.google.javascript.jscomp.CompilerInput compilerInput12 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput6, "", false);
        org.junit.Assert.assertNotNull(sourceFile1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(sourceAst7);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        java.nio.charset.Charset charset1 = null;
        com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromFile("hi!. hi! at (unknown source) line (unknown line) : (unknown column)", charset1);
        org.junit.Assert.assertNotNull(sourceFile2);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        java.util.logging.Logger logger0 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager1 = new com.google.javascript.jscomp.LoggerErrorManager(logger0);
        double double2 = loggerErrorManager1.getTypedPercent();
        com.google.javascript.jscomp.Compiler compiler3 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager1);
        com.google.javascript.jscomp.Result result4 = compiler3.getResult();
        java.util.logging.Logger logger5 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager6 = new com.google.javascript.jscomp.LoggerErrorManager(logger5);
        double double7 = loggerErrorManager6.getTypedPercent();
        compiler3.setErrorManager((com.google.javascript.jscomp.ErrorManager) loggerErrorManager6);
        com.google.javascript.jscomp.NodeTraversal.Callback callback9 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal10 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler3, callback9);
        double double11 = compiler3.getProgress();
        com.google.javascript.jscomp.NodeTraversal.Callback callback12 = null;
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.IR.name("hi!");
        com.google.javascript.rhino.Node[] nodeArray15 = new com.google.javascript.rhino.Node[] { node14 };
        try {
            com.google.javascript.jscomp.NodeTraversal.traverseRoots((com.google.javascript.jscomp.AbstractCompiler) compiler3, callback12, nodeArray15);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: INTERNAL COMPILER ERROR.\nPlease report this problem.\nnull");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(result4);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNotNull(nodeArray15);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.reportMissingOverride;
        compilerOptions0.setAppNameStr("module$STRING hi!");
        boolean boolean4 = compilerOptions0.crossModuleMethodMotion;
        boolean boolean5 = compilerOptions0.computeFunctionSideEffects;
        byte[] byteArray6 = compilerOptions0.inputVariableMapSerialized;
        compilerOptions0.checkMissingGetCssNameBlacklist = "hi!";
        compilerOptions0.setAliasStringsBlacklist("goog.exportSymbol");
        boolean boolean11 = compilerOptions0.markAsCompiled;
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(byteArray6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        java.util.logging.Logger logger0 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager1 = new com.google.javascript.jscomp.LoggerErrorManager(logger0);
        double double2 = loggerErrorManager1.getTypedPercent();
        loggerErrorManager1.setTypedPercent(0.0d);
        int int5 = loggerErrorManager1.getWarningCount();
        double double6 = loggerErrorManager1.getTypedPercent();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.reportMissingOverride;
        compilerOptions0.setAppNameStr("module$STRING hi!");
        compilerOptions0.setOutputJsStringUsage(true);
        compilerOptions0.resetWarningsGuard();
        compilerOptions0.setGenerateExports(false);
        java.lang.String str9 = compilerOptions0.instrumentationTemplate;
        compilerOptions0.setInlineGetters(true);
        compilerOptions0.setMarkNoSideEffectCalls(false);
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNull(str9);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        java.util.logging.Logger logger0 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager1 = new com.google.javascript.jscomp.LoggerErrorManager(logger0);
        double double2 = loggerErrorManager1.getTypedPercent();
        com.google.javascript.jscomp.Compiler compiler3 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager1);
        com.google.javascript.jscomp.Result result4 = compiler3.getResult();
        java.util.logging.Logger logger5 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager6 = new com.google.javascript.jscomp.LoggerErrorManager(logger5);
        double double7 = loggerErrorManager6.getTypedPercent();
        compiler3.setErrorManager((com.google.javascript.jscomp.ErrorManager) loggerErrorManager6);
        com.google.javascript.jscomp.SourceFile.Generator generator10 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile11 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("goog.global", generator10);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile13 = com.google.javascript.jscomp.JSSourceFile.fromFile("Unknown class name");
        com.google.javascript.jscomp.CompilerOptions compilerOptions14 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions14.setRewriteFunctionExpressions(true);
        compilerOptions14.setInstrumentationTemplate("// Input %num%");
        com.google.javascript.jscomp.CompilerOptions compilerOptions19 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel20 = compilerOptions19.reportMissingOverride;
        compilerOptions19.setAppNameStr("module$STRING hi!");
        boolean boolean23 = compilerOptions19.crossModuleMethodMotion;
        boolean boolean24 = compilerOptions19.computeFunctionSideEffects;
        boolean boolean25 = compilerOptions19.removeUnusedLocalVars;
        com.google.javascript.jscomp.CompilerOptions compilerOptions26 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel27 = compilerOptions26.reportMissingOverride;
        compilerOptions19.setCheckUnreachableCode(checkLevel27);
        compilerOptions14.setCheckGlobalNamesLevel(checkLevel27);
        try {
            com.google.javascript.jscomp.Result result30 = compiler3.compile(jSSourceFile11, jSSourceFile13, compilerOptions14);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: java.lang.NullPointerException");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(result4);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(jSSourceFile11);
        org.junit.Assert.assertNotNull(jSSourceFile13);
        org.junit.Assert.assertTrue("'" + checkLevel20 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel20.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + checkLevel27 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel27.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newString("hi!");
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.IR.voidNode(node1);
        boolean boolean4 = node1.getBooleanProp(0);
        com.google.javascript.rhino.Node node5 = null;
        try {
            node1.addChildrenToBack(node5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        com.google.javascript.rhino.Node node1 = null;
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean4 = node3.isFor();
        boolean boolean5 = node3.isExprResult();
        java.lang.String str6 = node3.getString();
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean9 = node8.isFor();
        boolean boolean10 = node8.isExprResult();
        com.google.javascript.rhino.Node node11 = node3.clonePropsFrom(node8);
        boolean boolean12 = node11.isVar();
        com.google.javascript.rhino.Node node16 = new com.google.javascript.rhino.Node((int) (byte) 100, (int) (byte) 1, 54);
        boolean boolean17 = node16.isReturn();
        boolean boolean18 = node11.hasChild(node16);
        int int20 = node16.getIntProp((int) (byte) -1);
        try {
            com.google.javascript.rhino.Node node21 = new com.google.javascript.rhino.Node(46, node1, node16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        com.google.javascript.jscomp.DiagnosticType diagnosticType2 = com.google.javascript.jscomp.DiagnosticType.disabled("hi!", "hi!");
        java.lang.String[] strArray4 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError5 = com.google.javascript.jscomp.JSError.make(diagnosticType2, strArray4);
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean8 = node7.isFor();
        boolean boolean9 = node7.isExprResult();
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean12 = node11.isFor();
        com.google.javascript.rhino.Node node13 = node7.clonePropsFrom(node11);
        node7.putIntProp(53, (int) (byte) 100);
        boolean boolean17 = jSError5.equals((java.lang.Object) 53);
        com.google.javascript.jscomp.CheckLevel checkLevel18 = jSError5.level;
        java.lang.String str19 = jSError5.toString();
        org.junit.Assert.assertNotNull(diagnosticType2);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(jSError5);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + checkLevel18 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel18.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "hi!. hi! at (unknown source) line (unknown line) : (unknown column)" + "'", str19.equals("hi!. hi! at (unknown source) line (unknown line) : (unknown column)"));
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        java.util.logging.Logger logger0 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager1 = new com.google.javascript.jscomp.LoggerErrorManager(logger0);
        double double2 = loggerErrorManager1.getTypedPercent();
        com.google.javascript.jscomp.Compiler compiler3 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager1);
        com.google.javascript.jscomp.Result result4 = compiler3.getResult();
        java.util.logging.Logger logger5 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager6 = new com.google.javascript.jscomp.LoggerErrorManager(logger5);
        double double7 = loggerErrorManager6.getTypedPercent();
        compiler3.setErrorManager((com.google.javascript.jscomp.ErrorManager) loggerErrorManager6);
        com.google.javascript.jscomp.SourceFile.Generator generator10 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile11 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("goog.global", generator10);
        com.google.javascript.jscomp.SourceFile.Generator generator13 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile14 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("goog.global", generator13);
        com.google.javascript.jscomp.SourceFile.Generator generator16 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile17 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("goog.global", generator16);
        java.nio.charset.Charset charset19 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile20 = com.google.javascript.jscomp.JSSourceFile.fromFile("hi!. hi! at (unknown source) line (unknown line) : (unknown column)", charset19);
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray21 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile11, jSSourceFile14, jSSourceFile17, jSSourceFile20 };
        com.google.javascript.jscomp.SourceFile.Generator generator23 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile24 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("goog.global", generator23);
        com.google.javascript.jscomp.SourceFile.Generator generator26 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile27 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("goog.global", generator26);
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray28 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile24, jSSourceFile27 };
        com.google.javascript.jscomp.CompilerOptions compilerOptions29 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel30 = compilerOptions29.reportMissingOverride;
        compilerOptions29.setAppNameStr("module$STRING hi!");
        boolean boolean33 = compilerOptions29.crossModuleMethodMotion;
        boolean boolean34 = compilerOptions29.computeFunctionSideEffects;
        byte[] byteArray35 = compilerOptions29.inputVariableMapSerialized;
        compilerOptions29.checkMissingGetCssNameBlacklist = "hi!";
        compiler3.init(jSSourceFileArray21, jSSourceFileArray28, compilerOptions29);
        java.nio.charset.Charset charset40 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile41 = com.google.javascript.jscomp.JSSourceFile.fromFile("hi!. hi! at (unknown source) line (unknown line) : (unknown column)", charset40);
        com.google.javascript.jscomp.SourceFile sourceFile43 = com.google.javascript.jscomp.SourceFile.fromFile("hi!");
        boolean boolean44 = sourceFile43.isExtern();
        com.google.javascript.jscomp.JsAst jsAst45 = new com.google.javascript.jscomp.JsAst(sourceFile43);
        java.util.logging.Logger logger46 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager47 = new com.google.javascript.jscomp.LoggerErrorManager(logger46);
        double double48 = loggerErrorManager47.getTypedPercent();
        com.google.javascript.jscomp.Compiler compiler49 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager47);
        com.google.javascript.jscomp.Result result50 = compiler49.getResult();
        java.util.logging.Logger logger51 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager52 = new com.google.javascript.jscomp.LoggerErrorManager(logger51);
        double double53 = loggerErrorManager52.getTypedPercent();
        compiler49.setErrorManager((com.google.javascript.jscomp.ErrorManager) loggerErrorManager52);
        com.google.javascript.jscomp.NodeTraversal.Callback callback55 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal56 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler49, callback55);
        com.google.javascript.jscomp.Scope scope57 = compiler49.getTopScope();
        com.google.javascript.rhino.Node node58 = jsAst45.getAstRoot((com.google.javascript.jscomp.AbstractCompiler) compiler49);
        java.lang.String str61 = compiler49.getSourceLine("// Input %num%", (-1));
        com.google.javascript.jscomp.SourceFile.Generator generator63 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile64 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("goog.global", generator63);
        jSSourceFile64.clearCachedSource();
        java.nio.charset.Charset charset67 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile68 = com.google.javascript.jscomp.JSSourceFile.fromFile("hi!. hi! at (unknown source) line (unknown line) : (unknown column)", charset67);
        java.lang.Class<?> wildcardClass69 = jSSourceFile68.getClass();
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray70 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile64, jSSourceFile68 };
        com.google.javascript.jscomp.JSModule[] jSModuleArray71 = new com.google.javascript.jscomp.JSModule[] {};
        com.google.javascript.jscomp.CompilerOptions compilerOptions72 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel73 = compilerOptions72.reportMissingOverride;
        com.google.javascript.jscomp.CompilerOptions.LanguageMode languageMode74 = com.google.javascript.jscomp.CompilerOptions.LanguageMode.ECMASCRIPT5;
        compilerOptions72.setLanguageIn(languageMode74);
        compiler49.init(jSSourceFileArray70, jSModuleArray71, compilerOptions72);
        com.google.javascript.jscomp.CompilerOptions compilerOptions77 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel78 = compilerOptions77.reportMissingOverride;
        compilerOptions77.setAppNameStr("module$STRING hi!");
        boolean boolean81 = compilerOptions77.crossModuleMethodMotion;
        boolean boolean82 = compilerOptions77.computeFunctionSideEffects;
        compilerOptions77.locale = "module$STRING hi!";
        compilerOptions77.setComputeFunctionSideEffects(true);
        boolean boolean87 = compilerOptions77.ambiguateProperties;
        boolean boolean88 = compilerOptions77.exportTestFunctions;
        com.google.javascript.jscomp.SourceMap.Format format89 = compilerOptions77.sourceMapFormat;
        boolean boolean90 = compilerOptions77.checkTypes;
        compilerOptions77.setRemoveAbstractMethods(false);
        try {
            com.google.javascript.jscomp.Result result93 = compiler3.compile(jSSourceFile41, jSModuleArray71, compilerOptions77);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(result4);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(jSSourceFile11);
        org.junit.Assert.assertNotNull(jSSourceFile14);
        org.junit.Assert.assertNotNull(jSSourceFile17);
        org.junit.Assert.assertNotNull(jSSourceFile20);
        org.junit.Assert.assertNotNull(jSSourceFileArray21);
        org.junit.Assert.assertNotNull(jSSourceFile24);
        org.junit.Assert.assertNotNull(jSSourceFile27);
        org.junit.Assert.assertNotNull(jSSourceFileArray28);
        org.junit.Assert.assertTrue("'" + checkLevel30 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel30.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNull(byteArray35);
        org.junit.Assert.assertNotNull(jSSourceFile41);
        org.junit.Assert.assertNotNull(sourceFile43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 0.0d + "'", double48 == 0.0d);
        org.junit.Assert.assertNotNull(result50);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 0.0d + "'", double53 == 0.0d);
        org.junit.Assert.assertNull(scope57);
        org.junit.Assert.assertNotNull(node58);
        org.junit.Assert.assertNull(str61);
        org.junit.Assert.assertNotNull(jSSourceFile64);
        org.junit.Assert.assertNotNull(jSSourceFile68);
        org.junit.Assert.assertNotNull(wildcardClass69);
        org.junit.Assert.assertNotNull(jSSourceFileArray70);
        org.junit.Assert.assertNotNull(jSModuleArray71);
        org.junit.Assert.assertTrue("'" + checkLevel73 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel73.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + languageMode74 + "' != '" + com.google.javascript.jscomp.CompilerOptions.LanguageMode.ECMASCRIPT5 + "'", languageMode74.equals(com.google.javascript.jscomp.CompilerOptions.LanguageMode.ECMASCRIPT5));
        org.junit.Assert.assertTrue("'" + checkLevel78 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel78.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + false + "'", boolean81 == false);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + false + "'", boolean87 == false);
        org.junit.Assert.assertTrue("'" + boolean88 + "' != '" + false + "'", boolean88 == false);
        org.junit.Assert.assertNotNull(format89);
        org.junit.Assert.assertTrue("'" + boolean90 + "' != '" + false + "'", boolean90 == false);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        com.google.javascript.jscomp.SourceFile sourceFile1 = com.google.javascript.jscomp.SourceFile.fromFile("hi!");
        boolean boolean2 = sourceFile1.isExtern();
        com.google.javascript.jscomp.JsAst jsAst3 = new com.google.javascript.jscomp.JsAst(sourceFile1);
        com.google.javascript.jscomp.CompilerInput compilerInput6 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) jsAst3, "// Input %num%", false);
        com.google.javascript.jscomp.SourceFile sourceFile8 = com.google.javascript.jscomp.SourceFile.fromFile("hi!");
        boolean boolean9 = sourceFile8.isExtern();
        com.google.javascript.jscomp.JsAst jsAst10 = new com.google.javascript.jscomp.JsAst(sourceFile8);
        java.util.logging.Logger logger11 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager12 = new com.google.javascript.jscomp.LoggerErrorManager(logger11);
        double double13 = loggerErrorManager12.getTypedPercent();
        com.google.javascript.jscomp.Compiler compiler14 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager12);
        com.google.javascript.jscomp.Result result15 = compiler14.getResult();
        java.util.logging.Logger logger16 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager17 = new com.google.javascript.jscomp.LoggerErrorManager(logger16);
        double double18 = loggerErrorManager17.getTypedPercent();
        compiler14.setErrorManager((com.google.javascript.jscomp.ErrorManager) loggerErrorManager17);
        com.google.javascript.jscomp.NodeTraversal.Callback callback20 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal21 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler14, callback20);
        com.google.javascript.jscomp.Scope scope22 = compiler14.getTopScope();
        com.google.javascript.rhino.Node node23 = jsAst10.getAstRoot((com.google.javascript.jscomp.AbstractCompiler) compiler14);
        com.google.javascript.rhino.InputId inputId24 = jsAst10.getInputId();
        com.google.javascript.jscomp.CompilerInput compilerInput26 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput6, inputId24, true);
        org.junit.Assert.assertNotNull(sourceFile1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(sourceFile8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertNotNull(result15);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNull(scope22);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(inputId24);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean3 = node2.isFor();
        boolean boolean4 = node2.isExprResult();
        java.lang.String str5 = node2.getString();
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean8 = node7.isFor();
        boolean boolean9 = node7.isExprResult();
        com.google.javascript.rhino.Node node10 = node2.clonePropsFrom(node7);
        boolean boolean11 = node10.isVar();
        com.google.javascript.rhino.Node node15 = new com.google.javascript.rhino.Node((int) (byte) 100, (int) (byte) 1, 54);
        boolean boolean16 = node15.isReturn();
        boolean boolean17 = node10.hasChild(node15);
        int int19 = node15.getIntProp((int) (byte) -1);
        com.google.javascript.rhino.Node node21 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean22 = node21.isFor();
        boolean boolean23 = node21.isExprResult();
        java.lang.String str24 = node21.getString();
        com.google.javascript.rhino.Node node26 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean27 = node26.isFor();
        boolean boolean28 = node26.isExprResult();
        com.google.javascript.rhino.Node node29 = node21.clonePropsFrom(node26);
        com.google.javascript.rhino.Node node31 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean32 = node31.isFor();
        boolean boolean33 = node31.isExprResult();
        java.lang.String str34 = node31.getString();
        com.google.javascript.rhino.Node node36 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean37 = node36.isFor();
        boolean boolean38 = node36.isExprResult();
        com.google.javascript.rhino.Node node39 = node31.clonePropsFrom(node36);
        int int40 = node26.getIndexOfChild(node31);
        com.google.javascript.rhino.Node node41 = new com.google.javascript.rhino.Node(46, node15, node31);
        com.google.javascript.rhino.Node node42 = node15.removeFirstChild();
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "hi!" + "'", str24.equals("hi!"));
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "hi!" + "'", str34.equals("hi!"));
        org.junit.Assert.assertNotNull(node36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(node39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + (-1) + "'", int40 == (-1));
        org.junit.Assert.assertNull(node42);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        com.google.javascript.jscomp.DiagnosticType diagnosticType3 = com.google.javascript.jscomp.Compiler.MOTION_ITERATIONS_ERROR;
        com.google.javascript.jscomp.DiagnosticType diagnosticType6 = com.google.javascript.jscomp.DiagnosticType.disabled("hi!", "hi!");
        java.lang.String[] strArray8 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError9 = com.google.javascript.jscomp.JSError.make(diagnosticType6, strArray8);
        com.google.javascript.jscomp.JSError jSError10 = com.google.javascript.jscomp.JSError.make("hi!. hi! at (unknown source) line (unknown line) : (unknown column)", (int) ' ', 0, diagnosticType3, strArray8);
        java.lang.String str11 = diagnosticType3.key;
        java.util.logging.Logger logger12 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager13 = new com.google.javascript.jscomp.LoggerErrorManager(logger12);
        double double14 = loggerErrorManager13.getTypedPercent();
        com.google.javascript.jscomp.Compiler compiler15 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager13);
        com.google.javascript.jscomp.Result result16 = compiler15.getResult();
        java.util.logging.Logger logger17 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager18 = new com.google.javascript.jscomp.LoggerErrorManager(logger17);
        double double19 = loggerErrorManager18.getTypedPercent();
        compiler15.setErrorManager((com.google.javascript.jscomp.ErrorManager) loggerErrorManager18);
        com.google.javascript.jscomp.NodeTraversal.Callback callback21 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal22 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler15, callback21);
        com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean26 = node25.isFor();
        boolean boolean27 = node25.isExprResult();
        java.lang.String str28 = node25.getString();
        com.google.javascript.rhino.Node node30 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean31 = node30.isFor();
        boolean boolean32 = node30.isExprResult();
        com.google.javascript.rhino.Node node33 = node25.clonePropsFrom(node30);
        com.google.javascript.rhino.Node node35 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean36 = node35.isFor();
        boolean boolean37 = node35.isExprResult();
        java.lang.String str38 = node35.getString();
        com.google.javascript.rhino.Node node40 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean41 = node40.isFor();
        boolean boolean42 = node40.isExprResult();
        com.google.javascript.rhino.Node node43 = node35.clonePropsFrom(node40);
        boolean boolean44 = node43.isVar();
        node43.setSourceEncodedPositionForTree(16);
        com.google.javascript.rhino.Node node47 = new com.google.javascript.rhino.Node(10, node30, node43);
        com.google.javascript.jscomp.SourceFile sourceFile49 = com.google.javascript.jscomp.SourceFile.fromFile("hi!");
        node47.setStaticSourceFile((com.google.javascript.rhino.jstype.StaticSourceFile) sourceFile49);
        com.google.javascript.rhino.Node node51 = com.google.javascript.rhino.IR.paramList();
        com.google.javascript.rhino.Node node52 = node47.srcref(node51);
        com.google.javascript.rhino.Node node56 = new com.google.javascript.rhino.Node((int) (byte) 100, (int) (byte) 1, 54);
        boolean boolean57 = node56.isReturn();
        boolean boolean58 = node52.isEquivalentToTyped(node56);
        com.google.javascript.jscomp.CompilerOptions compilerOptions59 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel60 = compilerOptions59.reportMissingOverride;
        compilerOptions59.setAppNameStr("module$STRING hi!");
        boolean boolean63 = compilerOptions59.crossModuleMethodMotion;
        boolean boolean64 = compilerOptions59.computeFunctionSideEffects;
        compilerOptions59.locale = "module$STRING hi!";
        compilerOptions59.setComputeFunctionSideEffects(true);
        compilerOptions59.setAliasableGlobals("hi!");
        com.google.javascript.jscomp.CompilerOptions compilerOptions71 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel72 = compilerOptions71.reportMissingOverride;
        compilerOptions59.checkUnreachableCode = checkLevel72;
        com.google.javascript.jscomp.CompilerOptions compilerOptions74 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel75 = compilerOptions74.reportMissingOverride;
        compilerOptions74.setAppNameStr("module$STRING hi!");
        boolean boolean78 = compilerOptions74.crossModuleMethodMotion;
        boolean boolean79 = compilerOptions74.computeFunctionSideEffects;
        compilerOptions74.locale = "module$STRING hi!";
        compilerOptions74.setComputeFunctionSideEffects(true);
        compilerOptions74.setAliasableGlobals("hi!");
        com.google.javascript.jscomp.CompilerOptions compilerOptions86 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel87 = compilerOptions86.reportMissingOverride;
        compilerOptions74.checkUnreachableCode = checkLevel87;
        compilerOptions59.checkMissingGetCssNameLevel = checkLevel87;
        com.google.javascript.jscomp.DiagnosticType diagnosticType90 = com.google.javascript.jscomp.Compiler.MOTION_ITERATIONS_ERROR;
        java.lang.String[] strArray92 = new java.lang.String[] { "hi!. hi! at (unknown source) line (unknown line) : (unknown column)" };
        com.google.javascript.jscomp.JSError jSError93 = nodeTraversal22.makeError(node56, checkLevel87, diagnosticType90, strArray92);
        diagnosticType3.level = checkLevel87;
        org.junit.Assert.assertNotNull(diagnosticType3);
        org.junit.Assert.assertNotNull(diagnosticType6);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertNotNull(jSError9);
        org.junit.Assert.assertNotNull(jSError10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "JSC_OPTIMIZE_LOOP_ERROR" + "'", str11.equals("JSC_OPTIMIZE_LOOP_ERROR"));
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNotNull(result16);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "hi!" + "'", str28.equals("hi!"));
        org.junit.Assert.assertNotNull(node30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(node33);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "hi!" + "'", str38.equals("hi!"));
        org.junit.Assert.assertNotNull(node40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(node43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(sourceFile49);
        org.junit.Assert.assertNotNull(node51);
        org.junit.Assert.assertNotNull(node52);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertTrue("'" + checkLevel60 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel60.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertTrue("'" + checkLevel72 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel72.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + checkLevel75 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel75.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
        org.junit.Assert.assertTrue("'" + checkLevel87 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel87.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(diagnosticType90);
        org.junit.Assert.assertNotNull(strArray92);
        org.junit.Assert.assertNotNull(jSError93);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newString("hi!");
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.IR.voidNode(node1);
        boolean boolean3 = node2.isBreak();
        boolean boolean4 = node2.isLabelName();
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean3 = node2.isFor();
        boolean boolean4 = node2.isExprResult();
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean7 = node6.isFor();
        com.google.javascript.rhino.Node node8 = node2.clonePropsFrom(node6);
        boolean boolean9 = node2.isOnlyModifiesThisCall();
        boolean boolean10 = node2.isAdd();
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean14 = node13.isFor();
        boolean boolean15 = node13.isExprResult();
        java.lang.String str16 = node13.getString();
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean19 = node18.isFor();
        boolean boolean20 = node18.isExprResult();
        com.google.javascript.rhino.Node node21 = node13.clonePropsFrom(node18);
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean24 = node23.isFor();
        boolean boolean25 = node23.isExprResult();
        java.lang.String str26 = node23.getString();
        com.google.javascript.rhino.Node node28 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean29 = node28.isFor();
        boolean boolean30 = node28.isExprResult();
        com.google.javascript.rhino.Node node31 = node23.clonePropsFrom(node28);
        boolean boolean32 = node31.isVar();
        node31.setSourceEncodedPositionForTree(16);
        com.google.javascript.rhino.Node node35 = new com.google.javascript.rhino.Node(10, node18, node31);
        com.google.javascript.rhino.Node node36 = node35.cloneTree();
        com.google.javascript.rhino.Node node37 = node2.useSourceInfoIfMissingFromForTree(node36);
        com.google.javascript.rhino.Node node39 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean40 = node39.isFor();
        boolean boolean41 = node39.isExprResult();
        java.lang.String str42 = node39.getString();
        com.google.javascript.rhino.Node node44 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean45 = node44.isFor();
        boolean boolean46 = node44.isExprResult();
        com.google.javascript.rhino.Node node47 = node39.clonePropsFrom(node44);
        com.google.javascript.rhino.Node node49 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean50 = node49.isFor();
        boolean boolean51 = node49.isExprResult();
        java.lang.String str52 = node49.getString();
        com.google.javascript.rhino.Node node54 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean55 = node54.isFor();
        boolean boolean56 = node54.isExprResult();
        com.google.javascript.rhino.Node node57 = node49.clonePropsFrom(node54);
        int int58 = node44.getIndexOfChild(node49);
        com.google.javascript.rhino.Node node59 = node44.cloneTree();
        node44.setString("module$STRING hi!");
        boolean boolean62 = node44.isVarArgs();
        com.google.javascript.rhino.Node node63 = node2.copyInformationFromForTree(node44);
        com.google.javascript.rhino.Node node64 = com.google.javascript.rhino.IR.returnNode();
        boolean boolean65 = node64.isSwitch();
        com.google.javascript.rhino.Node node67 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean68 = node67.isFor();
        boolean boolean69 = node67.isExprResult();
        java.lang.String str70 = node67.getString();
        com.google.javascript.rhino.Node node71 = null;
        try {
            com.google.javascript.rhino.Node node74 = new com.google.javascript.rhino.Node(0, node2, node64, node67, node71, 39, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "hi!" + "'", str16.equals("hi!"));
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "hi!" + "'", str26.equals("hi!"));
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(node36);
        org.junit.Assert.assertNotNull(node37);
        org.junit.Assert.assertNotNull(node39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "hi!" + "'", str42.equals("hi!"));
        org.junit.Assert.assertNotNull(node44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(node47);
        org.junit.Assert.assertNotNull(node49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "hi!" + "'", str52.equals("hi!"));
        org.junit.Assert.assertNotNull(node54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertNotNull(node57);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + (-1) + "'", int58 == (-1));
        org.junit.Assert.assertNotNull(node59);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertNotNull(node63);
        org.junit.Assert.assertNotNull(node64);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertNotNull(node67);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
        org.junit.Assert.assertTrue("'" + str70 + "' != '" + "hi!" + "'", str70.equals("hi!"));
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean2 = node1.isFor();
        boolean boolean3 = node1.isExprResult();
        java.lang.String str4 = node1.getString();
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean7 = node6.isFor();
        boolean boolean8 = node6.isExprResult();
        com.google.javascript.rhino.Node node9 = node1.clonePropsFrom(node6);
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean12 = node11.isFor();
        boolean boolean13 = node11.isExprResult();
        java.lang.String str14 = node11.getString();
        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean17 = node16.isFor();
        boolean boolean18 = node16.isExprResult();
        com.google.javascript.rhino.Node node19 = node11.clonePropsFrom(node16);
        int int20 = node6.getIndexOfChild(node11);
        com.google.javascript.rhino.Node node22 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean23 = node22.isFor();
        boolean boolean24 = node22.isExprResult();
        java.lang.String str25 = node22.getString();
        com.google.javascript.rhino.Node node27 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean28 = node27.isFor();
        boolean boolean29 = node27.isExprResult();
        com.google.javascript.rhino.Node node30 = node22.clonePropsFrom(node27);
        com.google.javascript.rhino.Node node31 = com.google.javascript.rhino.IR.sheq(node6, node27);
        boolean boolean32 = node27.isComma();
        com.google.javascript.rhino.Node node33 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.InputId inputId34 = com.google.javascript.jscomp.NodeUtil.getInputId(node33);
        com.google.javascript.rhino.Node node35 = node27.copyInformationFrom(node33);
        com.google.javascript.rhino.Node node37 = com.google.javascript.rhino.IR.name("hi!");
        try {
            com.google.javascript.rhino.Node node38 = com.google.javascript.rhino.IR.assign(node35, node37);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "hi!" + "'", str4.equals("hi!"));
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "hi!" + "'", str14.equals("hi!"));
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "hi!" + "'", str25.equals("hi!"));
        org.junit.Assert.assertNotNull(node27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(node30);
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(node33);
        org.junit.Assert.assertNull(inputId34);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertNotNull(node37);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        com.google.javascript.rhino.Node[] nodeArray1 = null;
        try {
            com.google.javascript.rhino.Node node2 = new com.google.javascript.rhino.Node(45, nodeArray1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        com.google.javascript.jscomp.CompilerOptions.TweakProcessing tweakProcessing0 = com.google.javascript.jscomp.CompilerOptions.TweakProcessing.CHECK;
        org.junit.Assert.assertTrue("'" + tweakProcessing0 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TweakProcessing.CHECK + "'", tweakProcessing0.equals(com.google.javascript.jscomp.CompilerOptions.TweakProcessing.CHECK));
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        int int0 = com.google.javascript.rhino.Node.NO_SIDE_EFFECTS;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 15 + "'", int0 == 15);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.reportMissingOverride;
        compilerOptions0.setAppNameStr("module$STRING hi!");
        boolean boolean4 = compilerOptions0.crossModuleMethodMotion;
        boolean boolean5 = compilerOptions0.computeFunctionSideEffects;
        com.google.javascript.jscomp.CompilerOptions compilerOptions6 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel7 = compilerOptions6.reportMissingOverride;
        com.google.javascript.jscomp.CompilerOptions.LanguageMode languageMode8 = com.google.javascript.jscomp.CompilerOptions.LanguageMode.ECMASCRIPT5;
        compilerOptions6.setLanguageIn(languageMode8);
        compilerOptions0.setLanguageIn(languageMode8);
        compilerOptions0.deadAssignmentElimination = false;
        compilerOptions0.markAsCompiled = false;
        com.google.javascript.jscomp.CompilerOptions compilerOptions15 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel16 = compilerOptions15.reportMissingOverride;
        compilerOptions15.setAppNameStr("module$STRING hi!");
        boolean boolean19 = compilerOptions15.crossModuleMethodMotion;
        boolean boolean20 = compilerOptions15.computeFunctionSideEffects;
        compilerOptions15.locale = "module$STRING hi!";
        compilerOptions15.setComputeFunctionSideEffects(true);
        compilerOptions15.setAliasableGlobals("hi!");
        com.google.javascript.jscomp.CompilerOptions compilerOptions27 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel28 = compilerOptions27.reportMissingOverride;
        compilerOptions15.checkUnreachableCode = checkLevel28;
        com.google.javascript.jscomp.CompilerOptions compilerOptions30 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel31 = compilerOptions30.reportMissingOverride;
        compilerOptions30.setAppNameStr("module$STRING hi!");
        boolean boolean34 = compilerOptions30.crossModuleMethodMotion;
        boolean boolean35 = compilerOptions30.computeFunctionSideEffects;
        compilerOptions30.locale = "module$STRING hi!";
        compilerOptions30.setComputeFunctionSideEffects(true);
        compilerOptions30.setAliasableGlobals("hi!");
        com.google.javascript.jscomp.CompilerOptions compilerOptions42 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel43 = compilerOptions42.reportMissingOverride;
        compilerOptions30.checkUnreachableCode = checkLevel43;
        compilerOptions15.checkMissingGetCssNameLevel = checkLevel43;
        compilerOptions0.checkUnreachableCode = checkLevel43;
        compilerOptions0.setCheckCaja(true);
        boolean boolean49 = compilerOptions0.computeFunctionSideEffects;
        compilerOptions0.collapseProperties = true;
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + checkLevel7 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel7.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + languageMode8 + "' != '" + com.google.javascript.jscomp.CompilerOptions.LanguageMode.ECMASCRIPT5 + "'", languageMode8.equals(com.google.javascript.jscomp.CompilerOptions.LanguageMode.ECMASCRIPT5));
        org.junit.Assert.assertTrue("'" + checkLevel16 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel16.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + checkLevel28 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel28.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + checkLevel31 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel31.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + checkLevel43 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel43.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.reportMissingOverride;
        compilerOptions0.setAppNameStr("module$STRING hi!");
        boolean boolean4 = compilerOptions0.crossModuleMethodMotion;
        boolean boolean5 = compilerOptions0.computeFunctionSideEffects;
        com.google.javascript.jscomp.CompilerOptions compilerOptions6 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel7 = compilerOptions6.reportMissingOverride;
        com.google.javascript.jscomp.CompilerOptions.LanguageMode languageMode8 = com.google.javascript.jscomp.CompilerOptions.LanguageMode.ECMASCRIPT5;
        compilerOptions6.setLanguageIn(languageMode8);
        compilerOptions0.setLanguageIn(languageMode8);
        compilerOptions0.deadAssignmentElimination = false;
        compilerOptions0.markAsCompiled = false;
        com.google.javascript.jscomp.CompilerOptions compilerOptions15 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel16 = compilerOptions15.reportMissingOverride;
        compilerOptions15.setAppNameStr("module$STRING hi!");
        boolean boolean19 = compilerOptions15.crossModuleMethodMotion;
        boolean boolean20 = compilerOptions15.computeFunctionSideEffects;
        compilerOptions15.locale = "module$STRING hi!";
        compilerOptions15.setComputeFunctionSideEffects(true);
        compilerOptions15.setAliasableGlobals("hi!");
        com.google.javascript.jscomp.CompilerOptions compilerOptions27 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel28 = compilerOptions27.reportMissingOverride;
        compilerOptions15.checkUnreachableCode = checkLevel28;
        com.google.javascript.jscomp.CompilerOptions compilerOptions30 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel31 = compilerOptions30.reportMissingOverride;
        compilerOptions30.setAppNameStr("module$STRING hi!");
        boolean boolean34 = compilerOptions30.crossModuleMethodMotion;
        boolean boolean35 = compilerOptions30.computeFunctionSideEffects;
        compilerOptions30.locale = "module$STRING hi!";
        compilerOptions30.setComputeFunctionSideEffects(true);
        compilerOptions30.setAliasableGlobals("hi!");
        com.google.javascript.jscomp.CompilerOptions compilerOptions42 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel43 = compilerOptions42.reportMissingOverride;
        compilerOptions30.checkUnreachableCode = checkLevel43;
        compilerOptions15.checkMissingGetCssNameLevel = checkLevel43;
        compilerOptions0.checkUnreachableCode = checkLevel43;
        compilerOptions0.setCheckCaja(true);
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy49 = compilerOptions0.variableRenaming;
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + checkLevel7 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel7.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + languageMode8 + "' != '" + com.google.javascript.jscomp.CompilerOptions.LanguageMode.ECMASCRIPT5 + "'", languageMode8.equals(com.google.javascript.jscomp.CompilerOptions.LanguageMode.ECMASCRIPT5));
        org.junit.Assert.assertTrue("'" + checkLevel16 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel16.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + checkLevel28 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel28.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + checkLevel31 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel31.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + checkLevel43 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel43.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy49 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.OFF + "'", variableRenamingPolicy49.equals(com.google.javascript.jscomp.VariableRenamingPolicy.OFF));
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.reportMissingOverride;
        compilerOptions0.setAppNameStr("module$STRING hi!");
        compilerOptions0.setOutputJsStringUsage(true);
        java.util.Set<java.lang.String> strSet6 = null;
        compilerOptions0.setStripTypes(strSet6);
        com.google.javascript.jscomp.CompilerOptions compilerOptions8 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel9 = compilerOptions8.reportMissingOverride;
        compilerOptions8.setAppNameStr("module$STRING hi!");
        boolean boolean12 = compilerOptions8.crossModuleMethodMotion;
        boolean boolean13 = compilerOptions8.computeFunctionSideEffects;
        compilerOptions8.locale = "module$STRING hi!";
        compilerOptions8.setComputeFunctionSideEffects(true);
        compilerOptions8.setAliasableGlobals("hi!");
        com.google.javascript.jscomp.CompilerOptions compilerOptions20 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel21 = compilerOptions20.reportMissingOverride;
        compilerOptions8.checkUnreachableCode = checkLevel21;
        compilerOptions0.setCheckProvides(checkLevel21);
        boolean boolean24 = compilerOptions0.disambiguateProperties;
        com.google.javascript.jscomp.SourceMap.Format format25 = compilerOptions0.sourceMapFormat;
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + checkLevel9 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel9.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + checkLevel21 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel21.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(format25);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.NON_STANDARD_JSDOC;
        com.google.javascript.jscomp.DiagnosticGroups.AMBIGUOUS_FUNCTION_DECL = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticGroups.CONST = diagnosticGroup0;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.reportMissingOverride;
        compilerOptions0.setAppNameStr("module$STRING hi!");
        boolean boolean4 = compilerOptions0.crossModuleMethodMotion;
        boolean boolean5 = compilerOptions0.computeFunctionSideEffects;
        compilerOptions0.reserveRawExports = false;
        compilerOptions0.setLocale("");
        compilerOptions0.closurePass = true;
        compilerOptions0.setLocale("JSC_OPTIMIZE_LOOP_ERROR");
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.reportMissingOverride;
        compilerOptions0.setAppNameStr("module$STRING hi!");
        com.google.javascript.jscomp.CompilerOptions.Reach reach4 = com.google.javascript.jscomp.CompilerOptions.Reach.ALL;
        compilerOptions0.setRemoveUnusedVariables(reach4);
        java.lang.String str6 = compilerOptions0.renamePrefix;
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + reach4 + "' != '" + com.google.javascript.jscomp.CompilerOptions.Reach.ALL + "'", reach4.equals(com.google.javascript.jscomp.CompilerOptions.Reach.ALL));
        org.junit.Assert.assertNull(str6);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        com.google.javascript.rhino.Node node3 = new com.google.javascript.rhino.Node((int) (byte) 100, (int) (byte) 1, 54);
        int int4 = node3.getLength();
        int int5 = node3.getSourcePosition();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4150 + "'", int5 == 4150);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CompilerOptions compilerOptions1 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel2 = compilerOptions1.reportMissingOverride;
        compilerOptions0.setAggressiveVarCheck(checkLevel2);
        com.google.javascript.jscomp.SourceMap.Format format4 = compilerOptions0.sourceMapFormat;
        boolean boolean5 = compilerOptions0.collapseVariableDeclarations;
        compilerOptions0.setAcceptConstKeyword(true);
        compilerOptions0.markAsCompiled = true;
        boolean boolean10 = compilerOptions0.ambiguateProperties;
        java.util.Map<java.lang.String, java.lang.Object> strMap11 = null;
        compilerOptions0.setDefineReplacements(strMap11);
        org.junit.Assert.assertTrue("'" + checkLevel2 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel2.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(format4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean2 = node1.isFor();
        boolean boolean3 = node1.isExprResult();
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean6 = node5.isFor();
        com.google.javascript.rhino.Node node7 = node1.clonePropsFrom(node5);
        boolean boolean8 = node1.isOnlyModifiesThisCall();
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean11 = node10.isFor();
        boolean boolean12 = node10.isExprResult();
        java.lang.String str13 = node10.getString();
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean16 = node15.isFor();
        boolean boolean17 = node15.isExprResult();
        com.google.javascript.rhino.Node node18 = node10.clonePropsFrom(node15);
        boolean boolean19 = node18.isVar();
        com.google.javascript.rhino.Node node20 = node1.useSourceInfoFromForTree(node18);
        com.google.javascript.rhino.jstype.JSType jSType21 = null;
        node20.setJSType(jSType21);
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.IR.paramList();
        boolean boolean24 = node23.isThrow();
        node20.addChildToBack(node23);
        com.google.javascript.rhino.Node node27 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean28 = node27.isFor();
        boolean boolean29 = node27.isExprResult();
        com.google.javascript.rhino.Node node31 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean32 = node31.isFor();
        com.google.javascript.rhino.Node node33 = node27.clonePropsFrom(node31);
        boolean boolean34 = node27.isOnlyModifiesThisCall();
        com.google.javascript.rhino.Node node36 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean37 = node36.isFor();
        boolean boolean38 = node36.isExprResult();
        java.lang.String str39 = node36.getString();
        com.google.javascript.rhino.Node node41 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean42 = node41.isFor();
        boolean boolean43 = node41.isExprResult();
        com.google.javascript.rhino.Node node44 = node36.clonePropsFrom(node41);
        boolean boolean45 = node44.isVar();
        com.google.javascript.rhino.Node node46 = node27.useSourceInfoFromForTree(node44);
        boolean boolean47 = node46.isLabelName();
        com.google.javascript.rhino.Node node48 = node20.useSourceInfoFromForTree(node46);
        com.google.javascript.rhino.Node node50 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean51 = node50.isFor();
        boolean boolean52 = node50.isExprResult();
        java.lang.String str53 = node50.getString();
        com.google.javascript.rhino.Node node55 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean56 = node55.isFor();
        boolean boolean57 = node55.isExprResult();
        com.google.javascript.rhino.Node node58 = node50.clonePropsFrom(node55);
        com.google.javascript.rhino.Node node59 = com.google.javascript.rhino.IR.pos(node50);
        boolean boolean60 = node50.isWhile();
        com.google.javascript.rhino.Node node62 = com.google.javascript.rhino.Node.newString("hi!");
        com.google.javascript.rhino.Node node63 = com.google.javascript.rhino.IR.voidNode(node62);
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable64 = node63.children();
        com.google.javascript.rhino.Node node65 = node50.srcrefTree(node63);
        boolean boolean66 = node65.isEmpty();
        try {
            com.google.javascript.rhino.Node node67 = com.google.javascript.rhino.IR.caseNode(node20, node65);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "hi!" + "'", str13.equals("hi!"));
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(node27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(node33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(node36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "hi!" + "'", str39.equals("hi!"));
        org.junit.Assert.assertNotNull(node41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(node44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(node46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(node48);
        org.junit.Assert.assertNotNull(node50);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "hi!" + "'", str53.equals("hi!"));
        org.junit.Assert.assertNotNull(node55);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertNotNull(node58);
        org.junit.Assert.assertNotNull(node59);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertNotNull(node62);
        org.junit.Assert.assertNotNull(node63);
        org.junit.Assert.assertNotNull(nodeIterable64);
        org.junit.Assert.assertNotNull(node65);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.reportMissingOverride;
        compilerOptions0.setAppNameStr("module$STRING hi!");
        boolean boolean4 = compilerOptions0.crossModuleMethodMotion;
        boolean boolean5 = compilerOptions0.computeFunctionSideEffects;
        compilerOptions0.reserveRawExports = false;
        compilerOptions0.setLocale("");
        java.lang.String str10 = compilerOptions0.sourceMapOutputPath;
        compilerOptions0.setProcessObjectPropertyString(true);
        java.util.Set<java.lang.String> strSet13 = compilerOptions0.aliasableStrings;
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertNotNull(strSet13);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        java.util.logging.Logger logger0 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager1 = new com.google.javascript.jscomp.LoggerErrorManager(logger0);
        double double2 = loggerErrorManager1.getTypedPercent();
        com.google.javascript.jscomp.Compiler compiler3 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager1);
        com.google.javascript.jscomp.Result result4 = compiler3.getResult();
        java.util.logging.Logger logger5 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager6 = new com.google.javascript.jscomp.LoggerErrorManager(logger5);
        double double7 = loggerErrorManager6.getTypedPercent();
        compiler3.setErrorManager((com.google.javascript.jscomp.ErrorManager) loggerErrorManager6);
        com.google.javascript.jscomp.NodeTraversal.Callback callback9 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal10 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler3, callback9);
        com.google.javascript.jscomp.Result result11 = compiler3.getResult();
        java.io.PrintStream printStream12 = null;
        com.google.javascript.jscomp.Compiler compiler13 = new com.google.javascript.jscomp.Compiler(printStream12);
        java.nio.charset.Charset charset15 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile16 = com.google.javascript.jscomp.JSSourceFile.fromFile("hi!. hi! at (unknown source) line (unknown line) : (unknown column)", charset15);
        com.google.javascript.jscomp.SourceFile.Generator generator18 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile19 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("goog.global", generator18);
        com.google.javascript.jscomp.CompilerInput compilerInput20 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile19);
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray21 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile19 };
        com.google.javascript.jscomp.CompilerOptions compilerOptions22 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel23 = compilerOptions22.reportMissingOverride;
        compilerOptions22.setAppNameStr("module$STRING hi!");
        boolean boolean26 = compilerOptions22.crossModuleMethodMotion;
        boolean boolean27 = compilerOptions22.computeFunctionSideEffects;
        compilerOptions22.reserveRawExports = false;
        boolean boolean30 = compilerOptions22.collapseAnonymousFunctions;
        boolean boolean31 = compilerOptions22.exportTestFunctions;
        com.google.javascript.jscomp.CheckLevel checkLevel32 = null;
        compilerOptions22.setCheckRequires(checkLevel32);
        com.google.javascript.jscomp.Result result34 = compiler13.compile(jSSourceFile16, jSSourceFileArray21, compilerOptions22);
        java.lang.String str35 = jSSourceFile16.getOriginalPath();
        com.google.javascript.jscomp.SourceFile sourceFile37 = com.google.javascript.jscomp.SourceFile.fromFile("hi!");
        boolean boolean38 = sourceFile37.isExtern();
        com.google.javascript.jscomp.JsAst jsAst39 = new com.google.javascript.jscomp.JsAst(sourceFile37);
        java.util.logging.Logger logger40 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager41 = new com.google.javascript.jscomp.LoggerErrorManager(logger40);
        double double42 = loggerErrorManager41.getTypedPercent();
        com.google.javascript.jscomp.Compiler compiler43 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager41);
        com.google.javascript.jscomp.Result result44 = compiler43.getResult();
        java.util.logging.Logger logger45 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager46 = new com.google.javascript.jscomp.LoggerErrorManager(logger45);
        double double47 = loggerErrorManager46.getTypedPercent();
        compiler43.setErrorManager((com.google.javascript.jscomp.ErrorManager) loggerErrorManager46);
        com.google.javascript.jscomp.NodeTraversal.Callback callback49 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal50 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler43, callback49);
        com.google.javascript.jscomp.Scope scope51 = compiler43.getTopScope();
        com.google.javascript.rhino.Node node52 = jsAst39.getAstRoot((com.google.javascript.jscomp.AbstractCompiler) compiler43);
        java.lang.String str55 = compiler43.getSourceLine("// Input %num%", (-1));
        com.google.javascript.jscomp.SourceFile.Generator generator57 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile58 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("goog.global", generator57);
        jSSourceFile58.clearCachedSource();
        java.nio.charset.Charset charset61 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile62 = com.google.javascript.jscomp.JSSourceFile.fromFile("hi!. hi! at (unknown source) line (unknown line) : (unknown column)", charset61);
        java.lang.Class<?> wildcardClass63 = jSSourceFile62.getClass();
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray64 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile58, jSSourceFile62 };
        com.google.javascript.jscomp.JSModule[] jSModuleArray65 = new com.google.javascript.jscomp.JSModule[] {};
        com.google.javascript.jscomp.CompilerOptions compilerOptions66 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel67 = compilerOptions66.reportMissingOverride;
        com.google.javascript.jscomp.CompilerOptions.LanguageMode languageMode68 = com.google.javascript.jscomp.CompilerOptions.LanguageMode.ECMASCRIPT5;
        compilerOptions66.setLanguageIn(languageMode68);
        compiler43.init(jSSourceFileArray64, jSModuleArray65, compilerOptions66);
        com.google.javascript.jscomp.CompilerOptions compilerOptions71 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel72 = compilerOptions71.reportMissingOverride;
        compilerOptions71.setAppNameStr("module$STRING hi!");
        com.google.javascript.jscomp.CompilerOptions compilerOptions75 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel76 = compilerOptions75.reportMissingOverride;
        compilerOptions75.setAppNameStr("module$STRING hi!");
        boolean boolean79 = compilerOptions75.crossModuleMethodMotion;
        boolean boolean80 = compilerOptions75.computeFunctionSideEffects;
        compilerOptions75.locale = "module$STRING hi!";
        compilerOptions75.setComputeFunctionSideEffects(true);
        boolean boolean85 = compilerOptions75.ambiguateProperties;
        boolean boolean86 = compilerOptions75.exportTestFunctions;
        com.google.javascript.jscomp.SourceMap.Format format87 = compilerOptions75.sourceMapFormat;
        compilerOptions71.setSourceMapFormat(format87);
        try {
            com.google.javascript.jscomp.Result result89 = compiler3.compile(jSSourceFile16, jSSourceFileArray64, compilerOptions71);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(result4);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(result11);
        org.junit.Assert.assertNotNull(jSSourceFile16);
        org.junit.Assert.assertNotNull(jSSourceFile19);
        org.junit.Assert.assertNotNull(jSSourceFileArray21);
        org.junit.Assert.assertTrue("'" + checkLevel23 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel23.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(result34);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "hi!. hi! at (unknown source) line (unknown line) : (unknown column)" + "'", str35.equals("hi!. hi! at (unknown source) line (unknown line) : (unknown column)"));
        org.junit.Assert.assertNotNull(sourceFile37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 0.0d + "'", double42 == 0.0d);
        org.junit.Assert.assertNotNull(result44);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 0.0d + "'", double47 == 0.0d);
        org.junit.Assert.assertNull(scope51);
        org.junit.Assert.assertNotNull(node52);
        org.junit.Assert.assertNull(str55);
        org.junit.Assert.assertNotNull(jSSourceFile58);
        org.junit.Assert.assertNotNull(jSSourceFile62);
        org.junit.Assert.assertNotNull(wildcardClass63);
        org.junit.Assert.assertNotNull(jSSourceFileArray64);
        org.junit.Assert.assertNotNull(jSModuleArray65);
        org.junit.Assert.assertTrue("'" + checkLevel67 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel67.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + languageMode68 + "' != '" + com.google.javascript.jscomp.CompilerOptions.LanguageMode.ECMASCRIPT5 + "'", languageMode68.equals(com.google.javascript.jscomp.CompilerOptions.LanguageMode.ECMASCRIPT5));
        org.junit.Assert.assertTrue("'" + checkLevel72 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel72.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + checkLevel76 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel76.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + false + "'", boolean80 == false);
        org.junit.Assert.assertTrue("'" + boolean85 + "' != '" + false + "'", boolean85 == false);
        org.junit.Assert.assertTrue("'" + boolean86 + "' != '" + false + "'", boolean86 == false);
        org.junit.Assert.assertNotNull(format87);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        java.util.logging.Logger logger0 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager1 = new com.google.javascript.jscomp.LoggerErrorManager(logger0);
        double double2 = loggerErrorManager1.getTypedPercent();
        com.google.javascript.jscomp.Compiler compiler3 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager1);
        com.google.javascript.jscomp.Result result4 = compiler3.getResult();
        java.util.logging.Logger logger5 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager6 = new com.google.javascript.jscomp.LoggerErrorManager(logger5);
        double double7 = loggerErrorManager6.getTypedPercent();
        compiler3.setErrorManager((com.google.javascript.jscomp.ErrorManager) loggerErrorManager6);
        com.google.javascript.jscomp.NodeTraversal.Callback callback9 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal10 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler3, callback9);
        com.google.javascript.jscomp.Result result11 = compiler3.getResult();
        int int12 = compiler3.getErrorCount();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(result4);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(result11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        java.util.logging.Logger logger0 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager1 = new com.google.javascript.jscomp.LoggerErrorManager(logger0);
        double double2 = loggerErrorManager1.getTypedPercent();
        com.google.javascript.jscomp.Compiler compiler3 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager1);
        com.google.javascript.jscomp.Result result4 = compiler3.getResult();
        java.util.logging.Logger logger5 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager6 = new com.google.javascript.jscomp.LoggerErrorManager(logger5);
        double double7 = loggerErrorManager6.getTypedPercent();
        compiler3.setErrorManager((com.google.javascript.jscomp.ErrorManager) loggerErrorManager6);
        compiler3.disableThreads();
        try {
            compiler3.parse();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(result4);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newNumber(0.0d);
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.IR.returnNode(node1);
        com.google.javascript.rhino.Node node3 = node2.getFirstChild();
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertNotNull(node3);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newNumber(0.0d);
        com.google.javascript.rhino.Node.AncestorIterable ancestorIterable2 = node1.getAncestors();
        boolean boolean3 = node1.isThrow();
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertNotNull(ancestorIterable2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.INVALID_CASTS;
        com.google.javascript.jscomp.DiagnosticGroups.UNDEFINED_NAMES = diagnosticGroup0;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        com.google.javascript.jscomp.CodingConvention codingConvention0 = com.google.javascript.jscomp.CodingConventions.getDefault();
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention1 = new com.google.javascript.jscomp.ClosureCodingConvention(codingConvention0);
        boolean boolean4 = closureCodingConvention1.isExported("hi!", true);
        java.lang.String str5 = closureCodingConvention1.getGlobalObject();
        org.junit.Assert.assertNotNull(codingConvention0);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "goog.global" + "'", str5.equals("goog.global"));
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.reportMissingOverride;
        compilerOptions0.setAppNameStr("module$STRING hi!");
        compilerOptions0.setOutputJsStringUsage(true);
        java.util.Set<java.lang.String> strSet6 = null;
        compilerOptions0.setStripTypes(strSet6);
        compilerOptions0.removeUnusedVars = false;
        compilerOptions0.setDefineToNumberLiteral("InputId: ", (int) 'a');
        compilerOptions0.crossModuleMethodMotion = false;
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean2 = node1.isFor();
        boolean boolean3 = node1.hasChildren();
        boolean boolean4 = node1.isLabel();
        try {
            com.google.javascript.rhino.Node node5 = node1.detachFromParent();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean3 = node2.isFor();
        boolean boolean4 = node2.isExprResult();
        java.lang.String str5 = node2.getString();
        boolean boolean6 = node2.isGetterDef();
        int int7 = node2.getSourcePosition();
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean10 = node9.isFor();
        boolean boolean11 = node9.isExprResult();
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean14 = node13.isFor();
        com.google.javascript.rhino.Node node15 = node9.clonePropsFrom(node13);
        boolean boolean16 = node9.isOnlyModifiesThisCall();
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean19 = node18.isFor();
        boolean boolean20 = node18.isExprResult();
        java.lang.String str21 = node18.getString();
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean24 = node23.isFor();
        boolean boolean25 = node23.isExprResult();
        com.google.javascript.rhino.Node node26 = node18.clonePropsFrom(node23);
        boolean boolean27 = node26.isVar();
        com.google.javascript.rhino.Node node28 = node9.useSourceInfoFromForTree(node26);
        boolean boolean29 = node9.isTypeOf();
        com.google.javascript.rhino.jstype.JSType jSType30 = null;
        node9.setJSType(jSType30);
        boolean boolean32 = node9.isString();
        com.google.javascript.rhino.Node node34 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean35 = node34.isFor();
        boolean boolean36 = node34.isExprResult();
        java.lang.String str37 = node34.getString();
        com.google.javascript.rhino.Node node39 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean40 = node39.isFor();
        boolean boolean41 = node39.isExprResult();
        com.google.javascript.rhino.Node node42 = node34.clonePropsFrom(node39);
        com.google.javascript.rhino.Node node43 = com.google.javascript.rhino.IR.pos(node34);
        boolean boolean44 = node34.isWhile();
        com.google.javascript.rhino.Node node46 = com.google.javascript.rhino.Node.newString("hi!");
        com.google.javascript.rhino.Node node47 = com.google.javascript.rhino.IR.voidNode(node46);
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable48 = node47.children();
        com.google.javascript.rhino.Node node49 = node34.srcrefTree(node47);
        com.google.javascript.jscomp.CodingConvention codingConvention50 = com.google.javascript.jscomp.CodingConventions.getDefault();
        com.google.javascript.rhino.Node node52 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode(codingConvention50, "./");
        com.google.javascript.rhino.Node node53 = com.google.javascript.rhino.IR.throwNode(node52);
        try {
            com.google.javascript.rhino.Node node56 = new com.google.javascript.rhino.Node((int) (short) -1, node2, node9, node49, node53, (int) (short) -1, (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "hi!" + "'", str21.equals("hi!"));
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNotNull(node34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "hi!" + "'", str37.equals("hi!"));
        org.junit.Assert.assertNotNull(node39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(node42);
        org.junit.Assert.assertNotNull(node43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(node46);
        org.junit.Assert.assertNotNull(node47);
        org.junit.Assert.assertNotNull(nodeIterable48);
        org.junit.Assert.assertNotNull(node49);
        org.junit.Assert.assertNotNull(codingConvention50);
        org.junit.Assert.assertNotNull(node52);
        org.junit.Assert.assertNotNull(node53);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newNumber(0.0d);
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.IR.returnNode(node1);
        node2.setOptionalArg(true);
        com.google.javascript.rhino.Node node5 = node2.getLastChild();
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertNotNull(node5);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.reportMissingOverride;
        compilerOptions0.setAppNameStr("module$STRING hi!");
        com.google.javascript.jscomp.CompilerOptions.Reach reach4 = com.google.javascript.jscomp.CompilerOptions.Reach.ALL;
        compilerOptions0.setRemoveUnusedVariables(reach4);
        compilerOptions0.aliasAllStrings = true;
        com.google.javascript.jscomp.CompilerOptions.TweakProcessing tweakProcessing8 = compilerOptions0.getTweakProcessing();
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + reach4 + "' != '" + com.google.javascript.jscomp.CompilerOptions.Reach.ALL + "'", reach4.equals(com.google.javascript.jscomp.CompilerOptions.Reach.ALL));
        org.junit.Assert.assertTrue("'" + tweakProcessing8 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TweakProcessing.OFF + "'", tweakProcessing8.equals(com.google.javascript.jscomp.CompilerOptions.TweakProcessing.OFF));
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean2 = node1.isFor();
        boolean boolean3 = node1.isExprResult();
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean6 = node5.isFor();
        com.google.javascript.rhino.Node node7 = node1.clonePropsFrom(node5);
        boolean boolean8 = node1.isOnlyModifiesThisCall();
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean11 = node10.isFor();
        boolean boolean12 = node10.isExprResult();
        java.lang.String str13 = node10.getString();
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean16 = node15.isFor();
        boolean boolean17 = node15.isExprResult();
        com.google.javascript.rhino.Node node18 = node10.clonePropsFrom(node15);
        boolean boolean19 = node18.isVar();
        com.google.javascript.rhino.Node node20 = node1.useSourceInfoFromForTree(node18);
        com.google.javascript.rhino.jstype.JSType jSType21 = null;
        node20.setJSType(jSType21);
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.IR.paramList();
        boolean boolean24 = node23.isThrow();
        node20.addChildToBack(node23);
        com.google.javascript.rhino.jstype.JSType jSType26 = node23.getJSType();
        boolean boolean27 = node23.isAssign();
        boolean boolean28 = node23.isCase();
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "hi!" + "'", str13.equals("hi!"));
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNull(jSType26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        com.google.javascript.rhino.Node[] nodeArray0 = null;
        try {
            com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.objectlit(nodeArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }
}

