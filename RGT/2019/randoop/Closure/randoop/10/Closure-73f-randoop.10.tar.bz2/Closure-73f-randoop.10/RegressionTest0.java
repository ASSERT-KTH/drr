import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        com.google.javascript.jscomp.AbstractCompiler abstractCompiler0 = null;
        java.util.List<com.google.javascript.rhino.Node> nodeList1 = null;
        com.google.javascript.jscomp.NodeTraversal.Callback callback2 = null;
        try {
            com.google.javascript.jscomp.NodeTraversal.traverseRoots(abstractCompiler0, nodeList1, callback2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        com.google.javascript.rhino.jstype.JSType jSType0 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType1 = com.google.javascript.rhino.jstype.ObjectType.cast(jSType0);
        org.junit.Assert.assertNull(objectType1);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        int int0 = com.google.javascript.rhino.Node.QUOTED_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 35 + "'", int0 == 35);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        com.google.javascript.jscomp.parsing.Config.LanguageMode languageMode0 = com.google.javascript.jscomp.parsing.Config.LanguageMode.ECMASCRIPT5;
        org.junit.Assert.assertTrue("'" + languageMode0 + "' != '" + com.google.javascript.jscomp.parsing.Config.LanguageMode.ECMASCRIPT5 + "'", languageMode0.equals(com.google.javascript.jscomp.parsing.Config.LanguageMode.ECMASCRIPT5));
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        com.google.javascript.jscomp.SourceExcerptProvider sourceExcerptProvider0 = null;
        try {
            com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter1 = new com.google.javascript.jscomp.LightweightMessageFormatter(sourceExcerptProvider0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        int int0 = com.google.javascript.rhino.Context.FEATURE_DYNAMIC_SCOPE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 7 + "'", int0 == 7);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        int int0 = com.google.javascript.rhino.Node.TARGETBLOCK_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 22 + "'", int0 == 22);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        long long1 = com.google.javascript.rhino.ScriptRuntime.testUint32String("");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1L) + "'", long1 == (-1L));
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = null;
        com.google.javascript.jscomp.DiagnosticGroups.INVALID_CASTS = diagnosticGroup0;
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile0 = null;
        try {
            com.google.javascript.jscomp.CompilerInput compilerInput1 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.NON_STANDARD_JSDOC;
        com.google.javascript.jscomp.JSError jSError1 = null;
        try {
            boolean boolean2 = diagnosticGroup0.matches(jSError1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        int int0 = com.google.javascript.rhino.Node.FINALLY_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 20 + "'", int0 == 20);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        int int0 = com.google.javascript.rhino.Context.VERSION_1_6;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 160 + "'", int0 == 160);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        com.google.javascript.rhino.jstype.JSType jSType0 = null;
        com.google.javascript.rhino.jstype.JSType jSType1 = null;
        boolean boolean2 = com.google.javascript.rhino.jstype.JSType.isEquivalent(jSType0, jSType1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        com.google.javascript.jscomp.WarningsGuard warningsGuard0 = null;
        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray1 = new com.google.javascript.jscomp.WarningsGuard[] { warningsGuard0 };
        try {
            com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard2 = new com.google.javascript.jscomp.ComposeWarningsGuard(warningsGuardArray1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(warningsGuardArray1);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        java.lang.Object obj3 = null;
        try {
            java.lang.String str4 = com.google.javascript.rhino.ScriptRuntime.getMessage2("hi!", (java.lang.Object) "", obj3);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property hi!");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile2);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        int int0 = com.google.javascript.rhino.Context.FEATURE_STRICT_EVAL;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 9 + "'", int0 == 9);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        int int0 = com.google.javascript.rhino.Node.NO_SIDE_EFFECTS;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 15 + "'", int0 == 15);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        int int0 = com.google.javascript.rhino.Context.VERSION_UNKNOWN;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + (-1) + "'", int0 == (-1));
    }

//    @Test
//    public void test020() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test020");
//        try {
//            com.google.javascript.rhino.EvaluatorException evaluatorException1 = com.google.javascript.rhino.Context.reportRuntimeError("");
//            org.junit.Assert.fail("Expected exception of type com.google.javascript.rhino.EvaluatorException; message: ");
//        } catch (com.google.javascript.rhino.EvaluatorException e) {
//        }
//    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        int int0 = com.google.javascript.rhino.Node.POST_FLAG;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        int int0 = com.google.javascript.rhino.Node.EMPTY_BLOCK;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 38 + "'", int0 == 38);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        com.google.javascript.rhino.JSDocInfo jSDocInfo5 = null;
        node4.setJSDocInfo(jSDocInfo5);
        java.lang.RuntimeException runtimeException8 = com.google.javascript.rhino.ScriptRuntime.undefReadError((java.lang.Object) node4, (java.lang.Object) 22);
        try {
            int int10 = node4.getExistingIntProp(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: FAILED ASSERTION");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(runtimeException8);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        java.lang.RuntimeException runtimeException1 = com.google.javascript.rhino.ScriptRuntime.notFunctionError((java.lang.Object) 100);
        org.junit.Assert.assertNotNull(runtimeException1);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        int int0 = com.google.javascript.rhino.Context.FEATURE_PARENT_PROTO_PROPRTIES;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 5 + "'", int0 == 5);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        java.lang.String str0 = com.google.javascript.rhino.Context.languageVersionProperty;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "language version" + "'", str0.equals("language version"));
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        try {
            java.lang.String str1 = com.google.javascript.rhino.ScriptRuntime.getMessage0("");
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property ");
        } catch (java.lang.RuntimeException e) {
        }
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.NON_STANDARD_JSDOC;
        com.google.javascript.jscomp.DiagnosticGroups.TWEAKS = diagnosticGroup0;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        java.io.File file0 = null;
        try {
            com.google.javascript.jscomp.SourceFile sourceFile1 = com.google.javascript.jscomp.SourceFile.fromFile(file0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        int int0 = com.google.javascript.rhino.Node.MAX_COLUMN_NUMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4095 + "'", int0 == 4095);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        com.google.javascript.jscomp.CodingConvention codingConvention0 = null;
        try {
            com.google.javascript.rhino.Node node4 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode(codingConvention0, "", (int) '4', 9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        java.util.logging.Level level0 = null;
        com.google.javascript.jscomp.Compiler.setLoggingLevel(level0);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        com.google.javascript.jscomp.ErrorManager errorManager0 = null;
        try {
            com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(errorManager0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: the error manager cannot be null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        int int0 = com.google.javascript.rhino.Node.SIDE_EFFECTS_FLAGS_MASK;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 31 + "'", int0 == 31);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        try {
            com.google.javascript.rhino.EcmaError ecmaError1 = com.google.javascript.rhino.ScriptRuntime.typeError0("hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property hi!");
        } catch (java.lang.RuntimeException e) {
        }
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        java.lang.String str0 = com.google.javascript.rhino.Context.errorReporterProperty;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "error reporter" + "'", str0.equals("error reporter"));
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        boolean boolean5 = node4.hasMoreThanOneChild();
        node4.setLineno(0);
        com.google.javascript.rhino.Node node8 = node4.cloneTree();
        com.google.javascript.rhino.Node node9 = node8.removeFirstChild();
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        node14.removeProp((int) (short) 1);
        com.google.javascript.rhino.Node node22 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        boolean boolean23 = node22.hasMoreThanOneChild();
        node22.setLineno(0);
        boolean boolean26 = node22.hasOneChild();
        com.google.javascript.rhino.jstype.JSType jSType27 = node22.getJSType();
        com.google.javascript.rhino.Node node32 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        node32.removeProp((int) (short) 1);
        com.google.javascript.rhino.Node[] nodeArray35 = new com.google.javascript.rhino.Node[] { node22, node32 };
        com.google.javascript.rhino.Node node38 = new com.google.javascript.rhino.Node((int) (byte) 10, nodeArray35, (int) '4', (int) (byte) -1);
        com.google.javascript.rhino.Node node39 = node14.copyInformationFromForTree(node38);
        node14.setLineno((int) (short) 10);
        com.google.javascript.rhino.Node node46 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        node46.removeProp((int) (short) 1);
        com.google.javascript.rhino.Node node54 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        boolean boolean55 = node54.hasMoreThanOneChild();
        node54.setLineno(0);
        boolean boolean58 = node54.hasOneChild();
        com.google.javascript.rhino.jstype.JSType jSType59 = node54.getJSType();
        com.google.javascript.rhino.Node node64 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        node64.removeProp((int) (short) 1);
        com.google.javascript.rhino.Node[] nodeArray67 = new com.google.javascript.rhino.Node[] { node54, node64 };
        com.google.javascript.rhino.Node node70 = new com.google.javascript.rhino.Node((int) (byte) 10, nodeArray67, (int) '4', (int) (byte) -1);
        com.google.javascript.rhino.Node node71 = node46.copyInformationFromForTree(node70);
        try {
            node9.addChildBefore(node14, node70);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNull(node9);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNull(jSType27);
        org.junit.Assert.assertNotNull(node32);
        org.junit.Assert.assertNotNull(nodeArray35);
        org.junit.Assert.assertNotNull(node39);
        org.junit.Assert.assertNotNull(node46);
        org.junit.Assert.assertNotNull(node54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNull(jSType59);
        org.junit.Assert.assertNotNull(node64);
        org.junit.Assert.assertNotNull(nodeArray67);
        org.junit.Assert.assertNotNull(node71);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        int int0 = com.google.javascript.rhino.Node.MEMBER_TYPE_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 32 + "'", int0 == 32);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        boolean boolean1 = com.google.javascript.rhino.Context.isValidOptimizationLevel((int) (byte) 0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        com.google.javascript.jscomp.parsing.Config config2 = null;
        com.google.javascript.jscomp.mozilla.rhino.ErrorReporter errorReporter3 = null;
        java.util.logging.Logger logger4 = null;
        try {
            com.google.javascript.rhino.Node node5 = com.google.javascript.jscomp.parsing.ParserRunner.parse("hi!", "", config2, errorReporter3, logger4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test041() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test041");
//        try {
//            com.google.javascript.rhino.EvaluatorException evaluatorException5 = com.google.javascript.rhino.Context.reportRuntimeError("", "language version", 4095, "", 5);
//            org.junit.Assert.fail("Expected exception of type com.google.javascript.rhino.EvaluatorException; message:  (language version#4095)");
//        } catch (com.google.javascript.rhino.EvaluatorException e) {
//        }
//    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        int int0 = com.google.javascript.rhino.Context.FEATURE_MEMBER_EXPR_AS_FUNCTION_NAME;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        java.lang.String str1 = com.google.javascript.rhino.ScriptRuntime.escapeString("");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        int int0 = com.google.javascript.rhino.Node.COLUMN_BITS;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 12 + "'", int0 == 12);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        com.google.javascript.jscomp.SourceMap.Format format0 = com.google.javascript.jscomp.SourceMap.Format.EXPERIMENTIAL;
        org.junit.Assert.assertNotNull(format0);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString("", 9, (int) '#');
        try {
            boolean boolean5 = closureCodingConvention0.isPropertyTestFunction(node4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node4);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        int int0 = com.google.javascript.rhino.Node.PROPERTY_FLAG;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        com.google.javascript.jscomp.SourceAst sourceAst0 = null;
        try {
            com.google.javascript.jscomp.CompilerInput compilerInput1 = new com.google.javascript.jscomp.CompilerInput(sourceAst0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.devirtualizePrototypeMethods = false;
        compilerOptions0.collapseProperties = false;
        com.google.javascript.jscomp.WarningsGuard warningsGuard5 = null;
        try {
            compilerOptions0.addWarningsGuard(warningsGuard5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.devirtualizePrototypeMethods = false;
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy3 = com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC;
        compilerOptions0.propertyRenaming = propertyRenamingPolicy3;
        compilerOptions0.checkCaja = true;
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy3 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC + "'", propertyRenamingPolicy3.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC));
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        int int0 = com.google.javascript.rhino.Node.FLAG_THIS_UNMODIFIED;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        boolean boolean7 = node6.hasMoreThanOneChild();
        node6.setLineno(0);
        boolean boolean10 = node6.hasOneChild();
        com.google.javascript.rhino.jstype.JSType jSType11 = node6.getJSType();
        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        node16.removeProp((int) (short) 1);
        com.google.javascript.rhino.Node[] nodeArray19 = new com.google.javascript.rhino.Node[] { node6, node16 };
        com.google.javascript.rhino.Node node22 = new com.google.javascript.rhino.Node((int) (byte) 10, nodeArray19, (int) '4', (int) (byte) -1);
        try {
            com.google.javascript.rhino.Node node23 = new com.google.javascript.rhino.Node(7, nodeArray19);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: duplicate child");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNull(jSType11);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertNotNull(nodeArray19);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        int int0 = com.google.javascript.rhino.Node.IS_CONSTANT_NAME;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 42 + "'", int0 == 42);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.devirtualizePrototypeMethods = false;
        compilerOptions0.groupVariableDeclarations = false;
        boolean boolean5 = compilerOptions0.crossModuleCodeMotion;
        compilerOptions0.setManageClosureDependencies(true);
        compilerOptions0.inlineVariables = false;
        compilerOptions0.printInputDelimiter = true;
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        java.io.File file0 = null;
        java.nio.charset.Charset charset1 = null;
        try {
            com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromFile(file0, charset1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        int int0 = com.google.javascript.rhino.Node.TEMP_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 6 + "'", int0 == 6);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        com.google.javascript.rhino.Context context0 = new com.google.javascript.rhino.Context();
        com.google.javascript.jscomp.AnonymousFunctionNamingPolicy anonymousFunctionNamingPolicy1 = com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.UNMAPPED;
        context0.removeThreadLocal((java.lang.Object) anonymousFunctionNamingPolicy1);
        long long3 = com.google.javascript.rhino.ScriptRuntime.lastUint32Result(context0);
        context0.setInstructionObserverThreshold((int) (byte) 100);
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        try {
            context0.addPropertyChangeListener(propertyChangeListener6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + anonymousFunctionNamingPolicy1 + "' != '" + com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.UNMAPPED + "'", anonymousFunctionNamingPolicy1.equals(com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.UNMAPPED));
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        node4.removeProp((int) (short) 1);
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        boolean boolean13 = node12.hasMoreThanOneChild();
        node12.setLineno(0);
        boolean boolean16 = node12.hasOneChild();
        com.google.javascript.rhino.jstype.JSType jSType17 = node12.getJSType();
        com.google.javascript.rhino.Node node22 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        node22.removeProp((int) (short) 1);
        com.google.javascript.rhino.Node[] nodeArray25 = new com.google.javascript.rhino.Node[] { node12, node22 };
        com.google.javascript.rhino.Node node28 = new com.google.javascript.rhino.Node((int) (byte) 10, nodeArray25, (int) '4', (int) (byte) -1);
        com.google.javascript.rhino.Node node29 = node4.copyInformationFromForTree(node28);
        boolean boolean30 = node4.hasChildren();
        com.google.javascript.rhino.Node node32 = node4.getChildAtIndex((int) (short) 0);
        try {
            boolean boolean33 = node32.isSyntheticBlock();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNull(jSType17);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertNotNull(nodeArray25);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNull(node32);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        int int0 = com.google.javascript.rhino.Context.VERSION_1_4;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 140 + "'", int0 == 140);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        node4.setSourcePositionForTree(20);
        try {
            node4.setSideEffectFlags(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: setIsNoSideEffectsCall only supports CALL and NEW nodes, got EOL");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node4);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile1 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.CompilerInput compilerInput2 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile1);
        boolean boolean3 = compilerInput2.isExtern();
        try {
            java.lang.String str4 = compilerInput2.getCode();
            org.junit.Assert.fail("Expected exception of type java.io.FileNotFoundException; message:  (No such file or directory)");
        } catch (java.io.FileNotFoundException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        java.lang.String str1 = com.google.javascript.rhino.Node.tokenToName(160);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "<unknown=160>" + "'", str1.equals("<unknown=160>"));
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy0 = com.google.javascript.jscomp.PropertyRenamingPolicy.ALL_UNQUOTED;
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy0 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.ALL_UNQUOTED + "'", propertyRenamingPolicy0.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.ALL_UNQUOTED));
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        int int0 = com.google.javascript.rhino.Node.FLAG_GLOBAL_STATE_UNMODIFIED;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        com.google.javascript.jscomp.DiagnosticType[] diagnosticTypeArray0 = null;
        try {
            com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup1 = new com.google.javascript.jscomp.DiagnosticGroup(diagnosticTypeArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        com.google.javascript.jscomp.AbstractCompiler abstractCompiler0 = null;
        com.google.javascript.jscomp.NodeTraversal.Callback callback1 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal2 = new com.google.javascript.jscomp.NodeTraversal(abstractCompiler0, callback1);
        try {
            com.google.javascript.jscomp.CompilerInput compilerInput3 = nodeTraversal2.getInput();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        int int0 = com.google.javascript.rhino.Context.FEATURE_STRICT_MODE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 11 + "'", int0 == 11);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        int int0 = com.google.javascript.rhino.Node.SYNTHETIC_BLOCK_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 37 + "'", int0 == 37);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        com.google.javascript.jscomp.SourceFile.Generator generator1 = null;
        com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromGenerator("error reporter", generator1);
        org.junit.Assert.assertNotNull(sourceFile2);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        com.google.javascript.jscomp.AbstractCompiler abstractCompiler0 = null;
        com.google.javascript.jscomp.NodeTraversal.Callback callback1 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal2 = new com.google.javascript.jscomp.NodeTraversal(abstractCompiler0, callback1);
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        node7.removeProp((int) (short) 1);
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        com.google.javascript.rhino.JSDocInfo jSDocInfo15 = null;
        node14.setJSDocInfo(jSDocInfo15);
        java.lang.RuntimeException runtimeException18 = com.google.javascript.rhino.ScriptRuntime.undefReadError((java.lang.Object) node14, (java.lang.Object) 22);
        node14.detachChildren();
        int int20 = node14.getChildCount();
        node14.setType((-1));
        com.google.javascript.rhino.Node node27 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        node27.removeProp((int) (short) 1);
        com.google.javascript.rhino.Node node35 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        boolean boolean36 = node35.hasMoreThanOneChild();
        node35.setLineno(0);
        boolean boolean39 = node35.hasOneChild();
        com.google.javascript.rhino.jstype.JSType jSType40 = node35.getJSType();
        com.google.javascript.rhino.Node node45 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        node45.removeProp((int) (short) 1);
        com.google.javascript.rhino.Node[] nodeArray48 = new com.google.javascript.rhino.Node[] { node35, node45 };
        com.google.javascript.rhino.Node node51 = new com.google.javascript.rhino.Node((int) (byte) 10, nodeArray48, (int) '4', (int) (byte) -1);
        com.google.javascript.rhino.Node node52 = node27.copyInformationFromForTree(node51);
        boolean boolean53 = node27.hasChildren();
        com.google.javascript.rhino.Node[] nodeArray54 = new com.google.javascript.rhino.Node[] { node7, node14, node27 };
        try {
            nodeTraversal2.traverseRoots(nodeArray54);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNotNull(runtimeException18);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(node27);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNull(jSType40);
        org.junit.Assert.assertNotNull(node45);
        org.junit.Assert.assertNotNull(nodeArray48);
        org.junit.Assert.assertNotNull(node52);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNotNull(nodeArray54);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        boolean boolean1 = com.google.javascript.rhino.Context.isValidOptimizationLevel((int) (short) 10);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        int int0 = com.google.javascript.rhino.Context.VERSION_1_2;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 120 + "'", int0 == 120);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        java.lang.Object obj0 = null;
        java.lang.RuntimeException runtimeException1 = com.google.javascript.rhino.ScriptRuntime.notFunctionError(obj0);
        java.lang.Throwable[] throwableArray2 = runtimeException1.getSuppressed();
        org.junit.Assert.assertNotNull(runtimeException1);
        org.junit.Assert.assertNotNull(throwableArray2);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        try {
            com.google.javascript.rhino.Context.checkOptimizationLevel(37);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Optimization level outside [-1..9]: 37");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.TYPE_INVALIDATION;
        com.google.javascript.jscomp.DiagnosticGroups.NON_STANDARD_JSDOC = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticGroups.CONSTANT_PROPERTY = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticGroups.VISIBILITY = diagnosticGroup0;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        com.google.javascript.rhino.JSDocInfo jSDocInfo5 = null;
        node4.setJSDocInfo(jSDocInfo5);
        java.lang.RuntimeException runtimeException8 = com.google.javascript.rhino.ScriptRuntime.undefReadError((java.lang.Object) node4, (java.lang.Object) 22);
        node4.detachChildren();
        java.lang.String[] strArray15 = new java.lang.String[] { "error reporter", "hi!", "BITXOR", "error reporter", "BITXOR" };
        java.util.LinkedHashSet<java.lang.String> strSet16 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean17 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet16, strArray15);
        node4.setDirectives((java.util.Set<java.lang.String>) strSet16);
        try {
            int int20 = node4.getExistingIntProp(12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: FAILED ASSERTION");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(runtimeException8);
        org.junit.Assert.assertNotNull(strArray15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        node4.removeProp((int) (short) 1);
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        boolean boolean13 = node12.hasMoreThanOneChild();
        node12.setLineno(0);
        boolean boolean16 = node12.hasOneChild();
        com.google.javascript.rhino.jstype.JSType jSType17 = node12.getJSType();
        com.google.javascript.rhino.Node node22 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        node22.removeProp((int) (short) 1);
        com.google.javascript.rhino.Node[] nodeArray25 = new com.google.javascript.rhino.Node[] { node12, node22 };
        com.google.javascript.rhino.Node node28 = new com.google.javascript.rhino.Node((int) (byte) 10, nodeArray25, (int) '4', (int) (byte) -1);
        com.google.javascript.rhino.Node node29 = node4.copyInformationFromForTree(node28);
        com.google.javascript.rhino.Node node35 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        node35.removeProp((int) (short) 1);
        com.google.javascript.rhino.Node node43 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        boolean boolean44 = node43.hasMoreThanOneChild();
        node43.setLineno(0);
        boolean boolean47 = node43.hasOneChild();
        com.google.javascript.rhino.jstype.JSType jSType48 = node43.getJSType();
        com.google.javascript.rhino.Node node53 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        node53.removeProp((int) (short) 1);
        com.google.javascript.rhino.Node[] nodeArray56 = new com.google.javascript.rhino.Node[] { node43, node53 };
        com.google.javascript.rhino.Node node59 = new com.google.javascript.rhino.Node((int) (byte) 10, nodeArray56, (int) '4', (int) (byte) -1);
        com.google.javascript.rhino.Node node60 = node35.copyInformationFromForTree(node59);
        com.google.javascript.rhino.Node node65 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        node65.setSourcePositionForTree(20);
        com.google.javascript.rhino.Node node72 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        boolean boolean73 = node72.hasMoreThanOneChild();
        node72.setLineno(0);
        com.google.javascript.rhino.Node node76 = node72.cloneTree();
        com.google.javascript.rhino.Node node81 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        com.google.javascript.rhino.JSDocInfo jSDocInfo82 = null;
        node81.setJSDocInfo(jSDocInfo82);
        java.lang.RuntimeException runtimeException85 = com.google.javascript.rhino.ScriptRuntime.undefReadError((java.lang.Object) node81, (java.lang.Object) 22);
        node81.detachChildren();
        int int87 = node81.getChildCount();
        com.google.javascript.rhino.Node node90 = new com.google.javascript.rhino.Node((int) (short) -1, node60, node65, node76, node81, 15, (int) (byte) 1);
        try {
            node4.addChildrenToBack(node81);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNull(jSType17);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertNotNull(nodeArray25);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertNotNull(node43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNull(jSType48);
        org.junit.Assert.assertNotNull(node53);
        org.junit.Assert.assertNotNull(nodeArray56);
        org.junit.Assert.assertNotNull(node60);
        org.junit.Assert.assertNotNull(node65);
        org.junit.Assert.assertNotNull(node72);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
        org.junit.Assert.assertNotNull(node76);
        org.junit.Assert.assertNotNull(node81);
        org.junit.Assert.assertNotNull(runtimeException85);
        org.junit.Assert.assertTrue("'" + int87 + "' != '" + 0 + "'", int87 == 0);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        boolean boolean7 = node6.hasMoreThanOneChild();
        node6.setLineno(0);
        boolean boolean10 = node6.hasOneChild();
        com.google.javascript.rhino.jstype.JSType jSType11 = node6.getJSType();
        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        node16.removeProp((int) (short) 1);
        com.google.javascript.rhino.Node[] nodeArray19 = new com.google.javascript.rhino.Node[] { node6, node16 };
        com.google.javascript.rhino.Node node22 = new com.google.javascript.rhino.Node((int) (byte) 10, nodeArray19, (int) '4', (int) (byte) -1);
        try {
            com.google.javascript.rhino.Node node25 = new com.google.javascript.rhino.Node(5, nodeArray19, 160, (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: duplicate child");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNull(jSType11);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertNotNull(nodeArray19);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        com.google.javascript.rhino.JSDocInfo jSDocInfo5 = null;
        node4.setJSDocInfo(jSDocInfo5);
        node4.setType(100);
        com.google.javascript.rhino.Node node9 = null;
        try {
            com.google.javascript.rhino.Node node10 = node4.clonePropsFrom(node9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node4);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        int int0 = com.google.javascript.rhino.Node.LAST_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 49 + "'", int0 == 49);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        java.lang.String str1 = com.google.javascript.rhino.ScriptRuntime.escapeString("<unknown=160>");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "<unknown=160>" + "'", str1.equals("<unknown=160>"));
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        int int0 = com.google.javascript.rhino.jstype.JSType.NOT_ENUMDECL;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        int int0 = com.google.javascript.rhino.Node.PARENTHESIZED_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 34 + "'", int0 == 34);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        int int0 = com.google.javascript.rhino.Node.USES_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 11 + "'", int0 == 11);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        com.google.javascript.jscomp.CompilerOptions.TracerMode tracerMode0 = com.google.javascript.jscomp.CompilerOptions.TracerMode.OFF;
        org.junit.Assert.assertTrue("'" + tracerMode0 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TracerMode.OFF + "'", tracerMode0.equals(com.google.javascript.jscomp.CompilerOptions.TracerMode.OFF));
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile1 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.CompilerInput compilerInput2 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile1);
        boolean boolean3 = compilerInput2.isExtern();
        com.google.javascript.jscomp.SourceFile sourceFile4 = null;
        try {
            compilerInput2.setSourceFile(sourceFile4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        com.google.javascript.rhino.JSDocInfo jSDocInfo6 = null;
        node5.setJSDocInfo(jSDocInfo6);
        try {
            java.lang.String str8 = com.google.javascript.rhino.ScriptRuntime.getMessage1("language version", (java.lang.Object) node5);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property language version");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(node5);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        int int0 = com.google.javascript.rhino.Node.DIRECTCALL_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 26 + "'", int0 == 26);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        java.io.File file0 = null;
        try {
            com.google.javascript.jscomp.JSSourceFile jSSourceFile1 = com.google.javascript.jscomp.JSSourceFile.fromFile(file0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        com.google.javascript.rhino.JSDocInfo jSDocInfo6 = null;
        node5.setJSDocInfo(jSDocInfo6);
        java.lang.RuntimeException runtimeException9 = com.google.javascript.rhino.ScriptRuntime.undefReadError((java.lang.Object) node5, (java.lang.Object) 22);
        node5.detachChildren();
        com.google.javascript.rhino.Node node11 = new com.google.javascript.rhino.Node((int) (short) 100, node5);
        com.google.javascript.rhino.Node.SideEffectFlags sideEffectFlags12 = null;
        try {
            node5.setSideEffectFlags(sideEffectFlags12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNotNull(runtimeException9);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        int int0 = com.google.javascript.rhino.Node.LOCAL_BLOCK_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + (-3) + "'", int0 == (-3));
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        com.google.javascript.rhino.JSDocInfo jSDocInfo5 = null;
        node4.setJSDocInfo(jSDocInfo5);
        java.lang.RuntimeException runtimeException8 = com.google.javascript.rhino.ScriptRuntime.undefReadError((java.lang.Object) node4, (java.lang.Object) 22);
        node4.detachChildren();
        int int10 = node4.getChildCount();
        node4.setType((-1));
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        node17.removeProp((int) (short) 1);
        com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        boolean boolean26 = node25.hasMoreThanOneChild();
        node25.setLineno(0);
        boolean boolean29 = node25.hasOneChild();
        com.google.javascript.rhino.jstype.JSType jSType30 = node25.getJSType();
        com.google.javascript.rhino.Node node35 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        node35.removeProp((int) (short) 1);
        com.google.javascript.rhino.Node[] nodeArray38 = new com.google.javascript.rhino.Node[] { node25, node35 };
        com.google.javascript.rhino.Node node41 = new com.google.javascript.rhino.Node((int) (byte) 10, nodeArray38, (int) '4', (int) (byte) -1);
        com.google.javascript.rhino.Node node42 = node17.copyInformationFromForTree(node41);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder43 = node41.new FileLevelJsDocBuilder();
        java.lang.String str47 = node41.toString(false, false, false);
        com.google.javascript.rhino.Node node52 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        boolean boolean53 = node52.hasMoreThanOneChild();
        node52.setLineno(0);
        com.google.javascript.rhino.Node node56 = node52.cloneTree();
        com.google.javascript.rhino.Node node61 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        node61.removeProp((int) (short) 1);
        com.google.javascript.rhino.Node node69 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        boolean boolean70 = node69.hasMoreThanOneChild();
        node69.setLineno(0);
        boolean boolean73 = node69.hasOneChild();
        com.google.javascript.rhino.jstype.JSType jSType74 = node69.getJSType();
        com.google.javascript.rhino.Node node79 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        node79.removeProp((int) (short) 1);
        com.google.javascript.rhino.Node[] nodeArray82 = new com.google.javascript.rhino.Node[] { node69, node79 };
        com.google.javascript.rhino.Node node85 = new com.google.javascript.rhino.Node((int) (byte) 10, nodeArray82, (int) '4', (int) (byte) -1);
        com.google.javascript.rhino.Node node86 = node61.copyInformationFromForTree(node85);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder87 = node85.new FileLevelJsDocBuilder();
        java.lang.String str91 = node85.toString(false, false, false);
        node52.addChildrenToBack(node85);
        boolean boolean93 = node85.wasEmptyNode();
        try {
            node4.replaceChild(node41, node85);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The new child node already has a parent.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(runtimeException8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNull(jSType30);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertNotNull(nodeArray38);
        org.junit.Assert.assertNotNull(node42);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "BITXOR" + "'", str47.equals("BITXOR"));
        org.junit.Assert.assertNotNull(node52);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNotNull(node56);
        org.junit.Assert.assertNotNull(node61);
        org.junit.Assert.assertNotNull(node69);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
        org.junit.Assert.assertNull(jSType74);
        org.junit.Assert.assertNotNull(node79);
        org.junit.Assert.assertNotNull(nodeArray82);
        org.junit.Assert.assertNotNull(node86);
        org.junit.Assert.assertTrue("'" + str91 + "' != '" + "BITXOR" + "'", str91.equals("BITXOR"));
        org.junit.Assert.assertTrue("'" + boolean93 + "' != '" + false + "'", boolean93 == false);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        int int0 = com.google.javascript.rhino.Node.IS_NAMESPACE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 45 + "'", int0 == 45);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        int int0 = com.google.javascript.rhino.Node.VAR_ARGS_NAME;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 29 + "'", int0 == 29);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        int int0 = com.google.javascript.rhino.Node.FUNCTION_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 5 + "'", int0 == 5);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        node4.removeProp((int) (short) 1);
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        boolean boolean13 = node12.hasMoreThanOneChild();
        node12.setLineno(0);
        boolean boolean16 = node12.hasOneChild();
        com.google.javascript.rhino.jstype.JSType jSType17 = node12.getJSType();
        com.google.javascript.rhino.Node node22 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        node22.removeProp((int) (short) 1);
        com.google.javascript.rhino.Node[] nodeArray25 = new com.google.javascript.rhino.Node[] { node12, node22 };
        com.google.javascript.rhino.Node node28 = new com.google.javascript.rhino.Node((int) (byte) 10, nodeArray25, (int) '4', (int) (byte) -1);
        com.google.javascript.rhino.Node node29 = node4.copyInformationFromForTree(node28);
        boolean boolean30 = node4.hasChildren();
        com.google.javascript.rhino.Node node31 = node4.removeFirstChild();
        try {
            node4.setDouble((double) 32);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: EOL  is not a string node");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNull(jSType17);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertNotNull(nodeArray25);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNull(node31);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.FILEOVERVIEW_JSDOC;
        com.google.javascript.jscomp.DiagnosticGroups.INVALID_CASTS = diagnosticGroup0;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        node4.removeProp((int) (short) 1);
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        boolean boolean13 = node12.hasMoreThanOneChild();
        node12.setLineno(0);
        boolean boolean16 = node12.hasOneChild();
        com.google.javascript.rhino.jstype.JSType jSType17 = node12.getJSType();
        com.google.javascript.rhino.Node node22 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        node22.removeProp((int) (short) 1);
        com.google.javascript.rhino.Node[] nodeArray25 = new com.google.javascript.rhino.Node[] { node12, node22 };
        com.google.javascript.rhino.Node node28 = new com.google.javascript.rhino.Node((int) (byte) 10, nodeArray25, (int) '4', (int) (byte) -1);
        com.google.javascript.rhino.Node node29 = node4.copyInformationFromForTree(node28);
        boolean boolean30 = node4.hasChildren();
        try {
            com.google.javascript.rhino.Node node31 = node4.detachFromParent();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNull(jSType17);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertNotNull(nodeArray25);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = null;
        com.google.javascript.jscomp.CompilerOptions compilerOptions1 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions1.devirtualizePrototypeMethods = false;
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy4 = com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC;
        compilerOptions1.propertyRenaming = propertyRenamingPolicy4;
        boolean boolean6 = compilerOptions1.recordFunctionInformation;
        compilerOptions1.optimizeArgumentsArray = false;
        com.google.javascript.jscomp.DiagnosticType diagnosticType9 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        com.google.javascript.jscomp.CheckLevel checkLevel10 = diagnosticType9.defaultLevel;
        compilerOptions1.checkMethods = checkLevel10;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard12 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup0, checkLevel10);
        com.google.javascript.jscomp.DiagnosticType diagnosticType16 = com.google.javascript.jscomp.Compiler.MOTION_ITERATIONS_ERROR;
        java.lang.String[] strArray23 = new java.lang.String[] { "<unknown=160>", "<unknown=160>", "<unknown=160>", "<unknown=160>", "BITXOR", "DiagnosticGroup<undefinedVars>" };
        com.google.javascript.jscomp.JSError jSError24 = com.google.javascript.jscomp.JSError.make("BITXOR", 32, (int) (short) 100, diagnosticType16, strArray23);
        try {
            com.google.javascript.jscomp.CheckLevel checkLevel25 = diagnosticGroupWarningsGuard12.level(jSError24);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy4 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC + "'", propertyRenamingPolicy4.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(diagnosticType9);
        org.junit.Assert.assertTrue("'" + checkLevel10 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel10.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticType16);
        org.junit.Assert.assertNotNull(strArray23);
        org.junit.Assert.assertNotNull(jSError24);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        com.google.javascript.jscomp.mozilla.rhino.ast.AstRoot astRoot0 = null;
        com.google.javascript.jscomp.parsing.Config config2 = null;
        com.google.javascript.jscomp.mozilla.rhino.ErrorReporter errorReporter3 = null;
        try {
            com.google.javascript.rhino.Node node4 = com.google.javascript.jscomp.parsing.IRFactory.transformTree(astRoot0, "BITXOR", config2, errorReporter3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        node4.removeProp((int) (short) 1);
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        boolean boolean13 = node12.hasMoreThanOneChild();
        node12.setLineno(0);
        boolean boolean16 = node12.hasOneChild();
        com.google.javascript.rhino.jstype.JSType jSType17 = node12.getJSType();
        com.google.javascript.rhino.Node node22 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        node22.removeProp((int) (short) 1);
        com.google.javascript.rhino.Node[] nodeArray25 = new com.google.javascript.rhino.Node[] { node12, node22 };
        com.google.javascript.rhino.Node node28 = new com.google.javascript.rhino.Node((int) (byte) 10, nodeArray25, (int) '4', (int) (byte) -1);
        com.google.javascript.rhino.Node node29 = node4.copyInformationFromForTree(node28);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder30 = node28.new FileLevelJsDocBuilder();
        java.lang.String str34 = node28.toString(false, false, false);
        boolean boolean35 = node28.isUnscopedQualifiedName();
        node28.setVarArgs(false);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNull(jSType17);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertNotNull(nodeArray25);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "BITXOR" + "'", str34.equals("BITXOR"));
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CodingConvention codingConvention1 = compilerOptions0.getCodingConvention();
        com.google.javascript.jscomp.CompilerOptions.AliasTransformationHandler aliasTransformationHandler2 = compilerOptions0.getAliasTransformationHandler();
        com.google.javascript.rhino.SourcePosition<com.google.javascript.jscomp.CompilerOptions.AliasTransformation> aliasTransformationSourcePosition4 = null;
        try {
            com.google.javascript.jscomp.CompilerOptions.AliasTransformation aliasTransformation5 = aliasTransformationHandler2.logAliasTransformation("<unknown=160>", aliasTransformationSourcePosition4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(codingConvention1);
        org.junit.Assert.assertNotNull(aliasTransformationHandler2);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.jstype.FunctionType functionType1 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType2 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType3 = null;
        closureCodingConvention0.applySubclassRelationship(functionType1, functionType2, subclassType3);
        com.google.javascript.rhino.jstype.ObjectType objectType5 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType6 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType7 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType8 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType9 = null;
        closureCodingConvention0.applyDelegateRelationship(objectType5, objectType6, objectType7, functionType8, functionType9);
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        com.google.javascript.rhino.JSDocInfo jSDocInfo16 = null;
        node15.setJSDocInfo(jSDocInfo16);
        java.lang.RuntimeException runtimeException19 = com.google.javascript.rhino.ScriptRuntime.undefReadError((java.lang.Object) node15, (java.lang.Object) 22);
        try {
            com.google.javascript.jscomp.CodingConvention.SubclassRelationship subclassRelationship20 = closureCodingConvention0.getClassesDefinedByCall(node15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertNotNull(runtimeException19);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        com.google.javascript.jscomp.SourceExcerptProvider sourceExcerptProvider0 = null;
        com.google.javascript.jscomp.SourceExcerptProvider.SourceExcerpt sourceExcerpt1 = null;
        try {
            com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter2 = new com.google.javascript.jscomp.LightweightMessageFormatter(sourceExcerptProvider0, sourceExcerpt1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        try {
            com.google.javascript.rhino.EcmaError ecmaError2 = com.google.javascript.rhino.ScriptRuntime.typeError1("goog.global", "DiagnosticGroup<undefinedVars>");
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property goog.global");
        } catch (java.lang.RuntimeException e) {
        }
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.devirtualizePrototypeMethods = false;
        compilerOptions0.groupVariableDeclarations = false;
        java.util.Set<java.lang.String> strSet5 = compilerOptions0.stripNamePrefixes;
        java.lang.String str6 = compilerOptions0.syntheticBlockEndMarker;
        boolean boolean7 = compilerOptions0.optimizeReturns;
        org.junit.Assert.assertNotNull(strSet5);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        int int0 = com.google.javascript.rhino.Node.RIGHT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        java.lang.String str2 = com.google.javascript.rhino.ScriptRuntime.numberToString(0.0d, 5);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0" + "'", str2.equals("0"));
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.devirtualizePrototypeMethods = false;
        compilerOptions0.groupVariableDeclarations = false;
        java.util.Set<java.lang.String> strSet5 = compilerOptions0.stripNamePrefixes;
        java.lang.String str6 = compilerOptions0.syntheticBlockEndMarker;
        boolean boolean7 = compilerOptions0.inlineFunctions;
        java.lang.String str8 = compilerOptions0.renamePrefix;
        org.junit.Assert.assertNotNull(strSet5);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(str8);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.devirtualizePrototypeMethods = false;
        compilerOptions0.groupVariableDeclarations = false;
        boolean boolean5 = compilerOptions0.crossModuleCodeMotion;
        com.google.javascript.jscomp.CheckLevel checkLevel6 = null;
        compilerOptions0.checkProvides = checkLevel6;
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        int int0 = com.google.javascript.rhino.Context.VERSION_1_3;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 130 + "'", int0 == 130);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CodingConvention codingConvention1 = compilerOptions0.getCodingConvention();
        compilerOptions0.computeFunctionSideEffects = true;
        java.util.Set<java.lang.String> strSet4 = null;
        compilerOptions0.stripNameSuffixes = strSet4;
        org.junit.Assert.assertNull(codingConvention1);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        try {
            com.google.javascript.rhino.EcmaError ecmaError2 = com.google.javascript.rhino.ScriptRuntime.typeError1("<unknown=160>", "DiagnosticGroup<undefinedVars>");
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property <unknown=160>");
        } catch (java.lang.RuntimeException e) {
        }
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        int int0 = com.google.javascript.rhino.Node.LABEL_ID_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        com.google.javascript.rhino.Context context0 = new com.google.javascript.rhino.Context();
        com.google.javascript.jscomp.AnonymousFunctionNamingPolicy anonymousFunctionNamingPolicy1 = com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.UNMAPPED;
        context0.removeThreadLocal((java.lang.Object) anonymousFunctionNamingPolicy1);
        boolean boolean3 = context0.isGeneratingDebug();
        long long4 = com.google.javascript.rhino.ScriptRuntime.lastUint32Result(context0);
        com.google.javascript.rhino.Context context5 = com.google.javascript.rhino.Context.enter(context0);
        boolean boolean6 = context5.isGeneratingSource();
        try {
            context5.setLanguageVersion(31);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Bad language version: 31");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + anonymousFunctionNamingPolicy1 + "' != '" + com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.UNMAPPED + "'", anonymousFunctionNamingPolicy1.equals(com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.UNMAPPED));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
        org.junit.Assert.assertNotNull(context5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        java.lang.String str0 = com.google.javascript.rhino.jstype.JSType.NOT_A_CLASS;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "Not declared as a constructor" + "'", str0.equals("Not declared as a constructor"));
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.devirtualizePrototypeMethods = false;
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy3 = com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC;
        compilerOptions0.propertyRenaming = propertyRenamingPolicy3;
        boolean boolean5 = compilerOptions0.recordFunctionInformation;
        compilerOptions0.enableExternExports(false);
        com.google.javascript.jscomp.CheckLevel checkLevel8 = compilerOptions0.checkUnreachableCode;
        compilerOptions0.setOutputCharset("0");
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy3 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC + "'", propertyRenamingPolicy3.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + checkLevel8 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel8.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CodingConvention codingConvention1 = compilerOptions0.getCodingConvention();
        com.google.javascript.jscomp.CompilerOptions.AliasTransformationHandler aliasTransformationHandler2 = compilerOptions0.getAliasTransformationHandler();
        compilerOptions0.extractPrototypeMemberDeclarations = false;
        boolean boolean5 = compilerOptions0.optimizeReturns;
        org.junit.Assert.assertNull(codingConvention1);
        org.junit.Assert.assertNotNull(aliasTransformationHandler2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        java.io.InputStream inputStream1 = null;
        try {
            com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromInputStream("BITXOR", inputStream1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeUnusedLocalVars = false;
        compilerOptions0.crossModuleCodeMotion = false;
        compilerOptions0.ambiguateProperties = false;
        compilerOptions0.foldConstants = false;
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        com.google.javascript.jscomp.SourceMap.Format format0 = com.google.javascript.jscomp.SourceMap.Format.DEFAULT;
        org.junit.Assert.assertNotNull(format0);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        node5.removeProp((int) (short) 1);
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        boolean boolean14 = node13.hasMoreThanOneChild();
        node13.setLineno(0);
        boolean boolean17 = node13.hasOneChild();
        com.google.javascript.rhino.jstype.JSType jSType18 = node13.getJSType();
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        node23.removeProp((int) (short) 1);
        com.google.javascript.rhino.Node[] nodeArray26 = new com.google.javascript.rhino.Node[] { node13, node23 };
        com.google.javascript.rhino.Node node29 = new com.google.javascript.rhino.Node((int) (byte) 10, nodeArray26, (int) '4', (int) (byte) -1);
        com.google.javascript.rhino.Node node30 = node5.copyInformationFromForTree(node29);
        com.google.javascript.rhino.Node node35 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        node35.setSourcePositionForTree(20);
        com.google.javascript.rhino.Node node42 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        boolean boolean43 = node42.hasMoreThanOneChild();
        node42.setLineno(0);
        com.google.javascript.rhino.Node node46 = node42.cloneTree();
        com.google.javascript.rhino.Node node51 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        com.google.javascript.rhino.JSDocInfo jSDocInfo52 = null;
        node51.setJSDocInfo(jSDocInfo52);
        java.lang.RuntimeException runtimeException55 = com.google.javascript.rhino.ScriptRuntime.undefReadError((java.lang.Object) node51, (java.lang.Object) 22);
        node51.detachChildren();
        int int57 = node51.getChildCount();
        com.google.javascript.rhino.Node node60 = new com.google.javascript.rhino.Node((int) (short) -1, node30, node35, node46, node51, 15, (int) (byte) 1);
        com.google.javascript.rhino.Node node61 = node35.getNext();
        com.google.javascript.rhino.Node node65 = com.google.javascript.rhino.Node.newString("", 9, (int) '#');
        com.google.javascript.rhino.Node node68 = com.google.javascript.rhino.Node.newString(0, "");
        try {
            node61.replaceChildAfter(node65, node68);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: prev is not a child of this node.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNull(jSType18);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(nodeArray26);
        org.junit.Assert.assertNotNull(node30);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertNotNull(node42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(node46);
        org.junit.Assert.assertNotNull(node51);
        org.junit.Assert.assertNotNull(runtimeException55);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 0 + "'", int57 == 0);
        org.junit.Assert.assertNotNull(node61);
        org.junit.Assert.assertNotNull(node65);
        org.junit.Assert.assertNotNull(node68);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.NON_STANDARD_JSDOC;
        com.google.javascript.jscomp.DiagnosticGroups.MISSING_PROPERTIES = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticGroups.INTERNET_EXPLORER_CHECKS = diagnosticGroup0;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        com.google.javascript.jscomp.AnonymousFunctionNamingPolicy anonymousFunctionNamingPolicy0 = com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.MAPPED;
        org.junit.Assert.assertTrue("'" + anonymousFunctionNamingPolicy0 + "' != '" + com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.MAPPED + "'", anonymousFunctionNamingPolicy0.equals(com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.MAPPED));
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.devirtualizePrototypeMethods = false;
        compilerOptions0.groupVariableDeclarations = false;
        boolean boolean5 = compilerOptions0.ideMode;
        compilerOptions0.setProcessObjectPropertyString(true);
        com.google.javascript.jscomp.CompilerOptions.AliasTransformationHandler aliasTransformationHandler8 = compilerOptions0.getAliasTransformationHandler();
        com.google.javascript.rhino.SourcePosition<com.google.javascript.jscomp.CompilerOptions.AliasTransformation> aliasTransformationSourcePosition10 = null;
        try {
            com.google.javascript.jscomp.CompilerOptions.AliasTransformation aliasTransformation11 = aliasTransformationHandler8.logAliasTransformation("", aliasTransformationSourcePosition10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(aliasTransformationHandler8);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        int int0 = com.google.javascript.rhino.Node.ISNUMBER_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 25 + "'", int0 == 25);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.devirtualizePrototypeMethods = false;
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy3 = com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC;
        compilerOptions0.propertyRenaming = propertyRenamingPolicy3;
        boolean boolean5 = compilerOptions0.recordFunctionInformation;
        compilerOptions0.enableExternExports(false);
        boolean boolean8 = compilerOptions0.removeUnusedLocalVars;
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy3 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC + "'", propertyRenamingPolicy3.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        com.google.javascript.rhino.JSDocInfo jSDocInfo6 = null;
        node5.setJSDocInfo(jSDocInfo6);
        java.lang.RuntimeException runtimeException9 = com.google.javascript.rhino.ScriptRuntime.undefReadError((java.lang.Object) node5, (java.lang.Object) 22);
        node5.detachChildren();
        com.google.javascript.rhino.Node node11 = new com.google.javascript.rhino.Node((int) (short) 100, node5);
        boolean boolean13 = node5.getBooleanProp(6);
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        com.google.javascript.rhino.JSDocInfo jSDocInfo20 = null;
        node19.setJSDocInfo(jSDocInfo20);
        java.lang.RuntimeException runtimeException23 = com.google.javascript.rhino.ScriptRuntime.undefReadError((java.lang.Object) node19, (java.lang.Object) 22);
        node19.detachChildren();
        com.google.javascript.rhino.Node node25 = new com.google.javascript.rhino.Node((int) (short) 100, node19);
        boolean boolean27 = node19.getBooleanProp(6);
        com.google.javascript.rhino.Node node32 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        node32.removeProp((int) (short) 1);
        com.google.javascript.rhino.Node node40 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        boolean boolean41 = node40.hasMoreThanOneChild();
        node40.setLineno(0);
        boolean boolean44 = node40.hasOneChild();
        com.google.javascript.rhino.jstype.JSType jSType45 = node40.getJSType();
        com.google.javascript.rhino.Node node50 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        node50.removeProp((int) (short) 1);
        com.google.javascript.rhino.Node[] nodeArray53 = new com.google.javascript.rhino.Node[] { node40, node50 };
        com.google.javascript.rhino.Node node56 = new com.google.javascript.rhino.Node((int) (byte) 10, nodeArray53, (int) '4', (int) (byte) -1);
        com.google.javascript.rhino.Node node57 = node32.copyInformationFromForTree(node56);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder58 = node56.new FileLevelJsDocBuilder();
        java.lang.String str62 = node56.toString(false, false, false);
        boolean boolean63 = node56.isUnscopedQualifiedName();
        try {
            node5.replaceChild(node19, node56);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNotNull(runtimeException9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNotNull(runtimeException23);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(node32);
        org.junit.Assert.assertNotNull(node40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNull(jSType45);
        org.junit.Assert.assertNotNull(node50);
        org.junit.Assert.assertNotNull(nodeArray53);
        org.junit.Assert.assertNotNull(node57);
        org.junit.Assert.assertTrue("'" + str62 + "' != '" + "BITXOR" + "'", str62.equals("BITXOR"));
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeUnusedLocalVars = false;
        compilerOptions0.crossModuleCodeMotion = false;
        boolean boolean5 = compilerOptions0.optimizeParameters;
        boolean boolean6 = compilerOptions0.recordFunctionInformation;
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

//    @Test
//    public void test130() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test130");
//        com.google.javascript.rhino.Context context0 = com.google.javascript.rhino.Context.getCurrentContext();
//        org.junit.Assert.assertNull(context0);
//    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.jstype.FunctionType functionType1 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType2 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType3 = null;
        closureCodingConvention0.applySubclassRelationship(functionType1, functionType2, subclassType3);
        com.google.javascript.rhino.jstype.FunctionType functionType5 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType6 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType7 = null;
        closureCodingConvention0.applySubclassRelationship(functionType5, functionType6, subclassType7);
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        node13.removeProp((int) (short) 1);
        com.google.javascript.rhino.Node node21 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        boolean boolean22 = node21.hasMoreThanOneChild();
        node21.setLineno(0);
        boolean boolean25 = node21.hasOneChild();
        com.google.javascript.rhino.jstype.JSType jSType26 = node21.getJSType();
        com.google.javascript.rhino.Node node31 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        node31.removeProp((int) (short) 1);
        com.google.javascript.rhino.Node[] nodeArray34 = new com.google.javascript.rhino.Node[] { node21, node31 };
        com.google.javascript.rhino.Node node37 = new com.google.javascript.rhino.Node((int) (byte) 10, nodeArray34, (int) '4', (int) (byte) -1);
        com.google.javascript.rhino.Node node38 = node13.copyInformationFromForTree(node37);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder39 = node37.new FileLevelJsDocBuilder();
        java.lang.String str43 = node37.toString(false, false, false);
        com.google.javascript.jscomp.CodingConvention.SubclassRelationship subclassRelationship44 = closureCodingConvention0.getClassesDefinedByCall(node37);
        com.google.javascript.rhino.Node node49 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        com.google.javascript.rhino.JSDocInfo jSDocInfo50 = null;
        node49.setJSDocInfo(jSDocInfo50);
        java.lang.RuntimeException runtimeException53 = com.google.javascript.rhino.ScriptRuntime.undefReadError((java.lang.Object) node49, (java.lang.Object) 22);
        node49.detachChildren();
        int int55 = node49.getChildCount();
        try {
            com.google.javascript.jscomp.CodingConvention.SubclassRelationship subclassRelationship56 = closureCodingConvention0.getClassesDefinedByCall(node49);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNull(jSType26);
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertNotNull(nodeArray34);
        org.junit.Assert.assertNotNull(node38);
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "BITXOR" + "'", str43.equals("BITXOR"));
        org.junit.Assert.assertNull(subclassRelationship44);
        org.junit.Assert.assertNotNull(node49);
        org.junit.Assert.assertNotNull(runtimeException53);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 0 + "'", int55 == 0);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        node4.removeProp((int) (short) 1);
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        boolean boolean13 = node12.hasMoreThanOneChild();
        node12.setLineno(0);
        boolean boolean16 = node12.hasOneChild();
        com.google.javascript.rhino.jstype.JSType jSType17 = node12.getJSType();
        com.google.javascript.rhino.Node node22 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        node22.removeProp((int) (short) 1);
        com.google.javascript.rhino.Node[] nodeArray25 = new com.google.javascript.rhino.Node[] { node12, node22 };
        com.google.javascript.rhino.Node node28 = new com.google.javascript.rhino.Node((int) (byte) 10, nodeArray25, (int) '4', (int) (byte) -1);
        com.google.javascript.rhino.Node node29 = node4.copyInformationFromForTree(node28);
        java.lang.String str30 = node29.getQualifiedName();
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNull(jSType17);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertNotNull(nodeArray25);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNull(str30);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup1 = com.google.javascript.jscomp.DiagnosticGroups.TYPE_INVALIDATION;
        com.google.javascript.jscomp.DiagnosticGroups.NON_STANDARD_JSDOC = diagnosticGroup1;
        com.google.javascript.jscomp.DiagnosticGroups.CONSTANT_PROPERTY = diagnosticGroup1;
        com.google.javascript.jscomp.CompilerOptions compilerOptions4 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CodingConvention codingConvention5 = compilerOptions4.getCodingConvention();
        compilerOptions4.computeFunctionSideEffects = true;
        com.google.javascript.jscomp.CheckLevel checkLevel8 = compilerOptions4.checkRequires;
        try {
            java.lang.String str9 = com.google.javascript.rhino.ScriptRuntime.getMessage2("@IMPLEMENTATION.VERSION@", (java.lang.Object) diagnosticGroup1, (java.lang.Object) compilerOptions4);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property @IMPLEMENTATION.VERSION@");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(diagnosticGroup1);
        org.junit.Assert.assertNull(codingConvention5);
        org.junit.Assert.assertTrue("'" + checkLevel8 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel8.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        com.google.javascript.rhino.Context context0 = new com.google.javascript.rhino.Context();
        com.google.javascript.jscomp.AnonymousFunctionNamingPolicy anonymousFunctionNamingPolicy1 = com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.UNMAPPED;
        context0.removeThreadLocal((java.lang.Object) anonymousFunctionNamingPolicy1);
        boolean boolean3 = context0.isGeneratingDebug();
        long long4 = com.google.javascript.rhino.ScriptRuntime.lastUint32Result(context0);
        com.google.javascript.rhino.Context context5 = com.google.javascript.rhino.Context.enter(context0);
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        try {
            context5.removePropertyChangeListener(propertyChangeListener6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + anonymousFunctionNamingPolicy1 + "' != '" + com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.UNMAPPED + "'", anonymousFunctionNamingPolicy1.equals(com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.UNMAPPED));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
        org.junit.Assert.assertNotNull(context5);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        com.google.javascript.jscomp.ErrorFormat errorFormat0 = com.google.javascript.jscomp.ErrorFormat.SOURCELESS;
        com.google.javascript.jscomp.SourceExcerptProvider sourceExcerptProvider1 = null;
        com.google.javascript.jscomp.MessageFormatter messageFormatter3 = errorFormat0.toFormatter(sourceExcerptProvider1, true);
        org.junit.Assert.assertNotNull(errorFormat0);
        org.junit.Assert.assertNotNull(messageFormatter3);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        long long1 = com.google.javascript.rhino.ScriptRuntime.testUint32String("hi!");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1L) + "'", long1 == (-1L));
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        java.lang.String str1 = com.google.javascript.rhino.jstype.ObjectType.createDelegateSuffix("goog.exportSymbol");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "(goog.exportSymbol)" + "'", str1.equals("(goog.exportSymbol)"));
    }

//    @Test
//    public void test138() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test138");
//        try {
//            com.google.javascript.rhino.Context.exit();
//            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Calling Context.exit without previous Context.enter");
//        } catch (java.lang.RuntimeException e) {
//        }
//    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        int int0 = com.google.javascript.rhino.Node.CASES_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 13 + "'", int0 == 13);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = null;
        com.google.javascript.jscomp.CompilerOptions compilerOptions1 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions1.devirtualizePrototypeMethods = false;
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy4 = com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC;
        compilerOptions1.propertyRenaming = propertyRenamingPolicy4;
        boolean boolean6 = compilerOptions1.recordFunctionInformation;
        compilerOptions1.optimizeArgumentsArray = false;
        com.google.javascript.jscomp.DiagnosticType diagnosticType9 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        com.google.javascript.jscomp.CheckLevel checkLevel10 = diagnosticType9.defaultLevel;
        compilerOptions1.checkMethods = checkLevel10;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard12 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup0, checkLevel10);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup13 = com.google.javascript.jscomp.DiagnosticGroups.UNDEFINED_VARIABLES;
        com.google.javascript.jscomp.DiagnosticGroups.UNDEFINED_VARIABLES = diagnosticGroup13;
        try {
            boolean boolean15 = diagnosticGroupWarningsGuard12.enables(diagnosticGroup13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy4 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC + "'", propertyRenamingPolicy4.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(diagnosticType9);
        org.junit.Assert.assertTrue("'" + checkLevel10 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel10.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticGroup13);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        boolean boolean1 = com.google.javascript.rhino.Context.isValidOptimizationLevel((int) (byte) 1);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        com.google.javascript.jscomp.parsing.Config config2 = null;
        com.google.javascript.jscomp.mozilla.rhino.ErrorReporter errorReporter3 = null;
        java.util.logging.Logger logger4 = null;
        try {
            com.google.javascript.rhino.Node node5 = com.google.javascript.jscomp.parsing.ParserRunner.parse("goog.exportProperty", "", config2, errorReporter3, logger4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        java.lang.String str0 = com.google.javascript.rhino.jstype.JSType.NOT_A_TYPE;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "Not declared as a type name" + "'", str0.equals("Not declared as a type name"));
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile1 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.CompilerInput compilerInput2 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile1);
        com.google.javascript.jscomp.Region region4 = compilerInput2.getRegion(10);
        com.google.javascript.jscomp.AbstractCompiler abstractCompiler5 = null;
        try {
            compilerInput2.setCompiler(abstractCompiler5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile1);
        org.junit.Assert.assertNull(region4);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        int int0 = com.google.javascript.rhino.Node.LABEL_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 19 + "'", int0 == 19);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.devirtualizePrototypeMethods = false;
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy3 = com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC;
        compilerOptions0.propertyRenaming = propertyRenamingPolicy3;
        boolean boolean5 = compilerOptions0.recordFunctionInformation;
        compilerOptions0.enableExternExports(false);
        byte[] byteArray11 = new byte[] { (byte) -1, (byte) 1, (byte) 10 };
        compilerOptions0.inputVariableMapSerialized = byteArray11;
        compilerOptions0.foldConstants = false;
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy3 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC + "'", propertyRenamingPolicy3.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(byteArray11);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeDeadCode = false;
        boolean boolean3 = compilerOptions0.devirtualizePrototypeMethods;
        compilerOptions0.setDefineToNumberLiteral("@IMPLEMENTATION.VERSION@", 0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        int int0 = com.google.javascript.rhino.Node.VARS_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        java.io.Reader reader1 = null;
        try {
            com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromReader("Not declared as a constructor", reader1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.EXTERNS_VALIDATION;
        com.google.javascript.jscomp.DiagnosticGroups.UNKNOWN_DEFINES = diagnosticGroup0;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile1 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        java.lang.String str2 = jSSourceFile1.getOriginalPath();
        try {
            java.lang.String str3 = jSSourceFile1.getCode();
            org.junit.Assert.fail("Expected exception of type java.io.FileNotFoundException; message:  (No such file or directory)");
        } catch (java.io.FileNotFoundException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        java.io.InputStream inputStream1 = null;
        try {
            com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromInputStream("Not declared as a type name", inputStream1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        int int0 = com.google.javascript.rhino.Context.FEATURE_NON_ECMA_GET_YEAR;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        int int0 = com.google.javascript.rhino.Node.LEFT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        node5.removeProp((int) (short) 1);
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        boolean boolean14 = node13.hasMoreThanOneChild();
        node13.setLineno(0);
        boolean boolean17 = node13.hasOneChild();
        com.google.javascript.rhino.jstype.JSType jSType18 = node13.getJSType();
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        node23.removeProp((int) (short) 1);
        com.google.javascript.rhino.Node[] nodeArray26 = new com.google.javascript.rhino.Node[] { node13, node23 };
        com.google.javascript.rhino.Node node29 = new com.google.javascript.rhino.Node((int) (byte) 10, nodeArray26, (int) '4', (int) (byte) -1);
        com.google.javascript.rhino.Node node30 = node5.copyInformationFromForTree(node29);
        com.google.javascript.rhino.Node node35 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        node35.setSourcePositionForTree(20);
        com.google.javascript.rhino.Node node42 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        boolean boolean43 = node42.hasMoreThanOneChild();
        node42.setLineno(0);
        com.google.javascript.rhino.Node node46 = node42.cloneTree();
        com.google.javascript.rhino.Node node51 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        com.google.javascript.rhino.JSDocInfo jSDocInfo52 = null;
        node51.setJSDocInfo(jSDocInfo52);
        java.lang.RuntimeException runtimeException55 = com.google.javascript.rhino.ScriptRuntime.undefReadError((java.lang.Object) node51, (java.lang.Object) 22);
        node51.detachChildren();
        int int57 = node51.getChildCount();
        com.google.javascript.rhino.Node node60 = new com.google.javascript.rhino.Node((int) (short) -1, node30, node35, node46, node51, 15, (int) (byte) 1);
        com.google.javascript.rhino.Node node61 = null;
        try {
            node46.addChildrenToBack(node61);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNull(jSType18);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(nodeArray26);
        org.junit.Assert.assertNotNull(node30);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertNotNull(node42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(node46);
        org.junit.Assert.assertNotNull(node51);
        org.junit.Assert.assertNotNull(runtimeException55);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 0 + "'", int57 == 0);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CodingConvention codingConvention1 = compilerOptions0.getCodingConvention();
        boolean boolean2 = compilerOptions0.inlineLocalVariables;
        compilerOptions0.coalesceVariableNames = true;
        boolean boolean5 = compilerOptions0.removeEmptyFunctions;
        boolean boolean6 = compilerOptions0.generatePseudoNames;
        org.junit.Assert.assertNull(codingConvention1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        try {
            com.google.javascript.rhino.EcmaError ecmaError2 = com.google.javascript.rhino.ScriptRuntime.typeError1("goog.exportSymbol", "");
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property goog.exportSymbol");
        } catch (java.lang.RuntimeException e) {
        }
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.devirtualizePrototypeMethods = false;
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy3 = com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC;
        compilerOptions0.propertyRenaming = propertyRenamingPolicy3;
        compilerOptions0.disableRuntimeTypeCheck();
        compilerOptions0.checkSuspiciousCode = false;
        boolean boolean8 = compilerOptions0.gatherCssNames;
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy3 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC + "'", propertyRenamingPolicy3.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CodingConvention codingConvention1 = compilerOptions0.getCodingConvention();
        com.google.javascript.jscomp.CompilerOptions.AliasTransformationHandler aliasTransformationHandler2 = compilerOptions0.getAliasTransformationHandler();
        compilerOptions0.setTweakToBooleanLiteral("<unknown=160>", false);
        com.google.javascript.jscomp.CompilerOptions compilerOptions6 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions6.removeUnusedLocalVars = false;
        compilerOptions6.crossModuleCodeMotion = false;
        compilerOptions6.ambiguateProperties = false;
        compilerOptions6.checkTypedPropertyCalls = true;
        java.lang.String str15 = compilerOptions6.syntheticBlockEndMarker;
        java.util.Set<java.lang.String> strSet16 = compilerOptions6.stripTypes;
        compilerOptions0.setIdGenerators(strSet16);
        compilerOptions0.aliasableGlobals = "BITXOR";
        org.junit.Assert.assertNull(codingConvention1);
        org.junit.Assert.assertNotNull(aliasTransformationHandler2);
        org.junit.Assert.assertNull(str15);
        org.junit.Assert.assertNotNull(strSet16);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        int int0 = com.google.javascript.rhino.Node.SIDE_EFFECT_FLAGS;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 41 + "'", int0 == 41);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        com.google.javascript.rhino.Context context0 = null;
        try {
            com.google.javascript.rhino.ScriptRuntime.storeUint32Result(context0, (long) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        java.lang.String str1 = com.google.javascript.rhino.ScriptRuntime.toString((java.lang.Object) "DiagnosticGroup<undefinedVars>");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "DiagnosticGroup<undefinedVars>" + "'", str1.equals("DiagnosticGroup<undefinedVars>"));
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        try {
            com.google.javascript.jscomp.JSError[] jSErrorArray2 = compiler1.getMessages();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        node5.removeProp((int) (short) 1);
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        boolean boolean14 = node13.hasMoreThanOneChild();
        node13.setLineno(0);
        boolean boolean17 = node13.hasOneChild();
        com.google.javascript.rhino.jstype.JSType jSType18 = node13.getJSType();
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        node23.removeProp((int) (short) 1);
        com.google.javascript.rhino.Node[] nodeArray26 = new com.google.javascript.rhino.Node[] { node13, node23 };
        com.google.javascript.rhino.Node node29 = new com.google.javascript.rhino.Node((int) (byte) 10, nodeArray26, (int) '4', (int) (byte) -1);
        com.google.javascript.rhino.Node node30 = node5.copyInformationFromForTree(node29);
        com.google.javascript.rhino.Node node35 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        node35.setSourcePositionForTree(20);
        com.google.javascript.rhino.Node node42 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        boolean boolean43 = node42.hasMoreThanOneChild();
        node42.setLineno(0);
        com.google.javascript.rhino.Node node46 = node42.cloneTree();
        com.google.javascript.rhino.Node node51 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        com.google.javascript.rhino.JSDocInfo jSDocInfo52 = null;
        node51.setJSDocInfo(jSDocInfo52);
        java.lang.RuntimeException runtimeException55 = com.google.javascript.rhino.ScriptRuntime.undefReadError((java.lang.Object) node51, (java.lang.Object) 22);
        node51.detachChildren();
        int int57 = node51.getChildCount();
        com.google.javascript.rhino.Node node60 = new com.google.javascript.rhino.Node((int) (short) -1, node30, node35, node46, node51, 15, (int) (byte) 1);
        java.lang.Appendable appendable61 = null;
        try {
            node30.appendStringTree(appendable61);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNull(jSType18);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(nodeArray26);
        org.junit.Assert.assertNotNull(node30);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertNotNull(node42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(node46);
        org.junit.Assert.assertNotNull(node51);
        org.junit.Assert.assertNotNull(runtimeException55);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 0 + "'", int57 == 0);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        java.lang.Double double0 = com.google.javascript.rhino.ScriptRuntime.NaNobj;
        org.junit.Assert.assertEquals((double) double0, Double.NaN, 0);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        try {
            compiler1.check();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test167() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test167");
//        try {
//            com.google.javascript.rhino.EvaluatorException evaluatorException5 = com.google.javascript.rhino.Context.reportRuntimeError("", "", 120, "hi!", 2);
//            org.junit.Assert.fail("Expected exception of type com.google.javascript.rhino.EvaluatorException; message:  (#120)");
//        } catch (com.google.javascript.rhino.EvaluatorException e) {
//        }
//    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.devirtualizePrototypeMethods = false;
        compilerOptions0.groupVariableDeclarations = false;
        boolean boolean5 = compilerOptions0.crossModuleCodeMotion;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap6 = null;
        compilerOptions0.cssRenamingMap = cssRenamingMap6;
        compilerOptions0.inputDelimiter = "<unknown=160>";
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.devirtualizePrototypeMethods = false;
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy3 = com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC;
        compilerOptions0.propertyRenaming = propertyRenamingPolicy3;
        java.lang.String str5 = compilerOptions0.unaliasableGlobals;
        compilerOptions0.setOutputCharset("language version");
        compilerOptions0.setAcceptConstKeyword(true);
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy3 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC + "'", propertyRenamingPolicy3.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC));
        org.junit.Assert.assertNull(str5);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        com.google.javascript.jscomp.SourceMap.DetailLevel detailLevel0 = com.google.javascript.jscomp.SourceMap.DetailLevel.ALL;
        org.junit.Assert.assertNotNull(detailLevel0);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        int int0 = com.google.javascript.rhino.Context.FEATURE_WARNING_AS_ERROR;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 12 + "'", int0 == 12);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeDeadCode = false;
        compilerOptions0.inlineLocalVariables = true;
        boolean boolean5 = compilerOptions0.optimizeArgumentsArray;
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.Compiler.IntermediateState intermediateState2 = null;
        try {
            compiler1.setState(intermediateState2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        com.google.javascript.rhino.Context context0 = null;
        try {
            long long1 = com.google.javascript.rhino.ScriptRuntime.lastUint32Result(context0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        java.lang.Object[] objArray0 = com.google.javascript.rhino.ScriptRuntime.emptyArgs;
        org.junit.Assert.assertNotNull(objArray0);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.devirtualizePrototypeMethods = false;
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy3 = com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC;
        compilerOptions0.propertyRenaming = propertyRenamingPolicy3;
        java.lang.String str5 = compilerOptions0.unaliasableGlobals;
        boolean boolean6 = compilerOptions0.checkTypedPropertyCalls;
        compilerOptions0.setTweakToBooleanLiteral("", true);
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy3 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC + "'", propertyRenamingPolicy3.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC));
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.devirtualizePrototypeMethods = false;
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy3 = com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC;
        compilerOptions0.propertyRenaming = propertyRenamingPolicy3;
        boolean boolean5 = compilerOptions0.recordFunctionInformation;
        compilerOptions0.enableExternExports(false);
        byte[] byteArray11 = new byte[] { (byte) -1, (byte) 1, (byte) 10 };
        compilerOptions0.inputVariableMapSerialized = byteArray11;
        compilerOptions0.convertToDottedProperties = true;
        boolean boolean15 = compilerOptions0.specializeInitialModule;
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy3 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC + "'", propertyRenamingPolicy3.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(byteArray11);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        try {
            int int2 = compiler1.getErrorCount();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        double double0 = com.google.javascript.rhino.ScriptRuntime.NaN;
        org.junit.Assert.assertEquals((double) double0, Double.NaN, 0);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        int int0 = com.google.javascript.rhino.Node.FREE_CALL;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 49 + "'", int0 == 49);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.devirtualizePrototypeMethods = false;
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy3 = com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC;
        compilerOptions0.propertyRenaming = propertyRenamingPolicy3;
        java.util.Set<java.lang.String> strSet5 = compilerOptions0.stripNameSuffixes;
        boolean boolean6 = compilerOptions0.strictMessageReplacement;
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy3 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC + "'", propertyRenamingPolicy3.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC));
        org.junit.Assert.assertNotNull(strSet5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeUnusedLocalVars = false;
        compilerOptions0.crossModuleCodeMotion = false;
        boolean boolean5 = compilerOptions0.optimizeParameters;
        compilerOptions0.checkSymbols = false;
        com.google.javascript.jscomp.CompilerOptions compilerOptions8 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CodingConvention codingConvention9 = compilerOptions8.getCodingConvention();
        com.google.javascript.jscomp.CompilerOptions.AliasTransformationHandler aliasTransformationHandler10 = compilerOptions8.getAliasTransformationHandler();
        compilerOptions8.extractPrototypeMemberDeclarations = false;
        com.google.javascript.jscomp.CheckLevel checkLevel13 = compilerOptions8.checkGlobalThisLevel;
        compilerOptions0.checkGlobalThisLevel = checkLevel13;
        compilerOptions0.disableRuntimeTypeCheck();
        compilerOptions0.optimizeArgumentsArray = false;
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(codingConvention9);
        org.junit.Assert.assertNotNull(aliasTransformationHandler10);
        org.junit.Assert.assertTrue("'" + checkLevel13 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel13.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        int int0 = com.google.javascript.rhino.Node.DEFAULT_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 14 + "'", int0 == 14);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.jstype.FunctionType functionType1 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType2 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType3 = null;
        closureCodingConvention0.applySubclassRelationship(functionType1, functionType2, subclassType3);
        com.google.javascript.rhino.jstype.FunctionType functionType5 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType6 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType7 = null;
        closureCodingConvention0.applySubclassRelationship(functionType5, functionType6, subclassType7);
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        node13.removeProp((int) (short) 1);
        com.google.javascript.rhino.Node node21 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        boolean boolean22 = node21.hasMoreThanOneChild();
        node21.setLineno(0);
        boolean boolean25 = node21.hasOneChild();
        com.google.javascript.rhino.jstype.JSType jSType26 = node21.getJSType();
        com.google.javascript.rhino.Node node31 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        node31.removeProp((int) (short) 1);
        com.google.javascript.rhino.Node[] nodeArray34 = new com.google.javascript.rhino.Node[] { node21, node31 };
        com.google.javascript.rhino.Node node37 = new com.google.javascript.rhino.Node((int) (byte) 10, nodeArray34, (int) '4', (int) (byte) -1);
        com.google.javascript.rhino.Node node38 = node13.copyInformationFromForTree(node37);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder39 = node37.new FileLevelJsDocBuilder();
        java.lang.String str43 = node37.toString(false, false, false);
        com.google.javascript.jscomp.CodingConvention.SubclassRelationship subclassRelationship44 = closureCodingConvention0.getClassesDefinedByCall(node37);
        com.google.javascript.jscomp.AbstractCompiler abstractCompiler45 = null;
        com.google.javascript.jscomp.NodeTraversal.Callback callback46 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal47 = new com.google.javascript.jscomp.NodeTraversal(abstractCompiler45, callback46);
        com.google.javascript.rhino.Node node52 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        boolean boolean53 = node52.hasMoreThanOneChild();
        node52.setLineno(0);
        boolean boolean56 = node52.hasOneChild();
        com.google.javascript.rhino.jstype.JSType jSType57 = node52.getJSType();
        try {
            com.google.javascript.jscomp.CodingConvention.ObjectLiteralCast objectLiteralCast58 = closureCodingConvention0.getObjectLiteralCast(nodeTraversal47, node52);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNull(jSType26);
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertNotNull(nodeArray34);
        org.junit.Assert.assertNotNull(node38);
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "BITXOR" + "'", str43.equals("BITXOR"));
        org.junit.Assert.assertNull(subclassRelationship44);
        org.junit.Assert.assertNotNull(node52);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertNull(jSType57);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.jstype.FunctionType functionType1 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType2 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType3 = null;
        closureCodingConvention0.applySubclassRelationship(functionType1, functionType2, subclassType3);
        boolean boolean6 = closureCodingConvention0.isSuperClassReference("");
        java.lang.String str7 = closureCodingConvention0.getAbstractMethodName();
        java.lang.String str8 = closureCodingConvention0.getExportPropertyFunction();
        java.lang.String str9 = closureCodingConvention0.getExportPropertyFunction();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "goog.abstractMethod" + "'", str7.equals("goog.abstractMethod"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "goog.exportProperty" + "'", str8.equals("goog.exportProperty"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "goog.exportProperty" + "'", str9.equals("goog.exportProperty"));
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        boolean boolean7 = node6.hasMoreThanOneChild();
        node6.setLineno(0);
        boolean boolean10 = node6.hasOneChild();
        com.google.javascript.rhino.jstype.JSType jSType11 = node6.getJSType();
        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        node16.removeProp((int) (short) 1);
        com.google.javascript.rhino.Node[] nodeArray19 = new com.google.javascript.rhino.Node[] { node6, node16 };
        com.google.javascript.rhino.Node node22 = new com.google.javascript.rhino.Node((int) (byte) 10, nodeArray19, (int) '4', (int) (byte) -1);
        try {
            com.google.javascript.rhino.Node node23 = new com.google.javascript.rhino.Node(37, nodeArray19);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: duplicate child");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNull(jSType11);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertNotNull(nodeArray19);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.devirtualizePrototypeMethods = false;
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy3 = com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC;
        compilerOptions0.propertyRenaming = propertyRenamingPolicy3;
        java.util.Set<java.lang.String> strSet5 = compilerOptions0.stripNameSuffixes;
        compilerOptions0.recordFunctionInformation = false;
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy3 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC + "'", propertyRenamingPolicy3.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC));
        org.junit.Assert.assertNotNull(strSet5);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.EXTERNS_VALIDATION;
        com.google.javascript.jscomp.DiagnosticGroups.AMBIGUOUS_FUNCTION_DECL = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticGroups.CHECK_REGEXP = diagnosticGroup0;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.devirtualizePrototypeMethods = false;
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy3 = com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC;
        compilerOptions0.propertyRenaming = propertyRenamingPolicy3;
        boolean boolean5 = compilerOptions0.recordFunctionInformation;
        compilerOptions0.enableExternExports(false);
        boolean boolean8 = compilerOptions0.optimizeArgumentsArray;
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy3 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC + "'", propertyRenamingPolicy3.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        int int0 = com.google.javascript.rhino.Node.SKIP_INDEXES_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 30 + "'", int0 == 30);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile1 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        java.lang.String str2 = jSSourceFile1.getOriginalPath();
        jSSourceFile1.clearCachedSource();
        org.junit.Assert.assertNotNull(jSSourceFile1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        com.google.javascript.jscomp.CompilerOptions.TweakProcessing tweakProcessing0 = com.google.javascript.jscomp.CompilerOptions.TweakProcessing.STRIP;
        boolean boolean1 = tweakProcessing0.shouldStrip();
        org.junit.Assert.assertTrue("'" + tweakProcessing0 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TweakProcessing.STRIP + "'", tweakProcessing0.equals(com.google.javascript.jscomp.CompilerOptions.TweakProcessing.STRIP));
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        int int0 = com.google.javascript.rhino.jstype.JSType.ENUMDECL;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile1 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.CompilerInput compilerInput2 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile1);
        com.google.javascript.jscomp.JSModule jSModule3 = null;
        compilerInput2.setModule(jSModule3);
        com.google.javascript.jscomp.CompilerInput compilerInput6 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput2, false);
        com.google.javascript.jscomp.Region region8 = compilerInput6.getRegion(32);
        boolean boolean9 = compilerInput6.isExtern();
        org.junit.Assert.assertNotNull(jSSourceFile1);
        org.junit.Assert.assertNull(region8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        int int0 = com.google.javascript.rhino.Node.CASEARRAY_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 15 + "'", int0 == 15);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.devirtualizePrototypeMethods = false;
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy3 = com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC;
        compilerOptions0.propertyRenaming = propertyRenamingPolicy3;
        boolean boolean5 = compilerOptions0.recordFunctionInformation;
        compilerOptions0.enableExternExports(false);
        byte[] byteArray11 = new byte[] { (byte) -1, (byte) 1, (byte) 10 };
        compilerOptions0.inputVariableMapSerialized = byteArray11;
        compilerOptions0.convertToDottedProperties = true;
        com.google.javascript.jscomp.CompilerOptions compilerOptions15 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions15.devirtualizePrototypeMethods = false;
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy18 = com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC;
        compilerOptions15.propertyRenaming = propertyRenamingPolicy18;
        boolean boolean20 = compilerOptions15.recordFunctionInformation;
        compilerOptions15.enableExternExports(false);
        com.google.javascript.jscomp.CheckLevel checkLevel23 = compilerOptions15.checkUnreachableCode;
        compilerOptions0.checkRequires = checkLevel23;
        java.lang.String str25 = com.google.javascript.rhino.ScriptRuntime.toString((java.lang.Object) compilerOptions0);
        com.google.javascript.jscomp.MessageBundle messageBundle26 = null;
        compilerOptions0.messageBundle = messageBundle26;
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy3 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC + "'", propertyRenamingPolicy3.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(byteArray11);
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy18 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC + "'", propertyRenamingPolicy18.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC));
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + checkLevel23 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel23.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        int int0 = com.google.javascript.rhino.Node.OPT_ARG_NAME;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 36 + "'", int0 == 36);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        int int0 = com.google.javascript.rhino.Node.TARGET_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CodingConvention codingConvention1 = compilerOptions0.getCodingConvention();
        com.google.javascript.jscomp.CompilerOptions.AliasTransformationHandler aliasTransformationHandler2 = compilerOptions0.getAliasTransformationHandler();
        com.google.javascript.jscomp.CompilerOptions compilerOptions3 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions3.devirtualizePrototypeMethods = false;
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy6 = com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC;
        compilerOptions3.propertyRenaming = propertyRenamingPolicy6;
        boolean boolean8 = compilerOptions3.recordFunctionInformation;
        compilerOptions3.enableExternExports(false);
        byte[] byteArray14 = new byte[] { (byte) -1, (byte) 1, (byte) 10 };
        compilerOptions3.inputVariableMapSerialized = byteArray14;
        compilerOptions0.inputPropertyMapSerialized = byteArray14;
        boolean boolean17 = compilerOptions0.inferTypesInGlobalScope;
        java.lang.String str18 = compilerOptions0.appNameStr;
        org.junit.Assert.assertNull(codingConvention1);
        org.junit.Assert.assertNotNull(aliasTransformationHandler2);
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy6 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC + "'", propertyRenamingPolicy6.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(byteArray14);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "" + "'", str18.equals(""));
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.devirtualizePrototypeMethods = false;
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy3 = com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC;
        compilerOptions0.propertyRenaming = propertyRenamingPolicy3;
        boolean boolean5 = compilerOptions0.recordFunctionInformation;
        compilerOptions0.enableExternExports(false);
        com.google.javascript.jscomp.CompilerOptions.TweakProcessing tweakProcessing8 = compilerOptions0.getTweakProcessing();
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy3 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC + "'", propertyRenamingPolicy3.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + tweakProcessing8 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TweakProcessing.OFF + "'", tweakProcessing8.equals(com.google.javascript.jscomp.CompilerOptions.TweakProcessing.OFF));
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.devirtualizePrototypeMethods = false;
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy3 = com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC;
        compilerOptions0.propertyRenaming = propertyRenamingPolicy3;
        boolean boolean5 = compilerOptions0.recordFunctionInformation;
        compilerOptions0.setColorizeErrorOutput(false);
        boolean boolean8 = compilerOptions0.specializeInitialModule;
        boolean boolean9 = compilerOptions0.specializeInitialModule;
        boolean boolean10 = compilerOptions0.generatePseudoNames;
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy3 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC + "'", propertyRenamingPolicy3.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.jstype.FunctionType functionType1 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType2 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType3 = null;
        closureCodingConvention0.applySubclassRelationship(functionType1, functionType2, subclassType3);
        com.google.javascript.rhino.jstype.FunctionType functionType5 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType6 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType7 = null;
        closureCodingConvention0.applySubclassRelationship(functionType5, functionType6, subclassType7);
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        node13.removeProp((int) (short) 1);
        com.google.javascript.rhino.Node node21 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        boolean boolean22 = node21.hasMoreThanOneChild();
        node21.setLineno(0);
        boolean boolean25 = node21.hasOneChild();
        com.google.javascript.rhino.jstype.JSType jSType26 = node21.getJSType();
        com.google.javascript.rhino.Node node31 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        node31.removeProp((int) (short) 1);
        com.google.javascript.rhino.Node[] nodeArray34 = new com.google.javascript.rhino.Node[] { node21, node31 };
        com.google.javascript.rhino.Node node37 = new com.google.javascript.rhino.Node((int) (byte) 10, nodeArray34, (int) '4', (int) (byte) -1);
        com.google.javascript.rhino.Node node38 = node13.copyInformationFromForTree(node37);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder39 = node37.new FileLevelJsDocBuilder();
        java.lang.String str43 = node37.toString(false, false, false);
        com.google.javascript.jscomp.CodingConvention.SubclassRelationship subclassRelationship44 = closureCodingConvention0.getClassesDefinedByCall(node37);
        boolean boolean46 = closureCodingConvention0.isExported("DiagnosticGroup<undefinedVars>");
        com.google.javascript.rhino.jstype.FunctionType functionType47 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType48 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType49 = null;
        closureCodingConvention0.applySubclassRelationship(functionType47, functionType48, subclassType49);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNull(jSType26);
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertNotNull(nodeArray34);
        org.junit.Assert.assertNotNull(node38);
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "BITXOR" + "'", str43.equals("BITXOR"));
        org.junit.Assert.assertNull(subclassRelationship44);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        com.google.javascript.rhino.JSDocInfo jSDocInfo5 = null;
        node4.setJSDocInfo(jSDocInfo5);
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable7 = node4.siblings();
        node4.setLineno(20);
        try {
            com.google.javascript.rhino.Node node11 = node4.getChildAtIndex(31);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(nodeIterable7);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.devirtualizePrototypeMethods = false;
        compilerOptions0.groupVariableDeclarations = false;
        boolean boolean5 = compilerOptions0.crossModuleCodeMotion;
        compilerOptions0.setManageClosureDependencies(true);
        compilerOptions0.inlineVariables = false;
        compilerOptions0.optimizeReturns = true;
        java.lang.String str12 = compilerOptions0.syntheticBlockStartMarker;
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(str12);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        com.google.javascript.rhino.EcmaError ecmaError2 = com.google.javascript.rhino.ScriptRuntime.constructError("0", "goog.exportProperty");
        int int3 = ecmaError2.lineNumber();
        ecmaError2.initLineSource("DiagnosticGroup<undefinedVars>");
        org.junit.Assert.assertNotNull(ecmaError2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile1 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.CompilerInput compilerInput2 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile1);
        boolean boolean3 = compilerInput2.isExtern();
        com.google.javascript.jscomp.JSModule jSModule4 = null;
        compilerInput2.setModule(jSModule4);
        compilerInput2.clearAst();
        java.nio.charset.Charset charset8 = null;
        com.google.javascript.jscomp.SourceFile sourceFile9 = com.google.javascript.jscomp.SourceFile.fromFile("BITXOR", charset8);
        java.lang.String str10 = sourceFile9.getOriginalPath();
        try {
            compilerInput2.setSourceFile(sourceFile9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(sourceFile9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "BITXOR" + "'", str10.equals("BITXOR"));
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeUnusedLocalVars = false;
        compilerOptions0.crossModuleCodeMotion = false;
        boolean boolean5 = compilerOptions0.optimizeParameters;
        compilerOptions0.checkSymbols = false;
        boolean boolean8 = compilerOptions0.inlineAnonymousFunctionExpressions;
        compilerOptions0.setCollapsePropertiesOnExternTypes(false);
        compilerOptions0.setTweakToStringLiteral("error reporter", "goog.exportProperty");
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.Node.newString(11, "(goog.exportSymbol)");
        org.junit.Assert.assertNotNull(node2);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        com.google.javascript.rhino.JSDocInfo jSDocInfo5 = null;
        node4.setJSDocInfo(jSDocInfo5);
        node4.setType(100);
        java.util.Set<java.lang.String> strSet9 = node4.getDirectives();
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNull(strSet9);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.jstype.FunctionType functionType1 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType2 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType3 = null;
        closureCodingConvention0.applySubclassRelationship(functionType1, functionType2, subclassType3);
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString("goog.exportSymbol");
        try {
            com.google.javascript.jscomp.CodingConvention.SubclassRelationship subclassRelationship7 = closureCodingConvention0.getClassesDefinedByCall(node6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node6);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.Node.newString((int) '4', "language version");
        org.junit.Assert.assertNotNull(node2);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeUnusedLocalVars = false;
        compilerOptions0.crossModuleCodeMotion = false;
        boolean boolean5 = compilerOptions0.optimizeParameters;
        compilerOptions0.checkSymbols = false;
        com.google.javascript.jscomp.CompilerOptions compilerOptions8 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CodingConvention codingConvention9 = compilerOptions8.getCodingConvention();
        com.google.javascript.jscomp.CompilerOptions.AliasTransformationHandler aliasTransformationHandler10 = compilerOptions8.getAliasTransformationHandler();
        compilerOptions8.extractPrototypeMemberDeclarations = false;
        com.google.javascript.jscomp.CheckLevel checkLevel13 = compilerOptions8.checkGlobalThisLevel;
        compilerOptions0.checkGlobalThisLevel = checkLevel13;
        java.lang.String str15 = compilerOptions0.syntheticBlockStartMarker;
        java.lang.String str16 = compilerOptions0.jsOutputFile;
        java.lang.String str17 = compilerOptions0.nameReferenceReportPath;
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(codingConvention9);
        org.junit.Assert.assertNotNull(aliasTransformationHandler10);
        org.junit.Assert.assertTrue("'" + checkLevel13 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel13.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNull(str15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
        org.junit.Assert.assertNull(str17);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        long long1 = com.google.javascript.rhino.ScriptRuntime.testUint32String("0");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        int int0 = com.google.javascript.rhino.Node.SPECIALCALL_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 27 + "'", int0 == 27);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.devirtualizePrototypeMethods = false;
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy3 = com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC;
        compilerOptions0.propertyRenaming = propertyRenamingPolicy3;
        java.lang.String str5 = compilerOptions0.unaliasableGlobals;
        compilerOptions0.setOutputCharset("language version");
        java.util.Set<java.lang.String> strSet8 = compilerOptions0.stripNamePrefixes;
        compilerOptions0.setTweakToNumberLiteral("goog.global", 37);
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy3 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC + "'", propertyRenamingPolicy3.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC));
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertNotNull(strSet8);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        com.google.javascript.rhino.Context context0 = null;
        com.google.javascript.rhino.Context context1 = com.google.javascript.rhino.Context.enter(context0);
        com.google.javascript.rhino.ErrorReporter errorReporter2 = null;
        try {
            com.google.javascript.rhino.ErrorReporter errorReporter3 = context1.setErrorReporter(errorReporter2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(context1);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        java.lang.String str1 = com.google.javascript.rhino.Node.tokenToName((int) ' ');
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "typeof" + "'", str1.equals("typeof"));
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        try {
            com.google.javascript.rhino.EcmaError ecmaError3 = com.google.javascript.rhino.ScriptRuntime.typeError2("0", "goog.abstractMethod", "<unknown=160>");
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property 0");
        } catch (java.lang.RuntimeException e) {
        }
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        com.google.javascript.jscomp.AbstractCompiler abstractCompiler0 = null;
        com.google.javascript.jscomp.NodeTraversal.Callback callback1 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal2 = new com.google.javascript.jscomp.NodeTraversal(abstractCompiler0, callback1);
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        com.google.javascript.rhino.JSDocInfo jSDocInfo9 = null;
        node8.setJSDocInfo(jSDocInfo9);
        java.lang.RuntimeException runtimeException12 = com.google.javascript.rhino.ScriptRuntime.undefReadError((java.lang.Object) node8, (java.lang.Object) 22);
        node8.detachChildren();
        com.google.javascript.rhino.Node node14 = new com.google.javascript.rhino.Node((int) (short) 100, node8);
        com.google.javascript.jscomp.CompilerOptions compilerOptions15 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CodingConvention codingConvention16 = compilerOptions15.getCodingConvention();
        compilerOptions15.computeFunctionSideEffects = true;
        com.google.javascript.jscomp.CheckLevel checkLevel19 = compilerOptions15.checkRequires;
        com.google.javascript.jscomp.DiagnosticType diagnosticType20 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        com.google.javascript.jscomp.DiagnosticType diagnosticType24 = com.google.javascript.jscomp.Compiler.MOTION_ITERATIONS_ERROR;
        java.lang.String[] strArray31 = new java.lang.String[] { "<unknown=160>", "<unknown=160>", "<unknown=160>", "<unknown=160>", "BITXOR", "DiagnosticGroup<undefinedVars>" };
        com.google.javascript.jscomp.JSError jSError32 = com.google.javascript.jscomp.JSError.make("BITXOR", 32, (int) (short) 100, diagnosticType24, strArray31);
        com.google.javascript.jscomp.JSError jSError33 = nodeTraversal2.makeError(node14, checkLevel19, diagnosticType20, strArray31);
        com.google.javascript.rhino.Node node34 = null;
        try {
            nodeTraversal2.traverse(node34);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNotNull(runtimeException12);
        org.junit.Assert.assertNull(codingConvention16);
        org.junit.Assert.assertTrue("'" + checkLevel19 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel19.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(diagnosticType20);
        org.junit.Assert.assertNotNull(diagnosticType24);
        org.junit.Assert.assertNotNull(strArray31);
        org.junit.Assert.assertNotNull(jSError32);
        org.junit.Assert.assertNotNull(jSError33);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        int int0 = com.google.javascript.rhino.Context.VERSION_DEFAULT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.devirtualizePrototypeMethods = false;
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy3 = com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC;
        compilerOptions0.propertyRenaming = propertyRenamingPolicy3;
        boolean boolean5 = compilerOptions0.recordFunctionInformation;
        compilerOptions0.enableExternExports(false);
        byte[] byteArray11 = new byte[] { (byte) -1, (byte) 1, (byte) 10 };
        compilerOptions0.inputVariableMapSerialized = byteArray11;
        compilerOptions0.removeTryCatchFinally = true;
        com.google.javascript.jscomp.CompilerOptions compilerOptions15 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions15.devirtualizePrototypeMethods = false;
        compilerOptions15.groupVariableDeclarations = false;
        boolean boolean20 = compilerOptions15.crossModuleCodeMotion;
        compilerOptions15.setManageClosureDependencies(true);
        compilerOptions15.inlineVariables = false;
        com.google.javascript.jscomp.CompilerOptions compilerOptions25 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CodingConvention codingConvention26 = compilerOptions25.getCodingConvention();
        compilerOptions25.computeFunctionSideEffects = true;
        com.google.javascript.jscomp.CheckLevel checkLevel29 = compilerOptions25.checkRequires;
        compilerOptions15.checkRequires = checkLevel29;
        compilerOptions0.checkGlobalNamesLevel = checkLevel29;
        boolean boolean32 = compilerOptions0.removeEmptyFunctions;
        compilerOptions0.disambiguateProperties = true;
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy3 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC + "'", propertyRenamingPolicy3.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(byteArray11);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNull(codingConvention26);
        org.junit.Assert.assertTrue("'" + checkLevel29 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel29.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        com.google.javascript.rhino.JSDocInfo jSDocInfo6 = null;
        node5.setJSDocInfo(jSDocInfo6);
        java.lang.RuntimeException runtimeException9 = com.google.javascript.rhino.ScriptRuntime.undefReadError((java.lang.Object) node5, (java.lang.Object) 22);
        node5.detachChildren();
        com.google.javascript.rhino.Node node11 = new com.google.javascript.rhino.Node((int) (short) 100, node5);
        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        com.google.javascript.rhino.JSDocInfo jSDocInfo17 = null;
        node16.setJSDocInfo(jSDocInfo17);
        node16.setType(100);
        com.google.javascript.rhino.Node node21 = node16.cloneTree();
        node5.addChildToBack(node16);
        java.util.Collection<com.google.javascript.rhino.Node> nodeCollection23 = com.google.javascript.jscomp.NodeUtil.getVarsDeclaredInBranch(node16);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNotNull(runtimeException9);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertNotNull(nodeCollection23);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        com.google.javascript.rhino.Context context0 = new com.google.javascript.rhino.Context();
        com.google.javascript.jscomp.AnonymousFunctionNamingPolicy anonymousFunctionNamingPolicy1 = com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.UNMAPPED;
        context0.removeThreadLocal((java.lang.Object) anonymousFunctionNamingPolicy1);
        java.util.Locale locale3 = context0.getLocale();
        java.lang.String str4 = context0.getImplementationVersion();
        com.google.javascript.rhino.Context context5 = com.google.javascript.rhino.Context.enter(context0);
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        try {
            context0.removePropertyChangeListener(propertyChangeListener6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + anonymousFunctionNamingPolicy1 + "' != '" + com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.UNMAPPED + "'", anonymousFunctionNamingPolicy1.equals(com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.UNMAPPED));
        org.junit.Assert.assertNotNull(locale3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "@IMPLEMENTATION.VERSION@" + "'", str4.equals("@IMPLEMENTATION.VERSION@"));
        org.junit.Assert.assertNotNull(context5);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        com.google.javascript.rhino.Node node0 = null;
        try {
            java.util.Collection<com.google.javascript.rhino.Node> nodeCollection1 = com.google.javascript.jscomp.NodeUtil.getVarsDeclaredInBranch(node0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        com.google.javascript.jscomp.AbstractCompiler abstractCompiler0 = null;
        com.google.javascript.jscomp.NodeTraversal.Callback callback1 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal2 = new com.google.javascript.jscomp.NodeTraversal(abstractCompiler0, callback1);
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        com.google.javascript.rhino.JSDocInfo jSDocInfo9 = null;
        node8.setJSDocInfo(jSDocInfo9);
        java.lang.RuntimeException runtimeException12 = com.google.javascript.rhino.ScriptRuntime.undefReadError((java.lang.Object) node8, (java.lang.Object) 22);
        node8.detachChildren();
        com.google.javascript.rhino.Node node14 = new com.google.javascript.rhino.Node((int) (short) 100, node8);
        com.google.javascript.jscomp.CompilerOptions compilerOptions15 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CodingConvention codingConvention16 = compilerOptions15.getCodingConvention();
        compilerOptions15.computeFunctionSideEffects = true;
        com.google.javascript.jscomp.CheckLevel checkLevel19 = compilerOptions15.checkRequires;
        com.google.javascript.jscomp.DiagnosticType diagnosticType20 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        com.google.javascript.jscomp.DiagnosticType diagnosticType24 = com.google.javascript.jscomp.Compiler.MOTION_ITERATIONS_ERROR;
        java.lang.String[] strArray31 = new java.lang.String[] { "<unknown=160>", "<unknown=160>", "<unknown=160>", "<unknown=160>", "BITXOR", "DiagnosticGroup<undefinedVars>" };
        com.google.javascript.jscomp.JSError jSError32 = com.google.javascript.jscomp.JSError.make("BITXOR", 32, (int) (short) 100, diagnosticType24, strArray31);
        com.google.javascript.jscomp.JSError jSError33 = nodeTraversal2.makeError(node14, checkLevel19, diagnosticType20, strArray31);
        com.google.javascript.rhino.Node node38 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        boolean boolean39 = node38.hasMoreThanOneChild();
        node38.setLineno(0);
        boolean boolean42 = node38.hasOneChild();
        com.google.javascript.rhino.jstype.JSType jSType43 = node38.getJSType();
        try {
            nodeTraversal2.traverse(node38);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNotNull(runtimeException12);
        org.junit.Assert.assertNull(codingConvention16);
        org.junit.Assert.assertTrue("'" + checkLevel19 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel19.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(diagnosticType20);
        org.junit.Assert.assertNotNull(diagnosticType24);
        org.junit.Assert.assertNotNull(strArray31);
        org.junit.Assert.assertNotNull(jSError32);
        org.junit.Assert.assertNotNull(jSError33);
        org.junit.Assert.assertNotNull(node38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNull(jSType43);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        int int0 = com.google.javascript.rhino.Node.NON_SPECIALCALL;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.ACCESS_CONTROLS;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = null;
        com.google.javascript.jscomp.CompilerOptions compilerOptions1 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions1.devirtualizePrototypeMethods = false;
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy4 = com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC;
        compilerOptions1.propertyRenaming = propertyRenamingPolicy4;
        boolean boolean6 = compilerOptions1.recordFunctionInformation;
        compilerOptions1.optimizeArgumentsArray = false;
        com.google.javascript.jscomp.DiagnosticType diagnosticType9 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        com.google.javascript.jscomp.CheckLevel checkLevel10 = diagnosticType9.defaultLevel;
        compilerOptions1.checkMethods = checkLevel10;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard12 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup0, checkLevel10);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup13 = null;
        com.google.javascript.jscomp.CompilerOptions compilerOptions14 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions14.devirtualizePrototypeMethods = false;
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy17 = com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC;
        compilerOptions14.propertyRenaming = propertyRenamingPolicy17;
        boolean boolean19 = compilerOptions14.recordFunctionInformation;
        compilerOptions14.optimizeArgumentsArray = false;
        com.google.javascript.jscomp.DiagnosticType diagnosticType22 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        com.google.javascript.jscomp.CheckLevel checkLevel23 = diagnosticType22.defaultLevel;
        compilerOptions14.checkMethods = checkLevel23;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard25 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup13, checkLevel23);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup26 = null;
        com.google.javascript.jscomp.CompilerOptions compilerOptions27 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions27.devirtualizePrototypeMethods = false;
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy30 = com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC;
        compilerOptions27.propertyRenaming = propertyRenamingPolicy30;
        boolean boolean32 = compilerOptions27.recordFunctionInformation;
        compilerOptions27.optimizeArgumentsArray = false;
        com.google.javascript.jscomp.DiagnosticType diagnosticType35 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        com.google.javascript.jscomp.CheckLevel checkLevel36 = diagnosticType35.defaultLevel;
        compilerOptions27.checkMethods = checkLevel36;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard38 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup26, checkLevel36);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup39 = null;
        com.google.javascript.jscomp.CompilerOptions compilerOptions40 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions40.devirtualizePrototypeMethods = false;
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy43 = com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC;
        compilerOptions40.propertyRenaming = propertyRenamingPolicy43;
        boolean boolean45 = compilerOptions40.recordFunctionInformation;
        compilerOptions40.optimizeArgumentsArray = false;
        com.google.javascript.jscomp.DiagnosticType diagnosticType48 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        com.google.javascript.jscomp.CheckLevel checkLevel49 = diagnosticType48.defaultLevel;
        compilerOptions40.checkMethods = checkLevel49;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard51 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup39, checkLevel49);
        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray52 = new com.google.javascript.jscomp.WarningsGuard[] { diagnosticGroupWarningsGuard12, diagnosticGroupWarningsGuard25, diagnosticGroupWarningsGuard38, diagnosticGroupWarningsGuard51 };
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard53 = new com.google.javascript.jscomp.ComposeWarningsGuard(warningsGuardArray52);
        java.lang.String str54 = composeWarningsGuard53.toString();
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup55 = com.google.javascript.jscomp.DiagnosticGroups.TYPE_INVALIDATION;
        com.google.javascript.jscomp.DiagnosticGroups.NON_STANDARD_JSDOC = diagnosticGroup55;
        com.google.javascript.jscomp.DiagnosticGroups.UNDEFINED_VARIABLES = diagnosticGroup55;
        try {
            boolean boolean58 = composeWarningsGuard53.disables(diagnosticGroup55);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy4 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC + "'", propertyRenamingPolicy4.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(diagnosticType9);
        org.junit.Assert.assertTrue("'" + checkLevel10 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel10.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy17 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC + "'", propertyRenamingPolicy17.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(diagnosticType22);
        org.junit.Assert.assertTrue("'" + checkLevel23 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel23.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy30 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC + "'", propertyRenamingPolicy30.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC));
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(diagnosticType35);
        org.junit.Assert.assertTrue("'" + checkLevel36 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel36.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy43 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC + "'", propertyRenamingPolicy43.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC));
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(diagnosticType48);
        org.junit.Assert.assertTrue("'" + checkLevel49 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel49.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(warningsGuardArray52);
        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "null(ERROR), null(ERROR), null(ERROR), null(ERROR)" + "'", str54.equals("null(ERROR), null(ERROR), null(ERROR), null(ERROR)"));
        org.junit.Assert.assertNotNull(diagnosticGroup55);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        boolean boolean5 = node4.hasMoreThanOneChild();
        node4.setLineno(0);
        com.google.javascript.rhino.Node node8 = node4.cloneTree();
        com.google.javascript.rhino.Node node9 = node8.removeChildren();
        try {
            com.google.javascript.rhino.Node node10 = node9.detachFromParent();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNull(node9);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        com.google.javascript.rhino.JSDocInfo jSDocInfo5 = null;
        node4.setJSDocInfo(jSDocInfo5);
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable7 = node4.siblings();
        com.google.javascript.rhino.Context context8 = new com.google.javascript.rhino.Context();
        com.google.javascript.jscomp.AnonymousFunctionNamingPolicy anonymousFunctionNamingPolicy9 = com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.UNMAPPED;
        context8.removeThreadLocal((java.lang.Object) anonymousFunctionNamingPolicy9);
        boolean boolean11 = context8.isGeneratingDebug();
        long long12 = com.google.javascript.rhino.ScriptRuntime.lastUint32Result(context8);
        com.google.javascript.rhino.Context context13 = com.google.javascript.rhino.Context.enter(context8);
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        node18.removeProp((int) (short) 1);
        com.google.javascript.rhino.Node node26 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        boolean boolean27 = node26.hasMoreThanOneChild();
        node26.setLineno(0);
        boolean boolean30 = node26.hasOneChild();
        com.google.javascript.rhino.jstype.JSType jSType31 = node26.getJSType();
        com.google.javascript.rhino.Node node36 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        node36.removeProp((int) (short) 1);
        com.google.javascript.rhino.Node[] nodeArray39 = new com.google.javascript.rhino.Node[] { node26, node36 };
        com.google.javascript.rhino.Node node42 = new com.google.javascript.rhino.Node((int) (byte) 10, nodeArray39, (int) '4', (int) (byte) -1);
        com.google.javascript.rhino.Node node43 = node18.copyInformationFromForTree(node42);
        java.lang.Object obj44 = context13.getThreadLocal((java.lang.Object) node43);
        try {
            node4.removeChild(node43);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(nodeIterable7);
        org.junit.Assert.assertTrue("'" + anonymousFunctionNamingPolicy9 + "' != '" + com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.UNMAPPED + "'", anonymousFunctionNamingPolicy9.equals(com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.UNMAPPED));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertNotNull(context13);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNull(jSType31);
        org.junit.Assert.assertNotNull(node36);
        org.junit.Assert.assertNotNull(nodeArray39);
        org.junit.Assert.assertNotNull(node43);
        org.junit.Assert.assertNull(obj44);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeUnusedLocalVars = false;
        compilerOptions0.crossModuleCodeMotion = false;
        boolean boolean5 = compilerOptions0.optimizeParameters;
        compilerOptions0.checkSymbols = false;
        boolean boolean8 = compilerOptions0.inlineAnonymousFunctionExpressions;
        compilerOptions0.enableRuntimeTypeCheck("0");
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.MISSING_PROPERTIES;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeUnusedLocalVars = false;
        compilerOptions0.crossModuleCodeMotion = false;
        boolean boolean5 = compilerOptions0.optimizeParameters;
        compilerOptions0.checkSymbols = false;
        boolean boolean8 = compilerOptions0.inlineAnonymousFunctionExpressions;
        compilerOptions0.setCollapsePropertiesOnExternTypes(false);
        compilerOptions0.deadAssignmentElimination = false;
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        int int0 = com.google.javascript.rhino.Node.SIDE_EFFECTS_ALL;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.jstype.FunctionType functionType1 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType2 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType3 = null;
        closureCodingConvention0.applySubclassRelationship(functionType1, functionType2, subclassType3);
        boolean boolean6 = closureCodingConvention0.isSuperClassReference("");
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        node11.removeProp((int) (short) 1);
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        boolean boolean20 = node19.hasMoreThanOneChild();
        node19.setLineno(0);
        boolean boolean23 = node19.hasOneChild();
        com.google.javascript.rhino.jstype.JSType jSType24 = node19.getJSType();
        com.google.javascript.rhino.Node node29 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        node29.removeProp((int) (short) 1);
        com.google.javascript.rhino.Node[] nodeArray32 = new com.google.javascript.rhino.Node[] { node19, node29 };
        com.google.javascript.rhino.Node node35 = new com.google.javascript.rhino.Node((int) (byte) 10, nodeArray32, (int) '4', (int) (byte) -1);
        com.google.javascript.rhino.Node node36 = node11.copyInformationFromForTree(node35);
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention37 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.jstype.FunctionType functionType38 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType39 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType40 = null;
        closureCodingConvention37.applySubclassRelationship(functionType38, functionType39, subclassType40);
        com.google.javascript.rhino.jstype.FunctionType functionType42 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType43 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType44 = null;
        closureCodingConvention37.applySubclassRelationship(functionType42, functionType43, subclassType44);
        com.google.javascript.rhino.Node node50 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        node50.removeProp((int) (short) 1);
        com.google.javascript.rhino.Node node58 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        boolean boolean59 = node58.hasMoreThanOneChild();
        node58.setLineno(0);
        boolean boolean62 = node58.hasOneChild();
        com.google.javascript.rhino.jstype.JSType jSType63 = node58.getJSType();
        com.google.javascript.rhino.Node node68 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        node68.removeProp((int) (short) 1);
        com.google.javascript.rhino.Node[] nodeArray71 = new com.google.javascript.rhino.Node[] { node58, node68 };
        com.google.javascript.rhino.Node node74 = new com.google.javascript.rhino.Node((int) (byte) 10, nodeArray71, (int) '4', (int) (byte) -1);
        com.google.javascript.rhino.Node node75 = node50.copyInformationFromForTree(node74);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder76 = node74.new FileLevelJsDocBuilder();
        java.lang.String str80 = node74.toString(false, false, false);
        com.google.javascript.jscomp.CodingConvention.SubclassRelationship subclassRelationship81 = closureCodingConvention37.getClassesDefinedByCall(node74);
        java.lang.String str82 = closureCodingConvention0.extractClassNameIfProvide(node11, node74);
        try {
            int int84 = node74.getExistingIntProp(36);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: FAILED ASSERTION");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNull(jSType24);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNotNull(nodeArray32);
        org.junit.Assert.assertNotNull(node36);
        org.junit.Assert.assertNotNull(node50);
        org.junit.Assert.assertNotNull(node58);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertNull(jSType63);
        org.junit.Assert.assertNotNull(node68);
        org.junit.Assert.assertNotNull(nodeArray71);
        org.junit.Assert.assertNotNull(node75);
        org.junit.Assert.assertTrue("'" + str80 + "' != '" + "BITXOR" + "'", str80.equals("BITXOR"));
        org.junit.Assert.assertNull(subclassRelationship81);
        org.junit.Assert.assertNull(str82);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        try {
            java.lang.String[] strArray2 = compiler1.toSourceArray();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        java.lang.String str1 = closureCodingConvention0.getExportPropertyFunction();
        com.google.javascript.rhino.jstype.FunctionType functionType2 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType3 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType4 = null;
        try {
            closureCodingConvention0.applySingletonGetter(functionType2, functionType3, objectType4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "goog.exportProperty" + "'", str1.equals("goog.exportProperty"));
    }

//    @Test
//    public void test238() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test238");
//        com.google.javascript.rhino.Context context0 = new com.google.javascript.rhino.Context();
//        com.google.javascript.jscomp.AnonymousFunctionNamingPolicy anonymousFunctionNamingPolicy1 = com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.UNMAPPED;
//        context0.removeThreadLocal((java.lang.Object) anonymousFunctionNamingPolicy1);
//        java.util.Locale locale3 = context0.getLocale();
//        java.lang.String str4 = context0.getImplementationVersion();
//        com.google.javascript.rhino.Context context5 = com.google.javascript.rhino.Context.enter(context0);
//        try {
//            com.google.javascript.rhino.Context context6 = com.google.javascript.rhino.Context.enter(context0);
//            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Cannot enter Context active on another thread");
//        } catch (java.lang.RuntimeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + anonymousFunctionNamingPolicy1 + "' != '" + com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.UNMAPPED + "'", anonymousFunctionNamingPolicy1.equals(com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.UNMAPPED));
//        org.junit.Assert.assertNotNull(locale3);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "@IMPLEMENTATION.VERSION@" + "'", str4.equals("@IMPLEMENTATION.VERSION@"));
//        org.junit.Assert.assertNotNull(context5);
//    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        try {
            com.google.javascript.rhino.EcmaError ecmaError2 = com.google.javascript.rhino.ScriptRuntime.typeError1("<unknown=160>", "0");
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property <unknown=160>");
        } catch (java.lang.RuntimeException e) {
        }
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.devirtualizePrototypeMethods = false;
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy3 = com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC;
        compilerOptions0.propertyRenaming = propertyRenamingPolicy3;
        boolean boolean5 = compilerOptions0.recordFunctionInformation;
        compilerOptions0.enableExternExports(false);
        com.google.javascript.jscomp.CheckLevel checkLevel8 = compilerOptions0.checkUnreachableCode;
        com.google.javascript.jscomp.CheckLevel checkLevel9 = compilerOptions0.reportMissingOverride;
        java.lang.String str10 = com.google.javascript.rhino.ScriptRuntime.toString((java.lang.Object) compilerOptions0);
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy3 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC + "'", propertyRenamingPolicy3.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + checkLevel8 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel8.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + checkLevel9 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel9.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.devirtualizePrototypeMethods = false;
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy3 = com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC;
        compilerOptions0.propertyRenaming = propertyRenamingPolicy3;
        boolean boolean5 = compilerOptions0.recordFunctionInformation;
        compilerOptions0.setColorizeErrorOutput(false);
        boolean boolean8 = compilerOptions0.collapseAnonymousFunctions;
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy3 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC + "'", propertyRenamingPolicy3.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.CHECK_VARIABLES;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.devirtualizePrototypeMethods = false;
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy3 = com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC;
        compilerOptions0.propertyRenaming = propertyRenamingPolicy3;
        boolean boolean5 = compilerOptions0.recordFunctionInformation;
        compilerOptions0.enableExternExports(false);
        byte[] byteArray11 = new byte[] { (byte) -1, (byte) 1, (byte) 10 };
        compilerOptions0.inputVariableMapSerialized = byteArray11;
        compilerOptions0.convertToDottedProperties = true;
        compilerOptions0.instrumentForCoverageOnly = true;
        compilerOptions0.nameReferenceReportPath = "BITXOR";
        java.lang.String str19 = compilerOptions0.renamePrefix;
        compilerOptions0.removeDeadCode = false;
        com.google.javascript.jscomp.CompilerOptions compilerOptions22 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions22.devirtualizePrototypeMethods = false;
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy25 = com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC;
        compilerOptions22.propertyRenaming = propertyRenamingPolicy25;
        compilerOptions22.disableRuntimeTypeCheck();
        boolean boolean28 = compilerOptions22.allowLegacyJsMessages;
        com.google.javascript.jscomp.CompilerOptions compilerOptions29 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions29.removeUnusedLocalVars = false;
        compilerOptions29.crossModuleCodeMotion = false;
        com.google.javascript.jscomp.CompilerOptions compilerOptions34 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions34.devirtualizePrototypeMethods = false;
        java.util.Set<java.lang.String> strSet37 = compilerOptions34.stripNameSuffixes;
        compilerOptions29.stripNamePrefixes = strSet37;
        compilerOptions22.aliasableStrings = strSet37;
        compilerOptions0.setIdGenerators(strSet37);
        java.lang.String str41 = compilerOptions0.nameReferenceGraphPath;
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy3 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC + "'", propertyRenamingPolicy3.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(byteArray11);
        org.junit.Assert.assertNull(str19);
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy25 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC + "'", propertyRenamingPolicy25.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC));
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(strSet37);
        org.junit.Assert.assertNull(str41);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.jstype.FunctionType functionType1 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType2 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType3 = null;
        closureCodingConvention0.applySubclassRelationship(functionType1, functionType2, subclassType3);
        com.google.javascript.rhino.jstype.ObjectType objectType5 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType6 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType7 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType8 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType9 = null;
        closureCodingConvention0.applyDelegateRelationship(objectType5, objectType6, objectType7, functionType8, functionType9);
        java.util.Collection<com.google.javascript.jscomp.CodingConvention.AssertionFunctionSpec> assertionFunctionSpecCollection11 = closureCodingConvention0.getAssertionFunctions();
        com.google.javascript.rhino.jstype.FunctionType functionType12 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType13 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType14 = null;
        closureCodingConvention0.applySubclassRelationship(functionType12, functionType13, subclassType14);
        com.google.javascript.rhino.Node node16 = null;
        try {
            java.util.List<java.lang.String> strList17 = closureCodingConvention0.identifyTypeDeclarationCall(node16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(assertionFunctionSpecCollection11);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray2 = new com.google.javascript.jscomp.JSSourceFile[] {};
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray3 = new com.google.javascript.jscomp.JSSourceFile[] {};
        com.google.javascript.jscomp.CompilerOptions compilerOptions4 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions4.devirtualizePrototypeMethods = false;
        compilerOptions4.groupVariableDeclarations = false;
        boolean boolean9 = compilerOptions4.ideMode;
        compilerOptions4.setProcessObjectPropertyString(true);
        compilerOptions4.setDefineToBooleanLiteral("BITXOR", true);
        compilerOptions4.checkControlStructures = true;
        java.util.Map<java.lang.String, com.google.javascript.rhino.Node> strMap17 = compilerOptions4.getTweakReplacements();
        com.google.javascript.jscomp.Result result18 = compiler1.compile(jSSourceFileArray2, jSSourceFileArray3, compilerOptions4);
        com.google.javascript.jscomp.SourceExcerptProvider.SourceExcerpt sourceExcerpt19 = null;
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter20 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler1, sourceExcerpt19);
        com.google.javascript.jscomp.Compiler.CodeBuilder codeBuilder21 = new com.google.javascript.jscomp.Compiler.CodeBuilder();
        com.google.javascript.rhino.Node node28 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        com.google.javascript.rhino.JSDocInfo jSDocInfo29 = null;
        node28.setJSDocInfo(jSDocInfo29);
        java.lang.RuntimeException runtimeException32 = com.google.javascript.rhino.ScriptRuntime.undefReadError((java.lang.Object) node28, (java.lang.Object) 22);
        node28.detachChildren();
        com.google.javascript.rhino.Node node34 = new com.google.javascript.rhino.Node((int) (short) 100, node28);
        boolean boolean36 = node28.getBooleanProp(6);
        try {
            compiler1.toSource(codeBuilder21, 14, node28);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: java.lang.Error: Unknown type 1\nEOL  32\n");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFileArray2);
        org.junit.Assert.assertNotNull(jSSourceFileArray3);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(strMap17);
        org.junit.Assert.assertNotNull(result18);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertNotNull(runtimeException32);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        boolean boolean7 = node6.hasMoreThanOneChild();
        node6.setLineno(0);
        boolean boolean10 = node6.hasOneChild();
        com.google.javascript.rhino.jstype.JSType jSType11 = node6.getJSType();
        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        node16.removeProp((int) (short) 1);
        com.google.javascript.rhino.Node[] nodeArray19 = new com.google.javascript.rhino.Node[] { node6, node16 };
        com.google.javascript.rhino.Node node22 = new com.google.javascript.rhino.Node((int) (byte) 10, nodeArray19, (int) '4', (int) (byte) -1);
        try {
            com.google.javascript.rhino.Node node23 = new com.google.javascript.rhino.Node(0, nodeArray19);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: duplicate child");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNull(jSType11);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertNotNull(nodeArray19);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeUnusedLocalVars = false;
        compilerOptions0.crossModuleCodeMotion = false;
        compilerOptions0.ambiguateProperties = false;
        compilerOptions0.checkTypedPropertyCalls = true;
        boolean boolean9 = compilerOptions0.shouldColorizeErrorOutput();
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newNumber(0.0d, 160, 15);
        try {
            int int5 = node3.getExistingIntProp(15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: FAILED ASSERTION");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(node3);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        com.google.javascript.rhino.EcmaError ecmaError2 = com.google.javascript.rhino.ScriptRuntime.constructError("DiagnosticGroup<undefinedVars>", "<unknown=160>");
        int int3 = ecmaError2.getColumnNumber();
        ecmaError2.initLineSource("error reporter");
        java.lang.String str6 = ecmaError2.details();
        org.junit.Assert.assertNotNull(ecmaError2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "DiagnosticGroup<undefinedVars>: <unknown=160>" + "'", str6.equals("DiagnosticGroup<undefinedVars>: <unknown=160>"));
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.devirtualizePrototypeMethods = false;
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy3 = com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC;
        compilerOptions0.propertyRenaming = propertyRenamingPolicy3;
        boolean boolean5 = compilerOptions0.recordFunctionInformation;
        compilerOptions0.optimizeArgumentsArray = false;
        com.google.javascript.jscomp.DiagnosticType diagnosticType8 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        com.google.javascript.jscomp.CheckLevel checkLevel9 = diagnosticType8.defaultLevel;
        compilerOptions0.checkMethods = checkLevel9;
        com.google.javascript.jscomp.CompilerOptions.AliasTransformationHandler aliasTransformationHandler11 = compilerOptions0.getAliasTransformationHandler();
        boolean boolean12 = compilerOptions0.inlineAnonymousFunctionExpressions;
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy3 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC + "'", propertyRenamingPolicy3.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(diagnosticType8);
        org.junit.Assert.assertTrue("'" + checkLevel9 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel9.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(aliasTransformationHandler11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        com.google.javascript.jscomp.DiagnosticType diagnosticType1 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        java.text.MessageFormat messageFormat2 = diagnosticType1.format;
        com.google.javascript.jscomp.CompilerOptions.TweakProcessing tweakProcessing3 = com.google.javascript.jscomp.CompilerOptions.TweakProcessing.CHECK;
        try {
            java.lang.String str4 = com.google.javascript.rhino.ScriptRuntime.getMessage2("@IMPLEMENTATION.VERSION@", (java.lang.Object) messageFormat2, (java.lang.Object) tweakProcessing3);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property @IMPLEMENTATION.VERSION@");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(diagnosticType1);
        org.junit.Assert.assertNotNull(messageFormat2);
        org.junit.Assert.assertTrue("'" + tweakProcessing3 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TweakProcessing.CHECK + "'", tweakProcessing3.equals(com.google.javascript.jscomp.CompilerOptions.TweakProcessing.CHECK));
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        java.lang.Object[] objArray0 = com.google.javascript.rhino.Context.emptyArgs;
        org.junit.Assert.assertNotNull(objArray0);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        try {
            com.google.javascript.rhino.EcmaError ecmaError2 = com.google.javascript.rhino.ScriptRuntime.typeError1("null(ERROR), null(ERROR), null(ERROR), null(ERROR)", "(goog.exportSymbol)");
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property null(ERROR), null(ERROR), null(ERROR), null(ERROR)");
        } catch (java.lang.RuntimeException e) {
        }
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.devirtualizePrototypeMethods = false;
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy3 = com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC;
        compilerOptions0.propertyRenaming = propertyRenamingPolicy3;
        compilerOptions0.disableRuntimeTypeCheck();
        compilerOptions0.setDefineToNumberLiteral("DiagnosticGroup<undefinedVars>", 41);
        boolean boolean9 = compilerOptions0.collapseAnonymousFunctions;
        compilerOptions0.disambiguateProperties = false;
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy3 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC + "'", propertyRenamingPolicy3.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.VISIBILITY;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.devirtualizePrototypeMethods = false;
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy3 = com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC;
        compilerOptions0.propertyRenaming = propertyRenamingPolicy3;
        boolean boolean5 = compilerOptions0.recordFunctionInformation;
        compilerOptions0.optimizeArgumentsArray = false;
        com.google.javascript.jscomp.DiagnosticType diagnosticType8 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        com.google.javascript.jscomp.CheckLevel checkLevel9 = diagnosticType8.defaultLevel;
        compilerOptions0.checkMethods = checkLevel9;
        com.google.javascript.jscomp.CompilerOptions.AliasTransformationHandler aliasTransformationHandler11 = compilerOptions0.getAliasTransformationHandler();
        compilerOptions0.setDefineToNumberLiteral("0", 22);
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy3 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC + "'", propertyRenamingPolicy3.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(diagnosticType8);
        org.junit.Assert.assertTrue("'" + checkLevel9 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel9.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(aliasTransformationHandler11);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        int int0 = com.google.javascript.rhino.Node.FLAG_ARGUMENTS_UNMODIFIED;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        java.lang.String str1 = com.google.javascript.rhino.jstype.ObjectType.createDelegateSuffix("Not declared as a constructor");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "(Not declared as a constructor)" + "'", str1.equals("(Not declared as a constructor)"));
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        com.google.javascript.rhino.EvaluatorException evaluatorException1 = new com.google.javascript.rhino.EvaluatorException("goog.exportProperty");
        evaluatorException1.initLineSource("typeof");
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.jstype.FunctionType functionType1 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType2 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType3 = null;
        closureCodingConvention0.applySubclassRelationship(functionType1, functionType2, subclassType3);
        com.google.javascript.rhino.jstype.ObjectType objectType5 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType6 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType7 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType8 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType9 = null;
        closureCodingConvention0.applyDelegateRelationship(objectType5, objectType6, objectType7, functionType8, functionType9);
        java.lang.String str11 = closureCodingConvention0.getExportSymbolFunction();
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "goog.exportSymbol" + "'", str11.equals("goog.exportSymbol"));
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        int int0 = com.google.javascript.rhino.Node.SOURCENAME_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 16 + "'", int0 == 16);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.devirtualizePrototypeMethods = false;
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy3 = com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC;
        compilerOptions0.propertyRenaming = propertyRenamingPolicy3;
        boolean boolean5 = compilerOptions0.recordFunctionInformation;
        compilerOptions0.setColorizeErrorOutput(false);
        boolean boolean8 = compilerOptions0.specializeInitialModule;
        compilerOptions0.computeFunctionSideEffects = false;
        boolean boolean11 = compilerOptions0.collapseAnonymousFunctions;
        boolean boolean12 = compilerOptions0.rewriteFunctionExpressions;
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy3 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC + "'", propertyRenamingPolicy3.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        com.google.javascript.rhino.EvaluatorException evaluatorException1 = new com.google.javascript.rhino.EvaluatorException("language version");
        evaluatorException1.initLineNumber((int) (byte) 1);
        java.lang.String str4 = evaluatorException1.lineSource();
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.devirtualizePrototypeMethods = false;
        compilerOptions0.groupVariableDeclarations = false;
        boolean boolean5 = compilerOptions0.ideMode;
        compilerOptions0.setProcessObjectPropertyString(true);
        compilerOptions0.setDefineToBooleanLiteral("BITXOR", true);
        byte[] byteArray11 = compilerOptions0.inputVariableMapSerialized;
        compilerOptions0.markAsCompiled = false;
        com.google.javascript.jscomp.CompilerOptions compilerOptions14 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions14.removeUnusedLocalVars = false;
        compilerOptions14.crossModuleCodeMotion = false;
        com.google.javascript.jscomp.CompilerOptions compilerOptions19 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions19.devirtualizePrototypeMethods = false;
        java.util.Set<java.lang.String> strSet22 = compilerOptions19.stripNameSuffixes;
        compilerOptions14.stripNamePrefixes = strSet22;
        compilerOptions0.aliasableStrings = strSet22;
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(byteArray11);
        org.junit.Assert.assertNotNull(strSet22);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        com.google.javascript.rhino.EvaluatorException evaluatorException1 = new com.google.javascript.rhino.EvaluatorException("goog.exportProperty");
        evaluatorException1.initSourceName("Not declared as a type name");
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        java.lang.String str0 = com.google.javascript.rhino.jstype.JSType.UNKNOWN_NAME;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "Unknown class name" + "'", str0.equals("Unknown class name"));
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        com.google.javascript.rhino.JSDocInfo jSDocInfo6 = null;
        node5.setJSDocInfo(jSDocInfo6);
        java.lang.RuntimeException runtimeException9 = com.google.javascript.rhino.ScriptRuntime.undefReadError((java.lang.Object) node5, (java.lang.Object) 22);
        node5.detachChildren();
        com.google.javascript.rhino.Node node11 = new com.google.javascript.rhino.Node((int) (short) 100, node5);
        com.google.javascript.rhino.JSDocInfo jSDocInfo12 = null;
        node11.setJSDocInfo(jSDocInfo12);
        java.lang.String str14 = node11.getQualifiedName();
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNotNull(runtimeException9);
        org.junit.Assert.assertNull(str14);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.devirtualizePrototypeMethods = false;
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy3 = com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC;
        compilerOptions0.propertyRenaming = propertyRenamingPolicy3;
        boolean boolean5 = compilerOptions0.recordFunctionInformation;
        compilerOptions0.enableExternExports(false);
        byte[] byteArray11 = new byte[] { (byte) -1, (byte) 1, (byte) 10 };
        compilerOptions0.inputVariableMapSerialized = byteArray11;
        compilerOptions0.convertToDottedProperties = true;
        com.google.javascript.jscomp.CompilerOptions compilerOptions15 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions15.devirtualizePrototypeMethods = false;
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy18 = com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC;
        compilerOptions15.propertyRenaming = propertyRenamingPolicy18;
        boolean boolean20 = compilerOptions15.recordFunctionInformation;
        compilerOptions15.enableExternExports(false);
        com.google.javascript.jscomp.CheckLevel checkLevel23 = compilerOptions15.checkUnreachableCode;
        compilerOptions0.checkRequires = checkLevel23;
        java.lang.String str25 = com.google.javascript.rhino.ScriptRuntime.toString((java.lang.Object) compilerOptions0);
        compilerOptions0.appNameStr = "typeof";
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy3 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC + "'", propertyRenamingPolicy3.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(byteArray11);
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy18 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC + "'", propertyRenamingPolicy18.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC));
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + checkLevel23 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel23.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        int int0 = com.google.javascript.rhino.Context.FEATURE_RESERVED_KEYWORD_AS_IDENTIFIER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeDeadCode = false;
        compilerOptions0.inlineLocalVariables = true;
        boolean boolean5 = compilerOptions0.printInputDelimiter;
        com.google.javascript.jscomp.CompilerOptions compilerOptions6 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CodingConvention codingConvention7 = compilerOptions6.getCodingConvention();
        compilerOptions6.computeFunctionSideEffects = true;
        com.google.javascript.jscomp.CheckLevel checkLevel10 = compilerOptions6.checkRequires;
        compilerOptions0.checkProvides = checkLevel10;
        boolean boolean12 = compilerOptions0.deadAssignmentElimination;
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(codingConvention7);
        org.junit.Assert.assertTrue("'" + checkLevel10 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel10.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        int int0 = com.google.javascript.rhino.Node.SPECIALCALL_EVAL;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        boolean boolean5 = node4.hasMoreThanOneChild();
        node4.setLineno(0);
        com.google.javascript.rhino.Node node8 = node4.cloneTree();
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        node13.removeProp((int) (short) 1);
        com.google.javascript.rhino.Node node21 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        boolean boolean22 = node21.hasMoreThanOneChild();
        node21.setLineno(0);
        boolean boolean25 = node21.hasOneChild();
        com.google.javascript.rhino.jstype.JSType jSType26 = node21.getJSType();
        com.google.javascript.rhino.Node node31 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        node31.removeProp((int) (short) 1);
        com.google.javascript.rhino.Node[] nodeArray34 = new com.google.javascript.rhino.Node[] { node21, node31 };
        com.google.javascript.rhino.Node node37 = new com.google.javascript.rhino.Node((int) (byte) 10, nodeArray34, (int) '4', (int) (byte) -1);
        com.google.javascript.rhino.Node node38 = node13.copyInformationFromForTree(node37);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder39 = node37.new FileLevelJsDocBuilder();
        java.lang.String str43 = node37.toString(false, false, false);
        node4.addChildrenToBack(node37);
        boolean boolean45 = node37.wasEmptyNode();
        com.google.javascript.rhino.Node node50 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        com.google.javascript.rhino.JSDocInfo jSDocInfo51 = null;
        node50.setJSDocInfo(jSDocInfo51);
        boolean boolean53 = node37.isEquivalentTo(node50);
        node50.setCharno(45);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup56 = com.google.javascript.jscomp.DiagnosticGroups.STRICT_MODULE_DEP_CHECK;
        com.google.javascript.jscomp.CompilerOptions compilerOptions57 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions57.devirtualizePrototypeMethods = false;
        compilerOptions57.collapseProperties = false;
        com.google.javascript.jscomp.CheckLevel checkLevel62 = null;
        compilerOptions57.reportMissingOverride = checkLevel62;
        com.google.javascript.jscomp.CompilerOptions compilerOptions64 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions64.devirtualizePrototypeMethods = false;
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy67 = com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC;
        compilerOptions64.propertyRenaming = propertyRenamingPolicy67;
        boolean boolean69 = compilerOptions64.recordFunctionInformation;
        java.util.Set<java.lang.String> strSet70 = compilerOptions64.stripTypes;
        compilerOptions57.aliasableStrings = strSet70;
        java.lang.RuntimeException runtimeException72 = com.google.javascript.rhino.ScriptRuntime.undefWriteError((java.lang.Object) node50, (java.lang.Object) diagnosticGroup56, (java.lang.Object) strSet70);
        java.lang.String str73 = node50.getQualifiedName();
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNull(jSType26);
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertNotNull(nodeArray34);
        org.junit.Assert.assertNotNull(node38);
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "BITXOR" + "'", str43.equals("BITXOR"));
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(node50);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNotNull(diagnosticGroup56);
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy67 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC + "'", propertyRenamingPolicy67.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC));
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
        org.junit.Assert.assertNotNull(strSet70);
        org.junit.Assert.assertNotNull(runtimeException72);
        org.junit.Assert.assertNull(str73);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        com.google.javascript.jscomp.AbstractCompiler abstractCompiler0 = null;
        com.google.javascript.jscomp.NodeTraversal.Callback callback1 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal2 = new com.google.javascript.jscomp.NodeTraversal(abstractCompiler0, callback1);
        com.google.javascript.jscomp.Compiler compiler3 = nodeTraversal2.getCompiler();
        try {
            com.google.javascript.jscomp.CompilerInput compilerInput4 = nodeTraversal2.getInput();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(compiler3);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        com.google.javascript.rhino.EvaluatorException evaluatorException1 = new com.google.javascript.rhino.EvaluatorException("language version");
        evaluatorException1.initLineNumber((int) (byte) 1);
        evaluatorException1.initColumnNumber(38);
        java.lang.String str6 = evaluatorException1.details();
        try {
            evaluatorException1.initLineNumber(10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "language version" + "'", str6.equals("language version"));
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile1 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.CompilerInput compilerInput2 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile1);
        com.google.javascript.jscomp.CompilerInput compilerInput4 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile1, true);
        try {
            java.lang.String str5 = compilerInput4.getPathRelativeToClosureBase();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: null");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile1);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        try {
            java.lang.String str1 = com.google.javascript.rhino.ScriptRuntime.getMessage0("DiagnosticGroup<undefinedVars>: <unknown=160>");
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property DiagnosticGroup<undefinedVars>: <unknown=160>");
        } catch (java.lang.RuntimeException e) {
        }
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.jstype.FunctionType functionType1 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType2 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType3 = null;
        closureCodingConvention0.applySubclassRelationship(functionType1, functionType2, subclassType3);
        com.google.javascript.rhino.jstype.ObjectType objectType5 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType6 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType7 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType8 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType9 = null;
        closureCodingConvention0.applyDelegateRelationship(objectType5, objectType6, objectType7, functionType8, functionType9);
        java.util.Collection<com.google.javascript.jscomp.CodingConvention.AssertionFunctionSpec> assertionFunctionSpecCollection11 = closureCodingConvention0.getAssertionFunctions();
        java.lang.String str12 = closureCodingConvention0.getAbstractMethodName();
        boolean boolean14 = closureCodingConvention0.isValidEnumKey("BITXOR");
        com.google.javascript.jscomp.AbstractCompiler abstractCompiler15 = null;
        com.google.javascript.jscomp.NodeTraversal.Callback callback16 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal17 = new com.google.javascript.jscomp.NodeTraversal(abstractCompiler15, callback16);
        com.google.javascript.rhino.Node node18 = nodeTraversal17.getEnclosingFunction();
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        boolean boolean24 = node23.hasMoreThanOneChild();
        node23.setLineno(0);
        com.google.javascript.rhino.Node node27 = node23.cloneTree();
        com.google.javascript.rhino.Node node28 = node27.removeFirstChild();
        try {
            com.google.javascript.jscomp.CodingConvention.ObjectLiteralCast objectLiteralCast29 = closureCodingConvention0.getObjectLiteralCast(nodeTraversal17, node27);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(assertionFunctionSpecCollection11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "goog.abstractMethod" + "'", str12.equals("goog.abstractMethod"));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNull(node18);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(node27);
        org.junit.Assert.assertNull(node28);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        try {
            com.google.javascript.rhino.Context.reportWarning("goog.abstractMethod");
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: No Context associated with current Thread");
        } catch (java.lang.RuntimeException e) {
        }
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.devirtualizePrototypeMethods = false;
        compilerOptions0.groupVariableDeclarations = false;
        boolean boolean5 = compilerOptions0.crossModuleCodeMotion;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap6 = null;
        compilerOptions0.cssRenamingMap = cssRenamingMap6;
        byte[] byteArray8 = compilerOptions0.inputPropertyMapSerialized;
        com.google.javascript.jscomp.CompilerOptions compilerOptions9 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions9.devirtualizePrototypeMethods = false;
        boolean boolean12 = compilerOptions9.ambiguateProperties;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy13 = com.google.javascript.jscomp.VariableRenamingPolicy.UNSPECIFIED;
        compilerOptions9.variableRenaming = variableRenamingPolicy13;
        boolean boolean15 = compilerOptions9.gatherCssNames;
        com.google.javascript.jscomp.DiagnosticType diagnosticType16 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        com.google.javascript.jscomp.CheckLevel checkLevel17 = diagnosticType16.level;
        compilerOptions9.reportMissingOverride = checkLevel17;
        compilerOptions0.checkFunctions = checkLevel17;
        com.google.javascript.jscomp.SourceMap.DetailLevel detailLevel20 = compilerOptions0.sourceMapDetailLevel;
        com.google.javascript.jscomp.CodingConvention codingConvention21 = compilerOptions0.getCodingConvention();
        com.google.javascript.jscomp.CheckLevel checkLevel22 = com.google.javascript.jscomp.CheckLevel.OFF;
        compilerOptions0.brokenClosureRequiresLevel = checkLevel22;
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(byteArray8);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy13 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.UNSPECIFIED + "'", variableRenamingPolicy13.equals(com.google.javascript.jscomp.VariableRenamingPolicy.UNSPECIFIED));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(diagnosticType16);
        org.junit.Assert.assertTrue("'" + checkLevel17 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel17.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(detailLevel20);
        org.junit.Assert.assertNull(codingConvention21);
        org.junit.Assert.assertTrue("'" + checkLevel22 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel22.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.devirtualizePrototypeMethods = false;
        compilerOptions0.groupVariableDeclarations = false;
        boolean boolean5 = compilerOptions0.crossModuleCodeMotion;
        compilerOptions0.setTweakToStringLiteral("", "@IMPLEMENTATION.VERSION@");
        compilerOptions0.coalesceVariableNames = true;
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray2 = new com.google.javascript.jscomp.JSSourceFile[] {};
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray3 = new com.google.javascript.jscomp.JSSourceFile[] {};
        com.google.javascript.jscomp.CompilerOptions compilerOptions4 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions4.devirtualizePrototypeMethods = false;
        compilerOptions4.groupVariableDeclarations = false;
        boolean boolean9 = compilerOptions4.ideMode;
        compilerOptions4.setProcessObjectPropertyString(true);
        compilerOptions4.setDefineToBooleanLiteral("BITXOR", true);
        compilerOptions4.checkControlStructures = true;
        java.util.Map<java.lang.String, com.google.javascript.rhino.Node> strMap17 = compilerOptions4.getTweakReplacements();
        com.google.javascript.jscomp.Result result18 = compiler1.compile(jSSourceFileArray2, jSSourceFileArray3, compilerOptions4);
        com.google.javascript.jscomp.SourceExcerptProvider.SourceExcerpt sourceExcerpt19 = null;
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter20 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler1, sourceExcerpt19);
        lightweightMessageFormatter20.setColorize(false);
        org.junit.Assert.assertNotNull(jSSourceFileArray2);
        org.junit.Assert.assertNotNull(jSSourceFileArray3);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(strMap17);
        org.junit.Assert.assertNotNull(result18);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.devirtualizePrototypeMethods = false;
        compilerOptions0.groupVariableDeclarations = false;
        compilerOptions0.setChainCalls(true);
        java.lang.String str7 = compilerOptions0.syntheticBlockEndMarker;
        org.junit.Assert.assertNull(str7);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        try {
            com.google.javascript.rhino.EcmaError ecmaError2 = com.google.javascript.rhino.ScriptRuntime.typeError1("<unknown=160>", "typeof");
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property <unknown=160>");
        } catch (java.lang.RuntimeException e) {
        }
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        com.google.javascript.rhino.Context context0 = new com.google.javascript.rhino.Context();
        com.google.javascript.jscomp.AnonymousFunctionNamingPolicy anonymousFunctionNamingPolicy1 = com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.UNMAPPED;
        context0.removeThreadLocal((java.lang.Object) anonymousFunctionNamingPolicy1);
        boolean boolean3 = context0.isGeneratingDebug();
        com.google.javascript.jscomp.CompilerOptions compilerOptions4 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions4.devirtualizePrototypeMethods = false;
        java.util.Set<java.lang.String> strSet7 = compilerOptions4.stripNameSuffixes;
        boolean boolean8 = compilerOptions4.tightenTypes;
        java.lang.Object obj9 = context0.getThreadLocal((java.lang.Object) boolean8);
        org.junit.Assert.assertTrue("'" + anonymousFunctionNamingPolicy1 + "' != '" + com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.UNMAPPED + "'", anonymousFunctionNamingPolicy1.equals(com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.UNMAPPED));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(strSet7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNull(obj9);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray2 = new com.google.javascript.jscomp.JSSourceFile[] {};
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray3 = new com.google.javascript.jscomp.JSSourceFile[] {};
        com.google.javascript.jscomp.CompilerOptions compilerOptions4 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions4.devirtualizePrototypeMethods = false;
        compilerOptions4.groupVariableDeclarations = false;
        boolean boolean9 = compilerOptions4.ideMode;
        compilerOptions4.setProcessObjectPropertyString(true);
        compilerOptions4.setDefineToBooleanLiteral("BITXOR", true);
        compilerOptions4.checkControlStructures = true;
        java.util.Map<java.lang.String, com.google.javascript.rhino.Node> strMap17 = compilerOptions4.getTweakReplacements();
        com.google.javascript.jscomp.Result result18 = compiler1.compile(jSSourceFileArray2, jSSourceFileArray3, compilerOptions4);
        com.google.javascript.jscomp.SourceExcerptProvider.SourceExcerpt sourceExcerpt19 = null;
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter20 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler1, sourceExcerpt19);
        com.google.javascript.jscomp.DiagnosticType diagnosticType24 = com.google.javascript.jscomp.Compiler.MOTION_ITERATIONS_ERROR;
        java.lang.String[] strArray31 = new java.lang.String[] { "<unknown=160>", "<unknown=160>", "<unknown=160>", "<unknown=160>", "BITXOR", "DiagnosticGroup<undefinedVars>" };
        com.google.javascript.jscomp.JSError jSError32 = com.google.javascript.jscomp.JSError.make("BITXOR", 32, (int) (short) 100, diagnosticType24, strArray31);
        com.google.javascript.jscomp.DiagnosticType diagnosticType33 = jSError32.getType();
        try {
            java.lang.String str34 = lightweightMessageFormatter20.formatError(jSError32);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFileArray2);
        org.junit.Assert.assertNotNull(jSSourceFileArray3);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(strMap17);
        org.junit.Assert.assertNotNull(result18);
        org.junit.Assert.assertNotNull(diagnosticType24);
        org.junit.Assert.assertNotNull(strArray31);
        org.junit.Assert.assertNotNull(jSError32);
        org.junit.Assert.assertNotNull(diagnosticType33);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString("hi!", 100, 0);
        node3.putIntProp(27, 36);
        org.junit.Assert.assertNotNull(node3);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeUnusedLocalVars = false;
        compilerOptions0.crossModuleCodeMotion = false;
        compilerOptions0.specializeInitialModule = false;
        compilerOptions0.removeUnusedLocalVars = false;
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        com.google.javascript.rhino.Context context0 = new com.google.javascript.rhino.Context();
        com.google.javascript.jscomp.AnonymousFunctionNamingPolicy anonymousFunctionNamingPolicy1 = com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.UNMAPPED;
        context0.removeThreadLocal((java.lang.Object) anonymousFunctionNamingPolicy1);
        java.lang.String str3 = context0.getImplementationVersion();
        java.util.Locale locale4 = context0.getLocale();
        com.google.javascript.jscomp.SourceMap.Format format5 = com.google.javascript.jscomp.SourceMap.Format.LEGACY;
        try {
            context0.unseal((java.lang.Object) format5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + anonymousFunctionNamingPolicy1 + "' != '" + com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.UNMAPPED + "'", anonymousFunctionNamingPolicy1.equals(com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.UNMAPPED));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "@IMPLEMENTATION.VERSION@" + "'", str3.equals("@IMPLEMENTATION.VERSION@"));
        org.junit.Assert.assertNotNull(locale4);
        org.junit.Assert.assertNotNull(format5);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        int int0 = com.google.javascript.rhino.Context.FEATURE_TO_STRING_AS_SOURCE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newNumber((double) 'a', (int) (byte) 1, 0);
        node3.setIsSyntheticBlock(false);
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        com.google.javascript.rhino.JSDocInfo jSDocInfo12 = null;
        node11.setJSDocInfo(jSDocInfo12);
        java.lang.RuntimeException runtimeException15 = com.google.javascript.rhino.ScriptRuntime.undefReadError((java.lang.Object) node11, (java.lang.Object) 22);
        node11.detachChildren();
        java.lang.String[] strArray22 = new java.lang.String[] { "error reporter", "hi!", "BITXOR", "error reporter", "BITXOR" };
        java.util.LinkedHashSet<java.lang.String> strSet23 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean24 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet23, strArray22);
        node11.setDirectives((java.util.Set<java.lang.String>) strSet23);
        com.google.javascript.jscomp.AbstractCompiler abstractCompiler26 = null;
        com.google.javascript.jscomp.NodeTraversal.Callback callback27 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal28 = new com.google.javascript.jscomp.NodeTraversal(abstractCompiler26, callback27);
        com.google.javascript.rhino.Node node34 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        com.google.javascript.rhino.JSDocInfo jSDocInfo35 = null;
        node34.setJSDocInfo(jSDocInfo35);
        java.lang.RuntimeException runtimeException38 = com.google.javascript.rhino.ScriptRuntime.undefReadError((java.lang.Object) node34, (java.lang.Object) 22);
        node34.detachChildren();
        com.google.javascript.rhino.Node node40 = new com.google.javascript.rhino.Node((int) (short) 100, node34);
        com.google.javascript.jscomp.CompilerOptions compilerOptions41 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CodingConvention codingConvention42 = compilerOptions41.getCodingConvention();
        compilerOptions41.computeFunctionSideEffects = true;
        com.google.javascript.jscomp.CheckLevel checkLevel45 = compilerOptions41.checkRequires;
        com.google.javascript.jscomp.DiagnosticType diagnosticType46 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        com.google.javascript.jscomp.DiagnosticType diagnosticType50 = com.google.javascript.jscomp.Compiler.MOTION_ITERATIONS_ERROR;
        java.lang.String[] strArray57 = new java.lang.String[] { "<unknown=160>", "<unknown=160>", "<unknown=160>", "<unknown=160>", "BITXOR", "DiagnosticGroup<undefinedVars>" };
        com.google.javascript.jscomp.JSError jSError58 = com.google.javascript.jscomp.JSError.make("BITXOR", 32, (int) (short) 100, diagnosticType50, strArray57);
        com.google.javascript.jscomp.JSError jSError59 = nodeTraversal28.makeError(node40, checkLevel45, diagnosticType46, strArray57);
        com.google.javascript.rhino.Node node60 = node11.copyInformationFromForTree(node40);
        node3.putProp(42, (java.lang.Object) node60);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertNotNull(runtimeException15);
        org.junit.Assert.assertNotNull(strArray22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(node34);
        org.junit.Assert.assertNotNull(runtimeException38);
        org.junit.Assert.assertNull(codingConvention42);
        org.junit.Assert.assertTrue("'" + checkLevel45 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel45.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(diagnosticType46);
        org.junit.Assert.assertNotNull(diagnosticType50);
        org.junit.Assert.assertNotNull(strArray57);
        org.junit.Assert.assertNotNull(jSError58);
        org.junit.Assert.assertNotNull(jSError59);
        org.junit.Assert.assertNotNull(node60);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray2 = new com.google.javascript.jscomp.JSSourceFile[] {};
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray3 = new com.google.javascript.jscomp.JSSourceFile[] {};
        com.google.javascript.jscomp.CompilerOptions compilerOptions4 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions4.devirtualizePrototypeMethods = false;
        compilerOptions4.groupVariableDeclarations = false;
        boolean boolean9 = compilerOptions4.ideMode;
        compilerOptions4.setProcessObjectPropertyString(true);
        compilerOptions4.setDefineToBooleanLiteral("BITXOR", true);
        compilerOptions4.checkControlStructures = true;
        java.util.Map<java.lang.String, com.google.javascript.rhino.Node> strMap17 = compilerOptions4.getTweakReplacements();
        com.google.javascript.jscomp.Result result18 = compiler1.compile(jSSourceFileArray2, jSSourceFileArray3, compilerOptions4);
        com.google.javascript.jscomp.JSError[] jSErrorArray19 = compiler1.getErrors();
        com.google.javascript.rhino.Node node20 = compiler1.getRoot();
        com.google.javascript.jscomp.Result result21 = compiler1.getResult();
        org.junit.Assert.assertNotNull(jSSourceFileArray2);
        org.junit.Assert.assertNotNull(jSSourceFileArray3);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(strMap17);
        org.junit.Assert.assertNotNull(result18);
        org.junit.Assert.assertNotNull(jSErrorArray19);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNotNull(result21);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        int int0 = com.google.javascript.rhino.Node.CONTINUE_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.devirtualizePrototypeMethods = false;
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy3 = com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC;
        compilerOptions0.propertyRenaming = propertyRenamingPolicy3;
        compilerOptions0.disableRuntimeTypeCheck();
        boolean boolean6 = compilerOptions0.allowLegacyJsMessages;
        compilerOptions0.nameReferenceGraphPath = "null(ERROR)";
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy3 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC + "'", propertyRenamingPolicy3.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        com.google.javascript.jscomp.ErrorFormat errorFormat0 = com.google.javascript.jscomp.ErrorFormat.LEGACY;
        org.junit.Assert.assertNotNull(errorFormat0);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        java.io.InputStream inputStream1 = null;
        try {
            com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromInputStream("(Not declared as a constructor)", inputStream1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray2 = new com.google.javascript.jscomp.JSSourceFile[] {};
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray3 = new com.google.javascript.jscomp.JSSourceFile[] {};
        com.google.javascript.jscomp.CompilerOptions compilerOptions4 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions4.devirtualizePrototypeMethods = false;
        compilerOptions4.groupVariableDeclarations = false;
        boolean boolean9 = compilerOptions4.ideMode;
        compilerOptions4.setProcessObjectPropertyString(true);
        compilerOptions4.setDefineToBooleanLiteral("BITXOR", true);
        compilerOptions4.checkControlStructures = true;
        java.util.Map<java.lang.String, com.google.javascript.rhino.Node> strMap17 = compilerOptions4.getTweakReplacements();
        com.google.javascript.jscomp.Result result18 = compiler1.compile(jSSourceFileArray2, jSSourceFileArray3, compilerOptions4);
        com.google.javascript.jscomp.JSError[] jSErrorArray19 = compiler1.getErrors();
        com.google.javascript.rhino.Node node20 = compiler1.getRoot();
        com.google.javascript.jscomp.PassConfig passConfig21 = null;
        try {
            compiler1.setPassConfig(passConfig21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFileArray2);
        org.junit.Assert.assertNotNull(jSSourceFileArray3);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(strMap17);
        org.junit.Assert.assertNotNull(result18);
        org.junit.Assert.assertNotNull(jSErrorArray19);
        org.junit.Assert.assertNotNull(node20);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        boolean boolean5 = node4.hasMoreThanOneChild();
        node4.setLineno(0);
        int int8 = node4.getChildCount();
        java.lang.String[] strArray21 = new java.lang.String[] { "@IMPLEMENTATION.VERSION@", "goog.exportProperty", "DiagnosticGroup<undefinedVars>: <unknown=160>", "goog.exportProperty", "BITXOR", "JSC_OPTIMIZE_LOOP_ERROR", "<unknown=160>", "DiagnosticGroup<undefinedVars>: <unknown=160>", "DiagnosticGroup<undefinedVars>: <unknown=160>", "JSC_OPTIMIZE_LOOP_ERROR", "BITXOR", "<unknown=160>" };
        java.util.LinkedHashSet<java.lang.String> strSet22 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean23 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet22, strArray21);
        node4.setDirectives((java.util.Set<java.lang.String>) strSet22);
        com.google.javascript.rhino.Node node25 = null;
        try {
            com.google.javascript.rhino.Node node26 = node4.clonePropsFrom(node25);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Node has existing properties.");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(strArray21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.devirtualizePrototypeMethods = false;
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy3 = com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC;
        compilerOptions0.propertyRenaming = propertyRenamingPolicy3;
        java.lang.String str5 = compilerOptions0.unaliasableGlobals;
        compilerOptions0.setOutputCharset("language version");
        java.util.Set<java.lang.String> strSet8 = compilerOptions0.stripNamePrefixes;
        compilerOptions0.setTweakToStringLiteral("", "@IMPLEMENTATION.VERSION@");
        com.google.javascript.jscomp.CompilerOptions compilerOptions12 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CodingConvention codingConvention13 = compilerOptions12.getCodingConvention();
        compilerOptions12.computeFunctionSideEffects = true;
        byte[] byteArray16 = compilerOptions12.inputPropertyMapSerialized;
        com.google.javascript.jscomp.CompilerOptions compilerOptions17 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions17.removeUnusedLocalVars = false;
        compilerOptions17.crossModuleCodeMotion = false;
        compilerOptions17.ambiguateProperties = false;
        compilerOptions17.checkTypedPropertyCalls = true;
        java.lang.String str26 = compilerOptions17.syntheticBlockEndMarker;
        java.util.Set<java.lang.String> strSet27 = compilerOptions17.stripTypes;
        compilerOptions12.setIdGenerators(strSet27);
        compilerOptions0.stripTypePrefixes = strSet27;
        compilerOptions0.debugFunctionSideEffectsPath = "(Not declared as a constructor)";
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy3 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC + "'", propertyRenamingPolicy3.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC));
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertNotNull(strSet8);
        org.junit.Assert.assertNull(codingConvention13);
        org.junit.Assert.assertNull(byteArray16);
        org.junit.Assert.assertNull(str26);
        org.junit.Assert.assertNotNull(strSet27);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        com.google.javascript.rhino.EvaluatorException evaluatorException1 = new com.google.javascript.rhino.EvaluatorException("language version");
        java.lang.String str2 = evaluatorException1.details();
        int int3 = evaluatorException1.columnNumber();
        evaluatorException1.initLineSource("@IMPLEMENTATION.VERSION@");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "language version" + "'", str2.equals("language version"));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        node5.removeProp((int) (short) 1);
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        boolean boolean14 = node13.hasMoreThanOneChild();
        node13.setLineno(0);
        boolean boolean17 = node13.hasOneChild();
        com.google.javascript.rhino.jstype.JSType jSType18 = node13.getJSType();
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        node23.removeProp((int) (short) 1);
        com.google.javascript.rhino.Node[] nodeArray26 = new com.google.javascript.rhino.Node[] { node13, node23 };
        com.google.javascript.rhino.Node node29 = new com.google.javascript.rhino.Node((int) (byte) 10, nodeArray26, (int) '4', (int) (byte) -1);
        com.google.javascript.rhino.Node node30 = node5.copyInformationFromForTree(node29);
        com.google.javascript.rhino.Node node35 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        node35.setSourcePositionForTree(20);
        com.google.javascript.rhino.Node node42 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        boolean boolean43 = node42.hasMoreThanOneChild();
        node42.setLineno(0);
        com.google.javascript.rhino.Node node46 = node42.cloneTree();
        com.google.javascript.rhino.Node node51 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        com.google.javascript.rhino.JSDocInfo jSDocInfo52 = null;
        node51.setJSDocInfo(jSDocInfo52);
        java.lang.RuntimeException runtimeException55 = com.google.javascript.rhino.ScriptRuntime.undefReadError((java.lang.Object) node51, (java.lang.Object) 22);
        node51.detachChildren();
        int int57 = node51.getChildCount();
        com.google.javascript.rhino.Node node60 = new com.google.javascript.rhino.Node((int) (short) -1, node30, node35, node46, node51, 15, (int) (byte) 1);
        com.google.javascript.rhino.Node node61 = node35.getNext();
        node61.addSuppression("<No stack trace available>");
        node61.setIsSyntheticBlock(true);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNull(jSType18);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(nodeArray26);
        org.junit.Assert.assertNotNull(node30);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertNotNull(node42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(node46);
        org.junit.Assert.assertNotNull(node51);
        org.junit.Assert.assertNotNull(runtimeException55);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 0 + "'", int57 == 0);
        org.junit.Assert.assertNotNull(node61);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newString("goog.exportSymbol");
        boolean boolean2 = node1.isOptionalArg();
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        boolean boolean7 = node6.hasMoreThanOneChild();
        node6.setLineno(0);
        boolean boolean10 = node6.hasOneChild();
        com.google.javascript.rhino.jstype.JSType jSType11 = node6.getJSType();
        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        node16.removeProp((int) (short) 1);
        com.google.javascript.rhino.Node[] nodeArray19 = new com.google.javascript.rhino.Node[] { node6, node16 };
        com.google.javascript.rhino.Node node22 = new com.google.javascript.rhino.Node((int) (byte) 10, nodeArray19, (int) '4', (int) (byte) -1);
        node22.putBooleanProp(42, false);
        com.google.javascript.rhino.Node node30 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        boolean boolean31 = node30.hasMoreThanOneChild();
        node30.setLineno(0);
        com.google.javascript.rhino.Node node34 = node30.cloneTree();
        com.google.javascript.rhino.Node node39 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        node39.removeProp((int) (short) 1);
        com.google.javascript.rhino.Node node47 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        boolean boolean48 = node47.hasMoreThanOneChild();
        node47.setLineno(0);
        boolean boolean51 = node47.hasOneChild();
        com.google.javascript.rhino.jstype.JSType jSType52 = node47.getJSType();
        com.google.javascript.rhino.Node node57 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        node57.removeProp((int) (short) 1);
        com.google.javascript.rhino.Node[] nodeArray60 = new com.google.javascript.rhino.Node[] { node47, node57 };
        com.google.javascript.rhino.Node node63 = new com.google.javascript.rhino.Node((int) (byte) 10, nodeArray60, (int) '4', (int) (byte) -1);
        com.google.javascript.rhino.Node node64 = node39.copyInformationFromForTree(node63);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder65 = node63.new FileLevelJsDocBuilder();
        java.lang.String str69 = node63.toString(false, false, false);
        node30.addChildrenToBack(node63);
        boolean boolean71 = node63.wasEmptyNode();
        com.google.javascript.rhino.Node node76 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        com.google.javascript.rhino.JSDocInfo jSDocInfo77 = null;
        node76.setJSDocInfo(jSDocInfo77);
        boolean boolean79 = node63.isEquivalentTo(node76);
        com.google.javascript.rhino.Node node82 = new com.google.javascript.rhino.Node((int) (byte) 100, node22, node76, 38, 38);
        com.google.javascript.rhino.JSDocInfo jSDocInfo83 = null;
        node76.setJSDocInfo(jSDocInfo83);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNull(jSType11);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertNotNull(nodeArray19);
        org.junit.Assert.assertNotNull(node30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(node34);
        org.junit.Assert.assertNotNull(node39);
        org.junit.Assert.assertNotNull(node47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertNull(jSType52);
        org.junit.Assert.assertNotNull(node57);
        org.junit.Assert.assertNotNull(nodeArray60);
        org.junit.Assert.assertNotNull(node64);
        org.junit.Assert.assertTrue("'" + str69 + "' != '" + "BITXOR" + "'", str69.equals("BITXOR"));
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
        org.junit.Assert.assertNotNull(node76);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention1 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.jstype.FunctionType functionType2 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType3 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType4 = null;
        closureCodingConvention1.applySubclassRelationship(functionType2, functionType3, subclassType4);
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        boolean boolean11 = node10.hasMoreThanOneChild();
        node10.setLineno(0);
        com.google.javascript.rhino.Node node14 = node10.cloneTree();
        com.google.javascript.rhino.Node node15 = node14.removeFirstChild();
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        node20.removeProp((int) (short) 1);
        com.google.javascript.rhino.Node node28 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        boolean boolean29 = node28.hasMoreThanOneChild();
        node28.setLineno(0);
        boolean boolean32 = node28.hasOneChild();
        com.google.javascript.rhino.jstype.JSType jSType33 = node28.getJSType();
        com.google.javascript.rhino.Node node38 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        node38.removeProp((int) (short) 1);
        com.google.javascript.rhino.Node[] nodeArray41 = new com.google.javascript.rhino.Node[] { node28, node38 };
        com.google.javascript.rhino.Node node44 = new com.google.javascript.rhino.Node((int) (byte) 10, nodeArray41, (int) '4', (int) (byte) -1);
        com.google.javascript.rhino.Node node45 = node20.copyInformationFromForTree(node44);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder46 = node44.new FileLevelJsDocBuilder();
        java.lang.String str50 = node44.toString(false, false, false);
        boolean boolean51 = node44.isUnscopedQualifiedName();
        int int52 = node44.getLineno();
        java.lang.String str53 = closureCodingConvention1.extractClassNameIfProvide(node14, node44);
        com.google.javascript.rhino.Node node54 = new com.google.javascript.rhino.Node(22, node44);
        try {
            node44.setString("hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: BITXOR is not a string node");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNull(node15);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNull(jSType33);
        org.junit.Assert.assertNotNull(node38);
        org.junit.Assert.assertNotNull(nodeArray41);
        org.junit.Assert.assertNotNull(node45);
        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "BITXOR" + "'", str50.equals("BITXOR"));
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + (-1) + "'", int52 == (-1));
        org.junit.Assert.assertNull(str53);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        boolean boolean6 = node5.hasMoreThanOneChild();
        node5.setLineno(0);
        com.google.javascript.rhino.Node node9 = node5.cloneTree();
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        node14.removeProp((int) (short) 1);
        com.google.javascript.rhino.Node node22 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        boolean boolean23 = node22.hasMoreThanOneChild();
        node22.setLineno(0);
        boolean boolean26 = node22.hasOneChild();
        com.google.javascript.rhino.jstype.JSType jSType27 = node22.getJSType();
        com.google.javascript.rhino.Node node32 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        node32.removeProp((int) (short) 1);
        com.google.javascript.rhino.Node[] nodeArray35 = new com.google.javascript.rhino.Node[] { node22, node32 };
        com.google.javascript.rhino.Node node38 = new com.google.javascript.rhino.Node((int) (byte) 10, nodeArray35, (int) '4', (int) (byte) -1);
        com.google.javascript.rhino.Node node39 = node14.copyInformationFromForTree(node38);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder40 = node38.new FileLevelJsDocBuilder();
        java.lang.String str44 = node38.toString(false, false, false);
        node5.addChildrenToBack(node38);
        boolean boolean46 = node38.wasEmptyNode();
        com.google.javascript.rhino.Node node51 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        com.google.javascript.rhino.JSDocInfo jSDocInfo52 = null;
        node51.setJSDocInfo(jSDocInfo52);
        boolean boolean54 = node38.isEquivalentTo(node51);
        com.google.javascript.rhino.Node node57 = new com.google.javascript.rhino.Node(0, node51, 5, 0);
        node57.setType(4);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNull(jSType27);
        org.junit.Assert.assertNotNull(node32);
        org.junit.Assert.assertNotNull(nodeArray35);
        org.junit.Assert.assertNotNull(node39);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "BITXOR" + "'", str44.equals("BITXOR"));
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(node51);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.devirtualizePrototypeMethods = false;
        compilerOptions0.groupVariableDeclarations = false;
        java.util.Set<java.lang.String> strSet5 = compilerOptions0.stripNamePrefixes;
        boolean boolean6 = compilerOptions0.decomposeExpressions;
        boolean boolean7 = compilerOptions0.optimizeArgumentsArray;
        org.junit.Assert.assertNotNull(strSet5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        boolean boolean6 = node5.hasMoreThanOneChild();
        node5.setLineno(0);
        boolean boolean9 = node5.hasOneChild();
        com.google.javascript.rhino.jstype.JSType jSType10 = node5.getJSType();
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        node15.removeProp((int) (short) 1);
        com.google.javascript.rhino.Node[] nodeArray18 = new com.google.javascript.rhino.Node[] { node5, node15 };
        com.google.javascript.rhino.Node node21 = new com.google.javascript.rhino.Node((int) (byte) 10, nodeArray18, (int) '4', (int) (byte) -1);
        node21.putBooleanProp(42, false);
        int int25 = node21.getLineno();
        com.google.javascript.rhino.Node node26 = null;
        try {
            node21.addChildrenToBack(node26);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(jSType10);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertNotNull(nodeArray18);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-1) + "'", int25 == (-1));
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        try {
            com.google.javascript.rhino.Context.checkOptimizationLevel((int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Optimization level outside [-1..9]: 100");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        java.util.logging.Logger logger0 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager1 = new com.google.javascript.jscomp.LoggerErrorManager(logger0);
        com.google.javascript.jscomp.JSError[] jSErrorArray2 = loggerErrorManager1.getWarnings();
        com.google.javascript.jscomp.Compiler compiler3 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager1);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile5 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        java.lang.String str6 = jSSourceFile5.getOriginalPath();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile8 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.CompilerInput compilerInput9 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile8);
        com.google.javascript.jscomp.CompilerInput compilerInput11 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile8, true);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile13 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.CompilerInput compilerInput14 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile13);
        com.google.javascript.jscomp.CompilerInput compilerInput16 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile13, true);
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray17 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile5, jSSourceFile8, jSSourceFile13 };
        java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList18 = new java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile>();
        boolean boolean19 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList18, jSSourceFileArray17);
        java.io.PrintStream printStream20 = null;
        com.google.javascript.jscomp.Compiler compiler21 = new com.google.javascript.jscomp.Compiler(printStream20);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile23 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        jSSourceFile23.clearCachedSource();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile26 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile28 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        jSSourceFile28.clearCachedSource();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile31 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.CompilerInput compilerInput32 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile31);
        boolean boolean33 = compilerInput32.isExtern();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile35 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        java.lang.String str36 = jSSourceFile35.getOriginalPath();
        compilerInput32.setSourceFile((com.google.javascript.jscomp.SourceFile) jSSourceFile35);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile39 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.CompilerInput compilerInput40 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile39);
        com.google.javascript.jscomp.CompilerInput compilerInput42 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile39, true);
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray43 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile23, jSSourceFile26, jSSourceFile28, jSSourceFile35, jSSourceFile39 };
        java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList44 = new java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile>();
        boolean boolean45 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList44, jSSourceFileArray43);
        com.google.javascript.jscomp.JSModule[] jSModuleArray46 = new com.google.javascript.jscomp.JSModule[] {};
        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList47 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
        boolean boolean48 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList47, jSModuleArray46);
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph49 = new com.google.javascript.jscomp.JSModuleGraph((java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList47);
        com.google.javascript.jscomp.CompilerOptions compilerOptions50 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions50.devirtualizePrototypeMethods = false;
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy53 = com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC;
        compilerOptions50.propertyRenaming = propertyRenamingPolicy53;
        boolean boolean55 = compilerOptions50.recordFunctionInformation;
        compilerOptions50.enableExternExports(false);
        byte[] byteArray61 = new byte[] { (byte) -1, (byte) 1, (byte) 10 };
        compilerOptions50.inputVariableMapSerialized = byteArray61;
        compilerOptions50.convertToDottedProperties = true;
        compilerOptions50.instrumentForCoverageOnly = true;
        compilerOptions50.nameReferenceReportPath = "BITXOR";
        com.google.javascript.jscomp.Result result69 = compiler21.compileModules((java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList44, (java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList47, compilerOptions50);
        com.google.javascript.jscomp.CompilerOptions compilerOptions70 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions70.devirtualizePrototypeMethods = false;
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy73 = com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC;
        compilerOptions70.propertyRenaming = propertyRenamingPolicy73;
        boolean boolean75 = compilerOptions70.recordFunctionInformation;
        compilerOptions70.optimizeArgumentsArray = false;
        com.google.javascript.jscomp.DiagnosticType diagnosticType78 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        com.google.javascript.jscomp.CheckLevel checkLevel79 = diagnosticType78.defaultLevel;
        compilerOptions70.checkMethods = checkLevel79;
        com.google.javascript.jscomp.CheckLevel checkLevel81 = compilerOptions70.checkRequires;
        compilerOptions70.setRewriteNewDateGoogNow(true);
        boolean boolean84 = compilerOptions70.checkUnusedPropertiesEarly;
        compiler3.init((java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList18, (java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList44, compilerOptions70);
        try {
            compiler3.processDefines();
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: INTERNAL COMPILER ERROR.\nPlease report this problem.\nnull");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(jSErrorArray2);
        org.junit.Assert.assertNotNull(jSSourceFile5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertNotNull(jSSourceFile8);
        org.junit.Assert.assertNotNull(jSSourceFile13);
        org.junit.Assert.assertNotNull(jSSourceFileArray17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(jSSourceFile23);
        org.junit.Assert.assertNotNull(jSSourceFile26);
        org.junit.Assert.assertNotNull(jSSourceFile28);
        org.junit.Assert.assertNotNull(jSSourceFile31);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(jSSourceFile35);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "" + "'", str36.equals(""));
        org.junit.Assert.assertNotNull(jSSourceFile39);
        org.junit.Assert.assertNotNull(jSSourceFileArray43);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
        org.junit.Assert.assertNotNull(jSModuleArray46);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy53 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC + "'", propertyRenamingPolicy53.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC));
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNotNull(byteArray61);
        org.junit.Assert.assertNotNull(result69);
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy73 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC + "'", propertyRenamingPolicy73.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC));
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
        org.junit.Assert.assertNotNull(diagnosticType78);
        org.junit.Assert.assertTrue("'" + checkLevel79 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel79.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + checkLevel81 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel81.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean84 + "' != '" + false + "'", boolean84 == false);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.debugFunctionSideEffectsPath = "";
        compilerOptions0.collapseVariableDeclarations = true;
        com.google.javascript.jscomp.ErrorFormat errorFormat5 = com.google.javascript.jscomp.ErrorFormat.MULTILINE;
        compilerOptions0.errorFormat = errorFormat5;
        org.junit.Assert.assertNotNull(errorFormat5);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        node5.removeProp((int) (short) 1);
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        boolean boolean14 = node13.hasMoreThanOneChild();
        node13.setLineno(0);
        boolean boolean17 = node13.hasOneChild();
        com.google.javascript.rhino.jstype.JSType jSType18 = node13.getJSType();
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        node23.removeProp((int) (short) 1);
        com.google.javascript.rhino.Node[] nodeArray26 = new com.google.javascript.rhino.Node[] { node13, node23 };
        com.google.javascript.rhino.Node node29 = new com.google.javascript.rhino.Node((int) (byte) 10, nodeArray26, (int) '4', (int) (byte) -1);
        com.google.javascript.rhino.Node node30 = node5.copyInformationFromForTree(node29);
        com.google.javascript.rhino.Node node35 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        node35.setSourcePositionForTree(20);
        com.google.javascript.rhino.Node node42 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        boolean boolean43 = node42.hasMoreThanOneChild();
        node42.setLineno(0);
        com.google.javascript.rhino.Node node46 = node42.cloneTree();
        com.google.javascript.rhino.Node node51 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        com.google.javascript.rhino.JSDocInfo jSDocInfo52 = null;
        node51.setJSDocInfo(jSDocInfo52);
        java.lang.RuntimeException runtimeException55 = com.google.javascript.rhino.ScriptRuntime.undefReadError((java.lang.Object) node51, (java.lang.Object) 22);
        node51.detachChildren();
        int int57 = node51.getChildCount();
        com.google.javascript.rhino.Node node60 = new com.google.javascript.rhino.Node((int) (short) -1, node30, node35, node46, node51, 15, (int) (byte) 1);
        com.google.javascript.rhino.jstype.JSType jSType61 = node60.getJSType();
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNull(jSType18);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(nodeArray26);
        org.junit.Assert.assertNotNull(node30);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertNotNull(node42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(node46);
        org.junit.Assert.assertNotNull(node51);
        org.junit.Assert.assertNotNull(runtimeException55);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 0 + "'", int57 == 0);
        org.junit.Assert.assertNull(jSType61);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeUnusedLocalVars = false;
        compilerOptions0.crossModuleCodeMotion = false;
        compilerOptions0.ambiguateProperties = false;
        com.google.javascript.jscomp.CheckLevel checkLevel7 = compilerOptions0.checkMethods;
        boolean boolean8 = compilerOptions0.allowLegacyJsMessages;
        org.junit.Assert.assertTrue("'" + checkLevel7 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel7.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        com.google.javascript.rhino.EvaluatorException evaluatorException1 = new com.google.javascript.rhino.EvaluatorException("null(ERROR)");
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        com.google.javascript.jscomp.CompilerOptions compilerOptions3 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions3.devirtualizePrototypeMethods = false;
        compilerOptions3.groupVariableDeclarations = false;
        java.util.Set<java.lang.String> strSet8 = compilerOptions3.stripNamePrefixes;
        java.lang.String str9 = compilerOptions3.syntheticBlockEndMarker;
        boolean boolean10 = compilerOptions3.inlineFunctions;
        com.google.javascript.jscomp.CheckLevel checkLevel11 = compilerOptions3.checkMissingReturn;
        com.google.javascript.jscomp.DiagnosticType diagnosticType12 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray16 = new java.lang.String[] { "BITXOR", "hi!", "Not declared as a constructor" };
        com.google.javascript.jscomp.JSError jSError17 = com.google.javascript.jscomp.JSError.make("BITXOR", 0, 35, checkLevel11, diagnosticType12, strArray16);
        org.junit.Assert.assertNotNull(strSet8);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + checkLevel11 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel11.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(diagnosticType12);
        org.junit.Assert.assertNotNull(strArray16);
        org.junit.Assert.assertNotNull(jSError17);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        com.google.javascript.rhino.Context context0 = new com.google.javascript.rhino.Context();
        boolean boolean1 = context0.isGeneratingDebug();
        context0.addActivationName("Not declared as a constructor");
        com.google.javascript.rhino.ErrorReporter errorReporter4 = null;
        try {
            com.google.javascript.rhino.ErrorReporter errorReporter5 = context0.setErrorReporter(errorReporter4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.devirtualizePrototypeMethods = false;
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy3 = com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC;
        compilerOptions0.propertyRenaming = propertyRenamingPolicy3;
        boolean boolean5 = compilerOptions0.recordFunctionInformation;
        compilerOptions0.optimizeArgumentsArray = false;
        com.google.javascript.jscomp.DiagnosticType diagnosticType8 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        com.google.javascript.jscomp.CheckLevel checkLevel9 = diagnosticType8.defaultLevel;
        compilerOptions0.checkMethods = checkLevel9;
        com.google.javascript.jscomp.CheckLevel checkLevel11 = compilerOptions0.checkRequires;
        compilerOptions0.setRewriteNewDateGoogNow(true);
        compilerOptions0.skipAllCompilerPasses();
        compilerOptions0.renamePrefix = "Not declared as a constructor";
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy3 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC + "'", propertyRenamingPolicy3.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(diagnosticType8);
        org.junit.Assert.assertTrue("'" + checkLevel9 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel9.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + checkLevel11 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel11.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.devirtualizePrototypeMethods = false;
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy3 = com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC;
        compilerOptions0.propertyRenaming = propertyRenamingPolicy3;
        boolean boolean5 = compilerOptions0.recordFunctionInformation;
        compilerOptions0.optimizeArgumentsArray = false;
        boolean boolean8 = compilerOptions0.rewriteFunctionExpressions;
        compilerOptions0.sourceMapOutputPath = "BITXOR";
        compilerOptions0.enableExternExports(true);
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy3 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC + "'", propertyRenamingPolicy3.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        com.google.javascript.jscomp.mozilla.rhino.ast.AstRoot astRoot0 = null;
        com.google.javascript.jscomp.parsing.Config.LanguageMode languageMode4 = com.google.javascript.jscomp.parsing.Config.LanguageMode.ECMASCRIPT3;
        com.google.javascript.jscomp.parsing.Config config6 = com.google.javascript.jscomp.parsing.ParserRunner.createConfig(true, languageMode4, false);
        com.google.javascript.jscomp.parsing.Config config8 = com.google.javascript.jscomp.parsing.ParserRunner.createConfig(false, languageMode4, true);
        com.google.javascript.jscomp.mozilla.rhino.ErrorReporter errorReporter9 = null;
        try {
            com.google.javascript.rhino.Node node10 = com.google.javascript.jscomp.parsing.IRFactory.transformTree(astRoot0, "@IMPLEMENTATION.VERSION@", config8, errorReporter9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + languageMode4 + "' != '" + com.google.javascript.jscomp.parsing.Config.LanguageMode.ECMASCRIPT3 + "'", languageMode4.equals(com.google.javascript.jscomp.parsing.Config.LanguageMode.ECMASCRIPT3));
        org.junit.Assert.assertNotNull(config6);
        org.junit.Assert.assertNotNull(config8);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.devirtualizePrototypeMethods = false;
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy3 = com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC;
        compilerOptions0.propertyRenaming = propertyRenamingPolicy3;
        boolean boolean5 = compilerOptions0.recordFunctionInformation;
        compilerOptions0.optimizeArgumentsArray = false;
        com.google.javascript.jscomp.DiagnosticType diagnosticType8 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        com.google.javascript.jscomp.CheckLevel checkLevel9 = diagnosticType8.defaultLevel;
        compilerOptions0.checkMethods = checkLevel9;
        com.google.javascript.jscomp.CompilerOptions.AliasTransformationHandler aliasTransformationHandler11 = compilerOptions0.getAliasTransformationHandler();
        boolean boolean12 = compilerOptions0.devirtualizePrototypeMethods;
        java.lang.String str13 = compilerOptions0.renamePrefix;
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy3 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC + "'", propertyRenamingPolicy3.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(diagnosticType8);
        org.junit.Assert.assertTrue("'" + checkLevel9 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel9.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(aliasTransformationHandler11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNull(str13);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString(1, "language version", (int) (short) 10, (int) (byte) 100);
        try {
            node4.setDouble((double) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: EOL language version 10 is not a string node");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(node4);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.devirtualizePrototypeMethods = false;
        compilerOptions0.groupVariableDeclarations = false;
        boolean boolean5 = compilerOptions0.crossModuleCodeMotion;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap6 = null;
        compilerOptions0.cssRenamingMap = cssRenamingMap6;
        byte[] byteArray8 = compilerOptions0.inputPropertyMapSerialized;
        boolean boolean9 = compilerOptions0.generateExports;
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(byteArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.devirtualizePrototypeMethods = false;
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy3 = com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC;
        compilerOptions0.propertyRenaming = propertyRenamingPolicy3;
        java.lang.String str5 = compilerOptions0.unaliasableGlobals;
        compilerOptions0.setOutputCharset("language version");
        java.util.Set<java.lang.String> strSet8 = compilerOptions0.stripNamePrefixes;
        compilerOptions0.flowSensitiveInlineVariables = true;
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy3 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC + "'", propertyRenamingPolicy3.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC));
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertNotNull(strSet8);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.jstype.FunctionType functionType1 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType2 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType3 = null;
        closureCodingConvention0.applySubclassRelationship(functionType1, functionType2, subclassType3);
        boolean boolean6 = closureCodingConvention0.isSuperClassReference("");
        java.lang.String str7 = closureCodingConvention0.getAbstractMethodName();
        java.lang.String str8 = closureCodingConvention0.getExportPropertyFunction();
        java.lang.String str9 = closureCodingConvention0.getDelegateSuperclassName();
        com.google.javascript.rhino.jstype.FunctionType functionType10 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType11 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType12 = null;
        try {
            closureCodingConvention0.applySingletonGetter(functionType10, functionType11, objectType12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "goog.abstractMethod" + "'", str7.equals("goog.abstractMethod"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "goog.exportProperty" + "'", str8.equals("goog.exportProperty"));
        org.junit.Assert.assertNull(str9);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        java.io.Reader reader1 = null;
        try {
            com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromReader("(goog.exportSymbol)", reader1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.jstype.FunctionType functionType1 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType2 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType3 = null;
        closureCodingConvention0.applySubclassRelationship(functionType1, functionType2, subclassType3);
        com.google.javascript.rhino.jstype.ObjectType objectType5 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType6 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType7 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType8 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType9 = null;
        closureCodingConvention0.applyDelegateRelationship(objectType5, objectType6, objectType7, functionType8, functionType9);
        java.util.Collection<com.google.javascript.jscomp.CodingConvention.AssertionFunctionSpec> assertionFunctionSpecCollection11 = closureCodingConvention0.getAssertionFunctions();
        java.lang.String str12 = closureCodingConvention0.getGlobalObject();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry13 = null;
        com.google.javascript.jscomp.Scope scope14 = null;
        java.util.List<com.google.javascript.rhino.jstype.ObjectType> objectTypeList15 = null;
        closureCodingConvention0.defineDelegateProxyPrototypeProperties(jSTypeRegistry13, scope14, objectTypeList15);
        org.junit.Assert.assertNotNull(assertionFunctionSpecCollection11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "goog.global" + "'", str12.equals("goog.global"));
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        node4.removeProp((int) (short) 1);
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        boolean boolean13 = node12.hasMoreThanOneChild();
        node12.setLineno(0);
        boolean boolean16 = node12.hasOneChild();
        com.google.javascript.rhino.jstype.JSType jSType17 = node12.getJSType();
        com.google.javascript.rhino.Node node22 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        node22.removeProp((int) (short) 1);
        com.google.javascript.rhino.Node[] nodeArray25 = new com.google.javascript.rhino.Node[] { node12, node22 };
        com.google.javascript.rhino.Node node28 = new com.google.javascript.rhino.Node((int) (byte) 10, nodeArray25, (int) '4', (int) (byte) -1);
        com.google.javascript.rhino.Node node29 = node4.copyInformationFromForTree(node28);
        boolean boolean30 = node4.hasChildren();
        java.lang.String str31 = node4.getString();
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder32 = node4.getJsDocBuilderForNode();
        fileLevelJsDocBuilder32.append("Not declared as a constructor");
        fileLevelJsDocBuilder32.append("@IMPLEMENTATION.VERSION@");
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNull(jSType17);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertNotNull(nodeArray25);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "" + "'", str31.equals(""));
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder32);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        int int0 = com.google.javascript.rhino.Node.IS_VAR_ARGS_PARAM;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 44 + "'", int0 == 44);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.jstype.FunctionType functionType1 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType2 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType3 = null;
        closureCodingConvention0.applySubclassRelationship(functionType1, functionType2, subclassType3);
        com.google.javascript.rhino.jstype.ObjectType objectType5 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType6 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType7 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType8 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType9 = null;
        closureCodingConvention0.applyDelegateRelationship(objectType5, objectType6, objectType7, functionType8, functionType9);
        java.util.Collection<com.google.javascript.jscomp.CodingConvention.AssertionFunctionSpec> assertionFunctionSpecCollection11 = closureCodingConvention0.getAssertionFunctions();
        java.lang.String str12 = closureCodingConvention0.getAbstractMethodName();
        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.Node.newNumber((double) 'a', (int) (byte) 1, 0);
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable17 = node16.siblings();
        boolean boolean18 = closureCodingConvention0.isVarArgsParameter(node16);
        com.google.javascript.rhino.jstype.FunctionType functionType19 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType20 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType21 = null;
        try {
            closureCodingConvention0.applySingletonGetter(functionType19, functionType20, objectType21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(assertionFunctionSpecCollection11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "goog.abstractMethod" + "'", str12.equals("goog.abstractMethod"));
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertNotNull(nodeIterable17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        int int0 = com.google.javascript.rhino.Node.TYPE_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 17 + "'", int0 == 17);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        try {
            com.google.javascript.rhino.Context.reportWarning("DiagnosticGroup<typeInvalidation>", "goog.exportSymbol", 44, "", 14);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: No Context associated with current Thread");
        } catch (java.lang.RuntimeException e) {
        }
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        java.util.logging.Logger logger0 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager1 = new com.google.javascript.jscomp.LoggerErrorManager(logger0);
        com.google.javascript.jscomp.JSError[] jSErrorArray2 = loggerErrorManager1.getWarnings();
        com.google.javascript.jscomp.Compiler compiler3 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager1);
        try {
            com.google.javascript.jscomp.CompilerInput compilerInput5 = compiler3.getInput("<No stack trace available>");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jSErrorArray2);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        com.google.javascript.jscomp.JSModule[] jSModuleArray0 = new com.google.javascript.jscomp.JSModule[] {};
        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList1 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList1, jSModuleArray0);
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph3 = new com.google.javascript.jscomp.JSModuleGraph((java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList1);
        com.google.javascript.jscomp.JSModule jSModule4 = null;
        com.google.javascript.jscomp.JSModule jSModule5 = null;
        com.google.javascript.jscomp.JSModule jSModule6 = jSModuleGraph3.getDeepestCommonDependencyInclusive(jSModule4, jSModule5);
        jSModuleGraph3.coalesceDuplicateFiles();
        com.google.javascript.jscomp.JSModule jSModule8 = null;
        com.google.javascript.jscomp.JSModule jSModule9 = null;
        try {
            boolean boolean10 = jSModuleGraph3.dependsOn(jSModule8, jSModule9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jSModuleArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(jSModule6);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        com.google.javascript.jscomp.CheckLevel checkLevel0 = com.google.javascript.jscomp.CheckLevel.ERROR;
        org.junit.Assert.assertTrue("'" + checkLevel0 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel0.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        com.google.javascript.rhino.Node node1 = new com.google.javascript.rhino.Node((-1));
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        com.google.javascript.rhino.EvaluatorException evaluatorException1 = new com.google.javascript.rhino.EvaluatorException("goog.exportProperty");
        java.lang.String str2 = evaluatorException1.getScriptStackTrace();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "<No stack trace available>" + "'", str2.equals("<No stack trace available>"));
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.jstype.FunctionType functionType1 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType2 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType3 = null;
        closureCodingConvention0.applySubclassRelationship(functionType1, functionType2, subclassType3);
        boolean boolean6 = closureCodingConvention0.isSuperClassReference("");
        java.lang.String str7 = closureCodingConvention0.getAbstractMethodName();
        java.lang.String str8 = closureCodingConvention0.getExportPropertyFunction();
        java.lang.String str9 = closureCodingConvention0.getDelegateSuperclassName();
        boolean boolean11 = closureCodingConvention0.isConstant("JSC_OPTIMIZE_LOOP_ERROR");
        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        boolean boolean17 = node16.hasMoreThanOneChild();
        node16.setLineno(0);
        com.google.javascript.rhino.Node node20 = node16.cloneTree();
        com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        node25.removeProp((int) (short) 1);
        com.google.javascript.rhino.Node node33 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        boolean boolean34 = node33.hasMoreThanOneChild();
        node33.setLineno(0);
        boolean boolean37 = node33.hasOneChild();
        com.google.javascript.rhino.jstype.JSType jSType38 = node33.getJSType();
        com.google.javascript.rhino.Node node43 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        node43.removeProp((int) (short) 1);
        com.google.javascript.rhino.Node[] nodeArray46 = new com.google.javascript.rhino.Node[] { node33, node43 };
        com.google.javascript.rhino.Node node49 = new com.google.javascript.rhino.Node((int) (byte) 10, nodeArray46, (int) '4', (int) (byte) -1);
        com.google.javascript.rhino.Node node50 = node25.copyInformationFromForTree(node49);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder51 = node49.new FileLevelJsDocBuilder();
        java.lang.String str55 = node49.toString(false, false, false);
        node16.addChildrenToBack(node49);
        boolean boolean57 = node49.wasEmptyNode();
        com.google.javascript.rhino.Node node62 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        com.google.javascript.rhino.JSDocInfo jSDocInfo63 = null;
        node62.setJSDocInfo(jSDocInfo63);
        boolean boolean65 = node49.isEquivalentTo(node62);
        int int67 = node62.getIntProp(26);
        try {
            com.google.javascript.jscomp.CodingConvention.SubclassRelationship subclassRelationship68 = closureCodingConvention0.getClassesDefinedByCall(node62);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "goog.abstractMethod" + "'", str7.equals("goog.abstractMethod"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "goog.exportProperty" + "'", str8.equals("goog.exportProperty"));
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNotNull(node33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNull(jSType38);
        org.junit.Assert.assertNotNull(node43);
        org.junit.Assert.assertNotNull(nodeArray46);
        org.junit.Assert.assertNotNull(node50);
        org.junit.Assert.assertTrue("'" + str55 + "' != '" + "BITXOR" + "'", str55.equals("BITXOR"));
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertNotNull(node62);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 0 + "'", int67 == 0);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.devirtualizePrototypeMethods = false;
        compilerOptions0.groupVariableDeclarations = false;
        boolean boolean5 = compilerOptions0.crossModuleCodeMotion;
        compilerOptions0.setManageClosureDependencies(true);
        compilerOptions0.inlineVariables = false;
        compilerOptions0.optimizeReturns = true;
        compilerOptions0.locale = "<unknown=160>";
        java.lang.String str14 = compilerOptions0.sourceMapOutputPath;
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(str14);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        node4.removeProp((int) (short) 1);
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        boolean boolean13 = node12.hasMoreThanOneChild();
        node12.setLineno(0);
        boolean boolean16 = node12.hasOneChild();
        com.google.javascript.rhino.jstype.JSType jSType17 = node12.getJSType();
        com.google.javascript.rhino.Node node22 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        node22.removeProp((int) (short) 1);
        com.google.javascript.rhino.Node[] nodeArray25 = new com.google.javascript.rhino.Node[] { node12, node22 };
        com.google.javascript.rhino.Node node28 = new com.google.javascript.rhino.Node((int) (byte) 10, nodeArray25, (int) '4', (int) (byte) -1);
        com.google.javascript.rhino.Node node29 = node4.copyInformationFromForTree(node28);
        boolean boolean30 = node4.hasChildren();
        java.util.Collection<com.google.javascript.rhino.Node> nodeCollection31 = com.google.javascript.jscomp.NodeUtil.getVarsDeclaredInBranch(node4);
        boolean boolean32 = node4.wasEmptyNode();
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNull(jSType17);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertNotNull(nodeArray25);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(nodeCollection31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString((int) (byte) 10, "hi!", 37, (-1));
        boolean boolean5 = node4.isQualifiedName();
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        com.google.javascript.jscomp.AbstractCompiler abstractCompiler0 = null;
        com.google.javascript.jscomp.NodeTraversal.Callback callback1 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal2 = new com.google.javascript.jscomp.NodeTraversal(abstractCompiler0, callback1);
        com.google.javascript.jscomp.Scope scope3 = nodeTraversal2.getScope();
        int int4 = nodeTraversal2.getLineNumber();
        org.junit.Assert.assertNull(scope3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.devirtualizePrototypeMethods = false;
        compilerOptions0.groupVariableDeclarations = false;
        boolean boolean5 = compilerOptions0.crossModuleCodeMotion;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap6 = null;
        compilerOptions0.cssRenamingMap = cssRenamingMap6;
        boolean boolean8 = compilerOptions0.gatherCssNames;
        com.google.javascript.jscomp.ErrorFormat errorFormat9 = compilerOptions0.errorFormat;
        boolean boolean10 = compilerOptions0.collapseVariableDeclarations;
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(errorFormat9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

//    @Test
//    public void test341() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test341");
//        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = null;
//        com.google.javascript.jscomp.CompilerOptions compilerOptions1 = new com.google.javascript.jscomp.CompilerOptions();
//        compilerOptions1.devirtualizePrototypeMethods = false;
//        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy4 = com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC;
//        compilerOptions1.propertyRenaming = propertyRenamingPolicy4;
//        boolean boolean6 = compilerOptions1.recordFunctionInformation;
//        compilerOptions1.optimizeArgumentsArray = false;
//        com.google.javascript.jscomp.DiagnosticType diagnosticType9 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
//        com.google.javascript.jscomp.CheckLevel checkLevel10 = diagnosticType9.defaultLevel;
//        compilerOptions1.checkMethods = checkLevel10;
//        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard12 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup0, checkLevel10);
//        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup13 = null;
//        com.google.javascript.jscomp.CompilerOptions compilerOptions14 = new com.google.javascript.jscomp.CompilerOptions();
//        compilerOptions14.devirtualizePrototypeMethods = false;
//        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy17 = com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC;
//        compilerOptions14.propertyRenaming = propertyRenamingPolicy17;
//        boolean boolean19 = compilerOptions14.recordFunctionInformation;
//        compilerOptions14.optimizeArgumentsArray = false;
//        com.google.javascript.jscomp.DiagnosticType diagnosticType22 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
//        com.google.javascript.jscomp.CheckLevel checkLevel23 = diagnosticType22.defaultLevel;
//        compilerOptions14.checkMethods = checkLevel23;
//        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard25 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup13, checkLevel23);
//        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup26 = null;
//        com.google.javascript.jscomp.CompilerOptions compilerOptions27 = new com.google.javascript.jscomp.CompilerOptions();
//        compilerOptions27.devirtualizePrototypeMethods = false;
//        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy30 = com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC;
//        compilerOptions27.propertyRenaming = propertyRenamingPolicy30;
//        boolean boolean32 = compilerOptions27.recordFunctionInformation;
//        compilerOptions27.optimizeArgumentsArray = false;
//        com.google.javascript.jscomp.DiagnosticType diagnosticType35 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
//        com.google.javascript.jscomp.CheckLevel checkLevel36 = diagnosticType35.defaultLevel;
//        compilerOptions27.checkMethods = checkLevel36;
//        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard38 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup26, checkLevel36);
//        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup39 = null;
//        com.google.javascript.jscomp.CompilerOptions compilerOptions40 = new com.google.javascript.jscomp.CompilerOptions();
//        compilerOptions40.devirtualizePrototypeMethods = false;
//        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy43 = com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC;
//        compilerOptions40.propertyRenaming = propertyRenamingPolicy43;
//        boolean boolean45 = compilerOptions40.recordFunctionInformation;
//        compilerOptions40.optimizeArgumentsArray = false;
//        com.google.javascript.jscomp.DiagnosticType diagnosticType48 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
//        com.google.javascript.jscomp.CheckLevel checkLevel49 = diagnosticType48.defaultLevel;
//        compilerOptions40.checkMethods = checkLevel49;
//        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard51 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup39, checkLevel49);
//        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray52 = new com.google.javascript.jscomp.WarningsGuard[] { diagnosticGroupWarningsGuard12, diagnosticGroupWarningsGuard25, diagnosticGroupWarningsGuard38, diagnosticGroupWarningsGuard51 };
//        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard53 = new com.google.javascript.jscomp.ComposeWarningsGuard(warningsGuardArray52);
//        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard54 = new com.google.javascript.jscomp.ComposeWarningsGuard(warningsGuardArray52);
//        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup55 = com.google.javascript.jscomp.DiagnosticGroups.UNDEFINED_VARIABLES;
//        com.google.javascript.jscomp.DiagnosticGroups.NON_STANDARD_JSDOC = diagnosticGroup55;
//        java.lang.String str57 = diagnosticGroup55.toString();
//        com.google.javascript.jscomp.DiagnosticGroups.INVALID_CASTS = diagnosticGroup55;
//        com.google.javascript.jscomp.DiagnosticGroups.CONSTANT_PROPERTY = diagnosticGroup55;
//        try {
//            boolean boolean60 = composeWarningsGuard54.disables(diagnosticGroup55);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy4 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC + "'", propertyRenamingPolicy4.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC));
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(diagnosticType9);
//        org.junit.Assert.assertTrue("'" + checkLevel10 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel10.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
//        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy17 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC + "'", propertyRenamingPolicy17.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC));
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertNotNull(diagnosticType22);
//        org.junit.Assert.assertTrue("'" + checkLevel23 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel23.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
//        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy30 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC + "'", propertyRenamingPolicy30.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC));
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//        org.junit.Assert.assertNotNull(diagnosticType35);
//        org.junit.Assert.assertTrue("'" + checkLevel36 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel36.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
//        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy43 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC + "'", propertyRenamingPolicy43.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC));
//        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
//        org.junit.Assert.assertNotNull(diagnosticType48);
//        org.junit.Assert.assertTrue("'" + checkLevel49 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel49.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
//        org.junit.Assert.assertNotNull(warningsGuardArray52);
//        org.junit.Assert.assertNotNull(diagnosticGroup55);
//        org.junit.Assert.assertTrue("'" + str57 + "' != '" + "DiagnosticGroup<typeInvalidation>" + "'", str57.equals("DiagnosticGroup<typeInvalidation>"));
//    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        compiler1.reportCodeChange();
        try {
            boolean boolean3 = compiler1.acceptConstKeyword();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        int int0 = com.google.javascript.rhino.Node.CATCH_SCOPE_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + (-1) + "'", int0 == (-1));
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        int int0 = com.google.javascript.rhino.Node.BRACELESS_TYPE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 40 + "'", int0 == 40);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.devirtualizePrototypeMethods = false;
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy3 = com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC;
        compilerOptions0.propertyRenaming = propertyRenamingPolicy3;
        boolean boolean5 = compilerOptions0.recordFunctionInformation;
        compilerOptions0.enableExternExports(false);
        byte[] byteArray11 = new byte[] { (byte) -1, (byte) 1, (byte) 10 };
        compilerOptions0.inputVariableMapSerialized = byteArray11;
        compilerOptions0.convertToDottedProperties = true;
        com.google.javascript.jscomp.DiagnosticType diagnosticType15 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        com.google.javascript.jscomp.CheckLevel checkLevel16 = diagnosticType15.defaultLevel;
        compilerOptions0.checkFunctions = checkLevel16;
        boolean boolean18 = compilerOptions0.checkCaja;
        compilerOptions0.aliasAllStrings = false;
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy3 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC + "'", propertyRenamingPolicy3.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(byteArray11);
        org.junit.Assert.assertNotNull(diagnosticType15);
        org.junit.Assert.assertTrue("'" + checkLevel16 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel16.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.jstype.FunctionType functionType1 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType2 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType3 = null;
        closureCodingConvention0.applySubclassRelationship(functionType1, functionType2, subclassType3);
        com.google.javascript.rhino.jstype.FunctionType functionType5 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType6 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType7 = null;
        closureCodingConvention0.applySubclassRelationship(functionType5, functionType6, subclassType7);
        java.lang.String str9 = closureCodingConvention0.getGlobalObject();
        java.lang.String str10 = closureCodingConvention0.getAbstractMethodName();
        boolean boolean12 = closureCodingConvention0.isSuperClassReference("Unknown class name");
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "goog.global" + "'", str9.equals("goog.global"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "goog.abstractMethod" + "'", str10.equals("goog.abstractMethod"));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeDeadCode = false;
        compilerOptions0.inlineLocalVariables = true;
        boolean boolean5 = compilerOptions0.printInputDelimiter;
        boolean boolean6 = compilerOptions0.optimizeParameters;
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeUnusedLocalVars = false;
        compilerOptions0.crossModuleCodeMotion = false;
        com.google.javascript.jscomp.CompilerOptions compilerOptions5 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions5.devirtualizePrototypeMethods = false;
        java.util.Set<java.lang.String> strSet8 = compilerOptions5.stripNameSuffixes;
        compilerOptions0.stripNamePrefixes = strSet8;
        boolean boolean10 = compilerOptions0.disambiguateProperties;
        com.google.javascript.jscomp.CodingConvention codingConvention11 = compilerOptions0.getCodingConvention();
        org.junit.Assert.assertNotNull(strSet8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNull(codingConvention11);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        com.google.javascript.jscomp.AbstractCompiler abstractCompiler0 = null;
        com.google.javascript.jscomp.NodeTraversal.Callback callback1 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal2 = new com.google.javascript.jscomp.NodeTraversal(abstractCompiler0, callback1);
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        com.google.javascript.rhino.JSDocInfo jSDocInfo9 = null;
        node8.setJSDocInfo(jSDocInfo9);
        java.lang.RuntimeException runtimeException12 = com.google.javascript.rhino.ScriptRuntime.undefReadError((java.lang.Object) node8, (java.lang.Object) 22);
        node8.detachChildren();
        com.google.javascript.rhino.Node node14 = new com.google.javascript.rhino.Node((int) (short) 100, node8);
        com.google.javascript.jscomp.CompilerOptions compilerOptions15 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CodingConvention codingConvention16 = compilerOptions15.getCodingConvention();
        compilerOptions15.computeFunctionSideEffects = true;
        com.google.javascript.jscomp.CheckLevel checkLevel19 = compilerOptions15.checkRequires;
        com.google.javascript.jscomp.DiagnosticType diagnosticType20 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        com.google.javascript.jscomp.DiagnosticType diagnosticType24 = com.google.javascript.jscomp.Compiler.MOTION_ITERATIONS_ERROR;
        java.lang.String[] strArray31 = new java.lang.String[] { "<unknown=160>", "<unknown=160>", "<unknown=160>", "<unknown=160>", "BITXOR", "DiagnosticGroup<undefinedVars>" };
        com.google.javascript.jscomp.JSError jSError32 = com.google.javascript.jscomp.JSError.make("BITXOR", 32, (int) (short) 100, diagnosticType24, strArray31);
        com.google.javascript.jscomp.JSError jSError33 = nodeTraversal2.makeError(node14, checkLevel19, diagnosticType20, strArray31);
        com.google.javascript.jscomp.CheckLevel checkLevel34 = diagnosticType20.level;
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNotNull(runtimeException12);
        org.junit.Assert.assertNull(codingConvention16);
        org.junit.Assert.assertTrue("'" + checkLevel19 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel19.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(diagnosticType20);
        org.junit.Assert.assertNotNull(diagnosticType24);
        org.junit.Assert.assertNotNull(strArray31);
        org.junit.Assert.assertNotNull(jSError32);
        org.junit.Assert.assertNotNull(jSError33);
        org.junit.Assert.assertTrue("'" + checkLevel34 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel34.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        int int0 = com.google.javascript.rhino.Node.IS_DISPATCHER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 46 + "'", int0 == 46);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.devirtualizePrototypeMethods = false;
        compilerOptions0.collapseProperties = false;
        com.google.javascript.jscomp.CheckLevel checkLevel5 = null;
        compilerOptions0.reportMissingOverride = checkLevel5;
        java.lang.String str7 = compilerOptions0.nameReferenceGraphPath;
        compilerOptions0.inputDelimiter = "language version";
        java.lang.String str10 = com.google.javascript.rhino.ScriptRuntime.toString((java.lang.Object) compilerOptions0);
        org.junit.Assert.assertNull(str7);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        java.lang.String[] strArray0 = com.google.javascript.rhino.ScriptRuntime.emptyStrings;
        org.junit.Assert.assertNotNull(strArray0);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        com.google.javascript.rhino.JSDocInfo jSDocInfo6 = null;
        node5.setJSDocInfo(jSDocInfo6);
        java.lang.RuntimeException runtimeException9 = com.google.javascript.rhino.ScriptRuntime.undefReadError((java.lang.Object) node5, (java.lang.Object) 22);
        node5.detachChildren();
        java.lang.String[] strArray16 = new java.lang.String[] { "error reporter", "hi!", "BITXOR", "error reporter", "BITXOR" };
        java.util.LinkedHashSet<java.lang.String> strSet17 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean18 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet17, strArray16);
        node5.setDirectives((java.util.Set<java.lang.String>) strSet17);
        com.google.javascript.jscomp.DiagnosticType diagnosticType23 = com.google.javascript.jscomp.Compiler.MOTION_ITERATIONS_ERROR;
        java.lang.String[] strArray30 = new java.lang.String[] { "<unknown=160>", "<unknown=160>", "<unknown=160>", "<unknown=160>", "BITXOR", "DiagnosticGroup<undefinedVars>" };
        com.google.javascript.jscomp.JSError jSError31 = com.google.javascript.jscomp.JSError.make("BITXOR", 32, (int) (short) 100, diagnosticType23, strArray30);
        com.google.javascript.jscomp.DiagnosticType diagnosticType32 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        int int33 = diagnosticType23.compareTo(diagnosticType32);
        com.google.javascript.jscomp.DiagnosticType diagnosticType39 = com.google.javascript.jscomp.DiagnosticType.error("", "hi!");
        com.google.javascript.jscomp.DiagnosticType diagnosticType43 = com.google.javascript.jscomp.Compiler.MOTION_ITERATIONS_ERROR;
        java.lang.String[] strArray50 = new java.lang.String[] { "<unknown=160>", "<unknown=160>", "<unknown=160>", "<unknown=160>", "BITXOR", "DiagnosticGroup<undefinedVars>" };
        com.google.javascript.jscomp.JSError jSError51 = com.google.javascript.jscomp.JSError.make("BITXOR", 32, (int) (short) 100, diagnosticType43, strArray50);
        com.google.javascript.jscomp.JSError jSError52 = com.google.javascript.jscomp.JSError.make("BITXOR", 38, 130, diagnosticType39, strArray50);
        com.google.javascript.jscomp.JSError jSError53 = com.google.javascript.jscomp.JSError.make("hi!", node5, diagnosticType32, strArray50);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNotNull(runtimeException9);
        org.junit.Assert.assertNotNull(strArray16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(diagnosticType23);
        org.junit.Assert.assertNotNull(strArray30);
        org.junit.Assert.assertNotNull(jSError31);
        org.junit.Assert.assertNotNull(diagnosticType32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertNotNull(diagnosticType39);
        org.junit.Assert.assertNotNull(diagnosticType43);
        org.junit.Assert.assertNotNull(strArray50);
        org.junit.Assert.assertNotNull(jSError51);
        org.junit.Assert.assertNotNull(jSError52);
        org.junit.Assert.assertNotNull(jSError53);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.debugFunctionSideEffectsPath = "";
        compilerOptions0.collapseVariableDeclarations = true;
        compilerOptions0.checkEs5Strict = false;
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeDeadCode = false;
        boolean boolean3 = compilerOptions0.removeTryCatchFinally;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

//    @Test
//    public void test356() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test356");
//        try {
//            com.google.javascript.rhino.EvaluatorException evaluatorException1 = com.google.javascript.rhino.Context.reportRuntimeError("(goog.exportSymbol)");
//            org.junit.Assert.fail("Expected exception of type com.google.javascript.rhino.EvaluatorException; message: (goog.exportSymbol)");
//        } catch (com.google.javascript.rhino.EvaluatorException e) {
//        }
//    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        boolean boolean6 = node5.hasMoreThanOneChild();
        node5.setLineno(0);
        com.google.javascript.rhino.Node node9 = node5.cloneTree();
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        node14.removeProp((int) (short) 1);
        com.google.javascript.rhino.Node node22 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        boolean boolean23 = node22.hasMoreThanOneChild();
        node22.setLineno(0);
        boolean boolean26 = node22.hasOneChild();
        com.google.javascript.rhino.jstype.JSType jSType27 = node22.getJSType();
        com.google.javascript.rhino.Node node32 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        node32.removeProp((int) (short) 1);
        com.google.javascript.rhino.Node[] nodeArray35 = new com.google.javascript.rhino.Node[] { node22, node32 };
        com.google.javascript.rhino.Node node38 = new com.google.javascript.rhino.Node((int) (byte) 10, nodeArray35, (int) '4', (int) (byte) -1);
        com.google.javascript.rhino.Node node39 = node14.copyInformationFromForTree(node38);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder40 = node38.new FileLevelJsDocBuilder();
        java.lang.String str44 = node38.toString(false, false, false);
        node5.addChildrenToBack(node38);
        com.google.javascript.rhino.Node node46 = node5.removeFirstChild();
        com.google.javascript.jscomp.CheckLevel checkLevel47 = null;
        com.google.javascript.jscomp.DiagnosticType diagnosticType48 = null;
        com.google.javascript.jscomp.DiagnosticType diagnosticType52 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        com.google.javascript.jscomp.CheckLevel checkLevel53 = diagnosticType52.level;
        com.google.javascript.jscomp.CheckLevel checkLevel54 = com.google.javascript.jscomp.CheckLevel.OFF;
        diagnosticType52.level = checkLevel54;
        com.google.javascript.jscomp.AbstractCompiler abstractCompiler56 = null;
        com.google.javascript.jscomp.NodeTraversal.Callback callback57 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal58 = new com.google.javascript.jscomp.NodeTraversal(abstractCompiler56, callback57);
        com.google.javascript.rhino.Node node64 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        com.google.javascript.rhino.JSDocInfo jSDocInfo65 = null;
        node64.setJSDocInfo(jSDocInfo65);
        java.lang.RuntimeException runtimeException68 = com.google.javascript.rhino.ScriptRuntime.undefReadError((java.lang.Object) node64, (java.lang.Object) 22);
        node64.detachChildren();
        com.google.javascript.rhino.Node node70 = new com.google.javascript.rhino.Node((int) (short) 100, node64);
        com.google.javascript.jscomp.CompilerOptions compilerOptions71 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CodingConvention codingConvention72 = compilerOptions71.getCodingConvention();
        compilerOptions71.computeFunctionSideEffects = true;
        com.google.javascript.jscomp.CheckLevel checkLevel75 = compilerOptions71.checkRequires;
        com.google.javascript.jscomp.DiagnosticType diagnosticType76 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        com.google.javascript.jscomp.DiagnosticType diagnosticType80 = com.google.javascript.jscomp.Compiler.MOTION_ITERATIONS_ERROR;
        java.lang.String[] strArray87 = new java.lang.String[] { "<unknown=160>", "<unknown=160>", "<unknown=160>", "<unknown=160>", "BITXOR", "DiagnosticGroup<undefinedVars>" };
        com.google.javascript.jscomp.JSError jSError88 = com.google.javascript.jscomp.JSError.make("BITXOR", 32, (int) (short) 100, diagnosticType80, strArray87);
        com.google.javascript.jscomp.JSError jSError89 = nodeTraversal58.makeError(node70, checkLevel75, diagnosticType76, strArray87);
        com.google.javascript.jscomp.JSError jSError90 = com.google.javascript.jscomp.JSError.make("0", (int) (byte) -1, 20, diagnosticType52, strArray87);
        try {
            com.google.javascript.jscomp.JSError jSError91 = com.google.javascript.jscomp.JSError.make("null(ERROR), null(ERROR), null(ERROR), null(ERROR)", node46, checkLevel47, diagnosticType48, strArray87);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNull(jSType27);
        org.junit.Assert.assertNotNull(node32);
        org.junit.Assert.assertNotNull(nodeArray35);
        org.junit.Assert.assertNotNull(node39);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "BITXOR" + "'", str44.equals("BITXOR"));
        org.junit.Assert.assertNotNull(node46);
        org.junit.Assert.assertNotNull(diagnosticType52);
        org.junit.Assert.assertTrue("'" + checkLevel53 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel53.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + checkLevel54 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel54.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(node64);
        org.junit.Assert.assertNotNull(runtimeException68);
        org.junit.Assert.assertNull(codingConvention72);
        org.junit.Assert.assertTrue("'" + checkLevel75 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel75.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(diagnosticType76);
        org.junit.Assert.assertNotNull(diagnosticType80);
        org.junit.Assert.assertNotNull(strArray87);
        org.junit.Assert.assertNotNull(jSError88);
        org.junit.Assert.assertNotNull(jSError89);
        org.junit.Assert.assertNotNull(jSError90);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.devirtualizePrototypeMethods = false;
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy3 = com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC;
        compilerOptions0.propertyRenaming = propertyRenamingPolicy3;
        boolean boolean5 = compilerOptions0.recordFunctionInformation;
        compilerOptions0.optimizeArgumentsArray = false;
        com.google.javascript.jscomp.DiagnosticType diagnosticType8 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        com.google.javascript.jscomp.CheckLevel checkLevel9 = diagnosticType8.defaultLevel;
        compilerOptions0.checkMethods = checkLevel9;
        com.google.javascript.jscomp.CheckLevel checkLevel11 = compilerOptions0.checkRequires;
        compilerOptions0.setRewriteNewDateGoogNow(true);
        compilerOptions0.skipAllCompilerPasses();
        compilerOptions0.rewriteFunctionExpressions = true;
        com.google.javascript.jscomp.CheckLevel checkLevel17 = compilerOptions0.checkMethods;
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy3 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC + "'", propertyRenamingPolicy3.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(diagnosticType8);
        org.junit.Assert.assertTrue("'" + checkLevel9 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel9.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + checkLevel11 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel11.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + checkLevel17 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel17.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.devirtualizePrototypeMethods = false;
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy3 = com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC;
        compilerOptions0.propertyRenaming = propertyRenamingPolicy3;
        boolean boolean5 = compilerOptions0.recordFunctionInformation;
        compilerOptions0.optimizeArgumentsArray = false;
        boolean boolean8 = compilerOptions0.rewriteFunctionExpressions;
        compilerOptions0.locale = "language version";
        compilerOptions0.removeTryCatchFinally = false;
        com.google.javascript.jscomp.CompilerOptions compilerOptions13 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions13.devirtualizePrototypeMethods = false;
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy16 = com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC;
        compilerOptions13.propertyRenaming = propertyRenamingPolicy16;
        boolean boolean18 = compilerOptions13.recordFunctionInformation;
        java.util.Set<java.lang.String> strSet19 = compilerOptions13.stripTypes;
        compilerOptions0.stripNamePrefixes = strSet19;
        boolean boolean21 = compilerOptions0.reserveRawExports;
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy3 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC + "'", propertyRenamingPolicy3.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy16 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC + "'", propertyRenamingPolicy16.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(strSet19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.devirtualizePrototypeMethods = false;
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy3 = com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC;
        compilerOptions0.propertyRenaming = propertyRenamingPolicy3;
        boolean boolean5 = compilerOptions0.recordFunctionInformation;
        compilerOptions0.optimizeArgumentsArray = false;
        com.google.javascript.jscomp.DiagnosticType diagnosticType8 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        com.google.javascript.jscomp.CheckLevel checkLevel9 = diagnosticType8.defaultLevel;
        compilerOptions0.checkMethods = checkLevel9;
        com.google.javascript.jscomp.CompilerOptions compilerOptions11 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions11.devirtualizePrototypeMethods = false;
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy14 = com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC;
        compilerOptions11.propertyRenaming = propertyRenamingPolicy14;
        boolean boolean16 = compilerOptions11.recordFunctionInformation;
        compilerOptions11.enableExternExports(false);
        com.google.javascript.jscomp.CheckLevel checkLevel19 = compilerOptions11.checkUnreachableCode;
        com.google.javascript.jscomp.CheckLevel checkLevel20 = compilerOptions11.reportMissingOverride;
        compilerOptions0.checkProvides = checkLevel20;
        java.lang.String str22 = compilerOptions0.jsOutputFile;
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy3 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC + "'", propertyRenamingPolicy3.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(diagnosticType8);
        org.junit.Assert.assertTrue("'" + checkLevel9 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel9.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy14 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC + "'", propertyRenamingPolicy14.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + checkLevel19 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel19.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + checkLevel20 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel20.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "" + "'", str22.equals(""));
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        int int0 = com.google.javascript.rhino.Node.BREAK_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        int int0 = com.google.javascript.rhino.Node.LOCAL_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 7 + "'", int0 == 7);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        com.google.javascript.jscomp.DiagnosticGroup[] diagnosticGroupArray0 = new com.google.javascript.jscomp.DiagnosticGroup[] {};
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup1 = new com.google.javascript.jscomp.DiagnosticGroup(diagnosticGroupArray0);
        org.junit.Assert.assertNotNull(diagnosticGroupArray0);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        com.google.javascript.rhino.EcmaError ecmaError2 = com.google.javascript.rhino.ScriptRuntime.constructError("DiagnosticGroup<undefinedVars>", "<unknown=160>");
        java.lang.String str3 = ecmaError2.getSourceName();
        java.lang.String str4 = ecmaError2.getScriptStackTrace();
        java.lang.String str5 = ecmaError2.details();
        org.junit.Assert.assertNotNull(ecmaError2);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "<No stack trace available>" + "'", str4.equals("<No stack trace available>"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "DiagnosticGroup<undefinedVars>: <unknown=160>" + "'", str5.equals("DiagnosticGroup<undefinedVars>: <unknown=160>"));
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeUnusedLocalVars = false;
        compilerOptions0.crossModuleCodeMotion = false;
        boolean boolean5 = compilerOptions0.optimizeParameters;
        compilerOptions0.checkSymbols = false;
        java.util.Set<java.lang.String> strSet8 = compilerOptions0.stripTypePrefixes;
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(strSet8);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeUnusedLocalVars = false;
        compilerOptions0.jsOutputFile = "";
        com.google.javascript.jscomp.CodingConvention codingConvention5 = compilerOptions0.getCodingConvention();
        compilerOptions0.removeEmptyFunctions = true;
        org.junit.Assert.assertNull(codingConvention5);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.devirtualizePrototypeMethods = false;
        java.lang.String str3 = compilerOptions0.syntheticBlockStartMarker;
        com.google.javascript.jscomp.CompilerOptions compilerOptions4 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions4.devirtualizePrototypeMethods = false;
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy7 = com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC;
        compilerOptions4.propertyRenaming = propertyRenamingPolicy7;
        boolean boolean9 = compilerOptions4.recordFunctionInformation;
        compilerOptions4.optimizeArgumentsArray = false;
        boolean boolean12 = compilerOptions4.rewriteFunctionExpressions;
        compilerOptions4.locale = "language version";
        compilerOptions4.removeTryCatchFinally = false;
        com.google.javascript.jscomp.CompilerOptions compilerOptions17 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions17.devirtualizePrototypeMethods = false;
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy20 = com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC;
        compilerOptions17.propertyRenaming = propertyRenamingPolicy20;
        boolean boolean22 = compilerOptions17.recordFunctionInformation;
        java.util.Set<java.lang.String> strSet23 = compilerOptions17.stripTypes;
        compilerOptions4.stripNamePrefixes = strSet23;
        compilerOptions0.aliasableStrings = strSet23;
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy7 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC + "'", propertyRenamingPolicy7.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy20 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC + "'", propertyRenamingPolicy20.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(strSet23);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeDeadCode = false;
        boolean boolean3 = compilerOptions0.checkTypes;
        compilerOptions0.lineBreak = false;
        com.google.javascript.jscomp.MessageBundle messageBundle6 = compilerOptions0.messageBundle;
        com.google.javascript.jscomp.CompilerOptions compilerOptions7 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CodingConvention codingConvention8 = compilerOptions7.getCodingConvention();
        com.google.javascript.jscomp.CompilerOptions.AliasTransformationHandler aliasTransformationHandler9 = compilerOptions7.getAliasTransformationHandler();
        compilerOptions0.setAliasTransformationHandler(aliasTransformationHandler9);
        com.google.javascript.rhino.SourcePosition<com.google.javascript.jscomp.CompilerOptions.AliasTransformation> aliasTransformationSourcePosition12 = null;
        try {
            com.google.javascript.jscomp.CompilerOptions.AliasTransformation aliasTransformation13 = aliasTransformationHandler9.logAliasTransformation("goog.abstractMethod", aliasTransformationSourcePosition12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(messageBundle6);
        org.junit.Assert.assertNull(codingConvention8);
        org.junit.Assert.assertNotNull(aliasTransformationHandler9);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile1 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        java.lang.String str2 = jSSourceFile1.getOriginalPath();
        com.google.javascript.jscomp.CompilerInput compilerInput4 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile1, true);
        com.google.javascript.jscomp.SourceAst sourceAst5 = compilerInput4.getSourceAst();
        org.junit.Assert.assertNotNull(jSSourceFile1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertNotNull(sourceAst5);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.devirtualizePrototypeMethods = false;
        compilerOptions0.groupVariableDeclarations = false;
        boolean boolean5 = compilerOptions0.crossModuleCodeMotion;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap6 = null;
        compilerOptions0.cssRenamingMap = cssRenamingMap6;
        byte[] byteArray8 = compilerOptions0.inputPropertyMapSerialized;
        compilerOptions0.removeDeadCode = false;
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(byteArray8);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.devirtualizePrototypeMethods = false;
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy3 = com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC;
        compilerOptions0.propertyRenaming = propertyRenamingPolicy3;
        compilerOptions0.disableRuntimeTypeCheck();
        compilerOptions0.checkSuspiciousCode = false;
        com.google.javascript.jscomp.CheckLevel checkLevel8 = compilerOptions0.checkGlobalThisLevel;
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy3 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC + "'", propertyRenamingPolicy3.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC));
        org.junit.Assert.assertTrue("'" + checkLevel8 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel8.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

//    @Test
//    public void test372() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test372");
//        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.UNDEFINED_VARIABLES;
//        com.google.javascript.jscomp.DiagnosticGroups.NON_STANDARD_JSDOC = diagnosticGroup0;
//        java.lang.String str2 = diagnosticGroup0.toString();
//        com.google.javascript.jscomp.DiagnosticGroups.INVALID_CASTS = diagnosticGroup0;
//        com.google.javascript.jscomp.DiagnosticGroups.CONSTANT_PROPERTY = diagnosticGroup0;
//        com.google.javascript.jscomp.DiagnosticGroups.STRICT_MODULE_DEP_CHECK = diagnosticGroup0;
//        org.junit.Assert.assertNotNull(diagnosticGroup0);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "DiagnosticGroup<typeInvalidation>" + "'", str2.equals("DiagnosticGroup<typeInvalidation>"));
//    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        com.google.javascript.jscomp.JSModule[] jSModuleArray0 = new com.google.javascript.jscomp.JSModule[] {};
        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList1 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList1, jSModuleArray0);
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph3 = new com.google.javascript.jscomp.JSModuleGraph((java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList1);
        jSModuleGraph3.coalesceDuplicateFiles();
        org.junit.Assert.assertNotNull(jSModuleArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.DEPRECATED;
        com.google.javascript.jscomp.DiagnosticGroups.ACCESS_CONTROLS = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticGroups.NON_STANDARD_JSDOC = diagnosticGroup0;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        com.google.javascript.jscomp.CompilerOptions compilerOptions1 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions1.removeUnusedLocalVars = false;
        compilerOptions1.crossModuleCodeMotion = false;
        com.google.javascript.jscomp.CompilerOptions compilerOptions6 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions6.devirtualizePrototypeMethods = false;
        java.util.Set<java.lang.String> strSet9 = compilerOptions6.stripNameSuffixes;
        compilerOptions1.stripNamePrefixes = strSet9;
        compilerOptions1.labelRenaming = true;
        com.google.javascript.jscomp.CompilerOptions compilerOptions13 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions13.devirtualizePrototypeMethods = false;
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy16 = com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC;
        compilerOptions13.propertyRenaming = propertyRenamingPolicy16;
        boolean boolean18 = compilerOptions13.recordFunctionInformation;
        compilerOptions13.enableExternExports(false);
        com.google.javascript.jscomp.CheckLevel checkLevel21 = compilerOptions13.checkUnreachableCode;
        com.google.javascript.jscomp.CheckLevel checkLevel22 = compilerOptions13.reportMissingOverride;
        compilerOptions1.checkMissingGetCssNameLevel = checkLevel22;
        com.google.javascript.jscomp.DiagnosticType diagnosticType25 = com.google.javascript.jscomp.DiagnosticType.make("goog.exportProperty", checkLevel22, "Not declared as a constructor");
        org.junit.Assert.assertNotNull(strSet9);
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy16 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC + "'", propertyRenamingPolicy16.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + checkLevel21 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel21.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + checkLevel22 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel22.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(diagnosticType25);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile1 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.CompilerInput compilerInput2 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile1);
        boolean boolean3 = compilerInput2.isExtern();
        com.google.javascript.jscomp.JSModule jSModule4 = null;
        compilerInput2.setModule(jSModule4);
        compilerInput2.clearAst();
        try {
            java.lang.String str7 = compilerInput2.getPathRelativeToClosureBase();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: null");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        node5.removeProp((int) (short) 1);
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        boolean boolean14 = node13.hasMoreThanOneChild();
        node13.setLineno(0);
        boolean boolean17 = node13.hasOneChild();
        com.google.javascript.rhino.jstype.JSType jSType18 = node13.getJSType();
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        node23.removeProp((int) (short) 1);
        com.google.javascript.rhino.Node[] nodeArray26 = new com.google.javascript.rhino.Node[] { node13, node23 };
        com.google.javascript.rhino.Node node29 = new com.google.javascript.rhino.Node((int) (byte) 10, nodeArray26, (int) '4', (int) (byte) -1);
        com.google.javascript.rhino.Node node30 = node5.copyInformationFromForTree(node29);
        com.google.javascript.rhino.Node node35 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        node35.setSourcePositionForTree(20);
        com.google.javascript.rhino.Node node42 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        boolean boolean43 = node42.hasMoreThanOneChild();
        node42.setLineno(0);
        com.google.javascript.rhino.Node node46 = node42.cloneTree();
        com.google.javascript.rhino.Node node51 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        com.google.javascript.rhino.JSDocInfo jSDocInfo52 = null;
        node51.setJSDocInfo(jSDocInfo52);
        java.lang.RuntimeException runtimeException55 = com.google.javascript.rhino.ScriptRuntime.undefReadError((java.lang.Object) node51, (java.lang.Object) 22);
        node51.detachChildren();
        int int57 = node51.getChildCount();
        com.google.javascript.rhino.Node node60 = new com.google.javascript.rhino.Node((int) (short) -1, node30, node35, node46, node51, 15, (int) (byte) 1);
        com.google.javascript.rhino.Node node66 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        boolean boolean67 = node66.hasMoreThanOneChild();
        node66.setLineno(0);
        boolean boolean70 = node66.hasOneChild();
        com.google.javascript.rhino.jstype.JSType jSType71 = node66.getJSType();
        com.google.javascript.rhino.Node node76 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        node76.removeProp((int) (short) 1);
        com.google.javascript.rhino.Node[] nodeArray79 = new com.google.javascript.rhino.Node[] { node66, node76 };
        com.google.javascript.rhino.Node node82 = new com.google.javascript.rhino.Node((int) (byte) 10, nodeArray79, (int) '4', (int) (byte) -1);
        boolean boolean83 = node51.isEquivalentTo(node82);
        com.google.javascript.rhino.Node node84 = null;
        try {
            com.google.javascript.rhino.Node node85 = node51.copyInformationFromForTree(node84);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNull(jSType18);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(nodeArray26);
        org.junit.Assert.assertNotNull(node30);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertNotNull(node42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(node46);
        org.junit.Assert.assertNotNull(node51);
        org.junit.Assert.assertNotNull(runtimeException55);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 0 + "'", int57 == 0);
        org.junit.Assert.assertNotNull(node66);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertNull(jSType71);
        org.junit.Assert.assertNotNull(node76);
        org.junit.Assert.assertNotNull(nodeArray79);
        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + false + "'", boolean83 == false);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        com.google.javascript.jscomp.CheckLevel checkLevel0 = com.google.javascript.jscomp.CheckLevel.WARNING;
        org.junit.Assert.assertTrue("'" + checkLevel0 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel0.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        com.google.javascript.rhino.JSDocInfo jSDocInfo5 = null;
        node4.setJSDocInfo(jSDocInfo5);
        node4.setType(100);
        boolean boolean9 = node4.isQualifiedName();
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.jstype.FunctionType functionType1 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType2 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType3 = null;
        closureCodingConvention0.applySubclassRelationship(functionType1, functionType2, subclassType3);
        com.google.javascript.rhino.jstype.FunctionType functionType5 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType6 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType7 = null;
        closureCodingConvention0.applySubclassRelationship(functionType5, functionType6, subclassType7);
        java.lang.String str9 = closureCodingConvention0.getGlobalObject();
        com.google.javascript.rhino.jstype.ObjectType objectType10 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType11 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType12 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType13 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType14 = null;
        closureCodingConvention0.applyDelegateRelationship(objectType10, objectType11, objectType12, functionType13, functionType14);
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention16 = new com.google.javascript.jscomp.ClosureCodingConvention();
        java.lang.String str17 = closureCodingConvention16.getExportSymbolFunction();
        com.google.javascript.rhino.jstype.FunctionType functionType18 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType19 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType20 = null;
        closureCodingConvention16.applySubclassRelationship(functionType18, functionType19, subclassType20);
        com.google.javascript.rhino.Node node25 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode((com.google.javascript.jscomp.CodingConvention) closureCodingConvention16, "DiagnosticGroup<undefinedVars>: <unknown=160>", 7, 20);
        try {
            java.lang.String str26 = closureCodingConvention0.getSingletonGetterClassName(node25);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "goog.global" + "'", str9.equals("goog.global"));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "goog.exportSymbol" + "'", str17.equals("goog.exportSymbol"));
        org.junit.Assert.assertNotNull(node25);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        com.google.javascript.rhino.Context context0 = new com.google.javascript.rhino.Context();
        com.google.javascript.jscomp.AnonymousFunctionNamingPolicy anonymousFunctionNamingPolicy1 = com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.UNMAPPED;
        context0.removeThreadLocal((java.lang.Object) anonymousFunctionNamingPolicy1);
        long long3 = com.google.javascript.rhino.ScriptRuntime.lastUint32Result(context0);
        long long4 = com.google.javascript.rhino.ScriptRuntime.lastUint32Result(context0);
        com.google.javascript.jscomp.CompilerOptions compilerOptions5 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions5.devirtualizePrototypeMethods = false;
        java.util.Set<java.lang.String> strSet8 = compilerOptions5.stripNameSuffixes;
        com.google.javascript.jscomp.SourceMap.DetailLevel detailLevel9 = null;
        compilerOptions5.sourceMapDetailLevel = detailLevel9;
        boolean boolean11 = compilerOptions5.disambiguateProperties;
        try {
            context0.unseal((java.lang.Object) compilerOptions5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + anonymousFunctionNamingPolicy1 + "' != '" + com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.UNMAPPED + "'", anonymousFunctionNamingPolicy1.equals(com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.UNMAPPED));
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
        org.junit.Assert.assertNotNull(strSet8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString("goog.global", 49, 14);
        org.junit.Assert.assertNotNull(node3);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.devirtualizePrototypeMethods = false;
        compilerOptions0.groupVariableDeclarations = false;
        boolean boolean5 = compilerOptions0.crossModuleCodeMotion;
        compilerOptions0.setManageClosureDependencies(true);
        boolean boolean8 = compilerOptions0.tightenTypes;
        com.google.javascript.jscomp.CheckLevel checkLevel9 = compilerOptions0.checkGlobalThisLevel;
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + checkLevel9 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel9.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.devirtualizePrototypeMethods = false;
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy3 = com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC;
        compilerOptions0.propertyRenaming = propertyRenamingPolicy3;
        boolean boolean5 = compilerOptions0.recordFunctionInformation;
        compilerOptions0.optimizeArgumentsArray = false;
        com.google.javascript.jscomp.DiagnosticType diagnosticType8 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        com.google.javascript.jscomp.CheckLevel checkLevel9 = diagnosticType8.defaultLevel;
        compilerOptions0.checkMethods = checkLevel9;
        com.google.javascript.jscomp.CompilerOptions compilerOptions11 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions11.devirtualizePrototypeMethods = false;
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy14 = com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC;
        compilerOptions11.propertyRenaming = propertyRenamingPolicy14;
        boolean boolean16 = compilerOptions11.recordFunctionInformation;
        compilerOptions11.enableExternExports(false);
        com.google.javascript.jscomp.CheckLevel checkLevel19 = compilerOptions11.checkUnreachableCode;
        com.google.javascript.jscomp.CheckLevel checkLevel20 = compilerOptions11.reportMissingOverride;
        compilerOptions0.checkProvides = checkLevel20;
        compilerOptions0.syntheticBlockEndMarker = "goog.exportSymbol";
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy3 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC + "'", propertyRenamingPolicy3.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(diagnosticType8);
        org.junit.Assert.assertTrue("'" + checkLevel9 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel9.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy14 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC + "'", propertyRenamingPolicy14.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + checkLevel19 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel19.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + checkLevel20 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel20.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        com.google.javascript.rhino.Context context0 = new com.google.javascript.rhino.Context();
        com.google.javascript.jscomp.AnonymousFunctionNamingPolicy anonymousFunctionNamingPolicy1 = com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.UNMAPPED;
        context0.removeThreadLocal((java.lang.Object) anonymousFunctionNamingPolicy1);
        boolean boolean3 = context0.isGeneratingDebug();
        long long4 = com.google.javascript.rhino.ScriptRuntime.lastUint32Result(context0);
        com.google.javascript.rhino.Context context5 = com.google.javascript.rhino.Context.enter(context0);
        boolean boolean6 = context5.isGeneratingSource();
        com.google.javascript.jscomp.CompilerOptions compilerOptions7 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions7.removeUnusedLocalVars = false;
        compilerOptions7.jsOutputFile = "";
        com.google.javascript.jscomp.CompilerOptions.TweakProcessing tweakProcessing12 = com.google.javascript.jscomp.CompilerOptions.TweakProcessing.STRIP;
        compilerOptions7.setTweakProcessing(tweakProcessing12);
        com.google.javascript.jscomp.CompilerOptions compilerOptions14 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions14.devirtualizePrototypeMethods = false;
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy17 = com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC;
        compilerOptions14.propertyRenaming = propertyRenamingPolicy17;
        java.lang.String str19 = compilerOptions14.unaliasableGlobals;
        compilerOptions14.setOutputCharset("language version");
        java.util.Set<java.lang.String> strSet22 = compilerOptions14.stripNamePrefixes;
        compilerOptions14.setTweakToStringLiteral("", "@IMPLEMENTATION.VERSION@");
        com.google.javascript.jscomp.CompilerOptions compilerOptions26 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CodingConvention codingConvention27 = compilerOptions26.getCodingConvention();
        compilerOptions26.computeFunctionSideEffects = true;
        byte[] byteArray30 = compilerOptions26.inputPropertyMapSerialized;
        com.google.javascript.jscomp.CompilerOptions compilerOptions31 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions31.removeUnusedLocalVars = false;
        compilerOptions31.crossModuleCodeMotion = false;
        compilerOptions31.ambiguateProperties = false;
        compilerOptions31.checkTypedPropertyCalls = true;
        java.lang.String str40 = compilerOptions31.syntheticBlockEndMarker;
        java.util.Set<java.lang.String> strSet41 = compilerOptions31.stripTypes;
        compilerOptions26.setIdGenerators(strSet41);
        compilerOptions14.stripTypePrefixes = strSet41;
        context5.putThreadLocal((java.lang.Object) compilerOptions7, (java.lang.Object) strSet41);
        java.lang.Object obj45 = null;
        context5.seal(obj45);
        java.beans.PropertyChangeListener propertyChangeListener47 = null;
        try {
            context5.removePropertyChangeListener(propertyChangeListener47);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertTrue("'" + anonymousFunctionNamingPolicy1 + "' != '" + com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.UNMAPPED + "'", anonymousFunctionNamingPolicy1.equals(com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.UNMAPPED));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
        org.junit.Assert.assertNotNull(context5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + tweakProcessing12 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TweakProcessing.STRIP + "'", tweakProcessing12.equals(com.google.javascript.jscomp.CompilerOptions.TweakProcessing.STRIP));
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy17 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC + "'", propertyRenamingPolicy17.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC));
        org.junit.Assert.assertNull(str19);
        org.junit.Assert.assertNotNull(strSet22);
        org.junit.Assert.assertNull(codingConvention27);
        org.junit.Assert.assertNull(byteArray30);
        org.junit.Assert.assertNull(str40);
        org.junit.Assert.assertNotNull(strSet41);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.jstype.FunctionType functionType1 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType2 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType3 = null;
        closureCodingConvention0.applySubclassRelationship(functionType1, functionType2, subclassType3);
        com.google.javascript.rhino.jstype.FunctionType functionType5 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType6 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType7 = null;
        closureCodingConvention0.applySubclassRelationship(functionType5, functionType6, subclassType7);
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        node13.removeProp((int) (short) 1);
        com.google.javascript.rhino.Node node21 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        boolean boolean22 = node21.hasMoreThanOneChild();
        node21.setLineno(0);
        boolean boolean25 = node21.hasOneChild();
        com.google.javascript.rhino.jstype.JSType jSType26 = node21.getJSType();
        com.google.javascript.rhino.Node node31 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        node31.removeProp((int) (short) 1);
        com.google.javascript.rhino.Node[] nodeArray34 = new com.google.javascript.rhino.Node[] { node21, node31 };
        com.google.javascript.rhino.Node node37 = new com.google.javascript.rhino.Node((int) (byte) 10, nodeArray34, (int) '4', (int) (byte) -1);
        com.google.javascript.rhino.Node node38 = node13.copyInformationFromForTree(node37);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder39 = node37.new FileLevelJsDocBuilder();
        java.lang.String str43 = node37.toString(false, false, false);
        com.google.javascript.jscomp.CodingConvention.SubclassRelationship subclassRelationship44 = closureCodingConvention0.getClassesDefinedByCall(node37);
        com.google.javascript.rhino.Node node49 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        node49.setType(0);
        boolean boolean52 = node49.isOnlyModifiesThisCall();
        boolean boolean53 = closureCodingConvention0.isVarArgsParameter(node49);
        com.google.javascript.rhino.Node node57 = com.google.javascript.rhino.Node.newString("", 9, (int) '#');
        boolean boolean58 = node57.isSyntheticBlock();
        try {
            com.google.javascript.jscomp.CodingConvention.SubclassRelationship subclassRelationship59 = closureCodingConvention0.getClassesDefinedByCall(node57);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNull(jSType26);
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertNotNull(nodeArray34);
        org.junit.Assert.assertNotNull(node38);
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "BITXOR" + "'", str43.equals("BITXOR"));
        org.junit.Assert.assertNull(subclassRelationship44);
        org.junit.Assert.assertNotNull(node49);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNotNull(node57);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.devirtualizePrototypeMethods = false;
        compilerOptions0.crossModuleMethodMotion = true;
        compilerOptions0.checkSymbols = true;
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        java.lang.String str1 = closureCodingConvention0.getExportPropertyFunction();
        boolean boolean3 = closureCodingConvention0.isSuperClassReference("");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention4 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.jstype.FunctionType functionType5 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType6 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType7 = null;
        closureCodingConvention4.applySubclassRelationship(functionType5, functionType6, subclassType7);
        boolean boolean10 = closureCodingConvention4.isSuperClassReference("");
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        node15.removeProp((int) (short) 1);
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        boolean boolean24 = node23.hasMoreThanOneChild();
        node23.setLineno(0);
        boolean boolean27 = node23.hasOneChild();
        com.google.javascript.rhino.jstype.JSType jSType28 = node23.getJSType();
        com.google.javascript.rhino.Node node33 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        node33.removeProp((int) (short) 1);
        com.google.javascript.rhino.Node[] nodeArray36 = new com.google.javascript.rhino.Node[] { node23, node33 };
        com.google.javascript.rhino.Node node39 = new com.google.javascript.rhino.Node((int) (byte) 10, nodeArray36, (int) '4', (int) (byte) -1);
        com.google.javascript.rhino.Node node40 = node15.copyInformationFromForTree(node39);
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention41 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.jstype.FunctionType functionType42 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType43 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType44 = null;
        closureCodingConvention41.applySubclassRelationship(functionType42, functionType43, subclassType44);
        com.google.javascript.rhino.jstype.FunctionType functionType46 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType47 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType48 = null;
        closureCodingConvention41.applySubclassRelationship(functionType46, functionType47, subclassType48);
        com.google.javascript.rhino.Node node54 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        node54.removeProp((int) (short) 1);
        com.google.javascript.rhino.Node node62 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        boolean boolean63 = node62.hasMoreThanOneChild();
        node62.setLineno(0);
        boolean boolean66 = node62.hasOneChild();
        com.google.javascript.rhino.jstype.JSType jSType67 = node62.getJSType();
        com.google.javascript.rhino.Node node72 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        node72.removeProp((int) (short) 1);
        com.google.javascript.rhino.Node[] nodeArray75 = new com.google.javascript.rhino.Node[] { node62, node72 };
        com.google.javascript.rhino.Node node78 = new com.google.javascript.rhino.Node((int) (byte) 10, nodeArray75, (int) '4', (int) (byte) -1);
        com.google.javascript.rhino.Node node79 = node54.copyInformationFromForTree(node78);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder80 = node78.new FileLevelJsDocBuilder();
        java.lang.String str84 = node78.toString(false, false, false);
        com.google.javascript.jscomp.CodingConvention.SubclassRelationship subclassRelationship85 = closureCodingConvention41.getClassesDefinedByCall(node78);
        java.lang.String str86 = closureCodingConvention4.extractClassNameIfProvide(node15, node78);
        java.lang.String str87 = closureCodingConvention0.getSingletonGetterClassName(node78);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "goog.exportProperty" + "'", str1.equals("goog.exportProperty"));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNull(jSType28);
        org.junit.Assert.assertNotNull(node33);
        org.junit.Assert.assertNotNull(nodeArray36);
        org.junit.Assert.assertNotNull(node40);
        org.junit.Assert.assertNotNull(node54);
        org.junit.Assert.assertNotNull(node62);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertNull(jSType67);
        org.junit.Assert.assertNotNull(node72);
        org.junit.Assert.assertNotNull(nodeArray75);
        org.junit.Assert.assertNotNull(node79);
        org.junit.Assert.assertTrue("'" + str84 + "' != '" + "BITXOR" + "'", str84.equals("BITXOR"));
        org.junit.Assert.assertNull(subclassRelationship85);
        org.junit.Assert.assertNull(str86);
        org.junit.Assert.assertNull(str87);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newNumber((double) 'a', (int) (byte) 1, 0);
        node3.setDouble((double) 42);
        org.junit.Assert.assertNotNull(node3);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        com.google.javascript.rhino.Node[] nodeArray2 = new com.google.javascript.rhino.Node[] {};
        com.google.javascript.rhino.Node node5 = new com.google.javascript.rhino.Node(11, nodeArray2, 0, 0);
        com.google.javascript.rhino.Node node8 = new com.google.javascript.rhino.Node(4, nodeArray2, 15, 26);
        org.junit.Assert.assertNotNull(nodeArray2);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeUnusedLocalVars = false;
        compilerOptions0.crossModuleCodeMotion = false;
        com.google.javascript.jscomp.CompilerOptions compilerOptions5 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions5.devirtualizePrototypeMethods = false;
        java.util.Set<java.lang.String> strSet8 = compilerOptions5.stripNameSuffixes;
        compilerOptions0.stripNamePrefixes = strSet8;
        compilerOptions0.labelRenaming = true;
        boolean boolean12 = compilerOptions0.deadAssignmentElimination;
        org.junit.Assert.assertNotNull(strSet8);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.jstype.FunctionType functionType1 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType2 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType3 = null;
        closureCodingConvention0.applySubclassRelationship(functionType1, functionType2, subclassType3);
        com.google.javascript.rhino.jstype.FunctionType functionType5 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType6 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType7 = null;
        closureCodingConvention0.applySubclassRelationship(functionType5, functionType6, subclassType7);
        java.lang.String str9 = closureCodingConvention0.getGlobalObject();
        boolean boolean11 = closureCodingConvention0.isPrivate("goog.exportSymbol");
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry12 = null;
        com.google.javascript.jscomp.Scope scope13 = null;
        com.google.javascript.rhino.jstype.ObjectType[] objectTypeArray14 = new com.google.javascript.rhino.jstype.ObjectType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.ObjectType> objectTypeList15 = new java.util.ArrayList<com.google.javascript.rhino.jstype.ObjectType>();
        boolean boolean16 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.ObjectType>) objectTypeList15, objectTypeArray14);
        closureCodingConvention0.defineDelegateProxyPrototypeProperties(jSTypeRegistry12, scope13, (java.util.List<com.google.javascript.rhino.jstype.ObjectType>) objectTypeList15);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "goog.global" + "'", str9.equals("goog.global"));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(objectTypeArray14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        java.lang.String str1 = com.google.javascript.rhino.ScriptRuntime.escapeString("Unknown class name");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Unknown class name" + "'", str1.equals("Unknown class name"));
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.INVALID_CASTS;
        com.google.javascript.jscomp.DiagnosticGroups.CHECK_VARIABLES = diagnosticGroup0;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.CHECK_REGEXP;
        com.google.javascript.jscomp.DiagnosticGroups.DEPRECATED = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticGroups.TYPE_INVALIDATION = diagnosticGroup0;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.devirtualizePrototypeMethods = false;
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy3 = com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC;
        compilerOptions0.propertyRenaming = propertyRenamingPolicy3;
        boolean boolean5 = compilerOptions0.recordFunctionInformation;
        compilerOptions0.setColorizeErrorOutput(false);
        boolean boolean8 = compilerOptions0.specializeInitialModule;
        compilerOptions0.computeFunctionSideEffects = false;
        compilerOptions0.setDefineToNumberLiteral("language version", 37);
        boolean boolean14 = compilerOptions0.markAsCompiled;
        compilerOptions0.ambiguateProperties = true;
        compilerOptions0.flowSensitiveInlineVariables = true;
        com.google.javascript.jscomp.CheckLevel checkLevel19 = compilerOptions0.brokenClosureRequiresLevel;
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy3 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC + "'", propertyRenamingPolicy3.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + checkLevel19 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel19.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention1 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.jstype.FunctionType functionType2 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType3 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType4 = null;
        closureCodingConvention1.applySubclassRelationship(functionType2, functionType3, subclassType4);
        com.google.javascript.rhino.jstype.FunctionType functionType6 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType7 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType8 = null;
        closureCodingConvention1.applySubclassRelationship(functionType6, functionType7, subclassType8);
        com.google.javascript.rhino.jstype.FunctionType functionType10 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType11 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType12 = null;
        closureCodingConvention1.applySubclassRelationship(functionType10, functionType11, subclassType12);
        com.google.javascript.rhino.jstype.FunctionType functionType14 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType15 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType16 = null;
        closureCodingConvention1.applySubclassRelationship(functionType14, functionType15, subclassType16);
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        com.google.javascript.rhino.JSDocInfo jSDocInfo24 = null;
        node23.setJSDocInfo(jSDocInfo24);
        java.lang.RuntimeException runtimeException27 = com.google.javascript.rhino.ScriptRuntime.undefReadError((java.lang.Object) node23, (java.lang.Object) 22);
        node23.detachChildren();
        com.google.javascript.rhino.Node node29 = new com.google.javascript.rhino.Node((int) (short) 100, node23);
        com.google.javascript.rhino.JSDocInfo jSDocInfo30 = null;
        node29.setJSDocInfo(jSDocInfo30);
        java.lang.String str32 = closureCodingConvention1.identifyTypeDefAssign(node29);
        com.google.javascript.jscomp.CompilerOptions compilerOptions33 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions33.devirtualizePrototypeMethods = false;
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy36 = com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC;
        compilerOptions33.propertyRenaming = propertyRenamingPolicy36;
        boolean boolean38 = compilerOptions33.recordFunctionInformation;
        compilerOptions33.optimizeArgumentsArray = false;
        com.google.javascript.jscomp.DiagnosticType diagnosticType41 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        com.google.javascript.jscomp.CheckLevel checkLevel42 = diagnosticType41.defaultLevel;
        compilerOptions33.checkMethods = checkLevel42;
        com.google.javascript.jscomp.CheckLevel checkLevel44 = compilerOptions33.checkRequires;
        compilerOptions33.setRewriteNewDateGoogNow(true);
        compilerOptions33.skipAllCompilerPasses();
        compilerOptions33.setDefineToNumberLiteral("", 2);
        com.google.javascript.jscomp.CompilerOptions.TracerMode tracerMode51 = com.google.javascript.jscomp.CompilerOptions.TracerMode.FAST;
        compilerOptions33.tracer = tracerMode51;
        java.io.PrintStream printStream53 = null;
        com.google.javascript.jscomp.Compiler compiler54 = new com.google.javascript.jscomp.Compiler(printStream53);
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray55 = new com.google.javascript.jscomp.JSSourceFile[] {};
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray56 = new com.google.javascript.jscomp.JSSourceFile[] {};
        com.google.javascript.jscomp.CompilerOptions compilerOptions57 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions57.devirtualizePrototypeMethods = false;
        compilerOptions57.groupVariableDeclarations = false;
        boolean boolean62 = compilerOptions57.ideMode;
        compilerOptions57.setProcessObjectPropertyString(true);
        compilerOptions57.setDefineToBooleanLiteral("BITXOR", true);
        compilerOptions57.checkControlStructures = true;
        java.util.Map<java.lang.String, com.google.javascript.rhino.Node> strMap70 = compilerOptions57.getTweakReplacements();
        com.google.javascript.jscomp.Result result71 = compiler54.compile(jSSourceFileArray55, jSSourceFileArray56, compilerOptions57);
        compiler54.processDefines();
        com.google.javascript.jscomp.CompilerOptions compilerOptions73 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions73.debugFunctionSideEffectsPath = "";
        compilerOptions73.checkSuspiciousCode = true;
        boolean boolean78 = compilerOptions73.shouldColorizeErrorOutput();
        try {
            java.lang.String str79 = com.google.javascript.rhino.ScriptRuntime.getMessage4("Not declared as a constructor", (java.lang.Object) closureCodingConvention1, (java.lang.Object) compilerOptions33, (java.lang.Object) compiler54, (java.lang.Object) boolean78);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property Not declared as a constructor");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(runtimeException27);
        org.junit.Assert.assertNull(str32);
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy36 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC + "'", propertyRenamingPolicy36.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC));
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(diagnosticType41);
        org.junit.Assert.assertTrue("'" + checkLevel42 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel42.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + checkLevel44 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel44.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + tracerMode51 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TracerMode.FAST + "'", tracerMode51.equals(com.google.javascript.jscomp.CompilerOptions.TracerMode.FAST));
        org.junit.Assert.assertNotNull(jSSourceFileArray55);
        org.junit.Assert.assertNotNull(jSSourceFileArray56);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertNotNull(strMap70);
        org.junit.Assert.assertNotNull(result71);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.jstype.FunctionType functionType1 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType2 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType3 = null;
        closureCodingConvention0.applySubclassRelationship(functionType1, functionType2, subclassType3);
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        boolean boolean10 = node9.hasMoreThanOneChild();
        node9.setLineno(0);
        com.google.javascript.rhino.Node node13 = node9.cloneTree();
        com.google.javascript.rhino.Node node14 = node13.removeFirstChild();
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        node19.removeProp((int) (short) 1);
        com.google.javascript.rhino.Node node27 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        boolean boolean28 = node27.hasMoreThanOneChild();
        node27.setLineno(0);
        boolean boolean31 = node27.hasOneChild();
        com.google.javascript.rhino.jstype.JSType jSType32 = node27.getJSType();
        com.google.javascript.rhino.Node node37 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        node37.removeProp((int) (short) 1);
        com.google.javascript.rhino.Node[] nodeArray40 = new com.google.javascript.rhino.Node[] { node27, node37 };
        com.google.javascript.rhino.Node node43 = new com.google.javascript.rhino.Node((int) (byte) 10, nodeArray40, (int) '4', (int) (byte) -1);
        com.google.javascript.rhino.Node node44 = node19.copyInformationFromForTree(node43);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder45 = node43.new FileLevelJsDocBuilder();
        java.lang.String str49 = node43.toString(false, false, false);
        boolean boolean50 = node43.isUnscopedQualifiedName();
        int int51 = node43.getLineno();
        java.lang.String str52 = closureCodingConvention0.extractClassNameIfProvide(node13, node43);
        com.google.javascript.rhino.Node node53 = node13.removeFirstChild();
        try {
            com.google.javascript.rhino.Node node55 = node13.getChildAtIndex(12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNull(node14);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNotNull(node27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNull(jSType32);
        org.junit.Assert.assertNotNull(node37);
        org.junit.Assert.assertNotNull(nodeArray40);
        org.junit.Assert.assertNotNull(node44);
        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "BITXOR" + "'", str49.equals("BITXOR"));
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + (-1) + "'", int51 == (-1));
        org.junit.Assert.assertNull(str52);
        org.junit.Assert.assertNull(node53);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = null;
        com.google.javascript.jscomp.CompilerOptions compilerOptions1 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions1.devirtualizePrototypeMethods = false;
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy4 = com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC;
        compilerOptions1.propertyRenaming = propertyRenamingPolicy4;
        boolean boolean6 = compilerOptions1.recordFunctionInformation;
        compilerOptions1.optimizeArgumentsArray = false;
        com.google.javascript.jscomp.DiagnosticType diagnosticType9 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        com.google.javascript.jscomp.CheckLevel checkLevel10 = diagnosticType9.defaultLevel;
        compilerOptions1.checkMethods = checkLevel10;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard12 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup0, checkLevel10);
        java.lang.String str13 = diagnosticGroupWarningsGuard12.toString();
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup14 = null;
        try {
            boolean boolean15 = diagnosticGroupWarningsGuard12.enables(diagnosticGroup14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy4 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC + "'", propertyRenamingPolicy4.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(diagnosticType9);
        org.junit.Assert.assertTrue("'" + checkLevel10 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel10.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "null(ERROR)" + "'", str13.equals("null(ERROR)"));
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        boolean boolean5 = node4.hasMoreThanOneChild();
        node4.setLineno(0);
        boolean boolean8 = node4.hasOneChild();
        com.google.javascript.rhino.jstype.JSType jSType9 = node4.getJSType();
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        node14.removeProp((int) (short) 1);
        com.google.javascript.rhino.Node node22 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        boolean boolean23 = node22.hasMoreThanOneChild();
        node22.setLineno(0);
        boolean boolean26 = node22.hasOneChild();
        com.google.javascript.rhino.jstype.JSType jSType27 = node22.getJSType();
        com.google.javascript.rhino.Node node32 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        node32.removeProp((int) (short) 1);
        com.google.javascript.rhino.Node[] nodeArray35 = new com.google.javascript.rhino.Node[] { node22, node32 };
        com.google.javascript.rhino.Node node38 = new com.google.javascript.rhino.Node((int) (byte) 10, nodeArray35, (int) '4', (int) (byte) -1);
        com.google.javascript.rhino.Node node39 = node14.copyInformationFromForTree(node38);
        boolean boolean40 = node14.hasChildren();
        com.google.javascript.rhino.Node node41 = node14.removeFirstChild();
        com.google.javascript.rhino.Node node46 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        boolean boolean47 = node46.hasMoreThanOneChild();
        node46.setLineno(0);
        com.google.javascript.rhino.Node node50 = node46.cloneTree();
        com.google.javascript.rhino.Node node55 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        node55.removeProp((int) (short) 1);
        com.google.javascript.rhino.Node node63 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        boolean boolean64 = node63.hasMoreThanOneChild();
        node63.setLineno(0);
        boolean boolean67 = node63.hasOneChild();
        com.google.javascript.rhino.jstype.JSType jSType68 = node63.getJSType();
        com.google.javascript.rhino.Node node73 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        node73.removeProp((int) (short) 1);
        com.google.javascript.rhino.Node[] nodeArray76 = new com.google.javascript.rhino.Node[] { node63, node73 };
        com.google.javascript.rhino.Node node79 = new com.google.javascript.rhino.Node((int) (byte) 10, nodeArray76, (int) '4', (int) (byte) -1);
        com.google.javascript.rhino.Node node80 = node55.copyInformationFromForTree(node79);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder81 = node79.new FileLevelJsDocBuilder();
        java.lang.String str85 = node79.toString(false, false, false);
        node46.addChildrenToBack(node79);
        node4.addChildAfter(node14, node79);
        com.google.javascript.rhino.JSDocInfo jSDocInfo88 = node4.getJSDocInfo();
        node4.setOptionalArg(false);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNull(jSType9);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNull(jSType27);
        org.junit.Assert.assertNotNull(node32);
        org.junit.Assert.assertNotNull(nodeArray35);
        org.junit.Assert.assertNotNull(node39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNull(node41);
        org.junit.Assert.assertNotNull(node46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(node50);
        org.junit.Assert.assertNotNull(node55);
        org.junit.Assert.assertNotNull(node63);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
        org.junit.Assert.assertNull(jSType68);
        org.junit.Assert.assertNotNull(node73);
        org.junit.Assert.assertNotNull(nodeArray76);
        org.junit.Assert.assertNotNull(node80);
        org.junit.Assert.assertTrue("'" + str85 + "' != '" + "BITXOR" + "'", str85.equals("BITXOR"));
        org.junit.Assert.assertNull(jSDocInfo88);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.INTERNET_EXPLORER_CHECKS;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        com.google.javascript.jscomp.SourceFile sourceFile1 = com.google.javascript.jscomp.SourceFile.fromFile("hi!");
        java.lang.String str2 = sourceFile1.getName();
        org.junit.Assert.assertNotNull(sourceFile1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hi!" + "'", str2.equals("hi!"));
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.devirtualizePrototypeMethods = false;
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy3 = com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC;
        compilerOptions0.propertyRenaming = propertyRenamingPolicy3;
        boolean boolean5 = compilerOptions0.recordFunctionInformation;
        compilerOptions0.optimizeArgumentsArray = false;
        com.google.javascript.jscomp.DiagnosticType diagnosticType8 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        com.google.javascript.jscomp.CheckLevel checkLevel9 = diagnosticType8.defaultLevel;
        compilerOptions0.checkMethods = checkLevel9;
        com.google.javascript.jscomp.CheckLevel checkLevel11 = compilerOptions0.checkRequires;
        compilerOptions0.setRewriteNewDateGoogNow(true);
        compilerOptions0.skipAllCompilerPasses();
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy15 = compilerOptions0.propertyRenaming;
        java.util.Set<java.lang.String> strSet16 = compilerOptions0.aliasableStrings;
        com.google.javascript.rhino.Node node21 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        com.google.javascript.rhino.JSDocInfo jSDocInfo22 = null;
        node21.setJSDocInfo(jSDocInfo22);
        java.lang.RuntimeException runtimeException25 = com.google.javascript.rhino.ScriptRuntime.undefReadError((java.lang.Object) node21, (java.lang.Object) 22);
        node21.detachChildren();
        java.lang.String[] strArray32 = new java.lang.String[] { "error reporter", "hi!", "BITXOR", "error reporter", "BITXOR" };
        java.util.LinkedHashSet<java.lang.String> strSet33 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean34 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet33, strArray32);
        node21.setDirectives((java.util.Set<java.lang.String>) strSet33);
        compilerOptions0.stripNamePrefixes = strSet33;
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy3 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC + "'", propertyRenamingPolicy3.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(diagnosticType8);
        org.junit.Assert.assertTrue("'" + checkLevel9 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel9.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + checkLevel11 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel11.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy15 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC + "'", propertyRenamingPolicy15.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC));
        org.junit.Assert.assertNotNull(strSet16);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertNotNull(runtimeException25);
        org.junit.Assert.assertNotNull(strArray32);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        com.google.javascript.rhino.Context context0 = new com.google.javascript.rhino.Context();
        com.google.javascript.jscomp.AnonymousFunctionNamingPolicy anonymousFunctionNamingPolicy1 = com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.UNMAPPED;
        context0.removeThreadLocal((java.lang.Object) anonymousFunctionNamingPolicy1);
        boolean boolean3 = context0.isGeneratingDebug();
        boolean boolean4 = context0.hasCompileFunctionsWithDynamicScope();
        int int5 = context0.getLanguageVersion();
        org.junit.Assert.assertTrue("'" + anonymousFunctionNamingPolicy1 + "' != '" + com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.UNMAPPED + "'", anonymousFunctionNamingPolicy1.equals(com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.UNMAPPED));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        boolean boolean5 = node4.hasMoreThanOneChild();
        node4.setLineno(0);
        com.google.javascript.rhino.Node node8 = node4.cloneTree();
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        node13.removeProp((int) (short) 1);
        com.google.javascript.rhino.Node node21 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        boolean boolean22 = node21.hasMoreThanOneChild();
        node21.setLineno(0);
        boolean boolean25 = node21.hasOneChild();
        com.google.javascript.rhino.jstype.JSType jSType26 = node21.getJSType();
        com.google.javascript.rhino.Node node31 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        node31.removeProp((int) (short) 1);
        com.google.javascript.rhino.Node[] nodeArray34 = new com.google.javascript.rhino.Node[] { node21, node31 };
        com.google.javascript.rhino.Node node37 = new com.google.javascript.rhino.Node((int) (byte) 10, nodeArray34, (int) '4', (int) (byte) -1);
        com.google.javascript.rhino.Node node38 = node13.copyInformationFromForTree(node37);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder39 = node37.new FileLevelJsDocBuilder();
        java.lang.String str43 = node37.toString(false, false, false);
        node4.addChildrenToBack(node37);
        com.google.javascript.rhino.Node node45 = null;
        boolean boolean46 = node37.hasChild(node45);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNull(jSType26);
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertNotNull(nodeArray34);
        org.junit.Assert.assertNotNull(node38);
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "BITXOR" + "'", str43.equals("BITXOR"));
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.devirtualizePrototypeMethods = false;
        compilerOptions0.groupVariableDeclarations = false;
        boolean boolean5 = compilerOptions0.crossModuleCodeMotion;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap6 = null;
        compilerOptions0.cssRenamingMap = cssRenamingMap6;
        byte[] byteArray8 = compilerOptions0.inputPropertyMapSerialized;
        compilerOptions0.setTweakToDoubleLiteral("", (double) 16);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(byteArray8);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.devirtualizePrototypeMethods = false;
        compilerOptions0.groupVariableDeclarations = false;
        compilerOptions0.setChainCalls(true);
        compilerOptions0.reportPath = "error reporter";
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        int int0 = com.google.javascript.rhino.Context.FEATURE_STRICT_VARS;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 8 + "'", int0 == 8);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.UNKNOWN_DEFINES;
        com.google.javascript.jscomp.DiagnosticGroups.INVALID_CASTS = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticGroups.GLOBAL_THIS = diagnosticGroup0;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        int int0 = com.google.javascript.rhino.Node.SPECIAL_PROP_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 18 + "'", int0 == 18);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        boolean boolean5 = node4.hasMoreThanOneChild();
        node4.setLineno(0);
        com.google.javascript.rhino.Node node8 = node4.cloneTree();
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        node13.removeProp((int) (short) 1);
        com.google.javascript.rhino.Node node21 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        boolean boolean22 = node21.hasMoreThanOneChild();
        node21.setLineno(0);
        boolean boolean25 = node21.hasOneChild();
        com.google.javascript.rhino.jstype.JSType jSType26 = node21.getJSType();
        com.google.javascript.rhino.Node node31 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        node31.removeProp((int) (short) 1);
        com.google.javascript.rhino.Node[] nodeArray34 = new com.google.javascript.rhino.Node[] { node21, node31 };
        com.google.javascript.rhino.Node node37 = new com.google.javascript.rhino.Node((int) (byte) 10, nodeArray34, (int) '4', (int) (byte) -1);
        com.google.javascript.rhino.Node node38 = node13.copyInformationFromForTree(node37);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder39 = node37.new FileLevelJsDocBuilder();
        java.lang.String str43 = node37.toString(false, false, false);
        node4.addChildrenToBack(node37);
        boolean boolean45 = node37.wasEmptyNode();
        com.google.javascript.rhino.Node node50 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        com.google.javascript.rhino.JSDocInfo jSDocInfo51 = null;
        node50.setJSDocInfo(jSDocInfo51);
        boolean boolean53 = node37.isEquivalentTo(node50);
        int int55 = node50.getIntProp(26);
        com.google.javascript.rhino.Node node56 = node50.getParent();
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNull(jSType26);
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertNotNull(nodeArray34);
        org.junit.Assert.assertNotNull(node38);
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "BITXOR" + "'", str43.equals("BITXOR"));
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(node50);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 0 + "'", int55 == 0);
        org.junit.Assert.assertNull(node56);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.devirtualizePrototypeMethods = false;
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy3 = com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC;
        compilerOptions0.propertyRenaming = propertyRenamingPolicy3;
        compilerOptions0.disableRuntimeTypeCheck();
        boolean boolean6 = compilerOptions0.allowLegacyJsMessages;
        compilerOptions0.groupVariableDeclarations = false;
        boolean boolean9 = compilerOptions0.isExternExportsEnabled();
        compilerOptions0.enableRuntimeTypeCheck("goog.exportSymbol");
        com.google.javascript.jscomp.CompilerOptions compilerOptions12 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions12.devirtualizePrototypeMethods = false;
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy15 = com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC;
        compilerOptions12.propertyRenaming = propertyRenamingPolicy15;
        boolean boolean17 = compilerOptions12.recordFunctionInformation;
        compilerOptions12.enableExternExports(false);
        byte[] byteArray23 = new byte[] { (byte) -1, (byte) 1, (byte) 10 };
        compilerOptions12.inputVariableMapSerialized = byteArray23;
        compilerOptions0.inputPropertyMapSerialized = byteArray23;
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy3 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC + "'", propertyRenamingPolicy3.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy15 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC + "'", propertyRenamingPolicy15.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(byteArray23);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.devirtualizePrototypeMethods = false;
        compilerOptions0.groupVariableDeclarations = false;
        boolean boolean5 = compilerOptions0.ideMode;
        compilerOptions0.setProcessObjectPropertyString(true);
        compilerOptions0.removeUnusedLocalVars = false;
        compilerOptions0.locale = "hi!";
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.jstype.FunctionType functionType1 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType2 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType3 = null;
        closureCodingConvention0.applySubclassRelationship(functionType1, functionType2, subclassType3);
        boolean boolean6 = closureCodingConvention0.isSuperClassReference("");
        java.lang.String str7 = closureCodingConvention0.getAbstractMethodName();
        java.lang.String str8 = closureCodingConvention0.getExportPropertyFunction();
        java.lang.String str9 = closureCodingConvention0.getDelegateSuperclassName();
        com.google.javascript.rhino.jstype.FunctionType functionType10 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType11 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType12 = null;
        closureCodingConvention0.applySubclassRelationship(functionType10, functionType11, subclassType12);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "goog.abstractMethod" + "'", str7.equals("goog.abstractMethod"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "goog.exportProperty" + "'", str8.equals("goog.exportProperty"));
        org.junit.Assert.assertNull(str9);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = null;
        com.google.javascript.jscomp.DiagnosticGroups.AMBIGUOUS_FUNCTION_DECL = diagnosticGroup0;
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.devirtualizePrototypeMethods = false;
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy3 = com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC;
        compilerOptions0.propertyRenaming = propertyRenamingPolicy3;
        boolean boolean5 = compilerOptions0.recordFunctionInformation;
        java.util.Set<java.lang.String> strSet6 = compilerOptions0.stripTypes;
        compilerOptions0.deadAssignmentElimination = true;
        compilerOptions0.generateExports = false;
        compilerOptions0.generatePseudoNames = true;
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy3 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC + "'", propertyRenamingPolicy3.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(strSet6);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray2 = new com.google.javascript.jscomp.JSSourceFile[] {};
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray3 = new com.google.javascript.jscomp.JSSourceFile[] {};
        com.google.javascript.jscomp.CompilerOptions compilerOptions4 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions4.devirtualizePrototypeMethods = false;
        compilerOptions4.groupVariableDeclarations = false;
        boolean boolean9 = compilerOptions4.ideMode;
        compilerOptions4.setProcessObjectPropertyString(true);
        compilerOptions4.setDefineToBooleanLiteral("BITXOR", true);
        compilerOptions4.checkControlStructures = true;
        java.util.Map<java.lang.String, com.google.javascript.rhino.Node> strMap17 = compilerOptions4.getTweakReplacements();
        com.google.javascript.jscomp.Result result18 = compiler1.compile(jSSourceFileArray2, jSSourceFileArray3, compilerOptions4);
        boolean boolean19 = compiler1.acceptConstKeyword();
        compiler1.processDefines();
        org.junit.Assert.assertNotNull(jSSourceFileArray2);
        org.junit.Assert.assertNotNull(jSSourceFileArray3);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(strMap17);
        org.junit.Assert.assertNotNull(result18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        com.google.javascript.jscomp.DiagnosticType diagnosticType3 = com.google.javascript.jscomp.Compiler.MOTION_ITERATIONS_ERROR;
        java.lang.String[] strArray10 = new java.lang.String[] { "<unknown=160>", "<unknown=160>", "<unknown=160>", "<unknown=160>", "BITXOR", "DiagnosticGroup<undefinedVars>" };
        com.google.javascript.jscomp.JSError jSError11 = com.google.javascript.jscomp.JSError.make("BITXOR", 32, (int) (short) 100, diagnosticType3, strArray10);
        com.google.javascript.jscomp.DiagnosticType diagnosticType12 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        com.google.javascript.jscomp.CheckLevel checkLevel13 = diagnosticType12.level;
        int int14 = diagnosticType3.compareTo(diagnosticType12);
        com.google.javascript.jscomp.DiagnosticType diagnosticType17 = com.google.javascript.jscomp.DiagnosticType.disabled("0", "");
        int int18 = diagnosticType3.compareTo(diagnosticType17);
        org.junit.Assert.assertNotNull(diagnosticType3);
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertNotNull(jSError11);
        org.junit.Assert.assertNotNull(diagnosticType12);
        org.junit.Assert.assertTrue("'" + checkLevel13 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel13.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertNotNull(diagnosticType17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 26 + "'", int18 == 26);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newNumber((double) 2);
        org.junit.Assert.assertNotNull(node1);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        com.google.javascript.jscomp.parsing.Config.LanguageMode languageMode3 = com.google.javascript.jscomp.parsing.Config.LanguageMode.ECMASCRIPT3;
        com.google.javascript.jscomp.parsing.Config config5 = com.google.javascript.jscomp.parsing.ParserRunner.createConfig(true, languageMode3, false);
        com.google.javascript.jscomp.mozilla.rhino.ErrorReporter errorReporter6 = null;
        java.util.logging.Logger logger7 = null;
        try {
            com.google.javascript.rhino.Node node8 = com.google.javascript.jscomp.parsing.ParserRunner.parse("goog.abstractMethod", "<unknown=160>", config5, errorReporter6, logger7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + languageMode3 + "' != '" + com.google.javascript.jscomp.parsing.Config.LanguageMode.ECMASCRIPT3 + "'", languageMode3.equals(com.google.javascript.jscomp.parsing.Config.LanguageMode.ECMASCRIPT3));
        org.junit.Assert.assertNotNull(config5);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        com.google.javascript.jscomp.DiagnosticType diagnosticType2 = com.google.javascript.jscomp.DiagnosticType.warning("Unknown class name", "<unknown=160>");
        org.junit.Assert.assertNotNull(diagnosticType2);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        boolean boolean5 = node4.hasMoreThanOneChild();
        node4.setLineno(0);
        boolean boolean8 = node4.hasOneChild();
        com.google.javascript.rhino.jstype.JSType jSType9 = node4.getJSType();
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        node14.removeProp((int) (short) 1);
        com.google.javascript.rhino.Node node22 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        boolean boolean23 = node22.hasMoreThanOneChild();
        node22.setLineno(0);
        boolean boolean26 = node22.hasOneChild();
        com.google.javascript.rhino.jstype.JSType jSType27 = node22.getJSType();
        com.google.javascript.rhino.Node node32 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        node32.removeProp((int) (short) 1);
        com.google.javascript.rhino.Node[] nodeArray35 = new com.google.javascript.rhino.Node[] { node22, node32 };
        com.google.javascript.rhino.Node node38 = new com.google.javascript.rhino.Node((int) (byte) 10, nodeArray35, (int) '4', (int) (byte) -1);
        com.google.javascript.rhino.Node node39 = node14.copyInformationFromForTree(node38);
        boolean boolean40 = node14.hasChildren();
        com.google.javascript.rhino.Node node41 = node14.removeFirstChild();
        com.google.javascript.rhino.Node node46 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        boolean boolean47 = node46.hasMoreThanOneChild();
        node46.setLineno(0);
        com.google.javascript.rhino.Node node50 = node46.cloneTree();
        com.google.javascript.rhino.Node node55 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        node55.removeProp((int) (short) 1);
        com.google.javascript.rhino.Node node63 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        boolean boolean64 = node63.hasMoreThanOneChild();
        node63.setLineno(0);
        boolean boolean67 = node63.hasOneChild();
        com.google.javascript.rhino.jstype.JSType jSType68 = node63.getJSType();
        com.google.javascript.rhino.Node node73 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        node73.removeProp((int) (short) 1);
        com.google.javascript.rhino.Node[] nodeArray76 = new com.google.javascript.rhino.Node[] { node63, node73 };
        com.google.javascript.rhino.Node node79 = new com.google.javascript.rhino.Node((int) (byte) 10, nodeArray76, (int) '4', (int) (byte) -1);
        com.google.javascript.rhino.Node node80 = node55.copyInformationFromForTree(node79);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder81 = node79.new FileLevelJsDocBuilder();
        java.lang.String str85 = node79.toString(false, false, false);
        node46.addChildrenToBack(node79);
        node4.addChildAfter(node14, node79);
        com.google.javascript.rhino.JSDocInfo jSDocInfo88 = node4.getJSDocInfo();
        boolean boolean89 = node4.isUnscopedQualifiedName();
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNull(jSType9);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNull(jSType27);
        org.junit.Assert.assertNotNull(node32);
        org.junit.Assert.assertNotNull(nodeArray35);
        org.junit.Assert.assertNotNull(node39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNull(node41);
        org.junit.Assert.assertNotNull(node46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(node50);
        org.junit.Assert.assertNotNull(node55);
        org.junit.Assert.assertNotNull(node63);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
        org.junit.Assert.assertNull(jSType68);
        org.junit.Assert.assertNotNull(node73);
        org.junit.Assert.assertNotNull(nodeArray76);
        org.junit.Assert.assertNotNull(node80);
        org.junit.Assert.assertTrue("'" + str85 + "' != '" + "BITXOR" + "'", str85.equals("BITXOR"));
        org.junit.Assert.assertNull(jSDocInfo88);
        org.junit.Assert.assertTrue("'" + boolean89 + "' != '" + false + "'", boolean89 == false);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.devirtualizePrototypeMethods = false;
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy3 = com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC;
        compilerOptions0.propertyRenaming = propertyRenamingPolicy3;
        boolean boolean5 = compilerOptions0.recordFunctionInformation;
        compilerOptions0.aliasAllStrings = false;
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy3 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC + "'", propertyRenamingPolicy3.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        com.google.javascript.rhino.Context context0 = new com.google.javascript.rhino.Context();
        com.google.javascript.jscomp.AnonymousFunctionNamingPolicy anonymousFunctionNamingPolicy1 = com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.UNMAPPED;
        context0.removeThreadLocal((java.lang.Object) anonymousFunctionNamingPolicy1);
        long long3 = com.google.javascript.rhino.ScriptRuntime.lastUint32Result(context0);
        context0.setInstructionObserverThreshold((int) (byte) 100);
        boolean boolean7 = context0.isActivationNeeded("");
        int int8 = context0.getOptimizationLevel();
        org.junit.Assert.assertTrue("'" + anonymousFunctionNamingPolicy1 + "' != '" + com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.UNMAPPED + "'", anonymousFunctionNamingPolicy1.equals(com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.UNMAPPED));
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CodingConvention codingConvention1 = compilerOptions0.getCodingConvention();
        compilerOptions0.setOutputCharset("JSC_OPTIMIZE_LOOP_ERROR");
        org.junit.Assert.assertNull(codingConvention1);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        node5.removeProp((int) (short) 1);
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        boolean boolean14 = node13.hasMoreThanOneChild();
        node13.setLineno(0);
        boolean boolean17 = node13.hasOneChild();
        com.google.javascript.rhino.jstype.JSType jSType18 = node13.getJSType();
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        node23.removeProp((int) (short) 1);
        com.google.javascript.rhino.Node[] nodeArray26 = new com.google.javascript.rhino.Node[] { node13, node23 };
        com.google.javascript.rhino.Node node29 = new com.google.javascript.rhino.Node((int) (byte) 10, nodeArray26, (int) '4', (int) (byte) -1);
        com.google.javascript.rhino.Node node30 = node5.copyInformationFromForTree(node29);
        boolean boolean31 = node5.hasChildren();
        com.google.javascript.rhino.Node node33 = node5.getChildAtIndex((int) (short) 0);
        com.google.javascript.jscomp.DiagnosticType diagnosticType36 = com.google.javascript.jscomp.DiagnosticType.error("goog.exportProperty", "hi!");
        com.google.javascript.jscomp.CheckLevel checkLevel37 = diagnosticType36.level;
        com.google.javascript.jscomp.DiagnosticType diagnosticType38 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        com.google.javascript.jscomp.CheckLevel checkLevel39 = diagnosticType38.defaultLevel;
        java.lang.String[] strArray44 = new java.lang.String[] { "hi!", "goog.exportProperty", "<unknown=160>", "goog.global" };
        com.google.javascript.jscomp.JSError jSError45 = com.google.javascript.jscomp.JSError.make(diagnosticType38, strArray44);
        com.google.javascript.jscomp.JSError jSError46 = com.google.javascript.jscomp.JSError.make("0", node5, diagnosticType36, strArray44);
        com.google.javascript.jscomp.CheckLevel checkLevel47 = diagnosticType36.level;
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNull(jSType18);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(nodeArray26);
        org.junit.Assert.assertNotNull(node30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNull(node33);
        org.junit.Assert.assertNotNull(diagnosticType36);
        org.junit.Assert.assertTrue("'" + checkLevel37 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel37.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticType38);
        org.junit.Assert.assertTrue("'" + checkLevel39 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel39.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(strArray44);
        org.junit.Assert.assertNotNull(jSError45);
        org.junit.Assert.assertNotNull(jSError46);
        org.junit.Assert.assertTrue("'" + checkLevel47 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel47.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.devirtualizePrototypeMethods = false;
        java.util.Set<java.lang.String> strSet3 = compilerOptions0.stripNameSuffixes;
        com.google.javascript.jscomp.SourceMap.DetailLevel detailLevel4 = null;
        compilerOptions0.sourceMapDetailLevel = detailLevel4;
        compilerOptions0.devirtualizePrototypeMethods = false;
        org.junit.Assert.assertNotNull(strSet3);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.devirtualizePrototypeMethods = false;
        compilerOptions0.groupVariableDeclarations = false;
        boolean boolean5 = compilerOptions0.crossModuleCodeMotion;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap6 = null;
        compilerOptions0.cssRenamingMap = cssRenamingMap6;
        byte[] byteArray8 = compilerOptions0.inputPropertyMapSerialized;
        com.google.javascript.jscomp.CompilerOptions compilerOptions9 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions9.devirtualizePrototypeMethods = false;
        boolean boolean12 = compilerOptions9.ambiguateProperties;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy13 = com.google.javascript.jscomp.VariableRenamingPolicy.UNSPECIFIED;
        compilerOptions9.variableRenaming = variableRenamingPolicy13;
        boolean boolean15 = compilerOptions9.gatherCssNames;
        com.google.javascript.jscomp.DiagnosticType diagnosticType16 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        com.google.javascript.jscomp.CheckLevel checkLevel17 = diagnosticType16.level;
        compilerOptions9.reportMissingOverride = checkLevel17;
        compilerOptions0.checkFunctions = checkLevel17;
        com.google.javascript.jscomp.SourceMap.DetailLevel detailLevel20 = compilerOptions0.sourceMapDetailLevel;
        com.google.javascript.jscomp.CodingConvention codingConvention21 = compilerOptions0.getCodingConvention();
        compilerOptions0.enableRuntimeTypeCheck("goog.exportSymbol");
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(byteArray8);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy13 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.UNSPECIFIED + "'", variableRenamingPolicy13.equals(com.google.javascript.jscomp.VariableRenamingPolicy.UNSPECIFIED));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(diagnosticType16);
        org.junit.Assert.assertTrue("'" + checkLevel17 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel17.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(detailLevel20);
        org.junit.Assert.assertNull(codingConvention21);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile1 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.CompilerInput compilerInput2 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile1);
        com.google.javascript.jscomp.JSModule jSModule3 = null;
        compilerInput2.setModule(jSModule3);
        com.google.javascript.jscomp.CompilerInput compilerInput6 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput2, false);
        com.google.javascript.jscomp.Region region8 = compilerInput6.getRegion(32);
        java.lang.String str9 = compilerInput6.getName();
        java.io.PrintStream printStream10 = null;
        com.google.javascript.jscomp.Compiler compiler11 = new com.google.javascript.jscomp.Compiler(printStream10);
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray12 = new com.google.javascript.jscomp.JSSourceFile[] {};
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray13 = new com.google.javascript.jscomp.JSSourceFile[] {};
        com.google.javascript.jscomp.CompilerOptions compilerOptions14 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions14.devirtualizePrototypeMethods = false;
        compilerOptions14.groupVariableDeclarations = false;
        boolean boolean19 = compilerOptions14.ideMode;
        compilerOptions14.setProcessObjectPropertyString(true);
        compilerOptions14.setDefineToBooleanLiteral("BITXOR", true);
        compilerOptions14.checkControlStructures = true;
        java.util.Map<java.lang.String, com.google.javascript.rhino.Node> strMap27 = compilerOptions14.getTweakReplacements();
        com.google.javascript.jscomp.Result result28 = compiler11.compile(jSSourceFileArray12, jSSourceFileArray13, compilerOptions14);
        com.google.javascript.jscomp.JSError[] jSErrorArray29 = compiler11.getErrors();
        com.google.javascript.rhino.Node node30 = compiler11.getRoot();
        compilerInput6.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler11);
        boolean boolean32 = compiler11.hasErrors();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile34 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.CompilerInput compilerInput35 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile34);
        boolean boolean36 = compilerInput35.isExtern();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile38 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        java.lang.String str39 = jSSourceFile38.getOriginalPath();
        compilerInput35.setSourceFile((com.google.javascript.jscomp.SourceFile) jSSourceFile38);
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray41 = null;
        com.google.javascript.jscomp.CompilerOptions compilerOptions42 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions42.removeUnusedLocalVars = false;
        compilerOptions42.jsOutputFile = "";
        com.google.javascript.jscomp.CodingConvention codingConvention47 = compilerOptions42.getCodingConvention();
        try {
            com.google.javascript.jscomp.Result result48 = compiler11.compile(jSSourceFile38, jSSourceFileArray41, compilerOptions42);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile1);
        org.junit.Assert.assertNull(region8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertNotNull(jSSourceFileArray12);
        org.junit.Assert.assertNotNull(jSSourceFileArray13);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(strMap27);
        org.junit.Assert.assertNotNull(result28);
        org.junit.Assert.assertNotNull(jSErrorArray29);
        org.junit.Assert.assertNotNull(node30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(jSSourceFile34);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(jSSourceFile38);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "" + "'", str39.equals(""));
        org.junit.Assert.assertNull(codingConvention47);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        node4.removeProp((int) (short) 1);
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        boolean boolean13 = node12.hasMoreThanOneChild();
        node12.setLineno(0);
        boolean boolean16 = node12.hasOneChild();
        com.google.javascript.rhino.jstype.JSType jSType17 = node12.getJSType();
        com.google.javascript.rhino.Node node22 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        node22.removeProp((int) (short) 1);
        com.google.javascript.rhino.Node[] nodeArray25 = new com.google.javascript.rhino.Node[] { node12, node22 };
        com.google.javascript.rhino.Node node28 = new com.google.javascript.rhino.Node((int) (byte) 10, nodeArray25, (int) '4', (int) (byte) -1);
        com.google.javascript.rhino.Node node29 = node4.copyInformationFromForTree(node28);
        boolean boolean30 = node4.hasChildren();
        node4.setVarArgs(false);
        com.google.javascript.rhino.Node.AncestorIterable ancestorIterable33 = node4.getAncestors();
        java.util.Iterator<com.google.javascript.rhino.Node> nodeItor34 = ancestorIterable33.iterator();
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNull(jSType17);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertNotNull(nodeArray25);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(ancestorIterable33);
        org.junit.Assert.assertNotNull(nodeItor34);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.devirtualizePrototypeMethods = false;
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy3 = com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC;
        compilerOptions0.propertyRenaming = propertyRenamingPolicy3;
        boolean boolean5 = compilerOptions0.recordFunctionInformation;
        compilerOptions0.enableExternExports(false);
        com.google.javascript.jscomp.CheckLevel checkLevel8 = compilerOptions0.checkUnreachableCode;
        java.lang.String str9 = compilerOptions0.nameReferenceReportPath;
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy3 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC + "'", propertyRenamingPolicy3.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + checkLevel8 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel8.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNull(str9);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.devirtualizePrototypeMethods = false;
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy3 = com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC;
        compilerOptions0.propertyRenaming = propertyRenamingPolicy3;
        boolean boolean5 = compilerOptions0.recordFunctionInformation;
        compilerOptions0.optimizeArgumentsArray = false;
        com.google.javascript.jscomp.DiagnosticType diagnosticType8 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        com.google.javascript.jscomp.CheckLevel checkLevel9 = diagnosticType8.defaultLevel;
        compilerOptions0.checkMethods = checkLevel9;
        com.google.javascript.jscomp.CompilerOptions.AliasTransformationHandler aliasTransformationHandler11 = compilerOptions0.getAliasTransformationHandler();
        boolean boolean12 = compilerOptions0.devirtualizePrototypeMethods;
        boolean boolean13 = compilerOptions0.generatePseudoNames;
        com.google.javascript.rhino.Context context14 = new com.google.javascript.rhino.Context();
        com.google.javascript.jscomp.AnonymousFunctionNamingPolicy anonymousFunctionNamingPolicy15 = com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.UNMAPPED;
        context14.removeThreadLocal((java.lang.Object) anonymousFunctionNamingPolicy15);
        compilerOptions0.anonymousFunctionNaming = anonymousFunctionNamingPolicy15;
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy3 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC + "'", propertyRenamingPolicy3.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(diagnosticType8);
        org.junit.Assert.assertTrue("'" + checkLevel9 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel9.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(aliasTransformationHandler11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + anonymousFunctionNamingPolicy15 + "' != '" + com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.UNMAPPED + "'", anonymousFunctionNamingPolicy15.equals(com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.UNMAPPED));
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.devirtualizePrototypeMethods = false;
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy3 = com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC;
        compilerOptions0.propertyRenaming = propertyRenamingPolicy3;
        boolean boolean5 = compilerOptions0.recordFunctionInformation;
        compilerOptions0.enableExternExports(false);
        byte[] byteArray11 = new byte[] { (byte) -1, (byte) 1, (byte) 10 };
        compilerOptions0.inputVariableMapSerialized = byteArray11;
        compilerOptions0.convertToDottedProperties = true;
        compilerOptions0.instrumentForCoverageOnly = true;
        compilerOptions0.nameReferenceReportPath = "BITXOR";
        boolean boolean19 = compilerOptions0.removeUnusedLocalVars;
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy3 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC + "'", propertyRenamingPolicy3.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(byteArray11);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.devirtualizePrototypeMethods = false;
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy3 = com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC;
        compilerOptions0.propertyRenaming = propertyRenamingPolicy3;
        boolean boolean5 = compilerOptions0.recordFunctionInformation;
        compilerOptions0.optimizeArgumentsArray = false;
        com.google.javascript.jscomp.DiagnosticType diagnosticType8 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        com.google.javascript.jscomp.CheckLevel checkLevel9 = diagnosticType8.defaultLevel;
        compilerOptions0.checkMethods = checkLevel9;
        com.google.javascript.jscomp.CheckLevel checkLevel11 = compilerOptions0.checkRequires;
        compilerOptions0.setRewriteNewDateGoogNow(true);
        boolean boolean14 = compilerOptions0.optimizeCalls;
        com.google.javascript.jscomp.DiagnosticType diagnosticType15 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        com.google.javascript.jscomp.CheckLevel checkLevel16 = diagnosticType15.level;
        com.google.javascript.jscomp.CheckLevel checkLevel17 = com.google.javascript.jscomp.CheckLevel.OFF;
        diagnosticType15.level = checkLevel17;
        compilerOptions0.aggressiveVarCheck = checkLevel17;
        boolean boolean20 = compilerOptions0.ambiguateProperties;
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy3 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC + "'", propertyRenamingPolicy3.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(diagnosticType8);
        org.junit.Assert.assertTrue("'" + checkLevel9 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel9.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + checkLevel11 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel11.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(diagnosticType15);
        org.junit.Assert.assertTrue("'" + checkLevel16 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel16.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + checkLevel17 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel17.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        com.google.javascript.rhino.EvaluatorException evaluatorException3 = new com.google.javascript.rhino.EvaluatorException("null(ERROR), null(ERROR), null(ERROR), null(ERROR)", "null(ERROR), null(ERROR), null(ERROR), null(ERROR)", 0);
        java.lang.String str4 = evaluatorException3.details();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "null(ERROR), null(ERROR), null(ERROR), null(ERROR)" + "'", str4.equals("null(ERROR), null(ERROR), null(ERROR), null(ERROR)"));
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.devirtualizePrototypeMethods = false;
        compilerOptions0.groupVariableDeclarations = false;
        boolean boolean5 = compilerOptions0.ideMode;
        compilerOptions0.setProcessObjectPropertyString(true);
        compilerOptions0.setLooseTypes(true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        com.google.javascript.rhino.Context context0 = new com.google.javascript.rhino.Context();
        com.google.javascript.jscomp.AnonymousFunctionNamingPolicy anonymousFunctionNamingPolicy1 = com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.UNMAPPED;
        context0.removeThreadLocal((java.lang.Object) anonymousFunctionNamingPolicy1);
        java.lang.Object obj4 = context0.getThreadLocal((java.lang.Object) "error reporter");
        boolean boolean5 = context0.hasCompileFunctionsWithDynamicScope();
        boolean boolean6 = context0.isGeneratingDebugChanged();
        org.junit.Assert.assertTrue("'" + anonymousFunctionNamingPolicy1 + "' != '" + com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.UNMAPPED + "'", anonymousFunctionNamingPolicy1.equals(com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.UNMAPPED));
        org.junit.Assert.assertNull(obj4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.jstype.FunctionType functionType1 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType2 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType3 = null;
        closureCodingConvention0.applySubclassRelationship(functionType1, functionType2, subclassType3);
        com.google.javascript.rhino.jstype.ObjectType objectType5 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType6 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType7 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType8 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType9 = null;
        closureCodingConvention0.applyDelegateRelationship(objectType5, objectType6, objectType7, functionType8, functionType9);
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.Node.newNumber(1.0d, 26, (int) (short) 1);
        boolean boolean15 = node14.isNoSideEffectsCall();
        com.google.javascript.rhino.Node node21 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        node21.removeProp((int) (short) 1);
        com.google.javascript.rhino.Node node29 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        boolean boolean30 = node29.hasMoreThanOneChild();
        node29.setLineno(0);
        boolean boolean33 = node29.hasOneChild();
        com.google.javascript.rhino.jstype.JSType jSType34 = node29.getJSType();
        com.google.javascript.rhino.Node node39 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        node39.removeProp((int) (short) 1);
        com.google.javascript.rhino.Node[] nodeArray42 = new com.google.javascript.rhino.Node[] { node29, node39 };
        com.google.javascript.rhino.Node node45 = new com.google.javascript.rhino.Node((int) (byte) 10, nodeArray42, (int) '4', (int) (byte) -1);
        com.google.javascript.rhino.Node node46 = node21.copyInformationFromForTree(node45);
        com.google.javascript.rhino.Node node51 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        node51.setSourcePositionForTree(20);
        com.google.javascript.rhino.Node node58 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        boolean boolean59 = node58.hasMoreThanOneChild();
        node58.setLineno(0);
        com.google.javascript.rhino.Node node62 = node58.cloneTree();
        com.google.javascript.rhino.Node node67 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        com.google.javascript.rhino.JSDocInfo jSDocInfo68 = null;
        node67.setJSDocInfo(jSDocInfo68);
        java.lang.RuntimeException runtimeException71 = com.google.javascript.rhino.ScriptRuntime.undefReadError((java.lang.Object) node67, (java.lang.Object) 22);
        node67.detachChildren();
        int int73 = node67.getChildCount();
        com.google.javascript.rhino.Node node76 = new com.google.javascript.rhino.Node((int) (short) -1, node46, node51, node62, node67, 15, (int) (byte) 1);
        node14.addChildToBack(node76);
        com.google.javascript.rhino.Node node78 = null;
        try {
            java.lang.String str79 = closureCodingConvention0.extractClassNameIfRequire(node76, node78);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNull(jSType34);
        org.junit.Assert.assertNotNull(node39);
        org.junit.Assert.assertNotNull(nodeArray42);
        org.junit.Assert.assertNotNull(node46);
        org.junit.Assert.assertNotNull(node51);
        org.junit.Assert.assertNotNull(node58);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertNotNull(node62);
        org.junit.Assert.assertNotNull(node67);
        org.junit.Assert.assertNotNull(runtimeException71);
        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 0 + "'", int73 == 0);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = null;
        com.google.javascript.jscomp.DiagnosticGroups.NON_STANDARD_JSDOC = diagnosticGroup0;
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeUnusedLocalVars = false;
        compilerOptions0.crossModuleCodeMotion = false;
        com.google.javascript.jscomp.CompilerOptions compilerOptions5 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions5.devirtualizePrototypeMethods = false;
        java.util.Set<java.lang.String> strSet8 = compilerOptions5.stripNameSuffixes;
        compilerOptions0.stripNamePrefixes = strSet8;
        com.google.javascript.jscomp.CheckLevel checkLevel10 = compilerOptions0.checkGlobalThisLevel;
        compilerOptions0.removeTryCatchFinally = false;
        org.junit.Assert.assertNotNull(strSet8);
        org.junit.Assert.assertTrue("'" + checkLevel10 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel10.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeUnusedLocalVars = false;
        compilerOptions0.crossModuleCodeMotion = false;
        compilerOptions0.ambiguateProperties = false;
        compilerOptions0.computeFunctionSideEffects = false;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy9 = com.google.javascript.jscomp.VariableRenamingPolicy.UNSPECIFIED;
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy10 = com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC;
        compilerOptions0.setRenamingPolicy(variableRenamingPolicy9, propertyRenamingPolicy10);
        boolean boolean12 = compilerOptions0.exportTestFunctions;
        java.lang.String[] strArray24 = new java.lang.String[] { "goog.global", "JSC_OPTIMIZE_LOOP_ERROR", "goog.global", "language version", "typeof", "Not declared as a type name", "<No stack trace available>", "0", "<No stack trace available>", "typeof", "language version" };
        java.util.LinkedHashSet<java.lang.String> strSet25 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean26 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet25, strArray24);
        compilerOptions0.stripNameSuffixes = strSet25;
        compilerOptions0.optimizeCalls = true;
        compilerOptions0.aliasAllStrings = true;
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy9 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.UNSPECIFIED + "'", variableRenamingPolicy9.equals(com.google.javascript.jscomp.VariableRenamingPolicy.UNSPECIFIED));
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy10 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC + "'", propertyRenamingPolicy10.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(strArray24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.CompilerOptions compilerOptions2 = null;
        try {
            compiler1.initOptions(compilerOptions2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        com.google.javascript.rhino.JSDocInfo jSDocInfo6 = null;
        node5.setJSDocInfo(jSDocInfo6);
        java.lang.RuntimeException runtimeException9 = com.google.javascript.rhino.ScriptRuntime.undefReadError((java.lang.Object) node5, (java.lang.Object) 22);
        node5.detachChildren();
        com.google.javascript.rhino.Node node11 = new com.google.javascript.rhino.Node((int) (short) 100, node5);
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        com.google.javascript.rhino.JSDocInfo jSDocInfo18 = null;
        node17.setJSDocInfo(jSDocInfo18);
        java.lang.RuntimeException runtimeException21 = com.google.javascript.rhino.ScriptRuntime.undefReadError((java.lang.Object) node17, (java.lang.Object) 22);
        node17.detachChildren();
        com.google.javascript.rhino.Node node23 = new com.google.javascript.rhino.Node((int) (short) 100, node17);
        boolean boolean25 = node17.getBooleanProp(6);
        try {
            node5.addChildrenToFront(node17);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNotNull(runtimeException9);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(runtimeException21);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        node5.removeProp((int) (short) 1);
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        boolean boolean14 = node13.hasMoreThanOneChild();
        node13.setLineno(0);
        boolean boolean17 = node13.hasOneChild();
        com.google.javascript.rhino.jstype.JSType jSType18 = node13.getJSType();
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        node23.removeProp((int) (short) 1);
        com.google.javascript.rhino.Node[] nodeArray26 = new com.google.javascript.rhino.Node[] { node13, node23 };
        com.google.javascript.rhino.Node node29 = new com.google.javascript.rhino.Node((int) (byte) 10, nodeArray26, (int) '4', (int) (byte) -1);
        com.google.javascript.rhino.Node node30 = node5.copyInformationFromForTree(node29);
        boolean boolean31 = node29.isNoSideEffectsCall();
        com.google.javascript.rhino.Node node36 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        com.google.javascript.rhino.JSDocInfo jSDocInfo37 = null;
        node36.setJSDocInfo(jSDocInfo37);
        com.google.javascript.rhino.Node node44 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        com.google.javascript.rhino.JSDocInfo jSDocInfo45 = null;
        node44.setJSDocInfo(jSDocInfo45);
        java.lang.RuntimeException runtimeException48 = com.google.javascript.rhino.ScriptRuntime.undefReadError((java.lang.Object) node44, (java.lang.Object) 22);
        node44.detachChildren();
        com.google.javascript.rhino.Node node50 = new com.google.javascript.rhino.Node((int) (short) 100, node44);
        com.google.javascript.rhino.JSDocInfo jSDocInfo51 = null;
        node50.setJSDocInfo(jSDocInfo51);
        com.google.javascript.rhino.Node node53 = new com.google.javascript.rhino.Node((int) (byte) -1, node29, node36, node50);
        boolean boolean54 = node53.isLocalResultCall();
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNull(jSType18);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(nodeArray26);
        org.junit.Assert.assertNotNull(node30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(node36);
        org.junit.Assert.assertNotNull(node44);
        org.junit.Assert.assertNotNull(runtimeException48);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
    }

//    @Test
//    public void test445() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test445");
//        try {
//            java.lang.String str2 = com.google.javascript.rhino.ScriptRuntime.numberToString(10.0d, 140);
//            org.junit.Assert.fail("Expected exception of type com.google.javascript.rhino.EvaluatorException; message: illegal radix 140.");
//        } catch (com.google.javascript.rhino.EvaluatorException e) {
//        }
//    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.UNDEFINED_VARIABLES;
        com.google.javascript.jscomp.DiagnosticGroups.CHECK_USELESS_CODE = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticGroups.ACCESS_CONTROLS = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticGroups.CHECK_USELESS_CODE = diagnosticGroup0;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.devirtualizePrototypeMethods = false;
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy3 = com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC;
        compilerOptions0.propertyRenaming = propertyRenamingPolicy3;
        compilerOptions0.disableRuntimeTypeCheck();
        compilerOptions0.checkSuspiciousCode = false;
        boolean boolean8 = compilerOptions0.collapseAnonymousFunctions;
        compilerOptions0.checkControlStructures = true;
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy3 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC + "'", propertyRenamingPolicy3.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.devirtualizePrototypeMethods = false;
        java.lang.String str3 = compilerOptions0.syntheticBlockStartMarker;
        compilerOptions0.aliasStringsBlacklist = "goog.exportProperty";
        compilerOptions0.smartNameRemoval = false;
        com.google.javascript.jscomp.SourceMap.DetailLevel detailLevel8 = compilerOptions0.sourceMapDetailLevel;
        compilerOptions0.foldConstants = false;
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNotNull(detailLevel8);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.devirtualizePrototypeMethods = false;
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy3 = com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC;
        compilerOptions0.propertyRenaming = propertyRenamingPolicy3;
        boolean boolean5 = compilerOptions0.recordFunctionInformation;
        compilerOptions0.locale = "<unknown=160>";
        com.google.javascript.jscomp.CheckLevel checkLevel8 = compilerOptions0.brokenClosureRequiresLevel;
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy3 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC + "'", propertyRenamingPolicy3.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + checkLevel8 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel8.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        java.io.InputStream inputStream2 = null;
        try {
            com.google.javascript.jscomp.SourceFile sourceFile3 = com.google.javascript.jscomp.SourceFile.fromInputStream("", "(Not declared as a constructor)", inputStream2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        int int0 = com.google.javascript.rhino.Node.DEBUGSOURCE_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 28 + "'", int0 == 28);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.devirtualizePrototypeMethods = false;
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy3 = com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC;
        compilerOptions0.propertyRenaming = propertyRenamingPolicy3;
        boolean boolean5 = compilerOptions0.recordFunctionInformation;
        compilerOptions0.enableExternExports(false);
        byte[] byteArray11 = new byte[] { (byte) -1, (byte) 1, (byte) 10 };
        compilerOptions0.inputVariableMapSerialized = byteArray11;
        compilerOptions0.convertToDottedProperties = true;
        com.google.javascript.jscomp.DiagnosticType diagnosticType15 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        com.google.javascript.jscomp.CheckLevel checkLevel16 = diagnosticType15.defaultLevel;
        compilerOptions0.checkFunctions = checkLevel16;
        boolean boolean18 = compilerOptions0.aliasAllStrings;
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy3 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC + "'", propertyRenamingPolicy3.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(byteArray11);
        org.junit.Assert.assertNotNull(diagnosticType15);
        org.junit.Assert.assertTrue("'" + checkLevel16 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel16.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        boolean boolean5 = node4.hasMoreThanOneChild();
        node4.setLineno(0);
        com.google.javascript.rhino.Node node8 = node4.cloneTree();
        node4.setVarArgs(true);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(node8);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CodingConvention codingConvention1 = compilerOptions0.getCodingConvention();
        com.google.javascript.jscomp.CompilerOptions.AliasTransformationHandler aliasTransformationHandler2 = compilerOptions0.getAliasTransformationHandler();
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy3 = compilerOptions0.variableRenaming;
        org.junit.Assert.assertNull(codingConvention1);
        org.junit.Assert.assertNotNull(aliasTransformationHandler2);
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy3 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.OFF + "'", variableRenamingPolicy3.equals(com.google.javascript.jscomp.VariableRenamingPolicy.OFF));
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        try {
            boolean boolean2 = compiler1.acceptEcmaScript5();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.jstype.FunctionType functionType1 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType2 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType3 = null;
        closureCodingConvention0.applySubclassRelationship(functionType1, functionType2, subclassType3);
        com.google.javascript.rhino.jstype.FunctionType functionType5 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType6 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType7 = null;
        closureCodingConvention0.applySubclassRelationship(functionType5, functionType6, subclassType7);
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        node13.removeProp((int) (short) 1);
        com.google.javascript.rhino.Node node21 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        boolean boolean22 = node21.hasMoreThanOneChild();
        node21.setLineno(0);
        boolean boolean25 = node21.hasOneChild();
        com.google.javascript.rhino.jstype.JSType jSType26 = node21.getJSType();
        com.google.javascript.rhino.Node node31 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        node31.removeProp((int) (short) 1);
        com.google.javascript.rhino.Node[] nodeArray34 = new com.google.javascript.rhino.Node[] { node21, node31 };
        com.google.javascript.rhino.Node node37 = new com.google.javascript.rhino.Node((int) (byte) 10, nodeArray34, (int) '4', (int) (byte) -1);
        com.google.javascript.rhino.Node node38 = node13.copyInformationFromForTree(node37);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder39 = node37.new FileLevelJsDocBuilder();
        java.lang.String str43 = node37.toString(false, false, false);
        com.google.javascript.jscomp.CodingConvention.SubclassRelationship subclassRelationship44 = closureCodingConvention0.getClassesDefinedByCall(node37);
        boolean boolean46 = closureCodingConvention0.isExported("DiagnosticGroup<undefinedVars>");
        boolean boolean49 = closureCodingConvention0.isExported("", false);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNull(jSType26);
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertNotNull(nodeArray34);
        org.junit.Assert.assertNotNull(node38);
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "BITXOR" + "'", str43.equals("BITXOR"));
        org.junit.Assert.assertNull(subclassRelationship44);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        boolean boolean5 = node4.hasMoreThanOneChild();
        node4.setLineno(0);
        boolean boolean8 = node4.hasOneChild();
        com.google.javascript.rhino.jstype.JSType jSType9 = node4.getJSType();
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        node14.removeProp((int) (short) 1);
        com.google.javascript.rhino.Node node22 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        boolean boolean23 = node22.hasMoreThanOneChild();
        node22.setLineno(0);
        boolean boolean26 = node22.hasOneChild();
        com.google.javascript.rhino.jstype.JSType jSType27 = node22.getJSType();
        com.google.javascript.rhino.Node node32 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        node32.removeProp((int) (short) 1);
        com.google.javascript.rhino.Node[] nodeArray35 = new com.google.javascript.rhino.Node[] { node22, node32 };
        com.google.javascript.rhino.Node node38 = new com.google.javascript.rhino.Node((int) (byte) 10, nodeArray35, (int) '4', (int) (byte) -1);
        com.google.javascript.rhino.Node node39 = node14.copyInformationFromForTree(node38);
        boolean boolean40 = node14.hasChildren();
        com.google.javascript.rhino.Node node41 = node14.removeFirstChild();
        com.google.javascript.rhino.Node node46 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        boolean boolean47 = node46.hasMoreThanOneChild();
        node46.setLineno(0);
        com.google.javascript.rhino.Node node50 = node46.cloneTree();
        com.google.javascript.rhino.Node node55 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        node55.removeProp((int) (short) 1);
        com.google.javascript.rhino.Node node63 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        boolean boolean64 = node63.hasMoreThanOneChild();
        node63.setLineno(0);
        boolean boolean67 = node63.hasOneChild();
        com.google.javascript.rhino.jstype.JSType jSType68 = node63.getJSType();
        com.google.javascript.rhino.Node node73 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        node73.removeProp((int) (short) 1);
        com.google.javascript.rhino.Node[] nodeArray76 = new com.google.javascript.rhino.Node[] { node63, node73 };
        com.google.javascript.rhino.Node node79 = new com.google.javascript.rhino.Node((int) (byte) 10, nodeArray76, (int) '4', (int) (byte) -1);
        com.google.javascript.rhino.Node node80 = node55.copyInformationFromForTree(node79);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder81 = node79.new FileLevelJsDocBuilder();
        java.lang.String str85 = node79.toString(false, false, false);
        node46.addChildrenToBack(node79);
        node4.addChildAfter(node14, node79);
        node79.setType((int) (byte) 100);
        boolean boolean90 = node79.isSyntheticBlock();
        node79.removeProp(37);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNull(jSType9);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNull(jSType27);
        org.junit.Assert.assertNotNull(node32);
        org.junit.Assert.assertNotNull(nodeArray35);
        org.junit.Assert.assertNotNull(node39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNull(node41);
        org.junit.Assert.assertNotNull(node46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(node50);
        org.junit.Assert.assertNotNull(node55);
        org.junit.Assert.assertNotNull(node63);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
        org.junit.Assert.assertNull(jSType68);
        org.junit.Assert.assertNotNull(node73);
        org.junit.Assert.assertNotNull(nodeArray76);
        org.junit.Assert.assertNotNull(node80);
        org.junit.Assert.assertTrue("'" + str85 + "' != '" + "BITXOR" + "'", str85.equals("BITXOR"));
        org.junit.Assert.assertTrue("'" + boolean90 + "' != '" + false + "'", boolean90 == false);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray2 = new com.google.javascript.jscomp.JSSourceFile[] {};
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray3 = new com.google.javascript.jscomp.JSSourceFile[] {};
        com.google.javascript.jscomp.CompilerOptions compilerOptions4 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions4.devirtualizePrototypeMethods = false;
        compilerOptions4.groupVariableDeclarations = false;
        boolean boolean9 = compilerOptions4.ideMode;
        compilerOptions4.setProcessObjectPropertyString(true);
        compilerOptions4.setDefineToBooleanLiteral("BITXOR", true);
        compilerOptions4.checkControlStructures = true;
        java.util.Map<java.lang.String, com.google.javascript.rhino.Node> strMap17 = compilerOptions4.getTweakReplacements();
        com.google.javascript.jscomp.Result result18 = compiler1.compile(jSSourceFileArray2, jSSourceFileArray3, compilerOptions4);
        java.lang.String str21 = compiler1.getSourceLine("DiagnosticGroup<typeInvalidation>", (int) '#');
        org.junit.Assert.assertNotNull(jSSourceFileArray2);
        org.junit.Assert.assertNotNull(jSSourceFileArray3);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(strMap17);
        org.junit.Assert.assertNotNull(result18);
        org.junit.Assert.assertNull(str21);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        com.google.javascript.jscomp.JSModule[] jSModuleArray0 = new com.google.javascript.jscomp.JSModule[] {};
        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList1 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList1, jSModuleArray0);
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph3 = new com.google.javascript.jscomp.JSModuleGraph((java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList1);
        com.google.javascript.jscomp.JSModule jSModule4 = null;
        com.google.javascript.jscomp.JSModule jSModule5 = null;
        com.google.javascript.jscomp.JSModule jSModule6 = jSModuleGraph3.getDeepestCommonDependencyInclusive(jSModule4, jSModule5);
        jSModuleGraph3.coalesceDuplicateFiles();
        jSModuleGraph3.coalesceDuplicateFiles();
        jSModuleGraph3.coalesceDuplicateFiles();
        jSModuleGraph3.coalesceDuplicateFiles();
        org.junit.Assert.assertNotNull(jSModuleArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(jSModule6);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        com.google.javascript.rhino.Context context0 = new com.google.javascript.rhino.Context();
        com.google.javascript.jscomp.AnonymousFunctionNamingPolicy anonymousFunctionNamingPolicy1 = com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.UNMAPPED;
        context0.removeThreadLocal((java.lang.Object) anonymousFunctionNamingPolicy1);
        long long3 = com.google.javascript.rhino.ScriptRuntime.lastUint32Result(context0);
        com.google.javascript.rhino.Context context4 = new com.google.javascript.rhino.Context();
        com.google.javascript.jscomp.AnonymousFunctionNamingPolicy anonymousFunctionNamingPolicy5 = com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.UNMAPPED;
        context4.removeThreadLocal((java.lang.Object) anonymousFunctionNamingPolicy5);
        java.lang.String str7 = context4.getImplementationVersion();
        java.util.Locale locale8 = context4.getLocale();
        java.util.Locale locale9 = context0.setLocale(locale8);
        org.junit.Assert.assertTrue("'" + anonymousFunctionNamingPolicy1 + "' != '" + com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.UNMAPPED + "'", anonymousFunctionNamingPolicy1.equals(com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.UNMAPPED));
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertTrue("'" + anonymousFunctionNamingPolicy5 + "' != '" + com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.UNMAPPED + "'", anonymousFunctionNamingPolicy5.equals(com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.UNMAPPED));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "@IMPLEMENTATION.VERSION@" + "'", str7.equals("@IMPLEMENTATION.VERSION@"));
        org.junit.Assert.assertNotNull(locale8);
        org.junit.Assert.assertNull(locale9);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.jstype.FunctionType functionType1 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType2 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType3 = null;
        closureCodingConvention0.applySubclassRelationship(functionType1, functionType2, subclassType3);
        com.google.javascript.rhino.jstype.FunctionType functionType5 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType6 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType7 = null;
        closureCodingConvention0.applySubclassRelationship(functionType5, functionType6, subclassType7);
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        node13.removeProp((int) (short) 1);
        com.google.javascript.rhino.Node node21 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        boolean boolean22 = node21.hasMoreThanOneChild();
        node21.setLineno(0);
        boolean boolean25 = node21.hasOneChild();
        com.google.javascript.rhino.jstype.JSType jSType26 = node21.getJSType();
        com.google.javascript.rhino.Node node31 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        node31.removeProp((int) (short) 1);
        com.google.javascript.rhino.Node[] nodeArray34 = new com.google.javascript.rhino.Node[] { node21, node31 };
        com.google.javascript.rhino.Node node37 = new com.google.javascript.rhino.Node((int) (byte) 10, nodeArray34, (int) '4', (int) (byte) -1);
        com.google.javascript.rhino.Node node38 = node13.copyInformationFromForTree(node37);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder39 = node37.new FileLevelJsDocBuilder();
        java.lang.String str43 = node37.toString(false, false, false);
        com.google.javascript.jscomp.CodingConvention.SubclassRelationship subclassRelationship44 = closureCodingConvention0.getClassesDefinedByCall(node37);
        boolean boolean46 = closureCodingConvention0.isExported("DiagnosticGroup<undefinedVars>");
        com.google.javascript.rhino.Node node47 = null;
        com.google.javascript.rhino.Node node51 = com.google.javascript.rhino.Node.newNumber((double) 'a', (int) (byte) 1, 0);
        java.lang.String str52 = closureCodingConvention0.extractClassNameIfProvide(node47, node51);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNull(jSType26);
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertNotNull(nodeArray34);
        org.junit.Assert.assertNotNull(node38);
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "BITXOR" + "'", str43.equals("BITXOR"));
        org.junit.Assert.assertNull(subclassRelationship44);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(node51);
        org.junit.Assert.assertNull(str52);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        try {
            com.google.javascript.rhino.Context.reportWarning("DiagnosticGroup<undefinedVars>: <unknown=160>");
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: No Context associated with current Thread");
        } catch (java.lang.RuntimeException e) {
        }
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeUnusedLocalVars = false;
        compilerOptions0.crossModuleCodeMotion = false;
        com.google.javascript.jscomp.CompilerOptions compilerOptions5 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions5.devirtualizePrototypeMethods = false;
        java.util.Set<java.lang.String> strSet8 = compilerOptions5.stripNameSuffixes;
        compilerOptions0.stripNamePrefixes = strSet8;
        compilerOptions0.generatePseudoNames = false;
        compilerOptions0.optimizeArgumentsArray = true;
        org.junit.Assert.assertNotNull(strSet8);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeUnusedLocalVars = false;
        compilerOptions0.crossModuleCodeMotion = false;
        com.google.javascript.jscomp.CompilerOptions compilerOptions5 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions5.devirtualizePrototypeMethods = false;
        java.util.Set<java.lang.String> strSet8 = compilerOptions5.stripNameSuffixes;
        compilerOptions0.stripNamePrefixes = strSet8;
        compilerOptions0.appNameStr = "BITXOR";
        compilerOptions0.nameReferenceGraphPath = "";
        compilerOptions0.crossModuleMethodMotion = false;
        org.junit.Assert.assertNotNull(strSet8);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        int int0 = com.google.javascript.rhino.Node.BOTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        try {
            java.lang.String str2 = com.google.javascript.rhino.ScriptRuntime.escapeString("goog.abstractMethod", ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: FAILED ASSERTION");
        } catch (java.lang.IllegalStateException e) {
        }
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.jstype.FunctionType functionType1 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType2 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType3 = null;
        closureCodingConvention0.applySubclassRelationship(functionType1, functionType2, subclassType3);
        com.google.javascript.rhino.jstype.FunctionType functionType5 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType6 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType7 = null;
        closureCodingConvention0.applySubclassRelationship(functionType5, functionType6, subclassType7);
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        node13.removeProp((int) (short) 1);
        com.google.javascript.rhino.Node node21 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        boolean boolean22 = node21.hasMoreThanOneChild();
        node21.setLineno(0);
        boolean boolean25 = node21.hasOneChild();
        com.google.javascript.rhino.jstype.JSType jSType26 = node21.getJSType();
        com.google.javascript.rhino.Node node31 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        node31.removeProp((int) (short) 1);
        com.google.javascript.rhino.Node[] nodeArray34 = new com.google.javascript.rhino.Node[] { node21, node31 };
        com.google.javascript.rhino.Node node37 = new com.google.javascript.rhino.Node((int) (byte) 10, nodeArray34, (int) '4', (int) (byte) -1);
        com.google.javascript.rhino.Node node38 = node13.copyInformationFromForTree(node37);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder39 = node37.new FileLevelJsDocBuilder();
        java.lang.String str43 = node37.toString(false, false, false);
        com.google.javascript.jscomp.CodingConvention.SubclassRelationship subclassRelationship44 = closureCodingConvention0.getClassesDefinedByCall(node37);
        com.google.javascript.rhino.Node node45 = node37.removeFirstChild();
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNull(jSType26);
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertNotNull(nodeArray34);
        org.junit.Assert.assertNotNull(node38);
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "BITXOR" + "'", str43.equals("BITXOR"));
        org.junit.Assert.assertNull(subclassRelationship44);
        org.junit.Assert.assertNotNull(node45);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        try {
            com.google.javascript.rhino.Context.reportWarning("", "", 2, "language version", 26);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: No Context associated with current Thread");
        } catch (java.lang.RuntimeException e) {
        }
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        com.google.javascript.rhino.EvaluatorException evaluatorException1 = new com.google.javascript.rhino.EvaluatorException("goog.exportProperty");
        com.google.javascript.rhino.EcmaError ecmaError4 = com.google.javascript.rhino.ScriptRuntime.constructError("DiagnosticGroup<undefinedVars>", "<unknown=160>");
        int int5 = ecmaError4.getColumnNumber();
        int int6 = ecmaError4.getLineNumber();
        evaluatorException1.addSuppressed((java.lang.Throwable) ecmaError4);
        org.junit.Assert.assertNotNull(ecmaError4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CodingConvention codingConvention1 = compilerOptions0.getCodingConvention();
        boolean boolean2 = compilerOptions0.inlineLocalVariables;
        compilerOptions0.groupVariableDeclarations = true;
        compilerOptions0.ideMode = false;
        org.junit.Assert.assertNull(codingConvention1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile1 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.CompilerInput compilerInput2 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile1);
        com.google.javascript.jscomp.JSModule jSModule3 = null;
        compilerInput2.setModule(jSModule3);
        com.google.javascript.jscomp.CompilerInput compilerInput6 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput2, false);
        com.google.javascript.jscomp.JSModule jSModule7 = compilerInput6.getModule();
        try {
            java.util.Collection<java.lang.String> strCollection8 = compilerInput6.getRequires();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Expected setErrorManager to be called first");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile1);
        org.junit.Assert.assertNull(jSModule7);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        com.google.javascript.rhino.Context context0 = new com.google.javascript.rhino.Context();
        com.google.javascript.jscomp.AnonymousFunctionNamingPolicy anonymousFunctionNamingPolicy1 = com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.UNMAPPED;
        context0.removeThreadLocal((java.lang.Object) anonymousFunctionNamingPolicy1);
        boolean boolean3 = context0.isGeneratingDebug();
        long long4 = com.google.javascript.rhino.ScriptRuntime.lastUint32Result(context0);
        com.google.javascript.rhino.Context context5 = com.google.javascript.rhino.Context.enter(context0);
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        node10.removeProp((int) (short) 1);
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        boolean boolean19 = node18.hasMoreThanOneChild();
        node18.setLineno(0);
        boolean boolean22 = node18.hasOneChild();
        com.google.javascript.rhino.jstype.JSType jSType23 = node18.getJSType();
        com.google.javascript.rhino.Node node28 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        node28.removeProp((int) (short) 1);
        com.google.javascript.rhino.Node[] nodeArray31 = new com.google.javascript.rhino.Node[] { node18, node28 };
        com.google.javascript.rhino.Node node34 = new com.google.javascript.rhino.Node((int) (byte) 10, nodeArray31, (int) '4', (int) (byte) -1);
        com.google.javascript.rhino.Node node35 = node10.copyInformationFromForTree(node34);
        java.lang.Object obj36 = context5.getThreadLocal((java.lang.Object) node35);
        java.lang.String str37 = context5.getImplementationVersion();
        org.junit.Assert.assertTrue("'" + anonymousFunctionNamingPolicy1 + "' != '" + com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.UNMAPPED + "'", anonymousFunctionNamingPolicy1.equals(com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.UNMAPPED));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
        org.junit.Assert.assertNotNull(context5);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNull(jSType23);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertNotNull(nodeArray31);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertNull(obj36);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "@IMPLEMENTATION.VERSION@" + "'", str37.equals("@IMPLEMENTATION.VERSION@"));
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.jstype.FunctionType functionType1 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType2 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType3 = null;
        closureCodingConvention0.applySubclassRelationship(functionType1, functionType2, subclassType3);
        com.google.javascript.rhino.jstype.ObjectType objectType5 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType6 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType7 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType8 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType9 = null;
        closureCodingConvention0.applyDelegateRelationship(objectType5, objectType6, objectType7, functionType8, functionType9);
        java.util.Collection<com.google.javascript.jscomp.CodingConvention.AssertionFunctionSpec> assertionFunctionSpecCollection11 = closureCodingConvention0.getAssertionFunctions();
        java.lang.String str12 = closureCodingConvention0.getAbstractMethodName();
        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.Node.newNumber((double) 'a', (int) (byte) 1, 0);
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable17 = node16.siblings();
        boolean boolean18 = closureCodingConvention0.isVarArgsParameter(node16);
        java.lang.Object obj20 = node16.getProp(35);
        org.junit.Assert.assertNotNull(assertionFunctionSpecCollection11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "goog.abstractMethod" + "'", str12.equals("goog.abstractMethod"));
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertNotNull(nodeIterable17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNull(obj20);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile1 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.CompilerInput compilerInput2 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile1);
        com.google.javascript.jscomp.JSModule jSModule3 = null;
        compilerInput2.setModule(jSModule3);
        com.google.javascript.jscomp.CompilerInput compilerInput6 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput2, false);
        com.google.javascript.jscomp.Region region8 = compilerInput6.getRegion(32);
        com.google.javascript.jscomp.Region region10 = compilerInput6.getRegion(27);
        org.junit.Assert.assertNotNull(jSSourceFile1);
        org.junit.Assert.assertNull(region8);
        org.junit.Assert.assertNull(region10);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeDeadCode = false;
        compilerOptions0.inlineLocalVariables = true;
        boolean boolean5 = compilerOptions0.printInputDelimiter;
        com.google.javascript.jscomp.CompilerOptions compilerOptions6 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CodingConvention codingConvention7 = compilerOptions6.getCodingConvention();
        compilerOptions6.computeFunctionSideEffects = true;
        com.google.javascript.jscomp.CheckLevel checkLevel10 = compilerOptions6.checkRequires;
        compilerOptions0.checkProvides = checkLevel10;
        compilerOptions0.locale = "BITXOR";
        java.lang.String str14 = compilerOptions0.instrumentationTemplate;
        compilerOptions0.setDefineToBooleanLiteral("language version", false);
        boolean boolean18 = compilerOptions0.closurePass;
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(codingConvention7);
        org.junit.Assert.assertTrue("'" + checkLevel10 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel10.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        java.lang.String str1 = closureCodingConvention0.getExportPropertyFunction();
        boolean boolean3 = closureCodingConvention0.isSuperClassReference("");
        com.google.javascript.jscomp.AbstractCompiler abstractCompiler4 = null;
        com.google.javascript.jscomp.NodeTraversal.Callback callback5 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal6 = new com.google.javascript.jscomp.NodeTraversal(abstractCompiler4, callback5);
        com.google.javascript.rhino.Node node7 = nodeTraversal6.getEnclosingFunction();
        com.google.javascript.jscomp.Scope scope8 = nodeTraversal6.getScope();
        com.google.javascript.rhino.Node node9 = nodeTraversal6.getEnclosingFunction();
        com.google.javascript.rhino.Node node10 = nodeTraversal6.getEnclosingFunction();
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        boolean boolean16 = node15.hasMoreThanOneChild();
        node15.setLineno(0);
        try {
            com.google.javascript.jscomp.CodingConvention.ObjectLiteralCast objectLiteralCast19 = closureCodingConvention0.getObjectLiteralCast(nodeTraversal6, node15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "goog.exportProperty" + "'", str1.equals("goog.exportProperty"));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(node7);
        org.junit.Assert.assertNull(scope8);
        org.junit.Assert.assertNull(node9);
        org.junit.Assert.assertNull(node10);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.devirtualizePrototypeMethods = false;
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy3 = com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC;
        compilerOptions0.propertyRenaming = propertyRenamingPolicy3;
        boolean boolean5 = compilerOptions0.recordFunctionInformation;
        compilerOptions0.aliasKeywords = false;
        compilerOptions0.checkMissingGetCssNameBlacklist = "JSC_OPTIMIZE_LOOP_ERROR";
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy3 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC + "'", propertyRenamingPolicy3.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.devirtualizePrototypeMethods = false;
        compilerOptions0.groupVariableDeclarations = false;
        boolean boolean5 = compilerOptions0.ideMode;
        java.lang.String str6 = compilerOptions0.nameReferenceReportPath;
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(str6);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        com.google.javascript.rhino.Node node3 = new com.google.javascript.rhino.Node((int) 'a', (int) ' ', (int) (short) -1);
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        com.google.javascript.rhino.JSDocInfo jSDocInfo9 = null;
        node8.setJSDocInfo(jSDocInfo9);
        java.lang.RuntimeException runtimeException12 = com.google.javascript.rhino.ScriptRuntime.undefReadError((java.lang.Object) node8, (java.lang.Object) 22);
        boolean boolean13 = node3.isEquivalentToTyped(node8);
        node3.setLineno((int) 'a');
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNotNull(runtimeException12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile1 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.CompilerInput compilerInput2 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile1);
        boolean boolean3 = compilerInput2.isExtern();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile5 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        java.lang.String str6 = jSSourceFile5.getOriginalPath();
        compilerInput2.setSourceFile((com.google.javascript.jscomp.SourceFile) jSSourceFile5);
        com.google.javascript.jscomp.JSModule jSModule8 = compilerInput2.getModule();
        com.google.javascript.jscomp.Region region10 = compilerInput2.getRegion(160);
        com.google.javascript.jscomp.Region region12 = compilerInput2.getRegion(22);
        org.junit.Assert.assertNotNull(jSSourceFile1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(jSSourceFile5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertNull(jSModule8);
        org.junit.Assert.assertNull(region10);
        org.junit.Assert.assertNull(region12);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        com.google.javascript.jscomp.SourceFile sourceFile1 = com.google.javascript.jscomp.SourceFile.fromFile("goog.global");
        java.lang.String str2 = sourceFile1.getOriginalPath();
        org.junit.Assert.assertNotNull(sourceFile1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "goog.global" + "'", str2.equals("goog.global"));
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        java.util.logging.Logger logger0 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager1 = new com.google.javascript.jscomp.LoggerErrorManager(logger0);
        com.google.javascript.jscomp.JSError[] jSErrorArray2 = loggerErrorManager1.getWarnings();
        com.google.javascript.jscomp.Compiler compiler3 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager1);
        com.google.javascript.jscomp.CompilerOptions compilerOptions4 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions4.devirtualizePrototypeMethods = false;
        compilerOptions4.groupVariableDeclarations = false;
        boolean boolean9 = compilerOptions4.crossModuleCodeMotion;
        compiler3.initOptions(compilerOptions4);
        compilerOptions4.removeUnusedPrototypeProperties = false;
        org.junit.Assert.assertNotNull(jSErrorArray2);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.devirtualizePrototypeMethods = false;
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy3 = com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC;
        compilerOptions0.propertyRenaming = propertyRenamingPolicy3;
        boolean boolean5 = compilerOptions0.checkCaja;
        boolean boolean6 = compilerOptions0.lineBreak;
        boolean boolean7 = compilerOptions0.smartNameRemoval;
        compilerOptions0.setRewriteNewDateGoogNow(true);
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy3 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC + "'", propertyRenamingPolicy3.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray2 = new com.google.javascript.jscomp.JSSourceFile[] {};
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray3 = new com.google.javascript.jscomp.JSSourceFile[] {};
        com.google.javascript.jscomp.CompilerOptions compilerOptions4 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions4.devirtualizePrototypeMethods = false;
        compilerOptions4.groupVariableDeclarations = false;
        boolean boolean9 = compilerOptions4.ideMode;
        compilerOptions4.setProcessObjectPropertyString(true);
        compilerOptions4.setDefineToBooleanLiteral("BITXOR", true);
        compilerOptions4.checkControlStructures = true;
        java.util.Map<java.lang.String, com.google.javascript.rhino.Node> strMap17 = compilerOptions4.getTweakReplacements();
        com.google.javascript.jscomp.Result result18 = compiler1.compile(jSSourceFileArray2, jSSourceFileArray3, compilerOptions4);
        com.google.javascript.jscomp.SourceExcerptProvider.SourceExcerpt sourceExcerpt19 = null;
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter20 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler1, sourceExcerpt19);
        com.google.javascript.jscomp.Compiler.IntermediateState intermediateState21 = compiler1.getState();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile23 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.CompilerInput compilerInput24 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile23);
        com.google.javascript.jscomp.Region region26 = compilerInput24.getRegion(10);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile28 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        compilerInput24.setSourceFile((com.google.javascript.jscomp.SourceFile) jSSourceFile28);
        jSSourceFile28.clearCachedSource();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile31 = null;
        com.google.javascript.jscomp.CompilerOptions compilerOptions32 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions32.devirtualizePrototypeMethods = false;
        compilerOptions32.groupVariableDeclarations = false;
        boolean boolean37 = compilerOptions32.crossModuleCodeMotion;
        compilerOptions32.setTweakToStringLiteral("", "@IMPLEMENTATION.VERSION@");
        try {
            com.google.javascript.jscomp.Result result41 = compiler1.compile(jSSourceFile28, jSSourceFile31, compilerOptions32);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFileArray2);
        org.junit.Assert.assertNotNull(jSSourceFileArray3);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(strMap17);
        org.junit.Assert.assertNotNull(result18);
        org.junit.Assert.assertNotNull(intermediateState21);
        org.junit.Assert.assertNotNull(jSSourceFile23);
        org.junit.Assert.assertNull(region26);
        org.junit.Assert.assertNotNull(jSSourceFile28);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.CHECK_USELESS_CODE;
        com.google.javascript.jscomp.DiagnosticGroups.UNDEFINED_VARIABLES = diagnosticGroup0;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.jstype.FunctionType functionType1 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType2 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType3 = null;
        closureCodingConvention0.applySubclassRelationship(functionType1, functionType2, subclassType3);
        boolean boolean6 = closureCodingConvention0.isSuperClassReference("");
        java.lang.String str7 = closureCodingConvention0.getAbstractMethodName();
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        node13.removeProp((int) (short) 1);
        com.google.javascript.rhino.Node node21 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        boolean boolean22 = node21.hasMoreThanOneChild();
        node21.setLineno(0);
        boolean boolean25 = node21.hasOneChild();
        com.google.javascript.rhino.jstype.JSType jSType26 = node21.getJSType();
        com.google.javascript.rhino.Node node31 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        node31.removeProp((int) (short) 1);
        com.google.javascript.rhino.Node[] nodeArray34 = new com.google.javascript.rhino.Node[] { node21, node31 };
        com.google.javascript.rhino.Node node37 = new com.google.javascript.rhino.Node((int) (byte) 10, nodeArray34, (int) '4', (int) (byte) -1);
        com.google.javascript.rhino.Node node38 = node13.copyInformationFromForTree(node37);
        com.google.javascript.rhino.Node node43 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        node43.setSourcePositionForTree(20);
        com.google.javascript.rhino.Node node50 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        boolean boolean51 = node50.hasMoreThanOneChild();
        node50.setLineno(0);
        com.google.javascript.rhino.Node node54 = node50.cloneTree();
        com.google.javascript.rhino.Node node59 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        com.google.javascript.rhino.JSDocInfo jSDocInfo60 = null;
        node59.setJSDocInfo(jSDocInfo60);
        java.lang.RuntimeException runtimeException63 = com.google.javascript.rhino.ScriptRuntime.undefReadError((java.lang.Object) node59, (java.lang.Object) 22);
        node59.detachChildren();
        int int65 = node59.getChildCount();
        com.google.javascript.rhino.Node node68 = new com.google.javascript.rhino.Node((int) (short) -1, node38, node43, node54, node59, 15, (int) (byte) 1);
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable69 = node38.siblings();
        boolean boolean70 = closureCodingConvention0.isOptionalParameter(node38);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "goog.abstractMethod" + "'", str7.equals("goog.abstractMethod"));
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNull(jSType26);
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertNotNull(nodeArray34);
        org.junit.Assert.assertNotNull(node38);
        org.junit.Assert.assertNotNull(node43);
        org.junit.Assert.assertNotNull(node50);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertNotNull(node54);
        org.junit.Assert.assertNotNull(node59);
        org.junit.Assert.assertNotNull(runtimeException63);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 0 + "'", int65 == 0);
        org.junit.Assert.assertNotNull(nodeIterable69);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        com.google.javascript.rhino.Node.SideEffectFlags sideEffectFlags0 = new com.google.javascript.rhino.Node.SideEffectFlags();
        sideEffectFlags0.setMutatesThis();
        sideEffectFlags0.setMutatesThis();
        sideEffectFlags0.clearAllFlags();
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.devirtualizePrototypeMethods = false;
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy3 = com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC;
        compilerOptions0.propertyRenaming = propertyRenamingPolicy3;
        boolean boolean5 = compilerOptions0.recordFunctionInformation;
        compilerOptions0.enableExternExports(false);
        byte[] byteArray11 = new byte[] { (byte) -1, (byte) 1, (byte) 10 };
        compilerOptions0.inputVariableMapSerialized = byteArray11;
        compilerOptions0.convertToDottedProperties = true;
        compilerOptions0.instrumentForCoverageOnly = true;
        compilerOptions0.nameReferenceReportPath = "BITXOR";
        java.lang.String str19 = compilerOptions0.renamePrefix;
        compilerOptions0.removeDeadCode = false;
        boolean boolean22 = compilerOptions0.prettyPrint;
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy3 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC + "'", propertyRenamingPolicy3.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(byteArray11);
        org.junit.Assert.assertNull(str19);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.devirtualizePrototypeMethods = false;
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy3 = com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC;
        compilerOptions0.propertyRenaming = propertyRenamingPolicy3;
        boolean boolean5 = compilerOptions0.recordFunctionInformation;
        compilerOptions0.enableExternExports(false);
        byte[] byteArray11 = new byte[] { (byte) -1, (byte) 1, (byte) 10 };
        compilerOptions0.inputVariableMapSerialized = byteArray11;
        compilerOptions0.convertToDottedProperties = true;
        com.google.javascript.jscomp.DiagnosticType diagnosticType15 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        com.google.javascript.jscomp.CheckLevel checkLevel16 = diagnosticType15.defaultLevel;
        compilerOptions0.checkFunctions = checkLevel16;
        boolean boolean18 = compilerOptions0.devirtualizePrototypeMethods;
        boolean boolean19 = compilerOptions0.flowSensitiveInlineVariables;
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy3 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC + "'", propertyRenamingPolicy3.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(byteArray11);
        org.junit.Assert.assertNotNull(diagnosticType15);
        org.junit.Assert.assertTrue("'" + checkLevel16 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel16.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        java.io.InputStream inputStream2 = null;
        try {
            com.google.javascript.jscomp.SourceFile sourceFile3 = com.google.javascript.jscomp.SourceFile.fromInputStream("DiagnosticGroup<typeInvalidation>", "<unknown=160>", inputStream2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        try {
            com.google.javascript.rhino.Context.checkOptimizationLevel(120);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Optimization level outside [-1..9]: 120");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        node5.removeProp((int) (short) 1);
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        boolean boolean14 = node13.hasMoreThanOneChild();
        node13.setLineno(0);
        boolean boolean17 = node13.hasOneChild();
        com.google.javascript.rhino.jstype.JSType jSType18 = node13.getJSType();
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        node23.removeProp((int) (short) 1);
        com.google.javascript.rhino.Node[] nodeArray26 = new com.google.javascript.rhino.Node[] { node13, node23 };
        com.google.javascript.rhino.Node node29 = new com.google.javascript.rhino.Node((int) (byte) 10, nodeArray26, (int) '4', (int) (byte) -1);
        com.google.javascript.rhino.Node node30 = node5.copyInformationFromForTree(node29);
        boolean boolean31 = node29.isNoSideEffectsCall();
        com.google.javascript.rhino.Node node36 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        com.google.javascript.rhino.JSDocInfo jSDocInfo37 = null;
        node36.setJSDocInfo(jSDocInfo37);
        com.google.javascript.rhino.Node node44 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        com.google.javascript.rhino.JSDocInfo jSDocInfo45 = null;
        node44.setJSDocInfo(jSDocInfo45);
        java.lang.RuntimeException runtimeException48 = com.google.javascript.rhino.ScriptRuntime.undefReadError((java.lang.Object) node44, (java.lang.Object) 22);
        node44.detachChildren();
        com.google.javascript.rhino.Node node50 = new com.google.javascript.rhino.Node((int) (short) 100, node44);
        com.google.javascript.rhino.JSDocInfo jSDocInfo51 = null;
        node50.setJSDocInfo(jSDocInfo51);
        com.google.javascript.rhino.Node node53 = new com.google.javascript.rhino.Node((int) (byte) -1, node29, node36, node50);
        com.google.javascript.rhino.Node node57 = com.google.javascript.rhino.Node.newString("hi!", 100, 0);
        node53.addChildToFront(node57);
        node57.detachChildren();
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNull(jSType18);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(nodeArray26);
        org.junit.Assert.assertNotNull(node30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(node36);
        org.junit.Assert.assertNotNull(node44);
        org.junit.Assert.assertNotNull(runtimeException48);
        org.junit.Assert.assertNotNull(node57);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.jstype.FunctionType functionType1 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType2 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType3 = null;
        closureCodingConvention0.applySubclassRelationship(functionType1, functionType2, subclassType3);
        com.google.javascript.rhino.jstype.ObjectType objectType5 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType6 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType7 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType8 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType9 = null;
        closureCodingConvention0.applyDelegateRelationship(objectType5, objectType6, objectType7, functionType8, functionType9);
        java.util.Collection<com.google.javascript.jscomp.CodingConvention.AssertionFunctionSpec> assertionFunctionSpecCollection11 = closureCodingConvention0.getAssertionFunctions();
        java.lang.String str12 = closureCodingConvention0.getAbstractMethodName();
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        boolean boolean18 = node17.hasMoreThanOneChild();
        node17.setLineno(0);
        com.google.javascript.rhino.Node node21 = node17.cloneTree();
        com.google.javascript.rhino.Node node22 = node21.removeFirstChild();
        java.lang.String str23 = closureCodingConvention0.identifyTypeDefAssign(node21);
        int int24 = node21.getChildCount();
        boolean boolean25 = node21.isUnscopedQualifiedName();
        org.junit.Assert.assertNotNull(assertionFunctionSpecCollection11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "goog.abstractMethod" + "'", str12.equals("goog.abstractMethod"));
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertNull(node22);
        org.junit.Assert.assertNull(str23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        com.google.javascript.jscomp.AbstractCompiler abstractCompiler0 = null;
        com.google.javascript.jscomp.NodeTraversal.Callback callback1 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal2 = new com.google.javascript.jscomp.NodeTraversal(abstractCompiler0, callback1);
        com.google.javascript.rhino.Node node3 = nodeTraversal2.getEnclosingFunction();
        try {
            com.google.javascript.jscomp.JSModule jSModule4 = nodeTraversal2.getModule();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(node3);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        node5.removeProp((int) (short) 1);
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        boolean boolean14 = node13.hasMoreThanOneChild();
        node13.setLineno(0);
        boolean boolean17 = node13.hasOneChild();
        com.google.javascript.rhino.jstype.JSType jSType18 = node13.getJSType();
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        node23.removeProp((int) (short) 1);
        com.google.javascript.rhino.Node[] nodeArray26 = new com.google.javascript.rhino.Node[] { node13, node23 };
        com.google.javascript.rhino.Node node29 = new com.google.javascript.rhino.Node((int) (byte) 10, nodeArray26, (int) '4', (int) (byte) -1);
        com.google.javascript.rhino.Node node30 = node5.copyInformationFromForTree(node29);
        com.google.javascript.rhino.Node node35 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        node35.setSourcePositionForTree(20);
        com.google.javascript.rhino.Node node42 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        boolean boolean43 = node42.hasMoreThanOneChild();
        node42.setLineno(0);
        com.google.javascript.rhino.Node node46 = node42.cloneTree();
        com.google.javascript.rhino.Node node51 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        com.google.javascript.rhino.JSDocInfo jSDocInfo52 = null;
        node51.setJSDocInfo(jSDocInfo52);
        java.lang.RuntimeException runtimeException55 = com.google.javascript.rhino.ScriptRuntime.undefReadError((java.lang.Object) node51, (java.lang.Object) 22);
        node51.detachChildren();
        int int57 = node51.getChildCount();
        com.google.javascript.rhino.Node node60 = new com.google.javascript.rhino.Node((int) (short) -1, node30, node35, node46, node51, 15, (int) (byte) 1);
        com.google.javascript.rhino.Node node61 = node51.getFirstChild();
        node51.putIntProp(34, 45);
        java.util.Collection<com.google.javascript.rhino.Node> nodeCollection65 = com.google.javascript.jscomp.NodeUtil.getVarsDeclaredInBranch(node51);
        com.google.javascript.rhino.Node node68 = com.google.javascript.rhino.Node.newString(0, "");
        try {
            node51.removeChild(node68);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNull(jSType18);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(nodeArray26);
        org.junit.Assert.assertNotNull(node30);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertNotNull(node42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(node46);
        org.junit.Assert.assertNotNull(node51);
        org.junit.Assert.assertNotNull(runtimeException55);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 0 + "'", int57 == 0);
        org.junit.Assert.assertNull(node61);
        org.junit.Assert.assertNotNull(nodeCollection65);
        org.junit.Assert.assertNotNull(node68);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.jstype.FunctionType functionType1 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType2 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType3 = null;
        closureCodingConvention0.applySubclassRelationship(functionType1, functionType2, subclassType3);
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        boolean boolean10 = node9.hasMoreThanOneChild();
        node9.setLineno(0);
        com.google.javascript.rhino.Node node13 = node9.cloneTree();
        com.google.javascript.rhino.Node node14 = node13.removeFirstChild();
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        node19.removeProp((int) (short) 1);
        com.google.javascript.rhino.Node node27 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        boolean boolean28 = node27.hasMoreThanOneChild();
        node27.setLineno(0);
        boolean boolean31 = node27.hasOneChild();
        com.google.javascript.rhino.jstype.JSType jSType32 = node27.getJSType();
        com.google.javascript.rhino.Node node37 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        node37.removeProp((int) (short) 1);
        com.google.javascript.rhino.Node[] nodeArray40 = new com.google.javascript.rhino.Node[] { node27, node37 };
        com.google.javascript.rhino.Node node43 = new com.google.javascript.rhino.Node((int) (byte) 10, nodeArray40, (int) '4', (int) (byte) -1);
        com.google.javascript.rhino.Node node44 = node19.copyInformationFromForTree(node43);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder45 = node43.new FileLevelJsDocBuilder();
        java.lang.String str49 = node43.toString(false, false, false);
        boolean boolean50 = node43.isUnscopedQualifiedName();
        int int51 = node43.getLineno();
        java.lang.String str52 = closureCodingConvention0.extractClassNameIfProvide(node13, node43);
        com.google.javascript.rhino.Node node56 = com.google.javascript.rhino.Node.newNumber(1.0d, 26, (int) (short) 1);
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship57 = closureCodingConvention0.getDelegateRelationship(node56);
        boolean boolean59 = closureCodingConvention0.isExported("language version");
        com.google.javascript.rhino.Node node64 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        boolean boolean65 = node64.hasMoreThanOneChild();
        node64.setLineno(0);
        boolean boolean68 = closureCodingConvention0.isOptionalParameter(node64);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNull(node14);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNotNull(node27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNull(jSType32);
        org.junit.Assert.assertNotNull(node37);
        org.junit.Assert.assertNotNull(nodeArray40);
        org.junit.Assert.assertNotNull(node44);
        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "BITXOR" + "'", str49.equals("BITXOR"));
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + (-1) + "'", int51 == (-1));
        org.junit.Assert.assertNull(str52);
        org.junit.Assert.assertNotNull(node56);
        org.junit.Assert.assertNull(delegateRelationship57);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertNotNull(node64);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile1 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.CompilerInput compilerInput2 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile1);
        com.google.javascript.jscomp.JSModule jSModule3 = null;
        compilerInput2.setModule(jSModule3);
        com.google.javascript.jscomp.CompilerInput compilerInput6 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput2, false);
        com.google.javascript.jscomp.Region region8 = compilerInput6.getRegion(32);
        java.lang.String str9 = compilerInput6.getName();
        java.io.PrintStream printStream10 = null;
        com.google.javascript.jscomp.Compiler compiler11 = new com.google.javascript.jscomp.Compiler(printStream10);
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray12 = new com.google.javascript.jscomp.JSSourceFile[] {};
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray13 = new com.google.javascript.jscomp.JSSourceFile[] {};
        com.google.javascript.jscomp.CompilerOptions compilerOptions14 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions14.devirtualizePrototypeMethods = false;
        compilerOptions14.groupVariableDeclarations = false;
        boolean boolean19 = compilerOptions14.ideMode;
        compilerOptions14.setProcessObjectPropertyString(true);
        compilerOptions14.setDefineToBooleanLiteral("BITXOR", true);
        compilerOptions14.checkControlStructures = true;
        java.util.Map<java.lang.String, com.google.javascript.rhino.Node> strMap27 = compilerOptions14.getTweakReplacements();
        com.google.javascript.jscomp.Result result28 = compiler11.compile(jSSourceFileArray12, jSSourceFileArray13, compilerOptions14);
        com.google.javascript.jscomp.JSError[] jSErrorArray29 = compiler11.getErrors();
        com.google.javascript.rhino.Node node30 = compiler11.getRoot();
        compilerInput6.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler11);
        com.google.javascript.jscomp.DiagnosticType diagnosticType35 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        com.google.javascript.jscomp.CheckLevel checkLevel36 = diagnosticType35.level;
        com.google.javascript.jscomp.CheckLevel checkLevel37 = com.google.javascript.jscomp.CheckLevel.OFF;
        diagnosticType35.level = checkLevel37;
        com.google.javascript.jscomp.AbstractCompiler abstractCompiler39 = null;
        com.google.javascript.jscomp.NodeTraversal.Callback callback40 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal41 = new com.google.javascript.jscomp.NodeTraversal(abstractCompiler39, callback40);
        com.google.javascript.rhino.Node node47 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        com.google.javascript.rhino.JSDocInfo jSDocInfo48 = null;
        node47.setJSDocInfo(jSDocInfo48);
        java.lang.RuntimeException runtimeException51 = com.google.javascript.rhino.ScriptRuntime.undefReadError((java.lang.Object) node47, (java.lang.Object) 22);
        node47.detachChildren();
        com.google.javascript.rhino.Node node53 = new com.google.javascript.rhino.Node((int) (short) 100, node47);
        com.google.javascript.jscomp.CompilerOptions compilerOptions54 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CodingConvention codingConvention55 = compilerOptions54.getCodingConvention();
        compilerOptions54.computeFunctionSideEffects = true;
        com.google.javascript.jscomp.CheckLevel checkLevel58 = compilerOptions54.checkRequires;
        com.google.javascript.jscomp.DiagnosticType diagnosticType59 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        com.google.javascript.jscomp.DiagnosticType diagnosticType63 = com.google.javascript.jscomp.Compiler.MOTION_ITERATIONS_ERROR;
        java.lang.String[] strArray70 = new java.lang.String[] { "<unknown=160>", "<unknown=160>", "<unknown=160>", "<unknown=160>", "BITXOR", "DiagnosticGroup<undefinedVars>" };
        com.google.javascript.jscomp.JSError jSError71 = com.google.javascript.jscomp.JSError.make("BITXOR", 32, (int) (short) 100, diagnosticType63, strArray70);
        com.google.javascript.jscomp.JSError jSError72 = nodeTraversal41.makeError(node53, checkLevel58, diagnosticType59, strArray70);
        com.google.javascript.jscomp.JSError jSError73 = com.google.javascript.jscomp.JSError.make("0", (int) (byte) -1, 20, diagnosticType35, strArray70);
        com.google.javascript.jscomp.CheckLevel checkLevel74 = compiler11.getErrorLevel(jSError73);
        com.google.javascript.jscomp.DiagnosticType diagnosticType80 = com.google.javascript.jscomp.DiagnosticType.error("", "hi!");
        com.google.javascript.jscomp.DiagnosticType diagnosticType84 = com.google.javascript.jscomp.Compiler.MOTION_ITERATIONS_ERROR;
        java.lang.String[] strArray91 = new java.lang.String[] { "<unknown=160>", "<unknown=160>", "<unknown=160>", "<unknown=160>", "BITXOR", "DiagnosticGroup<undefinedVars>" };
        com.google.javascript.jscomp.JSError jSError92 = com.google.javascript.jscomp.JSError.make("BITXOR", 32, (int) (short) 100, diagnosticType84, strArray91);
        com.google.javascript.jscomp.JSError jSError93 = com.google.javascript.jscomp.JSError.make("BITXOR", 38, 130, diagnosticType80, strArray91);
        compiler11.report(jSError93);
        com.google.javascript.jscomp.NodeTraversal.Callback callback95 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal96 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler11, callback95);
        com.google.javascript.jscomp.Scope scope97 = nodeTraversal96.getScope();
        org.junit.Assert.assertNotNull(jSSourceFile1);
        org.junit.Assert.assertNull(region8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertNotNull(jSSourceFileArray12);
        org.junit.Assert.assertNotNull(jSSourceFileArray13);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(strMap27);
        org.junit.Assert.assertNotNull(result28);
        org.junit.Assert.assertNotNull(jSErrorArray29);
        org.junit.Assert.assertNotNull(node30);
        org.junit.Assert.assertNotNull(diagnosticType35);
        org.junit.Assert.assertTrue("'" + checkLevel36 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel36.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + checkLevel37 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel37.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(node47);
        org.junit.Assert.assertNotNull(runtimeException51);
        org.junit.Assert.assertNull(codingConvention55);
        org.junit.Assert.assertTrue("'" + checkLevel58 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel58.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(diagnosticType59);
        org.junit.Assert.assertNotNull(diagnosticType63);
        org.junit.Assert.assertNotNull(strArray70);
        org.junit.Assert.assertNotNull(jSError71);
        org.junit.Assert.assertNotNull(jSError72);
        org.junit.Assert.assertNotNull(jSError73);
        org.junit.Assert.assertNull(checkLevel74);
        org.junit.Assert.assertNotNull(diagnosticType80);
        org.junit.Assert.assertNotNull(diagnosticType84);
        org.junit.Assert.assertNotNull(strArray91);
        org.junit.Assert.assertNotNull(jSError92);
        org.junit.Assert.assertNotNull(jSError93);
        org.junit.Assert.assertNull(scope97);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.devirtualizePrototypeMethods = false;
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy3 = com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC;
        compilerOptions0.propertyRenaming = propertyRenamingPolicy3;
        boolean boolean5 = compilerOptions0.recordFunctionInformation;
        compilerOptions0.optimizeArgumentsArray = false;
        com.google.javascript.jscomp.DiagnosticType diagnosticType8 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        com.google.javascript.jscomp.CheckLevel checkLevel9 = diagnosticType8.defaultLevel;
        compilerOptions0.checkMethods = checkLevel9;
        com.google.javascript.jscomp.CheckLevel checkLevel11 = compilerOptions0.checkRequires;
        compilerOptions0.setRewriteNewDateGoogNow(true);
        compilerOptions0.skipAllCompilerPasses();
        compilerOptions0.aliasKeywords = true;
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy3 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC + "'", propertyRenamingPolicy3.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(diagnosticType8);
        org.junit.Assert.assertTrue("'" + checkLevel9 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel9.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + checkLevel11 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel11.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        boolean boolean5 = node4.hasMoreThanOneChild();
        node4.setLineno(0);
        com.google.javascript.rhino.Node node8 = node4.cloneTree();
        com.google.javascript.rhino.Node node9 = node8.removeFirstChild();
        try {
            node9.removeProp(34);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNull(node9);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray2 = new com.google.javascript.jscomp.JSSourceFile[] {};
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray3 = new com.google.javascript.jscomp.JSSourceFile[] {};
        com.google.javascript.jscomp.CompilerOptions compilerOptions4 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions4.devirtualizePrototypeMethods = false;
        compilerOptions4.groupVariableDeclarations = false;
        boolean boolean9 = compilerOptions4.ideMode;
        compilerOptions4.setProcessObjectPropertyString(true);
        compilerOptions4.setDefineToBooleanLiteral("BITXOR", true);
        compilerOptions4.checkControlStructures = true;
        java.util.Map<java.lang.String, com.google.javascript.rhino.Node> strMap17 = compilerOptions4.getTweakReplacements();
        com.google.javascript.jscomp.Result result18 = compiler1.compile(jSSourceFileArray2, jSSourceFileArray3, compilerOptions4);
        com.google.javascript.jscomp.JSError[] jSErrorArray19 = compiler1.getErrors();
        com.google.javascript.rhino.Node node20 = compiler1.getRoot();
        com.google.javascript.rhino.Node node21 = node20.removeChildren();
        node20.setIsSyntheticBlock(true);
        try {
            node20.setString("OR");
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: BLOCK [synthetic: 1] is not a string node");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFileArray2);
        org.junit.Assert.assertNotNull(jSSourceFileArray3);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(strMap17);
        org.junit.Assert.assertNotNull(result18);
        org.junit.Assert.assertNotNull(jSErrorArray19);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNotNull(node21);
    }
}

