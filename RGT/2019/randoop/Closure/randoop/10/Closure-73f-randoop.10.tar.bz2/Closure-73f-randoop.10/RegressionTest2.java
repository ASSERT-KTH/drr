import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest2 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray2 = new com.google.javascript.jscomp.JSSourceFile[] {};
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray3 = new com.google.javascript.jscomp.JSSourceFile[] {};
        com.google.javascript.jscomp.CompilerOptions compilerOptions4 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions4.devirtualizePrototypeMethods = false;
        compilerOptions4.groupVariableDeclarations = false;
        boolean boolean9 = compilerOptions4.ideMode;
        compilerOptions4.setProcessObjectPropertyString(true);
        compilerOptions4.setDefineToBooleanLiteral("BITXOR", true);
        compilerOptions4.checkControlStructures = true;
        java.util.Map<java.lang.String, com.google.javascript.rhino.Node> strMap17 = compilerOptions4.getTweakReplacements();
        com.google.javascript.jscomp.Result result18 = compiler1.compile(jSSourceFileArray2, jSSourceFileArray3, compilerOptions4);
        com.google.javascript.jscomp.JSError[] jSErrorArray19 = compiler1.getErrors();
        com.google.javascript.jscomp.JSError[] jSErrorArray20 = compiler1.getMessages();
        com.google.javascript.jscomp.AbstractCompiler abstractCompiler21 = null;
        com.google.javascript.jscomp.NodeTraversal.Callback callback22 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal23 = new com.google.javascript.jscomp.NodeTraversal(abstractCompiler21, callback22);
        com.google.javascript.rhino.Node node29 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        com.google.javascript.rhino.JSDocInfo jSDocInfo30 = null;
        node29.setJSDocInfo(jSDocInfo30);
        java.lang.RuntimeException runtimeException33 = com.google.javascript.rhino.ScriptRuntime.undefReadError((java.lang.Object) node29, (java.lang.Object) 22);
        node29.detachChildren();
        com.google.javascript.rhino.Node node35 = new com.google.javascript.rhino.Node((int) (short) 100, node29);
        com.google.javascript.jscomp.CompilerOptions compilerOptions36 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CodingConvention codingConvention37 = compilerOptions36.getCodingConvention();
        compilerOptions36.computeFunctionSideEffects = true;
        com.google.javascript.jscomp.CheckLevel checkLevel40 = compilerOptions36.checkRequires;
        com.google.javascript.jscomp.DiagnosticType diagnosticType41 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        com.google.javascript.jscomp.DiagnosticType diagnosticType45 = com.google.javascript.jscomp.Compiler.MOTION_ITERATIONS_ERROR;
        java.lang.String[] strArray52 = new java.lang.String[] { "<unknown=160>", "<unknown=160>", "<unknown=160>", "<unknown=160>", "BITXOR", "DiagnosticGroup<undefinedVars>" };
        com.google.javascript.jscomp.JSError jSError53 = com.google.javascript.jscomp.JSError.make("BITXOR", 32, (int) (short) 100, diagnosticType45, strArray52);
        com.google.javascript.jscomp.JSError jSError54 = nodeTraversal23.makeError(node35, checkLevel40, diagnosticType41, strArray52);
        com.google.javascript.jscomp.DiagnosticType diagnosticType55 = jSError54.getType();
        compiler1.report(jSError54);
        org.junit.Assert.assertNotNull(jSSourceFileArray2);
        org.junit.Assert.assertNotNull(jSSourceFileArray3);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(strMap17);
        org.junit.Assert.assertNotNull(result18);
        org.junit.Assert.assertNotNull(jSErrorArray19);
        org.junit.Assert.assertNotNull(jSErrorArray20);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNotNull(runtimeException33);
        org.junit.Assert.assertNull(codingConvention37);
        org.junit.Assert.assertTrue("'" + checkLevel40 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel40.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(diagnosticType41);
        org.junit.Assert.assertNotNull(diagnosticType45);
        org.junit.Assert.assertNotNull(strArray52);
        org.junit.Assert.assertNotNull(jSError53);
        org.junit.Assert.assertNotNull(jSError54);
        org.junit.Assert.assertNotNull(diagnosticType55);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test002");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention1 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.jstype.FunctionType functionType2 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType3 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType4 = null;
        closureCodingConvention1.applySubclassRelationship(functionType2, functionType3, subclassType4);
        boolean boolean7 = closureCodingConvention1.isSuperClassReference("");
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        node12.removeProp((int) (short) 1);
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        boolean boolean21 = node20.hasMoreThanOneChild();
        node20.setLineno(0);
        boolean boolean24 = node20.hasOneChild();
        com.google.javascript.rhino.jstype.JSType jSType25 = node20.getJSType();
        com.google.javascript.rhino.Node node30 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        node30.removeProp((int) (short) 1);
        com.google.javascript.rhino.Node[] nodeArray33 = new com.google.javascript.rhino.Node[] { node20, node30 };
        com.google.javascript.rhino.Node node36 = new com.google.javascript.rhino.Node((int) (byte) 10, nodeArray33, (int) '4', (int) (byte) -1);
        com.google.javascript.rhino.Node node37 = node12.copyInformationFromForTree(node36);
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention38 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.jstype.FunctionType functionType39 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType40 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType41 = null;
        closureCodingConvention38.applySubclassRelationship(functionType39, functionType40, subclassType41);
        com.google.javascript.rhino.jstype.FunctionType functionType43 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType44 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType45 = null;
        closureCodingConvention38.applySubclassRelationship(functionType43, functionType44, subclassType45);
        com.google.javascript.rhino.Node node51 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        node51.removeProp((int) (short) 1);
        com.google.javascript.rhino.Node node59 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        boolean boolean60 = node59.hasMoreThanOneChild();
        node59.setLineno(0);
        boolean boolean63 = node59.hasOneChild();
        com.google.javascript.rhino.jstype.JSType jSType64 = node59.getJSType();
        com.google.javascript.rhino.Node node69 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        node69.removeProp((int) (short) 1);
        com.google.javascript.rhino.Node[] nodeArray72 = new com.google.javascript.rhino.Node[] { node59, node69 };
        com.google.javascript.rhino.Node node75 = new com.google.javascript.rhino.Node((int) (byte) 10, nodeArray72, (int) '4', (int) (byte) -1);
        com.google.javascript.rhino.Node node76 = node51.copyInformationFromForTree(node75);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder77 = node75.new FileLevelJsDocBuilder();
        java.lang.String str81 = node75.toString(false, false, false);
        com.google.javascript.jscomp.CodingConvention.SubclassRelationship subclassRelationship82 = closureCodingConvention38.getClassesDefinedByCall(node75);
        java.lang.String str83 = closureCodingConvention1.extractClassNameIfProvide(node12, node75);
        com.google.javascript.rhino.Node[] nodeArray84 = new com.google.javascript.rhino.Node[] { node75 };
        com.google.javascript.rhino.Node node85 = new com.google.javascript.rhino.Node(27, nodeArray84);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder86 = node85.getJsDocBuilderForNode();
        fileLevelJsDocBuilder86.append("error reporter");
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNull(jSType25);
        org.junit.Assert.assertNotNull(node30);
        org.junit.Assert.assertNotNull(nodeArray33);
        org.junit.Assert.assertNotNull(node37);
        org.junit.Assert.assertNotNull(node51);
        org.junit.Assert.assertNotNull(node59);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertNull(jSType64);
        org.junit.Assert.assertNotNull(node69);
        org.junit.Assert.assertNotNull(nodeArray72);
        org.junit.Assert.assertNotNull(node76);
        org.junit.Assert.assertTrue("'" + str81 + "' != '" + "BITXOR" + "'", str81.equals("BITXOR"));
        org.junit.Assert.assertNull(subclassRelationship82);
        org.junit.Assert.assertNull(str83);
        org.junit.Assert.assertNotNull(nodeArray84);
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder86);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test003");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeUnusedLocalVars = false;
        com.google.javascript.jscomp.CheckLevel checkLevel3 = compilerOptions0.checkRequires;
        boolean boolean4 = compilerOptions0.isExternExportsEnabled();
        org.junit.Assert.assertTrue("'" + checkLevel3 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel3.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test004");
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        boolean boolean7 = node6.hasMoreThanOneChild();
        node6.setLineno(0);
        boolean boolean10 = node6.hasOneChild();
        com.google.javascript.rhino.jstype.JSType jSType11 = node6.getJSType();
        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        node16.removeProp((int) (short) 1);
        com.google.javascript.rhino.Node[] nodeArray19 = new com.google.javascript.rhino.Node[] { node6, node16 };
        com.google.javascript.rhino.Node node22 = new com.google.javascript.rhino.Node((int) (byte) 10, nodeArray19, (int) '4', (int) (byte) -1);
        try {
            com.google.javascript.rhino.Node node23 = new com.google.javascript.rhino.Node(21, nodeArray19);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: duplicate child");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNull(jSType11);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertNotNull(nodeArray19);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test005");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        node4.removeProp((int) (short) 1);
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        boolean boolean13 = node12.hasMoreThanOneChild();
        node12.setLineno(0);
        boolean boolean16 = node12.hasOneChild();
        com.google.javascript.rhino.jstype.JSType jSType17 = node12.getJSType();
        com.google.javascript.rhino.Node node22 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        node22.removeProp((int) (short) 1);
        com.google.javascript.rhino.Node[] nodeArray25 = new com.google.javascript.rhino.Node[] { node12, node22 };
        com.google.javascript.rhino.Node node28 = new com.google.javascript.rhino.Node((int) (byte) 10, nodeArray25, (int) '4', (int) (byte) -1);
        com.google.javascript.rhino.Node node29 = node4.copyInformationFromForTree(node28);
        boolean boolean30 = node4.hasChildren();
        java.util.Collection<com.google.javascript.rhino.Node> nodeCollection31 = com.google.javascript.jscomp.NodeUtil.getVarsDeclaredInBranch(node4);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder32 = node4.getJsDocBuilderForNode();
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNull(jSType17);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertNotNull(nodeArray25);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(nodeCollection31);
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder32);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test006");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.devirtualizePrototypeMethods = false;
        compilerOptions0.groupVariableDeclarations = false;
        boolean boolean5 = compilerOptions0.crossModuleCodeMotion;
        java.lang.String[] strArray21 = new java.lang.String[] { "", "hi!", "language version", "BITXOR", "(goog.exportSymbol)", "DiagnosticGroup<undefinedVars>", "goog.global", "goog.abstractMethod", "goog.exportProperty", "Unknown class name", "Unknown class name", "goog.exportSymbol", "DiagnosticGroup<undefinedVars>: <unknown=160>", "Not declared as a type name", "0" };
        java.util.ArrayList<java.lang.String> strList22 = new java.util.ArrayList<java.lang.String>();
        boolean boolean23 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strList22, strArray21);
        compilerOptions0.setManageClosureDependencies((java.util.List<java.lang.String>) strList22);
        compilerOptions0.gatherCssNames = false;
        compilerOptions0.setRewriteNewDateGoogNow(true);
        com.google.javascript.jscomp.CompilerOptions compilerOptions29 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions29.devirtualizePrototypeMethods = false;
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy32 = com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC;
        compilerOptions29.propertyRenaming = propertyRenamingPolicy32;
        boolean boolean34 = compilerOptions29.recordFunctionInformation;
        compilerOptions29.optimizeArgumentsArray = false;
        com.google.javascript.jscomp.DiagnosticType diagnosticType37 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        com.google.javascript.jscomp.CheckLevel checkLevel38 = diagnosticType37.defaultLevel;
        compilerOptions29.checkMethods = checkLevel38;
        com.google.javascript.jscomp.CompilerOptions compilerOptions40 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions40.devirtualizePrototypeMethods = false;
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy43 = com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC;
        compilerOptions40.propertyRenaming = propertyRenamingPolicy43;
        boolean boolean45 = compilerOptions40.recordFunctionInformation;
        compilerOptions40.enableExternExports(false);
        com.google.javascript.jscomp.CheckLevel checkLevel48 = compilerOptions40.checkUnreachableCode;
        com.google.javascript.jscomp.CheckLevel checkLevel49 = compilerOptions40.reportMissingOverride;
        compilerOptions29.checkProvides = checkLevel49;
        compilerOptions0.brokenClosureRequiresLevel = checkLevel49;
        compilerOptions0.setAcceptConstKeyword(true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(strArray21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy32 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC + "'", propertyRenamingPolicy32.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC));
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(diagnosticType37);
        org.junit.Assert.assertTrue("'" + checkLevel38 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel38.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy43 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC + "'", propertyRenamingPolicy43.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC));
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + checkLevel48 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel48.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + checkLevel49 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel49.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test007");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        com.google.javascript.rhino.JSDocInfo jSDocInfo5 = null;
        node4.setJSDocInfo(jSDocInfo5);
        node4.setType(100);
        boolean boolean9 = node4.isUnscopedQualifiedName();
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test008");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile1 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.CompilerInput compilerInput2 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile1);
        com.google.javascript.jscomp.JSModule jSModule3 = null;
        compilerInput2.setModule(jSModule3);
        com.google.javascript.jscomp.CompilerInput compilerInput6 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput2, false);
        com.google.javascript.jscomp.Region region8 = compilerInput6.getRegion(32);
        java.lang.String str9 = compilerInput6.getName();
        java.io.PrintStream printStream10 = null;
        com.google.javascript.jscomp.Compiler compiler11 = new com.google.javascript.jscomp.Compiler(printStream10);
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray12 = new com.google.javascript.jscomp.JSSourceFile[] {};
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray13 = new com.google.javascript.jscomp.JSSourceFile[] {};
        com.google.javascript.jscomp.CompilerOptions compilerOptions14 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions14.devirtualizePrototypeMethods = false;
        compilerOptions14.groupVariableDeclarations = false;
        boolean boolean19 = compilerOptions14.ideMode;
        compilerOptions14.setProcessObjectPropertyString(true);
        compilerOptions14.setDefineToBooleanLiteral("BITXOR", true);
        compilerOptions14.checkControlStructures = true;
        java.util.Map<java.lang.String, com.google.javascript.rhino.Node> strMap27 = compilerOptions14.getTweakReplacements();
        com.google.javascript.jscomp.Result result28 = compiler11.compile(jSSourceFileArray12, jSSourceFileArray13, compilerOptions14);
        com.google.javascript.jscomp.JSError[] jSErrorArray29 = compiler11.getErrors();
        com.google.javascript.rhino.Node node30 = compiler11.getRoot();
        compilerInput6.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler11);
        com.google.javascript.jscomp.DiagnosticType diagnosticType35 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        com.google.javascript.jscomp.CheckLevel checkLevel36 = diagnosticType35.level;
        com.google.javascript.jscomp.CheckLevel checkLevel37 = com.google.javascript.jscomp.CheckLevel.OFF;
        diagnosticType35.level = checkLevel37;
        com.google.javascript.jscomp.AbstractCompiler abstractCompiler39 = null;
        com.google.javascript.jscomp.NodeTraversal.Callback callback40 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal41 = new com.google.javascript.jscomp.NodeTraversal(abstractCompiler39, callback40);
        com.google.javascript.rhino.Node node47 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        com.google.javascript.rhino.JSDocInfo jSDocInfo48 = null;
        node47.setJSDocInfo(jSDocInfo48);
        java.lang.RuntimeException runtimeException51 = com.google.javascript.rhino.ScriptRuntime.undefReadError((java.lang.Object) node47, (java.lang.Object) 22);
        node47.detachChildren();
        com.google.javascript.rhino.Node node53 = new com.google.javascript.rhino.Node((int) (short) 100, node47);
        com.google.javascript.jscomp.CompilerOptions compilerOptions54 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CodingConvention codingConvention55 = compilerOptions54.getCodingConvention();
        compilerOptions54.computeFunctionSideEffects = true;
        com.google.javascript.jscomp.CheckLevel checkLevel58 = compilerOptions54.checkRequires;
        com.google.javascript.jscomp.DiagnosticType diagnosticType59 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        com.google.javascript.jscomp.DiagnosticType diagnosticType63 = com.google.javascript.jscomp.Compiler.MOTION_ITERATIONS_ERROR;
        java.lang.String[] strArray70 = new java.lang.String[] { "<unknown=160>", "<unknown=160>", "<unknown=160>", "<unknown=160>", "BITXOR", "DiagnosticGroup<undefinedVars>" };
        com.google.javascript.jscomp.JSError jSError71 = com.google.javascript.jscomp.JSError.make("BITXOR", 32, (int) (short) 100, diagnosticType63, strArray70);
        com.google.javascript.jscomp.JSError jSError72 = nodeTraversal41.makeError(node53, checkLevel58, diagnosticType59, strArray70);
        com.google.javascript.jscomp.JSError jSError73 = com.google.javascript.jscomp.JSError.make("0", (int) (byte) -1, 20, diagnosticType35, strArray70);
        com.google.javascript.jscomp.CheckLevel checkLevel74 = compiler11.getErrorLevel(jSError73);
        com.google.javascript.jscomp.DiagnosticType diagnosticType80 = com.google.javascript.jscomp.DiagnosticType.error("", "hi!");
        com.google.javascript.jscomp.DiagnosticType diagnosticType84 = com.google.javascript.jscomp.Compiler.MOTION_ITERATIONS_ERROR;
        java.lang.String[] strArray91 = new java.lang.String[] { "<unknown=160>", "<unknown=160>", "<unknown=160>", "<unknown=160>", "BITXOR", "DiagnosticGroup<undefinedVars>" };
        com.google.javascript.jscomp.JSError jSError92 = com.google.javascript.jscomp.JSError.make("BITXOR", 32, (int) (short) 100, diagnosticType84, strArray91);
        com.google.javascript.jscomp.JSError jSError93 = com.google.javascript.jscomp.JSError.make("BITXOR", 38, 130, diagnosticType80, strArray91);
        compiler11.report(jSError93);
        java.lang.String str95 = jSError93.description;
        org.junit.Assert.assertNotNull(jSSourceFile1);
        org.junit.Assert.assertNull(region8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertNotNull(jSSourceFileArray12);
        org.junit.Assert.assertNotNull(jSSourceFileArray13);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(strMap27);
        org.junit.Assert.assertNotNull(result28);
        org.junit.Assert.assertNotNull(jSErrorArray29);
        org.junit.Assert.assertNotNull(node30);
        org.junit.Assert.assertNotNull(diagnosticType35);
        org.junit.Assert.assertTrue("'" + checkLevel36 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel36.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + checkLevel37 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel37.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(node47);
        org.junit.Assert.assertNotNull(runtimeException51);
        org.junit.Assert.assertNull(codingConvention55);
        org.junit.Assert.assertTrue("'" + checkLevel58 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel58.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(diagnosticType59);
        org.junit.Assert.assertNotNull(diagnosticType63);
        org.junit.Assert.assertNotNull(strArray70);
        org.junit.Assert.assertNotNull(jSError71);
        org.junit.Assert.assertNotNull(jSError72);
        org.junit.Assert.assertNotNull(jSError73);
        org.junit.Assert.assertNull(checkLevel74);
        org.junit.Assert.assertNotNull(diagnosticType80);
        org.junit.Assert.assertNotNull(diagnosticType84);
        org.junit.Assert.assertNotNull(strArray91);
        org.junit.Assert.assertNotNull(jSError92);
        org.junit.Assert.assertNotNull(jSError93);
        org.junit.Assert.assertTrue("'" + str95 + "' != '" + "hi!" + "'", str95.equals("hi!"));
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test009");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newNumber((double) 30, 34, 25);
        com.google.javascript.rhino.Node node4 = node3.removeFirstChild();
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNull(node4);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test010");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeUnusedLocalVars = false;
        compilerOptions0.crossModuleCodeMotion = false;
        compilerOptions0.ambiguateProperties = false;
        compilerOptions0.checkTypedPropertyCalls = true;
        java.lang.String str9 = compilerOptions0.syntheticBlockEndMarker;
        java.util.Set<java.lang.String> strSet10 = compilerOptions0.stripTypes;
        boolean boolean11 = compilerOptions0.checkTypes;
        com.google.javascript.jscomp.CheckLevel checkLevel12 = compilerOptions0.aggressiveVarCheck;
        com.google.common.collect.Multimap<com.google.javascript.jscomp.CustomPassExecutionTime, com.google.javascript.jscomp.CompilerPass> customPassExecutionTimeMultimap13 = compilerOptions0.customPasses;
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertNotNull(strSet10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + checkLevel12 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel12.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNull(customPassExecutionTimeMultimap13);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test011");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.debugFunctionSideEffectsPath = "";
        compilerOptions0.collapseVariableDeclarations = true;
        com.google.javascript.jscomp.CompilerOptions compilerOptions5 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CodingConvention codingConvention6 = compilerOptions5.getCodingConvention();
        compilerOptions5.computeFunctionSideEffects = true;
        byte[] byteArray9 = compilerOptions5.inputPropertyMapSerialized;
        com.google.javascript.jscomp.CompilerOptions compilerOptions10 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions10.removeUnusedLocalVars = false;
        compilerOptions10.crossModuleCodeMotion = false;
        compilerOptions10.ambiguateProperties = false;
        compilerOptions10.checkTypedPropertyCalls = true;
        java.lang.String str19 = compilerOptions10.syntheticBlockEndMarker;
        java.util.Set<java.lang.String> strSet20 = compilerOptions10.stripTypes;
        compilerOptions5.setIdGenerators(strSet20);
        compilerOptions0.setIdGenerators(strSet20);
        com.google.javascript.jscomp.CompilerOptions compilerOptions23 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions23.devirtualizePrototypeMethods = false;
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy26 = com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC;
        compilerOptions23.propertyRenaming = propertyRenamingPolicy26;
        boolean boolean28 = compilerOptions23.recordFunctionInformation;
        compilerOptions23.enableExternExports(false);
        byte[] byteArray34 = new byte[] { (byte) -1, (byte) 1, (byte) 10 };
        compilerOptions23.inputVariableMapSerialized = byteArray34;
        compilerOptions0.inputVariableMapSerialized = byteArray34;
        compilerOptions0.checkSuspiciousCode = true;
        compilerOptions0.aliasStringsBlacklist = "error reporter";
        org.junit.Assert.assertNull(codingConvention6);
        org.junit.Assert.assertNull(byteArray9);
        org.junit.Assert.assertNull(str19);
        org.junit.Assert.assertNotNull(strSet20);
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy26 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC + "'", propertyRenamingPolicy26.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC));
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(byteArray34);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test012");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.devirtualizePrototypeMethods = false;
        java.lang.String str3 = compilerOptions0.syntheticBlockStartMarker;
        compilerOptions0.aliasStringsBlacklist = "goog.exportProperty";
        compilerOptions0.smartNameRemoval = false;
        com.google.javascript.jscomp.SourceMap.DetailLevel detailLevel8 = compilerOptions0.sourceMapDetailLevel;
        com.google.javascript.jscomp.CompilerOptions compilerOptions9 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions9.devirtualizePrototypeMethods = false;
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy12 = com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC;
        compilerOptions9.propertyRenaming = propertyRenamingPolicy12;
        boolean boolean14 = compilerOptions9.recordFunctionInformation;
        compilerOptions9.enableExternExports(false);
        compilerOptions9.removeDeadCode = false;
        compilerOptions9.smartNameRemoval = false;
        compilerOptions9.checkTypes = false;
        com.google.javascript.jscomp.SourceMap.Format format23 = compilerOptions9.sourceMapFormat;
        compilerOptions0.sourceMapFormat = format23;
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNotNull(detailLevel8);
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy12 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC + "'", propertyRenamingPolicy12.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(format23);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test013");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile3 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        jSSourceFile3.clearCachedSource();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile6 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile8 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        jSSourceFile8.clearCachedSource();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile11 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.CompilerInput compilerInput12 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile11);
        boolean boolean13 = compilerInput12.isExtern();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile15 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        java.lang.String str16 = jSSourceFile15.getOriginalPath();
        compilerInput12.setSourceFile((com.google.javascript.jscomp.SourceFile) jSSourceFile15);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile19 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.CompilerInput compilerInput20 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile19);
        com.google.javascript.jscomp.CompilerInput compilerInput22 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile19, true);
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray23 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile3, jSSourceFile6, jSSourceFile8, jSSourceFile15, jSSourceFile19 };
        java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList24 = new java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile>();
        boolean boolean25 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList24, jSSourceFileArray23);
        com.google.javascript.jscomp.JSModule[] jSModuleArray26 = new com.google.javascript.jscomp.JSModule[] {};
        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList27 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
        boolean boolean28 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList27, jSModuleArray26);
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph29 = new com.google.javascript.jscomp.JSModuleGraph((java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList27);
        com.google.javascript.jscomp.CompilerOptions compilerOptions30 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions30.devirtualizePrototypeMethods = false;
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy33 = com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC;
        compilerOptions30.propertyRenaming = propertyRenamingPolicy33;
        boolean boolean35 = compilerOptions30.recordFunctionInformation;
        compilerOptions30.enableExternExports(false);
        byte[] byteArray41 = new byte[] { (byte) -1, (byte) 1, (byte) 10 };
        compilerOptions30.inputVariableMapSerialized = byteArray41;
        compilerOptions30.convertToDottedProperties = true;
        compilerOptions30.instrumentForCoverageOnly = true;
        compilerOptions30.nameReferenceReportPath = "BITXOR";
        com.google.javascript.jscomp.Result result49 = compiler1.compileModules((java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList24, (java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList27, compilerOptions30);
        com.google.javascript.jscomp.AbstractCompiler abstractCompiler50 = null;
        com.google.javascript.jscomp.NodeTraversal.Callback callback51 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal52 = new com.google.javascript.jscomp.NodeTraversal(abstractCompiler50, callback51);
        com.google.javascript.rhino.Node node58 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        com.google.javascript.rhino.JSDocInfo jSDocInfo59 = null;
        node58.setJSDocInfo(jSDocInfo59);
        java.lang.RuntimeException runtimeException62 = com.google.javascript.rhino.ScriptRuntime.undefReadError((java.lang.Object) node58, (java.lang.Object) 22);
        node58.detachChildren();
        com.google.javascript.rhino.Node node64 = new com.google.javascript.rhino.Node((int) (short) 100, node58);
        com.google.javascript.jscomp.CompilerOptions compilerOptions65 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CodingConvention codingConvention66 = compilerOptions65.getCodingConvention();
        compilerOptions65.computeFunctionSideEffects = true;
        com.google.javascript.jscomp.CheckLevel checkLevel69 = compilerOptions65.checkRequires;
        com.google.javascript.jscomp.DiagnosticType diagnosticType70 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        com.google.javascript.jscomp.DiagnosticType diagnosticType74 = com.google.javascript.jscomp.Compiler.MOTION_ITERATIONS_ERROR;
        java.lang.String[] strArray81 = new java.lang.String[] { "<unknown=160>", "<unknown=160>", "<unknown=160>", "<unknown=160>", "BITXOR", "DiagnosticGroup<undefinedVars>" };
        com.google.javascript.jscomp.JSError jSError82 = com.google.javascript.jscomp.JSError.make("BITXOR", 32, (int) (short) 100, diagnosticType74, strArray81);
        com.google.javascript.jscomp.JSError jSError83 = nodeTraversal52.makeError(node64, checkLevel69, diagnosticType70, strArray81);
        java.lang.String str84 = jSError83.sourceName;
        com.google.javascript.jscomp.CompilerOptions compilerOptions85 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions85.devirtualizePrototypeMethods = false;
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy88 = com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC;
        compilerOptions85.propertyRenaming = propertyRenamingPolicy88;
        java.util.Set<java.lang.String> strSet90 = compilerOptions85.stripNameSuffixes;
        boolean boolean91 = jSError83.equals((java.lang.Object) strSet90);
        com.google.javascript.jscomp.CheckLevel checkLevel92 = compiler1.getErrorLevel(jSError83);
        org.junit.Assert.assertNotNull(jSSourceFile3);
        org.junit.Assert.assertNotNull(jSSourceFile6);
        org.junit.Assert.assertNotNull(jSSourceFile8);
        org.junit.Assert.assertNotNull(jSSourceFile11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(jSSourceFile15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
        org.junit.Assert.assertNotNull(jSSourceFile19);
        org.junit.Assert.assertNotNull(jSSourceFileArray23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(jSModuleArray26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy33 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC + "'", propertyRenamingPolicy33.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC));
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(byteArray41);
        org.junit.Assert.assertNotNull(result49);
        org.junit.Assert.assertNotNull(node58);
        org.junit.Assert.assertNotNull(runtimeException62);
        org.junit.Assert.assertNull(codingConvention66);
        org.junit.Assert.assertTrue("'" + checkLevel69 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel69.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(diagnosticType70);
        org.junit.Assert.assertNotNull(diagnosticType74);
        org.junit.Assert.assertNotNull(strArray81);
        org.junit.Assert.assertNotNull(jSError82);
        org.junit.Assert.assertNotNull(jSError83);
        org.junit.Assert.assertTrue("'" + str84 + "' != '" + "" + "'", str84.equals(""));
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy88 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC + "'", propertyRenamingPolicy88.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC));
        org.junit.Assert.assertNotNull(strSet90);
        org.junit.Assert.assertTrue("'" + boolean91 + "' != '" + false + "'", boolean91 == false);
        org.junit.Assert.assertNull(checkLevel92);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test014");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.devirtualizePrototypeMethods = false;
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy3 = com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC;
        compilerOptions0.propertyRenaming = propertyRenamingPolicy3;
        boolean boolean5 = compilerOptions0.recordFunctionInformation;
        compilerOptions0.setColorizeErrorOutput(false);
        boolean boolean8 = compilerOptions0.specializeInitialModule;
        compilerOptions0.computeFunctionSideEffects = false;
        compilerOptions0.setDefineToNumberLiteral("language version", 37);
        boolean boolean14 = compilerOptions0.markAsCompiled;
        compilerOptions0.ambiguateProperties = true;
        compilerOptions0.ideMode = true;
        compilerOptions0.generateExports = false;
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy3 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC + "'", propertyRenamingPolicy3.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test015");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.devirtualizePrototypeMethods = false;
        compilerOptions0.groupVariableDeclarations = false;
        boolean boolean5 = compilerOptions0.crossModuleCodeMotion;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap6 = null;
        compilerOptions0.cssRenamingMap = cssRenamingMap6;
        byte[] byteArray8 = compilerOptions0.inputPropertyMapSerialized;
        com.google.javascript.jscomp.CheckLevel checkLevel9 = compilerOptions0.aggressiveVarCheck;
        compilerOptions0.removeUnusedPrototypeProperties = true;
        boolean boolean12 = compilerOptions0.extractPrototypeMemberDeclarations;
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(byteArray8);
        org.junit.Assert.assertTrue("'" + checkLevel9 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel9.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test016");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.devirtualizePrototypeMethods = false;
        compilerOptions0.groupVariableDeclarations = false;
        boolean boolean5 = compilerOptions0.ideMode;
        compilerOptions0.setProcessObjectPropertyString(true);
        compilerOptions0.setDefineToBooleanLiteral("BITXOR", true);
        compilerOptions0.checkControlStructures = true;
        compilerOptions0.checkUnusedPropertiesEarly = false;
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test017");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newNumber(0.0d, 160, 15);
        boolean boolean4 = node3.hasSideEffects();
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test018");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.devirtualizePrototypeMethods = false;
        compilerOptions0.groupVariableDeclarations = false;
        java.util.Set<java.lang.String> strSet5 = compilerOptions0.stripNamePrefixes;
        java.lang.String str6 = compilerOptions0.syntheticBlockEndMarker;
        com.google.javascript.jscomp.DiagnosticType diagnosticType7 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        com.google.javascript.jscomp.CheckLevel checkLevel8 = diagnosticType7.level;
        compilerOptions0.reportMissingOverride = checkLevel8;
        compilerOptions0.inlineVariables = false;
        compilerOptions0.setAcceptConstKeyword(true);
        com.google.javascript.jscomp.SourceMap.Format format14 = null;
        compilerOptions0.sourceMapFormat = format14;
        com.google.javascript.jscomp.CheckLevel checkLevel16 = compilerOptions0.checkUndefinedProperties;
        org.junit.Assert.assertNotNull(strSet5);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNotNull(diagnosticType7);
        org.junit.Assert.assertTrue("'" + checkLevel8 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel8.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + checkLevel16 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel16.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test019");
        com.google.javascript.rhino.EvaluatorException evaluatorException3 = new com.google.javascript.rhino.EvaluatorException("null(ERROR), null(ERROR), null(ERROR), null(ERROR)", "null(ERROR), null(ERROR), null(ERROR), null(ERROR)", 0);
        evaluatorException3.initLineSource("goog.global");
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test020");
        com.google.javascript.rhino.Context context0 = new com.google.javascript.rhino.Context();
        com.google.javascript.jscomp.AnonymousFunctionNamingPolicy anonymousFunctionNamingPolicy1 = com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.UNMAPPED;
        context0.removeThreadLocal((java.lang.Object) anonymousFunctionNamingPolicy1);
        context0.addActivationName("hi!");
        org.junit.Assert.assertTrue("'" + anonymousFunctionNamingPolicy1 + "' != '" + com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.UNMAPPED + "'", anonymousFunctionNamingPolicy1.equals(com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.UNMAPPED));
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test021");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeUnusedLocalVars = false;
        boolean boolean3 = compilerOptions0.inlineLocalVariables;
        compilerOptions0.checkSymbols = false;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test022");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray2 = new com.google.javascript.jscomp.JSSourceFile[] {};
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray3 = new com.google.javascript.jscomp.JSSourceFile[] {};
        com.google.javascript.jscomp.CompilerOptions compilerOptions4 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions4.devirtualizePrototypeMethods = false;
        compilerOptions4.groupVariableDeclarations = false;
        boolean boolean9 = compilerOptions4.ideMode;
        compilerOptions4.setProcessObjectPropertyString(true);
        compilerOptions4.setDefineToBooleanLiteral("BITXOR", true);
        compilerOptions4.checkControlStructures = true;
        java.util.Map<java.lang.String, com.google.javascript.rhino.Node> strMap17 = compilerOptions4.getTweakReplacements();
        com.google.javascript.jscomp.Result result18 = compiler1.compile(jSSourceFileArray2, jSSourceFileArray3, compilerOptions4);
        com.google.javascript.jscomp.JSError[] jSErrorArray19 = compiler1.getErrors();
        com.google.javascript.rhino.Node node20 = compiler1.getRoot();
        compiler1.rebuildInputsFromModules();
        org.junit.Assert.assertNotNull(jSSourceFileArray2);
        org.junit.Assert.assertNotNull(jSSourceFileArray3);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(strMap17);
        org.junit.Assert.assertNotNull(result18);
        org.junit.Assert.assertNotNull(jSErrorArray19);
        org.junit.Assert.assertNotNull(node20);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test023");
        java.nio.charset.Charset charset1 = null;
        com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromFile("DiagnosticGroup<undefinedVars>", charset1);
        com.google.javascript.jscomp.JsAst jsAst3 = new com.google.javascript.jscomp.JsAst(sourceFile2);
        jsAst3.clearAst();
        jsAst3.clearAst();
        org.junit.Assert.assertNotNull(sourceFile2);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test024");
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention0 = new com.google.javascript.jscomp.DefaultCodingConvention();
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        node6.removeProp((int) (short) 1);
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        boolean boolean15 = node14.hasMoreThanOneChild();
        node14.setLineno(0);
        boolean boolean18 = node14.hasOneChild();
        com.google.javascript.rhino.jstype.JSType jSType19 = node14.getJSType();
        com.google.javascript.rhino.Node node24 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        node24.removeProp((int) (short) 1);
        com.google.javascript.rhino.Node[] nodeArray27 = new com.google.javascript.rhino.Node[] { node14, node24 };
        com.google.javascript.rhino.Node node30 = new com.google.javascript.rhino.Node((int) (byte) 10, nodeArray27, (int) '4', (int) (byte) -1);
        com.google.javascript.rhino.Node node31 = node6.copyInformationFromForTree(node30);
        boolean boolean32 = node30.isNoSideEffectsCall();
        com.google.javascript.rhino.Node node37 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        com.google.javascript.rhino.JSDocInfo jSDocInfo38 = null;
        node37.setJSDocInfo(jSDocInfo38);
        com.google.javascript.rhino.Node node45 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        com.google.javascript.rhino.JSDocInfo jSDocInfo46 = null;
        node45.setJSDocInfo(jSDocInfo46);
        java.lang.RuntimeException runtimeException49 = com.google.javascript.rhino.ScriptRuntime.undefReadError((java.lang.Object) node45, (java.lang.Object) 22);
        node45.detachChildren();
        com.google.javascript.rhino.Node node51 = new com.google.javascript.rhino.Node((int) (short) 100, node45);
        com.google.javascript.rhino.JSDocInfo jSDocInfo52 = null;
        node51.setJSDocInfo(jSDocInfo52);
        com.google.javascript.rhino.Node node54 = new com.google.javascript.rhino.Node((int) (byte) -1, node30, node37, node51);
        boolean boolean55 = node30.hasOneChild();
        java.lang.String str56 = defaultCodingConvention0.identifyTypeDefAssign(node30);
        java.lang.String str60 = node30.toString(false, false, true);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNull(jSType19);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertNotNull(nodeArray27);
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(node37);
        org.junit.Assert.assertNotNull(node45);
        org.junit.Assert.assertNotNull(runtimeException49);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNull(str56);
        org.junit.Assert.assertTrue("'" + str60 + "' != '" + "BITXOR" + "'", str60.equals("BITXOR"));
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test025");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeDeadCode = false;
        boolean boolean3 = compilerOptions0.checkTypes;
        com.google.javascript.jscomp.CheckLevel checkLevel4 = compilerOptions0.checkGlobalNamesLevel;
        com.google.javascript.jscomp.DiagnosticType diagnosticType5 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        com.google.javascript.jscomp.CheckLevel checkLevel6 = diagnosticType5.level;
        java.lang.Class<?> wildcardClass7 = diagnosticType5.getClass();
        com.google.javascript.jscomp.CheckLevel checkLevel8 = diagnosticType5.defaultLevel;
        compilerOptions0.checkMissingReturn = checkLevel8;
        compilerOptions0.allowLegacyJsMessages = false;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + checkLevel4 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel4.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(diagnosticType5);
        org.junit.Assert.assertTrue("'" + checkLevel6 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel6.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertTrue("'" + checkLevel8 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel8.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test026");
        com.google.javascript.jscomp.SourceFile.Generator generator1 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("null(ERROR)", generator1);
        org.junit.Assert.assertNotNull(jSSourceFile2);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test027");
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.Node.newString(8, "");
        com.google.javascript.rhino.Node node3 = com.google.javascript.jscomp.NodeUtil.newExpr(node2);
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertNotNull(node3);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test028");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeUnusedLocalVars = false;
        compilerOptions0.crossModuleCodeMotion = false;
        compilerOptions0.ambiguateProperties = false;
        compilerOptions0.checkTypedPropertyCalls = true;
        java.lang.String str9 = compilerOptions0.syntheticBlockEndMarker;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy10 = compilerOptions0.variableRenaming;
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy10 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.OFF + "'", variableRenamingPolicy10.equals(com.google.javascript.jscomp.VariableRenamingPolicy.OFF));
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test029");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.devirtualizePrototypeMethods = false;
        compilerOptions0.groupVariableDeclarations = false;
        java.util.Set<java.lang.String> strSet5 = compilerOptions0.stripNamePrefixes;
        java.lang.String str6 = compilerOptions0.syntheticBlockEndMarker;
        boolean boolean7 = compilerOptions0.inlineFunctions;
        com.google.javascript.jscomp.CheckLevel checkLevel8 = compilerOptions0.checkMissingReturn;
        compilerOptions0.generatePseudoNames = true;
        compilerOptions0.inlineGetters = true;
        org.junit.Assert.assertNotNull(strSet5);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + checkLevel8 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel8.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

//    @Test
//    public void test030() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test030");
//        com.google.javascript.rhino.Context context0 = new com.google.javascript.rhino.Context();
//        com.google.javascript.jscomp.AnonymousFunctionNamingPolicy anonymousFunctionNamingPolicy1 = com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.UNMAPPED;
//        context0.removeThreadLocal((java.lang.Object) anonymousFunctionNamingPolicy1);
//        long long3 = com.google.javascript.rhino.ScriptRuntime.lastUint32Result(context0);
//        long long4 = com.google.javascript.rhino.ScriptRuntime.lastUint32Result(context0);
//        com.google.javascript.jscomp.AbstractCompiler abstractCompiler5 = null;
//        com.google.javascript.jscomp.NodeTraversal.Callback callback6 = null;
//        com.google.javascript.jscomp.NodeTraversal nodeTraversal7 = new com.google.javascript.jscomp.NodeTraversal(abstractCompiler5, callback6);
//        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
//        com.google.javascript.rhino.JSDocInfo jSDocInfo14 = null;
//        node13.setJSDocInfo(jSDocInfo14);
//        java.lang.RuntimeException runtimeException17 = com.google.javascript.rhino.ScriptRuntime.undefReadError((java.lang.Object) node13, (java.lang.Object) 22);
//        node13.detachChildren();
//        com.google.javascript.rhino.Node node19 = new com.google.javascript.rhino.Node((int) (short) 100, node13);
//        com.google.javascript.jscomp.CompilerOptions compilerOptions20 = new com.google.javascript.jscomp.CompilerOptions();
//        com.google.javascript.jscomp.CodingConvention codingConvention21 = compilerOptions20.getCodingConvention();
//        compilerOptions20.computeFunctionSideEffects = true;
//        com.google.javascript.jscomp.CheckLevel checkLevel24 = compilerOptions20.checkRequires;
//        com.google.javascript.jscomp.DiagnosticType diagnosticType25 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
//        com.google.javascript.jscomp.DiagnosticType diagnosticType29 = com.google.javascript.jscomp.Compiler.MOTION_ITERATIONS_ERROR;
//        java.lang.String[] strArray36 = new java.lang.String[] { "<unknown=160>", "<unknown=160>", "<unknown=160>", "<unknown=160>", "BITXOR", "DiagnosticGroup<undefinedVars>" };
//        com.google.javascript.jscomp.JSError jSError37 = com.google.javascript.jscomp.JSError.make("BITXOR", 32, (int) (short) 100, diagnosticType29, strArray36);
//        com.google.javascript.jscomp.JSError jSError38 = nodeTraversal7.makeError(node19, checkLevel24, diagnosticType25, strArray36);
//        java.lang.String str39 = jSError38.sourceName;
//        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup40 = com.google.javascript.jscomp.DiagnosticGroups.NON_STANDARD_JSDOC;
//        context0.putThreadLocal((java.lang.Object) jSError38, (java.lang.Object) diagnosticGroup40);
//        int int42 = context0.getOptimizationLevel();
//        com.google.javascript.rhino.Context context43 = new com.google.javascript.rhino.Context();
//        com.google.javascript.jscomp.AnonymousFunctionNamingPolicy anonymousFunctionNamingPolicy44 = com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.UNMAPPED;
//        context43.removeThreadLocal((java.lang.Object) anonymousFunctionNamingPolicy44);
//        boolean boolean46 = context43.isGeneratingDebug();
//        java.util.Locale locale47 = context43.getLocale();
//        java.util.Locale locale48 = context43.getLocale();
//        com.google.javascript.jscomp.CompilerOptions compilerOptions49 = new com.google.javascript.jscomp.CompilerOptions();
//        com.google.javascript.jscomp.CodingConvention codingConvention50 = compilerOptions49.getCodingConvention();
//        boolean boolean51 = compilerOptions49.inlineLocalVariables;
//        com.google.javascript.jscomp.CheckLevel checkLevel52 = compilerOptions49.aggressiveVarCheck;
//        boolean boolean53 = compilerOptions49.convertToDottedProperties;
//        compilerOptions49.tightenTypes = false;
//        compilerOptions49.checkTypes = true;
//        context0.putThreadLocal((java.lang.Object) locale48, (java.lang.Object) compilerOptions49);
//        org.junit.Assert.assertTrue("'" + anonymousFunctionNamingPolicy1 + "' != '" + com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.UNMAPPED + "'", anonymousFunctionNamingPolicy1.equals(com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.UNMAPPED));
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
//        org.junit.Assert.assertNotNull(node13);
//        org.junit.Assert.assertNotNull(runtimeException17);
//        org.junit.Assert.assertNull(codingConvention21);
//        org.junit.Assert.assertTrue("'" + checkLevel24 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel24.equals(com.google.javascript.jscomp.CheckLevel.OFF));
//        org.junit.Assert.assertNotNull(diagnosticType25);
//        org.junit.Assert.assertNotNull(diagnosticType29);
//        org.junit.Assert.assertNotNull(strArray36);
//        org.junit.Assert.assertNotNull(jSError37);
//        org.junit.Assert.assertNotNull(jSError38);
//        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "" + "'", str39.equals(""));
//        org.junit.Assert.assertNotNull(diagnosticGroup40);
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
//        org.junit.Assert.assertTrue("'" + anonymousFunctionNamingPolicy44 + "' != '" + com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.UNMAPPED + "'", anonymousFunctionNamingPolicy44.equals(com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.UNMAPPED));
//        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
//        org.junit.Assert.assertNotNull(locale47);
//        org.junit.Assert.assertNotNull(locale48);
//        org.junit.Assert.assertNull(codingConvention50);
//        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
//        org.junit.Assert.assertTrue("'" + checkLevel52 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel52.equals(com.google.javascript.jscomp.CheckLevel.OFF));
//        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
//    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test031");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.devirtualizePrototypeMethods = false;
        compilerOptions0.groupVariableDeclarations = false;
        boolean boolean5 = compilerOptions0.ideMode;
        compilerOptions0.setProcessObjectPropertyString(true);
        compilerOptions0.setProcessObjectPropertyString(true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test032");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        boolean boolean6 = node5.hasMoreThanOneChild();
        boolean boolean7 = node5.hasOneChild();
        try {
            boolean boolean8 = closureCodingConvention0.isPropertyTestFunction(node5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test033");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile1 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.CompilerInput compilerInput2 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile1);
        com.google.javascript.jscomp.JSModule jSModule3 = null;
        compilerInput2.setModule(jSModule3);
        com.google.javascript.jscomp.CompilerInput compilerInput6 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput2, false);
        com.google.javascript.jscomp.Region region8 = compilerInput6.getRegion(32);
        java.lang.String str9 = compilerInput6.getName();
        java.io.PrintStream printStream10 = null;
        com.google.javascript.jscomp.Compiler compiler11 = new com.google.javascript.jscomp.Compiler(printStream10);
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray12 = new com.google.javascript.jscomp.JSSourceFile[] {};
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray13 = new com.google.javascript.jscomp.JSSourceFile[] {};
        com.google.javascript.jscomp.CompilerOptions compilerOptions14 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions14.devirtualizePrototypeMethods = false;
        compilerOptions14.groupVariableDeclarations = false;
        boolean boolean19 = compilerOptions14.ideMode;
        compilerOptions14.setProcessObjectPropertyString(true);
        compilerOptions14.setDefineToBooleanLiteral("BITXOR", true);
        compilerOptions14.checkControlStructures = true;
        java.util.Map<java.lang.String, com.google.javascript.rhino.Node> strMap27 = compilerOptions14.getTweakReplacements();
        com.google.javascript.jscomp.Result result28 = compiler11.compile(jSSourceFileArray12, jSSourceFileArray13, compilerOptions14);
        com.google.javascript.jscomp.JSError[] jSErrorArray29 = compiler11.getErrors();
        com.google.javascript.rhino.Node node30 = compiler11.getRoot();
        compilerInput6.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler11);
        com.google.javascript.jscomp.DiagnosticType diagnosticType35 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        com.google.javascript.jscomp.CheckLevel checkLevel36 = diagnosticType35.level;
        com.google.javascript.jscomp.CheckLevel checkLevel37 = com.google.javascript.jscomp.CheckLevel.OFF;
        diagnosticType35.level = checkLevel37;
        com.google.javascript.jscomp.AbstractCompiler abstractCompiler39 = null;
        com.google.javascript.jscomp.NodeTraversal.Callback callback40 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal41 = new com.google.javascript.jscomp.NodeTraversal(abstractCompiler39, callback40);
        com.google.javascript.rhino.Node node47 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        com.google.javascript.rhino.JSDocInfo jSDocInfo48 = null;
        node47.setJSDocInfo(jSDocInfo48);
        java.lang.RuntimeException runtimeException51 = com.google.javascript.rhino.ScriptRuntime.undefReadError((java.lang.Object) node47, (java.lang.Object) 22);
        node47.detachChildren();
        com.google.javascript.rhino.Node node53 = new com.google.javascript.rhino.Node((int) (short) 100, node47);
        com.google.javascript.jscomp.CompilerOptions compilerOptions54 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CodingConvention codingConvention55 = compilerOptions54.getCodingConvention();
        compilerOptions54.computeFunctionSideEffects = true;
        com.google.javascript.jscomp.CheckLevel checkLevel58 = compilerOptions54.checkRequires;
        com.google.javascript.jscomp.DiagnosticType diagnosticType59 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        com.google.javascript.jscomp.DiagnosticType diagnosticType63 = com.google.javascript.jscomp.Compiler.MOTION_ITERATIONS_ERROR;
        java.lang.String[] strArray70 = new java.lang.String[] { "<unknown=160>", "<unknown=160>", "<unknown=160>", "<unknown=160>", "BITXOR", "DiagnosticGroup<undefinedVars>" };
        com.google.javascript.jscomp.JSError jSError71 = com.google.javascript.jscomp.JSError.make("BITXOR", 32, (int) (short) 100, diagnosticType63, strArray70);
        com.google.javascript.jscomp.JSError jSError72 = nodeTraversal41.makeError(node53, checkLevel58, diagnosticType59, strArray70);
        com.google.javascript.jscomp.JSError jSError73 = com.google.javascript.jscomp.JSError.make("0", (int) (byte) -1, 20, diagnosticType35, strArray70);
        com.google.javascript.jscomp.CheckLevel checkLevel74 = compiler11.getErrorLevel(jSError73);
        int int75 = compiler11.getWarningCount();
        com.google.javascript.jscomp.SourceExcerptProvider.SourceExcerpt sourceExcerpt76 = null;
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter77 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler11, sourceExcerpt76);
        java.lang.String str78 = compiler11.getAstDotGraph();
        compiler11.reportCodeChange();
        org.junit.Assert.assertNotNull(jSSourceFile1);
        org.junit.Assert.assertNull(region8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertNotNull(jSSourceFileArray12);
        org.junit.Assert.assertNotNull(jSSourceFileArray13);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(strMap27);
        org.junit.Assert.assertNotNull(result28);
        org.junit.Assert.assertNotNull(jSErrorArray29);
        org.junit.Assert.assertNotNull(node30);
        org.junit.Assert.assertNotNull(diagnosticType35);
        org.junit.Assert.assertTrue("'" + checkLevel36 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel36.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + checkLevel37 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel37.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(node47);
        org.junit.Assert.assertNotNull(runtimeException51);
        org.junit.Assert.assertNull(codingConvention55);
        org.junit.Assert.assertTrue("'" + checkLevel58 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel58.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(diagnosticType59);
        org.junit.Assert.assertNotNull(diagnosticType63);
        org.junit.Assert.assertNotNull(strArray70);
        org.junit.Assert.assertNotNull(jSError71);
        org.junit.Assert.assertNotNull(jSError72);
        org.junit.Assert.assertNotNull(jSError73);
        org.junit.Assert.assertNull(checkLevel74);
        org.junit.Assert.assertTrue("'" + int75 + "' != '" + 1 + "'", int75 == 1);
        org.junit.Assert.assertTrue("'" + str78 + "' != '" + "digraph AST {\n  node [color=lightblue2, style=filled];\n  node0 [label=\"BLOCK\"];\n  node1 [label=\"SCRIPT\"];\n  node0 -> node1 [weight=1];\n  node1 -> RETURN [label=\"UNCOND\", fontcolor=\"red\", weight=0.01, color=\"red\"];\n  node0 -> RETURN [label=\"SYN_BLOCK\", fontcolor=\"red\", weight=0.01, color=\"red\"];\n  node0 -> node1 [label=\"UNCOND\", fontcolor=\"red\", weight=0.01, color=\"red\"];\n}\n" + "'", str78.equals("digraph AST {\n  node [color=lightblue2, style=filled];\n  node0 [label=\"BLOCK\"];\n  node1 [label=\"SCRIPT\"];\n  node0 -> node1 [weight=1];\n  node1 -> RETURN [label=\"UNCOND\", fontcolor=\"red\", weight=0.01, color=\"red\"];\n  node0 -> RETURN [label=\"SYN_BLOCK\", fontcolor=\"red\", weight=0.01, color=\"red\"];\n  node0 -> node1 [label=\"UNCOND\", fontcolor=\"red\", weight=0.01, color=\"red\"];\n}\n"));
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test034");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.devirtualizePrototypeMethods = false;
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy3 = com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC;
        compilerOptions0.propertyRenaming = propertyRenamingPolicy3;
        boolean boolean5 = compilerOptions0.recordFunctionInformation;
        compilerOptions0.optimizeArgumentsArray = false;
        com.google.javascript.jscomp.DiagnosticType diagnosticType8 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        com.google.javascript.jscomp.CheckLevel checkLevel9 = diagnosticType8.defaultLevel;
        compilerOptions0.checkMethods = checkLevel9;
        com.google.javascript.jscomp.CheckLevel checkLevel11 = compilerOptions0.checkRequires;
        compilerOptions0.setRewriteNewDateGoogNow(true);
        boolean boolean14 = compilerOptions0.checkUnusedPropertiesEarly;
        java.util.Set<java.lang.String> strSet15 = compilerOptions0.stripTypes;
        com.google.javascript.jscomp.MessageBundle messageBundle16 = compilerOptions0.messageBundle;
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy3 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC + "'", propertyRenamingPolicy3.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(diagnosticType8);
        org.junit.Assert.assertTrue("'" + checkLevel9 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel9.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + checkLevel11 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel11.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(strSet15);
        org.junit.Assert.assertNull(messageBundle16);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test035");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", ". hi! at BITXOR line 38 : 130");
        org.junit.Assert.assertNotNull(jSSourceFile2);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test036");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CodingConvention codingConvention1 = compilerOptions0.getCodingConvention();
        com.google.javascript.jscomp.CompilerOptions.AliasTransformationHandler aliasTransformationHandler2 = compilerOptions0.getAliasTransformationHandler();
        compilerOptions0.inputDelimiter = "<unknown=160>";
        com.google.javascript.jscomp.CheckLevel checkLevel5 = compilerOptions0.checkMethods;
        org.junit.Assert.assertNull(codingConvention1);
        org.junit.Assert.assertNotNull(aliasTransformationHandler2);
        org.junit.Assert.assertTrue("'" + checkLevel5 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel5.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test037");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        com.google.javascript.rhino.JSDocInfo jSDocInfo5 = null;
        node4.setJSDocInfo(jSDocInfo5);
        java.lang.RuntimeException runtimeException8 = com.google.javascript.rhino.ScriptRuntime.undefReadError((java.lang.Object) node4, (java.lang.Object) 22);
        node4.detachChildren();
        java.lang.String[] strArray15 = new java.lang.String[] { "error reporter", "hi!", "BITXOR", "error reporter", "BITXOR" };
        java.util.LinkedHashSet<java.lang.String> strSet16 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean17 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet16, strArray15);
        node4.setDirectives((java.util.Set<java.lang.String>) strSet16);
        com.google.javascript.jscomp.AbstractCompiler abstractCompiler19 = null;
        com.google.javascript.jscomp.NodeTraversal.Callback callback20 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal21 = new com.google.javascript.jscomp.NodeTraversal(abstractCompiler19, callback20);
        com.google.javascript.rhino.Node node27 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        com.google.javascript.rhino.JSDocInfo jSDocInfo28 = null;
        node27.setJSDocInfo(jSDocInfo28);
        java.lang.RuntimeException runtimeException31 = com.google.javascript.rhino.ScriptRuntime.undefReadError((java.lang.Object) node27, (java.lang.Object) 22);
        node27.detachChildren();
        com.google.javascript.rhino.Node node33 = new com.google.javascript.rhino.Node((int) (short) 100, node27);
        com.google.javascript.jscomp.CompilerOptions compilerOptions34 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CodingConvention codingConvention35 = compilerOptions34.getCodingConvention();
        compilerOptions34.computeFunctionSideEffects = true;
        com.google.javascript.jscomp.CheckLevel checkLevel38 = compilerOptions34.checkRequires;
        com.google.javascript.jscomp.DiagnosticType diagnosticType39 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        com.google.javascript.jscomp.DiagnosticType diagnosticType43 = com.google.javascript.jscomp.Compiler.MOTION_ITERATIONS_ERROR;
        java.lang.String[] strArray50 = new java.lang.String[] { "<unknown=160>", "<unknown=160>", "<unknown=160>", "<unknown=160>", "BITXOR", "DiagnosticGroup<undefinedVars>" };
        com.google.javascript.jscomp.JSError jSError51 = com.google.javascript.jscomp.JSError.make("BITXOR", 32, (int) (short) 100, diagnosticType43, strArray50);
        com.google.javascript.jscomp.JSError jSError52 = nodeTraversal21.makeError(node33, checkLevel38, diagnosticType39, strArray50);
        com.google.javascript.rhino.Node node53 = node4.copyInformationFromForTree(node33);
        com.google.javascript.rhino.jstype.JSType jSType54 = null;
        node4.setJSType(jSType54);
        boolean boolean56 = node4.isLocalResultCall();
        int int57 = node4.getType();
        com.google.javascript.rhino.Node node58 = node4.getLastSibling();
        boolean boolean59 = node4.hasMoreThanOneChild();
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(runtimeException8);
        org.junit.Assert.assertNotNull(strArray15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(node27);
        org.junit.Assert.assertNotNull(runtimeException31);
        org.junit.Assert.assertNull(codingConvention35);
        org.junit.Assert.assertTrue("'" + checkLevel38 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel38.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(diagnosticType39);
        org.junit.Assert.assertNotNull(diagnosticType43);
        org.junit.Assert.assertNotNull(strArray50);
        org.junit.Assert.assertNotNull(jSError51);
        org.junit.Assert.assertNotNull(jSError52);
        org.junit.Assert.assertNotNull(node53);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 1 + "'", int57 == 1);
        org.junit.Assert.assertNotNull(node58);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test038");
        com.google.javascript.rhino.Context context0 = new com.google.javascript.rhino.Context();
        com.google.javascript.jscomp.AnonymousFunctionNamingPolicy anonymousFunctionNamingPolicy1 = com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.UNMAPPED;
        context0.removeThreadLocal((java.lang.Object) anonymousFunctionNamingPolicy1);
        long long3 = com.google.javascript.rhino.ScriptRuntime.lastUint32Result(context0);
        int int4 = context0.getLanguageVersion();
        boolean boolean5 = context0.isGeneratingDebug();
        org.junit.Assert.assertTrue("'" + anonymousFunctionNamingPolicy1 + "' != '" + com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.UNMAPPED + "'", anonymousFunctionNamingPolicy1.equals(com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.UNMAPPED));
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test039");
        com.google.javascript.jscomp.AbstractCompiler abstractCompiler0 = null;
        com.google.javascript.jscomp.NodeTraversal.Callback callback1 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal2 = new com.google.javascript.jscomp.NodeTraversal(abstractCompiler0, callback1);
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        com.google.javascript.rhino.JSDocInfo jSDocInfo9 = null;
        node8.setJSDocInfo(jSDocInfo9);
        java.lang.RuntimeException runtimeException12 = com.google.javascript.rhino.ScriptRuntime.undefReadError((java.lang.Object) node8, (java.lang.Object) 22);
        node8.detachChildren();
        com.google.javascript.rhino.Node node14 = new com.google.javascript.rhino.Node((int) (short) 100, node8);
        com.google.javascript.jscomp.CompilerOptions compilerOptions15 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CodingConvention codingConvention16 = compilerOptions15.getCodingConvention();
        compilerOptions15.computeFunctionSideEffects = true;
        com.google.javascript.jscomp.CheckLevel checkLevel19 = compilerOptions15.checkRequires;
        com.google.javascript.jscomp.DiagnosticType diagnosticType20 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        com.google.javascript.jscomp.DiagnosticType diagnosticType24 = com.google.javascript.jscomp.Compiler.MOTION_ITERATIONS_ERROR;
        java.lang.String[] strArray31 = new java.lang.String[] { "<unknown=160>", "<unknown=160>", "<unknown=160>", "<unknown=160>", "BITXOR", "DiagnosticGroup<undefinedVars>" };
        com.google.javascript.jscomp.JSError jSError32 = com.google.javascript.jscomp.JSError.make("BITXOR", 32, (int) (short) 100, diagnosticType24, strArray31);
        com.google.javascript.jscomp.JSError jSError33 = nodeTraversal2.makeError(node14, checkLevel19, diagnosticType20, strArray31);
        int int34 = jSError33.lineNumber;
        com.google.javascript.rhino.Node node40 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        boolean boolean41 = node40.hasMoreThanOneChild();
        node40.setLineno(0);
        boolean boolean44 = node40.hasOneChild();
        com.google.javascript.rhino.jstype.JSType jSType45 = node40.getJSType();
        com.google.javascript.rhino.Node node50 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        node50.removeProp((int) (short) 1);
        com.google.javascript.rhino.Node[] nodeArray53 = new com.google.javascript.rhino.Node[] { node40, node50 };
        com.google.javascript.rhino.Node node56 = new com.google.javascript.rhino.Node((int) (byte) 10, nodeArray53, (int) '4', (int) (byte) -1);
        boolean boolean57 = jSError33.equals((java.lang.Object) (byte) 10);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNotNull(runtimeException12);
        org.junit.Assert.assertNull(codingConvention16);
        org.junit.Assert.assertTrue("'" + checkLevel19 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel19.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(diagnosticType20);
        org.junit.Assert.assertNotNull(diagnosticType24);
        org.junit.Assert.assertNotNull(strArray31);
        org.junit.Assert.assertNotNull(jSError32);
        org.junit.Assert.assertNotNull(jSError33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + (-1) + "'", int34 == (-1));
        org.junit.Assert.assertNotNull(node40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNull(jSType45);
        org.junit.Assert.assertNotNull(node50);
        org.junit.Assert.assertNotNull(nodeArray53);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test040");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.jstype.FunctionType functionType1 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType2 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType3 = null;
        closureCodingConvention0.applySubclassRelationship(functionType1, functionType2, subclassType3);
        com.google.javascript.rhino.jstype.FunctionType functionType5 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType6 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType7 = null;
        closureCodingConvention0.applySubclassRelationship(functionType5, functionType6, subclassType7);
        java.lang.String str9 = closureCodingConvention0.getGlobalObject();
        com.google.javascript.rhino.jstype.ObjectType objectType10 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType11 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType12 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType13 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType14 = null;
        closureCodingConvention0.applyDelegateRelationship(objectType10, objectType11, objectType12, functionType13, functionType14);
        java.lang.String str16 = closureCodingConvention0.getExportPropertyFunction();
        boolean boolean18 = closureCodingConvention0.isValidEnumKey("Named type with empty name component");
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "goog.global" + "'", str9.equals("goog.global"));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "goog.exportProperty" + "'", str16.equals("goog.exportProperty"));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test041");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.devirtualizePrototypeMethods = false;
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy3 = com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC;
        compilerOptions0.propertyRenaming = propertyRenamingPolicy3;
        java.lang.String str5 = compilerOptions0.unaliasableGlobals;
        compilerOptions0.setOutputCharset("language version");
        com.google.javascript.jscomp.SourceMap.DetailLevel detailLevel8 = com.google.javascript.jscomp.SourceMap.DetailLevel.SYMBOLS;
        compilerOptions0.sourceMapDetailLevel = detailLevel8;
        compilerOptions0.removeEmptyFunctions = false;
        boolean boolean12 = compilerOptions0.printInputDelimiter;
        com.google.javascript.jscomp.CompilerOptions compilerOptions13 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions13.devirtualizePrototypeMethods = false;
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy16 = com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC;
        compilerOptions13.propertyRenaming = propertyRenamingPolicy16;
        boolean boolean18 = compilerOptions13.recordFunctionInformation;
        compilerOptions13.enableExternExports(false);
        byte[] byteArray24 = new byte[] { (byte) -1, (byte) 1, (byte) 10 };
        compilerOptions13.inputVariableMapSerialized = byteArray24;
        compilerOptions13.removeTryCatchFinally = true;
        com.google.javascript.jscomp.CompilerOptions compilerOptions28 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions28.devirtualizePrototypeMethods = false;
        compilerOptions28.groupVariableDeclarations = false;
        boolean boolean33 = compilerOptions28.crossModuleCodeMotion;
        compilerOptions28.setManageClosureDependencies(true);
        compilerOptions28.inlineVariables = false;
        com.google.javascript.jscomp.CompilerOptions compilerOptions38 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CodingConvention codingConvention39 = compilerOptions38.getCodingConvention();
        compilerOptions38.computeFunctionSideEffects = true;
        com.google.javascript.jscomp.CheckLevel checkLevel42 = compilerOptions38.checkRequires;
        compilerOptions28.checkRequires = checkLevel42;
        compilerOptions13.checkGlobalNamesLevel = checkLevel42;
        com.google.javascript.jscomp.CompilerOptions compilerOptions45 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions45.removeUnusedLocalVars = false;
        compilerOptions45.crossModuleCodeMotion = false;
        compilerOptions45.specializeInitialModule = false;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy52 = compilerOptions45.variableRenaming;
        com.google.javascript.jscomp.CompilerOptions compilerOptions53 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions53.removeUnusedLocalVars = false;
        compilerOptions53.crossModuleCodeMotion = false;
        compilerOptions53.ambiguateProperties = false;
        compilerOptions53.computeFunctionSideEffects = false;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy62 = com.google.javascript.jscomp.VariableRenamingPolicy.UNSPECIFIED;
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy63 = com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC;
        compilerOptions53.setRenamingPolicy(variableRenamingPolicy62, propertyRenamingPolicy63);
        compilerOptions13.setRenamingPolicy(variableRenamingPolicy52, propertyRenamingPolicy63);
        compilerOptions0.variableRenaming = variableRenamingPolicy52;
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy3 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC + "'", propertyRenamingPolicy3.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC));
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertNotNull(detailLevel8);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy16 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC + "'", propertyRenamingPolicy16.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(byteArray24);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNull(codingConvention39);
        org.junit.Assert.assertTrue("'" + checkLevel42 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel42.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy52 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.OFF + "'", variableRenamingPolicy52.equals(com.google.javascript.jscomp.VariableRenamingPolicy.OFF));
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy62 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.UNSPECIFIED + "'", variableRenamingPolicy62.equals(com.google.javascript.jscomp.VariableRenamingPolicy.UNSPECIFIED));
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy63 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC + "'", propertyRenamingPolicy63.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC));
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test042");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.devirtualizePrototypeMethods = false;
        compilerOptions0.groupVariableDeclarations = false;
        boolean boolean5 = compilerOptions0.ideMode;
        compilerOptions0.setProcessObjectPropertyString(true);
        compilerOptions0.setDefineToBooleanLiteral("BITXOR", true);
        compilerOptions0.smartNameRemoval = true;
        compilerOptions0.markNoSideEffectCalls = true;
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test043");
        com.google.javascript.jscomp.AbstractCompiler abstractCompiler0 = null;
        com.google.javascript.jscomp.NodeTraversal.Callback callback1 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal2 = new com.google.javascript.jscomp.NodeTraversal(abstractCompiler0, callback1);
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        com.google.javascript.rhino.JSDocInfo jSDocInfo9 = null;
        node8.setJSDocInfo(jSDocInfo9);
        java.lang.RuntimeException runtimeException12 = com.google.javascript.rhino.ScriptRuntime.undefReadError((java.lang.Object) node8, (java.lang.Object) 22);
        node8.detachChildren();
        com.google.javascript.rhino.Node node14 = new com.google.javascript.rhino.Node((int) (short) 100, node8);
        com.google.javascript.jscomp.CompilerOptions compilerOptions15 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CodingConvention codingConvention16 = compilerOptions15.getCodingConvention();
        compilerOptions15.computeFunctionSideEffects = true;
        com.google.javascript.jscomp.CheckLevel checkLevel19 = compilerOptions15.checkRequires;
        com.google.javascript.jscomp.DiagnosticType diagnosticType20 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        com.google.javascript.jscomp.DiagnosticType diagnosticType24 = com.google.javascript.jscomp.Compiler.MOTION_ITERATIONS_ERROR;
        java.lang.String[] strArray31 = new java.lang.String[] { "<unknown=160>", "<unknown=160>", "<unknown=160>", "<unknown=160>", "BITXOR", "DiagnosticGroup<undefinedVars>" };
        com.google.javascript.jscomp.JSError jSError32 = com.google.javascript.jscomp.JSError.make("BITXOR", 32, (int) (short) 100, diagnosticType24, strArray31);
        com.google.javascript.jscomp.JSError jSError33 = nodeTraversal2.makeError(node14, checkLevel19, diagnosticType20, strArray31);
        java.lang.String str34 = jSError33.sourceName;
        java.lang.Class<?> wildcardClass35 = jSError33.getClass();
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNotNull(runtimeException12);
        org.junit.Assert.assertNull(codingConvention16);
        org.junit.Assert.assertTrue("'" + checkLevel19 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel19.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(diagnosticType20);
        org.junit.Assert.assertNotNull(diagnosticType24);
        org.junit.Assert.assertNotNull(strArray31);
        org.junit.Assert.assertNotNull(jSError32);
        org.junit.Assert.assertNotNull(jSError33);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "" + "'", str34.equals(""));
        org.junit.Assert.assertNotNull(wildcardClass35);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test044");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeUnusedLocalVars = false;
        compilerOptions0.jsOutputFile = "";
        com.google.javascript.jscomp.CompilerOptions.TweakProcessing tweakProcessing5 = com.google.javascript.jscomp.CompilerOptions.TweakProcessing.STRIP;
        compilerOptions0.setTweakProcessing(tweakProcessing5);
        compilerOptions0.optimizeCalls = false;
        compilerOptions0.generatePseudoNames = false;
        compilerOptions0.markNoSideEffectCalls = true;
        boolean boolean13 = compilerOptions0.removeTryCatchFinally;
        org.junit.Assert.assertTrue("'" + tweakProcessing5 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TweakProcessing.STRIP + "'", tweakProcessing5.equals(com.google.javascript.jscomp.CompilerOptions.TweakProcessing.STRIP));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test045");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString(1, "language version", (int) (short) 10, (int) (byte) 100);
        boolean boolean5 = node4.hasSideEffects();
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test046");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.devirtualizePrototypeMethods = false;
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy3 = com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC;
        compilerOptions0.propertyRenaming = propertyRenamingPolicy3;
        java.lang.String str5 = compilerOptions0.unaliasableGlobals;
        compilerOptions0.setOutputCharset("language version");
        com.google.javascript.jscomp.SourceMap.DetailLevel detailLevel8 = com.google.javascript.jscomp.SourceMap.DetailLevel.SYMBOLS;
        compilerOptions0.sourceMapDetailLevel = detailLevel8;
        boolean boolean10 = compilerOptions0.extractPrototypeMemberDeclarations;
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy3 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC + "'", propertyRenamingPolicy3.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC));
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertNotNull(detailLevel8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test047");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile1 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        java.lang.String str2 = jSSourceFile1.getOriginalPath();
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile1);
        com.google.javascript.jscomp.CompilerInput compilerInput5 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile1, false);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile7 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.CompilerInput compilerInput8 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile7);
        com.google.javascript.jscomp.JSModule jSModule9 = null;
        compilerInput8.setModule(jSModule9);
        com.google.javascript.jscomp.CompilerInput compilerInput12 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput8, false);
        com.google.javascript.jscomp.Region region14 = compilerInput12.getRegion(32);
        java.lang.String str15 = compilerInput12.getName();
        java.io.PrintStream printStream16 = null;
        com.google.javascript.jscomp.Compiler compiler17 = new com.google.javascript.jscomp.Compiler(printStream16);
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray18 = new com.google.javascript.jscomp.JSSourceFile[] {};
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray19 = new com.google.javascript.jscomp.JSSourceFile[] {};
        com.google.javascript.jscomp.CompilerOptions compilerOptions20 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions20.devirtualizePrototypeMethods = false;
        compilerOptions20.groupVariableDeclarations = false;
        boolean boolean25 = compilerOptions20.ideMode;
        compilerOptions20.setProcessObjectPropertyString(true);
        compilerOptions20.setDefineToBooleanLiteral("BITXOR", true);
        compilerOptions20.checkControlStructures = true;
        java.util.Map<java.lang.String, com.google.javascript.rhino.Node> strMap33 = compilerOptions20.getTweakReplacements();
        com.google.javascript.jscomp.Result result34 = compiler17.compile(jSSourceFileArray18, jSSourceFileArray19, compilerOptions20);
        com.google.javascript.jscomp.JSError[] jSErrorArray35 = compiler17.getErrors();
        com.google.javascript.rhino.Node node36 = compiler17.getRoot();
        compilerInput12.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler17);
        com.google.javascript.jscomp.DiagnosticType diagnosticType41 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        com.google.javascript.jscomp.CheckLevel checkLevel42 = diagnosticType41.level;
        com.google.javascript.jscomp.CheckLevel checkLevel43 = com.google.javascript.jscomp.CheckLevel.OFF;
        diagnosticType41.level = checkLevel43;
        com.google.javascript.jscomp.AbstractCompiler abstractCompiler45 = null;
        com.google.javascript.jscomp.NodeTraversal.Callback callback46 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal47 = new com.google.javascript.jscomp.NodeTraversal(abstractCompiler45, callback46);
        com.google.javascript.rhino.Node node53 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        com.google.javascript.rhino.JSDocInfo jSDocInfo54 = null;
        node53.setJSDocInfo(jSDocInfo54);
        java.lang.RuntimeException runtimeException57 = com.google.javascript.rhino.ScriptRuntime.undefReadError((java.lang.Object) node53, (java.lang.Object) 22);
        node53.detachChildren();
        com.google.javascript.rhino.Node node59 = new com.google.javascript.rhino.Node((int) (short) 100, node53);
        com.google.javascript.jscomp.CompilerOptions compilerOptions60 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CodingConvention codingConvention61 = compilerOptions60.getCodingConvention();
        compilerOptions60.computeFunctionSideEffects = true;
        com.google.javascript.jscomp.CheckLevel checkLevel64 = compilerOptions60.checkRequires;
        com.google.javascript.jscomp.DiagnosticType diagnosticType65 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        com.google.javascript.jscomp.DiagnosticType diagnosticType69 = com.google.javascript.jscomp.Compiler.MOTION_ITERATIONS_ERROR;
        java.lang.String[] strArray76 = new java.lang.String[] { "<unknown=160>", "<unknown=160>", "<unknown=160>", "<unknown=160>", "BITXOR", "DiagnosticGroup<undefinedVars>" };
        com.google.javascript.jscomp.JSError jSError77 = com.google.javascript.jscomp.JSError.make("BITXOR", 32, (int) (short) 100, diagnosticType69, strArray76);
        com.google.javascript.jscomp.JSError jSError78 = nodeTraversal47.makeError(node59, checkLevel64, diagnosticType65, strArray76);
        com.google.javascript.jscomp.JSError jSError79 = com.google.javascript.jscomp.JSError.make("0", (int) (byte) -1, 20, diagnosticType41, strArray76);
        com.google.javascript.jscomp.CheckLevel checkLevel80 = compiler17.getErrorLevel(jSError79);
        boolean boolean81 = compiler17.acceptEcmaScript5();
        com.google.javascript.jscomp.ErrorManager errorManager82 = compiler17.getErrorManager();
        compilerInput5.setErrorManager(errorManager82);
        org.junit.Assert.assertNotNull(jSSourceFile1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertNotNull(jSSourceFile7);
        org.junit.Assert.assertNull(region14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
        org.junit.Assert.assertNotNull(jSSourceFileArray18);
        org.junit.Assert.assertNotNull(jSSourceFileArray19);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(strMap33);
        org.junit.Assert.assertNotNull(result34);
        org.junit.Assert.assertNotNull(jSErrorArray35);
        org.junit.Assert.assertNotNull(node36);
        org.junit.Assert.assertNotNull(diagnosticType41);
        org.junit.Assert.assertTrue("'" + checkLevel42 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel42.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + checkLevel43 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel43.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(node53);
        org.junit.Assert.assertNotNull(runtimeException57);
        org.junit.Assert.assertNull(codingConvention61);
        org.junit.Assert.assertTrue("'" + checkLevel64 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel64.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(diagnosticType65);
        org.junit.Assert.assertNotNull(diagnosticType69);
        org.junit.Assert.assertNotNull(strArray76);
        org.junit.Assert.assertNotNull(jSError77);
        org.junit.Assert.assertNotNull(jSError78);
        org.junit.Assert.assertNotNull(jSError79);
        org.junit.Assert.assertNull(checkLevel80);
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + false + "'", boolean81 == false);
        org.junit.Assert.assertNotNull(errorManager82);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test048");
        java.util.logging.Logger logger0 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager1 = new com.google.javascript.jscomp.LoggerErrorManager(logger0);
        com.google.javascript.jscomp.JSError[] jSErrorArray2 = loggerErrorManager1.getWarnings();
        com.google.javascript.jscomp.Compiler compiler3 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager1);
        compiler3.disableThreads();
        com.google.javascript.jscomp.DiagnosticType diagnosticType8 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        com.google.javascript.jscomp.CheckLevel checkLevel9 = diagnosticType8.level;
        com.google.javascript.jscomp.DiagnosticType diagnosticType10 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        com.google.javascript.jscomp.CheckLevel checkLevel11 = diagnosticType10.defaultLevel;
        java.text.MessageFormat messageFormat12 = diagnosticType10.format;
        com.google.javascript.jscomp.DiagnosticType diagnosticType18 = com.google.javascript.jscomp.DiagnosticType.error("", "hi!");
        com.google.javascript.jscomp.DiagnosticType diagnosticType22 = com.google.javascript.jscomp.Compiler.MOTION_ITERATIONS_ERROR;
        java.lang.String[] strArray29 = new java.lang.String[] { "<unknown=160>", "<unknown=160>", "<unknown=160>", "<unknown=160>", "BITXOR", "DiagnosticGroup<undefinedVars>" };
        com.google.javascript.jscomp.JSError jSError30 = com.google.javascript.jscomp.JSError.make("BITXOR", 32, (int) (short) 100, diagnosticType22, strArray29);
        com.google.javascript.jscomp.JSError jSError31 = com.google.javascript.jscomp.JSError.make("BITXOR", 38, 130, diagnosticType18, strArray29);
        com.google.javascript.jscomp.JSError jSError32 = com.google.javascript.jscomp.JSError.make("typeof", 13, 160, checkLevel9, diagnosticType10, strArray29);
        try {
            com.google.javascript.jscomp.CheckLevel checkLevel33 = compiler3.getErrorLevel(jSError32);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jSErrorArray2);
        org.junit.Assert.assertNotNull(diagnosticType8);
        org.junit.Assert.assertTrue("'" + checkLevel9 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel9.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(diagnosticType10);
        org.junit.Assert.assertTrue("'" + checkLevel11 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel11.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(messageFormat12);
        org.junit.Assert.assertNotNull(diagnosticType18);
        org.junit.Assert.assertNotNull(diagnosticType22);
        org.junit.Assert.assertNotNull(strArray29);
        org.junit.Assert.assertNotNull(jSError30);
        org.junit.Assert.assertNotNull(jSError31);
        org.junit.Assert.assertNotNull(jSError32);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test049");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray2 = new com.google.javascript.jscomp.JSSourceFile[] {};
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray3 = new com.google.javascript.jscomp.JSSourceFile[] {};
        com.google.javascript.jscomp.CompilerOptions compilerOptions4 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions4.devirtualizePrototypeMethods = false;
        compilerOptions4.groupVariableDeclarations = false;
        boolean boolean9 = compilerOptions4.ideMode;
        compilerOptions4.setProcessObjectPropertyString(true);
        compilerOptions4.setDefineToBooleanLiteral("BITXOR", true);
        compilerOptions4.checkControlStructures = true;
        java.util.Map<java.lang.String, com.google.javascript.rhino.Node> strMap17 = compilerOptions4.getTweakReplacements();
        com.google.javascript.jscomp.Result result18 = compiler1.compile(jSSourceFileArray2, jSSourceFileArray3, compilerOptions4);
        com.google.javascript.jscomp.SourceExcerptProvider.SourceExcerpt sourceExcerpt19 = null;
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter20 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler1, sourceExcerpt19);
        com.google.javascript.jscomp.Compiler.IntermediateState intermediateState21 = compiler1.getState();
        com.google.javascript.jscomp.PerformanceTracker performanceTracker22 = compiler1.tracker;
        com.google.javascript.jscomp.Scope scope23 = compiler1.getTopScope();
        org.junit.Assert.assertNotNull(jSSourceFileArray2);
        org.junit.Assert.assertNotNull(jSSourceFileArray3);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(strMap17);
        org.junit.Assert.assertNotNull(result18);
        org.junit.Assert.assertNotNull(intermediateState21);
        org.junit.Assert.assertNull(performanceTracker22);
        org.junit.Assert.assertNull(scope23);
    }

//    @Test
//    public void test050() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test050");
//        try {
//            com.google.javascript.rhino.EvaluatorException evaluatorException5 = com.google.javascript.rhino.Context.reportRuntimeError(". hi! at BITXOR line 38 : 130", "DiagnosticGroup<undefinedVars>: <unknown=160>", 46, "goog.exportProperty", 39);
//            org.junit.Assert.fail("Expected exception of type com.google.javascript.rhino.EvaluatorException; message: . hi! at BITXOR line 38 : 130 (DiagnosticGroup<undefinedVars>: <unknown=160>#46)");
//        } catch (com.google.javascript.rhino.EvaluatorException e) {
//        }
//    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test051");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newNumber((double) 'a', (int) (byte) 1, 0);
        node3.setIsSyntheticBlock(false);
        com.google.javascript.rhino.Node node6 = com.google.javascript.jscomp.NodeUtil.newExpr(node3);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(node6);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test052");
        com.google.javascript.rhino.EcmaError ecmaError2 = com.google.javascript.rhino.ScriptRuntime.constructError("DiagnosticGroup<undefinedVars>", "<unknown=160>");
        int int3 = ecmaError2.getColumnNumber();
        int int4 = ecmaError2.getLineNumber();
        java.lang.String str5 = ecmaError2.getErrorMessage();
        org.junit.Assert.assertNotNull(ecmaError2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "<unknown=160>" + "'", str5.equals("<unknown=160>"));
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test053");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile1 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.CompilerInput compilerInput2 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile1);
        com.google.javascript.jscomp.JSModule jSModule3 = null;
        compilerInput2.setModule(jSModule3);
        com.google.javascript.jscomp.CompilerInput compilerInput6 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput2, false);
        com.google.javascript.jscomp.Region region8 = compilerInput6.getRegion(32);
        java.lang.String str9 = compilerInput6.getName();
        java.io.PrintStream printStream10 = null;
        com.google.javascript.jscomp.Compiler compiler11 = new com.google.javascript.jscomp.Compiler(printStream10);
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray12 = new com.google.javascript.jscomp.JSSourceFile[] {};
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray13 = new com.google.javascript.jscomp.JSSourceFile[] {};
        com.google.javascript.jscomp.CompilerOptions compilerOptions14 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions14.devirtualizePrototypeMethods = false;
        compilerOptions14.groupVariableDeclarations = false;
        boolean boolean19 = compilerOptions14.ideMode;
        compilerOptions14.setProcessObjectPropertyString(true);
        compilerOptions14.setDefineToBooleanLiteral("BITXOR", true);
        compilerOptions14.checkControlStructures = true;
        java.util.Map<java.lang.String, com.google.javascript.rhino.Node> strMap27 = compilerOptions14.getTweakReplacements();
        com.google.javascript.jscomp.Result result28 = compiler11.compile(jSSourceFileArray12, jSSourceFileArray13, compilerOptions14);
        com.google.javascript.jscomp.JSError[] jSErrorArray29 = compiler11.getErrors();
        com.google.javascript.rhino.Node node30 = compiler11.getRoot();
        compilerInput6.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler11);
        com.google.javascript.jscomp.DiagnosticType diagnosticType35 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        com.google.javascript.jscomp.CheckLevel checkLevel36 = diagnosticType35.level;
        com.google.javascript.jscomp.CheckLevel checkLevel37 = com.google.javascript.jscomp.CheckLevel.OFF;
        diagnosticType35.level = checkLevel37;
        com.google.javascript.jscomp.AbstractCompiler abstractCompiler39 = null;
        com.google.javascript.jscomp.NodeTraversal.Callback callback40 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal41 = new com.google.javascript.jscomp.NodeTraversal(abstractCompiler39, callback40);
        com.google.javascript.rhino.Node node47 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        com.google.javascript.rhino.JSDocInfo jSDocInfo48 = null;
        node47.setJSDocInfo(jSDocInfo48);
        java.lang.RuntimeException runtimeException51 = com.google.javascript.rhino.ScriptRuntime.undefReadError((java.lang.Object) node47, (java.lang.Object) 22);
        node47.detachChildren();
        com.google.javascript.rhino.Node node53 = new com.google.javascript.rhino.Node((int) (short) 100, node47);
        com.google.javascript.jscomp.CompilerOptions compilerOptions54 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CodingConvention codingConvention55 = compilerOptions54.getCodingConvention();
        compilerOptions54.computeFunctionSideEffects = true;
        com.google.javascript.jscomp.CheckLevel checkLevel58 = compilerOptions54.checkRequires;
        com.google.javascript.jscomp.DiagnosticType diagnosticType59 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        com.google.javascript.jscomp.DiagnosticType diagnosticType63 = com.google.javascript.jscomp.Compiler.MOTION_ITERATIONS_ERROR;
        java.lang.String[] strArray70 = new java.lang.String[] { "<unknown=160>", "<unknown=160>", "<unknown=160>", "<unknown=160>", "BITXOR", "DiagnosticGroup<undefinedVars>" };
        com.google.javascript.jscomp.JSError jSError71 = com.google.javascript.jscomp.JSError.make("BITXOR", 32, (int) (short) 100, diagnosticType63, strArray70);
        com.google.javascript.jscomp.JSError jSError72 = nodeTraversal41.makeError(node53, checkLevel58, diagnosticType59, strArray70);
        com.google.javascript.jscomp.JSError jSError73 = com.google.javascript.jscomp.JSError.make("0", (int) (byte) -1, 20, diagnosticType35, strArray70);
        com.google.javascript.jscomp.CheckLevel checkLevel74 = compiler11.getErrorLevel(jSError73);
        boolean boolean75 = compiler11.acceptEcmaScript5();
        com.google.javascript.jscomp.ErrorManager errorManager76 = compiler11.getErrorManager();
        int int77 = compiler11.getWarningCount();
        com.google.javascript.jscomp.CompilerOptions compilerOptions78 = null;
        com.google.javascript.jscomp.DefaultPassConfig defaultPassConfig79 = new com.google.javascript.jscomp.DefaultPassConfig(compilerOptions78);
        try {
            compiler11.setPassConfig((com.google.javascript.jscomp.PassConfig) defaultPassConfig79);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: this.passes has already been assigned");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile1);
        org.junit.Assert.assertNull(region8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertNotNull(jSSourceFileArray12);
        org.junit.Assert.assertNotNull(jSSourceFileArray13);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(strMap27);
        org.junit.Assert.assertNotNull(result28);
        org.junit.Assert.assertNotNull(jSErrorArray29);
        org.junit.Assert.assertNotNull(node30);
        org.junit.Assert.assertNotNull(diagnosticType35);
        org.junit.Assert.assertTrue("'" + checkLevel36 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel36.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + checkLevel37 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel37.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(node47);
        org.junit.Assert.assertNotNull(runtimeException51);
        org.junit.Assert.assertNull(codingConvention55);
        org.junit.Assert.assertTrue("'" + checkLevel58 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel58.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(diagnosticType59);
        org.junit.Assert.assertNotNull(diagnosticType63);
        org.junit.Assert.assertNotNull(strArray70);
        org.junit.Assert.assertNotNull(jSError71);
        org.junit.Assert.assertNotNull(jSError72);
        org.junit.Assert.assertNotNull(jSError73);
        org.junit.Assert.assertNull(checkLevel74);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
        org.junit.Assert.assertNotNull(errorManager76);
        org.junit.Assert.assertTrue("'" + int77 + "' != '" + 1 + "'", int77 == 1);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test054");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.devirtualizePrototypeMethods = false;
        compilerOptions0.groupVariableDeclarations = false;
        boolean boolean5 = compilerOptions0.crossModuleCodeMotion;
        java.lang.String[] strArray21 = new java.lang.String[] { "", "hi!", "language version", "BITXOR", "(goog.exportSymbol)", "DiagnosticGroup<undefinedVars>", "goog.global", "goog.abstractMethod", "goog.exportProperty", "Unknown class name", "Unknown class name", "goog.exportSymbol", "DiagnosticGroup<undefinedVars>: <unknown=160>", "Not declared as a type name", "0" };
        java.util.ArrayList<java.lang.String> strList22 = new java.util.ArrayList<java.lang.String>();
        boolean boolean23 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strList22, strArray21);
        compilerOptions0.setManageClosureDependencies((java.util.List<java.lang.String>) strList22);
        boolean boolean25 = compilerOptions0.lineBreak;
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(strArray21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test055");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = null;
        com.google.javascript.jscomp.CompilerOptions compilerOptions1 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions1.devirtualizePrototypeMethods = false;
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy4 = com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC;
        compilerOptions1.propertyRenaming = propertyRenamingPolicy4;
        boolean boolean6 = compilerOptions1.recordFunctionInformation;
        compilerOptions1.optimizeArgumentsArray = false;
        com.google.javascript.jscomp.DiagnosticType diagnosticType9 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        com.google.javascript.jscomp.CheckLevel checkLevel10 = diagnosticType9.defaultLevel;
        compilerOptions1.checkMethods = checkLevel10;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard12 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup0, checkLevel10);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup13 = null;
        com.google.javascript.jscomp.CompilerOptions compilerOptions14 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions14.devirtualizePrototypeMethods = false;
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy17 = com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC;
        compilerOptions14.propertyRenaming = propertyRenamingPolicy17;
        boolean boolean19 = compilerOptions14.recordFunctionInformation;
        compilerOptions14.optimizeArgumentsArray = false;
        com.google.javascript.jscomp.DiagnosticType diagnosticType22 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        com.google.javascript.jscomp.CheckLevel checkLevel23 = diagnosticType22.defaultLevel;
        compilerOptions14.checkMethods = checkLevel23;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard25 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup13, checkLevel23);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup26 = null;
        com.google.javascript.jscomp.CompilerOptions compilerOptions27 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions27.devirtualizePrototypeMethods = false;
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy30 = com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC;
        compilerOptions27.propertyRenaming = propertyRenamingPolicy30;
        boolean boolean32 = compilerOptions27.recordFunctionInformation;
        compilerOptions27.optimizeArgumentsArray = false;
        com.google.javascript.jscomp.DiagnosticType diagnosticType35 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        com.google.javascript.jscomp.CheckLevel checkLevel36 = diagnosticType35.defaultLevel;
        compilerOptions27.checkMethods = checkLevel36;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard38 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup26, checkLevel36);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup39 = null;
        com.google.javascript.jscomp.CompilerOptions compilerOptions40 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions40.devirtualizePrototypeMethods = false;
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy43 = com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC;
        compilerOptions40.propertyRenaming = propertyRenamingPolicy43;
        boolean boolean45 = compilerOptions40.recordFunctionInformation;
        compilerOptions40.optimizeArgumentsArray = false;
        com.google.javascript.jscomp.DiagnosticType diagnosticType48 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        com.google.javascript.jscomp.CheckLevel checkLevel49 = diagnosticType48.defaultLevel;
        compilerOptions40.checkMethods = checkLevel49;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard51 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup39, checkLevel49);
        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray52 = new com.google.javascript.jscomp.WarningsGuard[] { diagnosticGroupWarningsGuard12, diagnosticGroupWarningsGuard25, diagnosticGroupWarningsGuard38, diagnosticGroupWarningsGuard51 };
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard53 = new com.google.javascript.jscomp.ComposeWarningsGuard(warningsGuardArray52);
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard54 = new com.google.javascript.jscomp.ComposeWarningsGuard(warningsGuardArray52);
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard55 = new com.google.javascript.jscomp.ComposeWarningsGuard(warningsGuardArray52);
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy4 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC + "'", propertyRenamingPolicy4.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(diagnosticType9);
        org.junit.Assert.assertTrue("'" + checkLevel10 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel10.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy17 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC + "'", propertyRenamingPolicy17.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(diagnosticType22);
        org.junit.Assert.assertTrue("'" + checkLevel23 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel23.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy30 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC + "'", propertyRenamingPolicy30.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC));
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(diagnosticType35);
        org.junit.Assert.assertTrue("'" + checkLevel36 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel36.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy43 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC + "'", propertyRenamingPolicy43.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC));
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(diagnosticType48);
        org.junit.Assert.assertTrue("'" + checkLevel49 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel49.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(warningsGuardArray52);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test056");
        java.util.List<com.google.javascript.rhino.Node> nodeList1 = null;
        com.google.javascript.rhino.Node node3 = new com.google.javascript.rhino.Node(0);
        try {
            com.google.javascript.rhino.Node node6 = com.google.javascript.jscomp.NodeUtil.newFunctionNode("(goog.exportSymbol)", nodeList1, node3, 2, 45);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test057");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile1 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.CompilerInput compilerInput2 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile1);
        com.google.javascript.jscomp.Region region4 = compilerInput2.getRegion(10);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile6 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        compilerInput2.setSourceFile((com.google.javascript.jscomp.SourceFile) jSSourceFile6);
        jSSourceFile6.clearCachedSource();
        jSSourceFile6.clearCachedSource();
        org.junit.Assert.assertNotNull(jSSourceFile1);
        org.junit.Assert.assertNull(region4);
        org.junit.Assert.assertNotNull(jSSourceFile6);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test058");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile1 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.CompilerInput compilerInput2 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile1);
        com.google.javascript.jscomp.JSModule jSModule3 = null;
        compilerInput2.setModule(jSModule3);
        com.google.javascript.jscomp.CompilerInput compilerInput6 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput2, false);
        com.google.javascript.jscomp.Region region8 = compilerInput6.getRegion(32);
        java.lang.String str9 = compilerInput6.getName();
        java.io.PrintStream printStream10 = null;
        com.google.javascript.jscomp.Compiler compiler11 = new com.google.javascript.jscomp.Compiler(printStream10);
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray12 = new com.google.javascript.jscomp.JSSourceFile[] {};
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray13 = new com.google.javascript.jscomp.JSSourceFile[] {};
        com.google.javascript.jscomp.CompilerOptions compilerOptions14 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions14.devirtualizePrototypeMethods = false;
        compilerOptions14.groupVariableDeclarations = false;
        boolean boolean19 = compilerOptions14.ideMode;
        compilerOptions14.setProcessObjectPropertyString(true);
        compilerOptions14.setDefineToBooleanLiteral("BITXOR", true);
        compilerOptions14.checkControlStructures = true;
        java.util.Map<java.lang.String, com.google.javascript.rhino.Node> strMap27 = compilerOptions14.getTweakReplacements();
        com.google.javascript.jscomp.Result result28 = compiler11.compile(jSSourceFileArray12, jSSourceFileArray13, compilerOptions14);
        com.google.javascript.jscomp.JSError[] jSErrorArray29 = compiler11.getErrors();
        com.google.javascript.rhino.Node node30 = compiler11.getRoot();
        compilerInput6.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler11);
        com.google.javascript.jscomp.DiagnosticType diagnosticType35 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        com.google.javascript.jscomp.CheckLevel checkLevel36 = diagnosticType35.level;
        com.google.javascript.jscomp.CheckLevel checkLevel37 = com.google.javascript.jscomp.CheckLevel.OFF;
        diagnosticType35.level = checkLevel37;
        com.google.javascript.jscomp.AbstractCompiler abstractCompiler39 = null;
        com.google.javascript.jscomp.NodeTraversal.Callback callback40 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal41 = new com.google.javascript.jscomp.NodeTraversal(abstractCompiler39, callback40);
        com.google.javascript.rhino.Node node47 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        com.google.javascript.rhino.JSDocInfo jSDocInfo48 = null;
        node47.setJSDocInfo(jSDocInfo48);
        java.lang.RuntimeException runtimeException51 = com.google.javascript.rhino.ScriptRuntime.undefReadError((java.lang.Object) node47, (java.lang.Object) 22);
        node47.detachChildren();
        com.google.javascript.rhino.Node node53 = new com.google.javascript.rhino.Node((int) (short) 100, node47);
        com.google.javascript.jscomp.CompilerOptions compilerOptions54 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CodingConvention codingConvention55 = compilerOptions54.getCodingConvention();
        compilerOptions54.computeFunctionSideEffects = true;
        com.google.javascript.jscomp.CheckLevel checkLevel58 = compilerOptions54.checkRequires;
        com.google.javascript.jscomp.DiagnosticType diagnosticType59 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        com.google.javascript.jscomp.DiagnosticType diagnosticType63 = com.google.javascript.jscomp.Compiler.MOTION_ITERATIONS_ERROR;
        java.lang.String[] strArray70 = new java.lang.String[] { "<unknown=160>", "<unknown=160>", "<unknown=160>", "<unknown=160>", "BITXOR", "DiagnosticGroup<undefinedVars>" };
        com.google.javascript.jscomp.JSError jSError71 = com.google.javascript.jscomp.JSError.make("BITXOR", 32, (int) (short) 100, diagnosticType63, strArray70);
        com.google.javascript.jscomp.JSError jSError72 = nodeTraversal41.makeError(node53, checkLevel58, diagnosticType59, strArray70);
        com.google.javascript.jscomp.JSError jSError73 = com.google.javascript.jscomp.JSError.make("0", (int) (byte) -1, 20, diagnosticType35, strArray70);
        com.google.javascript.jscomp.CheckLevel checkLevel74 = compiler11.getErrorLevel(jSError73);
        com.google.javascript.jscomp.DiagnosticType diagnosticType80 = com.google.javascript.jscomp.DiagnosticType.error("", "hi!");
        com.google.javascript.jscomp.DiagnosticType diagnosticType84 = com.google.javascript.jscomp.Compiler.MOTION_ITERATIONS_ERROR;
        java.lang.String[] strArray91 = new java.lang.String[] { "<unknown=160>", "<unknown=160>", "<unknown=160>", "<unknown=160>", "BITXOR", "DiagnosticGroup<undefinedVars>" };
        com.google.javascript.jscomp.JSError jSError92 = com.google.javascript.jscomp.JSError.make("BITXOR", 32, (int) (short) 100, diagnosticType84, strArray91);
        com.google.javascript.jscomp.JSError jSError93 = com.google.javascript.jscomp.JSError.make("BITXOR", 38, 130, diagnosticType80, strArray91);
        compiler11.report(jSError93);
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter95 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler11);
        org.junit.Assert.assertNotNull(jSSourceFile1);
        org.junit.Assert.assertNull(region8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertNotNull(jSSourceFileArray12);
        org.junit.Assert.assertNotNull(jSSourceFileArray13);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(strMap27);
        org.junit.Assert.assertNotNull(result28);
        org.junit.Assert.assertNotNull(jSErrorArray29);
        org.junit.Assert.assertNotNull(node30);
        org.junit.Assert.assertNotNull(diagnosticType35);
        org.junit.Assert.assertTrue("'" + checkLevel36 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel36.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + checkLevel37 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel37.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(node47);
        org.junit.Assert.assertNotNull(runtimeException51);
        org.junit.Assert.assertNull(codingConvention55);
        org.junit.Assert.assertTrue("'" + checkLevel58 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel58.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(diagnosticType59);
        org.junit.Assert.assertNotNull(diagnosticType63);
        org.junit.Assert.assertNotNull(strArray70);
        org.junit.Assert.assertNotNull(jSError71);
        org.junit.Assert.assertNotNull(jSError72);
        org.junit.Assert.assertNotNull(jSError73);
        org.junit.Assert.assertNull(checkLevel74);
        org.junit.Assert.assertNotNull(diagnosticType80);
        org.junit.Assert.assertNotNull(diagnosticType84);
        org.junit.Assert.assertNotNull(strArray91);
        org.junit.Assert.assertNotNull(jSError92);
        org.junit.Assert.assertNotNull(jSError93);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test059");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = null;
        com.google.javascript.jscomp.DiagnosticGroups.TWEAKS = diagnosticGroup0;
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test060");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CodingConvention codingConvention1 = compilerOptions0.getCodingConvention();
        com.google.javascript.jscomp.CompilerOptions.AliasTransformationHandler aliasTransformationHandler2 = compilerOptions0.getAliasTransformationHandler();
        compilerOptions0.extractPrototypeMemberDeclarations = false;
        com.google.javascript.jscomp.CheckLevel checkLevel5 = compilerOptions0.checkGlobalThisLevel;
        com.google.javascript.jscomp.CheckLevel checkLevel6 = compilerOptions0.checkMethods;
        org.junit.Assert.assertNull(codingConvention1);
        org.junit.Assert.assertNotNull(aliasTransformationHandler2);
        org.junit.Assert.assertTrue("'" + checkLevel5 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel5.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + checkLevel6 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel6.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test061");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.devirtualizePrototypeMethods = false;
        compilerOptions0.groupVariableDeclarations = false;
        java.util.Set<java.lang.String> strSet5 = compilerOptions0.stripNamePrefixes;
        java.lang.String str6 = compilerOptions0.syntheticBlockEndMarker;
        boolean boolean7 = compilerOptions0.inlineFunctions;
        compilerOptions0.renamePrefix = "Not declared as a type name";
        compilerOptions0.crossModuleCodeMotion = false;
        java.lang.String str12 = compilerOptions0.locale;
        org.junit.Assert.assertNotNull(strSet5);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(str12);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test062");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        boolean boolean5 = node4.hasMoreThanOneChild();
        node4.setLineno(0);
        com.google.javascript.rhino.Node node8 = node4.cloneTree();
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        node13.removeProp((int) (short) 1);
        com.google.javascript.rhino.Node node21 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        boolean boolean22 = node21.hasMoreThanOneChild();
        node21.setLineno(0);
        boolean boolean25 = node21.hasOneChild();
        com.google.javascript.rhino.jstype.JSType jSType26 = node21.getJSType();
        com.google.javascript.rhino.Node node31 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        node31.removeProp((int) (short) 1);
        com.google.javascript.rhino.Node[] nodeArray34 = new com.google.javascript.rhino.Node[] { node21, node31 };
        com.google.javascript.rhino.Node node37 = new com.google.javascript.rhino.Node((int) (byte) 10, nodeArray34, (int) '4', (int) (byte) -1);
        com.google.javascript.rhino.Node node38 = node13.copyInformationFromForTree(node37);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder39 = node37.new FileLevelJsDocBuilder();
        java.lang.String str43 = node37.toString(false, false, false);
        node4.addChildrenToBack(node37);
        boolean boolean45 = node37.wasEmptyNode();
        com.google.javascript.rhino.Node node50 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        com.google.javascript.rhino.JSDocInfo jSDocInfo51 = null;
        node50.setJSDocInfo(jSDocInfo51);
        boolean boolean53 = node37.isEquivalentTo(node50);
        int int54 = node50.getCharno();
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNull(jSType26);
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertNotNull(nodeArray34);
        org.junit.Assert.assertNotNull(node38);
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "BITXOR" + "'", str43.equals("BITXOR"));
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(node50);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 1 + "'", int54 == 1);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test063");
        com.google.javascript.rhino.Node node3 = new com.google.javascript.rhino.Node((int) 'a', (int) ' ', (int) (short) -1);
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        com.google.javascript.rhino.JSDocInfo jSDocInfo9 = null;
        node8.setJSDocInfo(jSDocInfo9);
        java.lang.RuntimeException runtimeException12 = com.google.javascript.rhino.ScriptRuntime.undefReadError((java.lang.Object) node8, (java.lang.Object) 22);
        boolean boolean13 = node3.isEquivalentToTyped(node8);
        node8.setVarArgs(true);
        node8.setCharno(18);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNotNull(runtimeException12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test064");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        boolean boolean5 = node4.hasMoreThanOneChild();
        node4.setLineno(0);
        com.google.javascript.rhino.Node node8 = node4.cloneTree();
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        node13.removeProp((int) (short) 1);
        com.google.javascript.rhino.Node node21 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        boolean boolean22 = node21.hasMoreThanOneChild();
        node21.setLineno(0);
        boolean boolean25 = node21.hasOneChild();
        com.google.javascript.rhino.jstype.JSType jSType26 = node21.getJSType();
        com.google.javascript.rhino.Node node31 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        node31.removeProp((int) (short) 1);
        com.google.javascript.rhino.Node[] nodeArray34 = new com.google.javascript.rhino.Node[] { node21, node31 };
        com.google.javascript.rhino.Node node37 = new com.google.javascript.rhino.Node((int) (byte) 10, nodeArray34, (int) '4', (int) (byte) -1);
        com.google.javascript.rhino.Node node38 = node13.copyInformationFromForTree(node37);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder39 = node37.new FileLevelJsDocBuilder();
        java.lang.String str43 = node37.toString(false, false, false);
        node4.addChildrenToBack(node37);
        boolean boolean45 = node37.wasEmptyNode();
        com.google.javascript.rhino.Node node50 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        com.google.javascript.rhino.JSDocInfo jSDocInfo51 = null;
        node50.setJSDocInfo(jSDocInfo51);
        boolean boolean53 = node37.isEquivalentTo(node50);
        node50.setCharno(45);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup56 = com.google.javascript.jscomp.DiagnosticGroups.STRICT_MODULE_DEP_CHECK;
        com.google.javascript.jscomp.CompilerOptions compilerOptions57 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions57.devirtualizePrototypeMethods = false;
        compilerOptions57.collapseProperties = false;
        com.google.javascript.jscomp.CheckLevel checkLevel62 = null;
        compilerOptions57.reportMissingOverride = checkLevel62;
        com.google.javascript.jscomp.CompilerOptions compilerOptions64 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions64.devirtualizePrototypeMethods = false;
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy67 = com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC;
        compilerOptions64.propertyRenaming = propertyRenamingPolicy67;
        boolean boolean69 = compilerOptions64.recordFunctionInformation;
        java.util.Set<java.lang.String> strSet70 = compilerOptions64.stripTypes;
        compilerOptions57.aliasableStrings = strSet70;
        java.lang.RuntimeException runtimeException72 = com.google.javascript.rhino.ScriptRuntime.undefWriteError((java.lang.Object) node50, (java.lang.Object) diagnosticGroup56, (java.lang.Object) strSet70);
        node50.setSourcePositionForTree(0);
        java.lang.String[] strArray93 = new java.lang.String[] { "digraph AST {\n  node [color=lightblue2, style=filled];\n  node0 [label=\"BLOCK\"];\n  node1 [label=\"SCRIPT\"];\n  node0 -> node1 [weight=1];\n  node1 -> RETURN [label=\"UNCOND\", fontcolor=\"red\", weight=0.01, color=\"red\"];\n  node0 -> RETURN [label=\"SYN_BLOCK\", fontcolor=\"red\", weight=0.01, color=\"red\"];\n  node0 -> node1 [label=\"UNCOND\", fontcolor=\"red\", weight=0.01, color=\"red\"];\n}\n", "<unknown=160>", "Named type with empty name component", "Unknown class name", "(Not declared as a constructor)", "error reporter", "DiagnosticGroup<typeInvalidation>", "0", "EOL  0\n", "(Not declared as a constructor)", "<unknown=160>", "WARNING - hi!\n", "le", "DiagnosticGroup<undefinedVars>: <unknown=160>", "WARNING - hi!\n", "Unknown class name", "language version", "EOL " };
        java.util.LinkedHashSet<java.lang.String> strSet94 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean95 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet94, strArray93);
        node50.setDirectives((java.util.Set<java.lang.String>) strSet94);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNull(jSType26);
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertNotNull(nodeArray34);
        org.junit.Assert.assertNotNull(node38);
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "BITXOR" + "'", str43.equals("BITXOR"));
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(node50);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNotNull(diagnosticGroup56);
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy67 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC + "'", propertyRenamingPolicy67.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC));
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
        org.junit.Assert.assertNotNull(strSet70);
        org.junit.Assert.assertNotNull(runtimeException72);
        org.junit.Assert.assertNotNull(strArray93);
        org.junit.Assert.assertTrue("'" + boolean95 + "' != '" + true + "'", boolean95 == true);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test065");
        com.google.javascript.jscomp.SourceFile sourceFile1 = com.google.javascript.jscomp.SourceFile.fromFile("EOL  0\n");
        org.junit.Assert.assertNotNull(sourceFile1);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test066");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeDeadCode = false;
        boolean boolean3 = compilerOptions0.checkTypes;
        boolean boolean4 = compilerOptions0.reserveRawExports;
        compilerOptions0.aliasExternals = true;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test067");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.TWEAKS;
        com.google.javascript.jscomp.DiagnosticGroups.INVALID_CASTS = diagnosticGroup0;
        com.google.javascript.jscomp.CompilerOptions compilerOptions2 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions2.devirtualizePrototypeMethods = false;
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy5 = com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC;
        compilerOptions2.propertyRenaming = propertyRenamingPolicy5;
        boolean boolean7 = compilerOptions2.recordFunctionInformation;
        compilerOptions2.setColorizeErrorOutput(false);
        boolean boolean10 = compilerOptions2.specializeInitialModule;
        compilerOptions2.computeFunctionSideEffects = false;
        boolean boolean13 = compilerOptions2.collapseAnonymousFunctions;
        com.google.javascript.jscomp.DiagnosticType diagnosticType16 = com.google.javascript.jscomp.DiagnosticType.error("goog.exportProperty", "hi!");
        com.google.javascript.jscomp.CheckLevel checkLevel17 = diagnosticType16.level;
        com.google.javascript.jscomp.CheckLevel checkLevel18 = diagnosticType16.defaultLevel;
        compilerOptions2.checkFunctions = checkLevel18;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard20 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup0, checkLevel18);
        org.junit.Assert.assertNull(diagnosticGroup0);
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy5 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC + "'", propertyRenamingPolicy5.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(diagnosticType16);
        org.junit.Assert.assertTrue("'" + checkLevel17 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel17.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + checkLevel18 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel18.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test068");
        java.util.logging.Logger logger0 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager1 = new com.google.javascript.jscomp.LoggerErrorManager(logger0);
        com.google.javascript.jscomp.JSError[] jSErrorArray2 = loggerErrorManager1.getWarnings();
        com.google.javascript.jscomp.Compiler compiler3 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager1);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile5 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        java.lang.String str6 = jSSourceFile5.getOriginalPath();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile8 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.CompilerInput compilerInput9 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile8);
        com.google.javascript.jscomp.CompilerInput compilerInput11 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile8, true);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile13 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.CompilerInput compilerInput14 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile13);
        com.google.javascript.jscomp.CompilerInput compilerInput16 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile13, true);
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray17 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile5, jSSourceFile8, jSSourceFile13 };
        java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList18 = new java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile>();
        boolean boolean19 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList18, jSSourceFileArray17);
        java.io.PrintStream printStream20 = null;
        com.google.javascript.jscomp.Compiler compiler21 = new com.google.javascript.jscomp.Compiler(printStream20);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile23 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        jSSourceFile23.clearCachedSource();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile26 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile28 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        jSSourceFile28.clearCachedSource();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile31 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.CompilerInput compilerInput32 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile31);
        boolean boolean33 = compilerInput32.isExtern();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile35 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        java.lang.String str36 = jSSourceFile35.getOriginalPath();
        compilerInput32.setSourceFile((com.google.javascript.jscomp.SourceFile) jSSourceFile35);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile39 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.CompilerInput compilerInput40 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile39);
        com.google.javascript.jscomp.CompilerInput compilerInput42 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile39, true);
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray43 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile23, jSSourceFile26, jSSourceFile28, jSSourceFile35, jSSourceFile39 };
        java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList44 = new java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile>();
        boolean boolean45 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList44, jSSourceFileArray43);
        com.google.javascript.jscomp.JSModule[] jSModuleArray46 = new com.google.javascript.jscomp.JSModule[] {};
        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList47 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
        boolean boolean48 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList47, jSModuleArray46);
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph49 = new com.google.javascript.jscomp.JSModuleGraph((java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList47);
        com.google.javascript.jscomp.CompilerOptions compilerOptions50 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions50.devirtualizePrototypeMethods = false;
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy53 = com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC;
        compilerOptions50.propertyRenaming = propertyRenamingPolicy53;
        boolean boolean55 = compilerOptions50.recordFunctionInformation;
        compilerOptions50.enableExternExports(false);
        byte[] byteArray61 = new byte[] { (byte) -1, (byte) 1, (byte) 10 };
        compilerOptions50.inputVariableMapSerialized = byteArray61;
        compilerOptions50.convertToDottedProperties = true;
        compilerOptions50.instrumentForCoverageOnly = true;
        compilerOptions50.nameReferenceReportPath = "BITXOR";
        com.google.javascript.jscomp.Result result69 = compiler21.compileModules((java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList44, (java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList47, compilerOptions50);
        com.google.javascript.jscomp.CompilerOptions compilerOptions70 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions70.devirtualizePrototypeMethods = false;
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy73 = com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC;
        compilerOptions70.propertyRenaming = propertyRenamingPolicy73;
        boolean boolean75 = compilerOptions70.recordFunctionInformation;
        compilerOptions70.optimizeArgumentsArray = false;
        com.google.javascript.jscomp.DiagnosticType diagnosticType78 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        com.google.javascript.jscomp.CheckLevel checkLevel79 = diagnosticType78.defaultLevel;
        compilerOptions70.checkMethods = checkLevel79;
        com.google.javascript.jscomp.CheckLevel checkLevel81 = compilerOptions70.checkRequires;
        compilerOptions70.setRewriteNewDateGoogNow(true);
        boolean boolean84 = compilerOptions70.checkUnusedPropertiesEarly;
        compiler3.init((java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList18, (java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList44, compilerOptions70);
        int int86 = compiler3.getWarningCount();
        com.google.javascript.jscomp.Result result87 = compiler3.getResult();
        com.google.javascript.jscomp.JSError[] jSErrorArray88 = compiler3.getMessages();
        org.junit.Assert.assertNotNull(jSErrorArray2);
        org.junit.Assert.assertNotNull(jSSourceFile5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertNotNull(jSSourceFile8);
        org.junit.Assert.assertNotNull(jSSourceFile13);
        org.junit.Assert.assertNotNull(jSSourceFileArray17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(jSSourceFile23);
        org.junit.Assert.assertNotNull(jSSourceFile26);
        org.junit.Assert.assertNotNull(jSSourceFile28);
        org.junit.Assert.assertNotNull(jSSourceFile31);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(jSSourceFile35);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "" + "'", str36.equals(""));
        org.junit.Assert.assertNotNull(jSSourceFile39);
        org.junit.Assert.assertNotNull(jSSourceFileArray43);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
        org.junit.Assert.assertNotNull(jSModuleArray46);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy53 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC + "'", propertyRenamingPolicy53.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC));
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNotNull(byteArray61);
        org.junit.Assert.assertNotNull(result69);
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy73 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC + "'", propertyRenamingPolicy73.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC));
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
        org.junit.Assert.assertNotNull(diagnosticType78);
        org.junit.Assert.assertTrue("'" + checkLevel79 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel79.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + checkLevel81 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel81.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean84 + "' != '" + false + "'", boolean84 == false);
        org.junit.Assert.assertTrue("'" + int86 + "' != '" + 0 + "'", int86 == 0);
        org.junit.Assert.assertNotNull(result87);
        org.junit.Assert.assertNotNull(jSErrorArray88);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test069");
        com.google.javascript.rhino.Node.SideEffectFlags sideEffectFlags1 = new com.google.javascript.rhino.Node.SideEffectFlags((-3));
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test070");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile1 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.CompilerInput compilerInput2 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile1);
        com.google.javascript.jscomp.JSModule jSModule3 = null;
        compilerInput2.setModule(jSModule3);
        com.google.javascript.jscomp.CompilerInput compilerInput6 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput2, false);
        com.google.javascript.jscomp.Region region8 = compilerInput6.getRegion(32);
        java.lang.String str9 = compilerInput6.getName();
        java.io.PrintStream printStream10 = null;
        com.google.javascript.jscomp.Compiler compiler11 = new com.google.javascript.jscomp.Compiler(printStream10);
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray12 = new com.google.javascript.jscomp.JSSourceFile[] {};
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray13 = new com.google.javascript.jscomp.JSSourceFile[] {};
        com.google.javascript.jscomp.CompilerOptions compilerOptions14 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions14.devirtualizePrototypeMethods = false;
        compilerOptions14.groupVariableDeclarations = false;
        boolean boolean19 = compilerOptions14.ideMode;
        compilerOptions14.setProcessObjectPropertyString(true);
        compilerOptions14.setDefineToBooleanLiteral("BITXOR", true);
        compilerOptions14.checkControlStructures = true;
        java.util.Map<java.lang.String, com.google.javascript.rhino.Node> strMap27 = compilerOptions14.getTweakReplacements();
        com.google.javascript.jscomp.Result result28 = compiler11.compile(jSSourceFileArray12, jSSourceFileArray13, compilerOptions14);
        com.google.javascript.jscomp.JSError[] jSErrorArray29 = compiler11.getErrors();
        com.google.javascript.rhino.Node node30 = compiler11.getRoot();
        compilerInput6.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler11);
        com.google.javascript.jscomp.DiagnosticType diagnosticType35 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        com.google.javascript.jscomp.CheckLevel checkLevel36 = diagnosticType35.level;
        com.google.javascript.jscomp.CheckLevel checkLevel37 = com.google.javascript.jscomp.CheckLevel.OFF;
        diagnosticType35.level = checkLevel37;
        com.google.javascript.jscomp.AbstractCompiler abstractCompiler39 = null;
        com.google.javascript.jscomp.NodeTraversal.Callback callback40 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal41 = new com.google.javascript.jscomp.NodeTraversal(abstractCompiler39, callback40);
        com.google.javascript.rhino.Node node47 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        com.google.javascript.rhino.JSDocInfo jSDocInfo48 = null;
        node47.setJSDocInfo(jSDocInfo48);
        java.lang.RuntimeException runtimeException51 = com.google.javascript.rhino.ScriptRuntime.undefReadError((java.lang.Object) node47, (java.lang.Object) 22);
        node47.detachChildren();
        com.google.javascript.rhino.Node node53 = new com.google.javascript.rhino.Node((int) (short) 100, node47);
        com.google.javascript.jscomp.CompilerOptions compilerOptions54 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CodingConvention codingConvention55 = compilerOptions54.getCodingConvention();
        compilerOptions54.computeFunctionSideEffects = true;
        com.google.javascript.jscomp.CheckLevel checkLevel58 = compilerOptions54.checkRequires;
        com.google.javascript.jscomp.DiagnosticType diagnosticType59 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        com.google.javascript.jscomp.DiagnosticType diagnosticType63 = com.google.javascript.jscomp.Compiler.MOTION_ITERATIONS_ERROR;
        java.lang.String[] strArray70 = new java.lang.String[] { "<unknown=160>", "<unknown=160>", "<unknown=160>", "<unknown=160>", "BITXOR", "DiagnosticGroup<undefinedVars>" };
        com.google.javascript.jscomp.JSError jSError71 = com.google.javascript.jscomp.JSError.make("BITXOR", 32, (int) (short) 100, diagnosticType63, strArray70);
        com.google.javascript.jscomp.JSError jSError72 = nodeTraversal41.makeError(node53, checkLevel58, diagnosticType59, strArray70);
        com.google.javascript.jscomp.JSError jSError73 = com.google.javascript.jscomp.JSError.make("0", (int) (byte) -1, 20, diagnosticType35, strArray70);
        com.google.javascript.jscomp.CheckLevel checkLevel74 = compiler11.getErrorLevel(jSError73);
        boolean boolean75 = compiler11.acceptEcmaScript5();
        com.google.javascript.jscomp.ErrorManager errorManager76 = compiler11.getErrorManager();
        boolean boolean77 = compiler11.isTypeCheckingEnabled();
        org.junit.Assert.assertNotNull(jSSourceFile1);
        org.junit.Assert.assertNull(region8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertNotNull(jSSourceFileArray12);
        org.junit.Assert.assertNotNull(jSSourceFileArray13);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(strMap27);
        org.junit.Assert.assertNotNull(result28);
        org.junit.Assert.assertNotNull(jSErrorArray29);
        org.junit.Assert.assertNotNull(node30);
        org.junit.Assert.assertNotNull(diagnosticType35);
        org.junit.Assert.assertTrue("'" + checkLevel36 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel36.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + checkLevel37 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel37.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(node47);
        org.junit.Assert.assertNotNull(runtimeException51);
        org.junit.Assert.assertNull(codingConvention55);
        org.junit.Assert.assertTrue("'" + checkLevel58 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel58.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(diagnosticType59);
        org.junit.Assert.assertNotNull(diagnosticType63);
        org.junit.Assert.assertNotNull(strArray70);
        org.junit.Assert.assertNotNull(jSError71);
        org.junit.Assert.assertNotNull(jSError72);
        org.junit.Assert.assertNotNull(jSError73);
        org.junit.Assert.assertNull(checkLevel74);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
        org.junit.Assert.assertNotNull(errorManager76);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test071");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CodingConvention codingConvention1 = compilerOptions0.getCodingConvention();
        com.google.javascript.jscomp.CompilerOptions compilerOptions2 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions2.devirtualizePrototypeMethods = false;
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy5 = com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC;
        compilerOptions2.propertyRenaming = propertyRenamingPolicy5;
        boolean boolean7 = compilerOptions2.recordFunctionInformation;
        compilerOptions2.enableExternExports(false);
        byte[] byteArray13 = new byte[] { (byte) -1, (byte) 1, (byte) 10 };
        compilerOptions2.inputVariableMapSerialized = byteArray13;
        compilerOptions2.convertToDottedProperties = true;
        com.google.javascript.jscomp.DiagnosticType diagnosticType17 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        com.google.javascript.jscomp.CheckLevel checkLevel18 = diagnosticType17.defaultLevel;
        compilerOptions2.checkFunctions = checkLevel18;
        compilerOptions0.checkGlobalNamesLevel = checkLevel18;
        compilerOptions0.optimizeReturns = false;
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy23 = compilerOptions0.propertyRenaming;
        boolean boolean24 = compilerOptions0.removeUnusedPrototypePropertiesInExterns;
        org.junit.Assert.assertNull(codingConvention1);
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy5 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC + "'", propertyRenamingPolicy5.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(byteArray13);
        org.junit.Assert.assertNotNull(diagnosticType17);
        org.junit.Assert.assertTrue("'" + checkLevel18 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel18.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy23 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.OFF + "'", propertyRenamingPolicy23.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.OFF));
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test072");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.devirtualizePrototypeMethods = false;
        compilerOptions0.groupVariableDeclarations = false;
        boolean boolean5 = compilerOptions0.crossModuleCodeMotion;
        java.lang.String[] strArray21 = new java.lang.String[] { "", "hi!", "language version", "BITXOR", "(goog.exportSymbol)", "DiagnosticGroup<undefinedVars>", "goog.global", "goog.abstractMethod", "goog.exportProperty", "Unknown class name", "Unknown class name", "goog.exportSymbol", "DiagnosticGroup<undefinedVars>: <unknown=160>", "Not declared as a type name", "0" };
        java.util.ArrayList<java.lang.String> strList22 = new java.util.ArrayList<java.lang.String>();
        boolean boolean23 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strList22, strArray21);
        compilerOptions0.setManageClosureDependencies((java.util.List<java.lang.String>) strList22);
        compilerOptions0.gatherCssNames = false;
        compilerOptions0.setRewriteNewDateGoogNow(true);
        com.google.javascript.jscomp.CompilerOptions compilerOptions29 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions29.devirtualizePrototypeMethods = false;
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy32 = com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC;
        compilerOptions29.propertyRenaming = propertyRenamingPolicy32;
        boolean boolean34 = compilerOptions29.recordFunctionInformation;
        compilerOptions29.optimizeArgumentsArray = false;
        com.google.javascript.jscomp.DiagnosticType diagnosticType37 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        com.google.javascript.jscomp.CheckLevel checkLevel38 = diagnosticType37.defaultLevel;
        compilerOptions29.checkMethods = checkLevel38;
        com.google.javascript.jscomp.CompilerOptions compilerOptions40 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions40.devirtualizePrototypeMethods = false;
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy43 = com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC;
        compilerOptions40.propertyRenaming = propertyRenamingPolicy43;
        boolean boolean45 = compilerOptions40.recordFunctionInformation;
        compilerOptions40.enableExternExports(false);
        com.google.javascript.jscomp.CheckLevel checkLevel48 = compilerOptions40.checkUnreachableCode;
        com.google.javascript.jscomp.CheckLevel checkLevel49 = compilerOptions40.reportMissingOverride;
        compilerOptions29.checkProvides = checkLevel49;
        compilerOptions0.brokenClosureRequiresLevel = checkLevel49;
        compilerOptions0.setTweakToDoubleLiteral("", (double) 9);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(strArray21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy32 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC + "'", propertyRenamingPolicy32.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC));
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(diagnosticType37);
        org.junit.Assert.assertTrue("'" + checkLevel38 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel38.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy43 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC + "'", propertyRenamingPolicy43.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC));
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + checkLevel48 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel48.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + checkLevel49 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel49.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test073");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.jstype.FunctionType functionType1 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType2 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType3 = null;
        closureCodingConvention0.applySubclassRelationship(functionType1, functionType2, subclassType3);
        java.lang.String str5 = closureCodingConvention0.getExportSymbolFunction();
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        boolean boolean12 = node11.hasMoreThanOneChild();
        node11.setLineno(0);
        boolean boolean15 = node11.hasOneChild();
        com.google.javascript.rhino.jstype.JSType jSType16 = node11.getJSType();
        com.google.javascript.rhino.Node node21 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        node21.removeProp((int) (short) 1);
        com.google.javascript.rhino.Node[] nodeArray24 = new com.google.javascript.rhino.Node[] { node11, node21 };
        com.google.javascript.rhino.Node node27 = new com.google.javascript.rhino.Node((int) (byte) 10, nodeArray24, (int) '4', (int) (byte) -1);
        node27.putBooleanProp(42, false);
        int int31 = node27.getLineno();
        try {
            boolean boolean32 = closureCodingConvention0.isPropertyTestFunction(node27);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "goog.exportSymbol" + "'", str5.equals("goog.exportSymbol"));
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNull(jSType16);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertNotNull(nodeArray24);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + (-1) + "'", int31 == (-1));
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test074");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        node4.removeProp((int) (short) 1);
        com.google.javascript.rhino.Node node7 = node4.cloneNode();
        node4.setIsSyntheticBlock(false);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(node7);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test075");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.devirtualizePrototypeMethods = false;
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy3 = com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC;
        compilerOptions0.propertyRenaming = propertyRenamingPolicy3;
        boolean boolean5 = compilerOptions0.recordFunctionInformation;
        compilerOptions0.optimizeArgumentsArray = false;
        com.google.javascript.jscomp.DiagnosticType diagnosticType8 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        com.google.javascript.jscomp.CheckLevel checkLevel9 = diagnosticType8.defaultLevel;
        compilerOptions0.checkMethods = checkLevel9;
        com.google.javascript.jscomp.CheckLevel checkLevel11 = compilerOptions0.checkRequires;
        compilerOptions0.setRewriteNewDateGoogNow(true);
        compilerOptions0.skipAllCompilerPasses();
        compilerOptions0.setDefineToNumberLiteral("", 2);
        compilerOptions0.crossModuleCodeMotion = false;
        boolean boolean20 = compilerOptions0.exportTestFunctions;
        compilerOptions0.renamePrefix = "language version";
        compilerOptions0.inlineFunctions = false;
        com.google.javascript.jscomp.SourceMap.Format format25 = compilerOptions0.sourceMapFormat;
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy3 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC + "'", propertyRenamingPolicy3.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(diagnosticType8);
        org.junit.Assert.assertTrue("'" + checkLevel9 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel9.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + checkLevel11 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel11.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(format25);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test076");
        com.google.javascript.jscomp.CompilerOptions compilerOptions1 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CodingConvention codingConvention2 = compilerOptions1.getCodingConvention();
        com.google.javascript.jscomp.CompilerOptions.AliasTransformationHandler aliasTransformationHandler3 = compilerOptions1.getAliasTransformationHandler();
        compilerOptions1.setTweakToBooleanLiteral("<unknown=160>", false);
        com.google.javascript.jscomp.CompilerOptions compilerOptions7 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions7.removeUnusedLocalVars = false;
        compilerOptions7.crossModuleCodeMotion = false;
        compilerOptions7.ambiguateProperties = false;
        compilerOptions7.checkTypedPropertyCalls = true;
        java.lang.String str16 = compilerOptions7.syntheticBlockEndMarker;
        java.util.Set<java.lang.String> strSet17 = compilerOptions7.stripTypes;
        compilerOptions1.setIdGenerators(strSet17);
        compilerOptions1.checkCaja = false;
        compilerOptions1.removeDeadCode = false;
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention23 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.jstype.FunctionType functionType24 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType25 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType26 = null;
        closureCodingConvention23.applySubclassRelationship(functionType24, functionType25, subclassType26);
        com.google.javascript.rhino.jstype.FunctionType functionType28 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType29 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType30 = null;
        closureCodingConvention23.applySubclassRelationship(functionType28, functionType29, subclassType30);
        com.google.javascript.rhino.Node node36 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        boolean boolean37 = node36.hasMoreThanOneChild();
        node36.setLineno(0);
        com.google.javascript.rhino.Node node40 = node36.cloneTree();
        com.google.javascript.rhino.Node node45 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        node45.removeProp((int) (short) 1);
        com.google.javascript.rhino.Node node53 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        boolean boolean54 = node53.hasMoreThanOneChild();
        node53.setLineno(0);
        boolean boolean57 = node53.hasOneChild();
        com.google.javascript.rhino.jstype.JSType jSType58 = node53.getJSType();
        com.google.javascript.rhino.Node node63 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        node63.removeProp((int) (short) 1);
        com.google.javascript.rhino.Node[] nodeArray66 = new com.google.javascript.rhino.Node[] { node53, node63 };
        com.google.javascript.rhino.Node node69 = new com.google.javascript.rhino.Node((int) (byte) 10, nodeArray66, (int) '4', (int) (byte) -1);
        com.google.javascript.rhino.Node node70 = node45.copyInformationFromForTree(node69);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder71 = node69.new FileLevelJsDocBuilder();
        java.lang.String str75 = node69.toString(false, false, false);
        node36.addChildrenToBack(node69);
        boolean boolean77 = node69.wasEmptyNode();
        com.google.javascript.rhino.Node node82 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        com.google.javascript.rhino.JSDocInfo jSDocInfo83 = null;
        node82.setJSDocInfo(jSDocInfo83);
        boolean boolean85 = node69.isEquivalentTo(node82);
        node82.setCharno(45);
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship88 = closureCodingConvention23.getDelegateRelationship(node82);
        try {
            java.lang.String str89 = com.google.javascript.rhino.ScriptRuntime.getMessage2("", (java.lang.Object) compilerOptions1, (java.lang.Object) node82);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property ");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNull(codingConvention2);
        org.junit.Assert.assertNotNull(aliasTransformationHandler3);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertNotNull(strSet17);
        org.junit.Assert.assertNotNull(node36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(node40);
        org.junit.Assert.assertNotNull(node45);
        org.junit.Assert.assertNotNull(node53);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertNull(jSType58);
        org.junit.Assert.assertNotNull(node63);
        org.junit.Assert.assertNotNull(nodeArray66);
        org.junit.Assert.assertNotNull(node70);
        org.junit.Assert.assertTrue("'" + str75 + "' != '" + "BITXOR" + "'", str75.equals("BITXOR"));
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
        org.junit.Assert.assertNotNull(node82);
        org.junit.Assert.assertTrue("'" + boolean85 + "' != '" + false + "'", boolean85 == false);
        org.junit.Assert.assertNull(delegateRelationship88);
    }

//    @Test
//    public void test077() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test077");
//        try {
//            com.google.javascript.rhino.Context.reportError("DiagnosticGroup<undefinedVars>: <unknown=160>", "", (int) '4', "", (int) '4');
//            org.junit.Assert.fail("Expected exception of type com.google.javascript.rhino.EvaluatorException; message: DiagnosticGroup<undefinedVars>: <unknown=160> (#52)");
//        } catch (com.google.javascript.rhino.EvaluatorException e) {
//        }
//    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test078");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.devirtualizePrototypeMethods = false;
        compilerOptions0.groupVariableDeclarations = false;
        boolean boolean5 = compilerOptions0.crossModuleCodeMotion;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap6 = null;
        compilerOptions0.cssRenamingMap = cssRenamingMap6;
        byte[] byteArray8 = compilerOptions0.inputPropertyMapSerialized;
        com.google.javascript.jscomp.CompilerOptions compilerOptions9 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions9.devirtualizePrototypeMethods = false;
        boolean boolean12 = compilerOptions9.ambiguateProperties;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy13 = com.google.javascript.jscomp.VariableRenamingPolicy.UNSPECIFIED;
        compilerOptions9.variableRenaming = variableRenamingPolicy13;
        boolean boolean15 = compilerOptions9.gatherCssNames;
        com.google.javascript.jscomp.DiagnosticType diagnosticType16 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        com.google.javascript.jscomp.CheckLevel checkLevel17 = diagnosticType16.level;
        compilerOptions9.reportMissingOverride = checkLevel17;
        compilerOptions0.checkFunctions = checkLevel17;
        com.google.javascript.jscomp.SourceMap.DetailLevel detailLevel20 = compilerOptions0.sourceMapDetailLevel;
        compilerOptions0.coalesceVariableNames = false;
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(byteArray8);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy13 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.UNSPECIFIED + "'", variableRenamingPolicy13.equals(com.google.javascript.jscomp.VariableRenamingPolicy.UNSPECIFIED));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(diagnosticType16);
        org.junit.Assert.assertTrue("'" + checkLevel17 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel17.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(detailLevel20);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test079");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.jstype.FunctionType functionType1 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType2 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType3 = null;
        closureCodingConvention0.applySubclassRelationship(functionType1, functionType2, subclassType3);
        boolean boolean6 = closureCodingConvention0.isSuperClassReference("");
        java.lang.String str7 = closureCodingConvention0.getAbstractMethodName();
        java.lang.String str8 = closureCodingConvention0.getExportPropertyFunction();
        java.lang.String str9 = closureCodingConvention0.getDelegateSuperclassName();
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention11 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.jstype.FunctionType functionType12 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType13 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType14 = null;
        closureCodingConvention11.applySubclassRelationship(functionType12, functionType13, subclassType14);
        boolean boolean17 = closureCodingConvention11.isSuperClassReference("");
        com.google.javascript.rhino.Node node22 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        node22.removeProp((int) (short) 1);
        com.google.javascript.rhino.Node node30 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        boolean boolean31 = node30.hasMoreThanOneChild();
        node30.setLineno(0);
        boolean boolean34 = node30.hasOneChild();
        com.google.javascript.rhino.jstype.JSType jSType35 = node30.getJSType();
        com.google.javascript.rhino.Node node40 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        node40.removeProp((int) (short) 1);
        com.google.javascript.rhino.Node[] nodeArray43 = new com.google.javascript.rhino.Node[] { node30, node40 };
        com.google.javascript.rhino.Node node46 = new com.google.javascript.rhino.Node((int) (byte) 10, nodeArray43, (int) '4', (int) (byte) -1);
        com.google.javascript.rhino.Node node47 = node22.copyInformationFromForTree(node46);
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention48 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.jstype.FunctionType functionType49 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType50 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType51 = null;
        closureCodingConvention48.applySubclassRelationship(functionType49, functionType50, subclassType51);
        com.google.javascript.rhino.jstype.FunctionType functionType53 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType54 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType55 = null;
        closureCodingConvention48.applySubclassRelationship(functionType53, functionType54, subclassType55);
        com.google.javascript.rhino.Node node61 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        node61.removeProp((int) (short) 1);
        com.google.javascript.rhino.Node node69 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        boolean boolean70 = node69.hasMoreThanOneChild();
        node69.setLineno(0);
        boolean boolean73 = node69.hasOneChild();
        com.google.javascript.rhino.jstype.JSType jSType74 = node69.getJSType();
        com.google.javascript.rhino.Node node79 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        node79.removeProp((int) (short) 1);
        com.google.javascript.rhino.Node[] nodeArray82 = new com.google.javascript.rhino.Node[] { node69, node79 };
        com.google.javascript.rhino.Node node85 = new com.google.javascript.rhino.Node((int) (byte) 10, nodeArray82, (int) '4', (int) (byte) -1);
        com.google.javascript.rhino.Node node86 = node61.copyInformationFromForTree(node85);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder87 = node85.new FileLevelJsDocBuilder();
        java.lang.String str91 = node85.toString(false, false, false);
        com.google.javascript.jscomp.CodingConvention.SubclassRelationship subclassRelationship92 = closureCodingConvention48.getClassesDefinedByCall(node85);
        java.lang.String str93 = closureCodingConvention11.extractClassNameIfProvide(node22, node85);
        com.google.javascript.rhino.Node[] nodeArray94 = new com.google.javascript.rhino.Node[] { node85 };
        com.google.javascript.rhino.Node node95 = new com.google.javascript.rhino.Node(27, nodeArray94);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder96 = node95.getJsDocBuilderForNode();
        java.lang.String str97 = closureCodingConvention0.getSingletonGetterClassName(node95);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "goog.abstractMethod" + "'", str7.equals("goog.abstractMethod"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "goog.exportProperty" + "'", str8.equals("goog.exportProperty"));
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertNotNull(node30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNull(jSType35);
        org.junit.Assert.assertNotNull(node40);
        org.junit.Assert.assertNotNull(nodeArray43);
        org.junit.Assert.assertNotNull(node47);
        org.junit.Assert.assertNotNull(node61);
        org.junit.Assert.assertNotNull(node69);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
        org.junit.Assert.assertNull(jSType74);
        org.junit.Assert.assertNotNull(node79);
        org.junit.Assert.assertNotNull(nodeArray82);
        org.junit.Assert.assertNotNull(node86);
        org.junit.Assert.assertTrue("'" + str91 + "' != '" + "BITXOR" + "'", str91.equals("BITXOR"));
        org.junit.Assert.assertNull(subclassRelationship92);
        org.junit.Assert.assertNull(str93);
        org.junit.Assert.assertNotNull(nodeArray94);
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder96);
        org.junit.Assert.assertNull(str97);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test080");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.devirtualizePrototypeMethods = false;
        compilerOptions0.collapseProperties = false;
        compilerOptions0.enableRuntimeTypeCheck("DiagnosticGroup<undefinedVars>");
        compilerOptions0.disambiguateProperties = true;
        com.google.javascript.jscomp.SourceMap.DetailLevel detailLevel9 = compilerOptions0.sourceMapDetailLevel;
        org.junit.Assert.assertNotNull(detailLevel9);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test081");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        node4.removeProp((int) (short) 1);
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        boolean boolean13 = node12.hasMoreThanOneChild();
        node12.setLineno(0);
        boolean boolean16 = node12.hasOneChild();
        com.google.javascript.rhino.jstype.JSType jSType17 = node12.getJSType();
        com.google.javascript.rhino.Node node22 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        node22.removeProp((int) (short) 1);
        com.google.javascript.rhino.Node[] nodeArray25 = new com.google.javascript.rhino.Node[] { node12, node22 };
        com.google.javascript.rhino.Node node28 = new com.google.javascript.rhino.Node((int) (byte) 10, nodeArray25, (int) '4', (int) (byte) -1);
        com.google.javascript.rhino.Node node29 = node4.copyInformationFromForTree(node28);
        boolean boolean30 = node4.hasChildren();
        node4.setVarArgs(false);
        com.google.javascript.rhino.Node.AncestorIterable ancestorIterable33 = node4.getAncestors();
        node4.setType((int) (short) 100);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNull(jSType17);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertNotNull(nodeArray25);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(ancestorIterable33);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test082");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.devirtualizePrototypeMethods = false;
        compilerOptions0.groupVariableDeclarations = false;
        boolean boolean5 = compilerOptions0.ideMode;
        boolean boolean6 = compilerOptions0.inlineAnonymousFunctionExpressions;
        compilerOptions0.inlineGetters = false;
        compilerOptions0.disableRuntimeTypeCheck();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test083");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray2 = new com.google.javascript.jscomp.JSSourceFile[] {};
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray3 = new com.google.javascript.jscomp.JSSourceFile[] {};
        com.google.javascript.jscomp.CompilerOptions compilerOptions4 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions4.devirtualizePrototypeMethods = false;
        compilerOptions4.groupVariableDeclarations = false;
        boolean boolean9 = compilerOptions4.ideMode;
        compilerOptions4.setProcessObjectPropertyString(true);
        compilerOptions4.setDefineToBooleanLiteral("BITXOR", true);
        compilerOptions4.checkControlStructures = true;
        java.util.Map<java.lang.String, com.google.javascript.rhino.Node> strMap17 = compilerOptions4.getTweakReplacements();
        com.google.javascript.jscomp.Result result18 = compiler1.compile(jSSourceFileArray2, jSSourceFileArray3, compilerOptions4);
        com.google.javascript.jscomp.JSError[] jSErrorArray19 = compiler1.getErrors();
        com.google.javascript.rhino.Node node20 = compiler1.getRoot();
        com.google.javascript.jscomp.ErrorManager errorManager21 = compiler1.getErrorManager();
        com.google.javascript.jscomp.AbstractCompiler abstractCompiler22 = null;
        com.google.javascript.jscomp.NodeTraversal.Callback callback23 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal24 = new com.google.javascript.jscomp.NodeTraversal(abstractCompiler22, callback23);
        com.google.javascript.rhino.Node node30 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        com.google.javascript.rhino.JSDocInfo jSDocInfo31 = null;
        node30.setJSDocInfo(jSDocInfo31);
        java.lang.RuntimeException runtimeException34 = com.google.javascript.rhino.ScriptRuntime.undefReadError((java.lang.Object) node30, (java.lang.Object) 22);
        node30.detachChildren();
        com.google.javascript.rhino.Node node36 = new com.google.javascript.rhino.Node((int) (short) 100, node30);
        com.google.javascript.jscomp.CompilerOptions compilerOptions37 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CodingConvention codingConvention38 = compilerOptions37.getCodingConvention();
        compilerOptions37.computeFunctionSideEffects = true;
        com.google.javascript.jscomp.CheckLevel checkLevel41 = compilerOptions37.checkRequires;
        com.google.javascript.jscomp.DiagnosticType diagnosticType42 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        com.google.javascript.jscomp.DiagnosticType diagnosticType46 = com.google.javascript.jscomp.Compiler.MOTION_ITERATIONS_ERROR;
        java.lang.String[] strArray53 = new java.lang.String[] { "<unknown=160>", "<unknown=160>", "<unknown=160>", "<unknown=160>", "BITXOR", "DiagnosticGroup<undefinedVars>" };
        com.google.javascript.jscomp.JSError jSError54 = com.google.javascript.jscomp.JSError.make("BITXOR", 32, (int) (short) 100, diagnosticType46, strArray53);
        com.google.javascript.jscomp.JSError jSError55 = nodeTraversal24.makeError(node36, checkLevel41, diagnosticType42, strArray53);
        com.google.javascript.jscomp.CheckLevel checkLevel56 = compiler1.getErrorLevel(jSError55);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile57 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile59 = com.google.javascript.jscomp.JSSourceFile.fromFile("ifeq");
        com.google.javascript.jscomp.CompilerOptions compilerOptions60 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions60.removeDeadCode = false;
        compilerOptions60.inlineLocalVariables = true;
        compilerOptions60.rewriteFunctionExpressions = true;
        try {
            com.google.javascript.jscomp.Result result67 = compiler1.compile(jSSourceFile57, jSSourceFile59, compilerOptions60);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFileArray2);
        org.junit.Assert.assertNotNull(jSSourceFileArray3);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(strMap17);
        org.junit.Assert.assertNotNull(result18);
        org.junit.Assert.assertNotNull(jSErrorArray19);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNotNull(errorManager21);
        org.junit.Assert.assertNotNull(node30);
        org.junit.Assert.assertNotNull(runtimeException34);
        org.junit.Assert.assertNull(codingConvention38);
        org.junit.Assert.assertTrue("'" + checkLevel41 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel41.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(diagnosticType42);
        org.junit.Assert.assertNotNull(diagnosticType46);
        org.junit.Assert.assertNotNull(strArray53);
        org.junit.Assert.assertNotNull(jSError54);
        org.junit.Assert.assertNotNull(jSError55);
        org.junit.Assert.assertNull(checkLevel56);
        org.junit.Assert.assertNotNull(jSSourceFile59);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test084");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.devirtualizePrototypeMethods = false;
        compilerOptions0.groupVariableDeclarations = false;
        java.util.Set<java.lang.String> strSet5 = compilerOptions0.stripNamePrefixes;
        java.lang.String str6 = compilerOptions0.syntheticBlockEndMarker;
        boolean boolean7 = compilerOptions0.inlineFunctions;
        compilerOptions0.renamePrefix = "Not declared as a type name";
        boolean boolean10 = compilerOptions0.checkCaja;
        compilerOptions0.extractPrototypeMemberDeclarations = false;
        org.junit.Assert.assertNotNull(strSet5);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test085");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeUnusedLocalVars = false;
        compilerOptions0.crossModuleCodeMotion = false;
        compilerOptions0.ambiguateProperties = false;
        boolean boolean7 = compilerOptions0.markNoSideEffectCalls;
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test086");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile1 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.CompilerInput compilerInput2 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile1);
        boolean boolean3 = compilerInput2.isExtern();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile5 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        java.lang.String str6 = jSSourceFile5.getOriginalPath();
        compilerInput2.setSourceFile((com.google.javascript.jscomp.SourceFile) jSSourceFile5);
        com.google.javascript.jscomp.JSModule jSModule8 = compilerInput2.getModule();
        com.google.javascript.jscomp.Region region10 = compilerInput2.getRegion(12);
        org.junit.Assert.assertNotNull(jSSourceFile1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(jSSourceFile5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertNull(jSModule8);
        org.junit.Assert.assertNull(region10);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test087");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.devirtualizePrototypeMethods = false;
        compilerOptions0.groupVariableDeclarations = false;
        boolean boolean5 = compilerOptions0.ideMode;
        compilerOptions0.setProcessObjectPropertyString(true);
        compilerOptions0.setDefineToBooleanLiteral("BITXOR", true);
        compilerOptions0.checkControlStructures = true;
        java.util.Map<java.lang.String, com.google.javascript.rhino.Node> strMap13 = compilerOptions0.getTweakReplacements();
        boolean boolean14 = compilerOptions0.removeDeadCode;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy15 = null;
        com.google.javascript.jscomp.CompilerOptions compilerOptions16 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions16.removeUnusedLocalVars = false;
        compilerOptions16.crossModuleCodeMotion = false;
        compilerOptions16.ambiguateProperties = false;
        compilerOptions16.computeFunctionSideEffects = false;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy25 = com.google.javascript.jscomp.VariableRenamingPolicy.UNSPECIFIED;
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy26 = com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC;
        compilerOptions16.setRenamingPolicy(variableRenamingPolicy25, propertyRenamingPolicy26);
        compilerOptions0.setRenamingPolicy(variableRenamingPolicy15, propertyRenamingPolicy26);
        boolean boolean29 = compilerOptions0.prettyPrint;
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(strMap13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy25 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.UNSPECIFIED + "'", variableRenamingPolicy25.equals(com.google.javascript.jscomp.VariableRenamingPolicy.UNSPECIFIED));
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy26 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC + "'", propertyRenamingPolicy26.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC));
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test088");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile1 = com.google.javascript.jscomp.JSSourceFile.fromFile("DiagnosticGroup<undefinedVars>");
        jSSourceFile1.clearCachedSource();
        org.junit.Assert.assertNotNull(jSSourceFile1);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test089");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        boolean boolean5 = node4.hasMoreThanOneChild();
        node4.setLineno(0);
        boolean boolean8 = node4.hasOneChild();
        com.google.javascript.rhino.jstype.JSType jSType9 = node4.getJSType();
        com.google.javascript.jscomp.CompilerOptions compilerOptions10 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions10.removeUnusedLocalVars = false;
        compilerOptions10.crossModuleCodeMotion = false;
        com.google.javascript.jscomp.CompilerOptions compilerOptions15 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions15.devirtualizePrototypeMethods = false;
        java.util.Set<java.lang.String> strSet18 = compilerOptions15.stripNameSuffixes;
        compilerOptions10.stripNamePrefixes = strSet18;
        node4.setDirectives(strSet18);
        java.lang.String str21 = node4.getQualifiedName();
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNull(jSType9);
        org.junit.Assert.assertNotNull(strSet18);
        org.junit.Assert.assertNull(str21);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test090");
        com.google.javascript.rhino.EcmaError ecmaError2 = com.google.javascript.rhino.ScriptRuntime.constructError("0", "goog.exportProperty");
        java.lang.String str3 = ecmaError2.sourceName();
        int int4 = ecmaError2.getColumnNumber();
        java.lang.String str5 = ecmaError2.getSourceName();
        org.junit.Assert.assertNotNull(ecmaError2);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNull(str5);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test091");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile1 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.CompilerInput compilerInput2 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile1);
        com.google.javascript.jscomp.JSModule jSModule3 = null;
        compilerInput2.setModule(jSModule3);
        com.google.javascript.jscomp.CompilerInput compilerInput6 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput2, false);
        com.google.javascript.jscomp.Region region8 = compilerInput6.getRegion(32);
        java.lang.String str9 = compilerInput6.getName();
        java.io.PrintStream printStream10 = null;
        com.google.javascript.jscomp.Compiler compiler11 = new com.google.javascript.jscomp.Compiler(printStream10);
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray12 = new com.google.javascript.jscomp.JSSourceFile[] {};
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray13 = new com.google.javascript.jscomp.JSSourceFile[] {};
        com.google.javascript.jscomp.CompilerOptions compilerOptions14 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions14.devirtualizePrototypeMethods = false;
        compilerOptions14.groupVariableDeclarations = false;
        boolean boolean19 = compilerOptions14.ideMode;
        compilerOptions14.setProcessObjectPropertyString(true);
        compilerOptions14.setDefineToBooleanLiteral("BITXOR", true);
        compilerOptions14.checkControlStructures = true;
        java.util.Map<java.lang.String, com.google.javascript.rhino.Node> strMap27 = compilerOptions14.getTweakReplacements();
        com.google.javascript.jscomp.Result result28 = compiler11.compile(jSSourceFileArray12, jSSourceFileArray13, compilerOptions14);
        com.google.javascript.jscomp.JSError[] jSErrorArray29 = compiler11.getErrors();
        com.google.javascript.rhino.Node node30 = compiler11.getRoot();
        compilerInput6.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler11);
        boolean boolean32 = compiler11.acceptConstKeyword();
        com.google.javascript.jscomp.Result result33 = compiler11.getResult();
        com.google.javascript.jscomp.PerformanceTracker performanceTracker34 = compiler11.tracker;
        org.junit.Assert.assertNotNull(jSSourceFile1);
        org.junit.Assert.assertNull(region8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertNotNull(jSSourceFileArray12);
        org.junit.Assert.assertNotNull(jSSourceFileArray13);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(strMap27);
        org.junit.Assert.assertNotNull(result28);
        org.junit.Assert.assertNotNull(jSErrorArray29);
        org.junit.Assert.assertNotNull(node30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(result33);
        org.junit.Assert.assertNull(performanceTracker34);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test092");
        com.google.javascript.rhino.Context context0 = new com.google.javascript.rhino.Context();
        com.google.javascript.jscomp.AnonymousFunctionNamingPolicy anonymousFunctionNamingPolicy1 = com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.UNMAPPED;
        context0.removeThreadLocal((java.lang.Object) anonymousFunctionNamingPolicy1);
        long long3 = com.google.javascript.rhino.ScriptRuntime.lastUint32Result(context0);
        com.google.javascript.jscomp.CompilerOptions compilerOptions4 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions4.devirtualizePrototypeMethods = false;
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy7 = com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC;
        compilerOptions4.propertyRenaming = propertyRenamingPolicy7;
        boolean boolean9 = compilerOptions4.recordFunctionInformation;
        compilerOptions4.enableExternExports(false);
        byte[] byteArray15 = new byte[] { (byte) -1, (byte) 1, (byte) 10 };
        compilerOptions4.inputVariableMapSerialized = byteArray15;
        compilerOptions4.removeTryCatchFinally = true;
        com.google.javascript.jscomp.CheckLevel checkLevel19 = compilerOptions4.reportMissingOverride;
        context0.removeThreadLocal((java.lang.Object) compilerOptions4);
        java.beans.PropertyChangeListener propertyChangeListener21 = null;
        try {
            context0.addPropertyChangeListener(propertyChangeListener21);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + anonymousFunctionNamingPolicy1 + "' != '" + com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.UNMAPPED + "'", anonymousFunctionNamingPolicy1.equals(com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.UNMAPPED));
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy7 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC + "'", propertyRenamingPolicy7.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(byteArray15);
        org.junit.Assert.assertTrue("'" + checkLevel19 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel19.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test093");
        com.google.javascript.rhino.EcmaError ecmaError1 = com.google.javascript.rhino.ScriptRuntime.typeError("(goog.exportSymbol)");
        java.lang.String str2 = ecmaError1.details();
        int int3 = ecmaError1.getLineNumber();
        java.lang.String str4 = ecmaError1.lineSource();
        org.junit.Assert.assertNotNull(ecmaError1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "TypeError: (goog.exportSymbol)" + "'", str2.equals("TypeError: (goog.exportSymbol)"));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test094");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString(". hi! at BITXOR line 38 : 130", 19, 18);
        node3.putBooleanProp((int) (short) -1, true);
        org.junit.Assert.assertNotNull(node3);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test095");
        com.google.javascript.jscomp.CompilerOptions compilerOptions3 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions3.devirtualizePrototypeMethods = false;
        compilerOptions3.groupVariableDeclarations = false;
        java.util.Set<java.lang.String> strSet8 = compilerOptions3.stripNamePrefixes;
        java.lang.String str9 = compilerOptions3.syntheticBlockEndMarker;
        com.google.javascript.jscomp.DiagnosticType diagnosticType10 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        com.google.javascript.jscomp.CheckLevel checkLevel11 = diagnosticType10.level;
        compilerOptions3.reportMissingOverride = checkLevel11;
        com.google.javascript.rhino.Node node14 = null;
        com.google.javascript.jscomp.DiagnosticType diagnosticType15 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        com.google.javascript.jscomp.CheckLevel checkLevel16 = diagnosticType15.level;
        java.lang.Class<?> wildcardClass17 = diagnosticType15.getClass();
        com.google.javascript.jscomp.CompilerOptions compilerOptions18 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions18.devirtualizePrototypeMethods = false;
        compilerOptions18.groupVariableDeclarations = false;
        boolean boolean23 = compilerOptions18.crossModuleCodeMotion;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap24 = null;
        compilerOptions18.cssRenamingMap = cssRenamingMap24;
        byte[] byteArray26 = compilerOptions18.inputPropertyMapSerialized;
        com.google.javascript.jscomp.CompilerOptions compilerOptions27 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions27.devirtualizePrototypeMethods = false;
        boolean boolean30 = compilerOptions27.ambiguateProperties;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy31 = com.google.javascript.jscomp.VariableRenamingPolicy.UNSPECIFIED;
        compilerOptions27.variableRenaming = variableRenamingPolicy31;
        boolean boolean33 = compilerOptions27.gatherCssNames;
        com.google.javascript.jscomp.DiagnosticType diagnosticType34 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        com.google.javascript.jscomp.CheckLevel checkLevel35 = diagnosticType34.level;
        compilerOptions27.reportMissingOverride = checkLevel35;
        compilerOptions18.checkFunctions = checkLevel35;
        diagnosticType15.level = checkLevel35;
        com.google.javascript.rhino.Node node45 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        com.google.javascript.rhino.JSDocInfo jSDocInfo46 = null;
        node45.setJSDocInfo(jSDocInfo46);
        java.lang.RuntimeException runtimeException49 = com.google.javascript.rhino.ScriptRuntime.undefReadError((java.lang.Object) node45, (java.lang.Object) 22);
        node45.detachChildren();
        com.google.javascript.rhino.Node node51 = new com.google.javascript.rhino.Node((int) (short) 100, node45);
        boolean boolean52 = node51.isVarArgs();
        com.google.javascript.jscomp.DiagnosticType diagnosticType53 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        com.google.javascript.jscomp.DiagnosticType diagnosticType54 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        com.google.javascript.jscomp.CheckLevel checkLevel55 = diagnosticType54.defaultLevel;
        java.lang.String[] strArray60 = new java.lang.String[] { "hi!", "goog.exportProperty", "<unknown=160>", "goog.global" };
        com.google.javascript.jscomp.JSError jSError61 = com.google.javascript.jscomp.JSError.make(diagnosticType54, strArray60);
        com.google.javascript.jscomp.JSError jSError62 = com.google.javascript.jscomp.JSError.make("// Input %num%", node51, diagnosticType53, strArray60);
        com.google.javascript.jscomp.JSError jSError63 = com.google.javascript.jscomp.JSError.make("language version", node14, diagnosticType15, strArray60);
        com.google.javascript.jscomp.DiagnosticType diagnosticType66 = com.google.javascript.jscomp.DiagnosticType.disabled("", "error reporter");
        com.google.javascript.jscomp.DiagnosticType diagnosticType67 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        com.google.javascript.jscomp.CheckLevel checkLevel68 = diagnosticType67.defaultLevel;
        java.lang.String[] strArray73 = new java.lang.String[] { "hi!", "goog.exportProperty", "<unknown=160>", "goog.global" };
        com.google.javascript.jscomp.JSError jSError74 = com.google.javascript.jscomp.JSError.make(diagnosticType67, strArray73);
        com.google.javascript.jscomp.JSError jSError75 = com.google.javascript.jscomp.JSError.make(diagnosticType66, strArray73);
        com.google.javascript.jscomp.JSError jSError76 = com.google.javascript.jscomp.JSError.make("EOL  [parenthesized: 45]", (int) (byte) -1, 31, checkLevel11, diagnosticType15, strArray73);
        org.junit.Assert.assertNotNull(strSet8);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertNotNull(diagnosticType10);
        org.junit.Assert.assertTrue("'" + checkLevel11 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel11.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(diagnosticType15);
        org.junit.Assert.assertTrue("'" + checkLevel16 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel16.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNull(byteArray26);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy31 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.UNSPECIFIED + "'", variableRenamingPolicy31.equals(com.google.javascript.jscomp.VariableRenamingPolicy.UNSPECIFIED));
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(diagnosticType34);
        org.junit.Assert.assertTrue("'" + checkLevel35 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel35.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(node45);
        org.junit.Assert.assertNotNull(runtimeException49);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertNotNull(diagnosticType53);
        org.junit.Assert.assertNotNull(diagnosticType54);
        org.junit.Assert.assertTrue("'" + checkLevel55 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel55.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(strArray60);
        org.junit.Assert.assertNotNull(jSError61);
        org.junit.Assert.assertNotNull(jSError62);
        org.junit.Assert.assertNotNull(jSError63);
        org.junit.Assert.assertNotNull(diagnosticType66);
        org.junit.Assert.assertNotNull(diagnosticType67);
        org.junit.Assert.assertTrue("'" + checkLevel68 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel68.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(strArray73);
        org.junit.Assert.assertNotNull(jSError74);
        org.junit.Assert.assertNotNull(jSError75);
        org.junit.Assert.assertNotNull(jSError76);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test096");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString((int) (short) 100, "DiagnosticGroup<undefinedVars>", 30, 25);
        org.junit.Assert.assertNotNull(node4);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test097");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeUnusedLocalVars = false;
        compilerOptions0.crossModuleCodeMotion = false;
        compilerOptions0.specializeInitialModule = false;
        com.google.javascript.jscomp.SourceMap.DetailLevel detailLevel7 = compilerOptions0.sourceMapDetailLevel;
        com.google.javascript.jscomp.CompilerOptions compilerOptions8 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions8.removeUnusedLocalVars = false;
        compilerOptions8.crossModuleCodeMotion = false;
        compilerOptions8.ambiguateProperties = false;
        compilerOptions8.checkTypedPropertyCalls = true;
        java.lang.String str17 = compilerOptions8.syntheticBlockEndMarker;
        java.util.Set<java.lang.String> strSet18 = compilerOptions8.stripTypes;
        com.google.javascript.jscomp.CheckLevel checkLevel19 = compilerOptions8.reportMissingOverride;
        compilerOptions0.checkGlobalThisLevel = checkLevel19;
        org.junit.Assert.assertNotNull(detailLevel7);
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertNotNull(strSet18);
        org.junit.Assert.assertTrue("'" + checkLevel19 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel19.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test098");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray2 = new com.google.javascript.jscomp.JSSourceFile[] {};
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray3 = new com.google.javascript.jscomp.JSSourceFile[] {};
        com.google.javascript.jscomp.CompilerOptions compilerOptions4 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions4.devirtualizePrototypeMethods = false;
        compilerOptions4.groupVariableDeclarations = false;
        boolean boolean9 = compilerOptions4.ideMode;
        compilerOptions4.setProcessObjectPropertyString(true);
        compilerOptions4.setDefineToBooleanLiteral("BITXOR", true);
        compilerOptions4.checkControlStructures = true;
        java.util.Map<java.lang.String, com.google.javascript.rhino.Node> strMap17 = compilerOptions4.getTweakReplacements();
        com.google.javascript.jscomp.Result result18 = compiler1.compile(jSSourceFileArray2, jSSourceFileArray3, compilerOptions4);
        com.google.javascript.jscomp.JSError[] jSErrorArray19 = compiler1.getErrors();
        com.google.javascript.jscomp.JSError[] jSErrorArray20 = compiler1.getMessages();
        com.google.javascript.jscomp.JSError[] jSErrorArray21 = compiler1.getWarnings();
        try {
            compiler1.optimize();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: One-time passes cannot be run multiple times: markUnnormalized");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFileArray2);
        org.junit.Assert.assertNotNull(jSSourceFileArray3);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(strMap17);
        org.junit.Assert.assertNotNull(result18);
        org.junit.Assert.assertNotNull(jSErrorArray19);
        org.junit.Assert.assertNotNull(jSErrorArray20);
        org.junit.Assert.assertNotNull(jSErrorArray21);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test099");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.jstype.FunctionType functionType1 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType2 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType3 = null;
        closureCodingConvention0.applySubclassRelationship(functionType1, functionType2, subclassType3);
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        boolean boolean10 = node9.hasMoreThanOneChild();
        node9.setLineno(0);
        com.google.javascript.rhino.Node node13 = node9.cloneTree();
        com.google.javascript.rhino.Node node14 = node13.removeFirstChild();
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        node19.removeProp((int) (short) 1);
        com.google.javascript.rhino.Node node27 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        boolean boolean28 = node27.hasMoreThanOneChild();
        node27.setLineno(0);
        boolean boolean31 = node27.hasOneChild();
        com.google.javascript.rhino.jstype.JSType jSType32 = node27.getJSType();
        com.google.javascript.rhino.Node node37 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        node37.removeProp((int) (short) 1);
        com.google.javascript.rhino.Node[] nodeArray40 = new com.google.javascript.rhino.Node[] { node27, node37 };
        com.google.javascript.rhino.Node node43 = new com.google.javascript.rhino.Node((int) (byte) 10, nodeArray40, (int) '4', (int) (byte) -1);
        com.google.javascript.rhino.Node node44 = node19.copyInformationFromForTree(node43);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder45 = node43.new FileLevelJsDocBuilder();
        java.lang.String str49 = node43.toString(false, false, false);
        boolean boolean50 = node43.isUnscopedQualifiedName();
        int int51 = node43.getLineno();
        java.lang.String str52 = closureCodingConvention0.extractClassNameIfProvide(node13, node43);
        com.google.javascript.rhino.Node node53 = node13.removeFirstChild();
        java.lang.String str54 = node13.toStringTree();
        node13.putIntProp(0, (int) (short) 1);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNull(node14);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNotNull(node27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNull(jSType32);
        org.junit.Assert.assertNotNull(node37);
        org.junit.Assert.assertNotNull(nodeArray40);
        org.junit.Assert.assertNotNull(node44);
        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "BITXOR" + "'", str49.equals("BITXOR"));
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + (-1) + "'", int51 == (-1));
        org.junit.Assert.assertNull(str52);
        org.junit.Assert.assertNull(node53);
        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "EOL  0\n" + "'", str54.equals("EOL  0\n"));
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test100");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.devirtualizePrototypeMethods = false;
        java.lang.String str3 = compilerOptions0.syntheticBlockStartMarker;
        com.google.javascript.jscomp.CompilerOptions compilerOptions4 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CodingConvention codingConvention5 = compilerOptions4.getCodingConvention();
        boolean boolean6 = compilerOptions4.inlineLocalVariables;
        com.google.javascript.jscomp.CheckLevel checkLevel7 = compilerOptions4.aggressiveVarCheck;
        compilerOptions0.checkUndefinedProperties = checkLevel7;
        com.google.javascript.jscomp.CompilerOptions compilerOptions9 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions9.removeUnusedLocalVars = false;
        compilerOptions9.crossModuleCodeMotion = false;
        compilerOptions9.ambiguateProperties = false;
        compilerOptions9.computeFunctionSideEffects = false;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy18 = com.google.javascript.jscomp.VariableRenamingPolicy.UNSPECIFIED;
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy19 = com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC;
        compilerOptions9.setRenamingPolicy(variableRenamingPolicy18, propertyRenamingPolicy19);
        boolean boolean21 = compilerOptions9.aliasExternals;
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup22 = com.google.javascript.jscomp.DiagnosticGroups.UNDEFINED_VARIABLES;
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup23 = com.google.javascript.jscomp.DiagnosticGroups.CONSTANT_PROPERTY;
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup24 = com.google.javascript.jscomp.DiagnosticGroups.UNDEFINED_VARIABLES;
        com.google.javascript.jscomp.DiagnosticGroups.CHECK_USELESS_CODE = diagnosticGroup24;
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup26 = com.google.javascript.jscomp.DiagnosticGroups.CONSTANT_PROPERTY;
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup27 = com.google.javascript.jscomp.DiagnosticGroups.CONSTANT_PROPERTY;
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup28 = com.google.javascript.jscomp.DiagnosticGroups.TYPE_INVALIDATION;
        com.google.javascript.jscomp.DiagnosticGroup[] diagnosticGroupArray29 = new com.google.javascript.jscomp.DiagnosticGroup[] { diagnosticGroup22, diagnosticGroup23, diagnosticGroup24, diagnosticGroup26, diagnosticGroup27, diagnosticGroup28 };
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup30 = new com.google.javascript.jscomp.DiagnosticGroup(diagnosticGroupArray29);
        com.google.javascript.jscomp.CompilerOptions compilerOptions31 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CodingConvention codingConvention32 = compilerOptions31.getCodingConvention();
        compilerOptions31.computeFunctionSideEffects = true;
        com.google.javascript.jscomp.CheckLevel checkLevel35 = compilerOptions31.checkRequires;
        compilerOptions9.setWarningLevel(diagnosticGroup30, checkLevel35);
        compilerOptions0.checkMissingReturn = checkLevel35;
        compilerOptions0.inlineLocalFunctions = false;
        compilerOptions0.strictMessageReplacement = false;
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNull(codingConvention5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + checkLevel7 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel7.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy18 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.UNSPECIFIED + "'", variableRenamingPolicy18.equals(com.google.javascript.jscomp.VariableRenamingPolicy.UNSPECIFIED));
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy19 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC + "'", propertyRenamingPolicy19.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC));
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(diagnosticGroup22);
        org.junit.Assert.assertNotNull(diagnosticGroup23);
        org.junit.Assert.assertNotNull(diagnosticGroup24);
        org.junit.Assert.assertNotNull(diagnosticGroup26);
        org.junit.Assert.assertNotNull(diagnosticGroup27);
        org.junit.Assert.assertNotNull(diagnosticGroup28);
        org.junit.Assert.assertNotNull(diagnosticGroupArray29);
        org.junit.Assert.assertNull(codingConvention32);
        org.junit.Assert.assertTrue("'" + checkLevel35 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel35.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test101");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CodingConvention codingConvention1 = compilerOptions0.getCodingConvention();
        com.google.javascript.jscomp.CompilerOptions compilerOptions2 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions2.devirtualizePrototypeMethods = false;
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy5 = com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC;
        compilerOptions2.propertyRenaming = propertyRenamingPolicy5;
        boolean boolean7 = compilerOptions2.recordFunctionInformation;
        compilerOptions2.enableExternExports(false);
        byte[] byteArray13 = new byte[] { (byte) -1, (byte) 1, (byte) 10 };
        compilerOptions2.inputVariableMapSerialized = byteArray13;
        compilerOptions2.convertToDottedProperties = true;
        com.google.javascript.jscomp.DiagnosticType diagnosticType17 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        com.google.javascript.jscomp.CheckLevel checkLevel18 = diagnosticType17.defaultLevel;
        compilerOptions2.checkFunctions = checkLevel18;
        compilerOptions0.checkGlobalNamesLevel = checkLevel18;
        com.google.javascript.jscomp.MessageBundle messageBundle21 = null;
        compilerOptions0.messageBundle = messageBundle21;
        java.lang.String str23 = compilerOptions0.locale;
        com.google.javascript.jscomp.SourceMap.DetailLevel detailLevel24 = null;
        compilerOptions0.sourceMapDetailLevel = detailLevel24;
        org.junit.Assert.assertNull(codingConvention1);
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy5 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC + "'", propertyRenamingPolicy5.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(byteArray13);
        org.junit.Assert.assertNotNull(diagnosticType17);
        org.junit.Assert.assertTrue("'" + checkLevel18 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel18.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNull(str23);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test102");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeDeadCode = false;
        boolean boolean3 = compilerOptions0.inlineAnonymousFunctionExpressions;
        compilerOptions0.crossModuleMethodMotion = true;
        boolean boolean6 = compilerOptions0.moveFunctionDeclarations;
        compilerOptions0.collapseProperties = false;
        com.google.javascript.jscomp.CheckLevel checkLevel9 = compilerOptions0.checkProvides;
        boolean boolean10 = compilerOptions0.instrumentForCoverage;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + checkLevel9 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel9.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test103");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile1 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.CompilerInput compilerInput2 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile1);
        boolean boolean3 = compilerInput2.isExtern();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile5 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        java.lang.String str6 = jSSourceFile5.getOriginalPath();
        compilerInput2.setSourceFile((com.google.javascript.jscomp.SourceFile) jSSourceFile5);
        com.google.javascript.jscomp.JSModule jSModule8 = compilerInput2.getModule();
        com.google.javascript.jscomp.Region region10 = compilerInput2.getRegion(160);
        java.lang.String str12 = compilerInput2.getLine(42);
        com.google.javascript.jscomp.SourceFile sourceFile13 = compilerInput2.getSourceFile();
        org.junit.Assert.assertNotNull(jSSourceFile1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(jSSourceFile5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertNull(jSModule8);
        org.junit.Assert.assertNull(region10);
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertNotNull(sourceFile13);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test104");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeUnusedLocalVars = false;
        compilerOptions0.crossModuleCodeMotion = false;
        compilerOptions0.specializeInitialModule = false;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy7 = compilerOptions0.variableRenaming;
        compilerOptions0.collapseAnonymousFunctions = true;
        boolean boolean10 = compilerOptions0.disambiguateProperties;
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy7 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.OFF + "'", variableRenamingPolicy7.equals(com.google.javascript.jscomp.VariableRenamingPolicy.OFF));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test105");
        try {
            com.google.javascript.rhino.Context.reportWarning("EOL  [parenthesized: 45]");
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: No Context associated with current Thread");
        } catch (java.lang.RuntimeException e) {
        }
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test106");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.jstype.FunctionType functionType1 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType2 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType3 = null;
        closureCodingConvention0.applySubclassRelationship(functionType1, functionType2, subclassType3);
        boolean boolean6 = closureCodingConvention0.isSuperClassReference("");
        java.lang.String str7 = closureCodingConvention0.getAbstractMethodName();
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        boolean boolean15 = node14.hasMoreThanOneChild();
        node14.setLineno(0);
        boolean boolean18 = node14.hasOneChild();
        com.google.javascript.rhino.jstype.JSType jSType19 = node14.getJSType();
        com.google.javascript.rhino.Node node24 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        node24.removeProp((int) (short) 1);
        com.google.javascript.rhino.Node[] nodeArray27 = new com.google.javascript.rhino.Node[] { node14, node24 };
        com.google.javascript.rhino.Node node30 = new com.google.javascript.rhino.Node((int) (byte) 10, nodeArray27, (int) '4', (int) (byte) -1);
        node30.putBooleanProp(42, false);
        com.google.javascript.rhino.Node node38 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        boolean boolean39 = node38.hasMoreThanOneChild();
        node38.setLineno(0);
        com.google.javascript.rhino.Node node42 = node38.cloneTree();
        com.google.javascript.rhino.Node node47 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        node47.removeProp((int) (short) 1);
        com.google.javascript.rhino.Node node55 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        boolean boolean56 = node55.hasMoreThanOneChild();
        node55.setLineno(0);
        boolean boolean59 = node55.hasOneChild();
        com.google.javascript.rhino.jstype.JSType jSType60 = node55.getJSType();
        com.google.javascript.rhino.Node node65 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        node65.removeProp((int) (short) 1);
        com.google.javascript.rhino.Node[] nodeArray68 = new com.google.javascript.rhino.Node[] { node55, node65 };
        com.google.javascript.rhino.Node node71 = new com.google.javascript.rhino.Node((int) (byte) 10, nodeArray68, (int) '4', (int) (byte) -1);
        com.google.javascript.rhino.Node node72 = node47.copyInformationFromForTree(node71);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder73 = node71.new FileLevelJsDocBuilder();
        java.lang.String str77 = node71.toString(false, false, false);
        node38.addChildrenToBack(node71);
        boolean boolean79 = node71.wasEmptyNode();
        com.google.javascript.rhino.Node node84 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        com.google.javascript.rhino.JSDocInfo jSDocInfo85 = null;
        node84.setJSDocInfo(jSDocInfo85);
        boolean boolean87 = node71.isEquivalentTo(node84);
        com.google.javascript.rhino.Node node90 = new com.google.javascript.rhino.Node((int) (byte) 100, node30, node84, 38, 38);
        java.lang.String str91 = closureCodingConvention0.identifyTypeDefAssign(node84);
        com.google.javascript.rhino.Node node92 = node84.getParent();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "goog.abstractMethod" + "'", str7.equals("goog.abstractMethod"));
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNull(jSType19);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertNotNull(nodeArray27);
        org.junit.Assert.assertNotNull(node38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(node42);
        org.junit.Assert.assertNotNull(node47);
        org.junit.Assert.assertNotNull(node55);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertNull(jSType60);
        org.junit.Assert.assertNotNull(node65);
        org.junit.Assert.assertNotNull(nodeArray68);
        org.junit.Assert.assertNotNull(node72);
        org.junit.Assert.assertTrue("'" + str77 + "' != '" + "BITXOR" + "'", str77.equals("BITXOR"));
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
        org.junit.Assert.assertNotNull(node84);
        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + false + "'", boolean87 == false);
        org.junit.Assert.assertNull(str91);
        org.junit.Assert.assertNotNull(node92);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test107");
        com.google.javascript.rhino.Context context0 = new com.google.javascript.rhino.Context();
        com.google.javascript.jscomp.AnonymousFunctionNamingPolicy anonymousFunctionNamingPolicy1 = com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.UNMAPPED;
        context0.removeThreadLocal((java.lang.Object) anonymousFunctionNamingPolicy1);
        java.util.Locale locale3 = context0.getLocale();
        java.lang.String str4 = context0.getImplementationVersion();
        com.google.javascript.rhino.Context context5 = com.google.javascript.rhino.Context.enter(context0);
        java.util.Locale locale6 = context5.getLocale();
        org.junit.Assert.assertTrue("'" + anonymousFunctionNamingPolicy1 + "' != '" + com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.UNMAPPED + "'", anonymousFunctionNamingPolicy1.equals(com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.UNMAPPED));
        org.junit.Assert.assertNotNull(locale3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "@IMPLEMENTATION.VERSION@" + "'", str4.equals("@IMPLEMENTATION.VERSION@"));
        org.junit.Assert.assertNotNull(context5);
        org.junit.Assert.assertNotNull(locale6);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test108");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray2 = new com.google.javascript.jscomp.JSSourceFile[] {};
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray3 = new com.google.javascript.jscomp.JSSourceFile[] {};
        com.google.javascript.jscomp.CompilerOptions compilerOptions4 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions4.devirtualizePrototypeMethods = false;
        compilerOptions4.groupVariableDeclarations = false;
        boolean boolean9 = compilerOptions4.ideMode;
        compilerOptions4.setProcessObjectPropertyString(true);
        compilerOptions4.setDefineToBooleanLiteral("BITXOR", true);
        compilerOptions4.checkControlStructures = true;
        java.util.Map<java.lang.String, com.google.javascript.rhino.Node> strMap17 = compilerOptions4.getTweakReplacements();
        com.google.javascript.jscomp.Result result18 = compiler1.compile(jSSourceFileArray2, jSSourceFileArray3, compilerOptions4);
        com.google.javascript.jscomp.JSError[] jSErrorArray19 = compiler1.getErrors();
        com.google.javascript.jscomp.JSError[] jSErrorArray20 = compiler1.getMessages();
        com.google.javascript.jscomp.JSError[] jSErrorArray21 = compiler1.getWarnings();
        com.google.javascript.rhino.Node node22 = compiler1.getRoot();
        org.junit.Assert.assertNotNull(jSSourceFileArray2);
        org.junit.Assert.assertNotNull(jSSourceFileArray3);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(strMap17);
        org.junit.Assert.assertNotNull(result18);
        org.junit.Assert.assertNotNull(jSErrorArray19);
        org.junit.Assert.assertNotNull(jSErrorArray20);
        org.junit.Assert.assertNotNull(jSErrorArray21);
        org.junit.Assert.assertNotNull(node22);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test109");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString(1, "", (int) ' ', 1);
        node4.setQuotedString();
        org.junit.Assert.assertNotNull(node4);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test110");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray2 = new com.google.javascript.jscomp.JSSourceFile[] {};
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray3 = new com.google.javascript.jscomp.JSSourceFile[] {};
        com.google.javascript.jscomp.CompilerOptions compilerOptions4 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions4.devirtualizePrototypeMethods = false;
        compilerOptions4.groupVariableDeclarations = false;
        boolean boolean9 = compilerOptions4.ideMode;
        compilerOptions4.setProcessObjectPropertyString(true);
        compilerOptions4.setDefineToBooleanLiteral("BITXOR", true);
        compilerOptions4.checkControlStructures = true;
        java.util.Map<java.lang.String, com.google.javascript.rhino.Node> strMap17 = compilerOptions4.getTweakReplacements();
        com.google.javascript.jscomp.Result result18 = compiler1.compile(jSSourceFileArray2, jSSourceFileArray3, compilerOptions4);
        com.google.javascript.jscomp.JSError[] jSErrorArray19 = compiler1.getErrors();
        compiler1.rebuildInputsFromModules();
        org.junit.Assert.assertNotNull(jSSourceFileArray2);
        org.junit.Assert.assertNotNull(jSSourceFileArray3);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(strMap17);
        org.junit.Assert.assertNotNull(result18);
        org.junit.Assert.assertNotNull(jSErrorArray19);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test111");
        com.google.javascript.rhino.Context context0 = new com.google.javascript.rhino.Context();
        com.google.javascript.jscomp.AnonymousFunctionNamingPolicy anonymousFunctionNamingPolicy1 = com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.UNMAPPED;
        context0.removeThreadLocal((java.lang.Object) anonymousFunctionNamingPolicy1);
        java.lang.String str3 = context0.getImplementationVersion();
        java.util.Locale locale4 = context0.getLocale();
        context0.setGeneratingSource(false);
        com.google.javascript.rhino.ErrorReporter errorReporter7 = null;
        try {
            com.google.javascript.rhino.ErrorReporter errorReporter8 = context0.setErrorReporter(errorReporter7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + anonymousFunctionNamingPolicy1 + "' != '" + com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.UNMAPPED + "'", anonymousFunctionNamingPolicy1.equals(com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.UNMAPPED));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "@IMPLEMENTATION.VERSION@" + "'", str3.equals("@IMPLEMENTATION.VERSION@"));
        org.junit.Assert.assertNotNull(locale4);
    }
}

