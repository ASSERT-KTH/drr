import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        com.google.javascript.jscomp.JSModule jSModule1 = new com.google.javascript.jscomp.JSModule("Not declared as a constructor");
        java.nio.charset.Charset charset3 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile4 = com.google.javascript.jscomp.JSSourceFile.fromFile("Not declared as a constructor", charset3);
        java.lang.String str6 = jSSourceFile4.getLine(0);
        jSModule1.add(jSSourceFile4);
        java.util.List<java.lang.String> strList8 = jSModule1.getProvides();
        com.google.javascript.jscomp.JSModule jSModule10 = new com.google.javascript.jscomp.JSModule("Not declared as a constructor");
        java.nio.charset.Charset charset12 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile13 = com.google.javascript.jscomp.JSSourceFile.fromFile("Not declared as a constructor", charset12);
        java.lang.String str15 = jSSourceFile13.getLine(0);
        jSModule10.add(jSSourceFile13);
        com.google.javascript.jscomp.deps.DependencyInfo[] dependencyInfoArray17 = new com.google.javascript.jscomp.deps.DependencyInfo[] { jSModule1, jSModule10 };
        java.util.ArrayList<com.google.javascript.jscomp.deps.DependencyInfo> dependencyInfoList18 = new java.util.ArrayList<com.google.javascript.jscomp.deps.DependencyInfo>();
        boolean boolean19 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.deps.DependencyInfo>) dependencyInfoList18, dependencyInfoArray17);
        com.google.javascript.jscomp.deps.SortedDependencies<com.google.javascript.jscomp.deps.DependencyInfo> dependencyInfoSortedDependencies20 = new com.google.javascript.jscomp.deps.SortedDependencies<com.google.javascript.jscomp.deps.DependencyInfo>((java.util.List<com.google.javascript.jscomp.deps.DependencyInfo>) dependencyInfoList18);
        com.google.javascript.jscomp.JSModule jSModule22 = new com.google.javascript.jscomp.JSModule("Not declared as a constructor");
        java.nio.charset.Charset charset24 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile25 = com.google.javascript.jscomp.JSSourceFile.fromFile("Not declared as a constructor", charset24);
        java.lang.String str27 = jSSourceFile25.getLine(0);
        jSModule22.add(jSSourceFile25);
        java.util.List<java.lang.String> strList29 = jSModule22.getProvides();
        com.google.javascript.jscomp.JSModule jSModule31 = new com.google.javascript.jscomp.JSModule("Not declared as a constructor");
        java.nio.charset.Charset charset33 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile34 = com.google.javascript.jscomp.JSSourceFile.fromFile("Not declared as a constructor", charset33);
        java.lang.String str36 = jSSourceFile34.getLine(0);
        jSModule31.add(jSSourceFile34);
        com.google.javascript.jscomp.deps.DependencyInfo[] dependencyInfoArray38 = new com.google.javascript.jscomp.deps.DependencyInfo[] { jSModule22, jSModule31 };
        java.util.ArrayList<com.google.javascript.jscomp.deps.DependencyInfo> dependencyInfoList39 = new java.util.ArrayList<com.google.javascript.jscomp.deps.DependencyInfo>();
        boolean boolean40 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.deps.DependencyInfo>) dependencyInfoList39, dependencyInfoArray38);
        com.google.javascript.jscomp.deps.SortedDependencies<com.google.javascript.jscomp.deps.DependencyInfo> dependencyInfoSortedDependencies41 = new com.google.javascript.jscomp.deps.SortedDependencies<com.google.javascript.jscomp.deps.DependencyInfo>((java.util.List<com.google.javascript.jscomp.deps.DependencyInfo>) dependencyInfoList39);
        try {
            java.util.List<com.google.javascript.jscomp.deps.DependencyInfo> dependencyInfoList42 = dependencyInfoSortedDependencies20.getSortedDependenciesOf((java.util.List<com.google.javascript.jscomp.deps.DependencyInfo>) dependencyInfoList39);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile4);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNotNull(strList8);
        org.junit.Assert.assertNotNull(jSSourceFile13);
        org.junit.Assert.assertNull(str15);
        org.junit.Assert.assertNotNull(dependencyInfoArray17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(jSSourceFile25);
        org.junit.Assert.assertNull(str27);
        org.junit.Assert.assertNotNull(strList29);
        org.junit.Assert.assertNotNull(jSSourceFile34);
        org.junit.Assert.assertNull(str36);
        org.junit.Assert.assertNotNull(dependencyInfoArray38);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newNumber((double) (short) 100, 0, (int) (byte) -1);
        node3.removeProp((int) (short) 1);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder6 = node3.getJsDocBuilderForNode();
        try {
            node3.setString("hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: NUMBER 100.0 is not a string node");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder6);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        java.lang.String str1 = closureCodingConvention0.getAbstractMethodName();
        java.util.Collection<com.google.javascript.jscomp.CodingConvention.AssertionFunctionSpec> assertionFunctionSpecCollection2 = closureCodingConvention0.getAssertionFunctions();
        java.lang.String str3 = closureCodingConvention0.getExportPropertyFunction();
        boolean boolean5 = closureCodingConvention0.isExported("Unknown class name");
        java.lang.String str6 = closureCodingConvention0.getAbstractMethodName();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "goog.abstractMethod" + "'", str1.equals("goog.abstractMethod"));
        org.junit.Assert.assertNotNull(assertionFunctionSpecCollection2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "goog.exportProperty" + "'", str3.equals("goog.exportProperty"));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "goog.abstractMethod" + "'", str6.equals("goog.abstractMethod"));
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        java.io.PrintStream printStream2 = null;
        com.google.javascript.jscomp.Compiler compiler3 = new com.google.javascript.jscomp.Compiler(printStream2);
        com.google.javascript.jscomp.Scope scope4 = compiler3.getTopScope();
        com.google.javascript.jscomp.PerformanceTracker performanceTracker5 = null;
        compiler3.tracker = performanceTracker5;
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter7 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler3);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile10 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "NUMBER 100.0");
        com.google.javascript.rhino.Node node11 = compiler3.parse(jSSourceFile10);
        com.google.javascript.jscomp.JSModule jSModule13 = new com.google.javascript.jscomp.JSModule("goog.exportSymbol");
        java.lang.String str14 = jSModule13.toString();
        java.lang.String str15 = compiler3.toSource(jSModule13);
        try {
            java.lang.String[] strArray16 = compiler1.toSourceArray(jSModule13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(scope4);
        org.junit.Assert.assertNotNull(jSSourceFile10);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "goog.exportSymbol" + "'", str14.equals("goog.exportSymbol"));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newNumber((double) (-1.0f), 0, 48);
        com.google.javascript.rhino.ErrorReporter errorReporter4 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter4);
        com.google.javascript.rhino.jstype.JSType jSType7 = jSTypeRegistry5.getType("hi!");
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newNumber((double) (short) 0);
        com.google.javascript.rhino.ErrorReporter errorReporter11 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry12 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter11);
        com.google.javascript.rhino.jstype.JSType jSType13 = null;
        com.google.javascript.rhino.jstype.JSType jSType15 = jSTypeRegistry12.getGreatestSubtypeWithProperty(jSType13, "");
        com.google.javascript.rhino.jstype.JSType jSType17 = jSType15.findPropertyType("");
        com.google.javascript.rhino.jstype.ObjectType objectType18 = jSType15.dereference();
        boolean boolean19 = objectType18.isNumber();
        com.google.javascript.rhino.ErrorReporter errorReporter20 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry21 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter20);
        com.google.javascript.rhino.jstype.JSType jSType22 = null;
        com.google.javascript.rhino.jstype.JSType jSType24 = jSTypeRegistry21.getGreatestSubtypeWithProperty(jSType22, "");
        com.google.javascript.rhino.jstype.JSType jSType26 = jSType24.findPropertyType("");
        com.google.javascript.rhino.jstype.ObjectType objectType27 = jSType24.dereference();
        boolean boolean28 = objectType27.isNumber();
        com.google.javascript.rhino.jstype.JSType jSType29 = objectType18.getGreatestSubtype((com.google.javascript.rhino.jstype.JSType) objectType27);
        com.google.javascript.rhino.jstype.ObjectType objectType30 = jSTypeRegistry5.createObjectType("Not declared as a constructor", node10, objectType27);
        boolean boolean31 = node3.checkTreeEqualsSilent(node10);
        com.google.javascript.rhino.JSDocInfo jSDocInfo32 = null;
        node3.setJSDocInfo(jSDocInfo32);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNull(jSType7);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(jSType15);
        org.junit.Assert.assertNotNull(jSType17);
        org.junit.Assert.assertNotNull(objectType18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(jSType24);
        org.junit.Assert.assertNotNull(jSType26);
        org.junit.Assert.assertNotNull(objectType27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(jSType29);
        org.junit.Assert.assertNotNull(objectType30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        com.google.javascript.rhino.jstype.JSType jSType3 = jSTypeRegistry1.getType("hi!");
        com.google.javascript.rhino.ErrorReporter errorReporter4 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter4);
        com.google.javascript.rhino.jstype.JSType jSType6 = null;
        com.google.javascript.rhino.jstype.JSType jSType8 = jSTypeRegistry5.getGreatestSubtypeWithProperty(jSType6, "");
        com.google.javascript.rhino.jstype.JSType jSType10 = jSType8.findPropertyType("");
        boolean boolean11 = jSType10.isArrayType();
        boolean boolean12 = jSType10.isNominalType();
        com.google.javascript.rhino.ErrorReporter errorReporter13 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry14 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter13);
        com.google.javascript.rhino.jstype.JSType jSType15 = null;
        com.google.javascript.rhino.jstype.JSType jSType17 = jSTypeRegistry14.getGreatestSubtypeWithProperty(jSType15, "");
        com.google.javascript.rhino.jstype.JSType jSType19 = jSType17.findPropertyType("");
        com.google.javascript.rhino.jstype.ObjectType objectType20 = jSType17.dereference();
        com.google.javascript.rhino.ErrorReporter errorReporter21 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry22 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter21);
        com.google.javascript.rhino.jstype.JSType jSType23 = null;
        com.google.javascript.rhino.jstype.JSType jSType25 = jSTypeRegistry22.getGreatestSubtypeWithProperty(jSType23, "");
        com.google.javascript.rhino.jstype.JSType jSType27 = jSType25.findPropertyType("");
        com.google.javascript.rhino.jstype.ObjectType objectType28 = jSType25.dereference();
        com.google.javascript.rhino.ErrorReporter errorReporter29 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry30 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter29);
        com.google.javascript.rhino.jstype.JSType jSType31 = null;
        com.google.javascript.rhino.jstype.JSType jSType33 = jSTypeRegistry30.getGreatestSubtypeWithProperty(jSType31, "");
        com.google.javascript.rhino.jstype.JSType jSType35 = jSType33.findPropertyType("");
        com.google.javascript.rhino.jstype.ObjectType objectType36 = jSType33.dereference();
        boolean boolean37 = objectType36.isOrdinaryFunction();
        boolean boolean38 = objectType36.isUnknownType();
        boolean boolean39 = objectType36.matchesUint32Context();
        com.google.javascript.rhino.jstype.JSType.TypePair typePair40 = objectType28.getTypesUnderShallowInequality((com.google.javascript.rhino.jstype.JSType) objectType36);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray41 = new com.google.javascript.rhino.jstype.JSType[] { objectType20, objectType28 };
        com.google.javascript.rhino.jstype.FunctionType functionType42 = jSTypeRegistry1.createFunctionType(jSType10, jSTypeArray41);
        boolean boolean43 = functionType42.isReturnTypeInferred();
        try {
            com.google.javascript.rhino.jstype.JSType jSType45 = functionType42.getTopMostDefiningType("0");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNull(jSType3);
        org.junit.Assert.assertNotNull(jSType8);
        org.junit.Assert.assertNotNull(jSType10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(jSType17);
        org.junit.Assert.assertNotNull(jSType19);
        org.junit.Assert.assertNotNull(objectType20);
        org.junit.Assert.assertNotNull(jSType25);
        org.junit.Assert.assertNotNull(jSType27);
        org.junit.Assert.assertNotNull(objectType28);
        org.junit.Assert.assertNotNull(jSType33);
        org.junit.Assert.assertNotNull(jSType35);
        org.junit.Assert.assertNotNull(objectType36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertNotNull(typePair40);
        org.junit.Assert.assertNotNull(jSTypeArray41);
        org.junit.Assert.assertNotNull(functionType42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode4 = new com.google.javascript.rhino.ScriptOrFnNode((int) (short) 0, (int) ' ', 33);
        int int5 = scriptOrFnNode4.getEncodedSourceStart();
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newNumber((double) (short) 100, 0, (int) (byte) -1);
        java.lang.String str10 = node9.toString();
        java.lang.String str11 = closureCodingConvention0.extractClassNameIfRequire((com.google.javascript.rhino.Node) scriptOrFnNode4, node9);
        node9.setLineno(0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "NUMBER 100.0" + "'", str10.equals("NUMBER 100.0"));
        org.junit.Assert.assertNull(str11);
    }

//    @Test
//    public void test008() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test008");
//        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
//        com.google.javascript.rhino.jstype.JSType jSType3 = jSTypeRegistry1.getType("hi!");
//        com.google.javascript.rhino.ErrorReporter errorReporter4 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter4);
//        com.google.javascript.rhino.jstype.JSType jSType6 = null;
//        com.google.javascript.rhino.jstype.JSType jSType8 = jSTypeRegistry5.getGreatestSubtypeWithProperty(jSType6, "");
//        com.google.javascript.rhino.jstype.JSType jSType10 = jSType8.findPropertyType("");
//        boolean boolean11 = jSType10.isArrayType();
//        boolean boolean12 = jSType10.isNominalType();
//        com.google.javascript.rhino.ErrorReporter errorReporter13 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry14 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter13);
//        com.google.javascript.rhino.jstype.JSType jSType15 = null;
//        com.google.javascript.rhino.jstype.JSType jSType17 = jSTypeRegistry14.getGreatestSubtypeWithProperty(jSType15, "");
//        com.google.javascript.rhino.jstype.JSType jSType19 = jSType17.findPropertyType("");
//        com.google.javascript.rhino.jstype.ObjectType objectType20 = jSType17.dereference();
//        com.google.javascript.rhino.ErrorReporter errorReporter21 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry22 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter21);
//        com.google.javascript.rhino.jstype.JSType jSType23 = null;
//        com.google.javascript.rhino.jstype.JSType jSType25 = jSTypeRegistry22.getGreatestSubtypeWithProperty(jSType23, "");
//        com.google.javascript.rhino.jstype.JSType jSType27 = jSType25.findPropertyType("");
//        com.google.javascript.rhino.jstype.ObjectType objectType28 = jSType25.dereference();
//        com.google.javascript.rhino.ErrorReporter errorReporter29 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry30 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter29);
//        com.google.javascript.rhino.jstype.JSType jSType31 = null;
//        com.google.javascript.rhino.jstype.JSType jSType33 = jSTypeRegistry30.getGreatestSubtypeWithProperty(jSType31, "");
//        com.google.javascript.rhino.jstype.JSType jSType35 = jSType33.findPropertyType("");
//        com.google.javascript.rhino.jstype.ObjectType objectType36 = jSType33.dereference();
//        boolean boolean37 = objectType36.isOrdinaryFunction();
//        boolean boolean38 = objectType36.isUnknownType();
//        boolean boolean39 = objectType36.matchesUint32Context();
//        com.google.javascript.rhino.jstype.JSType.TypePair typePair40 = objectType28.getTypesUnderShallowInequality((com.google.javascript.rhino.jstype.JSType) objectType36);
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray41 = new com.google.javascript.rhino.jstype.JSType[] { objectType20, objectType28 };
//        com.google.javascript.rhino.jstype.FunctionType functionType42 = jSTypeRegistry1.createFunctionType(jSType10, jSTypeArray41);
//        java.util.Set set43 = functionType42.getOwnPropertyNames();
//        com.google.javascript.rhino.ErrorReporter errorReporter44 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry45 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter44);
//        com.google.javascript.rhino.jstype.JSType jSType47 = jSTypeRegistry45.getType("hi!");
//        com.google.javascript.rhino.ErrorReporter errorReporter48 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry49 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter48);
//        com.google.javascript.rhino.jstype.JSType jSType50 = null;
//        com.google.javascript.rhino.jstype.JSType jSType52 = jSTypeRegistry49.getGreatestSubtypeWithProperty(jSType50, "");
//        com.google.javascript.rhino.jstype.JSType jSType54 = jSType52.findPropertyType("");
//        boolean boolean55 = jSType54.isArrayType();
//        boolean boolean56 = jSType54.isNominalType();
//        com.google.javascript.rhino.ErrorReporter errorReporter57 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry58 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter57);
//        com.google.javascript.rhino.jstype.JSType jSType59 = null;
//        com.google.javascript.rhino.jstype.JSType jSType61 = jSTypeRegistry58.getGreatestSubtypeWithProperty(jSType59, "");
//        com.google.javascript.rhino.jstype.JSType jSType63 = jSType61.findPropertyType("");
//        com.google.javascript.rhino.jstype.ObjectType objectType64 = jSType61.dereference();
//        com.google.javascript.rhino.ErrorReporter errorReporter65 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry66 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter65);
//        com.google.javascript.rhino.jstype.JSType jSType67 = null;
//        com.google.javascript.rhino.jstype.JSType jSType69 = jSTypeRegistry66.getGreatestSubtypeWithProperty(jSType67, "");
//        com.google.javascript.rhino.jstype.JSType jSType71 = jSType69.findPropertyType("");
//        com.google.javascript.rhino.jstype.ObjectType objectType72 = jSType69.dereference();
//        com.google.javascript.rhino.ErrorReporter errorReporter73 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry74 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter73);
//        com.google.javascript.rhino.jstype.JSType jSType75 = null;
//        com.google.javascript.rhino.jstype.JSType jSType77 = jSTypeRegistry74.getGreatestSubtypeWithProperty(jSType75, "");
//        com.google.javascript.rhino.jstype.JSType jSType79 = jSType77.findPropertyType("");
//        com.google.javascript.rhino.jstype.ObjectType objectType80 = jSType77.dereference();
//        boolean boolean81 = objectType80.isOrdinaryFunction();
//        boolean boolean82 = objectType80.isUnknownType();
//        boolean boolean83 = objectType80.matchesUint32Context();
//        com.google.javascript.rhino.jstype.JSType.TypePair typePair84 = objectType72.getTypesUnderShallowInequality((com.google.javascript.rhino.jstype.JSType) objectType80);
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray85 = new com.google.javascript.rhino.jstype.JSType[] { objectType64, objectType72 };
//        com.google.javascript.rhino.jstype.FunctionType functionType86 = jSTypeRegistry45.createFunctionType(jSType54, jSTypeArray85);
//        boolean boolean87 = functionType42.hasEqualCallType(functionType86);
//        boolean boolean88 = functionType42.isNativeObjectType();
//        java.lang.String str89 = functionType42.toDebugHashCodeString();
//        com.google.javascript.rhino.Node node90 = functionType42.getSource();
//        com.google.javascript.rhino.JSDocInfo jSDocInfo92 = null;
//        functionType42.setPropertyJSDocInfo("function (function (this:me, {977034666}): me, function (this:me, {2129390726}): me): function (this:me, {1973436143}): me", jSDocInfo92, false);
//        org.junit.Assert.assertNull(jSType3);
//        org.junit.Assert.assertNotNull(jSType8);
//        org.junit.Assert.assertNotNull(jSType10);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertNotNull(jSType17);
//        org.junit.Assert.assertNotNull(jSType19);
//        org.junit.Assert.assertNotNull(objectType20);
//        org.junit.Assert.assertNotNull(jSType25);
//        org.junit.Assert.assertNotNull(jSType27);
//        org.junit.Assert.assertNotNull(objectType28);
//        org.junit.Assert.assertNotNull(jSType33);
//        org.junit.Assert.assertNotNull(jSType35);
//        org.junit.Assert.assertNotNull(objectType36);
//        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
//        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
//        org.junit.Assert.assertNotNull(typePair40);
//        org.junit.Assert.assertNotNull(jSTypeArray41);
//        org.junit.Assert.assertNotNull(functionType42);
//        org.junit.Assert.assertNotNull(set43);
//        org.junit.Assert.assertNull(jSType47);
//        org.junit.Assert.assertNotNull(jSType52);
//        org.junit.Assert.assertNotNull(jSType54);
//        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
//        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
//        org.junit.Assert.assertNotNull(jSType61);
//        org.junit.Assert.assertNotNull(jSType63);
//        org.junit.Assert.assertNotNull(objectType64);
//        org.junit.Assert.assertNotNull(jSType69);
//        org.junit.Assert.assertNotNull(jSType71);
//        org.junit.Assert.assertNotNull(objectType72);
//        org.junit.Assert.assertNotNull(jSType77);
//        org.junit.Assert.assertNotNull(jSType79);
//        org.junit.Assert.assertNotNull(objectType80);
//        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + false + "'", boolean81 == false);
//        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
//        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + true + "'", boolean83 == true);
//        org.junit.Assert.assertNotNull(typePair84);
//        org.junit.Assert.assertNotNull(jSTypeArray85);
//        org.junit.Assert.assertNotNull(functionType86);
//        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + false + "'", boolean87 == false);
//        org.junit.Assert.assertTrue("'" + boolean88 + "' != '" + false + "'", boolean88 == false);
//        org.junit.Assert.assertTrue("'" + str89 + "' != '" + "function (function (this:me, {1095461187}): me, function (this:me, {134451592}): me): function (this:me, {1948036348}): me" + "'", str89.equals("function (function (this:me, {1095461187}): me, function (this:me, {134451592}): me): function (this:me, {1948036348}): me"));
//        org.junit.Assert.assertNull(node90);
//    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        com.google.javascript.jscomp.SourceAst sourceAst0 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(sourceAst0, "goog.exportSymbol", true);
        java.lang.String str4 = compilerInput3.getName();
        com.google.javascript.jscomp.JSModule jSModule6 = new com.google.javascript.jscomp.JSModule("goog.exportSymbol");
        compilerInput3.setModule(jSModule6);
        com.google.javascript.jscomp.SourceAst sourceAst8 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput11 = new com.google.javascript.jscomp.CompilerInput(sourceAst8, "goog.exportSymbol", true);
        java.lang.String str12 = compilerInput11.getName();
        com.google.javascript.jscomp.JSModule jSModule14 = new com.google.javascript.jscomp.JSModule("goog.exportSymbol");
        com.google.javascript.jscomp.SourceAst sourceAst15 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput18 = new com.google.javascript.jscomp.CompilerInput(sourceAst15, "goog.exportSymbol", true);
        com.google.javascript.jscomp.JSModule jSModule20 = new com.google.javascript.jscomp.JSModule("Not declared as a constructor");
        java.nio.charset.Charset charset22 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile23 = com.google.javascript.jscomp.JSSourceFile.fromFile("Not declared as a constructor", charset22);
        java.lang.String str25 = jSSourceFile23.getLine(0);
        jSModule20.add(jSSourceFile23);
        com.google.javascript.jscomp.SourceAst sourceAst27 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput30 = new com.google.javascript.jscomp.CompilerInput(sourceAst27, "goog.exportSymbol", true);
        java.lang.String str31 = compilerInput30.getName();
        com.google.javascript.jscomp.JSModule jSModule33 = new com.google.javascript.jscomp.JSModule("goog.exportSymbol");
        compilerInput30.setModule(jSModule33);
        com.google.javascript.jscomp.JSModule jSModule36 = new com.google.javascript.jscomp.JSModule("goog.exportSymbol");
        java.lang.String str37 = jSModule36.toString();
        com.google.javascript.jscomp.JSModule[] jSModuleArray38 = new com.google.javascript.jscomp.JSModule[] {};
        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList39 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
        boolean boolean40 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList39, jSModuleArray38);
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph41 = new com.google.javascript.jscomp.JSModuleGraph((java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList39);
        com.google.javascript.jscomp.JSModule jSModule43 = new com.google.javascript.jscomp.JSModule("Not declared as a constructor");
        java.nio.charset.Charset charset45 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile46 = com.google.javascript.jscomp.JSSourceFile.fromFile("Not declared as a constructor", charset45);
        java.lang.String str48 = jSSourceFile46.getLine(0);
        jSModule43.add(jSSourceFile46);
        com.google.javascript.jscomp.JSModule jSModule51 = new com.google.javascript.jscomp.JSModule("Not declared as a constructor");
        java.nio.charset.Charset charset53 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile54 = com.google.javascript.jscomp.JSSourceFile.fromFile("Not declared as a constructor", charset53);
        java.lang.String str56 = jSSourceFile54.getLine(0);
        jSModule51.add(jSSourceFile54);
        java.util.List<java.lang.String> strList58 = jSModule51.getProvides();
        com.google.javascript.jscomp.JSModule jSModule59 = jSModuleGraph41.getDeepestCommonDependencyInclusive(jSModule43, jSModule51);
        com.google.javascript.jscomp.JSModule jSModule61 = new com.google.javascript.jscomp.JSModule("Not declared as a constructor");
        com.google.javascript.jscomp.JSModule jSModule63 = new com.google.javascript.jscomp.JSModule("goog.exportSymbol");
        com.google.javascript.jscomp.SourceAst sourceAst64 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput67 = new com.google.javascript.jscomp.CompilerInput(sourceAst64, "goog.exportSymbol", true);
        com.google.javascript.jscomp.SourceAst sourceAst68 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput71 = new com.google.javascript.jscomp.CompilerInput(sourceAst68, "goog.exportSymbol", true);
        java.lang.String str72 = compilerInput71.getName();
        com.google.javascript.jscomp.JSModule jSModule74 = new com.google.javascript.jscomp.JSModule("goog.exportSymbol");
        compilerInput71.setModule(jSModule74);
        com.google.javascript.jscomp.deps.DependencyInfo[] dependencyInfoArray76 = new com.google.javascript.jscomp.deps.DependencyInfo[] { compilerInput3, compilerInput11, jSModule14, compilerInput18, jSModule20, compilerInput30, jSModule36, jSModule43, jSModule61, jSModule63, compilerInput67, compilerInput71 };
        java.util.ArrayList<com.google.javascript.jscomp.deps.DependencyInfo> dependencyInfoList77 = new java.util.ArrayList<com.google.javascript.jscomp.deps.DependencyInfo>();
        boolean boolean78 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.deps.DependencyInfo>) dependencyInfoList77, dependencyInfoArray76);
        try {
            com.google.javascript.jscomp.deps.SortedDependencies<com.google.javascript.jscomp.deps.DependencyInfo> dependencyInfoSortedDependencies79 = new com.google.javascript.jscomp.deps.SortedDependencies<com.google.javascript.jscomp.deps.DependencyInfo>((java.util.List<com.google.javascript.jscomp.deps.DependencyInfo>) dependencyInfoList77);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Expected setErrorManager to be called first");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "goog.exportSymbol" + "'", str4.equals("goog.exportSymbol"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "goog.exportSymbol" + "'", str12.equals("goog.exportSymbol"));
        org.junit.Assert.assertNotNull(jSSourceFile23);
        org.junit.Assert.assertNull(str25);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "goog.exportSymbol" + "'", str31.equals("goog.exportSymbol"));
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "goog.exportSymbol" + "'", str37.equals("goog.exportSymbol"));
        org.junit.Assert.assertNotNull(jSModuleArray38);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(jSSourceFile46);
        org.junit.Assert.assertNull(str48);
        org.junit.Assert.assertNotNull(jSSourceFile54);
        org.junit.Assert.assertNull(str56);
        org.junit.Assert.assertNotNull(strList58);
        org.junit.Assert.assertNull(jSModule59);
        org.junit.Assert.assertTrue("'" + str72 + "' != '" + "goog.exportSymbol" + "'", str72.equals("goog.exportSymbol"));
        org.junit.Assert.assertNotNull(dependencyInfoArray76);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + true + "'", boolean78 == true);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        com.google.javascript.rhino.jstype.JSType jSType2 = null;
        com.google.javascript.rhino.jstype.JSType jSType4 = jSTypeRegistry1.getGreatestSubtypeWithProperty(jSType2, "");
        com.google.javascript.rhino.jstype.JSType jSType6 = jSType4.findPropertyType("");
        com.google.javascript.rhino.jstype.ObjectType objectType7 = jSType4.dereference();
        com.google.javascript.rhino.ErrorReporter errorReporter8 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry9 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter8);
        com.google.javascript.rhino.jstype.JSType jSType10 = null;
        com.google.javascript.rhino.jstype.JSType jSType12 = jSTypeRegistry9.getGreatestSubtypeWithProperty(jSType10, "");
        com.google.javascript.rhino.jstype.JSType jSType14 = jSType12.findPropertyType("");
        com.google.javascript.rhino.jstype.ObjectType objectType15 = jSType12.dereference();
        boolean boolean16 = objectType15.isOrdinaryFunction();
        boolean boolean17 = objectType15.isUnknownType();
        boolean boolean18 = objectType15.matchesUint32Context();
        com.google.javascript.rhino.jstype.JSType.TypePair typePair19 = objectType7.getTypesUnderShallowInequality((com.google.javascript.rhino.jstype.JSType) objectType15);
        boolean boolean20 = objectType15.isRecordType();
        boolean boolean21 = objectType15.isNominalType();
        org.junit.Assert.assertNotNull(jSType4);
        org.junit.Assert.assertNotNull(jSType6);
        org.junit.Assert.assertNotNull(objectType7);
        org.junit.Assert.assertNotNull(jSType12);
        org.junit.Assert.assertNotNull(jSType14);
        org.junit.Assert.assertNotNull(objectType15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(typePair19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        com.google.javascript.rhino.Context context0 = null;
        com.google.javascript.rhino.Context context1 = com.google.javascript.rhino.Context.enter(context0);
        com.google.javascript.rhino.Context context2 = com.google.javascript.rhino.Context.enter(context0);
        boolean boolean3 = context2.isGeneratingDebug();
        com.google.javascript.rhino.ErrorReporter errorReporter4 = context2.getErrorReporter();
        boolean boolean5 = context2.isGeneratingSource();
        int int6 = context2.getLanguageVersion();
        boolean boolean7 = context2.isGeneratingDebugChanged();
        org.junit.Assert.assertNotNull(context1);
        org.junit.Assert.assertNotNull(context2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(errorReporter4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        com.google.javascript.rhino.EcmaError ecmaError6 = com.google.javascript.rhino.ScriptRuntime.constructError("", "Named type with empty name component", "Not declared as a constructor", (int) 'a', "-1", (int) (byte) 1);
        java.lang.String str7 = ecmaError6.getErrorMessage();
        java.lang.String str8 = ecmaError6.details();
        org.junit.Assert.assertNotNull(ecmaError6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Named type with empty name component" + "'", str7.equals("Named type with empty name component"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + ": Named type with empty name component" + "'", str8.equals(": Named type with empty name component"));
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        com.google.javascript.rhino.Context context0 = null;
        com.google.javascript.rhino.Context context1 = com.google.javascript.rhino.Context.enter(context0);
        com.google.javascript.rhino.Context context2 = com.google.javascript.rhino.Context.enter(context0);
        boolean boolean3 = context2.isGeneratingDebug();
        context2.setGeneratingSource(true);
        int int6 = context2.getOptimizationLevel();
        context2.setGeneratingSource(false);
        org.junit.Assert.assertNotNull(context1);
        org.junit.Assert.assertNotNull(context2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.U2U_FUNCTION_TYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.U2U_FUNCTION_TYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.U2U_FUNCTION_TYPE));
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        com.google.javascript.rhino.jstype.JSType jSType3 = jSTypeRegistry1.getType("hi!");
        com.google.javascript.rhino.ErrorReporter errorReporter4 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter4);
        com.google.javascript.rhino.jstype.JSType jSType6 = null;
        com.google.javascript.rhino.jstype.JSType jSType8 = jSTypeRegistry5.getGreatestSubtypeWithProperty(jSType6, "");
        com.google.javascript.rhino.jstype.JSType jSType10 = jSType8.findPropertyType("");
        com.google.javascript.rhino.jstype.ObjectType objectType11 = jSType8.dereference();
        com.google.javascript.rhino.ErrorReporter errorReporter12 = null;
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope13 = null;
        com.google.javascript.rhino.jstype.JSType jSType14 = jSType8.forceResolve(errorReporter12, jSTypeStaticScope13);
        com.google.javascript.rhino.jstype.JSType jSType15 = jSTypeRegistry1.createOptionalNullableType(jSType8);
        jSTypeRegistry1.resetForTypeCheck();
        com.google.javascript.rhino.ErrorReporter errorReporter17 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry18 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter17);
        com.google.javascript.rhino.jstype.JSType jSType20 = jSTypeRegistry18.getType("hi!");
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newNumber((double) (short) 0);
        com.google.javascript.rhino.ErrorReporter errorReporter24 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry25 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter24);
        com.google.javascript.rhino.jstype.JSType jSType26 = null;
        com.google.javascript.rhino.jstype.JSType jSType28 = jSTypeRegistry25.getGreatestSubtypeWithProperty(jSType26, "");
        com.google.javascript.rhino.jstype.JSType jSType30 = jSType28.findPropertyType("");
        com.google.javascript.rhino.jstype.ObjectType objectType31 = jSType28.dereference();
        boolean boolean32 = objectType31.isNumber();
        com.google.javascript.rhino.ErrorReporter errorReporter33 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry34 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter33);
        com.google.javascript.rhino.jstype.JSType jSType35 = null;
        com.google.javascript.rhino.jstype.JSType jSType37 = jSTypeRegistry34.getGreatestSubtypeWithProperty(jSType35, "");
        com.google.javascript.rhino.jstype.JSType jSType39 = jSType37.findPropertyType("");
        com.google.javascript.rhino.jstype.ObjectType objectType40 = jSType37.dereference();
        boolean boolean41 = objectType40.isNumber();
        com.google.javascript.rhino.jstype.JSType jSType42 = objectType31.getGreatestSubtype((com.google.javascript.rhino.jstype.JSType) objectType40);
        com.google.javascript.rhino.jstype.ObjectType objectType43 = jSTypeRegistry18.createObjectType("Not declared as a constructor", node23, objectType40);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray44 = new com.google.javascript.rhino.jstype.JSType[] { objectType43 };
        com.google.javascript.rhino.Node node45 = jSTypeRegistry1.createOptionalParameters(jSTypeArray44);
        jSTypeRegistry1.setLastGeneration(false);
        org.junit.Assert.assertNull(jSType3);
        org.junit.Assert.assertNotNull(jSType8);
        org.junit.Assert.assertNotNull(jSType10);
        org.junit.Assert.assertNotNull(objectType11);
        org.junit.Assert.assertNotNull(jSType14);
        org.junit.Assert.assertNotNull(jSType15);
        org.junit.Assert.assertNull(jSType20);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(jSType28);
        org.junit.Assert.assertNotNull(jSType30);
        org.junit.Assert.assertNotNull(objectType31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNotNull(jSType37);
        org.junit.Assert.assertNotNull(jSType39);
        org.junit.Assert.assertNotNull(objectType40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
        org.junit.Assert.assertNotNull(jSType42);
        org.junit.Assert.assertNotNull(objectType43);
        org.junit.Assert.assertNotNull(jSTypeArray44);
        org.junit.Assert.assertNotNull(node45);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        com.google.javascript.jscomp.CompilerOptions.TracerMode tracerMode0 = com.google.javascript.jscomp.CompilerOptions.TracerMode.OFF;
        org.junit.Assert.assertTrue("'" + tracerMode0 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TracerMode.OFF + "'", tracerMode0.equals(com.google.javascript.jscomp.CompilerOptions.TracerMode.OFF));
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.Scope scope2 = compiler1.getTopScope();
        com.google.javascript.jscomp.Scope scope3 = compiler1.getTopScope();
        com.google.javascript.jscomp.JSModule[] jSModuleArray4 = new com.google.javascript.jscomp.JSModule[] {};
        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList5 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
        boolean boolean6 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList5, jSModuleArray4);
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph7 = new com.google.javascript.jscomp.JSModuleGraph((java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList5);
        com.google.javascript.jscomp.JSModule jSModule9 = new com.google.javascript.jscomp.JSModule("Not declared as a constructor");
        java.nio.charset.Charset charset11 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile12 = com.google.javascript.jscomp.JSSourceFile.fromFile("Not declared as a constructor", charset11);
        java.lang.String str14 = jSSourceFile12.getLine(0);
        jSModule9.add(jSSourceFile12);
        com.google.javascript.jscomp.JSModule jSModule17 = new com.google.javascript.jscomp.JSModule("Not declared as a constructor");
        java.nio.charset.Charset charset19 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile20 = com.google.javascript.jscomp.JSSourceFile.fromFile("Not declared as a constructor", charset19);
        java.lang.String str22 = jSSourceFile20.getLine(0);
        jSModule17.add(jSSourceFile20);
        java.util.List<java.lang.String> strList24 = jSModule17.getProvides();
        com.google.javascript.jscomp.JSModule jSModule25 = jSModuleGraph7.getDeepestCommonDependencyInclusive(jSModule9, jSModule17);
        try {
            java.lang.String str26 = compiler1.toSource(jSModule9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(scope2);
        org.junit.Assert.assertNull(scope3);
        org.junit.Assert.assertNotNull(jSModuleArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(jSSourceFile12);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNotNull(jSSourceFile20);
        org.junit.Assert.assertNull(str22);
        org.junit.Assert.assertNotNull(strList24);
        org.junit.Assert.assertNull(jSModule25);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        com.google.javascript.rhino.jstype.JSType jSType3 = jSTypeRegistry1.getType("hi!");
        com.google.javascript.rhino.ErrorReporter errorReporter4 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter4);
        com.google.javascript.rhino.jstype.JSType jSType6 = null;
        com.google.javascript.rhino.jstype.JSType jSType8 = jSTypeRegistry5.getGreatestSubtypeWithProperty(jSType6, "");
        com.google.javascript.rhino.jstype.JSType jSType10 = jSType8.findPropertyType("");
        boolean boolean11 = jSType10.isArrayType();
        boolean boolean12 = jSType10.isNominalType();
        com.google.javascript.rhino.ErrorReporter errorReporter13 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry14 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter13);
        com.google.javascript.rhino.jstype.JSType jSType15 = null;
        com.google.javascript.rhino.jstype.JSType jSType17 = jSTypeRegistry14.getGreatestSubtypeWithProperty(jSType15, "");
        com.google.javascript.rhino.jstype.JSType jSType19 = jSType17.findPropertyType("");
        com.google.javascript.rhino.jstype.ObjectType objectType20 = jSType17.dereference();
        com.google.javascript.rhino.ErrorReporter errorReporter21 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry22 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter21);
        com.google.javascript.rhino.jstype.JSType jSType23 = null;
        com.google.javascript.rhino.jstype.JSType jSType25 = jSTypeRegistry22.getGreatestSubtypeWithProperty(jSType23, "");
        com.google.javascript.rhino.jstype.JSType jSType27 = jSType25.findPropertyType("");
        com.google.javascript.rhino.jstype.ObjectType objectType28 = jSType25.dereference();
        com.google.javascript.rhino.ErrorReporter errorReporter29 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry30 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter29);
        com.google.javascript.rhino.jstype.JSType jSType31 = null;
        com.google.javascript.rhino.jstype.JSType jSType33 = jSTypeRegistry30.getGreatestSubtypeWithProperty(jSType31, "");
        com.google.javascript.rhino.jstype.JSType jSType35 = jSType33.findPropertyType("");
        com.google.javascript.rhino.jstype.ObjectType objectType36 = jSType33.dereference();
        boolean boolean37 = objectType36.isOrdinaryFunction();
        boolean boolean38 = objectType36.isUnknownType();
        boolean boolean39 = objectType36.matchesUint32Context();
        com.google.javascript.rhino.jstype.JSType.TypePair typePair40 = objectType28.getTypesUnderShallowInequality((com.google.javascript.rhino.jstype.JSType) objectType36);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray41 = new com.google.javascript.rhino.jstype.JSType[] { objectType20, objectType28 };
        com.google.javascript.rhino.jstype.FunctionType functionType42 = jSTypeRegistry1.createFunctionType(jSType10, jSTypeArray41);
        boolean boolean43 = functionType42.isInterface();
        com.google.javascript.rhino.jstype.FunctionPrototypeType functionPrototypeType44 = null;
        boolean boolean45 = functionType42.setPrototype(functionPrototypeType44);
        com.google.javascript.rhino.jstype.JSType jSType47 = functionType42.findPropertyType("-1");
        com.google.javascript.rhino.ErrorReporter errorReporter48 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry49 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter48);
        com.google.javascript.rhino.jstype.JSType jSType51 = jSTypeRegistry49.getType("hi!");
        com.google.javascript.rhino.ErrorReporter errorReporter52 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry53 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter52);
        com.google.javascript.rhino.jstype.JSType jSType54 = null;
        com.google.javascript.rhino.jstype.JSType jSType56 = jSTypeRegistry53.getGreatestSubtypeWithProperty(jSType54, "");
        com.google.javascript.rhino.jstype.JSType jSType58 = jSType56.findPropertyType("");
        boolean boolean59 = jSType58.isArrayType();
        boolean boolean60 = jSType58.isNominalType();
        com.google.javascript.rhino.ErrorReporter errorReporter61 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry62 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter61);
        com.google.javascript.rhino.jstype.JSType jSType63 = null;
        com.google.javascript.rhino.jstype.JSType jSType65 = jSTypeRegistry62.getGreatestSubtypeWithProperty(jSType63, "");
        com.google.javascript.rhino.jstype.JSType jSType67 = jSType65.findPropertyType("");
        com.google.javascript.rhino.jstype.ObjectType objectType68 = jSType65.dereference();
        com.google.javascript.rhino.ErrorReporter errorReporter69 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry70 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter69);
        com.google.javascript.rhino.jstype.JSType jSType71 = null;
        com.google.javascript.rhino.jstype.JSType jSType73 = jSTypeRegistry70.getGreatestSubtypeWithProperty(jSType71, "");
        com.google.javascript.rhino.jstype.JSType jSType75 = jSType73.findPropertyType("");
        com.google.javascript.rhino.jstype.ObjectType objectType76 = jSType73.dereference();
        com.google.javascript.rhino.ErrorReporter errorReporter77 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry78 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter77);
        com.google.javascript.rhino.jstype.JSType jSType79 = null;
        com.google.javascript.rhino.jstype.JSType jSType81 = jSTypeRegistry78.getGreatestSubtypeWithProperty(jSType79, "");
        com.google.javascript.rhino.jstype.JSType jSType83 = jSType81.findPropertyType("");
        com.google.javascript.rhino.jstype.ObjectType objectType84 = jSType81.dereference();
        boolean boolean85 = objectType84.isOrdinaryFunction();
        boolean boolean86 = objectType84.isUnknownType();
        boolean boolean87 = objectType84.matchesUint32Context();
        com.google.javascript.rhino.jstype.JSType.TypePair typePair88 = objectType76.getTypesUnderShallowInequality((com.google.javascript.rhino.jstype.JSType) objectType84);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray89 = new com.google.javascript.rhino.jstype.JSType[] { objectType68, objectType76 };
        com.google.javascript.rhino.jstype.FunctionType functionType90 = jSTypeRegistry49.createFunctionType(jSType58, jSTypeArray89);
        boolean boolean91 = functionType90.isInterface();
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable92 = functionType90.getParameters();
        boolean boolean93 = functionType42.hasEqualCallType(functionType90);
        org.junit.Assert.assertNull(jSType3);
        org.junit.Assert.assertNotNull(jSType8);
        org.junit.Assert.assertNotNull(jSType10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(jSType17);
        org.junit.Assert.assertNotNull(jSType19);
        org.junit.Assert.assertNotNull(objectType20);
        org.junit.Assert.assertNotNull(jSType25);
        org.junit.Assert.assertNotNull(jSType27);
        org.junit.Assert.assertNotNull(objectType28);
        org.junit.Assert.assertNotNull(jSType33);
        org.junit.Assert.assertNotNull(jSType35);
        org.junit.Assert.assertNotNull(objectType36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertNotNull(typePair40);
        org.junit.Assert.assertNotNull(jSTypeArray41);
        org.junit.Assert.assertNotNull(functionType42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNull(jSType47);
        org.junit.Assert.assertNull(jSType51);
        org.junit.Assert.assertNotNull(jSType56);
        org.junit.Assert.assertNotNull(jSType58);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertNotNull(jSType65);
        org.junit.Assert.assertNotNull(jSType67);
        org.junit.Assert.assertNotNull(objectType68);
        org.junit.Assert.assertNotNull(jSType73);
        org.junit.Assert.assertNotNull(jSType75);
        org.junit.Assert.assertNotNull(objectType76);
        org.junit.Assert.assertNotNull(jSType81);
        org.junit.Assert.assertNotNull(jSType83);
        org.junit.Assert.assertNotNull(objectType84);
        org.junit.Assert.assertTrue("'" + boolean85 + "' != '" + false + "'", boolean85 == false);
        org.junit.Assert.assertTrue("'" + boolean86 + "' != '" + false + "'", boolean86 == false);
        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + true + "'", boolean87 == true);
        org.junit.Assert.assertNotNull(typePair88);
        org.junit.Assert.assertNotNull(jSTypeArray89);
        org.junit.Assert.assertNotNull(functionType90);
        org.junit.Assert.assertTrue("'" + boolean91 + "' != '" + false + "'", boolean91 == false);
        org.junit.Assert.assertNotNull(nodeIterable92);
        org.junit.Assert.assertTrue("'" + boolean93 + "' != '" + false + "'", boolean93 == false);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        try {
            com.google.javascript.rhino.EcmaError ecmaError4 = com.google.javascript.rhino.ScriptRuntime.typeError3("goog.exportSymbol", ": Named type with empty name component", "goog.abstractMethod", "hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property goog.exportSymbol");
        } catch (java.lang.RuntimeException e) {
        }
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode3 = new com.google.javascript.rhino.ScriptOrFnNode((int) (short) 0, (int) ' ', 33);
        int int4 = scriptOrFnNode3.getEncodedSourceStart();
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative5 = com.google.javascript.rhino.jstype.JSTypeNative.LEAST_FUNCTION_TYPE;
        scriptOrFnNode3.setCompilerData((java.lang.Object) jSTypeNative5);
        int int7 = scriptOrFnNode3.getChildCount();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + jSTypeNative5 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.LEAST_FUNCTION_TYPE + "'", jSTypeNative5.equals(com.google.javascript.rhino.jstype.JSTypeNative.LEAST_FUNCTION_TYPE));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        com.google.javascript.rhino.jstype.JSType jSType2 = null;
        com.google.javascript.rhino.jstype.JSType jSType4 = jSTypeRegistry1.getGreatestSubtypeWithProperty(jSType2, "");
        com.google.javascript.rhino.jstype.JSType jSType6 = jSType4.findPropertyType("");
        com.google.javascript.rhino.jstype.ObjectType objectType7 = jSType4.dereference();
        com.google.javascript.rhino.ErrorReporter errorReporter8 = null;
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope9 = null;
        com.google.javascript.rhino.jstype.JSType jSType10 = jSType4.forceResolve(errorReporter8, jSTypeStaticScope9);
        boolean boolean11 = jSType10.isNominalType();
        org.junit.Assert.assertNotNull(jSType4);
        org.junit.Assert.assertNotNull(jSType6);
        org.junit.Assert.assertNotNull(objectType7);
        org.junit.Assert.assertNotNull(jSType10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        com.google.javascript.jscomp.JSModule[] jSModuleArray0 = new com.google.javascript.jscomp.JSModule[] {};
        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList1 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList1, jSModuleArray0);
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph3 = new com.google.javascript.jscomp.JSModuleGraph((java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList1);
        com.google.javascript.jscomp.JSModule jSModule5 = new com.google.javascript.jscomp.JSModule("Not declared as a constructor");
        java.nio.charset.Charset charset7 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile8 = com.google.javascript.jscomp.JSSourceFile.fromFile("Not declared as a constructor", charset7);
        java.lang.String str10 = jSSourceFile8.getLine(0);
        jSModule5.add(jSSourceFile8);
        com.google.javascript.jscomp.JSModule jSModule13 = new com.google.javascript.jscomp.JSModule("Not declared as a constructor");
        java.nio.charset.Charset charset15 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile16 = com.google.javascript.jscomp.JSSourceFile.fromFile("Not declared as a constructor", charset15);
        java.lang.String str18 = jSSourceFile16.getLine(0);
        jSModule13.add(jSSourceFile16);
        java.util.List<java.lang.String> strList20 = jSModule13.getProvides();
        com.google.javascript.jscomp.JSModule jSModule21 = jSModuleGraph3.getDeepestCommonDependencyInclusive(jSModule5, jSModule13);
        jSModule13.clearAsts();
        com.google.javascript.jscomp.SourceFile.Generator generator24 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile25 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("", generator24);
        java.lang.String str26 = jSSourceFile25.getName();
        jSModule13.add(jSSourceFile25);
        com.google.javascript.jscomp.SourceAst sourceAst28 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput31 = new com.google.javascript.jscomp.CompilerInput(sourceAst28, "goog.exportSymbol", true);
        java.lang.String str32 = compilerInput31.getName();
        com.google.javascript.jscomp.JSModule jSModule34 = new com.google.javascript.jscomp.JSModule("goog.exportSymbol");
        compilerInput31.setModule(jSModule34);
        try {
            jSModule13.addFirst(compilerInput31);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(jSModuleArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(jSSourceFile8);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertNotNull(jSSourceFile16);
        org.junit.Assert.assertNull(str18);
        org.junit.Assert.assertNotNull(strList20);
        org.junit.Assert.assertNull(jSModule21);
        org.junit.Assert.assertNotNull(jSSourceFile25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "" + "'", str26.equals(""));
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "goog.exportSymbol" + "'", str32.equals("goog.exportSymbol"));
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention1 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newNumber((double) (short) 100, 0, (int) (byte) -1);
        java.lang.String str6 = node5.toString();
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder7 = node5.getJsDocBuilderForNode();
        boolean boolean8 = closureCodingConvention1.isVarArgsParameter(node5);
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newNumber((double) (short) 100, 0, (int) (byte) -1);
        node12.removeProp((int) (short) 1);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder15 = node12.getJsDocBuilderForNode();
        java.lang.Object obj17 = node12.getProp((-1));
        boolean boolean18 = closureCodingConvention1.isVarArgsParameter(node12);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode22 = new com.google.javascript.rhino.ScriptOrFnNode((int) (short) 0, (int) ' ', 33);
        int int23 = scriptOrFnNode22.getEncodedSourceStart();
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative24 = com.google.javascript.rhino.jstype.JSTypeNative.LEAST_FUNCTION_TYPE;
        scriptOrFnNode22.setCompilerData((java.lang.Object) jSTypeNative24);
        java.lang.String[] strArray26 = scriptOrFnNode22.getParamAndVarNames();
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention27 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode31 = new com.google.javascript.rhino.ScriptOrFnNode((int) (short) 0, (int) ' ', 33);
        int int32 = scriptOrFnNode31.getEncodedSourceStart();
        com.google.javascript.rhino.Node node36 = com.google.javascript.rhino.Node.newNumber((double) (short) 100, 0, (int) (byte) -1);
        java.lang.String str37 = node36.toString();
        java.lang.String str38 = closureCodingConvention27.extractClassNameIfRequire((com.google.javascript.rhino.Node) scriptOrFnNode31, node36);
        com.google.javascript.rhino.Node node42 = com.google.javascript.rhino.Node.newNumber((double) (short) 100, 0, (int) (byte) -1);
        node42.removeProp((int) (short) 1);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder45 = node42.getJsDocBuilderForNode();
        java.lang.Object obj47 = node42.getProp((-1));
        com.google.javascript.rhino.Node node51 = com.google.javascript.rhino.Node.newNumber((double) (-1.0f), 0, 48);
        node42.addChildToFront(node51);
        com.google.javascript.rhino.Node node53 = node51.cloneTree();
        com.google.javascript.rhino.Node node56 = new com.google.javascript.rhino.Node((int) (byte) 10, node12, (com.google.javascript.rhino.Node) scriptOrFnNode22, node36, node53, 48, 0);
        scriptOrFnNode22.setEndLineno((int) (byte) 1);
        scriptOrFnNode22.removeProp(110);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "NUMBER 100.0" + "'", str6.equals("NUMBER 100.0"));
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder15);
        org.junit.Assert.assertNull(obj17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertTrue("'" + jSTypeNative24 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.LEAST_FUNCTION_TYPE + "'", jSTypeNative24.equals(com.google.javascript.rhino.jstype.JSTypeNative.LEAST_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(strArray26);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertNotNull(node36);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "NUMBER 100.0" + "'", str37.equals("NUMBER 100.0"));
        org.junit.Assert.assertNull(str38);
        org.junit.Assert.assertNotNull(node42);
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder45);
        org.junit.Assert.assertNull(obj47);
        org.junit.Assert.assertNotNull(node51);
        org.junit.Assert.assertNotNull(node53);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        com.google.javascript.rhino.Context context0 = null;
        com.google.javascript.rhino.Context context1 = com.google.javascript.rhino.Context.enter(context0);
        com.google.javascript.rhino.Context context2 = com.google.javascript.rhino.Context.enter(context0);
        boolean boolean3 = context2.isGeneratingDebug();
        context2.setGeneratingSource(true);
        java.lang.Class<?> wildcardClass6 = context2.getClass();
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        try {
            context2.addPropertyChangeListener(propertyChangeListener7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(context1);
        org.junit.Assert.assertNotNull(context2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(wildcardClass6);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        com.google.javascript.jscomp.JSModule jSModule1 = new com.google.javascript.jscomp.JSModule("Not declared as a constructor");
        java.nio.charset.Charset charset3 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile4 = com.google.javascript.jscomp.JSSourceFile.fromFile("Not declared as a constructor", charset3);
        java.lang.String str6 = jSSourceFile4.getLine(0);
        jSModule1.add(jSSourceFile4);
        java.util.List<java.lang.String> strList8 = jSModule1.getProvides();
        com.google.javascript.jscomp.JSModule jSModule10 = new com.google.javascript.jscomp.JSModule("Not declared as a constructor");
        java.nio.charset.Charset charset12 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile13 = com.google.javascript.jscomp.JSSourceFile.fromFile("Not declared as a constructor", charset12);
        java.lang.String str15 = jSSourceFile13.getLine(0);
        jSModule10.add(jSSourceFile13);
        com.google.javascript.jscomp.deps.DependencyInfo[] dependencyInfoArray17 = new com.google.javascript.jscomp.deps.DependencyInfo[] { jSModule1, jSModule10 };
        java.util.ArrayList<com.google.javascript.jscomp.deps.DependencyInfo> dependencyInfoList18 = new java.util.ArrayList<com.google.javascript.jscomp.deps.DependencyInfo>();
        boolean boolean19 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.deps.DependencyInfo>) dependencyInfoList18, dependencyInfoArray17);
        com.google.javascript.jscomp.deps.SortedDependencies<com.google.javascript.jscomp.deps.DependencyInfo> dependencyInfoSortedDependencies20 = new com.google.javascript.jscomp.deps.SortedDependencies<com.google.javascript.jscomp.deps.DependencyInfo>((java.util.List<com.google.javascript.jscomp.deps.DependencyInfo>) dependencyInfoList18);
        com.google.javascript.jscomp.deps.DependencyInfo dependencyInfo22 = dependencyInfoSortedDependencies20.getInputProviding("Not declared as a constructor");
        org.junit.Assert.assertNotNull(jSSourceFile4);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNotNull(strList8);
        org.junit.Assert.assertNotNull(jSSourceFile13);
        org.junit.Assert.assertNull(str15);
        org.junit.Assert.assertNotNull(dependencyInfoArray17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(dependencyInfo22);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        com.google.javascript.rhino.Context context0 = null;
        com.google.javascript.rhino.Context context1 = com.google.javascript.rhino.Context.enter(context0);
        com.google.javascript.rhino.Context context2 = com.google.javascript.rhino.Context.enter(context0);
        boolean boolean3 = context2.isGeneratingDebug();
        context2.setGeneratingSource(true);
        boolean boolean6 = context2.isGeneratingDebug();
        context2.setLanguageVersion(110);
        org.junit.Assert.assertNotNull(context1);
        org.junit.Assert.assertNotNull(context2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode4 = new com.google.javascript.rhino.ScriptOrFnNode((int) (short) 0, (int) ' ', 33);
        int int5 = scriptOrFnNode4.getEncodedSourceStart();
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newNumber((double) (short) 100, 0, (int) (byte) -1);
        java.lang.String str10 = node9.toString();
        java.lang.String str11 = closureCodingConvention0.extractClassNameIfRequire((com.google.javascript.rhino.Node) scriptOrFnNode4, node9);
        com.google.javascript.rhino.Node node12 = null;
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode16 = new com.google.javascript.rhino.ScriptOrFnNode((int) (short) 0, (int) ' ', 33);
        int int17 = scriptOrFnNode16.getEncodedSourceStart();
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative18 = com.google.javascript.rhino.jstype.JSTypeNative.LEAST_FUNCTION_TYPE;
        scriptOrFnNode16.setCompilerData((java.lang.Object) jSTypeNative18);
        int int20 = scriptOrFnNode16.getParamAndVarCount();
        java.lang.String str21 = closureCodingConvention0.extractClassNameIfProvide(node12, (com.google.javascript.rhino.Node) scriptOrFnNode16);
        com.google.javascript.rhino.Node node24 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.jscomp.CheckLevel checkLevel25 = com.google.javascript.jscomp.CheckLevel.OFF;
        com.google.javascript.jscomp.DiagnosticType diagnosticType28 = com.google.javascript.jscomp.DiagnosticType.warning("Unknown class name", "Unknown class name");
        java.text.MessageFormat messageFormat29 = diagnosticType28.format;
        java.lang.String[] strArray30 = null;
        com.google.javascript.jscomp.JSError jSError31 = com.google.javascript.jscomp.JSError.make("-1", node24, checkLevel25, diagnosticType28, strArray30);
        boolean boolean32 = closureCodingConvention0.isVarArgsParameter(node24);
        com.google.javascript.rhino.ErrorReporter errorReporter33 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry34 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter33);
        com.google.javascript.rhino.jstype.JSType jSType36 = jSTypeRegistry34.getType("hi!");
        com.google.javascript.rhino.Node node39 = com.google.javascript.rhino.Node.newNumber((double) (short) 0);
        com.google.javascript.rhino.ErrorReporter errorReporter40 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry41 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter40);
        com.google.javascript.rhino.jstype.JSType jSType42 = null;
        com.google.javascript.rhino.jstype.JSType jSType44 = jSTypeRegistry41.getGreatestSubtypeWithProperty(jSType42, "");
        com.google.javascript.rhino.jstype.JSType jSType46 = jSType44.findPropertyType("");
        com.google.javascript.rhino.jstype.ObjectType objectType47 = jSType44.dereference();
        boolean boolean48 = objectType47.isNumber();
        com.google.javascript.rhino.ErrorReporter errorReporter49 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry50 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter49);
        com.google.javascript.rhino.jstype.JSType jSType51 = null;
        com.google.javascript.rhino.jstype.JSType jSType53 = jSTypeRegistry50.getGreatestSubtypeWithProperty(jSType51, "");
        com.google.javascript.rhino.jstype.JSType jSType55 = jSType53.findPropertyType("");
        com.google.javascript.rhino.jstype.ObjectType objectType56 = jSType53.dereference();
        boolean boolean57 = objectType56.isNumber();
        com.google.javascript.rhino.jstype.JSType jSType58 = objectType47.getGreatestSubtype((com.google.javascript.rhino.jstype.JSType) objectType56);
        com.google.javascript.rhino.jstype.ObjectType objectType59 = jSTypeRegistry34.createObjectType("Not declared as a constructor", node39, objectType56);
        com.google.javascript.rhino.ErrorReporter errorReporter60 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry61 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter60);
        com.google.javascript.rhino.jstype.JSType jSType63 = jSTypeRegistry61.getType("hi!");
        com.google.javascript.rhino.Node node66 = com.google.javascript.rhino.Node.newNumber((double) (short) 0);
        com.google.javascript.rhino.ErrorReporter errorReporter67 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry68 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter67);
        com.google.javascript.rhino.jstype.JSType jSType69 = null;
        com.google.javascript.rhino.jstype.JSType jSType71 = jSTypeRegistry68.getGreatestSubtypeWithProperty(jSType69, "");
        com.google.javascript.rhino.jstype.JSType jSType73 = jSType71.findPropertyType("");
        com.google.javascript.rhino.jstype.ObjectType objectType74 = jSType71.dereference();
        boolean boolean75 = objectType74.isNumber();
        com.google.javascript.rhino.ErrorReporter errorReporter76 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry77 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter76);
        com.google.javascript.rhino.jstype.JSType jSType78 = null;
        com.google.javascript.rhino.jstype.JSType jSType80 = jSTypeRegistry77.getGreatestSubtypeWithProperty(jSType78, "");
        com.google.javascript.rhino.jstype.JSType jSType82 = jSType80.findPropertyType("");
        com.google.javascript.rhino.jstype.ObjectType objectType83 = jSType80.dereference();
        boolean boolean84 = objectType83.isNumber();
        com.google.javascript.rhino.jstype.JSType jSType85 = objectType74.getGreatestSubtype((com.google.javascript.rhino.jstype.JSType) objectType83);
        com.google.javascript.rhino.jstype.ObjectType objectType86 = jSTypeRegistry61.createObjectType("Not declared as a constructor", node66, objectType83);
        com.google.javascript.rhino.Node node87 = node39.copyInformationFrom(node66);
        try {
            java.lang.String str88 = closureCodingConvention0.getSingletonGetterClassName(node87);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "NUMBER 100.0" + "'", str10.equals("NUMBER 100.0"));
        org.junit.Assert.assertNull(str11);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + jSTypeNative18 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.LEAST_FUNCTION_TYPE + "'", jSTypeNative18.equals(com.google.javascript.rhino.jstype.JSTypeNative.LEAST_FUNCTION_TYPE));
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertTrue("'" + checkLevel25 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel25.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(diagnosticType28);
        org.junit.Assert.assertNotNull(messageFormat29);
        org.junit.Assert.assertNotNull(jSError31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNull(jSType36);
        org.junit.Assert.assertNotNull(node39);
        org.junit.Assert.assertNotNull(jSType44);
        org.junit.Assert.assertNotNull(jSType46);
        org.junit.Assert.assertNotNull(objectType47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + true + "'", boolean48 == true);
        org.junit.Assert.assertNotNull(jSType53);
        org.junit.Assert.assertNotNull(jSType55);
        org.junit.Assert.assertNotNull(objectType56);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + true + "'", boolean57 == true);
        org.junit.Assert.assertNotNull(jSType58);
        org.junit.Assert.assertNotNull(objectType59);
        org.junit.Assert.assertNull(jSType63);
        org.junit.Assert.assertNotNull(node66);
        org.junit.Assert.assertNotNull(jSType71);
        org.junit.Assert.assertNotNull(jSType73);
        org.junit.Assert.assertNotNull(objectType74);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + true + "'", boolean75 == true);
        org.junit.Assert.assertNotNull(jSType80);
        org.junit.Assert.assertNotNull(jSType82);
        org.junit.Assert.assertNotNull(objectType83);
        org.junit.Assert.assertTrue("'" + boolean84 + "' != '" + true + "'", boolean84 == true);
        org.junit.Assert.assertNotNull(jSType85);
        org.junit.Assert.assertNotNull(objectType86);
        org.junit.Assert.assertNotNull(node87);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        jSTypeRegistry2.incrementGeneration();
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative4 = com.google.javascript.rhino.jstype.JSTypeNative.VOID_TYPE;
        try {
            com.google.javascript.rhino.jstype.ObjectType objectType5 = jSTypeRegistry2.getNativeObjectType(jSTypeNative4);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: com.google.javascript.rhino.jstype.VoidType cannot be cast to com.google.javascript.rhino.jstype.ObjectType");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertTrue("'" + jSTypeNative4 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.VOID_TYPE + "'", jSTypeNative4.equals(com.google.javascript.rhino.jstype.JSTypeNative.VOID_TYPE));
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        com.google.javascript.rhino.jstype.JSType jSType3 = jSTypeRegistry1.getType("hi!");
        com.google.javascript.rhino.ErrorReporter errorReporter4 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter4);
        com.google.javascript.rhino.jstype.JSType jSType6 = null;
        com.google.javascript.rhino.jstype.JSType jSType8 = jSTypeRegistry5.getGreatestSubtypeWithProperty(jSType6, "");
        com.google.javascript.rhino.jstype.JSType jSType10 = jSType8.findPropertyType("");
        boolean boolean11 = jSType10.isArrayType();
        boolean boolean12 = jSType10.isNominalType();
        com.google.javascript.rhino.ErrorReporter errorReporter13 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry14 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter13);
        com.google.javascript.rhino.jstype.JSType jSType15 = null;
        com.google.javascript.rhino.jstype.JSType jSType17 = jSTypeRegistry14.getGreatestSubtypeWithProperty(jSType15, "");
        com.google.javascript.rhino.jstype.JSType jSType19 = jSType17.findPropertyType("");
        com.google.javascript.rhino.jstype.ObjectType objectType20 = jSType17.dereference();
        com.google.javascript.rhino.ErrorReporter errorReporter21 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry22 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter21);
        com.google.javascript.rhino.jstype.JSType jSType23 = null;
        com.google.javascript.rhino.jstype.JSType jSType25 = jSTypeRegistry22.getGreatestSubtypeWithProperty(jSType23, "");
        com.google.javascript.rhino.jstype.JSType jSType27 = jSType25.findPropertyType("");
        com.google.javascript.rhino.jstype.ObjectType objectType28 = jSType25.dereference();
        com.google.javascript.rhino.ErrorReporter errorReporter29 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry30 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter29);
        com.google.javascript.rhino.jstype.JSType jSType31 = null;
        com.google.javascript.rhino.jstype.JSType jSType33 = jSTypeRegistry30.getGreatestSubtypeWithProperty(jSType31, "");
        com.google.javascript.rhino.jstype.JSType jSType35 = jSType33.findPropertyType("");
        com.google.javascript.rhino.jstype.ObjectType objectType36 = jSType33.dereference();
        boolean boolean37 = objectType36.isOrdinaryFunction();
        boolean boolean38 = objectType36.isUnknownType();
        boolean boolean39 = objectType36.matchesUint32Context();
        com.google.javascript.rhino.jstype.JSType.TypePair typePair40 = objectType28.getTypesUnderShallowInequality((com.google.javascript.rhino.jstype.JSType) objectType36);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray41 = new com.google.javascript.rhino.jstype.JSType[] { objectType20, objectType28 };
        com.google.javascript.rhino.jstype.FunctionType functionType42 = jSTypeRegistry1.createFunctionType(jSType10, jSTypeArray41);
        com.google.javascript.rhino.ErrorReporter errorReporter43 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry44 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter43);
        com.google.javascript.rhino.jstype.JSType jSType45 = null;
        com.google.javascript.rhino.jstype.JSType jSType47 = jSTypeRegistry44.getGreatestSubtypeWithProperty(jSType45, "");
        com.google.javascript.rhino.jstype.JSType jSType49 = jSType47.findPropertyType("");
        com.google.javascript.rhino.jstype.ObjectType objectType50 = jSType47.dereference();
        com.google.javascript.rhino.jstype.ObjectType objectType51 = jSTypeRegistry1.createObjectType(objectType50);
        com.google.javascript.rhino.ErrorReporter errorReporter52 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry53 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter52);
        com.google.javascript.rhino.jstype.JSType jSType54 = null;
        com.google.javascript.rhino.jstype.JSType jSType56 = jSTypeRegistry53.getGreatestSubtypeWithProperty(jSType54, "");
        com.google.javascript.rhino.jstype.JSType jSType58 = jSType56.findPropertyType("");
        com.google.javascript.rhino.jstype.ObjectType objectType59 = jSType56.dereference();
        com.google.javascript.rhino.ErrorReporter errorReporter60 = null;
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope61 = null;
        com.google.javascript.rhino.jstype.JSType jSType62 = jSType56.forceResolve(errorReporter60, jSTypeStaticScope61);
        boolean boolean63 = jSType56.isEnumType();
        boolean boolean65 = jSTypeRegistry1.canPropertyBeDefined(jSType56, "-1");
        jSTypeRegistry1.resetForTypeCheck();
        com.google.javascript.rhino.jstype.ObjectType objectType67 = jSTypeRegistry1.createAnonymousObjectType();
        org.junit.Assert.assertNull(jSType3);
        org.junit.Assert.assertNotNull(jSType8);
        org.junit.Assert.assertNotNull(jSType10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(jSType17);
        org.junit.Assert.assertNotNull(jSType19);
        org.junit.Assert.assertNotNull(objectType20);
        org.junit.Assert.assertNotNull(jSType25);
        org.junit.Assert.assertNotNull(jSType27);
        org.junit.Assert.assertNotNull(objectType28);
        org.junit.Assert.assertNotNull(jSType33);
        org.junit.Assert.assertNotNull(jSType35);
        org.junit.Assert.assertNotNull(objectType36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertNotNull(typePair40);
        org.junit.Assert.assertNotNull(jSTypeArray41);
        org.junit.Assert.assertNotNull(functionType42);
        org.junit.Assert.assertNotNull(jSType47);
        org.junit.Assert.assertNotNull(jSType49);
        org.junit.Assert.assertNotNull(objectType50);
        org.junit.Assert.assertNotNull(objectType51);
        org.junit.Assert.assertNotNull(jSType56);
        org.junit.Assert.assertNotNull(jSType58);
        org.junit.Assert.assertNotNull(objectType59);
        org.junit.Assert.assertNotNull(jSType62);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertNotNull(objectType67);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        java.io.File file0 = null;
        java.nio.charset.Charset charset1 = null;
        try {
            com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromFile(file0, charset1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        com.google.javascript.rhino.EvaluatorException evaluatorException5 = new com.google.javascript.rhino.EvaluatorException("hi!", "-1", (int) '#', "", (int) (short) 1);
        int int6 = evaluatorException5.lineNumber();
        java.lang.String str7 = evaluatorException5.lineSource();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 35 + "'", int6 == 35);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        java.util.Set<com.google.javascript.rhino.jstype.ObjectType> objectTypeSet3 = jSTypeRegistry1.getTypesWithProperty("");
        com.google.javascript.rhino.ErrorReporter errorReporter4 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter4);
        com.google.javascript.rhino.jstype.JSType jSType6 = null;
        com.google.javascript.rhino.jstype.JSType jSType8 = jSTypeRegistry5.getGreatestSubtypeWithProperty(jSType6, "");
        com.google.javascript.rhino.jstype.JSType jSType10 = jSType8.findPropertyType("");
        com.google.javascript.rhino.ErrorReporter errorReporter11 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry12 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter11);
        com.google.javascript.rhino.jstype.JSType jSType13 = null;
        com.google.javascript.rhino.jstype.JSType jSType15 = jSTypeRegistry12.getGreatestSubtypeWithProperty(jSType13, "");
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray16 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.Node node17 = jSTypeRegistry12.createOptionalParameters(jSTypeArray16);
        com.google.javascript.rhino.jstype.FunctionType functionType18 = jSTypeRegistry1.createFunctionTypeWithVarArgs(jSType8, jSTypeArray16);
        java.util.Set<java.lang.String> strSet19 = functionType18.getOwnPropertyNames();
        boolean boolean20 = functionType18.isInterface();
        boolean boolean21 = functionType18.canBeCalled();
        boolean boolean22 = functionType18.hasReferenceName();
        com.google.javascript.rhino.jstype.ObjectType objectType23 = functionType18.toObjectType();
        boolean boolean24 = functionType18.isNominalType();
        org.junit.Assert.assertNotNull(objectTypeSet3);
        org.junit.Assert.assertNotNull(jSType8);
        org.junit.Assert.assertNotNull(jSType10);
        org.junit.Assert.assertNotNull(jSType15);
        org.junit.Assert.assertNotNull(jSTypeArray16);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(functionType18);
        org.junit.Assert.assertNotNull(strSet19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(objectType23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy0 = com.google.javascript.jscomp.PropertyRenamingPolicy.HEURISTIC;
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy0 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.HEURISTIC + "'", propertyRenamingPolicy0.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.HEURISTIC));
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.Scope scope2 = compiler1.getTopScope();
        com.google.javascript.jscomp.PerformanceTracker performanceTracker3 = null;
        compiler1.tracker = performanceTracker3;
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter5 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler1);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile8 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "NUMBER 100.0");
        com.google.javascript.rhino.Node node9 = compiler1.parse(jSSourceFile8);
        com.google.javascript.jscomp.JSModule jSModule11 = new com.google.javascript.jscomp.JSModule("goog.exportSymbol");
        java.lang.String str12 = jSModule11.toString();
        java.lang.String str13 = compiler1.toSource(jSModule11);
        java.util.Set<com.google.javascript.jscomp.JSModule> jSModuleSet14 = jSModule11.getThisAndAllDependencies();
        org.junit.Assert.assertNull(scope2);
        org.junit.Assert.assertNotNull(jSSourceFile8);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "goog.exportSymbol" + "'", str12.equals("goog.exportSymbol"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertNotNull(jSModuleSet14);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        com.google.javascript.jscomp.DiagnosticType diagnosticType0 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        org.junit.Assert.assertNotNull(diagnosticType0);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention0 = new com.google.javascript.jscomp.GoogleCodingConvention();
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention1 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode5 = new com.google.javascript.rhino.ScriptOrFnNode((int) (short) 0, (int) ' ', 33);
        int int6 = scriptOrFnNode5.getEncodedSourceStart();
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newNumber((double) (short) 100, 0, (int) (byte) -1);
        java.lang.String str11 = node10.toString();
        java.lang.String str12 = closureCodingConvention1.extractClassNameIfRequire((com.google.javascript.rhino.Node) scriptOrFnNode5, node10);
        java.lang.String str13 = googleCodingConvention0.identifyTypeDefAssign((com.google.javascript.rhino.Node) scriptOrFnNode5);
        java.lang.String str14 = googleCodingConvention0.getGlobalObject();
        boolean boolean16 = googleCodingConvention0.isSuperClassReference("goog.exportProperty");
        java.lang.String str17 = googleCodingConvention0.getExportSymbolFunction();
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode21 = new com.google.javascript.rhino.ScriptOrFnNode((int) (short) 0, (int) ' ', 33);
        java.lang.Object obj22 = scriptOrFnNode21.getCompilerData();
        try {
            boolean boolean23 = googleCodingConvention0.isPropertyTestFunction((com.google.javascript.rhino.Node) scriptOrFnNode21);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "NUMBER 100.0" + "'", str11.equals("NUMBER 100.0"));
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "goog.global" + "'", str14.equals("goog.global"));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "goog.exportSymbol" + "'", str17.equals("goog.exportSymbol"));
        org.junit.Assert.assertNull(obj22);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        java.util.Set<com.google.javascript.rhino.jstype.ObjectType> objectTypeSet3 = jSTypeRegistry1.getTypesWithProperty("");
        com.google.javascript.rhino.Node node8 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("function (function (this:me, {205500149}): me, function (this:me, {1319818263}): me): function (this:me, {426577557}): me", 13, 22);
        try {
            com.google.javascript.rhino.jstype.FunctionType functionType9 = jSTypeRegistry1.createInterfaceType("goog.exportSymbol", node8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(objectTypeSet3);
        org.junit.Assert.assertNotNull(node8);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        com.google.javascript.rhino.EcmaError ecmaError2 = com.google.javascript.rhino.ScriptRuntime.constructError("Not declared as a constructor", "");
        java.lang.String str3 = ecmaError2.getName();
        org.junit.Assert.assertNotNull(ecmaError2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Not declared as a constructor" + "'", str3.equals("Not declared as a constructor"));
    }

//    @Test
//    public void test039() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test039");
//        com.google.javascript.rhino.Context context0 = null;
//        com.google.javascript.rhino.Context context1 = com.google.javascript.rhino.Context.enter(context0);
//        com.google.javascript.rhino.Context context2 = com.google.javascript.rhino.Context.enter(context0);
//        java.lang.String str3 = context2.getImplementationVersion();
//        java.util.Locale locale4 = null;
//        java.util.Locale locale5 = context2.setLocale(locale4);
//        org.junit.Assert.assertNotNull(context1);
//        org.junit.Assert.assertNotNull(context2);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "@IMPLEMENTATION.VERSION@" + "'", str3.equals("@IMPLEMENTATION.VERSION@"));
//        org.junit.Assert.assertNull(locale5);
//    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.SourceMap sourceMap1 = compiler0.getSourceMap();
        com.google.javascript.jscomp.JSModule[] jSModuleArray2 = new com.google.javascript.jscomp.JSModule[] {};
        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList3 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
        boolean boolean4 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList3, jSModuleArray2);
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph5 = new com.google.javascript.jscomp.JSModuleGraph((java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList3);
        com.google.javascript.jscomp.JSModule jSModule7 = new com.google.javascript.jscomp.JSModule("Not declared as a constructor");
        java.nio.charset.Charset charset9 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile10 = com.google.javascript.jscomp.JSSourceFile.fromFile("Not declared as a constructor", charset9);
        java.lang.String str12 = jSSourceFile10.getLine(0);
        jSModule7.add(jSSourceFile10);
        com.google.javascript.jscomp.JSModule jSModule15 = new com.google.javascript.jscomp.JSModule("Not declared as a constructor");
        java.nio.charset.Charset charset17 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile18 = com.google.javascript.jscomp.JSSourceFile.fromFile("Not declared as a constructor", charset17);
        java.lang.String str20 = jSSourceFile18.getLine(0);
        jSModule15.add(jSSourceFile18);
        java.util.List<java.lang.String> strList22 = jSModule15.getProvides();
        com.google.javascript.jscomp.JSModule jSModule23 = jSModuleGraph5.getDeepestCommonDependencyInclusive(jSModule7, jSModule15);
        jSModule15.clearAsts();
        com.google.javascript.jscomp.SourceFile.Generator generator26 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile27 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("", generator26);
        java.lang.String str28 = jSSourceFile27.getName();
        jSModule15.add(jSSourceFile27);
        com.google.javascript.jscomp.SourceFile.Generator generator31 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile32 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("goog.abstractMethod", generator31);
        com.google.javascript.jscomp.SourceFile.Generator generator34 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile35 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("", generator34);
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray36 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile32, jSSourceFile35 };
        com.google.javascript.jscomp.CompilerOptions compilerOptions37 = null;
        try {
            com.google.javascript.jscomp.Result result38 = compiler0.compile(jSSourceFile27, jSSourceFileArray36, compilerOptions37);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(sourceMap1);
        org.junit.Assert.assertNotNull(jSModuleArray2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(jSSourceFile10);
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertNotNull(jSSourceFile18);
        org.junit.Assert.assertNull(str20);
        org.junit.Assert.assertNotNull(strList22);
        org.junit.Assert.assertNull(jSModule23);
        org.junit.Assert.assertNotNull(jSSourceFile27);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "" + "'", str28.equals(""));
        org.junit.Assert.assertNotNull(jSSourceFile32);
        org.junit.Assert.assertNotNull(jSSourceFile35);
        org.junit.Assert.assertNotNull(jSSourceFileArray36);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        int int0 = com.google.javascript.rhino.Node.DIRECTIVES;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 47 + "'", int0 == 47);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        int int0 = com.google.javascript.rhino.Node.LABEL_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 19 + "'", int0 == 19);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        java.lang.String str1 = com.google.javascript.rhino.ScriptRuntime.escapeString("function (function (this:me, {1364049326}): me, function (this:me, {1150306710}): me): function (this:me, {1082986857}): me");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "function (function (this:me, {1364049326}): me, function (this:me, {1150306710}): me): function (this:me, {1082986857}): me" + "'", str1.equals("function (function (this:me, {1364049326}): me, function (this:me, {1150306710}): me): function (this:me, {1082986857}): me"));
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        com.google.javascript.rhino.EcmaError ecmaError6 = com.google.javascript.rhino.ScriptRuntime.constructError("NUMBER 100.0", "Not declared as a constructor", "", 34, "NUMBER 100.0", 6);
        java.lang.String str7 = ecmaError6.getName();
        int int8 = ecmaError6.columnNumber();
        org.junit.Assert.assertNotNull(ecmaError6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "NUMBER 100.0" + "'", str7.equals("NUMBER 100.0"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.ErrorReporter errorReporter1 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter1);
        java.util.Set<com.google.javascript.rhino.jstype.ObjectType> objectTypeSet4 = jSTypeRegistry2.getTypesWithProperty("");
        com.google.javascript.rhino.ErrorReporter errorReporter5 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry6 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter5);
        com.google.javascript.rhino.jstype.JSType jSType7 = null;
        com.google.javascript.rhino.jstype.JSType jSType9 = jSTypeRegistry6.getGreatestSubtypeWithProperty(jSType7, "");
        com.google.javascript.rhino.jstype.JSType jSType11 = jSType9.findPropertyType("");
        com.google.javascript.rhino.ErrorReporter errorReporter12 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry13 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter12);
        com.google.javascript.rhino.jstype.JSType jSType14 = null;
        com.google.javascript.rhino.jstype.JSType jSType16 = jSTypeRegistry13.getGreatestSubtypeWithProperty(jSType14, "");
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray17 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.Node node18 = jSTypeRegistry13.createOptionalParameters(jSTypeArray17);
        com.google.javascript.rhino.jstype.FunctionType functionType19 = jSTypeRegistry2.createFunctionTypeWithVarArgs(jSType9, jSTypeArray17);
        com.google.javascript.rhino.jstype.FunctionType functionType20 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType21 = null;
        closureCodingConvention0.applySubclassRelationship(functionType19, functionType20, subclassType21);
        boolean boolean24 = functionType19.hasOwnProperty("NUMBER 0.0\n");
        org.junit.Assert.assertNotNull(objectTypeSet4);
        org.junit.Assert.assertNotNull(jSType9);
        org.junit.Assert.assertNotNull(jSType11);
        org.junit.Assert.assertNotNull(jSType16);
        org.junit.Assert.assertNotNull(jSTypeArray17);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNotNull(functionType19);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention3 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode7 = new com.google.javascript.rhino.ScriptOrFnNode((int) (short) 0, (int) ' ', 33);
        int int8 = scriptOrFnNode7.getEncodedSourceStart();
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newNumber((double) (short) 100, 0, (int) (byte) -1);
        java.lang.String str13 = node12.toString();
        java.lang.String str14 = closureCodingConvention3.extractClassNameIfRequire((com.google.javascript.rhino.Node) scriptOrFnNode7, node12);
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.Node.newNumber((double) (short) 100, 0, (int) (byte) -1);
        node18.removeProp((int) (short) 1);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder21 = node18.getJsDocBuilderForNode();
        com.google.javascript.rhino.Node[] nodeArray22 = new com.google.javascript.rhino.Node[] { node2, node12, node18 };
        com.google.javascript.rhino.Node node25 = new com.google.javascript.rhino.Node(49, nodeArray22, 45, (int) 'a');
        com.google.javascript.rhino.Node node26 = node25.removeFirstChild();
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "NUMBER 100.0" + "'", str13.equals("NUMBER 100.0"));
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder21);
        org.junit.Assert.assertNotNull(nodeArray22);
        org.junit.Assert.assertNotNull(node26);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newNumber((double) (short) 100, 0, (int) (byte) -1);
        node3.removeProp((int) (short) 1);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder6 = node3.getJsDocBuilderForNode();
        java.lang.Object obj8 = node3.getProp((-1));
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newNumber((double) (-1.0f), 0, 48);
        node3.addChildToFront(node12);
        com.google.javascript.rhino.Node node14 = node12.cloneTree();
        java.lang.String str15 = node12.toString();
        com.google.javascript.rhino.jstype.JSType jSType16 = node12.getJSType();
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder6);
        org.junit.Assert.assertNull(obj8);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "NUMBER -1.0 0" + "'", str15.equals("NUMBER -1.0 0"));
        org.junit.Assert.assertNull(jSType16);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        com.google.javascript.rhino.jstype.JSType jSType3 = jSTypeRegistry1.getType("hi!");
        com.google.javascript.rhino.ErrorReporter errorReporter4 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter4);
        com.google.javascript.rhino.jstype.JSType jSType6 = null;
        com.google.javascript.rhino.jstype.JSType jSType8 = jSTypeRegistry5.getGreatestSubtypeWithProperty(jSType6, "");
        com.google.javascript.rhino.jstype.JSType jSType10 = jSType8.findPropertyType("");
        com.google.javascript.rhino.jstype.ObjectType objectType11 = jSType8.dereference();
        com.google.javascript.rhino.ErrorReporter errorReporter12 = null;
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope13 = null;
        com.google.javascript.rhino.jstype.JSType jSType14 = jSType8.forceResolve(errorReporter12, jSTypeStaticScope13);
        com.google.javascript.rhino.jstype.JSType jSType15 = jSTypeRegistry1.createOptionalNullableType(jSType8);
        jSTypeRegistry1.resetForTypeCheck();
        com.google.javascript.rhino.jstype.JSType jSType21 = jSTypeRegistry1.createNamedType("Named type with empty name component", "Named type with empty name component", 20, 36);
        com.google.javascript.rhino.ErrorReporter errorReporter22 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry23 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter22);
        com.google.javascript.rhino.jstype.JSType jSType25 = jSTypeRegistry23.getType("hi!");
        com.google.javascript.rhino.ErrorReporter errorReporter26 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry27 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter26);
        com.google.javascript.rhino.jstype.JSType jSType28 = null;
        com.google.javascript.rhino.jstype.JSType jSType30 = jSTypeRegistry27.getGreatestSubtypeWithProperty(jSType28, "");
        com.google.javascript.rhino.jstype.JSType jSType32 = jSType30.findPropertyType("");
        boolean boolean33 = jSType32.isArrayType();
        boolean boolean34 = jSType32.isNominalType();
        com.google.javascript.rhino.ErrorReporter errorReporter35 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry36 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter35);
        com.google.javascript.rhino.jstype.JSType jSType37 = null;
        com.google.javascript.rhino.jstype.JSType jSType39 = jSTypeRegistry36.getGreatestSubtypeWithProperty(jSType37, "");
        com.google.javascript.rhino.jstype.JSType jSType41 = jSType39.findPropertyType("");
        com.google.javascript.rhino.jstype.ObjectType objectType42 = jSType39.dereference();
        com.google.javascript.rhino.ErrorReporter errorReporter43 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry44 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter43);
        com.google.javascript.rhino.jstype.JSType jSType45 = null;
        com.google.javascript.rhino.jstype.JSType jSType47 = jSTypeRegistry44.getGreatestSubtypeWithProperty(jSType45, "");
        com.google.javascript.rhino.jstype.JSType jSType49 = jSType47.findPropertyType("");
        com.google.javascript.rhino.jstype.ObjectType objectType50 = jSType47.dereference();
        com.google.javascript.rhino.ErrorReporter errorReporter51 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry52 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter51);
        com.google.javascript.rhino.jstype.JSType jSType53 = null;
        com.google.javascript.rhino.jstype.JSType jSType55 = jSTypeRegistry52.getGreatestSubtypeWithProperty(jSType53, "");
        com.google.javascript.rhino.jstype.JSType jSType57 = jSType55.findPropertyType("");
        com.google.javascript.rhino.jstype.ObjectType objectType58 = jSType55.dereference();
        boolean boolean59 = objectType58.isOrdinaryFunction();
        boolean boolean60 = objectType58.isUnknownType();
        boolean boolean61 = objectType58.matchesUint32Context();
        com.google.javascript.rhino.jstype.JSType.TypePair typePair62 = objectType50.getTypesUnderShallowInequality((com.google.javascript.rhino.jstype.JSType) objectType58);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray63 = new com.google.javascript.rhino.jstype.JSType[] { objectType42, objectType50 };
        com.google.javascript.rhino.jstype.FunctionType functionType64 = jSTypeRegistry23.createFunctionType(jSType32, jSTypeArray63);
        boolean boolean65 = functionType64.isInterface();
        com.google.javascript.rhino.ErrorReporter errorReporter66 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry67 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter66);
        com.google.javascript.rhino.jstype.JSType jSType68 = null;
        com.google.javascript.rhino.jstype.JSType jSType70 = jSTypeRegistry67.getGreatestSubtypeWithProperty(jSType68, "");
        com.google.javascript.rhino.jstype.JSType jSType72 = jSType70.findPropertyType("");
        com.google.javascript.rhino.jstype.ObjectType objectType73 = jSType70.dereference();
        boolean boolean74 = objectType73.isNumber();
        com.google.javascript.rhino.ErrorReporter errorReporter75 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry76 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter75);
        com.google.javascript.rhino.jstype.JSType jSType77 = null;
        com.google.javascript.rhino.jstype.JSType jSType79 = jSTypeRegistry76.getGreatestSubtypeWithProperty(jSType77, "");
        com.google.javascript.rhino.jstype.JSType jSType81 = jSType79.findPropertyType("");
        com.google.javascript.rhino.jstype.ObjectType objectType82 = jSType79.dereference();
        boolean boolean83 = objectType82.isNumber();
        com.google.javascript.rhino.jstype.JSType jSType84 = objectType73.getGreatestSubtype((com.google.javascript.rhino.jstype.JSType) objectType82);
        boolean boolean85 = objectType82.isFunctionPrototypeType();
        com.google.javascript.rhino.jstype.JSType jSType86 = functionType64.getLeastSupertype((com.google.javascript.rhino.jstype.JSType) objectType82);
        boolean boolean87 = jSType21.canTestForShallowEqualityWith((com.google.javascript.rhino.jstype.JSType) functionType64);
        com.google.javascript.rhino.ErrorReporter errorReporter88 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry89 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter88);
        com.google.javascript.rhino.jstype.JSType jSType90 = null;
        com.google.javascript.rhino.jstype.JSType jSType92 = jSTypeRegistry89.getGreatestSubtypeWithProperty(jSType90, "");
        com.google.javascript.rhino.jstype.JSType jSType94 = jSType92.findPropertyType("");
        com.google.javascript.rhino.jstype.ObjectType objectType95 = jSType92.dereference();
        boolean boolean96 = objectType95.isOrdinaryFunction();
        boolean boolean97 = functionType64.isEquivalentTo((com.google.javascript.rhino.jstype.JSType) objectType95);
        org.junit.Assert.assertNull(jSType3);
        org.junit.Assert.assertNotNull(jSType8);
        org.junit.Assert.assertNotNull(jSType10);
        org.junit.Assert.assertNotNull(objectType11);
        org.junit.Assert.assertNotNull(jSType14);
        org.junit.Assert.assertNotNull(jSType15);
        org.junit.Assert.assertNotNull(jSType21);
        org.junit.Assert.assertNull(jSType25);
        org.junit.Assert.assertNotNull(jSType30);
        org.junit.Assert.assertNotNull(jSType32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(jSType39);
        org.junit.Assert.assertNotNull(jSType41);
        org.junit.Assert.assertNotNull(objectType42);
        org.junit.Assert.assertNotNull(jSType47);
        org.junit.Assert.assertNotNull(jSType49);
        org.junit.Assert.assertNotNull(objectType50);
        org.junit.Assert.assertNotNull(jSType55);
        org.junit.Assert.assertNotNull(jSType57);
        org.junit.Assert.assertNotNull(objectType58);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + true + "'", boolean61 == true);
        org.junit.Assert.assertNotNull(typePair62);
        org.junit.Assert.assertNotNull(jSTypeArray63);
        org.junit.Assert.assertNotNull(functionType64);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertNotNull(jSType70);
        org.junit.Assert.assertNotNull(jSType72);
        org.junit.Assert.assertNotNull(objectType73);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + true + "'", boolean74 == true);
        org.junit.Assert.assertNotNull(jSType79);
        org.junit.Assert.assertNotNull(jSType81);
        org.junit.Assert.assertNotNull(objectType82);
        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + true + "'", boolean83 == true);
        org.junit.Assert.assertNotNull(jSType84);
        org.junit.Assert.assertTrue("'" + boolean85 + "' != '" + false + "'", boolean85 == false);
        org.junit.Assert.assertNotNull(jSType86);
        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + true + "'", boolean87 == true);
        org.junit.Assert.assertNotNull(jSType92);
        org.junit.Assert.assertNotNull(jSType94);
        org.junit.Assert.assertNotNull(objectType95);
        org.junit.Assert.assertTrue("'" + boolean96 + "' != '" + false + "'", boolean96 == false);
        org.junit.Assert.assertTrue("'" + boolean97 + "' != '" + false + "'", boolean97 == false);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        com.google.javascript.jscomp.SourceAst sourceAst0 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(sourceAst0, "goog.exportSymbol", true);
        java.lang.String str4 = compilerInput3.getName();
        com.google.javascript.jscomp.JSModule jSModule6 = new com.google.javascript.jscomp.JSModule("goog.exportSymbol");
        compilerInput3.setModule(jSModule6);
        com.google.javascript.jscomp.JSModule jSModule8 = compilerInput3.getModule();
        boolean boolean10 = jSModule8.removeByName("function (function (this:me, {1825710392}): me, function (this:me, {824960787}): me): function (this:me, {291082378}): me");
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "goog.exportSymbol" + "'", str4.equals("goog.exportSymbol"));
        org.junit.Assert.assertNotNull(jSModule8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromCode("error", "");
        org.junit.Assert.assertNotNull(jSSourceFile2);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        com.google.javascript.rhino.jstype.JSType jSType3 = jSTypeRegistry1.getType("hi!");
        com.google.javascript.rhino.ErrorReporter errorReporter4 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter4);
        com.google.javascript.rhino.jstype.JSType jSType6 = null;
        com.google.javascript.rhino.jstype.JSType jSType8 = jSTypeRegistry5.getGreatestSubtypeWithProperty(jSType6, "");
        com.google.javascript.rhino.jstype.JSType jSType10 = jSType8.findPropertyType("");
        boolean boolean11 = jSType10.isArrayType();
        boolean boolean12 = jSType10.isNominalType();
        com.google.javascript.rhino.ErrorReporter errorReporter13 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry14 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter13);
        com.google.javascript.rhino.jstype.JSType jSType15 = null;
        com.google.javascript.rhino.jstype.JSType jSType17 = jSTypeRegistry14.getGreatestSubtypeWithProperty(jSType15, "");
        com.google.javascript.rhino.jstype.JSType jSType19 = jSType17.findPropertyType("");
        com.google.javascript.rhino.jstype.ObjectType objectType20 = jSType17.dereference();
        com.google.javascript.rhino.ErrorReporter errorReporter21 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry22 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter21);
        com.google.javascript.rhino.jstype.JSType jSType23 = null;
        com.google.javascript.rhino.jstype.JSType jSType25 = jSTypeRegistry22.getGreatestSubtypeWithProperty(jSType23, "");
        com.google.javascript.rhino.jstype.JSType jSType27 = jSType25.findPropertyType("");
        com.google.javascript.rhino.jstype.ObjectType objectType28 = jSType25.dereference();
        com.google.javascript.rhino.ErrorReporter errorReporter29 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry30 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter29);
        com.google.javascript.rhino.jstype.JSType jSType31 = null;
        com.google.javascript.rhino.jstype.JSType jSType33 = jSTypeRegistry30.getGreatestSubtypeWithProperty(jSType31, "");
        com.google.javascript.rhino.jstype.JSType jSType35 = jSType33.findPropertyType("");
        com.google.javascript.rhino.jstype.ObjectType objectType36 = jSType33.dereference();
        boolean boolean37 = objectType36.isOrdinaryFunction();
        boolean boolean38 = objectType36.isUnknownType();
        boolean boolean39 = objectType36.matchesUint32Context();
        com.google.javascript.rhino.jstype.JSType.TypePair typePair40 = objectType28.getTypesUnderShallowInequality((com.google.javascript.rhino.jstype.JSType) objectType36);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray41 = new com.google.javascript.rhino.jstype.JSType[] { objectType20, objectType28 };
        com.google.javascript.rhino.jstype.FunctionType functionType42 = jSTypeRegistry1.createFunctionType(jSType10, jSTypeArray41);
        java.util.Set set43 = functionType42.getOwnPropertyNames();
        com.google.javascript.rhino.ErrorReporter errorReporter44 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry45 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter44);
        com.google.javascript.rhino.jstype.JSType jSType47 = jSTypeRegistry45.getType("hi!");
        com.google.javascript.rhino.ErrorReporter errorReporter48 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry49 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter48);
        com.google.javascript.rhino.jstype.JSType jSType50 = null;
        com.google.javascript.rhino.jstype.JSType jSType52 = jSTypeRegistry49.getGreatestSubtypeWithProperty(jSType50, "");
        com.google.javascript.rhino.jstype.JSType jSType54 = jSType52.findPropertyType("");
        boolean boolean55 = jSType54.isArrayType();
        boolean boolean56 = jSType54.isNominalType();
        com.google.javascript.rhino.ErrorReporter errorReporter57 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry58 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter57);
        com.google.javascript.rhino.jstype.JSType jSType59 = null;
        com.google.javascript.rhino.jstype.JSType jSType61 = jSTypeRegistry58.getGreatestSubtypeWithProperty(jSType59, "");
        com.google.javascript.rhino.jstype.JSType jSType63 = jSType61.findPropertyType("");
        com.google.javascript.rhino.jstype.ObjectType objectType64 = jSType61.dereference();
        com.google.javascript.rhino.ErrorReporter errorReporter65 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry66 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter65);
        com.google.javascript.rhino.jstype.JSType jSType67 = null;
        com.google.javascript.rhino.jstype.JSType jSType69 = jSTypeRegistry66.getGreatestSubtypeWithProperty(jSType67, "");
        com.google.javascript.rhino.jstype.JSType jSType71 = jSType69.findPropertyType("");
        com.google.javascript.rhino.jstype.ObjectType objectType72 = jSType69.dereference();
        com.google.javascript.rhino.ErrorReporter errorReporter73 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry74 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter73);
        com.google.javascript.rhino.jstype.JSType jSType75 = null;
        com.google.javascript.rhino.jstype.JSType jSType77 = jSTypeRegistry74.getGreatestSubtypeWithProperty(jSType75, "");
        com.google.javascript.rhino.jstype.JSType jSType79 = jSType77.findPropertyType("");
        com.google.javascript.rhino.jstype.ObjectType objectType80 = jSType77.dereference();
        boolean boolean81 = objectType80.isOrdinaryFunction();
        boolean boolean82 = objectType80.isUnknownType();
        boolean boolean83 = objectType80.matchesUint32Context();
        com.google.javascript.rhino.jstype.JSType.TypePair typePair84 = objectType72.getTypesUnderShallowInequality((com.google.javascript.rhino.jstype.JSType) objectType80);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray85 = new com.google.javascript.rhino.jstype.JSType[] { objectType64, objectType72 };
        com.google.javascript.rhino.jstype.FunctionType functionType86 = jSTypeRegistry45.createFunctionType(jSType54, jSTypeArray85);
        boolean boolean87 = functionType42.hasEqualCallType(functionType86);
        boolean boolean89 = functionType86.isPropertyInExterns("function (function (this:me, {2050730232}): me, function (this:me, {2014515411}): me): function (this:me, {472884160}): me");
        org.junit.Assert.assertNull(jSType3);
        org.junit.Assert.assertNotNull(jSType8);
        org.junit.Assert.assertNotNull(jSType10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(jSType17);
        org.junit.Assert.assertNotNull(jSType19);
        org.junit.Assert.assertNotNull(objectType20);
        org.junit.Assert.assertNotNull(jSType25);
        org.junit.Assert.assertNotNull(jSType27);
        org.junit.Assert.assertNotNull(objectType28);
        org.junit.Assert.assertNotNull(jSType33);
        org.junit.Assert.assertNotNull(jSType35);
        org.junit.Assert.assertNotNull(objectType36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertNotNull(typePair40);
        org.junit.Assert.assertNotNull(jSTypeArray41);
        org.junit.Assert.assertNotNull(functionType42);
        org.junit.Assert.assertNotNull(set43);
        org.junit.Assert.assertNull(jSType47);
        org.junit.Assert.assertNotNull(jSType52);
        org.junit.Assert.assertNotNull(jSType54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertNotNull(jSType61);
        org.junit.Assert.assertNotNull(jSType63);
        org.junit.Assert.assertNotNull(objectType64);
        org.junit.Assert.assertNotNull(jSType69);
        org.junit.Assert.assertNotNull(jSType71);
        org.junit.Assert.assertNotNull(objectType72);
        org.junit.Assert.assertNotNull(jSType77);
        org.junit.Assert.assertNotNull(jSType79);
        org.junit.Assert.assertNotNull(objectType80);
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + false + "'", boolean81 == false);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + true + "'", boolean83 == true);
        org.junit.Assert.assertNotNull(typePair84);
        org.junit.Assert.assertNotNull(jSTypeArray85);
        org.junit.Assert.assertNotNull(functionType86);
        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + false + "'", boolean87 == false);
        org.junit.Assert.assertTrue("'" + boolean89 + "' != '" + false + "'", boolean89 == false);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newNumber((double) (short) 100, 0, (int) (byte) -1);
        node3.removeProp((int) (short) 1);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder6 = node3.getJsDocBuilderForNode();
        java.lang.Object obj8 = node3.getProp(2);
        java.lang.Object obj10 = node3.getProp(110);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder6);
        org.junit.Assert.assertNull(obj8);
        org.junit.Assert.assertNull(obj10);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newNumber((double) (short) 100, 0, (int) (byte) -1);
        java.lang.String str5 = node4.toString();
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder6 = node4.getJsDocBuilderForNode();
        boolean boolean7 = closureCodingConvention0.isVarArgsParameter(node4);
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.Node.newNumber((double) (short) 100, 0, (int) (byte) -1);
        node11.removeProp((int) (short) 1);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder14 = node11.getJsDocBuilderForNode();
        java.lang.Object obj16 = node11.getProp((-1));
        boolean boolean17 = closureCodingConvention0.isVarArgsParameter(node11);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode21 = new com.google.javascript.rhino.ScriptOrFnNode((int) (short) 0, (int) ' ', 33);
        boolean boolean22 = closureCodingConvention0.isOptionalParameter((com.google.javascript.rhino.Node) scriptOrFnNode21);
        com.google.javascript.rhino.ErrorReporter errorReporter23 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry24 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter23);
        com.google.javascript.rhino.jstype.JSType jSType25 = null;
        com.google.javascript.rhino.jstype.JSType jSType27 = jSTypeRegistry24.getGreatestSubtypeWithProperty(jSType25, "");
        com.google.javascript.rhino.jstype.JSType jSType29 = jSType27.findPropertyType("");
        com.google.javascript.rhino.jstype.ObjectType objectType30 = jSType27.dereference();
        com.google.javascript.rhino.ErrorReporter errorReporter31 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry32 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter31);
        com.google.javascript.rhino.jstype.JSType jSType33 = null;
        com.google.javascript.rhino.jstype.JSType jSType35 = jSTypeRegistry32.getGreatestSubtypeWithProperty(jSType33, "");
        com.google.javascript.rhino.jstype.JSType jSType37 = jSType35.findPropertyType("");
        com.google.javascript.rhino.jstype.ObjectType objectType38 = jSType35.dereference();
        boolean boolean39 = objectType38.isOrdinaryFunction();
        boolean boolean40 = objectType38.isUnknownType();
        boolean boolean41 = objectType38.matchesUint32Context();
        com.google.javascript.rhino.jstype.JSType.TypePair typePair42 = objectType30.getTypesUnderShallowInequality((com.google.javascript.rhino.jstype.JSType) objectType38);
        boolean boolean43 = objectType30.isRecordType();
        com.google.javascript.jscomp.DiagnosticType diagnosticType49 = com.google.javascript.jscomp.DiagnosticType.warning("Unknown class name", "Unknown class name");
        java.lang.String[] strArray51 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError52 = com.google.javascript.jscomp.JSError.make("hi!", 6, 13, diagnosticType49, strArray51);
        com.google.javascript.rhino.ErrorReporter errorReporter53 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry54 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter53);
        com.google.javascript.rhino.jstype.JSType jSType56 = jSTypeRegistry54.getType("hi!");
        com.google.javascript.rhino.Node node59 = com.google.javascript.rhino.Node.newNumber((double) (short) 0);
        com.google.javascript.rhino.ErrorReporter errorReporter60 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry61 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter60);
        com.google.javascript.rhino.jstype.JSType jSType62 = null;
        com.google.javascript.rhino.jstype.JSType jSType64 = jSTypeRegistry61.getGreatestSubtypeWithProperty(jSType62, "");
        com.google.javascript.rhino.jstype.JSType jSType66 = jSType64.findPropertyType("");
        com.google.javascript.rhino.jstype.ObjectType objectType67 = jSType64.dereference();
        boolean boolean68 = objectType67.isNumber();
        com.google.javascript.rhino.ErrorReporter errorReporter69 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry70 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter69);
        com.google.javascript.rhino.jstype.JSType jSType71 = null;
        com.google.javascript.rhino.jstype.JSType jSType73 = jSTypeRegistry70.getGreatestSubtypeWithProperty(jSType71, "");
        com.google.javascript.rhino.jstype.JSType jSType75 = jSType73.findPropertyType("");
        com.google.javascript.rhino.jstype.ObjectType objectType76 = jSType73.dereference();
        boolean boolean77 = objectType76.isNumber();
        com.google.javascript.rhino.jstype.JSType jSType78 = objectType67.getGreatestSubtype((com.google.javascript.rhino.jstype.JSType) objectType76);
        com.google.javascript.rhino.jstype.ObjectType objectType79 = jSTypeRegistry54.createObjectType("Not declared as a constructor", node59, objectType76);
        boolean boolean80 = objectType76.isNativeObjectType();
        boolean boolean81 = jSError52.equals((java.lang.Object) objectType76);
        boolean boolean82 = objectType30.isEquivalentTo((com.google.javascript.rhino.jstype.JSType) objectType76);
        scriptOrFnNode21.setJSType((com.google.javascript.rhino.jstype.JSType) objectType30);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "NUMBER 100.0" + "'", str5.equals("NUMBER 100.0"));
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder14);
        org.junit.Assert.assertNull(obj16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(jSType27);
        org.junit.Assert.assertNotNull(jSType29);
        org.junit.Assert.assertNotNull(objectType30);
        org.junit.Assert.assertNotNull(jSType35);
        org.junit.Assert.assertNotNull(jSType37);
        org.junit.Assert.assertNotNull(objectType38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
        org.junit.Assert.assertNotNull(typePair42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(diagnosticType49);
        org.junit.Assert.assertNotNull(strArray51);
        org.junit.Assert.assertNotNull(jSError52);
        org.junit.Assert.assertNull(jSType56);
        org.junit.Assert.assertNotNull(node59);
        org.junit.Assert.assertNotNull(jSType64);
        org.junit.Assert.assertNotNull(jSType66);
        org.junit.Assert.assertNotNull(objectType67);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + true + "'", boolean68 == true);
        org.junit.Assert.assertNotNull(jSType73);
        org.junit.Assert.assertNotNull(jSType75);
        org.junit.Assert.assertNotNull(objectType76);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + true + "'", boolean77 == true);
        org.junit.Assert.assertNotNull(jSType78);
        org.junit.Assert.assertNotNull(objectType79);
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + true + "'", boolean80 == true);
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + false + "'", boolean81 == false);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
    }

//    @Test
//    public void test054() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test054");
//        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
//        com.google.javascript.rhino.jstype.JSType jSType3 = jSTypeRegistry1.getType("hi!");
//        com.google.javascript.rhino.ErrorReporter errorReporter4 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter4);
//        com.google.javascript.rhino.jstype.JSType jSType6 = null;
//        com.google.javascript.rhino.jstype.JSType jSType8 = jSTypeRegistry5.getGreatestSubtypeWithProperty(jSType6, "");
//        com.google.javascript.rhino.jstype.JSType jSType10 = jSType8.findPropertyType("");
//        boolean boolean11 = jSType10.isArrayType();
//        boolean boolean12 = jSType10.isNominalType();
//        com.google.javascript.rhino.ErrorReporter errorReporter13 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry14 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter13);
//        com.google.javascript.rhino.jstype.JSType jSType15 = null;
//        com.google.javascript.rhino.jstype.JSType jSType17 = jSTypeRegistry14.getGreatestSubtypeWithProperty(jSType15, "");
//        com.google.javascript.rhino.jstype.JSType jSType19 = jSType17.findPropertyType("");
//        com.google.javascript.rhino.jstype.ObjectType objectType20 = jSType17.dereference();
//        com.google.javascript.rhino.ErrorReporter errorReporter21 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry22 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter21);
//        com.google.javascript.rhino.jstype.JSType jSType23 = null;
//        com.google.javascript.rhino.jstype.JSType jSType25 = jSTypeRegistry22.getGreatestSubtypeWithProperty(jSType23, "");
//        com.google.javascript.rhino.jstype.JSType jSType27 = jSType25.findPropertyType("");
//        com.google.javascript.rhino.jstype.ObjectType objectType28 = jSType25.dereference();
//        com.google.javascript.rhino.ErrorReporter errorReporter29 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry30 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter29);
//        com.google.javascript.rhino.jstype.JSType jSType31 = null;
//        com.google.javascript.rhino.jstype.JSType jSType33 = jSTypeRegistry30.getGreatestSubtypeWithProperty(jSType31, "");
//        com.google.javascript.rhino.jstype.JSType jSType35 = jSType33.findPropertyType("");
//        com.google.javascript.rhino.jstype.ObjectType objectType36 = jSType33.dereference();
//        boolean boolean37 = objectType36.isOrdinaryFunction();
//        boolean boolean38 = objectType36.isUnknownType();
//        boolean boolean39 = objectType36.matchesUint32Context();
//        com.google.javascript.rhino.jstype.JSType.TypePair typePair40 = objectType28.getTypesUnderShallowInequality((com.google.javascript.rhino.jstype.JSType) objectType36);
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray41 = new com.google.javascript.rhino.jstype.JSType[] { objectType20, objectType28 };
//        com.google.javascript.rhino.jstype.FunctionType functionType42 = jSTypeRegistry1.createFunctionType(jSType10, jSTypeArray41);
//        boolean boolean43 = functionType42.isReturnTypeInferred();
//        boolean boolean44 = functionType42.hasInstanceType();
//        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable45 = functionType42.getImplementedInterfaces();
//        java.lang.String str46 = functionType42.toDebugHashCodeString();
//        boolean boolean47 = functionType42.isOrdinaryFunction();
//        org.junit.Assert.assertNull(jSType3);
//        org.junit.Assert.assertNotNull(jSType8);
//        org.junit.Assert.assertNotNull(jSType10);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertNotNull(jSType17);
//        org.junit.Assert.assertNotNull(jSType19);
//        org.junit.Assert.assertNotNull(objectType20);
//        org.junit.Assert.assertNotNull(jSType25);
//        org.junit.Assert.assertNotNull(jSType27);
//        org.junit.Assert.assertNotNull(objectType28);
//        org.junit.Assert.assertNotNull(jSType33);
//        org.junit.Assert.assertNotNull(jSType35);
//        org.junit.Assert.assertNotNull(objectType36);
//        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
//        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
//        org.junit.Assert.assertNotNull(typePair40);
//        org.junit.Assert.assertNotNull(jSTypeArray41);
//        org.junit.Assert.assertNotNull(functionType42);
//        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
//        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
//        org.junit.Assert.assertNotNull(objectTypeIterable45);
//        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "function (function (this:me, {557852266}): me, function (this:me, {604752285}): me): function (this:me, {368269249}): me" + "'", str46.equals("function (function (this:me, {557852266}): me, function (this:me, {604752285}): me): function (this:me, {368269249}): me"));
//        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
//    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        com.google.javascript.rhino.jstype.JSType jSType3 = jSTypeRegistry1.getType("hi!");
        com.google.javascript.rhino.ErrorReporter errorReporter4 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter4);
        com.google.javascript.rhino.jstype.JSType jSType6 = null;
        com.google.javascript.rhino.jstype.JSType jSType8 = jSTypeRegistry5.getGreatestSubtypeWithProperty(jSType6, "");
        com.google.javascript.rhino.jstype.JSType jSType10 = jSType8.findPropertyType("");
        boolean boolean11 = jSType10.isArrayType();
        boolean boolean12 = jSType10.isNominalType();
        com.google.javascript.rhino.ErrorReporter errorReporter13 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry14 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter13);
        com.google.javascript.rhino.jstype.JSType jSType15 = null;
        com.google.javascript.rhino.jstype.JSType jSType17 = jSTypeRegistry14.getGreatestSubtypeWithProperty(jSType15, "");
        com.google.javascript.rhino.jstype.JSType jSType19 = jSType17.findPropertyType("");
        com.google.javascript.rhino.jstype.ObjectType objectType20 = jSType17.dereference();
        com.google.javascript.rhino.ErrorReporter errorReporter21 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry22 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter21);
        com.google.javascript.rhino.jstype.JSType jSType23 = null;
        com.google.javascript.rhino.jstype.JSType jSType25 = jSTypeRegistry22.getGreatestSubtypeWithProperty(jSType23, "");
        com.google.javascript.rhino.jstype.JSType jSType27 = jSType25.findPropertyType("");
        com.google.javascript.rhino.jstype.ObjectType objectType28 = jSType25.dereference();
        com.google.javascript.rhino.ErrorReporter errorReporter29 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry30 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter29);
        com.google.javascript.rhino.jstype.JSType jSType31 = null;
        com.google.javascript.rhino.jstype.JSType jSType33 = jSTypeRegistry30.getGreatestSubtypeWithProperty(jSType31, "");
        com.google.javascript.rhino.jstype.JSType jSType35 = jSType33.findPropertyType("");
        com.google.javascript.rhino.jstype.ObjectType objectType36 = jSType33.dereference();
        boolean boolean37 = objectType36.isOrdinaryFunction();
        boolean boolean38 = objectType36.isUnknownType();
        boolean boolean39 = objectType36.matchesUint32Context();
        com.google.javascript.rhino.jstype.JSType.TypePair typePair40 = objectType28.getTypesUnderShallowInequality((com.google.javascript.rhino.jstype.JSType) objectType36);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray41 = new com.google.javascript.rhino.jstype.JSType[] { objectType20, objectType28 };
        com.google.javascript.rhino.jstype.FunctionType functionType42 = jSTypeRegistry1.createFunctionType(jSType10, jSTypeArray41);
        java.util.Set set43 = functionType42.getOwnPropertyNames();
        com.google.javascript.rhino.ErrorReporter errorReporter44 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry45 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter44);
        com.google.javascript.rhino.jstype.JSType jSType47 = jSTypeRegistry45.getType("hi!");
        com.google.javascript.rhino.ErrorReporter errorReporter48 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry49 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter48);
        com.google.javascript.rhino.jstype.JSType jSType50 = null;
        com.google.javascript.rhino.jstype.JSType jSType52 = jSTypeRegistry49.getGreatestSubtypeWithProperty(jSType50, "");
        com.google.javascript.rhino.jstype.JSType jSType54 = jSType52.findPropertyType("");
        boolean boolean55 = jSType54.isArrayType();
        boolean boolean56 = jSType54.isNominalType();
        com.google.javascript.rhino.ErrorReporter errorReporter57 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry58 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter57);
        com.google.javascript.rhino.jstype.JSType jSType59 = null;
        com.google.javascript.rhino.jstype.JSType jSType61 = jSTypeRegistry58.getGreatestSubtypeWithProperty(jSType59, "");
        com.google.javascript.rhino.jstype.JSType jSType63 = jSType61.findPropertyType("");
        com.google.javascript.rhino.jstype.ObjectType objectType64 = jSType61.dereference();
        com.google.javascript.rhino.ErrorReporter errorReporter65 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry66 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter65);
        com.google.javascript.rhino.jstype.JSType jSType67 = null;
        com.google.javascript.rhino.jstype.JSType jSType69 = jSTypeRegistry66.getGreatestSubtypeWithProperty(jSType67, "");
        com.google.javascript.rhino.jstype.JSType jSType71 = jSType69.findPropertyType("");
        com.google.javascript.rhino.jstype.ObjectType objectType72 = jSType69.dereference();
        com.google.javascript.rhino.ErrorReporter errorReporter73 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry74 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter73);
        com.google.javascript.rhino.jstype.JSType jSType75 = null;
        com.google.javascript.rhino.jstype.JSType jSType77 = jSTypeRegistry74.getGreatestSubtypeWithProperty(jSType75, "");
        com.google.javascript.rhino.jstype.JSType jSType79 = jSType77.findPropertyType("");
        com.google.javascript.rhino.jstype.ObjectType objectType80 = jSType77.dereference();
        boolean boolean81 = objectType80.isOrdinaryFunction();
        boolean boolean82 = objectType80.isUnknownType();
        boolean boolean83 = objectType80.matchesUint32Context();
        com.google.javascript.rhino.jstype.JSType.TypePair typePair84 = objectType72.getTypesUnderShallowInequality((com.google.javascript.rhino.jstype.JSType) objectType80);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray85 = new com.google.javascript.rhino.jstype.JSType[] { objectType64, objectType72 };
        com.google.javascript.rhino.jstype.FunctionType functionType86 = jSTypeRegistry45.createFunctionType(jSType54, jSTypeArray85);
        boolean boolean87 = functionType42.hasEqualCallType(functionType86);
        boolean boolean88 = functionType86.matchesNumberContext();
        boolean boolean89 = functionType86.hasReferenceName();
        boolean boolean90 = functionType86.isRegexpType();
        org.junit.Assert.assertNull(jSType3);
        org.junit.Assert.assertNotNull(jSType8);
        org.junit.Assert.assertNotNull(jSType10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(jSType17);
        org.junit.Assert.assertNotNull(jSType19);
        org.junit.Assert.assertNotNull(objectType20);
        org.junit.Assert.assertNotNull(jSType25);
        org.junit.Assert.assertNotNull(jSType27);
        org.junit.Assert.assertNotNull(objectType28);
        org.junit.Assert.assertNotNull(jSType33);
        org.junit.Assert.assertNotNull(jSType35);
        org.junit.Assert.assertNotNull(objectType36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertNotNull(typePair40);
        org.junit.Assert.assertNotNull(jSTypeArray41);
        org.junit.Assert.assertNotNull(functionType42);
        org.junit.Assert.assertNotNull(set43);
        org.junit.Assert.assertNull(jSType47);
        org.junit.Assert.assertNotNull(jSType52);
        org.junit.Assert.assertNotNull(jSType54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertNotNull(jSType61);
        org.junit.Assert.assertNotNull(jSType63);
        org.junit.Assert.assertNotNull(objectType64);
        org.junit.Assert.assertNotNull(jSType69);
        org.junit.Assert.assertNotNull(jSType71);
        org.junit.Assert.assertNotNull(objectType72);
        org.junit.Assert.assertNotNull(jSType77);
        org.junit.Assert.assertNotNull(jSType79);
        org.junit.Assert.assertNotNull(objectType80);
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + false + "'", boolean81 == false);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + true + "'", boolean83 == true);
        org.junit.Assert.assertNotNull(typePair84);
        org.junit.Assert.assertNotNull(jSTypeArray85);
        org.junit.Assert.assertNotNull(functionType86);
        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + false + "'", boolean87 == false);
        org.junit.Assert.assertTrue("'" + boolean88 + "' != '" + false + "'", boolean88 == false);
        org.junit.Assert.assertTrue("'" + boolean89 + "' != '" + false + "'", boolean89 == false);
        org.junit.Assert.assertTrue("'" + boolean90 + "' != '" + false + "'", boolean90 == false);
    }

//    @Test
//    public void test056() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test056");
//        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray0 = new com.google.javascript.jscomp.WarningsGuard[] {};
//        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard1 = new com.google.javascript.jscomp.ComposeWarningsGuard(warningsGuardArray0);
//        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup2 = com.google.javascript.jscomp.DiagnosticGroups.ACCESS_CONTROLS;
//        boolean boolean3 = composeWarningsGuard1.enables(diagnosticGroup2);
//        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray4 = new com.google.javascript.jscomp.WarningsGuard[] { composeWarningsGuard1 };
//        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard5 = new com.google.javascript.jscomp.ComposeWarningsGuard(warningsGuardArray4);
//        org.junit.Assert.assertNotNull(warningsGuardArray0);
//        org.junit.Assert.assertNull(diagnosticGroup2);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertNotNull(warningsGuardArray4);
//    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode3 = new com.google.javascript.rhino.ScriptOrFnNode((int) (short) 0, (int) ' ', 33);
        java.lang.Object obj4 = scriptOrFnNode3.getCompilerData();
        boolean boolean6 = scriptOrFnNode3.hasParamOrVar("");
        com.google.javascript.rhino.jstype.JSType jSType7 = null;
        scriptOrFnNode3.setJSType(jSType7);
        org.junit.Assert.assertNull(obj4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        boolean boolean2 = closureCodingConvention0.isSuperClassReference("Named type with empty name component");
        boolean boolean4 = closureCodingConvention0.isConstant("{...}");
        com.google.javascript.rhino.Node node5 = null;
        boolean boolean6 = closureCodingConvention0.isVarArgsParameter(node5);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.Scope scope2 = compiler1.getTopScope();
        com.google.javascript.jscomp.PerformanceTracker performanceTracker3 = null;
        compiler1.tracker = performanceTracker3;
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter5 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler1);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile8 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "NUMBER 100.0");
        com.google.javascript.rhino.Node node9 = compiler1.parse(jSSourceFile8);
        com.google.javascript.jscomp.JSModule jSModule11 = new com.google.javascript.jscomp.JSModule("goog.exportSymbol");
        java.lang.String str12 = jSModule11.toString();
        java.lang.String str13 = compiler1.toSource(jSModule11);
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry14 = compiler1.getTypeRegistry();
        org.junit.Assert.assertNull(scope2);
        org.junit.Assert.assertNotNull(jSSourceFile8);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "goog.exportSymbol" + "'", str12.equals("goog.exportSymbol"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertNotNull(jSTypeRegistry14);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        com.google.javascript.jscomp.JSModule jSModule1 = new com.google.javascript.jscomp.JSModule("Not declared as a constructor");
        com.google.javascript.jscomp.JSModule jSModule3 = new com.google.javascript.jscomp.JSModule("Not declared as a constructor");
        java.nio.charset.Charset charset5 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile6 = com.google.javascript.jscomp.JSSourceFile.fromFile("Not declared as a constructor", charset5);
        java.lang.String str8 = jSSourceFile6.getLine(0);
        jSModule3.add(jSSourceFile6);
        java.util.List<java.lang.String> strList10 = jSModule3.getProvides();
        java.util.List<java.lang.String> strList11 = jSModule3.getRequires();
        jSModule1.addDependency(jSModule3);
        org.junit.Assert.assertNotNull(jSSourceFile6);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(strList10);
        org.junit.Assert.assertNotNull(strList11);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        com.google.javascript.rhino.EvaluatorException evaluatorException5 = new com.google.javascript.rhino.EvaluatorException("function (function (this:me, {1862285343}): me, function (this:me, {305162809}): me): function (this:me, {669223368}): me", "-1", (-1), "error", 13);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        com.google.javascript.rhino.jstype.JSType jSType3 = jSTypeRegistry1.getType("hi!");
        com.google.javascript.rhino.ErrorReporter errorReporter4 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter4);
        com.google.javascript.rhino.jstype.JSType jSType6 = null;
        com.google.javascript.rhino.jstype.JSType jSType8 = jSTypeRegistry5.getGreatestSubtypeWithProperty(jSType6, "");
        com.google.javascript.rhino.jstype.JSType jSType10 = jSType8.findPropertyType("");
        boolean boolean11 = jSType10.isArrayType();
        boolean boolean12 = jSType10.isNominalType();
        com.google.javascript.rhino.ErrorReporter errorReporter13 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry14 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter13);
        com.google.javascript.rhino.jstype.JSType jSType15 = null;
        com.google.javascript.rhino.jstype.JSType jSType17 = jSTypeRegistry14.getGreatestSubtypeWithProperty(jSType15, "");
        com.google.javascript.rhino.jstype.JSType jSType19 = jSType17.findPropertyType("");
        com.google.javascript.rhino.jstype.ObjectType objectType20 = jSType17.dereference();
        com.google.javascript.rhino.ErrorReporter errorReporter21 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry22 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter21);
        com.google.javascript.rhino.jstype.JSType jSType23 = null;
        com.google.javascript.rhino.jstype.JSType jSType25 = jSTypeRegistry22.getGreatestSubtypeWithProperty(jSType23, "");
        com.google.javascript.rhino.jstype.JSType jSType27 = jSType25.findPropertyType("");
        com.google.javascript.rhino.jstype.ObjectType objectType28 = jSType25.dereference();
        com.google.javascript.rhino.ErrorReporter errorReporter29 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry30 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter29);
        com.google.javascript.rhino.jstype.JSType jSType31 = null;
        com.google.javascript.rhino.jstype.JSType jSType33 = jSTypeRegistry30.getGreatestSubtypeWithProperty(jSType31, "");
        com.google.javascript.rhino.jstype.JSType jSType35 = jSType33.findPropertyType("");
        com.google.javascript.rhino.jstype.ObjectType objectType36 = jSType33.dereference();
        boolean boolean37 = objectType36.isOrdinaryFunction();
        boolean boolean38 = objectType36.isUnknownType();
        boolean boolean39 = objectType36.matchesUint32Context();
        com.google.javascript.rhino.jstype.JSType.TypePair typePair40 = objectType28.getTypesUnderShallowInequality((com.google.javascript.rhino.jstype.JSType) objectType36);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray41 = new com.google.javascript.rhino.jstype.JSType[] { objectType20, objectType28 };
        com.google.javascript.rhino.jstype.FunctionType functionType42 = jSTypeRegistry1.createFunctionType(jSType10, jSTypeArray41);
        java.util.Set set43 = functionType42.getOwnPropertyNames();
        com.google.javascript.rhino.ErrorReporter errorReporter44 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry45 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter44);
        com.google.javascript.rhino.jstype.JSType jSType47 = jSTypeRegistry45.getType("hi!");
        com.google.javascript.rhino.ErrorReporter errorReporter48 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry49 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter48);
        com.google.javascript.rhino.jstype.JSType jSType50 = null;
        com.google.javascript.rhino.jstype.JSType jSType52 = jSTypeRegistry49.getGreatestSubtypeWithProperty(jSType50, "");
        com.google.javascript.rhino.jstype.JSType jSType54 = jSType52.findPropertyType("");
        boolean boolean55 = jSType54.isArrayType();
        boolean boolean56 = jSType54.isNominalType();
        com.google.javascript.rhino.ErrorReporter errorReporter57 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry58 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter57);
        com.google.javascript.rhino.jstype.JSType jSType59 = null;
        com.google.javascript.rhino.jstype.JSType jSType61 = jSTypeRegistry58.getGreatestSubtypeWithProperty(jSType59, "");
        com.google.javascript.rhino.jstype.JSType jSType63 = jSType61.findPropertyType("");
        com.google.javascript.rhino.jstype.ObjectType objectType64 = jSType61.dereference();
        com.google.javascript.rhino.ErrorReporter errorReporter65 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry66 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter65);
        com.google.javascript.rhino.jstype.JSType jSType67 = null;
        com.google.javascript.rhino.jstype.JSType jSType69 = jSTypeRegistry66.getGreatestSubtypeWithProperty(jSType67, "");
        com.google.javascript.rhino.jstype.JSType jSType71 = jSType69.findPropertyType("");
        com.google.javascript.rhino.jstype.ObjectType objectType72 = jSType69.dereference();
        com.google.javascript.rhino.ErrorReporter errorReporter73 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry74 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter73);
        com.google.javascript.rhino.jstype.JSType jSType75 = null;
        com.google.javascript.rhino.jstype.JSType jSType77 = jSTypeRegistry74.getGreatestSubtypeWithProperty(jSType75, "");
        com.google.javascript.rhino.jstype.JSType jSType79 = jSType77.findPropertyType("");
        com.google.javascript.rhino.jstype.ObjectType objectType80 = jSType77.dereference();
        boolean boolean81 = objectType80.isOrdinaryFunction();
        boolean boolean82 = objectType80.isUnknownType();
        boolean boolean83 = objectType80.matchesUint32Context();
        com.google.javascript.rhino.jstype.JSType.TypePair typePair84 = objectType72.getTypesUnderShallowInequality((com.google.javascript.rhino.jstype.JSType) objectType80);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray85 = new com.google.javascript.rhino.jstype.JSType[] { objectType64, objectType72 };
        com.google.javascript.rhino.jstype.FunctionType functionType86 = jSTypeRegistry45.createFunctionType(jSType54, jSTypeArray85);
        boolean boolean87 = functionType42.hasEqualCallType(functionType86);
        boolean boolean88 = functionType86.matchesNumberContext();
        java.lang.String str89 = functionType86.getTemplateTypeName();
        boolean boolean90 = functionType86.isNativeObjectType();
        org.junit.Assert.assertNull(jSType3);
        org.junit.Assert.assertNotNull(jSType8);
        org.junit.Assert.assertNotNull(jSType10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(jSType17);
        org.junit.Assert.assertNotNull(jSType19);
        org.junit.Assert.assertNotNull(objectType20);
        org.junit.Assert.assertNotNull(jSType25);
        org.junit.Assert.assertNotNull(jSType27);
        org.junit.Assert.assertNotNull(objectType28);
        org.junit.Assert.assertNotNull(jSType33);
        org.junit.Assert.assertNotNull(jSType35);
        org.junit.Assert.assertNotNull(objectType36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertNotNull(typePair40);
        org.junit.Assert.assertNotNull(jSTypeArray41);
        org.junit.Assert.assertNotNull(functionType42);
        org.junit.Assert.assertNotNull(set43);
        org.junit.Assert.assertNull(jSType47);
        org.junit.Assert.assertNotNull(jSType52);
        org.junit.Assert.assertNotNull(jSType54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertNotNull(jSType61);
        org.junit.Assert.assertNotNull(jSType63);
        org.junit.Assert.assertNotNull(objectType64);
        org.junit.Assert.assertNotNull(jSType69);
        org.junit.Assert.assertNotNull(jSType71);
        org.junit.Assert.assertNotNull(objectType72);
        org.junit.Assert.assertNotNull(jSType77);
        org.junit.Assert.assertNotNull(jSType79);
        org.junit.Assert.assertNotNull(objectType80);
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + false + "'", boolean81 == false);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + true + "'", boolean83 == true);
        org.junit.Assert.assertNotNull(typePair84);
        org.junit.Assert.assertNotNull(jSTypeArray85);
        org.junit.Assert.assertNotNull(functionType86);
        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + false + "'", boolean87 == false);
        org.junit.Assert.assertTrue("'" + boolean88 + "' != '" + false + "'", boolean88 == false);
        org.junit.Assert.assertNull(str89);
        org.junit.Assert.assertTrue("'" + boolean90 + "' != '" + false + "'", boolean90 == false);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.Scope scope2 = compiler1.getTopScope();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile5 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "Not declared as a constructor");
        com.google.javascript.rhino.Node node6 = compiler1.parse(jSSourceFile5);
        int int7 = node6.getCharno();
        org.junit.Assert.assertNull(scope2);
        org.junit.Assert.assertNotNull(jSSourceFile5);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        com.google.javascript.rhino.jstype.JSType jSType3 = jSTypeRegistry1.getType("hi!");
        com.google.javascript.rhino.ErrorReporter errorReporter4 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter4);
        com.google.javascript.rhino.jstype.JSType jSType6 = null;
        com.google.javascript.rhino.jstype.JSType jSType8 = jSTypeRegistry5.getGreatestSubtypeWithProperty(jSType6, "");
        com.google.javascript.rhino.jstype.JSType jSType10 = jSType8.findPropertyType("");
        boolean boolean11 = jSType10.isArrayType();
        boolean boolean12 = jSType10.isNominalType();
        com.google.javascript.rhino.ErrorReporter errorReporter13 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry14 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter13);
        com.google.javascript.rhino.jstype.JSType jSType15 = null;
        com.google.javascript.rhino.jstype.JSType jSType17 = jSTypeRegistry14.getGreatestSubtypeWithProperty(jSType15, "");
        com.google.javascript.rhino.jstype.JSType jSType19 = jSType17.findPropertyType("");
        com.google.javascript.rhino.jstype.ObjectType objectType20 = jSType17.dereference();
        com.google.javascript.rhino.ErrorReporter errorReporter21 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry22 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter21);
        com.google.javascript.rhino.jstype.JSType jSType23 = null;
        com.google.javascript.rhino.jstype.JSType jSType25 = jSTypeRegistry22.getGreatestSubtypeWithProperty(jSType23, "");
        com.google.javascript.rhino.jstype.JSType jSType27 = jSType25.findPropertyType("");
        com.google.javascript.rhino.jstype.ObjectType objectType28 = jSType25.dereference();
        com.google.javascript.rhino.ErrorReporter errorReporter29 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry30 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter29);
        com.google.javascript.rhino.jstype.JSType jSType31 = null;
        com.google.javascript.rhino.jstype.JSType jSType33 = jSTypeRegistry30.getGreatestSubtypeWithProperty(jSType31, "");
        com.google.javascript.rhino.jstype.JSType jSType35 = jSType33.findPropertyType("");
        com.google.javascript.rhino.jstype.ObjectType objectType36 = jSType33.dereference();
        boolean boolean37 = objectType36.isOrdinaryFunction();
        boolean boolean38 = objectType36.isUnknownType();
        boolean boolean39 = objectType36.matchesUint32Context();
        com.google.javascript.rhino.jstype.JSType.TypePair typePair40 = objectType28.getTypesUnderShallowInequality((com.google.javascript.rhino.jstype.JSType) objectType36);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray41 = new com.google.javascript.rhino.jstype.JSType[] { objectType20, objectType28 };
        com.google.javascript.rhino.jstype.FunctionType functionType42 = jSTypeRegistry1.createFunctionType(jSType10, jSTypeArray41);
        boolean boolean43 = functionType42.isInterface();
        com.google.javascript.rhino.ErrorReporter errorReporter44 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry45 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter44);
        com.google.javascript.rhino.jstype.JSType jSType46 = null;
        com.google.javascript.rhino.jstype.JSType jSType48 = jSTypeRegistry45.getGreatestSubtypeWithProperty(jSType46, "");
        com.google.javascript.rhino.jstype.JSType jSType50 = jSType48.findPropertyType("");
        com.google.javascript.rhino.jstype.ObjectType objectType51 = jSType48.dereference();
        boolean boolean52 = objectType51.isNumber();
        com.google.javascript.rhino.ErrorReporter errorReporter53 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry54 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter53);
        com.google.javascript.rhino.jstype.JSType jSType55 = null;
        com.google.javascript.rhino.jstype.JSType jSType57 = jSTypeRegistry54.getGreatestSubtypeWithProperty(jSType55, "");
        com.google.javascript.rhino.jstype.JSType jSType59 = jSType57.findPropertyType("");
        com.google.javascript.rhino.jstype.ObjectType objectType60 = jSType57.dereference();
        boolean boolean61 = objectType60.isNumber();
        com.google.javascript.rhino.jstype.JSType jSType62 = objectType51.getGreatestSubtype((com.google.javascript.rhino.jstype.JSType) objectType60);
        boolean boolean63 = objectType60.isFunctionPrototypeType();
        com.google.javascript.rhino.jstype.JSType jSType64 = functionType42.getLeastSupertype((com.google.javascript.rhino.jstype.JSType) objectType60);
        functionType42.clearResolved();
        org.junit.Assert.assertNull(jSType3);
        org.junit.Assert.assertNotNull(jSType8);
        org.junit.Assert.assertNotNull(jSType10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(jSType17);
        org.junit.Assert.assertNotNull(jSType19);
        org.junit.Assert.assertNotNull(objectType20);
        org.junit.Assert.assertNotNull(jSType25);
        org.junit.Assert.assertNotNull(jSType27);
        org.junit.Assert.assertNotNull(objectType28);
        org.junit.Assert.assertNotNull(jSType33);
        org.junit.Assert.assertNotNull(jSType35);
        org.junit.Assert.assertNotNull(objectType36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertNotNull(typePair40);
        org.junit.Assert.assertNotNull(jSTypeArray41);
        org.junit.Assert.assertNotNull(functionType42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(jSType48);
        org.junit.Assert.assertNotNull(jSType50);
        org.junit.Assert.assertNotNull(objectType51);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
        org.junit.Assert.assertNotNull(jSType57);
        org.junit.Assert.assertNotNull(jSType59);
        org.junit.Assert.assertNotNull(objectType60);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + true + "'", boolean61 == true);
        org.junit.Assert.assertNotNull(jSType62);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertNotNull(jSType64);
    }

//    @Test
//    public void test065() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test065");
//        try {
//            com.google.javascript.rhino.EvaluatorException evaluatorException1 = com.google.javascript.rhino.Context.reportRuntimeError("function (function (this:me, {1825710392}): me, function (this:me, {824960787}): me): function (this:me, {291082378}): me");
//            org.junit.Assert.fail("Expected exception of type com.google.javascript.rhino.EvaluatorException; message: function (function (this:me, {1825710392}): me, function (this:me, {824960787}): me): function (this:me, {291082378}): me");
//        } catch (com.google.javascript.rhino.EvaluatorException e) {
//        }
//    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        com.google.javascript.rhino.jstype.JSType jSType3 = jSTypeRegistry1.getType("hi!");
        com.google.javascript.rhino.ErrorReporter errorReporter4 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter4);
        com.google.javascript.rhino.jstype.JSType jSType6 = null;
        com.google.javascript.rhino.jstype.JSType jSType8 = jSTypeRegistry5.getGreatestSubtypeWithProperty(jSType6, "");
        com.google.javascript.rhino.jstype.JSType jSType10 = jSType8.findPropertyType("");
        com.google.javascript.rhino.jstype.ObjectType objectType11 = jSType8.dereference();
        com.google.javascript.rhino.ErrorReporter errorReporter12 = null;
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope13 = null;
        com.google.javascript.rhino.jstype.JSType jSType14 = jSType8.forceResolve(errorReporter12, jSTypeStaticScope13);
        com.google.javascript.rhino.jstype.JSType jSType15 = jSTypeRegistry1.createOptionalNullableType(jSType8);
        com.google.javascript.rhino.ErrorReporter errorReporter16 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry17 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter16);
        com.google.javascript.rhino.jstype.JSType jSType19 = jSTypeRegistry17.getType("hi!");
        com.google.javascript.rhino.Node node22 = com.google.javascript.rhino.Node.newNumber((double) (short) 0);
        com.google.javascript.rhino.ErrorReporter errorReporter23 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry24 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter23);
        com.google.javascript.rhino.jstype.JSType jSType25 = null;
        com.google.javascript.rhino.jstype.JSType jSType27 = jSTypeRegistry24.getGreatestSubtypeWithProperty(jSType25, "");
        com.google.javascript.rhino.jstype.JSType jSType29 = jSType27.findPropertyType("");
        com.google.javascript.rhino.jstype.ObjectType objectType30 = jSType27.dereference();
        boolean boolean31 = objectType30.isNumber();
        com.google.javascript.rhino.ErrorReporter errorReporter32 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry33 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter32);
        com.google.javascript.rhino.jstype.JSType jSType34 = null;
        com.google.javascript.rhino.jstype.JSType jSType36 = jSTypeRegistry33.getGreatestSubtypeWithProperty(jSType34, "");
        com.google.javascript.rhino.jstype.JSType jSType38 = jSType36.findPropertyType("");
        com.google.javascript.rhino.jstype.ObjectType objectType39 = jSType36.dereference();
        boolean boolean40 = objectType39.isNumber();
        com.google.javascript.rhino.jstype.JSType jSType41 = objectType30.getGreatestSubtype((com.google.javascript.rhino.jstype.JSType) objectType39);
        com.google.javascript.rhino.jstype.ObjectType objectType42 = jSTypeRegistry17.createObjectType("Not declared as a constructor", node22, objectType39);
        com.google.javascript.rhino.jstype.JSType jSType43 = jSTypeRegistry1.createDefaultObjectUnion((com.google.javascript.rhino.jstype.JSType) objectType42);
        com.google.javascript.rhino.Node node47 = com.google.javascript.rhino.Node.newString("null.prototype", 20, 100);
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope49 = null;
        com.google.javascript.rhino.jstype.JSType jSType50 = jSTypeRegistry1.createFromTypeNodes(node47, "NUMBER -1.0 0", jSTypeStaticScope49);
        jSTypeRegistry1.setTemplateTypeName("function (function (this:me, {557852266}): me, function (this:me, {604752285}): me): function (this:me, {368269249}): me");
        org.junit.Assert.assertNull(jSType3);
        org.junit.Assert.assertNotNull(jSType8);
        org.junit.Assert.assertNotNull(jSType10);
        org.junit.Assert.assertNotNull(objectType11);
        org.junit.Assert.assertNotNull(jSType14);
        org.junit.Assert.assertNotNull(jSType15);
        org.junit.Assert.assertNull(jSType19);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertNotNull(jSType27);
        org.junit.Assert.assertNotNull(jSType29);
        org.junit.Assert.assertNotNull(objectType30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertNotNull(jSType36);
        org.junit.Assert.assertNotNull(jSType38);
        org.junit.Assert.assertNotNull(objectType39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertNotNull(jSType41);
        org.junit.Assert.assertNotNull(objectType42);
        org.junit.Assert.assertNotNull(jSType43);
        org.junit.Assert.assertNotNull(node47);
        org.junit.Assert.assertNotNull(jSType50);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newNumber((double) (short) 100, 0, (int) (byte) -1);
        com.google.javascript.rhino.Node node4 = node3.getParent();
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNull(node4);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        try {
            com.google.javascript.rhino.Context.reportWarning("function (function (this:me, {1100568350}): me, function (this:me, {1143600822}): me): function (this:me, {1364033037}): me", "<No stack trace available>", (int) (short) 0, "", 49);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: No Context associated with current Thread");
        } catch (java.lang.RuntimeException e) {
        }
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        int int0 = com.google.javascript.rhino.Node.IS_DISPATCHER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 46 + "'", int0 == 46);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention0 = new com.google.javascript.jscomp.GoogleCodingConvention();
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention1 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode5 = new com.google.javascript.rhino.ScriptOrFnNode((int) (short) 0, (int) ' ', 33);
        int int6 = scriptOrFnNode5.getEncodedSourceStart();
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newNumber((double) (short) 100, 0, (int) (byte) -1);
        java.lang.String str11 = node10.toString();
        java.lang.String str12 = closureCodingConvention1.extractClassNameIfRequire((com.google.javascript.rhino.Node) scriptOrFnNode5, node10);
        java.lang.String str13 = googleCodingConvention0.identifyTypeDefAssign((com.google.javascript.rhino.Node) scriptOrFnNode5);
        java.lang.String str14 = googleCodingConvention0.getGlobalObject();
        boolean boolean16 = googleCodingConvention0.isSuperClassReference("goog.exportProperty");
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.Node.newNumber((double) (short) 100, 0, (int) (byte) -1);
        node20.removeProp((int) (short) 1);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder23 = node20.getJsDocBuilderForNode();
        java.lang.Object obj25 = node20.getProp((-1));
        com.google.javascript.rhino.Node node29 = com.google.javascript.rhino.Node.newNumber((double) (-1.0f), 0, 48);
        node20.addChildToFront(node29);
        com.google.javascript.rhino.ErrorReporter errorReporter31 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry32 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter31);
        com.google.javascript.rhino.jstype.JSType jSType34 = jSTypeRegistry32.getType("hi!");
        com.google.javascript.rhino.ErrorReporter errorReporter35 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry36 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter35);
        com.google.javascript.rhino.jstype.JSType jSType37 = null;
        com.google.javascript.rhino.jstype.JSType jSType39 = jSTypeRegistry36.getGreatestSubtypeWithProperty(jSType37, "");
        com.google.javascript.rhino.jstype.JSType jSType41 = jSType39.findPropertyType("");
        boolean boolean42 = jSType41.isArrayType();
        boolean boolean43 = jSType41.isNominalType();
        com.google.javascript.rhino.ErrorReporter errorReporter44 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry45 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter44);
        com.google.javascript.rhino.jstype.JSType jSType46 = null;
        com.google.javascript.rhino.jstype.JSType jSType48 = jSTypeRegistry45.getGreatestSubtypeWithProperty(jSType46, "");
        com.google.javascript.rhino.jstype.JSType jSType50 = jSType48.findPropertyType("");
        com.google.javascript.rhino.jstype.ObjectType objectType51 = jSType48.dereference();
        com.google.javascript.rhino.ErrorReporter errorReporter52 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry53 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter52);
        com.google.javascript.rhino.jstype.JSType jSType54 = null;
        com.google.javascript.rhino.jstype.JSType jSType56 = jSTypeRegistry53.getGreatestSubtypeWithProperty(jSType54, "");
        com.google.javascript.rhino.jstype.JSType jSType58 = jSType56.findPropertyType("");
        com.google.javascript.rhino.jstype.ObjectType objectType59 = jSType56.dereference();
        com.google.javascript.rhino.ErrorReporter errorReporter60 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry61 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter60);
        com.google.javascript.rhino.jstype.JSType jSType62 = null;
        com.google.javascript.rhino.jstype.JSType jSType64 = jSTypeRegistry61.getGreatestSubtypeWithProperty(jSType62, "");
        com.google.javascript.rhino.jstype.JSType jSType66 = jSType64.findPropertyType("");
        com.google.javascript.rhino.jstype.ObjectType objectType67 = jSType64.dereference();
        boolean boolean68 = objectType67.isOrdinaryFunction();
        boolean boolean69 = objectType67.isUnknownType();
        boolean boolean70 = objectType67.matchesUint32Context();
        com.google.javascript.rhino.jstype.JSType.TypePair typePair71 = objectType59.getTypesUnderShallowInequality((com.google.javascript.rhino.jstype.JSType) objectType67);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray72 = new com.google.javascript.rhino.jstype.JSType[] { objectType51, objectType59 };
        com.google.javascript.rhino.jstype.FunctionType functionType73 = jSTypeRegistry32.createFunctionType(jSType41, jSTypeArray72);
        com.google.javascript.rhino.ErrorReporter errorReporter74 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry75 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter74);
        com.google.javascript.rhino.jstype.JSType jSType76 = null;
        com.google.javascript.rhino.jstype.JSType jSType78 = jSTypeRegistry75.getGreatestSubtypeWithProperty(jSType76, "");
        com.google.javascript.rhino.jstype.JSType jSType80 = jSType78.findPropertyType("");
        com.google.javascript.rhino.jstype.ObjectType objectType81 = jSType78.dereference();
        boolean boolean82 = objectType81.isOrdinaryFunction();
        boolean boolean83 = objectType81.isUnknownType();
        boolean boolean84 = objectType81.matchesUint32Context();
        boolean boolean85 = objectType81.isNullable();
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode89 = new com.google.javascript.rhino.ScriptOrFnNode((int) (short) 0, (int) ' ', 33);
        int int90 = scriptOrFnNode89.getEncodedSourceStart();
        com.google.javascript.rhino.jstype.FunctionType functionType91 = jSTypeRegistry32.createFunctionType((com.google.javascript.rhino.jstype.JSType) objectType81, (com.google.javascript.rhino.Node) scriptOrFnNode89);
        scriptOrFnNode89.setSourceName("function (function (this:me, {977034666}): me, function (this:me, {2129390726}): me): function (this:me, {1973436143}): me");
        java.lang.String str94 = googleCodingConvention0.extractClassNameIfProvide(node20, (com.google.javascript.rhino.Node) scriptOrFnNode89);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "NUMBER 100.0" + "'", str11.equals("NUMBER 100.0"));
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "goog.global" + "'", str14.equals("goog.global"));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder23);
        org.junit.Assert.assertNull(obj25);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNull(jSType34);
        org.junit.Assert.assertNotNull(jSType39);
        org.junit.Assert.assertNotNull(jSType41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(jSType48);
        org.junit.Assert.assertNotNull(jSType50);
        org.junit.Assert.assertNotNull(objectType51);
        org.junit.Assert.assertNotNull(jSType56);
        org.junit.Assert.assertNotNull(jSType58);
        org.junit.Assert.assertNotNull(objectType59);
        org.junit.Assert.assertNotNull(jSType64);
        org.junit.Assert.assertNotNull(jSType66);
        org.junit.Assert.assertNotNull(objectType67);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + true + "'", boolean70 == true);
        org.junit.Assert.assertNotNull(typePair71);
        org.junit.Assert.assertNotNull(jSTypeArray72);
        org.junit.Assert.assertNotNull(functionType73);
        org.junit.Assert.assertNotNull(jSType78);
        org.junit.Assert.assertNotNull(jSType80);
        org.junit.Assert.assertNotNull(objectType81);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + false + "'", boolean83 == false);
        org.junit.Assert.assertTrue("'" + boolean84 + "' != '" + true + "'", boolean84 == true);
        org.junit.Assert.assertTrue("'" + boolean85 + "' != '" + true + "'", boolean85 == true);
        org.junit.Assert.assertTrue("'" + int90 + "' != '" + 0 + "'", int90 == 0);
        org.junit.Assert.assertNotNull(functionType91);
        org.junit.Assert.assertNull(str94);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        java.util.Set<com.google.javascript.rhino.jstype.ObjectType> objectTypeSet3 = jSTypeRegistry1.getTypesWithProperty("");
        com.google.javascript.rhino.ErrorReporter errorReporter4 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter4);
        com.google.javascript.rhino.jstype.JSType jSType6 = null;
        com.google.javascript.rhino.jstype.JSType jSType8 = jSTypeRegistry5.getGreatestSubtypeWithProperty(jSType6, "");
        com.google.javascript.rhino.jstype.JSType jSType10 = jSType8.findPropertyType("");
        com.google.javascript.rhino.ErrorReporter errorReporter11 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry12 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter11);
        com.google.javascript.rhino.jstype.JSType jSType13 = null;
        com.google.javascript.rhino.jstype.JSType jSType15 = jSTypeRegistry12.getGreatestSubtypeWithProperty(jSType13, "");
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray16 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.Node node17 = jSTypeRegistry12.createOptionalParameters(jSTypeArray16);
        com.google.javascript.rhino.jstype.FunctionType functionType18 = jSTypeRegistry1.createFunctionTypeWithVarArgs(jSType8, jSTypeArray16);
        java.util.Set<java.lang.String> strSet19 = functionType18.getOwnPropertyNames();
        boolean boolean20 = functionType18.isInterface();
        com.google.javascript.rhino.ErrorReporter errorReporter21 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry22 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter21);
        com.google.javascript.rhino.jstype.JSType jSType23 = null;
        com.google.javascript.rhino.jstype.JSType jSType25 = jSTypeRegistry22.getGreatestSubtypeWithProperty(jSType23, "");
        com.google.javascript.rhino.jstype.JSType jSType27 = jSType25.findPropertyType("");
        com.google.javascript.rhino.jstype.ObjectType objectType28 = jSType25.dereference();
        boolean boolean29 = objectType28.isOrdinaryFunction();
        boolean boolean30 = objectType28.isUnknownType();
        boolean boolean31 = objectType28.matchesUint32Context();
        boolean boolean32 = objectType28.isNullable();
        com.google.javascript.rhino.jstype.ObjectType objectType33 = objectType28.dereference();
        com.google.javascript.rhino.jstype.JSType.TypePair typePair34 = functionType18.getTypesUnderShallowEquality((com.google.javascript.rhino.jstype.JSType) objectType33);
        boolean boolean35 = objectType33.isNullable();
        org.junit.Assert.assertNotNull(objectTypeSet3);
        org.junit.Assert.assertNotNull(jSType8);
        org.junit.Assert.assertNotNull(jSType10);
        org.junit.Assert.assertNotNull(jSType15);
        org.junit.Assert.assertNotNull(jSTypeArray16);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(functionType18);
        org.junit.Assert.assertNotNull(strSet19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(jSType25);
        org.junit.Assert.assertNotNull(jSType27);
        org.junit.Assert.assertNotNull(objectType28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNotNull(objectType33);
        org.junit.Assert.assertNotNull(typePair34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newNumber((double) (short) 100, 0, (int) (byte) -1);
        node3.removeProp((int) (short) 1);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder6 = node3.getJsDocBuilderForNode();
        java.lang.Object obj8 = node3.getProp((-1));
        try {
            int int10 = node3.getExistingIntProp(33);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: FAILED ASSERTION");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder6);
        org.junit.Assert.assertNull(obj8);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newNumber((double) (short) 100, 0, (int) (byte) -1);
        node3.removeProp((int) (short) 1);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder6 = node3.getJsDocBuilderForNode();
        boolean boolean7 = node3.wasEmptyNode();
        com.google.javascript.rhino.ErrorReporter errorReporter8 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry9 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter8);
        com.google.javascript.rhino.jstype.JSType jSType10 = null;
        com.google.javascript.rhino.jstype.JSType jSType12 = jSTypeRegistry9.getGreatestSubtypeWithProperty(jSType10, "");
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray13 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.Node node14 = jSTypeRegistry9.createOptionalParameters(jSTypeArray13);
        boolean boolean15 = node3.checkTreeEqualsSilent(node14);
        com.google.javascript.rhino.Node node16 = node3.getParent();
        com.google.javascript.jscomp.MessageFormatter messageFormatter17 = null;
        java.util.logging.Logger logger18 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager19 = new com.google.javascript.jscomp.LoggerErrorManager(messageFormatter17, logger18);
        com.google.javascript.jscomp.Compiler compiler20 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager19);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile23 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "NUMBER 100.0");
        com.google.javascript.rhino.Node node24 = compiler20.parse(jSSourceFile23);
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention25 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node29 = com.google.javascript.rhino.Node.newNumber((double) (short) 100, 0, (int) (byte) -1);
        java.lang.String str30 = node29.toString();
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder31 = node29.getJsDocBuilderForNode();
        boolean boolean32 = closureCodingConvention25.isVarArgsParameter(node29);
        try {
            node16.addChildAfter(node24, node29);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(jSType12);
        org.junit.Assert.assertNotNull(jSTypeArray13);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNull(node16);
        org.junit.Assert.assertNotNull(jSSourceFile23);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "NUMBER 100.0" + "'", str30.equals("NUMBER 100.0"));
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        java.io.InputStream inputStream1 = null;
        try {
            com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromInputStream("", inputStream1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        com.google.javascript.rhino.jstype.JSType jSType2 = null;
        com.google.javascript.rhino.jstype.JSType jSType4 = jSTypeRegistry1.getGreatestSubtypeWithProperty(jSType2, "");
        boolean boolean5 = jSType4.isAllType();
        com.google.javascript.rhino.jstype.JSType jSType6 = jSType4.restrictByNotNullOrUndefined();
        boolean boolean7 = jSType4.isAllType();
        org.junit.Assert.assertNotNull(jSType4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(jSType6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        com.google.javascript.jscomp.SourceAst sourceAst0 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(sourceAst0, "goog.exportSymbol", true);
        java.lang.String str4 = compilerInput3.getName();
        try {
            java.util.Collection<java.lang.String> strCollection5 = compilerInput3.getProvides();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Expected setErrorManager to be called first");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "goog.exportSymbol" + "'", str4.equals("goog.exportSymbol"));
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        com.google.javascript.rhino.jstype.JSType jSType2 = null;
        com.google.javascript.rhino.jstype.JSType jSType4 = jSTypeRegistry1.getGreatestSubtypeWithProperty(jSType2, "");
        com.google.javascript.rhino.jstype.JSType jSType6 = jSType4.findPropertyType("");
        com.google.javascript.rhino.jstype.ObjectType objectType7 = jSType4.dereference();
        boolean boolean8 = objectType7.isOrdinaryFunction();
        boolean boolean9 = objectType7.isUnknownType();
        boolean boolean10 = objectType7.matchesUint32Context();
        boolean boolean11 = objectType7.isNullable();
        com.google.javascript.rhino.jstype.ObjectType objectType12 = objectType7.dereference();
        com.google.javascript.rhino.ErrorReporter errorReporter13 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry14 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter13);
        java.util.Set<com.google.javascript.rhino.jstype.ObjectType> objectTypeSet16 = jSTypeRegistry14.getTypesWithProperty("");
        com.google.javascript.rhino.ErrorReporter errorReporter17 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry18 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter17);
        com.google.javascript.rhino.jstype.JSType jSType19 = null;
        com.google.javascript.rhino.jstype.JSType jSType21 = jSTypeRegistry18.getGreatestSubtypeWithProperty(jSType19, "");
        com.google.javascript.rhino.jstype.JSType jSType23 = jSType21.findPropertyType("");
        com.google.javascript.rhino.ErrorReporter errorReporter24 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry25 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter24);
        com.google.javascript.rhino.jstype.JSType jSType26 = null;
        com.google.javascript.rhino.jstype.JSType jSType28 = jSTypeRegistry25.getGreatestSubtypeWithProperty(jSType26, "");
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray29 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.Node node30 = jSTypeRegistry25.createOptionalParameters(jSTypeArray29);
        com.google.javascript.rhino.jstype.FunctionType functionType31 = jSTypeRegistry14.createFunctionTypeWithVarArgs(jSType21, jSTypeArray29);
        java.util.Set<java.lang.String> strSet32 = functionType31.getOwnPropertyNames();
        boolean boolean34 = functionType31.isPropertyInExterns("function (function (this:me, {1825710392}): me, function (this:me, {824960787}): me): function (this:me, {291082378}): me");
        com.google.javascript.rhino.jstype.JSType.TypePair typePair35 = objectType7.getTypesUnderShallowEquality((com.google.javascript.rhino.jstype.JSType) functionType31);
        com.google.javascript.rhino.JSDocInfo jSDocInfo36 = functionType31.getJSDocInfo();
        org.junit.Assert.assertNotNull(jSType4);
        org.junit.Assert.assertNotNull(jSType6);
        org.junit.Assert.assertNotNull(objectType7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(objectType12);
        org.junit.Assert.assertNotNull(objectTypeSet16);
        org.junit.Assert.assertNotNull(jSType21);
        org.junit.Assert.assertNotNull(jSType23);
        org.junit.Assert.assertNotNull(jSType28);
        org.junit.Assert.assertNotNull(jSTypeArray29);
        org.junit.Assert.assertNotNull(node30);
        org.junit.Assert.assertNotNull(functionType31);
        org.junit.Assert.assertNotNull(strSet32);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(typePair35);
        org.junit.Assert.assertNull(jSDocInfo36);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        int int0 = com.google.javascript.rhino.Node.ATTRIBUTE_FLAG;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.Scope scope2 = compiler1.getTopScope();
        com.google.javascript.jscomp.PerformanceTracker performanceTracker3 = null;
        compiler1.tracker = performanceTracker3;
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter5 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler1);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile8 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "NUMBER 100.0");
        com.google.javascript.rhino.Node node9 = compiler1.parse(jSSourceFile8);
        com.google.javascript.jscomp.JSModule jSModule11 = new com.google.javascript.jscomp.JSModule("goog.exportSymbol");
        java.lang.String str12 = jSModule11.toString();
        java.lang.String str13 = compiler1.toSource(jSModule11);
        boolean boolean14 = compiler1.hasErrors();
        org.junit.Assert.assertNull(scope2);
        org.junit.Assert.assertNotNull(jSSourceFile8);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "goog.exportSymbol" + "'", str12.equals("goog.exportSymbol"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        boolean boolean2 = closureCodingConvention0.isSuperClassReference("Named type with empty name component");
        boolean boolean5 = closureCodingConvention0.isExported("goog.abstractMethod", true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        int int0 = com.google.javascript.rhino.Node.IS_CONSTANT_NAME;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 42 + "'", int0 == 42);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newNumber((double) (short) 100, 0, (int) (byte) -1);
        java.lang.String str4 = node3.toString();
        node3.detachChildren();
        node3.detachChildren();
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "NUMBER 100.0" + "'", str4.equals("NUMBER 100.0"));
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.jstype.JSType jSType3 = null;
        com.google.javascript.rhino.ErrorReporter errorReporter4 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter4);
        com.google.javascript.rhino.jstype.JSType jSType7 = jSTypeRegistry5.getType("hi!");
        com.google.javascript.rhino.ErrorReporter errorReporter8 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry9 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter8);
        com.google.javascript.rhino.jstype.JSType jSType10 = null;
        com.google.javascript.rhino.jstype.JSType jSType12 = jSTypeRegistry9.getGreatestSubtypeWithProperty(jSType10, "");
        com.google.javascript.rhino.jstype.JSType jSType14 = jSType12.findPropertyType("");
        boolean boolean15 = jSType14.isArrayType();
        boolean boolean16 = jSType14.isNominalType();
        com.google.javascript.rhino.ErrorReporter errorReporter17 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry18 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter17);
        com.google.javascript.rhino.jstype.JSType jSType19 = null;
        com.google.javascript.rhino.jstype.JSType jSType21 = jSTypeRegistry18.getGreatestSubtypeWithProperty(jSType19, "");
        com.google.javascript.rhino.jstype.JSType jSType23 = jSType21.findPropertyType("");
        com.google.javascript.rhino.jstype.ObjectType objectType24 = jSType21.dereference();
        com.google.javascript.rhino.ErrorReporter errorReporter25 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry26 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter25);
        com.google.javascript.rhino.jstype.JSType jSType27 = null;
        com.google.javascript.rhino.jstype.JSType jSType29 = jSTypeRegistry26.getGreatestSubtypeWithProperty(jSType27, "");
        com.google.javascript.rhino.jstype.JSType jSType31 = jSType29.findPropertyType("");
        com.google.javascript.rhino.jstype.ObjectType objectType32 = jSType29.dereference();
        com.google.javascript.rhino.ErrorReporter errorReporter33 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry34 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter33);
        com.google.javascript.rhino.jstype.JSType jSType35 = null;
        com.google.javascript.rhino.jstype.JSType jSType37 = jSTypeRegistry34.getGreatestSubtypeWithProperty(jSType35, "");
        com.google.javascript.rhino.jstype.JSType jSType39 = jSType37.findPropertyType("");
        com.google.javascript.rhino.jstype.ObjectType objectType40 = jSType37.dereference();
        boolean boolean41 = objectType40.isOrdinaryFunction();
        boolean boolean42 = objectType40.isUnknownType();
        boolean boolean43 = objectType40.matchesUint32Context();
        com.google.javascript.rhino.jstype.JSType.TypePair typePair44 = objectType32.getTypesUnderShallowInequality((com.google.javascript.rhino.jstype.JSType) objectType40);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray45 = new com.google.javascript.rhino.jstype.JSType[] { objectType24, objectType32 };
        com.google.javascript.rhino.jstype.FunctionType functionType46 = jSTypeRegistry5.createFunctionType(jSType14, jSTypeArray45);
        com.google.javascript.rhino.jstype.FunctionType functionType47 = jSTypeRegistry2.createConstructorTypeWithVarArgs(jSType3, jSTypeArray45);
        com.google.javascript.rhino.jstype.JSType jSType52 = jSTypeRegistry2.createNamedType("goog.exportSymbol", "function (function (this:me, {1100568350}): me, function (this:me, {1143600822}): me): function (this:me, {1364033037}): me", 0, 31);
        org.junit.Assert.assertNull(jSType7);
        org.junit.Assert.assertNotNull(jSType12);
        org.junit.Assert.assertNotNull(jSType14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(jSType21);
        org.junit.Assert.assertNotNull(jSType23);
        org.junit.Assert.assertNotNull(objectType24);
        org.junit.Assert.assertNotNull(jSType29);
        org.junit.Assert.assertNotNull(jSType31);
        org.junit.Assert.assertNotNull(objectType32);
        org.junit.Assert.assertNotNull(jSType37);
        org.junit.Assert.assertNotNull(jSType39);
        org.junit.Assert.assertNotNull(objectType40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertNotNull(typePair44);
        org.junit.Assert.assertNotNull(jSTypeArray45);
        org.junit.Assert.assertNotNull(functionType46);
        org.junit.Assert.assertNotNull(functionType47);
        org.junit.Assert.assertNotNull(jSType52);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.Scope scope2 = compiler1.getTopScope();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile5 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "Not declared as a constructor");
        com.google.javascript.rhino.Node node6 = compiler1.parse(jSSourceFile5);
        com.google.javascript.jscomp.SourceExcerptProvider.SourceExcerpt sourceExcerpt7 = null;
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter8 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler1, sourceExcerpt7);
        java.nio.charset.Charset charset10 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile11 = com.google.javascript.jscomp.JSSourceFile.fromFile("Not declared as a constructor", charset10);
        com.google.javascript.jscomp.JSModule jSModule13 = new com.google.javascript.jscomp.JSModule("Not declared as a constructor");
        java.nio.charset.Charset charset15 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile16 = com.google.javascript.jscomp.JSSourceFile.fromFile("Not declared as a constructor", charset15);
        java.lang.String str18 = jSSourceFile16.getLine(0);
        jSModule13.add(jSSourceFile16);
        com.google.javascript.jscomp.CompilerOptions compilerOptions20 = null;
        try {
            com.google.javascript.jscomp.Result result21 = compiler1.compile(jSSourceFile11, jSSourceFile16, compilerOptions20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(scope2);
        org.junit.Assert.assertNotNull(jSSourceFile5);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(jSSourceFile11);
        org.junit.Assert.assertNotNull(jSSourceFile16);
        org.junit.Assert.assertNull(str18);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        com.google.javascript.jscomp.SourceAst sourceAst0 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(sourceAst0, "goog.exportSymbol", true);
        java.lang.String str4 = compilerInput3.getName();
        com.google.javascript.jscomp.JSModule jSModule6 = new com.google.javascript.jscomp.JSModule("goog.exportSymbol");
        compilerInput3.setModule(jSModule6);
        java.util.Set<com.google.javascript.jscomp.JSModule> jSModuleSet8 = jSModule6.getAllDependencies();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "goog.exportSymbol" + "'", str4.equals("goog.exportSymbol"));
        org.junit.Assert.assertNotNull(jSModuleSet8);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        java.util.Set<com.google.javascript.rhino.jstype.ObjectType> objectTypeSet3 = jSTypeRegistry1.getTypesWithProperty("");
        com.google.javascript.rhino.ErrorReporter errorReporter4 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter4);
        com.google.javascript.rhino.jstype.JSType jSType6 = null;
        com.google.javascript.rhino.jstype.JSType jSType8 = jSTypeRegistry5.getGreatestSubtypeWithProperty(jSType6, "");
        com.google.javascript.rhino.jstype.JSType jSType10 = jSType8.findPropertyType("");
        com.google.javascript.rhino.ErrorReporter errorReporter11 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry12 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter11);
        com.google.javascript.rhino.jstype.JSType jSType13 = null;
        com.google.javascript.rhino.jstype.JSType jSType15 = jSTypeRegistry12.getGreatestSubtypeWithProperty(jSType13, "");
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray16 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.Node node17 = jSTypeRegistry12.createOptionalParameters(jSTypeArray16);
        com.google.javascript.rhino.jstype.FunctionType functionType18 = jSTypeRegistry1.createFunctionTypeWithVarArgs(jSType8, jSTypeArray16);
        java.util.Set<java.lang.String> strSet19 = functionType18.getOwnPropertyNames();
        boolean boolean20 = functionType18.isInterface();
        boolean boolean21 = functionType18.canBeCalled();
        int int22 = functionType18.getMinArguments();
        org.junit.Assert.assertNotNull(objectTypeSet3);
        org.junit.Assert.assertNotNull(jSType8);
        org.junit.Assert.assertNotNull(jSType10);
        org.junit.Assert.assertNotNull(jSType15);
        org.junit.Assert.assertNotNull(jSTypeArray16);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(functionType18);
        org.junit.Assert.assertNotNull(strSet19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        com.google.javascript.rhino.jstype.JSType jSType2 = null;
        com.google.javascript.rhino.jstype.JSType jSType4 = jSTypeRegistry1.getGreatestSubtypeWithProperty(jSType2, "");
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newNumber((double) (short) 100, 0, (int) (byte) -1);
        node9.removeProp((int) (short) 1);
        com.google.javascript.rhino.Node node12 = node9.removeFirstChild();
        com.google.javascript.rhino.ErrorReporter errorReporter13 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry14 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter13);
        java.util.Set<com.google.javascript.rhino.jstype.ObjectType> objectTypeSet16 = jSTypeRegistry14.getTypesWithProperty("");
        com.google.javascript.rhino.ErrorReporter errorReporter17 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry18 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter17);
        com.google.javascript.rhino.jstype.JSType jSType19 = null;
        com.google.javascript.rhino.jstype.JSType jSType21 = jSTypeRegistry18.getGreatestSubtypeWithProperty(jSType19, "");
        com.google.javascript.rhino.jstype.JSType jSType23 = jSType21.findPropertyType("");
        com.google.javascript.rhino.ErrorReporter errorReporter24 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry25 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter24);
        com.google.javascript.rhino.jstype.JSType jSType26 = null;
        com.google.javascript.rhino.jstype.JSType jSType28 = jSTypeRegistry25.getGreatestSubtypeWithProperty(jSType26, "");
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray29 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.Node node30 = jSTypeRegistry25.createOptionalParameters(jSTypeArray29);
        com.google.javascript.rhino.jstype.FunctionType functionType31 = jSTypeRegistry14.createFunctionTypeWithVarArgs(jSType21, jSTypeArray29);
        com.google.javascript.rhino.jstype.ObjectType objectType32 = jSTypeRegistry1.createObjectType("Unknown class name", node9, (com.google.javascript.rhino.jstype.ObjectType) functionType31);
        try {
            com.google.javascript.rhino.jstype.JSType jSType34 = functionType31.getTopMostDefiningType("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(jSType4);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNull(node12);
        org.junit.Assert.assertNotNull(objectTypeSet16);
        org.junit.Assert.assertNotNull(jSType21);
        org.junit.Assert.assertNotNull(jSType23);
        org.junit.Assert.assertNotNull(jSType28);
        org.junit.Assert.assertNotNull(jSTypeArray29);
        org.junit.Assert.assertNotNull(node30);
        org.junit.Assert.assertNotNull(functionType31);
        org.junit.Assert.assertNotNull(objectType32);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        com.google.javascript.rhino.EvaluatorException evaluatorException1 = new com.google.javascript.rhino.EvaluatorException("hi!");
        java.lang.String str2 = evaluatorException1.details();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hi!" + "'", str2.equals("hi!"));
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        com.google.javascript.rhino.Parser parser0 = null;
        java.io.Reader reader1 = null;
        com.google.javascript.rhino.TokenStream tokenStream4 = new com.google.javascript.rhino.TokenStream(parser0, reader1, "Not declared as a constructor", 0);
        int int5 = tokenStream4.getTokenno();
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newNumber((double) (short) 100, 0, (int) (byte) -1);
        java.lang.String str10 = node9.toString();
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder11 = node9.getJsDocBuilderForNode();
        tokenStream4.setFileLevelJsDocBuilder(fileLevelJsDocBuilder11);
        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.Node.newNumber((double) (short) 100, 0, (int) (byte) -1);
        node16.removeProp((int) (short) 1);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder19 = node16.getJsDocBuilderForNode();
        tokenStream4.setFileLevelJsDocBuilder(fileLevelJsDocBuilder19);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "NUMBER 100.0" + "'", str10.equals("NUMBER 100.0"));
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder11);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder19);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention0 = new com.google.javascript.jscomp.GoogleCodingConvention();
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention1 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode5 = new com.google.javascript.rhino.ScriptOrFnNode((int) (short) 0, (int) ' ', 33);
        int int6 = scriptOrFnNode5.getEncodedSourceStart();
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newNumber((double) (short) 100, 0, (int) (byte) -1);
        java.lang.String str11 = node10.toString();
        java.lang.String str12 = closureCodingConvention1.extractClassNameIfRequire((com.google.javascript.rhino.Node) scriptOrFnNode5, node10);
        java.lang.String str13 = googleCodingConvention0.identifyTypeDefAssign((com.google.javascript.rhino.Node) scriptOrFnNode5);
        java.lang.String str14 = googleCodingConvention0.getGlobalObject();
        boolean boolean16 = googleCodingConvention0.isSuperClassReference("goog.exportProperty");
        java.lang.String str17 = googleCodingConvention0.getGlobalObject();
        boolean boolean19 = googleCodingConvention0.isConstant("JSC_OPTIMIZE_LOOP_ERROR");
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "NUMBER 100.0" + "'", str11.equals("NUMBER 100.0"));
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "goog.global" + "'", str14.equals("goog.global"));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "goog.global" + "'", str17.equals("goog.global"));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        com.google.javascript.rhino.FunctionNode functionNode1 = new com.google.javascript.rhino.FunctionNode("NUMBER 0.0\n");
        int int2 = functionNode1.getFunctionType();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        try {
            com.google.javascript.rhino.EcmaError ecmaError3 = com.google.javascript.rhino.ScriptRuntime.typeError2("goog.exportProperty", "language version", "error");
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property goog.exportProperty");
        } catch (java.lang.RuntimeException e) {
        }
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        com.google.javascript.rhino.jstype.JSType jSType2 = null;
        com.google.javascript.rhino.jstype.JSType jSType4 = jSTypeRegistry1.getGreatestSubtypeWithProperty(jSType2, "");
        com.google.javascript.rhino.jstype.JSType jSType6 = jSType4.findPropertyType("");
        com.google.javascript.rhino.jstype.ObjectType objectType7 = jSType4.dereference();
        com.google.javascript.rhino.ErrorReporter errorReporter8 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry9 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter8);
        com.google.javascript.rhino.jstype.JSType jSType10 = null;
        com.google.javascript.rhino.jstype.JSType jSType12 = jSTypeRegistry9.getGreatestSubtypeWithProperty(jSType10, "");
        com.google.javascript.rhino.jstype.JSType jSType14 = jSType12.findPropertyType("");
        com.google.javascript.rhino.jstype.ObjectType objectType15 = jSType12.dereference();
        boolean boolean16 = objectType15.isOrdinaryFunction();
        boolean boolean17 = objectType15.isUnknownType();
        boolean boolean18 = objectType15.matchesUint32Context();
        com.google.javascript.rhino.jstype.JSType.TypePair typePair19 = objectType7.getTypesUnderShallowInequality((com.google.javascript.rhino.jstype.JSType) objectType15);
        boolean boolean20 = objectType7.isRecordType();
        com.google.javascript.rhino.jstype.JSType jSType22 = objectType7.findPropertyType("NUMBER 0.0\n");
        boolean boolean23 = objectType7.isFunctionPrototypeType();
        org.junit.Assert.assertNotNull(jSType4);
        org.junit.Assert.assertNotNull(jSType6);
        org.junit.Assert.assertNotNull(objectType7);
        org.junit.Assert.assertNotNull(jSType12);
        org.junit.Assert.assertNotNull(jSType14);
        org.junit.Assert.assertNotNull(objectType15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(typePair19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(jSType22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        com.google.javascript.rhino.jstype.JSType jSType3 = jSTypeRegistry1.getType("hi!");
        com.google.javascript.rhino.ErrorReporter errorReporter4 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter4);
        com.google.javascript.rhino.jstype.JSType jSType6 = null;
        com.google.javascript.rhino.jstype.JSType jSType8 = jSTypeRegistry5.getGreatestSubtypeWithProperty(jSType6, "");
        com.google.javascript.rhino.jstype.JSType jSType10 = jSType8.findPropertyType("");
        boolean boolean11 = jSType10.isArrayType();
        boolean boolean12 = jSType10.isNominalType();
        com.google.javascript.rhino.ErrorReporter errorReporter13 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry14 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter13);
        com.google.javascript.rhino.jstype.JSType jSType15 = null;
        com.google.javascript.rhino.jstype.JSType jSType17 = jSTypeRegistry14.getGreatestSubtypeWithProperty(jSType15, "");
        com.google.javascript.rhino.jstype.JSType jSType19 = jSType17.findPropertyType("");
        com.google.javascript.rhino.jstype.ObjectType objectType20 = jSType17.dereference();
        com.google.javascript.rhino.ErrorReporter errorReporter21 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry22 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter21);
        com.google.javascript.rhino.jstype.JSType jSType23 = null;
        com.google.javascript.rhino.jstype.JSType jSType25 = jSTypeRegistry22.getGreatestSubtypeWithProperty(jSType23, "");
        com.google.javascript.rhino.jstype.JSType jSType27 = jSType25.findPropertyType("");
        com.google.javascript.rhino.jstype.ObjectType objectType28 = jSType25.dereference();
        com.google.javascript.rhino.ErrorReporter errorReporter29 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry30 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter29);
        com.google.javascript.rhino.jstype.JSType jSType31 = null;
        com.google.javascript.rhino.jstype.JSType jSType33 = jSTypeRegistry30.getGreatestSubtypeWithProperty(jSType31, "");
        com.google.javascript.rhino.jstype.JSType jSType35 = jSType33.findPropertyType("");
        com.google.javascript.rhino.jstype.ObjectType objectType36 = jSType33.dereference();
        boolean boolean37 = objectType36.isOrdinaryFunction();
        boolean boolean38 = objectType36.isUnknownType();
        boolean boolean39 = objectType36.matchesUint32Context();
        com.google.javascript.rhino.jstype.JSType.TypePair typePair40 = objectType28.getTypesUnderShallowInequality((com.google.javascript.rhino.jstype.JSType) objectType36);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray41 = new com.google.javascript.rhino.jstype.JSType[] { objectType20, objectType28 };
        com.google.javascript.rhino.jstype.FunctionType functionType42 = jSTypeRegistry1.createFunctionType(jSType10, jSTypeArray41);
        java.util.Set set43 = functionType42.getOwnPropertyNames();
        com.google.javascript.rhino.ErrorReporter errorReporter44 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry45 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter44);
        com.google.javascript.rhino.jstype.JSType jSType47 = jSTypeRegistry45.getType("hi!");
        com.google.javascript.rhino.ErrorReporter errorReporter48 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry49 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter48);
        com.google.javascript.rhino.jstype.JSType jSType50 = null;
        com.google.javascript.rhino.jstype.JSType jSType52 = jSTypeRegistry49.getGreatestSubtypeWithProperty(jSType50, "");
        com.google.javascript.rhino.jstype.JSType jSType54 = jSType52.findPropertyType("");
        boolean boolean55 = jSType54.isArrayType();
        boolean boolean56 = jSType54.isNominalType();
        com.google.javascript.rhino.ErrorReporter errorReporter57 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry58 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter57);
        com.google.javascript.rhino.jstype.JSType jSType59 = null;
        com.google.javascript.rhino.jstype.JSType jSType61 = jSTypeRegistry58.getGreatestSubtypeWithProperty(jSType59, "");
        com.google.javascript.rhino.jstype.JSType jSType63 = jSType61.findPropertyType("");
        com.google.javascript.rhino.jstype.ObjectType objectType64 = jSType61.dereference();
        com.google.javascript.rhino.ErrorReporter errorReporter65 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry66 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter65);
        com.google.javascript.rhino.jstype.JSType jSType67 = null;
        com.google.javascript.rhino.jstype.JSType jSType69 = jSTypeRegistry66.getGreatestSubtypeWithProperty(jSType67, "");
        com.google.javascript.rhino.jstype.JSType jSType71 = jSType69.findPropertyType("");
        com.google.javascript.rhino.jstype.ObjectType objectType72 = jSType69.dereference();
        com.google.javascript.rhino.ErrorReporter errorReporter73 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry74 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter73);
        com.google.javascript.rhino.jstype.JSType jSType75 = null;
        com.google.javascript.rhino.jstype.JSType jSType77 = jSTypeRegistry74.getGreatestSubtypeWithProperty(jSType75, "");
        com.google.javascript.rhino.jstype.JSType jSType79 = jSType77.findPropertyType("");
        com.google.javascript.rhino.jstype.ObjectType objectType80 = jSType77.dereference();
        boolean boolean81 = objectType80.isOrdinaryFunction();
        boolean boolean82 = objectType80.isUnknownType();
        boolean boolean83 = objectType80.matchesUint32Context();
        com.google.javascript.rhino.jstype.JSType.TypePair typePair84 = objectType72.getTypesUnderShallowInequality((com.google.javascript.rhino.jstype.JSType) objectType80);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray85 = new com.google.javascript.rhino.jstype.JSType[] { objectType64, objectType72 };
        com.google.javascript.rhino.jstype.FunctionType functionType86 = jSTypeRegistry45.createFunctionType(jSType54, jSTypeArray85);
        boolean boolean87 = functionType42.hasEqualCallType(functionType86);
        boolean boolean88 = functionType86.matchesNumberContext();
        boolean boolean90 = functionType86.isPropertyInExterns("-1");
        boolean boolean91 = functionType86.isOrdinaryFunction();
        org.junit.Assert.assertNull(jSType3);
        org.junit.Assert.assertNotNull(jSType8);
        org.junit.Assert.assertNotNull(jSType10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(jSType17);
        org.junit.Assert.assertNotNull(jSType19);
        org.junit.Assert.assertNotNull(objectType20);
        org.junit.Assert.assertNotNull(jSType25);
        org.junit.Assert.assertNotNull(jSType27);
        org.junit.Assert.assertNotNull(objectType28);
        org.junit.Assert.assertNotNull(jSType33);
        org.junit.Assert.assertNotNull(jSType35);
        org.junit.Assert.assertNotNull(objectType36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertNotNull(typePair40);
        org.junit.Assert.assertNotNull(jSTypeArray41);
        org.junit.Assert.assertNotNull(functionType42);
        org.junit.Assert.assertNotNull(set43);
        org.junit.Assert.assertNull(jSType47);
        org.junit.Assert.assertNotNull(jSType52);
        org.junit.Assert.assertNotNull(jSType54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertNotNull(jSType61);
        org.junit.Assert.assertNotNull(jSType63);
        org.junit.Assert.assertNotNull(objectType64);
        org.junit.Assert.assertNotNull(jSType69);
        org.junit.Assert.assertNotNull(jSType71);
        org.junit.Assert.assertNotNull(objectType72);
        org.junit.Assert.assertNotNull(jSType77);
        org.junit.Assert.assertNotNull(jSType79);
        org.junit.Assert.assertNotNull(objectType80);
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + false + "'", boolean81 == false);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + true + "'", boolean83 == true);
        org.junit.Assert.assertNotNull(typePair84);
        org.junit.Assert.assertNotNull(jSTypeArray85);
        org.junit.Assert.assertNotNull(functionType86);
        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + false + "'", boolean87 == false);
        org.junit.Assert.assertTrue("'" + boolean88 + "' != '" + false + "'", boolean88 == false);
        org.junit.Assert.assertTrue("'" + boolean90 + "' != '" + false + "'", boolean90 == false);
        org.junit.Assert.assertTrue("'" + boolean91 + "' != '" + true + "'", boolean91 == true);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        com.google.javascript.jscomp.DiagnosticType diagnosticType5 = com.google.javascript.jscomp.DiagnosticType.warning("Unknown class name", "Unknown class name");
        java.lang.String[] strArray7 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError8 = com.google.javascript.jscomp.JSError.make("hi!", 6, 13, diagnosticType5, strArray7);
        com.google.javascript.rhino.ErrorReporter errorReporter9 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry10 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter9);
        com.google.javascript.rhino.jstype.JSType jSType12 = jSTypeRegistry10.getType("hi!");
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.Node.newNumber((double) (short) 0);
        com.google.javascript.rhino.ErrorReporter errorReporter16 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry17 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter16);
        com.google.javascript.rhino.jstype.JSType jSType18 = null;
        com.google.javascript.rhino.jstype.JSType jSType20 = jSTypeRegistry17.getGreatestSubtypeWithProperty(jSType18, "");
        com.google.javascript.rhino.jstype.JSType jSType22 = jSType20.findPropertyType("");
        com.google.javascript.rhino.jstype.ObjectType objectType23 = jSType20.dereference();
        boolean boolean24 = objectType23.isNumber();
        com.google.javascript.rhino.ErrorReporter errorReporter25 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry26 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter25);
        com.google.javascript.rhino.jstype.JSType jSType27 = null;
        com.google.javascript.rhino.jstype.JSType jSType29 = jSTypeRegistry26.getGreatestSubtypeWithProperty(jSType27, "");
        com.google.javascript.rhino.jstype.JSType jSType31 = jSType29.findPropertyType("");
        com.google.javascript.rhino.jstype.ObjectType objectType32 = jSType29.dereference();
        boolean boolean33 = objectType32.isNumber();
        com.google.javascript.rhino.jstype.JSType jSType34 = objectType23.getGreatestSubtype((com.google.javascript.rhino.jstype.JSType) objectType32);
        com.google.javascript.rhino.jstype.ObjectType objectType35 = jSTypeRegistry10.createObjectType("Not declared as a constructor", node15, objectType32);
        boolean boolean36 = objectType32.isNativeObjectType();
        boolean boolean37 = jSError8.equals((java.lang.Object) objectType32);
        com.google.javascript.rhino.jstype.BooleanLiteralSet booleanLiteralSet38 = objectType32.getPossibleToBooleanOutcomes();
        org.junit.Assert.assertNotNull(diagnosticType5);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertNotNull(jSError8);
        org.junit.Assert.assertNull(jSType12);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertNotNull(jSType20);
        org.junit.Assert.assertNotNull(jSType22);
        org.junit.Assert.assertNotNull(objectType23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(jSType29);
        org.junit.Assert.assertNotNull(jSType31);
        org.junit.Assert.assertNotNull(objectType32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertNotNull(jSType34);
        org.junit.Assert.assertNotNull(objectType35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + booleanLiteralSet38 + "' != '" + com.google.javascript.rhino.jstype.BooleanLiteralSet.EMPTY + "'", booleanLiteralSet38.equals(com.google.javascript.rhino.jstype.BooleanLiteralSet.EMPTY));
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.Node.newNumber((double) (short) 0);
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newNumber((double) (-1.0f), 0, 48);
        com.google.javascript.rhino.ErrorReporter errorReporter7 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry8 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter7);
        com.google.javascript.rhino.jstype.JSType jSType10 = jSTypeRegistry8.getType("hi!");
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newNumber((double) (short) 0);
        com.google.javascript.rhino.ErrorReporter errorReporter14 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry15 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter14);
        com.google.javascript.rhino.jstype.JSType jSType16 = null;
        com.google.javascript.rhino.jstype.JSType jSType18 = jSTypeRegistry15.getGreatestSubtypeWithProperty(jSType16, "");
        com.google.javascript.rhino.jstype.JSType jSType20 = jSType18.findPropertyType("");
        com.google.javascript.rhino.jstype.ObjectType objectType21 = jSType18.dereference();
        boolean boolean22 = objectType21.isNumber();
        com.google.javascript.rhino.ErrorReporter errorReporter23 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry24 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter23);
        com.google.javascript.rhino.jstype.JSType jSType25 = null;
        com.google.javascript.rhino.jstype.JSType jSType27 = jSTypeRegistry24.getGreatestSubtypeWithProperty(jSType25, "");
        com.google.javascript.rhino.jstype.JSType jSType29 = jSType27.findPropertyType("");
        com.google.javascript.rhino.jstype.ObjectType objectType30 = jSType27.dereference();
        boolean boolean31 = objectType30.isNumber();
        com.google.javascript.rhino.jstype.JSType jSType32 = objectType21.getGreatestSubtype((com.google.javascript.rhino.jstype.JSType) objectType30);
        com.google.javascript.rhino.jstype.ObjectType objectType33 = jSTypeRegistry8.createObjectType("Not declared as a constructor", node13, objectType30);
        boolean boolean34 = node6.checkTreeEqualsSilent(node13);
        java.lang.String str35 = node13.toStringTree();
        com.google.javascript.rhino.Node node39 = com.google.javascript.rhino.Node.newNumber((double) (short) 100, 0, (int) (byte) -1);
        node39.removeProp((int) (short) 1);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder42 = node39.getJsDocBuilderForNode();
        boolean boolean43 = node39.hasOneChild();
        com.google.javascript.rhino.Node node47 = com.google.javascript.rhino.Node.newNumber((double) (short) 100, 0, (int) (byte) -1);
        node47.removeProp((int) (short) 1);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder50 = node47.getJsDocBuilderForNode();
        java.lang.Object obj52 = node47.getProp((int) '#');
        com.google.javascript.rhino.Node node53 = node39.copyInformationFromForTree(node47);
        com.google.javascript.rhino.Node node54 = new com.google.javascript.rhino.Node(15, node2, node13, node47);
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNull(jSType10);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(jSType18);
        org.junit.Assert.assertNotNull(jSType20);
        org.junit.Assert.assertNotNull(objectType21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(jSType27);
        org.junit.Assert.assertNotNull(jSType29);
        org.junit.Assert.assertNotNull(objectType30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertNotNull(jSType32);
        org.junit.Assert.assertNotNull(objectType33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "NUMBER 0.0\n" + "'", str35.equals("NUMBER 0.0\n"));
        org.junit.Assert.assertNotNull(node39);
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(node47);
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder50);
        org.junit.Assert.assertNull(obj52);
        org.junit.Assert.assertNotNull(node53);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        com.google.javascript.jscomp.Compiler.CodeBuilder codeBuilder0 = new com.google.javascript.jscomp.Compiler.CodeBuilder();
        java.lang.String str1 = codeBuilder0.toString();
        java.lang.String str2 = codeBuilder0.toString();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile1 = com.google.javascript.jscomp.JSSourceFile.fromFile("-1");
        java.lang.String str2 = jSSourceFile1.toString();
        org.junit.Assert.assertNotNull(jSSourceFile1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "-1" + "'", str2.equals("-1"));
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newNumber((double) (short) 100, 0, (int) (byte) -1);
        java.lang.String str5 = node4.toString();
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder6 = node4.getJsDocBuilderForNode();
        boolean boolean7 = closureCodingConvention0.isVarArgsParameter(node4);
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.Node.newNumber((double) (short) 100, 0, (int) (byte) -1);
        node11.removeProp((int) (short) 1);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder14 = node11.getJsDocBuilderForNode();
        java.lang.Object obj16 = node11.getProp((-1));
        boolean boolean17 = closureCodingConvention0.isVarArgsParameter(node11);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode21 = new com.google.javascript.rhino.ScriptOrFnNode((int) (short) 0, (int) ' ', 33);
        boolean boolean22 = closureCodingConvention0.isOptionalParameter((com.google.javascript.rhino.Node) scriptOrFnNode21);
        java.lang.String str23 = closureCodingConvention0.getGlobalObject();
        boolean boolean25 = closureCodingConvention0.isValidEnumKey("function (function (this:me, {557852266}): me, function (this:me, {604752285}): me): function (this:me, {368269249}): me");
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "NUMBER 100.0" + "'", str5.equals("NUMBER 100.0"));
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder14);
        org.junit.Assert.assertNull(obj16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "goog.global" + "'", str23.equals("goog.global"));
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        com.google.javascript.jscomp.SourceAst sourceAst0 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(sourceAst0, "goog.exportSymbol", true);
        java.lang.String str4 = compilerInput3.getName();
        com.google.javascript.jscomp.JSModule jSModule6 = new com.google.javascript.jscomp.JSModule("goog.exportSymbol");
        compilerInput3.setModule(jSModule6);
        com.google.javascript.jscomp.JSModule jSModule8 = compilerInput3.getModule();
        try {
            java.util.Collection<java.lang.String> strCollection9 = compilerInput3.getProvides();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Expected setErrorManager to be called first");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "goog.exportSymbol" + "'", str4.equals("goog.exportSymbol"));
        org.junit.Assert.assertNotNull(jSModule8);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        com.google.javascript.rhino.Context context0 = null;
        com.google.javascript.rhino.Context context1 = com.google.javascript.rhino.Context.enter(context0);
        com.google.javascript.rhino.Context context2 = com.google.javascript.rhino.Context.enter(context0);
        boolean boolean3 = context2.isGeneratingDebug();
        context2.setGeneratingSource(true);
        java.lang.Class<?> wildcardClass6 = context2.getClass();
        java.lang.Object obj7 = context2.getDebuggerContextData();
        boolean boolean8 = context2.isGeneratingDebugChanged();
        org.junit.Assert.assertNotNull(context1);
        org.junit.Assert.assertNotNull(context2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNull(obj7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        com.google.javascript.rhino.EvaluatorException evaluatorException5 = new com.google.javascript.rhino.EvaluatorException("NUMBER 100.0", ": -1", 19, "Unknown class name", 2);
        java.lang.String str6 = evaluatorException5.sourceName();
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + ": -1" + "'", str6.equals(": -1"));
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        com.google.javascript.rhino.jstype.JSType jSType2 = null;
        com.google.javascript.rhino.jstype.JSType jSType4 = jSTypeRegistry1.getGreatestSubtypeWithProperty(jSType2, "");
        com.google.javascript.rhino.jstype.JSType jSType6 = jSType4.findPropertyType("");
        com.google.javascript.rhino.jstype.ObjectType objectType7 = jSType4.dereference();
        boolean boolean8 = objectType7.isNumber();
        com.google.javascript.rhino.ErrorReporter errorReporter9 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry10 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter9);
        com.google.javascript.rhino.jstype.JSType jSType11 = null;
        com.google.javascript.rhino.jstype.JSType jSType13 = jSTypeRegistry10.getGreatestSubtypeWithProperty(jSType11, "");
        com.google.javascript.rhino.jstype.JSType jSType15 = jSType13.findPropertyType("");
        com.google.javascript.rhino.jstype.ObjectType objectType16 = jSType13.dereference();
        boolean boolean17 = objectType16.isNumber();
        com.google.javascript.rhino.jstype.JSType jSType18 = objectType7.getGreatestSubtype((com.google.javascript.rhino.jstype.JSType) objectType16);
        boolean boolean19 = jSType18.isNumberObjectType();
        org.junit.Assert.assertNotNull(jSType4);
        org.junit.Assert.assertNotNull(jSType6);
        org.junit.Assert.assertNotNull(objectType7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(jSType13);
        org.junit.Assert.assertNotNull(jSType15);
        org.junit.Assert.assertNotNull(objectType16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(jSType18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        com.google.javascript.rhino.jstype.JSType jSType3 = jSTypeRegistry1.getType("hi!");
        com.google.javascript.rhino.ErrorReporter errorReporter4 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter4);
        com.google.javascript.rhino.jstype.JSType jSType6 = null;
        com.google.javascript.rhino.jstype.JSType jSType8 = jSTypeRegistry5.getGreatestSubtypeWithProperty(jSType6, "");
        com.google.javascript.rhino.jstype.JSType jSType10 = jSType8.findPropertyType("");
        boolean boolean11 = jSType10.isArrayType();
        boolean boolean12 = jSType10.isNominalType();
        com.google.javascript.rhino.ErrorReporter errorReporter13 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry14 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter13);
        com.google.javascript.rhino.jstype.JSType jSType15 = null;
        com.google.javascript.rhino.jstype.JSType jSType17 = jSTypeRegistry14.getGreatestSubtypeWithProperty(jSType15, "");
        com.google.javascript.rhino.jstype.JSType jSType19 = jSType17.findPropertyType("");
        com.google.javascript.rhino.jstype.ObjectType objectType20 = jSType17.dereference();
        com.google.javascript.rhino.ErrorReporter errorReporter21 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry22 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter21);
        com.google.javascript.rhino.jstype.JSType jSType23 = null;
        com.google.javascript.rhino.jstype.JSType jSType25 = jSTypeRegistry22.getGreatestSubtypeWithProperty(jSType23, "");
        com.google.javascript.rhino.jstype.JSType jSType27 = jSType25.findPropertyType("");
        com.google.javascript.rhino.jstype.ObjectType objectType28 = jSType25.dereference();
        com.google.javascript.rhino.ErrorReporter errorReporter29 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry30 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter29);
        com.google.javascript.rhino.jstype.JSType jSType31 = null;
        com.google.javascript.rhino.jstype.JSType jSType33 = jSTypeRegistry30.getGreatestSubtypeWithProperty(jSType31, "");
        com.google.javascript.rhino.jstype.JSType jSType35 = jSType33.findPropertyType("");
        com.google.javascript.rhino.jstype.ObjectType objectType36 = jSType33.dereference();
        boolean boolean37 = objectType36.isOrdinaryFunction();
        boolean boolean38 = objectType36.isUnknownType();
        boolean boolean39 = objectType36.matchesUint32Context();
        com.google.javascript.rhino.jstype.JSType.TypePair typePair40 = objectType28.getTypesUnderShallowInequality((com.google.javascript.rhino.jstype.JSType) objectType36);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray41 = new com.google.javascript.rhino.jstype.JSType[] { objectType20, objectType28 };
        com.google.javascript.rhino.jstype.FunctionType functionType42 = jSTypeRegistry1.createFunctionType(jSType10, jSTypeArray41);
        java.util.Set set43 = functionType42.getOwnPropertyNames();
        com.google.javascript.rhino.ErrorReporter errorReporter44 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry45 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter44);
        com.google.javascript.rhino.jstype.JSType jSType47 = jSTypeRegistry45.getType("hi!");
        com.google.javascript.rhino.ErrorReporter errorReporter48 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry49 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter48);
        com.google.javascript.rhino.jstype.JSType jSType50 = null;
        com.google.javascript.rhino.jstype.JSType jSType52 = jSTypeRegistry49.getGreatestSubtypeWithProperty(jSType50, "");
        com.google.javascript.rhino.jstype.JSType jSType54 = jSType52.findPropertyType("");
        boolean boolean55 = jSType54.isArrayType();
        boolean boolean56 = jSType54.isNominalType();
        com.google.javascript.rhino.ErrorReporter errorReporter57 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry58 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter57);
        com.google.javascript.rhino.jstype.JSType jSType59 = null;
        com.google.javascript.rhino.jstype.JSType jSType61 = jSTypeRegistry58.getGreatestSubtypeWithProperty(jSType59, "");
        com.google.javascript.rhino.jstype.JSType jSType63 = jSType61.findPropertyType("");
        com.google.javascript.rhino.jstype.ObjectType objectType64 = jSType61.dereference();
        com.google.javascript.rhino.ErrorReporter errorReporter65 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry66 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter65);
        com.google.javascript.rhino.jstype.JSType jSType67 = null;
        com.google.javascript.rhino.jstype.JSType jSType69 = jSTypeRegistry66.getGreatestSubtypeWithProperty(jSType67, "");
        com.google.javascript.rhino.jstype.JSType jSType71 = jSType69.findPropertyType("");
        com.google.javascript.rhino.jstype.ObjectType objectType72 = jSType69.dereference();
        com.google.javascript.rhino.ErrorReporter errorReporter73 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry74 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter73);
        com.google.javascript.rhino.jstype.JSType jSType75 = null;
        com.google.javascript.rhino.jstype.JSType jSType77 = jSTypeRegistry74.getGreatestSubtypeWithProperty(jSType75, "");
        com.google.javascript.rhino.jstype.JSType jSType79 = jSType77.findPropertyType("");
        com.google.javascript.rhino.jstype.ObjectType objectType80 = jSType77.dereference();
        boolean boolean81 = objectType80.isOrdinaryFunction();
        boolean boolean82 = objectType80.isUnknownType();
        boolean boolean83 = objectType80.matchesUint32Context();
        com.google.javascript.rhino.jstype.JSType.TypePair typePair84 = objectType72.getTypesUnderShallowInequality((com.google.javascript.rhino.jstype.JSType) objectType80);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray85 = new com.google.javascript.rhino.jstype.JSType[] { objectType64, objectType72 };
        com.google.javascript.rhino.jstype.FunctionType functionType86 = jSTypeRegistry45.createFunctionType(jSType54, jSTypeArray85);
        boolean boolean87 = functionType42.hasEqualCallType(functionType86);
        com.google.javascript.rhino.jstype.FunctionPrototypeType functionPrototypeType88 = functionType86.getPrototype();
        boolean boolean89 = functionPrototypeType88.matchesStringContext();
        boolean boolean90 = functionPrototypeType88.hasCachedValues();
        boolean boolean91 = functionPrototypeType88.isDateType();
        org.junit.Assert.assertNull(jSType3);
        org.junit.Assert.assertNotNull(jSType8);
        org.junit.Assert.assertNotNull(jSType10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(jSType17);
        org.junit.Assert.assertNotNull(jSType19);
        org.junit.Assert.assertNotNull(objectType20);
        org.junit.Assert.assertNotNull(jSType25);
        org.junit.Assert.assertNotNull(jSType27);
        org.junit.Assert.assertNotNull(objectType28);
        org.junit.Assert.assertNotNull(jSType33);
        org.junit.Assert.assertNotNull(jSType35);
        org.junit.Assert.assertNotNull(objectType36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertNotNull(typePair40);
        org.junit.Assert.assertNotNull(jSTypeArray41);
        org.junit.Assert.assertNotNull(functionType42);
        org.junit.Assert.assertNotNull(set43);
        org.junit.Assert.assertNull(jSType47);
        org.junit.Assert.assertNotNull(jSType52);
        org.junit.Assert.assertNotNull(jSType54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertNotNull(jSType61);
        org.junit.Assert.assertNotNull(jSType63);
        org.junit.Assert.assertNotNull(objectType64);
        org.junit.Assert.assertNotNull(jSType69);
        org.junit.Assert.assertNotNull(jSType71);
        org.junit.Assert.assertNotNull(objectType72);
        org.junit.Assert.assertNotNull(jSType77);
        org.junit.Assert.assertNotNull(jSType79);
        org.junit.Assert.assertNotNull(objectType80);
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + false + "'", boolean81 == false);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + true + "'", boolean83 == true);
        org.junit.Assert.assertNotNull(typePair84);
        org.junit.Assert.assertNotNull(jSTypeArray85);
        org.junit.Assert.assertNotNull(functionType86);
        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + false + "'", boolean87 == false);
        org.junit.Assert.assertNotNull(functionPrototypeType88);
        org.junit.Assert.assertTrue("'" + boolean89 + "' != '" + false + "'", boolean89 == false);
        org.junit.Assert.assertTrue("'" + boolean90 + "' != '" + false + "'", boolean90 == false);
        org.junit.Assert.assertTrue("'" + boolean91 + "' != '" + false + "'", boolean91 == false);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.UNDEFINED_VARIABLES;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        com.google.javascript.jscomp.JSModule jSModule1 = new com.google.javascript.jscomp.JSModule("Not declared as a constructor");
        java.nio.charset.Charset charset3 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile4 = com.google.javascript.jscomp.JSSourceFile.fromFile("Not declared as a constructor", charset3);
        java.lang.String str6 = jSSourceFile4.getLine(0);
        jSModule1.add(jSSourceFile4);
        java.util.List<java.lang.String> strList8 = jSModule1.getProvides();
        java.util.List<java.lang.String> strList9 = jSModule1.getRequires();
        com.google.javascript.jscomp.JSModule[] jSModuleArray10 = new com.google.javascript.jscomp.JSModule[] { jSModule1 };
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph11 = new com.google.javascript.jscomp.JSModuleGraph(jSModuleArray10);
        org.junit.Assert.assertNotNull(jSSourceFile4);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNotNull(strList8);
        org.junit.Assert.assertNotNull(strList9);
        org.junit.Assert.assertNotNull(jSModuleArray10);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        com.google.javascript.rhino.jstype.JSType jSType3 = jSTypeRegistry1.getType("hi!");
        com.google.javascript.rhino.ErrorReporter errorReporter4 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter4);
        com.google.javascript.rhino.jstype.JSType jSType6 = null;
        com.google.javascript.rhino.jstype.JSType jSType8 = jSTypeRegistry5.getGreatestSubtypeWithProperty(jSType6, "");
        com.google.javascript.rhino.jstype.JSType jSType10 = jSType8.findPropertyType("");
        boolean boolean11 = jSType10.isArrayType();
        boolean boolean12 = jSType10.isNominalType();
        com.google.javascript.rhino.ErrorReporter errorReporter13 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry14 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter13);
        com.google.javascript.rhino.jstype.JSType jSType15 = null;
        com.google.javascript.rhino.jstype.JSType jSType17 = jSTypeRegistry14.getGreatestSubtypeWithProperty(jSType15, "");
        com.google.javascript.rhino.jstype.JSType jSType19 = jSType17.findPropertyType("");
        com.google.javascript.rhino.jstype.ObjectType objectType20 = jSType17.dereference();
        com.google.javascript.rhino.ErrorReporter errorReporter21 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry22 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter21);
        com.google.javascript.rhino.jstype.JSType jSType23 = null;
        com.google.javascript.rhino.jstype.JSType jSType25 = jSTypeRegistry22.getGreatestSubtypeWithProperty(jSType23, "");
        com.google.javascript.rhino.jstype.JSType jSType27 = jSType25.findPropertyType("");
        com.google.javascript.rhino.jstype.ObjectType objectType28 = jSType25.dereference();
        com.google.javascript.rhino.ErrorReporter errorReporter29 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry30 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter29);
        com.google.javascript.rhino.jstype.JSType jSType31 = null;
        com.google.javascript.rhino.jstype.JSType jSType33 = jSTypeRegistry30.getGreatestSubtypeWithProperty(jSType31, "");
        com.google.javascript.rhino.jstype.JSType jSType35 = jSType33.findPropertyType("");
        com.google.javascript.rhino.jstype.ObjectType objectType36 = jSType33.dereference();
        boolean boolean37 = objectType36.isOrdinaryFunction();
        boolean boolean38 = objectType36.isUnknownType();
        boolean boolean39 = objectType36.matchesUint32Context();
        com.google.javascript.rhino.jstype.JSType.TypePair typePair40 = objectType28.getTypesUnderShallowInequality((com.google.javascript.rhino.jstype.JSType) objectType36);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray41 = new com.google.javascript.rhino.jstype.JSType[] { objectType20, objectType28 };
        com.google.javascript.rhino.jstype.FunctionType functionType42 = jSTypeRegistry1.createFunctionType(jSType10, jSTypeArray41);
        boolean boolean43 = jSTypeRegistry1.shouldTolerateUndefinedValues();
        org.junit.Assert.assertNull(jSType3);
        org.junit.Assert.assertNotNull(jSType8);
        org.junit.Assert.assertNotNull(jSType10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(jSType17);
        org.junit.Assert.assertNotNull(jSType19);
        org.junit.Assert.assertNotNull(objectType20);
        org.junit.Assert.assertNotNull(jSType25);
        org.junit.Assert.assertNotNull(jSType27);
        org.junit.Assert.assertNotNull(objectType28);
        org.junit.Assert.assertNotNull(jSType33);
        org.junit.Assert.assertNotNull(jSType35);
        org.junit.Assert.assertNotNull(objectType36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertNotNull(typePair40);
        org.junit.Assert.assertNotNull(jSTypeArray41);
        org.junit.Assert.assertNotNull(functionType42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        com.google.javascript.jscomp.MessageFormatter messageFormatter0 = null;
        java.util.logging.Logger logger1 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager2 = new com.google.javascript.jscomp.LoggerErrorManager(messageFormatter0, logger1);
        com.google.javascript.jscomp.Compiler compiler3 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager2);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile6 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "NUMBER 100.0");
        com.google.javascript.rhino.Node node7 = compiler3.parse(jSSourceFile6);
        java.util.Set<java.lang.String> strSet8 = node7.getDirectives();
        org.junit.Assert.assertNotNull(jSSourceFile6);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertNull(strSet8);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode3 = new com.google.javascript.rhino.ScriptOrFnNode((int) (short) 0, (int) ' ', 33);
        java.lang.Object obj4 = scriptOrFnNode3.getCompilerData();
        boolean boolean6 = scriptOrFnNode3.hasParamOrVar("");
        java.lang.String[] strArray7 = scriptOrFnNode3.getParamAndVarNames();
        org.junit.Assert.assertNull(obj4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(strArray7);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode3 = new com.google.javascript.rhino.ScriptOrFnNode((int) (short) 0, (int) ' ', 33);
        boolean boolean5 = scriptOrFnNode3.addConst("NUMBER 0.0\n");
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        java.util.Set<com.google.javascript.rhino.jstype.ObjectType> objectTypeSet3 = jSTypeRegistry1.getTypesWithProperty("");
        com.google.javascript.rhino.ErrorReporter errorReporter4 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter4);
        com.google.javascript.rhino.jstype.JSType jSType6 = null;
        com.google.javascript.rhino.jstype.JSType jSType8 = jSTypeRegistry5.getGreatestSubtypeWithProperty(jSType6, "");
        com.google.javascript.rhino.jstype.JSType jSType10 = jSType8.findPropertyType("");
        com.google.javascript.rhino.ErrorReporter errorReporter11 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry12 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter11);
        com.google.javascript.rhino.jstype.JSType jSType13 = null;
        com.google.javascript.rhino.jstype.JSType jSType15 = jSTypeRegistry12.getGreatestSubtypeWithProperty(jSType13, "");
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray16 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.Node node17 = jSTypeRegistry12.createOptionalParameters(jSTypeArray16);
        com.google.javascript.rhino.jstype.FunctionType functionType18 = jSTypeRegistry1.createFunctionTypeWithVarArgs(jSType8, jSTypeArray16);
        java.util.Set<java.lang.String> strSet19 = functionType18.getOwnPropertyNames();
        boolean boolean20 = functionType18.isInterface();
        com.google.javascript.rhino.ErrorReporter errorReporter21 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry22 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter21);
        com.google.javascript.rhino.jstype.JSType jSType23 = null;
        com.google.javascript.rhino.jstype.JSType jSType25 = jSTypeRegistry22.getGreatestSubtypeWithProperty(jSType23, "");
        com.google.javascript.rhino.jstype.JSType jSType27 = jSType25.findPropertyType("");
        com.google.javascript.rhino.jstype.ObjectType objectType28 = jSType25.dereference();
        boolean boolean29 = objectType28.isOrdinaryFunction();
        boolean boolean30 = objectType28.isUnknownType();
        boolean boolean31 = objectType28.matchesUint32Context();
        boolean boolean32 = objectType28.isNullable();
        com.google.javascript.rhino.jstype.ObjectType objectType33 = objectType28.dereference();
        com.google.javascript.rhino.jstype.JSType.TypePair typePair34 = functionType18.getTypesUnderShallowEquality((com.google.javascript.rhino.jstype.JSType) objectType33);
        boolean boolean35 = functionType18.isUnknownType();
        com.google.javascript.rhino.ErrorReporter errorReporter36 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry37 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter36);
        com.google.javascript.rhino.jstype.JSType jSType39 = jSTypeRegistry37.getType("hi!");
        com.google.javascript.rhino.ErrorReporter errorReporter40 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry41 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter40);
        com.google.javascript.rhino.jstype.JSType jSType42 = null;
        com.google.javascript.rhino.jstype.JSType jSType44 = jSTypeRegistry41.getGreatestSubtypeWithProperty(jSType42, "");
        com.google.javascript.rhino.jstype.JSType jSType46 = jSType44.findPropertyType("");
        boolean boolean47 = jSType46.isArrayType();
        boolean boolean48 = jSType46.isNominalType();
        com.google.javascript.rhino.ErrorReporter errorReporter49 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry50 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter49);
        com.google.javascript.rhino.jstype.JSType jSType51 = null;
        com.google.javascript.rhino.jstype.JSType jSType53 = jSTypeRegistry50.getGreatestSubtypeWithProperty(jSType51, "");
        com.google.javascript.rhino.jstype.JSType jSType55 = jSType53.findPropertyType("");
        com.google.javascript.rhino.jstype.ObjectType objectType56 = jSType53.dereference();
        com.google.javascript.rhino.ErrorReporter errorReporter57 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry58 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter57);
        com.google.javascript.rhino.jstype.JSType jSType59 = null;
        com.google.javascript.rhino.jstype.JSType jSType61 = jSTypeRegistry58.getGreatestSubtypeWithProperty(jSType59, "");
        com.google.javascript.rhino.jstype.JSType jSType63 = jSType61.findPropertyType("");
        com.google.javascript.rhino.jstype.ObjectType objectType64 = jSType61.dereference();
        com.google.javascript.rhino.ErrorReporter errorReporter65 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry66 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter65);
        com.google.javascript.rhino.jstype.JSType jSType67 = null;
        com.google.javascript.rhino.jstype.JSType jSType69 = jSTypeRegistry66.getGreatestSubtypeWithProperty(jSType67, "");
        com.google.javascript.rhino.jstype.JSType jSType71 = jSType69.findPropertyType("");
        com.google.javascript.rhino.jstype.ObjectType objectType72 = jSType69.dereference();
        boolean boolean73 = objectType72.isOrdinaryFunction();
        boolean boolean74 = objectType72.isUnknownType();
        boolean boolean75 = objectType72.matchesUint32Context();
        com.google.javascript.rhino.jstype.JSType.TypePair typePair76 = objectType64.getTypesUnderShallowInequality((com.google.javascript.rhino.jstype.JSType) objectType72);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray77 = new com.google.javascript.rhino.jstype.JSType[] { objectType56, objectType64 };
        com.google.javascript.rhino.jstype.FunctionType functionType78 = jSTypeRegistry37.createFunctionType(jSType46, jSTypeArray77);
        boolean boolean79 = functionType78.isInterface();
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable80 = functionType78.getParameters();
        com.google.javascript.rhino.jstype.JSType jSType81 = functionType18.getLeastSupertype((com.google.javascript.rhino.jstype.JSType) functionType78);
        com.google.javascript.rhino.JSDocInfo jSDocInfo83 = functionType78.getOwnPropertyJSDocInfo("function (function (this:me, {557852266}): me, function (this:me, {604752285}): me): function (this:me, {368269249}): me");
        org.junit.Assert.assertNotNull(objectTypeSet3);
        org.junit.Assert.assertNotNull(jSType8);
        org.junit.Assert.assertNotNull(jSType10);
        org.junit.Assert.assertNotNull(jSType15);
        org.junit.Assert.assertNotNull(jSTypeArray16);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(functionType18);
        org.junit.Assert.assertNotNull(strSet19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(jSType25);
        org.junit.Assert.assertNotNull(jSType27);
        org.junit.Assert.assertNotNull(objectType28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNotNull(objectType33);
        org.junit.Assert.assertNotNull(typePair34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNull(jSType39);
        org.junit.Assert.assertNotNull(jSType44);
        org.junit.Assert.assertNotNull(jSType46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(jSType53);
        org.junit.Assert.assertNotNull(jSType55);
        org.junit.Assert.assertNotNull(objectType56);
        org.junit.Assert.assertNotNull(jSType61);
        org.junit.Assert.assertNotNull(jSType63);
        org.junit.Assert.assertNotNull(objectType64);
        org.junit.Assert.assertNotNull(jSType69);
        org.junit.Assert.assertNotNull(jSType71);
        org.junit.Assert.assertNotNull(objectType72);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + true + "'", boolean75 == true);
        org.junit.Assert.assertNotNull(typePair76);
        org.junit.Assert.assertNotNull(jSTypeArray77);
        org.junit.Assert.assertNotNull(functionType78);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
        org.junit.Assert.assertNotNull(nodeIterable80);
        org.junit.Assert.assertNotNull(jSType81);
        org.junit.Assert.assertNull(jSDocInfo83);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        java.lang.Double double0 = com.google.javascript.rhino.ScriptRuntime.NaNobj;
        org.junit.Assert.assertEquals((double) double0, Double.NaN, 0);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        com.google.javascript.jscomp.SourceFile.Generator generator1 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("NUMBER -1.0 0", generator1);
        org.junit.Assert.assertNotNull(jSSourceFile2);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        com.google.javascript.rhino.jstype.JSType jSType3 = jSTypeRegistry1.getType("hi!");
        com.google.javascript.rhino.ErrorReporter errorReporter4 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter4);
        com.google.javascript.rhino.jstype.JSType jSType6 = null;
        com.google.javascript.rhino.jstype.JSType jSType8 = jSTypeRegistry5.getGreatestSubtypeWithProperty(jSType6, "");
        com.google.javascript.rhino.jstype.JSType jSType10 = jSType8.findPropertyType("");
        boolean boolean11 = jSType10.isArrayType();
        boolean boolean12 = jSType10.isNominalType();
        com.google.javascript.rhino.ErrorReporter errorReporter13 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry14 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter13);
        com.google.javascript.rhino.jstype.JSType jSType15 = null;
        com.google.javascript.rhino.jstype.JSType jSType17 = jSTypeRegistry14.getGreatestSubtypeWithProperty(jSType15, "");
        com.google.javascript.rhino.jstype.JSType jSType19 = jSType17.findPropertyType("");
        com.google.javascript.rhino.jstype.ObjectType objectType20 = jSType17.dereference();
        com.google.javascript.rhino.ErrorReporter errorReporter21 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry22 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter21);
        com.google.javascript.rhino.jstype.JSType jSType23 = null;
        com.google.javascript.rhino.jstype.JSType jSType25 = jSTypeRegistry22.getGreatestSubtypeWithProperty(jSType23, "");
        com.google.javascript.rhino.jstype.JSType jSType27 = jSType25.findPropertyType("");
        com.google.javascript.rhino.jstype.ObjectType objectType28 = jSType25.dereference();
        com.google.javascript.rhino.ErrorReporter errorReporter29 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry30 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter29);
        com.google.javascript.rhino.jstype.JSType jSType31 = null;
        com.google.javascript.rhino.jstype.JSType jSType33 = jSTypeRegistry30.getGreatestSubtypeWithProperty(jSType31, "");
        com.google.javascript.rhino.jstype.JSType jSType35 = jSType33.findPropertyType("");
        com.google.javascript.rhino.jstype.ObjectType objectType36 = jSType33.dereference();
        boolean boolean37 = objectType36.isOrdinaryFunction();
        boolean boolean38 = objectType36.isUnknownType();
        boolean boolean39 = objectType36.matchesUint32Context();
        com.google.javascript.rhino.jstype.JSType.TypePair typePair40 = objectType28.getTypesUnderShallowInequality((com.google.javascript.rhino.jstype.JSType) objectType36);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray41 = new com.google.javascript.rhino.jstype.JSType[] { objectType20, objectType28 };
        com.google.javascript.rhino.jstype.FunctionType functionType42 = jSTypeRegistry1.createFunctionType(jSType10, jSTypeArray41);
        java.util.Set set43 = functionType42.getOwnPropertyNames();
        com.google.javascript.rhino.ErrorReporter errorReporter44 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry45 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter44);
        com.google.javascript.rhino.jstype.JSType jSType47 = jSTypeRegistry45.getType("hi!");
        com.google.javascript.rhino.ErrorReporter errorReporter48 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry49 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter48);
        com.google.javascript.rhino.jstype.JSType jSType50 = null;
        com.google.javascript.rhino.jstype.JSType jSType52 = jSTypeRegistry49.getGreatestSubtypeWithProperty(jSType50, "");
        com.google.javascript.rhino.jstype.JSType jSType54 = jSType52.findPropertyType("");
        boolean boolean55 = jSType54.isArrayType();
        boolean boolean56 = jSType54.isNominalType();
        com.google.javascript.rhino.ErrorReporter errorReporter57 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry58 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter57);
        com.google.javascript.rhino.jstype.JSType jSType59 = null;
        com.google.javascript.rhino.jstype.JSType jSType61 = jSTypeRegistry58.getGreatestSubtypeWithProperty(jSType59, "");
        com.google.javascript.rhino.jstype.JSType jSType63 = jSType61.findPropertyType("");
        com.google.javascript.rhino.jstype.ObjectType objectType64 = jSType61.dereference();
        com.google.javascript.rhino.ErrorReporter errorReporter65 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry66 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter65);
        com.google.javascript.rhino.jstype.JSType jSType67 = null;
        com.google.javascript.rhino.jstype.JSType jSType69 = jSTypeRegistry66.getGreatestSubtypeWithProperty(jSType67, "");
        com.google.javascript.rhino.jstype.JSType jSType71 = jSType69.findPropertyType("");
        com.google.javascript.rhino.jstype.ObjectType objectType72 = jSType69.dereference();
        com.google.javascript.rhino.ErrorReporter errorReporter73 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry74 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter73);
        com.google.javascript.rhino.jstype.JSType jSType75 = null;
        com.google.javascript.rhino.jstype.JSType jSType77 = jSTypeRegistry74.getGreatestSubtypeWithProperty(jSType75, "");
        com.google.javascript.rhino.jstype.JSType jSType79 = jSType77.findPropertyType("");
        com.google.javascript.rhino.jstype.ObjectType objectType80 = jSType77.dereference();
        boolean boolean81 = objectType80.isOrdinaryFunction();
        boolean boolean82 = objectType80.isUnknownType();
        boolean boolean83 = objectType80.matchesUint32Context();
        com.google.javascript.rhino.jstype.JSType.TypePair typePair84 = objectType72.getTypesUnderShallowInequality((com.google.javascript.rhino.jstype.JSType) objectType80);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray85 = new com.google.javascript.rhino.jstype.JSType[] { objectType64, objectType72 };
        com.google.javascript.rhino.jstype.FunctionType functionType86 = jSTypeRegistry45.createFunctionType(jSType54, jSTypeArray85);
        boolean boolean87 = functionType42.hasEqualCallType(functionType86);
        com.google.javascript.rhino.jstype.FunctionPrototypeType functionPrototypeType88 = functionType86.getPrototype();
        boolean boolean89 = functionPrototypeType88.matchesObjectContext();
        com.google.javascript.rhino.jstype.ObjectType objectType90 = functionPrototypeType88.getImplicitPrototype();
        org.junit.Assert.assertNull(jSType3);
        org.junit.Assert.assertNotNull(jSType8);
        org.junit.Assert.assertNotNull(jSType10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(jSType17);
        org.junit.Assert.assertNotNull(jSType19);
        org.junit.Assert.assertNotNull(objectType20);
        org.junit.Assert.assertNotNull(jSType25);
        org.junit.Assert.assertNotNull(jSType27);
        org.junit.Assert.assertNotNull(objectType28);
        org.junit.Assert.assertNotNull(jSType33);
        org.junit.Assert.assertNotNull(jSType35);
        org.junit.Assert.assertNotNull(objectType36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertNotNull(typePair40);
        org.junit.Assert.assertNotNull(jSTypeArray41);
        org.junit.Assert.assertNotNull(functionType42);
        org.junit.Assert.assertNotNull(set43);
        org.junit.Assert.assertNull(jSType47);
        org.junit.Assert.assertNotNull(jSType52);
        org.junit.Assert.assertNotNull(jSType54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertNotNull(jSType61);
        org.junit.Assert.assertNotNull(jSType63);
        org.junit.Assert.assertNotNull(objectType64);
        org.junit.Assert.assertNotNull(jSType69);
        org.junit.Assert.assertNotNull(jSType71);
        org.junit.Assert.assertNotNull(objectType72);
        org.junit.Assert.assertNotNull(jSType77);
        org.junit.Assert.assertNotNull(jSType79);
        org.junit.Assert.assertNotNull(objectType80);
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + false + "'", boolean81 == false);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + true + "'", boolean83 == true);
        org.junit.Assert.assertNotNull(typePair84);
        org.junit.Assert.assertNotNull(jSTypeArray85);
        org.junit.Assert.assertNotNull(functionType86);
        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + false + "'", boolean87 == false);
        org.junit.Assert.assertNotNull(functionPrototypeType88);
        org.junit.Assert.assertTrue("'" + boolean89 + "' != '" + true + "'", boolean89 == true);
        org.junit.Assert.assertNotNull(objectType90);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        java.util.Set<com.google.javascript.rhino.jstype.ObjectType> objectTypeSet3 = jSTypeRegistry1.getTypesWithProperty("");
        com.google.javascript.rhino.ErrorReporter errorReporter4 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter4);
        com.google.javascript.rhino.jstype.JSType jSType6 = null;
        com.google.javascript.rhino.jstype.JSType jSType8 = jSTypeRegistry5.getGreatestSubtypeWithProperty(jSType6, "");
        com.google.javascript.rhino.jstype.JSType jSType10 = jSType8.findPropertyType("");
        com.google.javascript.rhino.ErrorReporter errorReporter11 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry12 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter11);
        com.google.javascript.rhino.jstype.JSType jSType13 = null;
        com.google.javascript.rhino.jstype.JSType jSType15 = jSTypeRegistry12.getGreatestSubtypeWithProperty(jSType13, "");
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray16 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.Node node17 = jSTypeRegistry12.createOptionalParameters(jSTypeArray16);
        com.google.javascript.rhino.jstype.FunctionType functionType18 = jSTypeRegistry1.createFunctionTypeWithVarArgs(jSType8, jSTypeArray16);
        java.util.Set<java.lang.String> strSet19 = functionType18.getOwnPropertyNames();
        boolean boolean20 = functionType18.isInterface();
        com.google.javascript.rhino.jstype.JSType jSType21 = null;
        boolean boolean22 = functionType18.isEquivalentTo(jSType21);
        com.google.javascript.rhino.jstype.ObjectType objectType23 = functionType18.getImplicitPrototype();
        org.junit.Assert.assertNotNull(objectTypeSet3);
        org.junit.Assert.assertNotNull(jSType8);
        org.junit.Assert.assertNotNull(jSType10);
        org.junit.Assert.assertNotNull(jSType15);
        org.junit.Assert.assertNotNull(jSTypeArray16);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(functionType18);
        org.junit.Assert.assertNotNull(strSet19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(objectType23);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        com.google.javascript.rhino.jstype.JSType jSType2 = null;
        com.google.javascript.rhino.jstype.JSType jSType4 = jSTypeRegistry1.getGreatestSubtypeWithProperty(jSType2, "");
        boolean boolean6 = jSTypeRegistry1.isForwardDeclaredType("Not declared as a constructor");
        com.google.javascript.rhino.ErrorReporter errorReporter7 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry8 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter7);
        com.google.javascript.rhino.jstype.JSType jSType9 = null;
        com.google.javascript.rhino.jstype.JSType jSType11 = jSTypeRegistry8.getGreatestSubtypeWithProperty(jSType9, "");
        com.google.javascript.rhino.ErrorReporter errorReporter12 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry13 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter12);
        com.google.javascript.rhino.jstype.JSType jSType14 = null;
        com.google.javascript.rhino.jstype.JSType jSType16 = jSTypeRegistry13.getGreatestSubtypeWithProperty(jSType14, "");
        com.google.javascript.rhino.jstype.JSType jSType18 = jSType16.findPropertyType("");
        com.google.javascript.rhino.jstype.ObjectType objectType19 = jSType16.dereference();
        boolean boolean20 = objectType19.isNumber();
        com.google.javascript.rhino.ErrorReporter errorReporter21 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry22 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter21);
        com.google.javascript.rhino.jstype.JSType jSType23 = null;
        com.google.javascript.rhino.jstype.JSType jSType25 = jSTypeRegistry22.getGreatestSubtypeWithProperty(jSType23, "");
        com.google.javascript.rhino.jstype.JSType jSType27 = jSType25.findPropertyType("");
        com.google.javascript.rhino.jstype.ObjectType objectType28 = jSType25.dereference();
        boolean boolean29 = objectType28.isNumber();
        com.google.javascript.rhino.jstype.JSType jSType30 = objectType19.getGreatestSubtype((com.google.javascript.rhino.jstype.JSType) objectType28);
        boolean boolean31 = jSType11.canAssignTo((com.google.javascript.rhino.jstype.JSType) objectType19);
        com.google.javascript.rhino.jstype.JSType jSType33 = jSTypeRegistry1.getGreatestSubtypeWithProperty(jSType11, "-1");
        com.google.javascript.rhino.ErrorReporter errorReporter35 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry36 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter35);
        com.google.javascript.rhino.jstype.JSType jSType37 = null;
        com.google.javascript.rhino.jstype.JSType jSType39 = jSTypeRegistry36.getGreatestSubtypeWithProperty(jSType37, "");
        com.google.javascript.rhino.Node node44 = com.google.javascript.rhino.Node.newNumber((double) (short) 100, 0, (int) (byte) -1);
        node44.removeProp((int) (short) 1);
        com.google.javascript.rhino.Node node47 = node44.removeFirstChild();
        com.google.javascript.rhino.ErrorReporter errorReporter48 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry49 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter48);
        java.util.Set<com.google.javascript.rhino.jstype.ObjectType> objectTypeSet51 = jSTypeRegistry49.getTypesWithProperty("");
        com.google.javascript.rhino.ErrorReporter errorReporter52 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry53 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter52);
        com.google.javascript.rhino.jstype.JSType jSType54 = null;
        com.google.javascript.rhino.jstype.JSType jSType56 = jSTypeRegistry53.getGreatestSubtypeWithProperty(jSType54, "");
        com.google.javascript.rhino.jstype.JSType jSType58 = jSType56.findPropertyType("");
        com.google.javascript.rhino.ErrorReporter errorReporter59 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry60 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter59);
        com.google.javascript.rhino.jstype.JSType jSType61 = null;
        com.google.javascript.rhino.jstype.JSType jSType63 = jSTypeRegistry60.getGreatestSubtypeWithProperty(jSType61, "");
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray64 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.Node node65 = jSTypeRegistry60.createOptionalParameters(jSTypeArray64);
        com.google.javascript.rhino.jstype.FunctionType functionType66 = jSTypeRegistry49.createFunctionTypeWithVarArgs(jSType56, jSTypeArray64);
        com.google.javascript.rhino.jstype.ObjectType objectType67 = jSTypeRegistry36.createObjectType("Unknown class name", node44, (com.google.javascript.rhino.jstype.ObjectType) functionType66);
        jSTypeRegistry1.registerPropertyOnType("function (function (this:me, {1100568350}): me, function (this:me, {1143600822}): me): function (this:me, {1364033037}): me", (com.google.javascript.rhino.jstype.JSType) functionType66);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable69 = functionType66.getImplementedInterfaces();
        org.junit.Assert.assertNotNull(jSType4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(jSType11);
        org.junit.Assert.assertNotNull(jSType16);
        org.junit.Assert.assertNotNull(jSType18);
        org.junit.Assert.assertNotNull(objectType19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(jSType25);
        org.junit.Assert.assertNotNull(jSType27);
        org.junit.Assert.assertNotNull(objectType28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertNotNull(jSType30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertNotNull(jSType33);
        org.junit.Assert.assertNotNull(jSType39);
        org.junit.Assert.assertNotNull(node44);
        org.junit.Assert.assertNull(node47);
        org.junit.Assert.assertNotNull(objectTypeSet51);
        org.junit.Assert.assertNotNull(jSType56);
        org.junit.Assert.assertNotNull(jSType58);
        org.junit.Assert.assertNotNull(jSType63);
        org.junit.Assert.assertNotNull(jSTypeArray64);
        org.junit.Assert.assertNotNull(node65);
        org.junit.Assert.assertNotNull(functionType66);
        org.junit.Assert.assertNotNull(objectType67);
        org.junit.Assert.assertNotNull(objectTypeIterable69);
    }
}

