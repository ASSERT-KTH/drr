import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        com.google.javascript.jscomp.CodingConvention codingConvention0 = null;
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention1 = new com.google.javascript.jscomp.GoogleCodingConvention(codingConvention0);
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention2 = new com.google.javascript.jscomp.GoogleCodingConvention((com.google.javascript.jscomp.CodingConvention) googleCodingConvention1);
        try {
            com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention3 = new com.google.javascript.jscomp.ClosureCodingConvention((com.google.javascript.jscomp.CodingConvention) googleCodingConvention1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry0 = null;
        com.google.javascript.rhino.jstype.FunctionBuilder functionBuilder1 = new com.google.javascript.rhino.jstype.FunctionBuilder(jSTypeRegistry0);
        com.google.javascript.rhino.jstype.FunctionBuilder functionBuilder3 = functionBuilder1.setIsConstructor(false);
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString((int) (short) -1, "");
        boolean boolean7 = node6.isThrow();
        com.google.javascript.rhino.Node node9 = new com.google.javascript.rhino.Node(10);
        com.google.javascript.rhino.Node node11 = new com.google.javascript.rhino.Node(10);
        boolean boolean12 = node9.isEquivalentToTyped(node11);
        boolean boolean13 = node9.isOnlyModifiesThisCall();
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.IR.throwNode(node9);
        com.google.javascript.rhino.Node node15 = node6.useSourceInfoIfMissingFrom(node9);
        com.google.javascript.rhino.jstype.FunctionBuilder functionBuilder16 = functionBuilder3.withSourceNode(node9);
        boolean boolean17 = node9.isLabel();
        org.junit.Assert.assertNotNull(functionBuilder3);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertNotNull(functionBuilder16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        com.google.javascript.jscomp.DiagnosticType diagnosticType2 = com.google.javascript.jscomp.DiagnosticType.warning("hi!", "");
        com.google.javascript.jscomp.DiagnosticType diagnosticType8 = com.google.javascript.jscomp.DiagnosticType.error("", "");
        java.lang.String str9 = diagnosticType8.toString();
        java.lang.String[] strArray12 = new java.lang.String[] { "", "" };
        com.google.javascript.jscomp.JSError jSError13 = com.google.javascript.jscomp.JSError.make("hi!", (-1), 0, diagnosticType8, strArray12);
        com.google.javascript.jscomp.DiagnosticType[] diagnosticTypeArray14 = new com.google.javascript.jscomp.DiagnosticType[] { diagnosticType2, diagnosticType8 };
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup15 = new com.google.javascript.jscomp.DiagnosticGroup(diagnosticTypeArray14);
        com.google.javascript.jscomp.DiagnosticGroups.AMBIGUOUS_FUNCTION_DECL = diagnosticGroup15;
        java.lang.String str17 = diagnosticGroup15.toString();
        com.google.javascript.jscomp.DiagnosticGroups.CONSTANT_PROPERTY = diagnosticGroup15;
        com.google.javascript.jscomp.DiagnosticGroups.CHECK_REGEXP = diagnosticGroup15;
        org.junit.Assert.assertNotNull(diagnosticType2);
        org.junit.Assert.assertNotNull(diagnosticType8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + ": " + "'", str9.equals(": "));
        org.junit.Assert.assertNotNull(strArray12);
        org.junit.Assert.assertNotNull(jSError13);
        org.junit.Assert.assertNotNull(diagnosticTypeArray14);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        com.google.javascript.jscomp.DiagnosticType diagnosticType2 = com.google.javascript.jscomp.DiagnosticType.warning("hi!", "");
        com.google.javascript.jscomp.DiagnosticType diagnosticType8 = com.google.javascript.jscomp.DiagnosticType.error("", "");
        java.lang.String str9 = diagnosticType8.toString();
        java.lang.String[] strArray12 = new java.lang.String[] { "", "" };
        com.google.javascript.jscomp.JSError jSError13 = com.google.javascript.jscomp.JSError.make("hi!", (-1), 0, diagnosticType8, strArray12);
        com.google.javascript.jscomp.DiagnosticType[] diagnosticTypeArray14 = new com.google.javascript.jscomp.DiagnosticType[] { diagnosticType2, diagnosticType8 };
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup15 = new com.google.javascript.jscomp.DiagnosticGroup(diagnosticTypeArray14);
        com.google.javascript.jscomp.DiagnosticGroups.AMBIGUOUS_FUNCTION_DECL = diagnosticGroup15;
        java.lang.String str17 = diagnosticGroup15.toString();
        com.google.javascript.jscomp.DiagnosticGroups.CONST = diagnosticGroup15;
        com.google.javascript.jscomp.DiagnosticGroups.CHECK_USELESS_CODE = diagnosticGroup15;
        org.junit.Assert.assertNotNull(diagnosticType2);
        org.junit.Assert.assertNotNull(diagnosticType8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + ": " + "'", str9.equals(": "));
        org.junit.Assert.assertNotNull(strArray12);
        org.junit.Assert.assertNotNull(jSError13);
        org.junit.Assert.assertNotNull(diagnosticTypeArray14);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.Node.newString(10, "Not declared as a type name");
        com.google.javascript.rhino.Node node5 = new com.google.javascript.rhino.Node(10);
        com.google.javascript.rhino.Node node7 = new com.google.javascript.rhino.Node(10);
        boolean boolean8 = node5.isEquivalentToTyped(node7);
        com.google.javascript.rhino.Node node10 = new com.google.javascript.rhino.Node(10);
        com.google.javascript.rhino.Node node12 = new com.google.javascript.rhino.Node(10);
        boolean boolean13 = node10.isEquivalentToTyped(node12);
        java.lang.String str14 = node10.getQualifiedName();
        com.google.javascript.rhino.Node node15 = node7.srcrefTree(node10);
        boolean boolean16 = node7.isTrue();
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.Node.newString((int) (short) -1, "");
        boolean boolean20 = node19.isObjectLit();
        com.google.javascript.rhino.Node node22 = new com.google.javascript.rhino.Node(10);
        com.google.javascript.rhino.Node node24 = new com.google.javascript.rhino.Node(10);
        com.google.javascript.rhino.Node node25 = node24.cloneTree();
        com.google.javascript.rhino.Node node26 = node22.clonePropsFrom(node25);
        com.google.javascript.rhino.Node node29 = com.google.javascript.rhino.Node.newString((int) (short) -1, "");
        boolean boolean30 = node29.isObjectLit();
        com.google.javascript.rhino.Node node31 = node29.cloneTree();
        com.google.javascript.rhino.Node node32 = new com.google.javascript.rhino.Node((int) (byte) 0, node7, node19, node22, node31);
        boolean boolean33 = node31.wasEmptyNode();
        boolean boolean34 = node31.wasEmptyNode();
        try {
            com.google.javascript.rhino.Node node35 = com.google.javascript.rhino.IR.tryCatch(node2, node31);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.exportTestFunctions;
        com.google.javascript.jscomp.AnonymousFunctionNamingPolicy anonymousFunctionNamingPolicy2 = compilerOptions0.anonymousFunctionNaming;
        com.google.javascript.jscomp.parsing.Config.LanguageMode languageMode4 = null;
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.IR.block();
        com.google.javascript.jscomp.parsing.Config.LanguageMode languageMode8 = null;
        java.lang.String[] strArray12 = new java.lang.String[] { "", "" };
        java.util.LinkedHashSet<java.lang.String> strSet13 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean14 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet13, strArray12);
        com.google.javascript.jscomp.parsing.Config config15 = com.google.javascript.jscomp.parsing.ParserRunner.createConfig(true, languageMode8, false, (java.util.Set<java.lang.String>) strSet13);
        node6.setDirectives((java.util.Set<java.lang.String>) strSet13);
        com.google.javascript.jscomp.parsing.Config config17 = com.google.javascript.jscomp.parsing.ParserRunner.createConfig(true, languageMode4, false, (java.util.Set<java.lang.String>) strSet13);
        compilerOptions0.setIdGenerators((java.util.Set<java.lang.String>) strSet13);
        compilerOptions0.setNameReferenceReportPath("Unknown class name");
        com.google.javascript.jscomp.MessageBundle messageBundle21 = null;
        compilerOptions0.setMessageBundle(messageBundle21);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + anonymousFunctionNamingPolicy2 + "' != '" + com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF + "'", anonymousFunctionNamingPolicy2.equals(com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF));
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(strArray12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(config15);
        org.junit.Assert.assertNotNull(config17);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.MessageFormatter messageFormatter1 = null;
        java.util.logging.Logger logger2 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager3 = new com.google.javascript.jscomp.LoggerErrorManager(messageFormatter1, logger2);
        compiler0.setErrorManager((com.google.javascript.jscomp.ErrorManager) loggerErrorManager3);
        compiler0.reportCodeChange();
        com.google.javascript.jscomp.Result result6 = compiler0.getResult();
        org.junit.Assert.assertNotNull(result6);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.MessageBundle messageBundle1 = compilerOptions0.messageBundle;
        compilerOptions0.removeUnusedVars = true;
        boolean boolean4 = compilerOptions0.checkSuspiciousCode;
        compilerOptions0.setAmbiguateProperties(false);
        org.junit.Assert.assertNull(messageBundle1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        com.google.javascript.rhino.Node node3 = new com.google.javascript.rhino.Node(0, 0, 53);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.STRING_OBJECT_TYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.STRING_OBJECT_TYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.STRING_OBJECT_TYPE));
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        jSTypeRegistry1.identifyNonNullableName("");
        com.google.javascript.rhino.ErrorReporter errorReporter4 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter4);
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope6 = null;
        jSTypeRegistry5.resolveTypesInScope(jSTypeStaticScope6);
        com.google.javascript.rhino.jstype.JSType jSType8 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray9 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList10 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean11 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList10, jSTypeArray9);
        com.google.javascript.rhino.jstype.FunctionType functionType12 = jSTypeRegistry5.createFunctionType(jSType8, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList10);
        com.google.javascript.rhino.ErrorReporter errorReporter14 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry15 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter14);
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope16 = null;
        jSTypeRegistry15.resolveTypesInScope(jSTypeStaticScope16);
        com.google.javascript.rhino.ErrorReporter errorReporter18 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry19 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter18);
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope20 = null;
        jSTypeRegistry19.resolveTypesInScope(jSTypeStaticScope20);
        com.google.javascript.rhino.jstype.JSType jSType22 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray23 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList24 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean25 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList24, jSTypeArray23);
        com.google.javascript.rhino.jstype.FunctionType functionType26 = jSTypeRegistry19.createFunctionType(jSType22, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList24);
        com.google.javascript.rhino.JSDocInfo jSDocInfo28 = functionType26.getOwnPropertyJSDocInfo("");
        com.google.javascript.rhino.ErrorReporter errorReporter29 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry30 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter29);
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope31 = null;
        jSTypeRegistry30.resolveTypesInScope(jSTypeStaticScope31);
        com.google.javascript.rhino.jstype.JSType jSType33 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray34 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList35 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean36 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList35, jSTypeArray34);
        com.google.javascript.rhino.jstype.FunctionType functionType37 = jSTypeRegistry30.createFunctionType(jSType33, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList35);
        com.google.javascript.rhino.JSDocInfo jSDocInfo39 = functionType37.getOwnPropertyJSDocInfo("");
        com.google.javascript.rhino.jstype.ObjectType objectType40 = functionType37.getImplicitPrototype();
        boolean boolean41 = objectType40.hasCachedValues();
        com.google.javascript.rhino.ErrorReporter errorReporter42 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry43 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter42);
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope44 = null;
        jSTypeRegistry43.resolveTypesInScope(jSTypeStaticScope44);
        com.google.javascript.rhino.jstype.JSType jSType46 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray47 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList48 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean49 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList48, jSTypeArray47);
        com.google.javascript.rhino.jstype.FunctionType functionType50 = jSTypeRegistry43.createFunctionType(jSType46, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList48);
        com.google.javascript.rhino.JSDocInfo jSDocInfo52 = functionType50.getOwnPropertyJSDocInfo("");
        boolean boolean54 = functionType50.removeProperty(".  at hi! line (unknown line) : 0");
        com.google.javascript.rhino.ErrorReporter errorReporter55 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry56 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter55);
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope57 = null;
        jSTypeRegistry56.resolveTypesInScope(jSTypeStaticScope57);
        com.google.javascript.rhino.jstype.JSType jSType59 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray60 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList61 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean62 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList61, jSTypeArray60);
        com.google.javascript.rhino.jstype.FunctionType functionType63 = jSTypeRegistry56.createFunctionType(jSType59, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList61);
        com.google.javascript.rhino.ErrorReporter errorReporter64 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry65 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter64);
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope66 = null;
        jSTypeRegistry65.resolveTypesInScope(jSTypeStaticScope66);
        com.google.javascript.rhino.jstype.JSType jSType68 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray69 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList70 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean71 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList70, jSTypeArray69);
        com.google.javascript.rhino.jstype.FunctionType functionType72 = jSTypeRegistry65.createFunctionType(jSType68, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList70);
        com.google.javascript.rhino.JSDocInfo jSDocInfo74 = functionType72.getOwnPropertyJSDocInfo("");
        com.google.javascript.rhino.ErrorReporter errorReporter75 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry76 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter75);
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope77 = null;
        jSTypeRegistry76.resolveTypesInScope(jSTypeStaticScope77);
        com.google.javascript.rhino.jstype.JSType jSType79 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray80 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList81 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean82 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList81, jSTypeArray80);
        com.google.javascript.rhino.jstype.FunctionType functionType83 = jSTypeRegistry76.createFunctionType(jSType79, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList81);
        com.google.javascript.rhino.JSDocInfo jSDocInfo85 = functionType83.getOwnPropertyJSDocInfo("");
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray86 = new com.google.javascript.rhino.jstype.JSType[] { objectType40, functionType50, functionType63, functionType72, functionType83 };
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList87 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean88 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList87, jSTypeArray86);
        com.google.javascript.rhino.jstype.FunctionType functionType89 = jSTypeRegistry15.createFunctionTypeWithVarArgs((com.google.javascript.rhino.jstype.JSType) functionType26, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList87);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray90 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.Node node91 = jSTypeRegistry15.createParameters(jSTypeArray90);
        com.google.javascript.rhino.jstype.FunctionType functionType92 = jSTypeRegistry1.createConstructorType(jSType8, false, jSTypeArray90);
        boolean boolean93 = functionType92.isNumberValueType();
        com.google.javascript.rhino.Node node94 = com.google.javascript.rhino.IR.script();
        functionType92.setSource(node94);
        try {
            com.google.javascript.rhino.Node node96 = com.google.javascript.rhino.IR.breakNode(node94);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(jSTypeArray9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(functionType12);
        org.junit.Assert.assertNotNull(jSTypeArray23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(functionType26);
        org.junit.Assert.assertNull(jSDocInfo28);
        org.junit.Assert.assertNotNull(jSTypeArray34);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(functionType37);
        org.junit.Assert.assertNull(jSDocInfo39);
        org.junit.Assert.assertNotNull(objectType40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(jSTypeArray47);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNotNull(functionType50);
        org.junit.Assert.assertNull(jSDocInfo52);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNotNull(jSTypeArray60);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertNotNull(functionType63);
        org.junit.Assert.assertNotNull(jSTypeArray69);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
        org.junit.Assert.assertNotNull(functionType72);
        org.junit.Assert.assertNull(jSDocInfo74);
        org.junit.Assert.assertNotNull(jSTypeArray80);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
        org.junit.Assert.assertNotNull(functionType83);
        org.junit.Assert.assertNull(jSDocInfo85);
        org.junit.Assert.assertNotNull(jSTypeArray86);
        org.junit.Assert.assertTrue("'" + boolean88 + "' != '" + true + "'", boolean88 == true);
        org.junit.Assert.assertNotNull(functionType89);
        org.junit.Assert.assertNotNull(jSTypeArray90);
        org.junit.Assert.assertNotNull(node91);
        org.junit.Assert.assertNotNull(functionType92);
        org.junit.Assert.assertTrue("'" + boolean93 + "' != '" + false + "'", boolean93 == false);
        org.junit.Assert.assertNotNull(node94);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        com.google.javascript.jscomp.CodingConvention codingConvention0 = null;
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention1 = new com.google.javascript.jscomp.GoogleCodingConvention(codingConvention0);
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention2 = new com.google.javascript.jscomp.GoogleCodingConvention((com.google.javascript.jscomp.CodingConvention) googleCodingConvention1);
        boolean boolean4 = googleCodingConvention1.isValidEnumKey("hi!");
        try {
            java.lang.String str5 = googleCodingConvention1.getGlobalObject();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setDeadAssignmentElimination(false);
        compilerOptions0.ideMode = true;
        boolean boolean5 = compilerOptions0.preferLineBreakAtEndOfFile;
        compilerOptions0.devirtualizePrototypeMethods = false;
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope2 = null;
        jSTypeRegistry1.resolveTypesInScope(jSTypeStaticScope2);
        com.google.javascript.rhino.jstype.JSType jSType4 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray5 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList6 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean7 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList6, jSTypeArray5);
        com.google.javascript.rhino.jstype.FunctionType functionType8 = jSTypeRegistry1.createFunctionType(jSType4, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList6);
        try {
            com.google.javascript.rhino.jstype.ObjectType objectType10 = functionType8.getTopMostDefiningType("2019/06/10 13:13");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(jSTypeArray5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(functionType8);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        com.google.javascript.rhino.Node node2 = new com.google.javascript.rhino.Node(10);
        com.google.javascript.rhino.Node node3 = node2.cloneTree();
        com.google.javascript.jscomp.DiagnosticType diagnosticType6 = com.google.javascript.jscomp.DiagnosticType.error("", "");
        com.google.javascript.jscomp.DiagnosticType diagnosticType12 = com.google.javascript.jscomp.DiagnosticType.error("", "");
        java.lang.String str13 = diagnosticType12.toString();
        java.lang.String[] strArray16 = new java.lang.String[] { "", "" };
        com.google.javascript.jscomp.JSError jSError17 = com.google.javascript.jscomp.JSError.make("hi!", (-1), 0, diagnosticType12, strArray16);
        com.google.javascript.jscomp.JSError jSError18 = com.google.javascript.jscomp.JSError.make("hi!", node2, diagnosticType6, strArray16);
        boolean boolean19 = node2.isArrayLit();
        com.google.javascript.rhino.Node node20 = null;
        com.google.javascript.rhino.Node node23 = new com.google.javascript.rhino.Node(10);
        com.google.javascript.rhino.Node node24 = node23.cloneTree();
        com.google.javascript.jscomp.DiagnosticType diagnosticType27 = com.google.javascript.jscomp.DiagnosticType.error("", "");
        com.google.javascript.jscomp.DiagnosticType diagnosticType33 = com.google.javascript.jscomp.DiagnosticType.error("", "");
        java.lang.String str34 = diagnosticType33.toString();
        java.lang.String[] strArray37 = new java.lang.String[] { "", "" };
        com.google.javascript.jscomp.JSError jSError38 = com.google.javascript.jscomp.JSError.make("hi!", (-1), 0, diagnosticType33, strArray37);
        com.google.javascript.jscomp.JSError jSError39 = com.google.javascript.jscomp.JSError.make("hi!", node23, diagnosticType27, strArray37);
        try {
            node2.addChildrenAfter(node20, node23);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(diagnosticType6);
        org.junit.Assert.assertNotNull(diagnosticType12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + ": " + "'", str13.equals(": "));
        org.junit.Assert.assertNotNull(strArray16);
        org.junit.Assert.assertNotNull(jSError17);
        org.junit.Assert.assertNotNull(jSError18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertNotNull(diagnosticType27);
        org.junit.Assert.assertNotNull(diagnosticType33);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + ": " + "'", str34.equals(": "));
        org.junit.Assert.assertNotNull(strArray37);
        org.junit.Assert.assertNotNull(jSError38);
        org.junit.Assert.assertNotNull(jSError39);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.EVAL_ERROR_TYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.EVAL_ERROR_TYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.EVAL_ERROR_TYPE));
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        com.google.javascript.jscomp.ClosureCodingConvention.AssertInstanceofSpec assertInstanceofSpec1 = new com.google.javascript.jscomp.ClosureCodingConvention.AssertInstanceofSpec("");
        com.google.javascript.rhino.Node node3 = new com.google.javascript.rhino.Node(10);
        com.google.javascript.rhino.Node node5 = new com.google.javascript.rhino.Node(10);
        boolean boolean6 = node3.isEquivalentToTyped(node5);
        com.google.javascript.rhino.Node node7 = assertInstanceofSpec1.getAssertedParam(node5);
        com.google.javascript.rhino.Node node9 = new com.google.javascript.rhino.Node(10);
        com.google.javascript.rhino.Node node11 = new com.google.javascript.rhino.Node(10);
        boolean boolean12 = node9.isEquivalentToTyped(node11);
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.IR.exprResult(node11);
        com.google.javascript.rhino.Node node14 = node11.cloneNode();
        boolean boolean15 = node11.hasOneChild();
        com.google.javascript.rhino.ErrorReporter errorReporter16 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry17 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter16);
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope18 = null;
        jSTypeRegistry17.resolveTypesInScope(jSTypeStaticScope18);
        com.google.javascript.rhino.jstype.JSType jSType20 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray21 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList22 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean23 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList22, jSTypeArray21);
        com.google.javascript.rhino.jstype.FunctionType functionType24 = jSTypeRegistry17.createFunctionType(jSType20, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList22);
        jSTypeRegistry17.identifyNonNullableName("DependencyInfo(relativePath='./', path=': ', provides=[DiagnosticGroup<checkRegExp>, : , , , hi!, .  at hi! line (unknown line) : 0], requires=[./])");
        jSTypeRegistry17.clearTemplateTypeNames();
        com.google.javascript.rhino.jstype.JSType jSType28 = assertInstanceofSpec1.getAssertedType(node11, jSTypeRegistry17);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable30 = jSTypeRegistry17.getEachReferenceTypeWithProperty("module$DiagnosticGroup<checkRegExp>");
        boolean boolean31 = jSTypeRegistry17.shouldTolerateUndefinedValues();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(jSTypeArray21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(functionType24);
        org.junit.Assert.assertNotNull(jSType28);
        org.junit.Assert.assertNotNull(objectTypeIterable30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        com.google.javascript.jscomp.CodingConvention codingConvention0 = null;
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention1 = new com.google.javascript.jscomp.GoogleCodingConvention(codingConvention0);
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention2 = new com.google.javascript.jscomp.GoogleCodingConvention((com.google.javascript.jscomp.CodingConvention) googleCodingConvention1);
        boolean boolean4 = googleCodingConvention1.isValidEnumKey("hi!");
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention5 = new com.google.javascript.jscomp.GoogleCodingConvention((com.google.javascript.jscomp.CodingConvention) googleCodingConvention1);
        boolean boolean7 = googleCodingConvention1.isConstant("goog.exportProperty");
        com.google.javascript.rhino.Node node9 = new com.google.javascript.rhino.Node(10);
        com.google.javascript.rhino.Node node11 = new com.google.javascript.rhino.Node(10);
        com.google.javascript.rhino.Node node12 = node11.cloneTree();
        com.google.javascript.rhino.Node node13 = node9.clonePropsFrom(node12);
        com.google.javascript.rhino.Node[] nodeArray16 = new com.google.javascript.rhino.Node[] {};
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.IR.block(nodeArray16);
        com.google.javascript.rhino.Node node20 = new com.google.javascript.rhino.Node((int) ' ', nodeArray16, (-1), 40);
        com.google.javascript.rhino.Node node21 = com.google.javascript.rhino.IR.script(nodeArray16);
        com.google.javascript.rhino.Node node22 = new com.google.javascript.rhino.Node(0, nodeArray16);
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.IR.newNode(node9, nodeArray16);
        com.google.javascript.rhino.Node node25 = new com.google.javascript.rhino.Node(10);
        com.google.javascript.rhino.Node node27 = new com.google.javascript.rhino.Node(10);
        boolean boolean28 = node25.isEquivalentToTyped(node27);
        java.lang.String str29 = node25.getQualifiedName();
        node25.setWasEmptyNode(false);
        boolean boolean32 = node25.isDo();
        com.google.javascript.rhino.Node node34 = new com.google.javascript.rhino.Node(10);
        com.google.javascript.rhino.Node node36 = new com.google.javascript.rhino.Node(10);
        boolean boolean37 = node34.isEquivalentToTyped(node36);
        com.google.javascript.rhino.Node node38 = com.google.javascript.rhino.IR.exprResult(node36);
        com.google.javascript.rhino.Node node39 = node25.useSourceInfoIfMissingFrom(node36);
        try {
            java.lang.String str40 = googleCodingConvention1.extractClassNameIfRequire(node23, node25);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(nodeArray16);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNull(str29);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertNotNull(node38);
        org.junit.Assert.assertNotNull(node39);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        com.google.javascript.rhino.Node node2 = new com.google.javascript.rhino.Node(10);
        com.google.javascript.rhino.Node node3 = node2.cloneTree();
        com.google.javascript.jscomp.DiagnosticType diagnosticType6 = com.google.javascript.jscomp.DiagnosticType.error("", "");
        com.google.javascript.jscomp.DiagnosticType diagnosticType12 = com.google.javascript.jscomp.DiagnosticType.error("", "");
        java.lang.String str13 = diagnosticType12.toString();
        java.lang.String[] strArray16 = new java.lang.String[] { "", "" };
        com.google.javascript.jscomp.JSError jSError17 = com.google.javascript.jscomp.JSError.make("hi!", (-1), 0, diagnosticType12, strArray16);
        com.google.javascript.jscomp.JSError jSError18 = com.google.javascript.jscomp.JSError.make("hi!", node2, diagnosticType6, strArray16);
        boolean boolean19 = node2.hasOneChild();
        com.google.javascript.rhino.Node node21 = new com.google.javascript.rhino.Node(10);
        com.google.javascript.rhino.Node node22 = node21.cloneTree();
        int int23 = node2.getIndexOfChild(node22);
        node2.putIntProp(0, (int) (short) 10);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(diagnosticType6);
        org.junit.Assert.assertNotNull(diagnosticType12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + ": " + "'", str13.equals(": "));
        org.junit.Assert.assertNotNull(strArray16);
        org.junit.Assert.assertNotNull(jSError17);
        org.junit.Assert.assertNotNull(jSError18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope2 = null;
        jSTypeRegistry1.resolveTypesInScope(jSTypeStaticScope2);
        com.google.javascript.rhino.ErrorReporter errorReporter4 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter4);
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope6 = null;
        jSTypeRegistry5.resolveTypesInScope(jSTypeStaticScope6);
        com.google.javascript.rhino.jstype.JSType jSType8 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray9 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList10 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean11 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList10, jSTypeArray9);
        com.google.javascript.rhino.jstype.FunctionType functionType12 = jSTypeRegistry5.createFunctionType(jSType8, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList10);
        com.google.javascript.rhino.JSDocInfo jSDocInfo14 = functionType12.getOwnPropertyJSDocInfo("");
        com.google.javascript.rhino.ErrorReporter errorReporter15 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry16 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter15);
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope17 = null;
        jSTypeRegistry16.resolveTypesInScope(jSTypeStaticScope17);
        com.google.javascript.rhino.jstype.JSType jSType19 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray20 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList21 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean22 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList21, jSTypeArray20);
        com.google.javascript.rhino.jstype.FunctionType functionType23 = jSTypeRegistry16.createFunctionType(jSType19, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList21);
        com.google.javascript.rhino.JSDocInfo jSDocInfo25 = functionType23.getOwnPropertyJSDocInfo("");
        com.google.javascript.rhino.jstype.ObjectType objectType26 = functionType23.getImplicitPrototype();
        boolean boolean27 = objectType26.hasCachedValues();
        com.google.javascript.rhino.ErrorReporter errorReporter28 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry29 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter28);
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope30 = null;
        jSTypeRegistry29.resolveTypesInScope(jSTypeStaticScope30);
        com.google.javascript.rhino.jstype.JSType jSType32 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray33 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList34 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean35 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList34, jSTypeArray33);
        com.google.javascript.rhino.jstype.FunctionType functionType36 = jSTypeRegistry29.createFunctionType(jSType32, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList34);
        com.google.javascript.rhino.JSDocInfo jSDocInfo38 = functionType36.getOwnPropertyJSDocInfo("");
        boolean boolean40 = functionType36.removeProperty(".  at hi! line (unknown line) : 0");
        com.google.javascript.rhino.ErrorReporter errorReporter41 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry42 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter41);
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope43 = null;
        jSTypeRegistry42.resolveTypesInScope(jSTypeStaticScope43);
        com.google.javascript.rhino.jstype.JSType jSType45 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray46 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList47 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean48 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList47, jSTypeArray46);
        com.google.javascript.rhino.jstype.FunctionType functionType49 = jSTypeRegistry42.createFunctionType(jSType45, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList47);
        com.google.javascript.rhino.ErrorReporter errorReporter50 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry51 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter50);
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope52 = null;
        jSTypeRegistry51.resolveTypesInScope(jSTypeStaticScope52);
        com.google.javascript.rhino.jstype.JSType jSType54 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray55 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList56 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean57 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList56, jSTypeArray55);
        com.google.javascript.rhino.jstype.FunctionType functionType58 = jSTypeRegistry51.createFunctionType(jSType54, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList56);
        com.google.javascript.rhino.JSDocInfo jSDocInfo60 = functionType58.getOwnPropertyJSDocInfo("");
        com.google.javascript.rhino.ErrorReporter errorReporter61 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry62 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter61);
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope63 = null;
        jSTypeRegistry62.resolveTypesInScope(jSTypeStaticScope63);
        com.google.javascript.rhino.jstype.JSType jSType65 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray66 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList67 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean68 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList67, jSTypeArray66);
        com.google.javascript.rhino.jstype.FunctionType functionType69 = jSTypeRegistry62.createFunctionType(jSType65, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList67);
        com.google.javascript.rhino.JSDocInfo jSDocInfo71 = functionType69.getOwnPropertyJSDocInfo("");
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray72 = new com.google.javascript.rhino.jstype.JSType[] { objectType26, functionType36, functionType49, functionType58, functionType69 };
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList73 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean74 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList73, jSTypeArray72);
        com.google.javascript.rhino.jstype.FunctionType functionType75 = jSTypeRegistry1.createFunctionTypeWithVarArgs((com.google.javascript.rhino.jstype.JSType) functionType12, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList73);
        boolean boolean77 = functionType75.isPropertyInExterns("");
        boolean boolean78 = functionType75.isNumberValueType();
        int int79 = functionType75.getPropertiesCount();
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable80 = functionType75.getCtorImplementedInterfaces();
        boolean boolean81 = functionType75.isNoResolvedType();
        org.junit.Assert.assertNotNull(jSTypeArray9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(functionType12);
        org.junit.Assert.assertNull(jSDocInfo14);
        org.junit.Assert.assertNotNull(jSTypeArray20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(functionType23);
        org.junit.Assert.assertNull(jSDocInfo25);
        org.junit.Assert.assertNotNull(objectType26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(jSTypeArray33);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(functionType36);
        org.junit.Assert.assertNull(jSDocInfo38);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(jSTypeArray46);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(functionType49);
        org.junit.Assert.assertNotNull(jSTypeArray55);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertNotNull(functionType58);
        org.junit.Assert.assertNull(jSDocInfo60);
        org.junit.Assert.assertNotNull(jSTypeArray66);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertNotNull(functionType69);
        org.junit.Assert.assertNull(jSDocInfo71);
        org.junit.Assert.assertNotNull(jSTypeArray72);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + true + "'", boolean74 == true);
        org.junit.Assert.assertNotNull(functionType75);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
        org.junit.Assert.assertTrue("'" + int79 + "' != '" + 0 + "'", int79 == 0);
        org.junit.Assert.assertNotNull(objectTypeIterable80);
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + false + "'", boolean81 == false);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.CONSTANT_PROPERTY;
        com.google.javascript.jscomp.DiagnosticGroups.STRICT_MODULE_DEP_CHECK = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticGroups.DUPLICATE_MESSAGE = diagnosticGroup0;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope2 = null;
        jSTypeRegistry1.resolveTypesInScope(jSTypeStaticScope2);
        com.google.javascript.rhino.ErrorReporter errorReporter4 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter4);
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope6 = null;
        jSTypeRegistry5.resolveTypesInScope(jSTypeStaticScope6);
        com.google.javascript.rhino.jstype.JSType jSType8 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray9 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList10 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean11 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList10, jSTypeArray9);
        com.google.javascript.rhino.jstype.FunctionType functionType12 = jSTypeRegistry5.createFunctionType(jSType8, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList10);
        com.google.javascript.rhino.JSDocInfo jSDocInfo14 = functionType12.getOwnPropertyJSDocInfo("");
        com.google.javascript.rhino.ErrorReporter errorReporter15 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry16 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter15);
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope17 = null;
        jSTypeRegistry16.resolveTypesInScope(jSTypeStaticScope17);
        com.google.javascript.rhino.jstype.JSType jSType19 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray20 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList21 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean22 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList21, jSTypeArray20);
        com.google.javascript.rhino.jstype.FunctionType functionType23 = jSTypeRegistry16.createFunctionType(jSType19, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList21);
        com.google.javascript.rhino.JSDocInfo jSDocInfo25 = functionType23.getOwnPropertyJSDocInfo("");
        com.google.javascript.rhino.jstype.ObjectType objectType26 = functionType23.getImplicitPrototype();
        boolean boolean27 = objectType26.hasCachedValues();
        com.google.javascript.rhino.ErrorReporter errorReporter28 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry29 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter28);
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope30 = null;
        jSTypeRegistry29.resolveTypesInScope(jSTypeStaticScope30);
        com.google.javascript.rhino.jstype.JSType jSType32 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray33 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList34 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean35 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList34, jSTypeArray33);
        com.google.javascript.rhino.jstype.FunctionType functionType36 = jSTypeRegistry29.createFunctionType(jSType32, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList34);
        com.google.javascript.rhino.JSDocInfo jSDocInfo38 = functionType36.getOwnPropertyJSDocInfo("");
        boolean boolean40 = functionType36.removeProperty(".  at hi! line (unknown line) : 0");
        com.google.javascript.rhino.ErrorReporter errorReporter41 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry42 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter41);
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope43 = null;
        jSTypeRegistry42.resolveTypesInScope(jSTypeStaticScope43);
        com.google.javascript.rhino.jstype.JSType jSType45 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray46 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList47 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean48 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList47, jSTypeArray46);
        com.google.javascript.rhino.jstype.FunctionType functionType49 = jSTypeRegistry42.createFunctionType(jSType45, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList47);
        com.google.javascript.rhino.ErrorReporter errorReporter50 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry51 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter50);
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope52 = null;
        jSTypeRegistry51.resolveTypesInScope(jSTypeStaticScope52);
        com.google.javascript.rhino.jstype.JSType jSType54 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray55 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList56 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean57 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList56, jSTypeArray55);
        com.google.javascript.rhino.jstype.FunctionType functionType58 = jSTypeRegistry51.createFunctionType(jSType54, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList56);
        com.google.javascript.rhino.JSDocInfo jSDocInfo60 = functionType58.getOwnPropertyJSDocInfo("");
        com.google.javascript.rhino.ErrorReporter errorReporter61 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry62 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter61);
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope63 = null;
        jSTypeRegistry62.resolveTypesInScope(jSTypeStaticScope63);
        com.google.javascript.rhino.jstype.JSType jSType65 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray66 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList67 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean68 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList67, jSTypeArray66);
        com.google.javascript.rhino.jstype.FunctionType functionType69 = jSTypeRegistry62.createFunctionType(jSType65, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList67);
        com.google.javascript.rhino.JSDocInfo jSDocInfo71 = functionType69.getOwnPropertyJSDocInfo("");
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray72 = new com.google.javascript.rhino.jstype.JSType[] { objectType26, functionType36, functionType49, functionType58, functionType69 };
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList73 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean74 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList73, jSTypeArray72);
        com.google.javascript.rhino.jstype.FunctionType functionType75 = jSTypeRegistry1.createFunctionTypeWithVarArgs((com.google.javascript.rhino.jstype.JSType) functionType12, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList73);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray76 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.Node node77 = jSTypeRegistry1.createParameters(jSTypeArray76);
        com.google.javascript.rhino.Node node78 = node77.getFirstChild();
        try {
            node78.setSideEffectFlags(38);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jSTypeArray9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(functionType12);
        org.junit.Assert.assertNull(jSDocInfo14);
        org.junit.Assert.assertNotNull(jSTypeArray20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(functionType23);
        org.junit.Assert.assertNull(jSDocInfo25);
        org.junit.Assert.assertNotNull(objectType26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(jSTypeArray33);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(functionType36);
        org.junit.Assert.assertNull(jSDocInfo38);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(jSTypeArray46);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(functionType49);
        org.junit.Assert.assertNotNull(jSTypeArray55);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertNotNull(functionType58);
        org.junit.Assert.assertNull(jSDocInfo60);
        org.junit.Assert.assertNotNull(jSTypeArray66);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertNotNull(functionType69);
        org.junit.Assert.assertNull(jSDocInfo71);
        org.junit.Assert.assertNotNull(jSTypeArray72);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + true + "'", boolean74 == true);
        org.junit.Assert.assertNotNull(functionType75);
        org.junit.Assert.assertNotNull(jSTypeArray76);
        org.junit.Assert.assertNotNull(node77);
        org.junit.Assert.assertNull(node78);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.returnNode();
        com.google.javascript.rhino.Node node2 = new com.google.javascript.rhino.Node(10);
        com.google.javascript.rhino.Node node4 = new com.google.javascript.rhino.Node(10);
        boolean boolean5 = node2.isEquivalentToTyped(node4);
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.IR.exprResult(node4);
        com.google.javascript.rhino.Node node7 = node4.cloneNode();
        boolean boolean8 = node4.hasOneChild();
        com.google.javascript.rhino.Node node9 = node4.cloneTree();
        com.google.javascript.rhino.Node node10 = node0.useSourceInfoFrom(node4);
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.IR.block();
        com.google.javascript.jscomp.parsing.Config.LanguageMode languageMode13 = null;
        java.lang.String[] strArray17 = new java.lang.String[] { "", "" };
        java.util.LinkedHashSet<java.lang.String> strSet18 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean19 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet18, strArray17);
        com.google.javascript.jscomp.parsing.Config config20 = com.google.javascript.jscomp.parsing.ParserRunner.createConfig(true, languageMode13, false, (java.util.Set<java.lang.String>) strSet18);
        node11.setDirectives((java.util.Set<java.lang.String>) strSet18);
        java.lang.String str22 = node10.checkTreeEquals(node11);
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertNotNull(strArray17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(config20);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "Node tree inequality:\nTree1:\nRETURN\n\n\nTree2:\nBLOCK [directives: []]\n\n\nSubtree1: RETURN\n\n\nSubtree2: BLOCK [directives: []]\n" + "'", str22.equals("Node tree inequality:\nTree1:\nRETURN\n\n\nTree2:\nBLOCK [directives: []]\n\n\nSubtree1: RETURN\n\n\nSubtree2: BLOCK [directives: []]\n"));
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope2 = null;
        jSTypeRegistry1.resolveTypesInScope(jSTypeStaticScope2);
        com.google.javascript.rhino.jstype.JSType jSType4 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray5 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList6 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean7 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList6, jSTypeArray5);
        com.google.javascript.rhino.jstype.FunctionType functionType8 = jSTypeRegistry1.createFunctionType(jSType4, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList6);
        com.google.javascript.rhino.ErrorReporter errorReporter9 = jSTypeRegistry1.getErrorReporter();
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray10 = null;
        try {
            com.google.javascript.rhino.Node node11 = jSTypeRegistry1.createParametersWithVarArgs(jSTypeArray10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jSTypeArray5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(functionType8);
        org.junit.Assert.assertNull(errorReporter9);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setCheckTypes(false);
        boolean boolean3 = compilerOptions0.removeTryCatchFinally;
        boolean boolean4 = compilerOptions0.removeDeadCode;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        java.lang.String str1 = com.google.javascript.jscomp.ProcessCommonJSModules.toModuleName("Not declared as a type name");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "module$Not declared as a type name" + "'", str1.equals("module$Not declared as a type name"));
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope2 = null;
        jSTypeRegistry1.resolveTypesInScope(jSTypeStaticScope2);
        com.google.javascript.rhino.jstype.JSType jSType4 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray5 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList6 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean7 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList6, jSTypeArray5);
        com.google.javascript.rhino.jstype.FunctionType functionType8 = jSTypeRegistry1.createFunctionType(jSType4, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList6);
        boolean boolean9 = functionType8.hasReferenceName();
        com.google.javascript.rhino.jstype.ObjectType objectType10 = functionType8.getTypeOfThis();
        com.google.javascript.rhino.ErrorReporter errorReporter11 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry12 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter11);
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope13 = null;
        jSTypeRegistry12.resolveTypesInScope(jSTypeStaticScope13);
        com.google.javascript.rhino.jstype.JSType jSType15 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray16 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList17 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean18 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList17, jSTypeArray16);
        com.google.javascript.rhino.jstype.FunctionType functionType19 = jSTypeRegistry12.createFunctionType(jSType15, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList17);
        com.google.javascript.rhino.JSDocInfo jSDocInfo21 = functionType19.getOwnPropertyJSDocInfo("");
        com.google.javascript.rhino.JSDocInfo jSDocInfo22 = functionType19.getJSDocInfo();
        com.google.javascript.rhino.jstype.TernaryValue ternaryValue23 = functionType8.testForEquality((com.google.javascript.rhino.jstype.JSType) functionType19);
        boolean boolean24 = functionType19.isNumber();
        org.junit.Assert.assertNotNull(jSTypeArray5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(functionType8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(objectType10);
        org.junit.Assert.assertNotNull(jSTypeArray16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(functionType19);
        org.junit.Assert.assertNull(jSDocInfo21);
        org.junit.Assert.assertNull(jSDocInfo22);
        org.junit.Assert.assertNotNull(ternaryValue23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        com.google.javascript.rhino.Node node2 = new com.google.javascript.rhino.Node(10);
        com.google.javascript.rhino.Node node3 = node2.cloneTree();
        com.google.javascript.jscomp.DiagnosticType diagnosticType6 = com.google.javascript.jscomp.DiagnosticType.error("", "");
        com.google.javascript.jscomp.DiagnosticType diagnosticType12 = com.google.javascript.jscomp.DiagnosticType.error("", "");
        java.lang.String str13 = diagnosticType12.toString();
        java.lang.String[] strArray16 = new java.lang.String[] { "", "" };
        com.google.javascript.jscomp.JSError jSError17 = com.google.javascript.jscomp.JSError.make("hi!", (-1), 0, diagnosticType12, strArray16);
        com.google.javascript.jscomp.JSError jSError18 = com.google.javascript.jscomp.JSError.make("hi!", node2, diagnosticType6, strArray16);
        boolean boolean19 = node2.isArrayLit();
        com.google.javascript.rhino.Node node20 = node2.removeFirstChild();
        java.lang.String str21 = node2.getSourceFileName();
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(diagnosticType6);
        org.junit.Assert.assertNotNull(diagnosticType12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + ": " + "'", str13.equals(": "));
        org.junit.Assert.assertNotNull(strArray16);
        org.junit.Assert.assertNotNull(jSError17);
        org.junit.Assert.assertNotNull(jSError18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNull(node20);
        org.junit.Assert.assertNull(str21);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.MessageFormatter messageFormatter1 = null;
        java.util.logging.Logger logger2 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager3 = new com.google.javascript.jscomp.LoggerErrorManager(messageFormatter1, logger2);
        compiler0.setErrorManager((com.google.javascript.jscomp.ErrorManager) loggerErrorManager3);
        com.google.javascript.jscomp.NodeTraversal.Callback callback5 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal6 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler0, callback5);
        try {
            com.google.javascript.jscomp.CompilerInput compilerInput7 = nodeTraversal6.getInput();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope2 = null;
        jSTypeRegistry1.resolveTypesInScope(jSTypeStaticScope2);
        com.google.javascript.rhino.jstype.JSType jSType4 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray5 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList6 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean7 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList6, jSTypeArray5);
        com.google.javascript.rhino.jstype.FunctionType functionType8 = jSTypeRegistry1.createFunctionType(jSType4, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList6);
        com.google.javascript.rhino.JSDocInfo jSDocInfo10 = functionType8.getOwnPropertyJSDocInfo("");
        com.google.javascript.rhino.jstype.ObjectType objectType11 = functionType8.getImplicitPrototype();
        int int12 = functionType8.getMinArguments();
        com.google.javascript.rhino.JSDocInfo jSDocInfo13 = functionType8.getJSDocInfo();
        com.google.javascript.rhino.Node node15 = functionType8.getPropertyNode("2019/06/10 13:13");
        org.junit.Assert.assertNotNull(jSTypeArray5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(functionType8);
        org.junit.Assert.assertNull(jSDocInfo10);
        org.junit.Assert.assertNotNull(objectType11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNull(jSDocInfo13);
        org.junit.Assert.assertNull(node15);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        com.google.javascript.rhino.Node node1 = new com.google.javascript.rhino.Node(10);
        com.google.javascript.rhino.Node node3 = new com.google.javascript.rhino.Node(10);
        boolean boolean4 = node1.isEquivalentToTyped(node3);
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.IR.voidNode(node3);
        boolean boolean6 = node3.isVar();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

//    @Test
//    public void test032() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test032");
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry0 = null;
//        com.google.javascript.rhino.jstype.FunctionBuilder functionBuilder1 = new com.google.javascript.rhino.jstype.FunctionBuilder(jSTypeRegistry0);
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = null;
//        com.google.javascript.rhino.jstype.FunctionParamBuilder functionParamBuilder3 = new com.google.javascript.rhino.jstype.FunctionParamBuilder(jSTypeRegistry2);
//        boolean boolean4 = functionParamBuilder3.hasVarArgs();
//        com.google.javascript.rhino.jstype.FunctionBuilder functionBuilder5 = functionBuilder1.withParams(functionParamBuilder3);
//        com.google.javascript.rhino.ErrorReporter errorReporter6 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry7 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter6);
//        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope8 = null;
//        jSTypeRegistry7.resolveTypesInScope(jSTypeStaticScope8);
//        com.google.javascript.rhino.ErrorReporter errorReporter10 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry11 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter10);
//        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope12 = null;
//        jSTypeRegistry11.resolveTypesInScope(jSTypeStaticScope12);
//        com.google.javascript.rhino.jstype.JSType jSType14 = null;
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray15 = new com.google.javascript.rhino.jstype.JSType[] {};
//        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList16 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
//        boolean boolean17 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList16, jSTypeArray15);
//        com.google.javascript.rhino.jstype.FunctionType functionType18 = jSTypeRegistry11.createFunctionType(jSType14, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList16);
//        com.google.javascript.rhino.JSDocInfo jSDocInfo20 = functionType18.getOwnPropertyJSDocInfo("");
//        com.google.javascript.rhino.ErrorReporter errorReporter21 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry22 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter21);
//        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope23 = null;
//        jSTypeRegistry22.resolveTypesInScope(jSTypeStaticScope23);
//        com.google.javascript.rhino.jstype.JSType jSType25 = null;
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray26 = new com.google.javascript.rhino.jstype.JSType[] {};
//        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList27 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
//        boolean boolean28 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList27, jSTypeArray26);
//        com.google.javascript.rhino.jstype.FunctionType functionType29 = jSTypeRegistry22.createFunctionType(jSType25, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList27);
//        com.google.javascript.rhino.JSDocInfo jSDocInfo31 = functionType29.getOwnPropertyJSDocInfo("");
//        com.google.javascript.rhino.jstype.ObjectType objectType32 = functionType29.getImplicitPrototype();
//        boolean boolean33 = objectType32.hasCachedValues();
//        com.google.javascript.rhino.ErrorReporter errorReporter34 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry35 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter34);
//        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope36 = null;
//        jSTypeRegistry35.resolveTypesInScope(jSTypeStaticScope36);
//        com.google.javascript.rhino.jstype.JSType jSType38 = null;
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray39 = new com.google.javascript.rhino.jstype.JSType[] {};
//        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList40 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
//        boolean boolean41 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList40, jSTypeArray39);
//        com.google.javascript.rhino.jstype.FunctionType functionType42 = jSTypeRegistry35.createFunctionType(jSType38, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList40);
//        com.google.javascript.rhino.JSDocInfo jSDocInfo44 = functionType42.getOwnPropertyJSDocInfo("");
//        boolean boolean46 = functionType42.removeProperty(".  at hi! line (unknown line) : 0");
//        com.google.javascript.rhino.ErrorReporter errorReporter47 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry48 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter47);
//        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope49 = null;
//        jSTypeRegistry48.resolveTypesInScope(jSTypeStaticScope49);
//        com.google.javascript.rhino.jstype.JSType jSType51 = null;
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray52 = new com.google.javascript.rhino.jstype.JSType[] {};
//        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList53 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
//        boolean boolean54 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList53, jSTypeArray52);
//        com.google.javascript.rhino.jstype.FunctionType functionType55 = jSTypeRegistry48.createFunctionType(jSType51, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList53);
//        com.google.javascript.rhino.ErrorReporter errorReporter56 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry57 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter56);
//        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope58 = null;
//        jSTypeRegistry57.resolveTypesInScope(jSTypeStaticScope58);
//        com.google.javascript.rhino.jstype.JSType jSType60 = null;
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray61 = new com.google.javascript.rhino.jstype.JSType[] {};
//        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList62 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
//        boolean boolean63 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList62, jSTypeArray61);
//        com.google.javascript.rhino.jstype.FunctionType functionType64 = jSTypeRegistry57.createFunctionType(jSType60, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList62);
//        com.google.javascript.rhino.JSDocInfo jSDocInfo66 = functionType64.getOwnPropertyJSDocInfo("");
//        com.google.javascript.rhino.ErrorReporter errorReporter67 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry68 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter67);
//        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope69 = null;
//        jSTypeRegistry68.resolveTypesInScope(jSTypeStaticScope69);
//        com.google.javascript.rhino.jstype.JSType jSType71 = null;
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray72 = new com.google.javascript.rhino.jstype.JSType[] {};
//        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList73 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
//        boolean boolean74 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList73, jSTypeArray72);
//        com.google.javascript.rhino.jstype.FunctionType functionType75 = jSTypeRegistry68.createFunctionType(jSType71, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList73);
//        com.google.javascript.rhino.JSDocInfo jSDocInfo77 = functionType75.getOwnPropertyJSDocInfo("");
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray78 = new com.google.javascript.rhino.jstype.JSType[] { objectType32, functionType42, functionType55, functionType64, functionType75 };
//        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList79 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
//        boolean boolean80 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList79, jSTypeArray78);
//        com.google.javascript.rhino.jstype.FunctionType functionType81 = jSTypeRegistry7.createFunctionTypeWithVarArgs((com.google.javascript.rhino.jstype.JSType) functionType18, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList79);
//        java.lang.String str82 = functionType81.toDebugHashCodeString();
//        com.google.javascript.rhino.jstype.FunctionBuilder functionBuilder83 = functionBuilder5.withReturnType((com.google.javascript.rhino.jstype.JSType) functionType81);
//        try {
//            com.google.javascript.rhino.jstype.ObjectType objectType85 = functionType81.getTopMostDefiningType("function (): {396369497}");
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
//        } catch (java.lang.IllegalStateException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertNotNull(functionBuilder5);
//        org.junit.Assert.assertNotNull(jSTypeArray15);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertNotNull(functionType18);
//        org.junit.Assert.assertNull(jSDocInfo20);
//        org.junit.Assert.assertNotNull(jSTypeArray26);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//        org.junit.Assert.assertNotNull(functionType29);
//        org.junit.Assert.assertNull(jSDocInfo31);
//        org.junit.Assert.assertNotNull(objectType32);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
//        org.junit.Assert.assertNotNull(jSTypeArray39);
//        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
//        org.junit.Assert.assertNotNull(functionType42);
//        org.junit.Assert.assertNull(jSDocInfo44);
//        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
//        org.junit.Assert.assertNotNull(jSTypeArray52);
//        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
//        org.junit.Assert.assertNotNull(functionType55);
//        org.junit.Assert.assertNotNull(jSTypeArray61);
//        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
//        org.junit.Assert.assertNotNull(functionType64);
//        org.junit.Assert.assertNull(jSDocInfo66);
//        org.junit.Assert.assertNotNull(jSTypeArray72);
//        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
//        org.junit.Assert.assertNotNull(functionType75);
//        org.junit.Assert.assertNull(jSDocInfo77);
//        org.junit.Assert.assertNotNull(jSTypeArray78);
//        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + true + "'", boolean80 == true);
//        org.junit.Assert.assertNotNull(functionType81);
//        org.junit.Assert.assertTrue("'" + str82 + "' != '" + "function ({-1449262206}, function (): {1652314470}, function (): {1338257933}, function (): {1504844900}, {(function (): {881100559},{1546220337})}): function (): {1013323581}" + "'", str82.equals("function ({-1449262206}, function (): {1652314470}, function (): {1338257933}, function (): {1504844900}, {(function (): {881100559},{1546220337})}): function (): {1013323581}"));
//        org.junit.Assert.assertNotNull(functionBuilder83);
//    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        com.google.javascript.rhino.ErrorReporter errorReporter2 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry3 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter2);
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope4 = null;
        jSTypeRegistry3.resolveTypesInScope(jSTypeStaticScope4);
        com.google.javascript.rhino.jstype.ObjectType objectType6 = null;
        com.google.javascript.rhino.ErrorReporter errorReporter7 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry8 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter7);
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope9 = null;
        jSTypeRegistry8.resolveTypesInScope(jSTypeStaticScope9);
        com.google.javascript.rhino.jstype.JSType jSType11 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray12 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList13 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean14 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList13, jSTypeArray12);
        com.google.javascript.rhino.jstype.FunctionType functionType15 = jSTypeRegistry8.createFunctionType(jSType11, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList13);
        com.google.javascript.rhino.JSDocInfo jSDocInfo17 = functionType15.getOwnPropertyJSDocInfo("");
        com.google.javascript.rhino.jstype.ObjectType objectType18 = functionType15.getImplicitPrototype();
        int int19 = functionType15.getMinArguments();
        com.google.javascript.rhino.JSDocInfo jSDocInfo20 = functionType15.getJSDocInfo();
        com.google.javascript.rhino.ErrorReporter errorReporter21 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry22 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter21);
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope23 = null;
        jSTypeRegistry22.resolveTypesInScope(jSTypeStaticScope23);
        com.google.javascript.rhino.jstype.JSType jSType25 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray26 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList27 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean28 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList27, jSTypeArray26);
        com.google.javascript.rhino.jstype.FunctionType functionType29 = jSTypeRegistry22.createFunctionType(jSType25, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList27);
        com.google.javascript.rhino.jstype.JSType jSType30 = jSTypeRegistry3.createFunctionType(objectType6, (com.google.javascript.rhino.jstype.JSType) functionType15, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList27);
        com.google.javascript.rhino.Node node31 = jSTypeRegistry1.createParametersWithVarArgs((java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList27);
        java.util.List<com.google.javascript.rhino.jstype.JSType> jSTypeList32 = null;
        try {
            com.google.javascript.rhino.Node node33 = jSTypeRegistry1.createParametersWithVarArgs(jSTypeList32);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jSTypeArray12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(functionType15);
        org.junit.Assert.assertNull(jSDocInfo17);
        org.junit.Assert.assertNotNull(objectType18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNull(jSDocInfo20);
        org.junit.Assert.assertNotNull(jSTypeArray26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(functionType29);
        org.junit.Assert.assertNotNull(jSType30);
        org.junit.Assert.assertNotNull(node31);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.exportTestFunctions = false;
        boolean boolean3 = compilerOptions0.coalesceVariableNames;
        compilerOptions0.setInlineProperties(false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        com.google.javascript.rhino.JSDocInfo jSDocInfo0 = new com.google.javascript.rhino.JSDocInfo();
        boolean boolean1 = jSDocInfo0.isNoShadow();
        boolean boolean2 = jSDocInfo0.hasType();
        boolean boolean3 = jSDocInfo0.isExport();
        java.lang.String str4 = jSDocInfo0.getLendsName();
        boolean boolean6 = jSDocInfo0.hasDescriptionForParameter("Not declared as a constructor");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        com.google.javascript.jscomp.SourceFile sourceFile3 = com.google.javascript.jscomp.SourceFile.fromCode("hi!", "./", "function (): ?");
        org.junit.Assert.assertNotNull(sourceFile3);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        com.google.javascript.jscomp.DiagnosticType diagnosticType5 = com.google.javascript.jscomp.DiagnosticType.error("", "");
        java.lang.String str6 = diagnosticType5.toString();
        java.lang.String[] strArray9 = new java.lang.String[] { "", "" };
        com.google.javascript.jscomp.JSError jSError10 = com.google.javascript.jscomp.JSError.make("hi!", (-1), 0, diagnosticType5, strArray9);
        com.google.javascript.jscomp.DiagnosticType diagnosticType11 = jSError10.getType();
        com.google.javascript.rhino.ErrorReporter errorReporter12 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry13 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter12);
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope14 = null;
        jSTypeRegistry13.resolveTypesInScope(jSTypeStaticScope14);
        com.google.javascript.rhino.jstype.JSType jSType16 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray17 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList18 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean19 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList18, jSTypeArray17);
        com.google.javascript.rhino.jstype.FunctionType functionType20 = jSTypeRegistry13.createFunctionType(jSType16, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList18);
        com.google.javascript.rhino.JSDocInfo jSDocInfo22 = functionType20.getOwnPropertyJSDocInfo("");
        boolean boolean24 = functionType20.removeProperty(".  at hi! line (unknown line) : 0");
        com.google.javascript.rhino.jstype.ParameterizedType parameterizedType25 = functionType20.toMaybeParameterizedType();
        boolean boolean26 = functionType20.isEnumElementType();
        com.google.javascript.rhino.ErrorReporter errorReporter27 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry28 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter27);
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope29 = null;
        jSTypeRegistry28.resolveTypesInScope(jSTypeStaticScope29);
        com.google.javascript.rhino.jstype.JSType jSType31 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray32 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList33 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean34 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList33, jSTypeArray32);
        com.google.javascript.rhino.jstype.FunctionType functionType35 = jSTypeRegistry28.createFunctionType(jSType31, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList33);
        boolean boolean36 = functionType35.hasReferenceName();
        com.google.javascript.rhino.jstype.ObjectType objectType37 = functionType35.getTypeOfThis();
        com.google.javascript.rhino.JSDocInfo jSDocInfo39 = functionType35.getOwnPropertyJSDocInfo(".  at hi! line (unknown line) : 0");
        com.google.javascript.rhino.JSDocInfo jSDocInfo40 = new com.google.javascript.rhino.JSDocInfo();
        boolean boolean41 = jSDocInfo40.isNoShadow();
        boolean boolean42 = jSDocInfo40.hasType();
        boolean boolean43 = jSDocInfo40.containsDeclaration();
        boolean boolean44 = jSDocInfo40.hasBaseType();
        functionType35.setJSDocInfo(jSDocInfo40);
        boolean boolean46 = jSDocInfo40.isExport();
        functionType20.setJSDocInfo(jSDocInfo40);
        boolean boolean48 = diagnosticType11.equals((java.lang.Object) functionType20);
        org.junit.Assert.assertNotNull(diagnosticType5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + ": " + "'", str6.equals(": "));
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertNotNull(jSError10);
        org.junit.Assert.assertNotNull(diagnosticType11);
        org.junit.Assert.assertNotNull(jSTypeArray17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(functionType20);
        org.junit.Assert.assertNull(jSDocInfo22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNull(parameterizedType25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(jSTypeArray32);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(functionType35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(objectType37);
        org.junit.Assert.assertNull(jSDocInfo39);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        com.google.javascript.rhino.Node node1 = new com.google.javascript.rhino.Node(10);
        com.google.javascript.rhino.Node node3 = new com.google.javascript.rhino.Node(10);
        com.google.javascript.rhino.Node node4 = node3.cloneTree();
        com.google.javascript.rhino.Node node5 = node1.clonePropsFrom(node4);
        com.google.javascript.rhino.Node[] nodeArray8 = new com.google.javascript.rhino.Node[] {};
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.IR.block(nodeArray8);
        com.google.javascript.rhino.Node node12 = new com.google.javascript.rhino.Node((int) ' ', nodeArray8, (-1), 40);
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.IR.script(nodeArray8);
        com.google.javascript.rhino.Node node14 = new com.google.javascript.rhino.Node(0, nodeArray8);
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.IR.newNode(node1, nodeArray8);
        boolean boolean16 = node15.isNew();
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNotNull(nodeArray8);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.exportTestFunctions;
        com.google.javascript.jscomp.AnonymousFunctionNamingPolicy anonymousFunctionNamingPolicy2 = compilerOptions0.anonymousFunctionNaming;
        boolean boolean3 = compilerOptions0.closurePass;
        compilerOptions0.instrumentationTemplate = "module$.  at hi! line (unknown line) : 0";
        compilerOptions0.ideMode = false;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + anonymousFunctionNamingPolicy2 + "' != '" + com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF + "'", anonymousFunctionNamingPolicy2.equals(com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        com.google.javascript.rhino.Node node1 = new com.google.javascript.rhino.Node(10);
        com.google.javascript.rhino.Node node3 = new com.google.javascript.rhino.Node(10);
        boolean boolean4 = node1.isEquivalentToTyped(node3);
        boolean boolean5 = node1.isExprResult();
        com.google.javascript.rhino.jstype.StaticSourceFile staticSourceFile6 = com.google.javascript.jscomp.NodeUtil.getSourceFile(node1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(staticSourceFile6);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newString(": ");
        boolean boolean2 = node1.isAssignAdd();
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.exportTestFunctions;
        com.google.javascript.jscomp.AnonymousFunctionNamingPolicy anonymousFunctionNamingPolicy2 = compilerOptions0.anonymousFunctionNaming;
        boolean boolean3 = compilerOptions0.closurePass;
        com.google.javascript.jscomp.CheckLevel checkLevel4 = com.google.javascript.jscomp.CheckLevel.ERROR;
        compilerOptions0.reportMissingOverride = checkLevel4;
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy6 = compilerOptions0.propertyRenaming;
        compilerOptions0.preferLineBreakAtEndOfFile = true;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + anonymousFunctionNamingPolicy2 + "' != '" + com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF + "'", anonymousFunctionNamingPolicy2.equals(com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + checkLevel4 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel4.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy6 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.OFF + "'", propertyRenamingPolicy6.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.OFF));
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setDeadAssignmentElimination(false);
        compilerOptions0.ideMode = true;
        boolean boolean5 = compilerOptions0.preferLineBreakAtEndOfFile;
        compilerOptions0.setRenamePrefix("");
        boolean boolean8 = compilerOptions0.closurePass;
        com.google.javascript.jscomp.CompilerOptions compilerOptions9 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean10 = compilerOptions9.exportTestFunctions;
        com.google.javascript.jscomp.AnonymousFunctionNamingPolicy anonymousFunctionNamingPolicy11 = compilerOptions9.anonymousFunctionNaming;
        com.google.javascript.jscomp.parsing.Config.LanguageMode languageMode13 = null;
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.IR.block();
        com.google.javascript.jscomp.parsing.Config.LanguageMode languageMode17 = null;
        java.lang.String[] strArray21 = new java.lang.String[] { "", "" };
        java.util.LinkedHashSet<java.lang.String> strSet22 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean23 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet22, strArray21);
        com.google.javascript.jscomp.parsing.Config config24 = com.google.javascript.jscomp.parsing.ParserRunner.createConfig(true, languageMode17, false, (java.util.Set<java.lang.String>) strSet22);
        node15.setDirectives((java.util.Set<java.lang.String>) strSet22);
        com.google.javascript.jscomp.parsing.Config config26 = com.google.javascript.jscomp.parsing.ParserRunner.createConfig(true, languageMode13, false, (java.util.Set<java.lang.String>) strSet22);
        compilerOptions9.setIdGenerators((java.util.Set<java.lang.String>) strSet22);
        compilerOptions0.stripTypes = strSet22;
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + anonymousFunctionNamingPolicy11 + "' != '" + com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF + "'", anonymousFunctionNamingPolicy11.equals(com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF));
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertNotNull(strArray21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(config24);
        org.junit.Assert.assertNotNull(config26);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        com.google.javascript.rhino.ErrorReporter errorReporter3 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry4 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter3);
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope5 = null;
        jSTypeRegistry4.resolveTypesInScope(jSTypeStaticScope5);
        com.google.javascript.rhino.jstype.JSType jSType7 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray8 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList9 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean10 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList9, jSTypeArray8);
        com.google.javascript.rhino.jstype.FunctionType functionType11 = jSTypeRegistry4.createFunctionType(jSType7, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList9);
        com.google.javascript.rhino.JSDocInfo jSDocInfo13 = functionType11.getOwnPropertyJSDocInfo("");
        com.google.javascript.rhino.JSDocInfo jSDocInfo14 = functionType11.getJSDocInfo();
        boolean boolean15 = functionType11.isNullable();
        com.google.javascript.rhino.ErrorReporter errorReporter17 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry18 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter17);
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope19 = null;
        jSTypeRegistry18.resolveTypesInScope(jSTypeStaticScope19);
        com.google.javascript.rhino.jstype.JSType jSType21 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray22 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList23 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean24 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList23, jSTypeArray22);
        com.google.javascript.rhino.jstype.FunctionType functionType25 = jSTypeRegistry18.createFunctionType(jSType21, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList23);
        boolean boolean26 = functionType25.hasInstanceType();
        boolean boolean27 = functionType25.isNominalConstructor();
        com.google.javascript.rhino.Node node30 = new com.google.javascript.rhino.Node(10);
        com.google.javascript.rhino.Node node31 = node30.cloneTree();
        com.google.javascript.jscomp.DiagnosticType diagnosticType34 = com.google.javascript.jscomp.DiagnosticType.error("", "");
        com.google.javascript.jscomp.DiagnosticType diagnosticType40 = com.google.javascript.jscomp.DiagnosticType.error("", "");
        java.lang.String str41 = diagnosticType40.toString();
        java.lang.String[] strArray44 = new java.lang.String[] { "", "" };
        com.google.javascript.jscomp.JSError jSError45 = com.google.javascript.jscomp.JSError.make("hi!", (-1), 0, diagnosticType40, strArray44);
        com.google.javascript.jscomp.JSError jSError46 = com.google.javascript.jscomp.JSError.make("hi!", node30, diagnosticType34, strArray44);
        boolean boolean47 = node30.isArrayLit();
        com.google.javascript.rhino.Node node48 = node30.removeFirstChild();
        boolean boolean49 = functionType11.defineDeclaredProperty("function (): ?", (com.google.javascript.rhino.jstype.JSType) functionType25, node48);
        jSTypeRegistry1.unregisterPropertyOnType("DependencyInfo(relativePath='./', path=': ', provides=[DiagnosticGroup<checkRegExp>, : , , , hi!, .  at hi! line (unknown line) : 0], requires=[./])", (com.google.javascript.rhino.jstype.JSType) functionType25);
        org.junit.Assert.assertNotNull(jSTypeArray8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(functionType11);
        org.junit.Assert.assertNull(jSDocInfo13);
        org.junit.Assert.assertNull(jSDocInfo14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(jSTypeArray22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(functionType25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertNotNull(diagnosticType34);
        org.junit.Assert.assertNotNull(diagnosticType40);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + ": " + "'", str41.equals(": "));
        org.junit.Assert.assertNotNull(strArray44);
        org.junit.Assert.assertNotNull(jSError45);
        org.junit.Assert.assertNotNull(jSError46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNull(node48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        com.google.javascript.rhino.Node node1 = new com.google.javascript.rhino.Node(10);
        com.google.javascript.rhino.Node node3 = new com.google.javascript.rhino.Node(10);
        boolean boolean4 = node1.isEquivalentToTyped(node3);
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.IR.exprResult(node3);
        com.google.javascript.rhino.Node node6 = node3.cloneNode();
        boolean boolean7 = node3.hasOneChild();
        boolean boolean8 = node3.isOr();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope2 = null;
        jSTypeRegistry1.resolveTypesInScope(jSTypeStaticScope2);
        com.google.javascript.rhino.jstype.JSType jSType4 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray5 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList6 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean7 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList6, jSTypeArray5);
        com.google.javascript.rhino.jstype.FunctionType functionType8 = jSTypeRegistry1.createFunctionType(jSType4, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList6);
        boolean boolean9 = functionType8.hasReferenceName();
        com.google.javascript.rhino.jstype.ObjectType objectType10 = functionType8.getTypeOfThis();
        com.google.javascript.rhino.JSDocInfo jSDocInfo12 = functionType8.getOwnPropertyJSDocInfo(".  at hi! line (unknown line) : 0");
        com.google.javascript.rhino.JSDocInfo jSDocInfo13 = new com.google.javascript.rhino.JSDocInfo();
        boolean boolean14 = jSDocInfo13.isNoShadow();
        boolean boolean15 = jSDocInfo13.hasType();
        boolean boolean16 = jSDocInfo13.containsDeclaration();
        boolean boolean17 = jSDocInfo13.hasBaseType();
        functionType8.setJSDocInfo(jSDocInfo13);
        boolean boolean19 = functionType8.isAllType();
        org.junit.Assert.assertNotNull(jSTypeArray5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(functionType8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(objectType10);
        org.junit.Assert.assertNull(jSDocInfo12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        com.google.javascript.rhino.ErrorReporter errorReporter2 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry3 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter2);
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope4 = null;
        jSTypeRegistry3.resolveTypesInScope(jSTypeStaticScope4);
        com.google.javascript.rhino.ErrorReporter errorReporter6 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry7 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter6);
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope8 = null;
        jSTypeRegistry7.resolveTypesInScope(jSTypeStaticScope8);
        com.google.javascript.rhino.jstype.JSType jSType10 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray11 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList12 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean13 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList12, jSTypeArray11);
        com.google.javascript.rhino.jstype.FunctionType functionType14 = jSTypeRegistry7.createFunctionType(jSType10, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList12);
        com.google.javascript.rhino.JSDocInfo jSDocInfo16 = functionType14.getOwnPropertyJSDocInfo("");
        com.google.javascript.rhino.ErrorReporter errorReporter17 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry18 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter17);
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope19 = null;
        jSTypeRegistry18.resolveTypesInScope(jSTypeStaticScope19);
        com.google.javascript.rhino.jstype.JSType jSType21 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray22 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList23 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean24 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList23, jSTypeArray22);
        com.google.javascript.rhino.jstype.FunctionType functionType25 = jSTypeRegistry18.createFunctionType(jSType21, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList23);
        com.google.javascript.rhino.JSDocInfo jSDocInfo27 = functionType25.getOwnPropertyJSDocInfo("");
        com.google.javascript.rhino.jstype.ObjectType objectType28 = functionType25.getImplicitPrototype();
        boolean boolean29 = objectType28.hasCachedValues();
        com.google.javascript.rhino.ErrorReporter errorReporter30 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry31 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter30);
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope32 = null;
        jSTypeRegistry31.resolveTypesInScope(jSTypeStaticScope32);
        com.google.javascript.rhino.jstype.JSType jSType34 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray35 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList36 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean37 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList36, jSTypeArray35);
        com.google.javascript.rhino.jstype.FunctionType functionType38 = jSTypeRegistry31.createFunctionType(jSType34, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList36);
        com.google.javascript.rhino.JSDocInfo jSDocInfo40 = functionType38.getOwnPropertyJSDocInfo("");
        boolean boolean42 = functionType38.removeProperty(".  at hi! line (unknown line) : 0");
        com.google.javascript.rhino.ErrorReporter errorReporter43 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry44 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter43);
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope45 = null;
        jSTypeRegistry44.resolveTypesInScope(jSTypeStaticScope45);
        com.google.javascript.rhino.jstype.JSType jSType47 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray48 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList49 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean50 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList49, jSTypeArray48);
        com.google.javascript.rhino.jstype.FunctionType functionType51 = jSTypeRegistry44.createFunctionType(jSType47, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList49);
        com.google.javascript.rhino.ErrorReporter errorReporter52 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry53 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter52);
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope54 = null;
        jSTypeRegistry53.resolveTypesInScope(jSTypeStaticScope54);
        com.google.javascript.rhino.jstype.JSType jSType56 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray57 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList58 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean59 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList58, jSTypeArray57);
        com.google.javascript.rhino.jstype.FunctionType functionType60 = jSTypeRegistry53.createFunctionType(jSType56, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList58);
        com.google.javascript.rhino.JSDocInfo jSDocInfo62 = functionType60.getOwnPropertyJSDocInfo("");
        com.google.javascript.rhino.ErrorReporter errorReporter63 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry64 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter63);
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope65 = null;
        jSTypeRegistry64.resolveTypesInScope(jSTypeStaticScope65);
        com.google.javascript.rhino.jstype.JSType jSType67 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray68 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList69 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean70 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList69, jSTypeArray68);
        com.google.javascript.rhino.jstype.FunctionType functionType71 = jSTypeRegistry64.createFunctionType(jSType67, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList69);
        com.google.javascript.rhino.JSDocInfo jSDocInfo73 = functionType71.getOwnPropertyJSDocInfo("");
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray74 = new com.google.javascript.rhino.jstype.JSType[] { objectType28, functionType38, functionType51, functionType60, functionType71 };
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList75 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean76 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList75, jSTypeArray74);
        com.google.javascript.rhino.jstype.FunctionType functionType77 = jSTypeRegistry3.createFunctionTypeWithVarArgs((com.google.javascript.rhino.jstype.JSType) functionType14, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList75);
        boolean boolean79 = functionType77.isPropertyInExterns("");
        boolean boolean80 = functionType77.isNumberValueType();
        com.google.javascript.rhino.ErrorReporter errorReporter81 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry82 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter81);
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope83 = null;
        jSTypeRegistry82.resolveTypesInScope(jSTypeStaticScope83);
        com.google.javascript.rhino.jstype.JSType jSType85 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray86 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList87 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean88 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList87, jSTypeArray86);
        com.google.javascript.rhino.jstype.FunctionType functionType89 = jSTypeRegistry82.createFunctionType(jSType85, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList87);
        boolean boolean90 = jSTypeRegistry1.resetImplicitPrototype((com.google.javascript.rhino.jstype.JSType) functionType77, (com.google.javascript.rhino.jstype.ObjectType) functionType89);
        boolean boolean91 = functionType77.isNumberObjectType();
        org.junit.Assert.assertNotNull(jSTypeArray11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(functionType14);
        org.junit.Assert.assertNull(jSDocInfo16);
        org.junit.Assert.assertNotNull(jSTypeArray22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(functionType25);
        org.junit.Assert.assertNull(jSDocInfo27);
        org.junit.Assert.assertNotNull(objectType28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(jSTypeArray35);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(functionType38);
        org.junit.Assert.assertNull(jSDocInfo40);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(jSTypeArray48);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(functionType51);
        org.junit.Assert.assertNotNull(jSTypeArray57);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertNotNull(functionType60);
        org.junit.Assert.assertNull(jSDocInfo62);
        org.junit.Assert.assertNotNull(jSTypeArray68);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertNotNull(functionType71);
        org.junit.Assert.assertNull(jSDocInfo73);
        org.junit.Assert.assertNotNull(jSTypeArray74);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + true + "'", boolean76 == true);
        org.junit.Assert.assertNotNull(functionType77);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + false + "'", boolean80 == false);
        org.junit.Assert.assertNotNull(jSTypeArray86);
        org.junit.Assert.assertTrue("'" + boolean88 + "' != '" + false + "'", boolean88 == false);
        org.junit.Assert.assertNotNull(functionType89);
        org.junit.Assert.assertTrue("'" + boolean90 + "' != '" + true + "'", boolean90 == true);
        org.junit.Assert.assertTrue("'" + boolean91 + "' != '" + false + "'", boolean91 == false);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        com.google.javascript.rhino.Node node2 = new com.google.javascript.rhino.Node(10);
        com.google.javascript.rhino.Node node3 = node2.cloneTree();
        com.google.javascript.jscomp.DiagnosticType diagnosticType6 = com.google.javascript.jscomp.DiagnosticType.error("", "");
        com.google.javascript.jscomp.DiagnosticType diagnosticType12 = com.google.javascript.jscomp.DiagnosticType.error("", "");
        java.lang.String str13 = diagnosticType12.toString();
        java.lang.String[] strArray16 = new java.lang.String[] { "", "" };
        com.google.javascript.jscomp.JSError jSError17 = com.google.javascript.jscomp.JSError.make("hi!", (-1), 0, diagnosticType12, strArray16);
        com.google.javascript.jscomp.JSError jSError18 = com.google.javascript.jscomp.JSError.make("hi!", node2, diagnosticType6, strArray16);
        com.google.javascript.rhino.Node node20 = new com.google.javascript.rhino.Node(10);
        com.google.javascript.rhino.Node node22 = new com.google.javascript.rhino.Node(10);
        boolean boolean23 = node20.isEquivalentToTyped(node22);
        node2.addChildToFront(node20);
        boolean boolean25 = node20.isLabel();
        java.util.Collection<com.google.javascript.rhino.Node> nodeCollection26 = com.google.javascript.jscomp.NodeUtil.getVarsDeclaredInBranch(node20);
        node20.setIsSyntheticBlock(false);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(diagnosticType6);
        org.junit.Assert.assertNotNull(diagnosticType12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + ": " + "'", str13.equals(": "));
        org.junit.Assert.assertNotNull(strArray16);
        org.junit.Assert.assertNotNull(jSError17);
        org.junit.Assert.assertNotNull(jSError18);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(nodeCollection26);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setCheckTypes(false);
        com.google.javascript.jscomp.CompilerOptions.LanguageMode languageMode3 = compilerOptions0.getLanguageOut();
        compilerOptions0.setInlineLocalVariables(false);
        compilerOptions0.setTightenTypes(true);
        compilerOptions0.setGroupVariableDeclarations(false);
        compilerOptions0.setAliasableGlobals("module$Not declared as a type name");
        org.junit.Assert.assertNull(languageMode3);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope2 = null;
        jSTypeRegistry1.resolveTypesInScope(jSTypeStaticScope2);
        com.google.javascript.rhino.jstype.JSType jSType4 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray5 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList6 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean7 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList6, jSTypeArray5);
        com.google.javascript.rhino.jstype.FunctionType functionType8 = jSTypeRegistry1.createFunctionType(jSType4, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList6);
        boolean boolean9 = functionType8.hasReferenceName();
        boolean boolean10 = functionType8.isInterface();
        org.junit.Assert.assertNotNull(jSTypeArray5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(functionType8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope2 = null;
        jSTypeRegistry1.resolveTypesInScope(jSTypeStaticScope2);
        com.google.javascript.rhino.ErrorReporter errorReporter4 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter4);
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope6 = null;
        jSTypeRegistry5.resolveTypesInScope(jSTypeStaticScope6);
        com.google.javascript.rhino.jstype.JSType jSType8 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray9 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList10 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean11 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList10, jSTypeArray9);
        com.google.javascript.rhino.jstype.FunctionType functionType12 = jSTypeRegistry5.createFunctionType(jSType8, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList10);
        com.google.javascript.rhino.JSDocInfo jSDocInfo14 = functionType12.getOwnPropertyJSDocInfo("");
        com.google.javascript.rhino.ErrorReporter errorReporter15 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry16 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter15);
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope17 = null;
        jSTypeRegistry16.resolveTypesInScope(jSTypeStaticScope17);
        com.google.javascript.rhino.jstype.JSType jSType19 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray20 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList21 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean22 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList21, jSTypeArray20);
        com.google.javascript.rhino.jstype.FunctionType functionType23 = jSTypeRegistry16.createFunctionType(jSType19, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList21);
        com.google.javascript.rhino.JSDocInfo jSDocInfo25 = functionType23.getOwnPropertyJSDocInfo("");
        com.google.javascript.rhino.jstype.ObjectType objectType26 = functionType23.getImplicitPrototype();
        boolean boolean27 = objectType26.hasCachedValues();
        com.google.javascript.rhino.ErrorReporter errorReporter28 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry29 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter28);
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope30 = null;
        jSTypeRegistry29.resolveTypesInScope(jSTypeStaticScope30);
        com.google.javascript.rhino.jstype.JSType jSType32 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray33 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList34 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean35 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList34, jSTypeArray33);
        com.google.javascript.rhino.jstype.FunctionType functionType36 = jSTypeRegistry29.createFunctionType(jSType32, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList34);
        com.google.javascript.rhino.JSDocInfo jSDocInfo38 = functionType36.getOwnPropertyJSDocInfo("");
        boolean boolean40 = functionType36.removeProperty(".  at hi! line (unknown line) : 0");
        com.google.javascript.rhino.ErrorReporter errorReporter41 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry42 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter41);
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope43 = null;
        jSTypeRegistry42.resolveTypesInScope(jSTypeStaticScope43);
        com.google.javascript.rhino.jstype.JSType jSType45 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray46 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList47 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean48 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList47, jSTypeArray46);
        com.google.javascript.rhino.jstype.FunctionType functionType49 = jSTypeRegistry42.createFunctionType(jSType45, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList47);
        com.google.javascript.rhino.ErrorReporter errorReporter50 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry51 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter50);
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope52 = null;
        jSTypeRegistry51.resolveTypesInScope(jSTypeStaticScope52);
        com.google.javascript.rhino.jstype.JSType jSType54 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray55 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList56 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean57 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList56, jSTypeArray55);
        com.google.javascript.rhino.jstype.FunctionType functionType58 = jSTypeRegistry51.createFunctionType(jSType54, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList56);
        com.google.javascript.rhino.JSDocInfo jSDocInfo60 = functionType58.getOwnPropertyJSDocInfo("");
        com.google.javascript.rhino.ErrorReporter errorReporter61 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry62 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter61);
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope63 = null;
        jSTypeRegistry62.resolveTypesInScope(jSTypeStaticScope63);
        com.google.javascript.rhino.jstype.JSType jSType65 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray66 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList67 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean68 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList67, jSTypeArray66);
        com.google.javascript.rhino.jstype.FunctionType functionType69 = jSTypeRegistry62.createFunctionType(jSType65, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList67);
        com.google.javascript.rhino.JSDocInfo jSDocInfo71 = functionType69.getOwnPropertyJSDocInfo("");
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray72 = new com.google.javascript.rhino.jstype.JSType[] { objectType26, functionType36, functionType49, functionType58, functionType69 };
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList73 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean74 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList73, jSTypeArray72);
        com.google.javascript.rhino.jstype.FunctionType functionType75 = jSTypeRegistry1.createFunctionTypeWithVarArgs((com.google.javascript.rhino.jstype.JSType) functionType12, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList73);
        boolean boolean77 = functionType75.isPropertyInExterns("");
        boolean boolean78 = functionType75.isEnumType();
        java.lang.String str79 = functionType75.getNormalizedReferenceName();
        org.junit.Assert.assertNotNull(jSTypeArray9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(functionType12);
        org.junit.Assert.assertNull(jSDocInfo14);
        org.junit.Assert.assertNotNull(jSTypeArray20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(functionType23);
        org.junit.Assert.assertNull(jSDocInfo25);
        org.junit.Assert.assertNotNull(objectType26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(jSTypeArray33);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(functionType36);
        org.junit.Assert.assertNull(jSDocInfo38);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(jSTypeArray46);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(functionType49);
        org.junit.Assert.assertNotNull(jSTypeArray55);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertNotNull(functionType58);
        org.junit.Assert.assertNull(jSDocInfo60);
        org.junit.Assert.assertNotNull(jSTypeArray66);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertNotNull(functionType69);
        org.junit.Assert.assertNull(jSDocInfo71);
        org.junit.Assert.assertNotNull(jSTypeArray72);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + true + "'", boolean74 == true);
        org.junit.Assert.assertNotNull(functionType75);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
        org.junit.Assert.assertNull(str79);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        com.google.javascript.rhino.Node node1 = new com.google.javascript.rhino.Node(10);
        com.google.javascript.rhino.Node node3 = new com.google.javascript.rhino.Node(10);
        boolean boolean4 = node1.isEquivalentToTyped(node3);
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.IR.exprResult(node3);
        com.google.javascript.rhino.Node node7 = new com.google.javascript.rhino.Node(10);
        com.google.javascript.rhino.Node node9 = new com.google.javascript.rhino.Node(10);
        boolean boolean10 = node7.isEquivalentToTyped(node9);
        com.google.javascript.rhino.Node node12 = new com.google.javascript.rhino.Node(10);
        com.google.javascript.rhino.Node node14 = new com.google.javascript.rhino.Node(10);
        boolean boolean15 = node12.isEquivalentToTyped(node14);
        java.lang.String str16 = node12.getQualifiedName();
        com.google.javascript.rhino.Node node17 = node9.srcrefTree(node12);
        boolean boolean18 = node17.isNumber();
        node17.setLength(0);
        try {
            com.google.javascript.rhino.Node node21 = com.google.javascript.rhino.IR.ifNode(node3, node17);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        com.google.javascript.jscomp.ErrorFormat errorFormat0 = com.google.javascript.jscomp.ErrorFormat.LEGACY;
        org.junit.Assert.assertNotNull(errorFormat0);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        boolean boolean1 = com.google.javascript.jscomp.NodeUtil.isValidQualifiedName("goog.exportProperty");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        com.google.javascript.rhino.Node node2 = new com.google.javascript.rhino.Node(10);
        com.google.javascript.rhino.Node node3 = node2.cloneTree();
        com.google.javascript.jscomp.DiagnosticType diagnosticType6 = com.google.javascript.jscomp.DiagnosticType.error("", "");
        com.google.javascript.jscomp.DiagnosticType diagnosticType12 = com.google.javascript.jscomp.DiagnosticType.error("", "");
        java.lang.String str13 = diagnosticType12.toString();
        java.lang.String[] strArray16 = new java.lang.String[] { "", "" };
        com.google.javascript.jscomp.JSError jSError17 = com.google.javascript.jscomp.JSError.make("hi!", (-1), 0, diagnosticType12, strArray16);
        com.google.javascript.jscomp.JSError jSError18 = com.google.javascript.jscomp.JSError.make("hi!", node2, diagnosticType6, strArray16);
        boolean boolean19 = node2.hasOneChild();
        boolean boolean20 = node2.isTry();
        com.google.javascript.rhino.Node node22 = new com.google.javascript.rhino.Node(10);
        com.google.javascript.rhino.Node node24 = new com.google.javascript.rhino.Node(10);
        boolean boolean25 = node22.isEquivalentToTyped(node24);
        com.google.javascript.rhino.Node node26 = com.google.javascript.rhino.IR.exprResult(node24);
        com.google.javascript.rhino.Node node27 = node24.cloneNode();
        java.lang.String str31 = node24.toString(true, false, true);
        try {
            com.google.javascript.rhino.Node node32 = com.google.javascript.rhino.IR.add(node2, node24);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: second new child has existing parent");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(diagnosticType6);
        org.junit.Assert.assertNotNull(diagnosticType12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + ": " + "'", str13.equals(": "));
        org.junit.Assert.assertNotNull(strArray16);
        org.junit.Assert.assertNotNull(jSError17);
        org.junit.Assert.assertNotNull(jSError18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertNotNull(node27);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "BITXOR" + "'", str31.equals("BITXOR"));
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.MessageFormatter messageFormatter1 = null;
        java.util.logging.Logger logger2 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager3 = new com.google.javascript.jscomp.LoggerErrorManager(messageFormatter1, logger2);
        compiler0.setErrorManager((com.google.javascript.jscomp.ErrorManager) loggerErrorManager3);
        com.google.javascript.jscomp.ErrorManager errorManager5 = compiler0.getErrorManager();
        double double6 = compiler0.getProgress();
        com.google.javascript.jscomp.JSError[] jSErrorArray7 = compiler0.getMessages();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile8 = null;
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray9 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile8 };
        com.google.javascript.jscomp.JSModule jSModule11 = new com.google.javascript.jscomp.JSModule("Not declared as a type name");
        com.google.javascript.jscomp.JSModule[] jSModuleArray12 = new com.google.javascript.jscomp.JSModule[] { jSModule11 };
        com.google.javascript.jscomp.CompilerOptions compilerOptions13 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions13.setProcessObjectPropertyString(true);
        boolean boolean16 = compilerOptions13.markAsCompiled;
        try {
            compiler0.init(jSSourceFileArray9, jSModuleArray12, compilerOptions13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(errorManager5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(jSErrorArray7);
        org.junit.Assert.assertNotNull(jSSourceFileArray9);
        org.junit.Assert.assertNotNull(jSModuleArray12);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        com.google.javascript.rhino.Node node1 = new com.google.javascript.rhino.Node(10);
        com.google.javascript.rhino.Node node3 = new com.google.javascript.rhino.Node(10);
        com.google.javascript.rhino.Node node4 = node3.cloneTree();
        com.google.javascript.rhino.Node node5 = node1.clonePropsFrom(node4);
        boolean boolean6 = node4.isEmpty();
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString((int) (short) -1, "");
        boolean boolean10 = node9.isThrow();
        try {
            com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.IR.doNode(node4, node9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope2 = null;
        jSTypeRegistry1.resolveTypesInScope(jSTypeStaticScope2);
        com.google.javascript.rhino.jstype.JSType jSType4 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray5 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList6 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean7 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList6, jSTypeArray5);
        com.google.javascript.rhino.jstype.FunctionType functionType8 = jSTypeRegistry1.createFunctionType(jSType4, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList6);
        com.google.javascript.rhino.ErrorReporter errorReporter9 = jSTypeRegistry1.getErrorReporter();
        jSTypeRegistry1.resetForTypeCheck();
        com.google.javascript.rhino.ErrorReporter errorReporter11 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry12 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter11);
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope13 = null;
        jSTypeRegistry12.resolveTypesInScope(jSTypeStaticScope13);
        com.google.javascript.rhino.ErrorReporter errorReporter15 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry16 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter15);
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope17 = null;
        jSTypeRegistry16.resolveTypesInScope(jSTypeStaticScope17);
        com.google.javascript.rhino.jstype.JSType jSType19 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray20 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList21 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean22 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList21, jSTypeArray20);
        com.google.javascript.rhino.jstype.FunctionType functionType23 = jSTypeRegistry16.createFunctionType(jSType19, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList21);
        com.google.javascript.rhino.JSDocInfo jSDocInfo25 = functionType23.getOwnPropertyJSDocInfo("");
        com.google.javascript.rhino.ErrorReporter errorReporter26 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry27 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter26);
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope28 = null;
        jSTypeRegistry27.resolveTypesInScope(jSTypeStaticScope28);
        com.google.javascript.rhino.jstype.JSType jSType30 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray31 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList32 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean33 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList32, jSTypeArray31);
        com.google.javascript.rhino.jstype.FunctionType functionType34 = jSTypeRegistry27.createFunctionType(jSType30, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList32);
        com.google.javascript.rhino.JSDocInfo jSDocInfo36 = functionType34.getOwnPropertyJSDocInfo("");
        com.google.javascript.rhino.jstype.ObjectType objectType37 = functionType34.getImplicitPrototype();
        boolean boolean38 = objectType37.hasCachedValues();
        com.google.javascript.rhino.ErrorReporter errorReporter39 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry40 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter39);
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope41 = null;
        jSTypeRegistry40.resolveTypesInScope(jSTypeStaticScope41);
        com.google.javascript.rhino.jstype.JSType jSType43 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray44 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList45 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean46 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList45, jSTypeArray44);
        com.google.javascript.rhino.jstype.FunctionType functionType47 = jSTypeRegistry40.createFunctionType(jSType43, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList45);
        com.google.javascript.rhino.JSDocInfo jSDocInfo49 = functionType47.getOwnPropertyJSDocInfo("");
        boolean boolean51 = functionType47.removeProperty(".  at hi! line (unknown line) : 0");
        com.google.javascript.rhino.ErrorReporter errorReporter52 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry53 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter52);
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope54 = null;
        jSTypeRegistry53.resolveTypesInScope(jSTypeStaticScope54);
        com.google.javascript.rhino.jstype.JSType jSType56 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray57 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList58 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean59 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList58, jSTypeArray57);
        com.google.javascript.rhino.jstype.FunctionType functionType60 = jSTypeRegistry53.createFunctionType(jSType56, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList58);
        com.google.javascript.rhino.ErrorReporter errorReporter61 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry62 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter61);
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope63 = null;
        jSTypeRegistry62.resolveTypesInScope(jSTypeStaticScope63);
        com.google.javascript.rhino.jstype.JSType jSType65 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray66 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList67 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean68 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList67, jSTypeArray66);
        com.google.javascript.rhino.jstype.FunctionType functionType69 = jSTypeRegistry62.createFunctionType(jSType65, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList67);
        com.google.javascript.rhino.JSDocInfo jSDocInfo71 = functionType69.getOwnPropertyJSDocInfo("");
        com.google.javascript.rhino.ErrorReporter errorReporter72 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry73 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter72);
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope74 = null;
        jSTypeRegistry73.resolveTypesInScope(jSTypeStaticScope74);
        com.google.javascript.rhino.jstype.JSType jSType76 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray77 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList78 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean79 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList78, jSTypeArray77);
        com.google.javascript.rhino.jstype.FunctionType functionType80 = jSTypeRegistry73.createFunctionType(jSType76, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList78);
        com.google.javascript.rhino.JSDocInfo jSDocInfo82 = functionType80.getOwnPropertyJSDocInfo("");
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray83 = new com.google.javascript.rhino.jstype.JSType[] { objectType37, functionType47, functionType60, functionType69, functionType80 };
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList84 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean85 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList84, jSTypeArray83);
        com.google.javascript.rhino.jstype.FunctionType functionType86 = jSTypeRegistry12.createFunctionTypeWithVarArgs((com.google.javascript.rhino.jstype.JSType) functionType23, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList84);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray87 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.Node node88 = jSTypeRegistry12.createParameters(jSTypeArray87);
        com.google.javascript.rhino.Node node89 = jSTypeRegistry1.createParametersWithVarArgs(jSTypeArray87);
        org.junit.Assert.assertNotNull(jSTypeArray5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(functionType8);
        org.junit.Assert.assertNull(errorReporter9);
        org.junit.Assert.assertNotNull(jSTypeArray20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(functionType23);
        org.junit.Assert.assertNull(jSDocInfo25);
        org.junit.Assert.assertNotNull(jSTypeArray31);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(functionType34);
        org.junit.Assert.assertNull(jSDocInfo36);
        org.junit.Assert.assertNotNull(objectType37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(jSTypeArray44);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(functionType47);
        org.junit.Assert.assertNull(jSDocInfo49);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertNotNull(jSTypeArray57);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertNotNull(functionType60);
        org.junit.Assert.assertNotNull(jSTypeArray66);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertNotNull(functionType69);
        org.junit.Assert.assertNull(jSDocInfo71);
        org.junit.Assert.assertNotNull(jSTypeArray77);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
        org.junit.Assert.assertNotNull(functionType80);
        org.junit.Assert.assertNull(jSDocInfo82);
        org.junit.Assert.assertNotNull(jSTypeArray83);
        org.junit.Assert.assertTrue("'" + boolean85 + "' != '" + true + "'", boolean85 == true);
        org.junit.Assert.assertNotNull(functionType86);
        org.junit.Assert.assertNotNull(jSTypeArray87);
        org.junit.Assert.assertNotNull(node88);
        org.junit.Assert.assertNotNull(node89);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        com.google.javascript.jscomp.CodingConvention codingConvention0 = com.google.javascript.jscomp.CodingConventions.getDefault();
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention1 = new com.google.javascript.jscomp.ClosureCodingConvention(codingConvention0);
        com.google.javascript.rhino.Node node3 = new com.google.javascript.rhino.Node(10);
        com.google.javascript.rhino.Node node5 = new com.google.javascript.rhino.Node(10);
        boolean boolean6 = node3.isEquivalentToTyped(node5);
        java.lang.String str7 = node3.getQualifiedName();
        node3.setWasEmptyNode(false);
        boolean boolean10 = node3.isDo();
        com.google.javascript.rhino.Node node12 = new com.google.javascript.rhino.Node(10);
        com.google.javascript.rhino.Node node14 = new com.google.javascript.rhino.Node(10);
        boolean boolean15 = node12.isEquivalentToTyped(node14);
        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.IR.exprResult(node14);
        com.google.javascript.rhino.Node node17 = node3.useSourceInfoIfMissingFrom(node14);
        boolean boolean18 = closureCodingConvention1.isVarArgsParameter(node3);
        org.junit.Assert.assertNotNull(codingConvention0);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setDeadAssignmentElimination(false);
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy3 = com.google.javascript.jscomp.PropertyRenamingPolicy.OFF;
        compilerOptions0.setPropertyRenaming(propertyRenamingPolicy3);
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy3 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.OFF + "'", propertyRenamingPolicy3.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.OFF));
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        com.google.javascript.rhino.Node node1 = new com.google.javascript.rhino.Node(10);
        com.google.javascript.rhino.Node node3 = new com.google.javascript.rhino.Node(10);
        boolean boolean4 = node1.isEquivalentToTyped(node3);
        boolean boolean5 = node1.isOnlyModifiesThisCall();
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.IR.throwNode(node1);
        int int7 = node1.getType();
        try {
            com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.IR.paramList(node1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 10 + "'", int7 == 10);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry0 = null;
        com.google.javascript.rhino.jstype.FunctionParamBuilder functionParamBuilder1 = new com.google.javascript.rhino.jstype.FunctionParamBuilder(jSTypeRegistry0);
        com.google.javascript.rhino.Node node3 = new com.google.javascript.rhino.Node(10);
        com.google.javascript.rhino.Node node5 = new com.google.javascript.rhino.Node(10);
        boolean boolean6 = node3.isEquivalentToTyped(node5);
        java.lang.String str7 = node3.getQualifiedName();
        node3.setWasEmptyNode(false);
        com.google.javascript.rhino.Node node11 = new com.google.javascript.rhino.Node(10);
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.IR.comma(node3, node11);
        com.google.javascript.rhino.Node node15 = new com.google.javascript.rhino.Node(10);
        com.google.javascript.rhino.Node node16 = node15.cloneTree();
        com.google.javascript.jscomp.DiagnosticType diagnosticType19 = com.google.javascript.jscomp.DiagnosticType.error("", "");
        com.google.javascript.jscomp.DiagnosticType diagnosticType25 = com.google.javascript.jscomp.DiagnosticType.error("", "");
        java.lang.String str26 = diagnosticType25.toString();
        java.lang.String[] strArray29 = new java.lang.String[] { "", "" };
        com.google.javascript.jscomp.JSError jSError30 = com.google.javascript.jscomp.JSError.make("hi!", (-1), 0, diagnosticType25, strArray29);
        com.google.javascript.jscomp.JSError jSError31 = com.google.javascript.jscomp.JSError.make("hi!", node15, diagnosticType19, strArray29);
        com.google.javascript.rhino.Node node33 = new com.google.javascript.rhino.Node(10);
        com.google.javascript.rhino.Node node35 = new com.google.javascript.rhino.Node(10);
        boolean boolean36 = node33.isEquivalentToTyped(node35);
        node15.addChildToFront(node33);
        boolean boolean38 = node33.isLabel();
        com.google.javascript.rhino.Node node39 = node12.srcref(node33);
        com.google.javascript.rhino.Node node40 = functionParamBuilder1.newOptionalParameterFromNode(node33);
        java.lang.Object obj42 = node33.getProp(0);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertNotNull(diagnosticType19);
        org.junit.Assert.assertNotNull(diagnosticType25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + ": " + "'", str26.equals(": "));
        org.junit.Assert.assertNotNull(strArray29);
        org.junit.Assert.assertNotNull(jSError30);
        org.junit.Assert.assertNotNull(jSError31);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(node39);
        org.junit.Assert.assertNotNull(node40);
        org.junit.Assert.assertNull(obj42);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        java.nio.charset.Charset charset1 = null;
        com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromFile(": ", charset1);
        com.google.javascript.jscomp.parsing.Config.LanguageMode languageMode5 = null;
        com.google.javascript.jscomp.parsing.Config config7 = com.google.javascript.jscomp.parsing.ParserRunner.createConfig(true, languageMode5, false);
        com.google.javascript.rhino.head.ErrorReporter errorReporter8 = null;
        java.util.logging.Logger logger9 = null;
        try {
            com.google.javascript.rhino.Node node10 = com.google.javascript.jscomp.parsing.ParserRunner.parse((com.google.javascript.rhino.jstype.StaticSourceFile) sourceFile2, "Unversioned directory", config7, errorReporter8, logger9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(sourceFile2);
        org.junit.Assert.assertNotNull(config7);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        com.google.javascript.rhino.JSDocInfo jSDocInfo0 = new com.google.javascript.rhino.JSDocInfo();
        java.lang.String str1 = jSDocInfo0.getLicense();
        java.lang.String str2 = jSDocInfo0.getDeprecationReason();
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setReplaceIdGenerators(false);
        compilerOptions0.setTransformAMDToCJSModules(false);
        compilerOptions0.setMoveFunctionDeclarations(true);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.DEPRECATED;
        com.google.javascript.jscomp.DiagnosticType diagnosticType6 = com.google.javascript.jscomp.DiagnosticType.error("", "");
        java.lang.String str7 = diagnosticType6.toString();
        java.lang.String[] strArray10 = new java.lang.String[] { "", "" };
        com.google.javascript.jscomp.JSError jSError11 = com.google.javascript.jscomp.JSError.make("hi!", (-1), 0, diagnosticType6, strArray10);
        boolean boolean12 = diagnosticGroup0.matches(jSError11);
        com.google.javascript.jscomp.DiagnosticGroups.DEBUGGER_STATEMENT_PRESENT = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticGroups.CONSTANT_PROPERTY = diagnosticGroup0;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
        org.junit.Assert.assertNotNull(diagnosticType6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + ": " + "'", str7.equals(": "));
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertNotNull(jSError11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        com.google.javascript.rhino.Node node1 = new com.google.javascript.rhino.Node(10);
        com.google.javascript.rhino.Node node3 = new com.google.javascript.rhino.Node(10);
        com.google.javascript.rhino.Node node4 = node3.cloneTree();
        com.google.javascript.rhino.Node node5 = node1.clonePropsFrom(node4);
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString((int) (short) -1, "");
        boolean boolean9 = node8.isThrow();
        com.google.javascript.rhino.Node node11 = new com.google.javascript.rhino.Node(10);
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node(10);
        boolean boolean14 = node11.isEquivalentToTyped(node13);
        boolean boolean15 = node11.isOnlyModifiesThisCall();
        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.IR.throwNode(node11);
        com.google.javascript.rhino.Node node17 = node8.useSourceInfoIfMissingFrom(node11);
        int int18 = node11.getSourceOffset();
        com.google.javascript.rhino.Node node19 = node1.copyInformationFrom(node11);
        boolean boolean20 = node1.isBlock();
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setCheckTypes(false);
        com.google.javascript.jscomp.CompilerOptions.LanguageMode languageMode3 = compilerOptions0.getLanguageOut();
        compilerOptions0.setTransformAMDToCJSModules(false);
        compilerOptions0.setRemoveUnusedVars(true);
        org.junit.Assert.assertNull(languageMode3);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        com.google.javascript.jscomp.SourceFile.Builder builder0 = com.google.javascript.jscomp.SourceFile.builder();
        java.io.Reader reader2 = null;
        try {
            com.google.javascript.jscomp.SourceFile sourceFile3 = builder0.buildFromReader("Unknown class name", reader2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(builder0);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        jSTypeRegistry1.identifyNonNullableName("");
        com.google.javascript.rhino.ErrorReporter errorReporter4 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter4);
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope6 = null;
        jSTypeRegistry5.resolveTypesInScope(jSTypeStaticScope6);
        com.google.javascript.rhino.jstype.JSType jSType8 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray9 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList10 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean11 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList10, jSTypeArray9);
        com.google.javascript.rhino.jstype.FunctionType functionType12 = jSTypeRegistry5.createFunctionType(jSType8, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList10);
        com.google.javascript.rhino.ErrorReporter errorReporter14 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry15 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter14);
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope16 = null;
        jSTypeRegistry15.resolveTypesInScope(jSTypeStaticScope16);
        com.google.javascript.rhino.ErrorReporter errorReporter18 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry19 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter18);
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope20 = null;
        jSTypeRegistry19.resolveTypesInScope(jSTypeStaticScope20);
        com.google.javascript.rhino.jstype.JSType jSType22 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray23 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList24 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean25 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList24, jSTypeArray23);
        com.google.javascript.rhino.jstype.FunctionType functionType26 = jSTypeRegistry19.createFunctionType(jSType22, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList24);
        com.google.javascript.rhino.JSDocInfo jSDocInfo28 = functionType26.getOwnPropertyJSDocInfo("");
        com.google.javascript.rhino.ErrorReporter errorReporter29 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry30 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter29);
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope31 = null;
        jSTypeRegistry30.resolveTypesInScope(jSTypeStaticScope31);
        com.google.javascript.rhino.jstype.JSType jSType33 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray34 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList35 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean36 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList35, jSTypeArray34);
        com.google.javascript.rhino.jstype.FunctionType functionType37 = jSTypeRegistry30.createFunctionType(jSType33, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList35);
        com.google.javascript.rhino.JSDocInfo jSDocInfo39 = functionType37.getOwnPropertyJSDocInfo("");
        com.google.javascript.rhino.jstype.ObjectType objectType40 = functionType37.getImplicitPrototype();
        boolean boolean41 = objectType40.hasCachedValues();
        com.google.javascript.rhino.ErrorReporter errorReporter42 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry43 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter42);
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope44 = null;
        jSTypeRegistry43.resolveTypesInScope(jSTypeStaticScope44);
        com.google.javascript.rhino.jstype.JSType jSType46 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray47 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList48 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean49 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList48, jSTypeArray47);
        com.google.javascript.rhino.jstype.FunctionType functionType50 = jSTypeRegistry43.createFunctionType(jSType46, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList48);
        com.google.javascript.rhino.JSDocInfo jSDocInfo52 = functionType50.getOwnPropertyJSDocInfo("");
        boolean boolean54 = functionType50.removeProperty(".  at hi! line (unknown line) : 0");
        com.google.javascript.rhino.ErrorReporter errorReporter55 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry56 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter55);
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope57 = null;
        jSTypeRegistry56.resolveTypesInScope(jSTypeStaticScope57);
        com.google.javascript.rhino.jstype.JSType jSType59 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray60 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList61 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean62 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList61, jSTypeArray60);
        com.google.javascript.rhino.jstype.FunctionType functionType63 = jSTypeRegistry56.createFunctionType(jSType59, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList61);
        com.google.javascript.rhino.ErrorReporter errorReporter64 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry65 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter64);
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope66 = null;
        jSTypeRegistry65.resolveTypesInScope(jSTypeStaticScope66);
        com.google.javascript.rhino.jstype.JSType jSType68 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray69 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList70 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean71 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList70, jSTypeArray69);
        com.google.javascript.rhino.jstype.FunctionType functionType72 = jSTypeRegistry65.createFunctionType(jSType68, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList70);
        com.google.javascript.rhino.JSDocInfo jSDocInfo74 = functionType72.getOwnPropertyJSDocInfo("");
        com.google.javascript.rhino.ErrorReporter errorReporter75 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry76 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter75);
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope77 = null;
        jSTypeRegistry76.resolveTypesInScope(jSTypeStaticScope77);
        com.google.javascript.rhino.jstype.JSType jSType79 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray80 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList81 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean82 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList81, jSTypeArray80);
        com.google.javascript.rhino.jstype.FunctionType functionType83 = jSTypeRegistry76.createFunctionType(jSType79, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList81);
        com.google.javascript.rhino.JSDocInfo jSDocInfo85 = functionType83.getOwnPropertyJSDocInfo("");
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray86 = new com.google.javascript.rhino.jstype.JSType[] { objectType40, functionType50, functionType63, functionType72, functionType83 };
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList87 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean88 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList87, jSTypeArray86);
        com.google.javascript.rhino.jstype.FunctionType functionType89 = jSTypeRegistry15.createFunctionTypeWithVarArgs((com.google.javascript.rhino.jstype.JSType) functionType26, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList87);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray90 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.Node node91 = jSTypeRegistry15.createParameters(jSTypeArray90);
        com.google.javascript.rhino.jstype.FunctionType functionType92 = jSTypeRegistry1.createConstructorType(jSType8, false, jSTypeArray90);
        com.google.javascript.rhino.jstype.FunctionType functionType93 = functionType92.getSuperClassConstructor();
        boolean boolean94 = functionType92.isNullable();
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable95 = functionType92.getAllImplementedInterfaces();
        org.junit.Assert.assertNotNull(jSTypeArray9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(functionType12);
        org.junit.Assert.assertNotNull(jSTypeArray23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(functionType26);
        org.junit.Assert.assertNull(jSDocInfo28);
        org.junit.Assert.assertNotNull(jSTypeArray34);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(functionType37);
        org.junit.Assert.assertNull(jSDocInfo39);
        org.junit.Assert.assertNotNull(objectType40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(jSTypeArray47);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNotNull(functionType50);
        org.junit.Assert.assertNull(jSDocInfo52);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNotNull(jSTypeArray60);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertNotNull(functionType63);
        org.junit.Assert.assertNotNull(jSTypeArray69);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
        org.junit.Assert.assertNotNull(functionType72);
        org.junit.Assert.assertNull(jSDocInfo74);
        org.junit.Assert.assertNotNull(jSTypeArray80);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
        org.junit.Assert.assertNotNull(functionType83);
        org.junit.Assert.assertNull(jSDocInfo85);
        org.junit.Assert.assertNotNull(jSTypeArray86);
        org.junit.Assert.assertTrue("'" + boolean88 + "' != '" + true + "'", boolean88 == true);
        org.junit.Assert.assertNotNull(functionType89);
        org.junit.Assert.assertNotNull(jSTypeArray90);
        org.junit.Assert.assertNotNull(node91);
        org.junit.Assert.assertNotNull(functionType92);
        org.junit.Assert.assertNull(functionType93);
        org.junit.Assert.assertTrue("'" + boolean94 + "' != '" + false + "'", boolean94 == false);
        org.junit.Assert.assertNotNull(objectTypeIterable95);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setCheckTypes(false);
        com.google.javascript.jscomp.CompilerOptions.LanguageMode languageMode3 = compilerOptions0.getLanguageOut();
        compilerOptions0.setInlineLocalVariables(false);
        compilerOptions0.setTightenTypes(true);
        compilerOptions0.setGroupVariableDeclarations(false);
        compilerOptions0.setCheckTypes(false);
        compilerOptions0.convertToDottedProperties = false;
        org.junit.Assert.assertNull(languageMode3);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        com.google.javascript.rhino.ErrorReporter errorReporter3 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry4 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter3);
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope5 = null;
        jSTypeRegistry4.resolveTypesInScope(jSTypeStaticScope5);
        com.google.javascript.rhino.jstype.JSType jSType7 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray8 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList9 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean10 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList9, jSTypeArray8);
        com.google.javascript.rhino.jstype.FunctionType functionType11 = jSTypeRegistry4.createFunctionType(jSType7, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList9);
        boolean boolean13 = functionType11.hasProperty("");
        boolean boolean14 = functionType11.isInstanceType();
        jSTypeRegistry1.unregisterPropertyOnType(".  at hi! line (unknown line) : 0", (com.google.javascript.rhino.jstype.JSType) functionType11);
        com.google.javascript.rhino.JSDocInfo jSDocInfo16 = new com.google.javascript.rhino.JSDocInfo();
        boolean boolean17 = jSDocInfo16.isExterns();
        functionType11.setJSDocInfo(jSDocInfo16);
        boolean boolean19 = jSDocInfo16.isNoAlias();
        org.junit.Assert.assertNotNull(jSTypeArray8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(functionType11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.MessageFormatter messageFormatter1 = null;
        java.util.logging.Logger logger2 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager3 = new com.google.javascript.jscomp.LoggerErrorManager(messageFormatter1, logger2);
        compiler0.setErrorManager((com.google.javascript.jscomp.ErrorManager) loggerErrorManager3);
        com.google.javascript.jscomp.ErrorManager errorManager5 = compiler0.getErrorManager();
        double double6 = compiler0.getProgress();
        com.google.javascript.jscomp.JSError[] jSErrorArray7 = compiler0.getWarnings();
        try {
            java.util.Map<com.google.javascript.rhino.InputId, com.google.javascript.jscomp.CompilerInput> inputIdMap8 = compiler0.getInputsById();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(errorManager5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(jSErrorArray7);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        java.io.File file0 = null;
        java.nio.charset.Charset charset1 = null;
        try {
            com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromFile(file0, charset1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope2 = null;
        jSTypeRegistry1.resolveTypesInScope(jSTypeStaticScope2);
        com.google.javascript.rhino.jstype.ObjectType objectType4 = null;
        com.google.javascript.rhino.ErrorReporter errorReporter5 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry6 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter5);
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope7 = null;
        jSTypeRegistry6.resolveTypesInScope(jSTypeStaticScope7);
        com.google.javascript.rhino.jstype.JSType jSType9 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray10 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList11 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean12 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList11, jSTypeArray10);
        com.google.javascript.rhino.jstype.FunctionType functionType13 = jSTypeRegistry6.createFunctionType(jSType9, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList11);
        com.google.javascript.rhino.JSDocInfo jSDocInfo15 = functionType13.getOwnPropertyJSDocInfo("");
        com.google.javascript.rhino.jstype.ObjectType objectType16 = functionType13.getImplicitPrototype();
        int int17 = functionType13.getMinArguments();
        com.google.javascript.rhino.JSDocInfo jSDocInfo18 = functionType13.getJSDocInfo();
        com.google.javascript.rhino.ErrorReporter errorReporter19 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry20 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter19);
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope21 = null;
        jSTypeRegistry20.resolveTypesInScope(jSTypeStaticScope21);
        com.google.javascript.rhino.jstype.JSType jSType23 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray24 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList25 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean26 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList25, jSTypeArray24);
        com.google.javascript.rhino.jstype.FunctionType functionType27 = jSTypeRegistry20.createFunctionType(jSType23, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList25);
        com.google.javascript.rhino.jstype.JSType jSType28 = jSTypeRegistry1.createFunctionType(objectType4, (com.google.javascript.rhino.jstype.JSType) functionType13, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList25);
        com.google.javascript.rhino.ErrorReporter errorReporter29 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry30 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter29);
        java.lang.String[] strArray39 = new java.lang.String[] { "DiagnosticGroup<checkRegExp>", ": ", "", "", "hi!", ".  at hi! line (unknown line) : 0" };
        java.util.ArrayList<java.lang.String> strList40 = new java.util.ArrayList<java.lang.String>();
        boolean boolean41 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strList40, strArray39);
        java.lang.String[] strArray43 = new java.lang.String[] { "./" };
        java.util.ArrayList<java.lang.String> strList44 = new java.util.ArrayList<java.lang.String>();
        boolean boolean45 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strList44, strArray43);
        com.google.javascript.jscomp.deps.SimpleDependencyInfo simpleDependencyInfo46 = new com.google.javascript.jscomp.deps.SimpleDependencyInfo("./", ": ", (java.util.List<java.lang.String>) strList40, (java.util.List<java.lang.String>) strList44);
        jSTypeRegistry30.setTemplateTypeNames((java.util.List<java.lang.String>) strList40);
        com.google.javascript.rhino.ErrorReporter errorReporter48 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry49 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter48);
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope50 = null;
        jSTypeRegistry49.resolveTypesInScope(jSTypeStaticScope50);
        com.google.javascript.rhino.jstype.JSType jSType52 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray53 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList54 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean55 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList54, jSTypeArray53);
        com.google.javascript.rhino.jstype.FunctionType functionType56 = jSTypeRegistry49.createFunctionType(jSType52, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList54);
        boolean boolean57 = functionType56.hasInstanceType();
        int int58 = functionType56.getMinArguments();
        com.google.javascript.rhino.Node node60 = new com.google.javascript.rhino.Node(10);
        com.google.javascript.rhino.Node node62 = new com.google.javascript.rhino.Node(10);
        boolean boolean63 = node60.isEquivalentToTyped(node62);
        com.google.javascript.rhino.Node node65 = new com.google.javascript.rhino.Node(10);
        com.google.javascript.rhino.Node node67 = new com.google.javascript.rhino.Node(10);
        boolean boolean68 = node65.isEquivalentToTyped(node67);
        java.lang.String str69 = node65.getQualifiedName();
        com.google.javascript.rhino.Node node70 = node62.srcrefTree(node65);
        boolean boolean71 = node70.isNumber();
        com.google.javascript.rhino.jstype.FunctionType functionType72 = jSTypeRegistry30.createFunctionType((com.google.javascript.rhino.jstype.JSType) functionType56, node70);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray73 = new com.google.javascript.rhino.jstype.JSType[] { functionType72 };
        com.google.javascript.rhino.Node node74 = jSTypeRegistry1.createParametersWithVarArgs(jSTypeArray73);
        jSTypeRegistry1.identifyNonNullableName("goog.exportProperty");
        org.junit.Assert.assertNotNull(jSTypeArray10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(functionType13);
        org.junit.Assert.assertNull(jSDocInfo15);
        org.junit.Assert.assertNotNull(objectType16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNull(jSDocInfo18);
        org.junit.Assert.assertNotNull(jSTypeArray24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(functionType27);
        org.junit.Assert.assertNotNull(jSType28);
        org.junit.Assert.assertNotNull(strArray39);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
        org.junit.Assert.assertNotNull(strArray43);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
        org.junit.Assert.assertNotNull(jSTypeArray53);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNotNull(functionType56);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 0 + "'", int58 == 0);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + true + "'", boolean63 == true);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + true + "'", boolean68 == true);
        org.junit.Assert.assertNull(str69);
        org.junit.Assert.assertNotNull(node70);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
        org.junit.Assert.assertNotNull(functionType72);
        org.junit.Assert.assertNotNull(jSTypeArray73);
        org.junit.Assert.assertNotNull(node74);
    }

//    @Test
//    public void test076() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test076");
//        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
//        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope2 = null;
//        jSTypeRegistry1.resolveTypesInScope(jSTypeStaticScope2);
//        com.google.javascript.rhino.jstype.JSType jSType4 = null;
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray5 = new com.google.javascript.rhino.jstype.JSType[] {};
//        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList6 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
//        boolean boolean7 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList6, jSTypeArray5);
//        com.google.javascript.rhino.jstype.FunctionType functionType8 = jSTypeRegistry1.createFunctionType(jSType4, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList6);
//        boolean boolean9 = functionType8.hasReferenceName();
//        com.google.javascript.rhino.jstype.ObjectType objectType10 = functionType8.getTypeOfThis();
//        com.google.javascript.rhino.JSDocInfo jSDocInfo12 = functionType8.getOwnPropertyJSDocInfo(".  at hi! line (unknown line) : 0");
//        java.lang.String str13 = functionType8.toDebugHashCodeString();
//        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable14 = functionType8.getAllExtendedInterfaces();
//        org.junit.Assert.assertNotNull(jSTypeArray5);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertNotNull(functionType8);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertNotNull(objectType10);
//        org.junit.Assert.assertNull(jSDocInfo12);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "function (): {1800053647}" + "'", str13.equals("function (): {1800053647}"));
//        org.junit.Assert.assertNotNull(objectTypeIterable14);
//    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        com.google.javascript.rhino.Node[] nodeArray2 = new com.google.javascript.rhino.Node[] {};
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.IR.block(nodeArray2);
        com.google.javascript.rhino.Node node6 = new com.google.javascript.rhino.Node((int) ' ', nodeArray2, (-1), 40);
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.IR.script(nodeArray2);
        com.google.javascript.rhino.Node node10 = new com.google.javascript.rhino.Node((int) (byte) 100, nodeArray2, 46, 0);
        boolean boolean11 = node10.isCase();
        org.junit.Assert.assertNotNull(nodeArray2);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.exportTestFunctions;
        com.google.javascript.jscomp.AnonymousFunctionNamingPolicy anonymousFunctionNamingPolicy2 = compilerOptions0.anonymousFunctionNaming;
        com.google.javascript.jscomp.parsing.Config.LanguageMode languageMode4 = null;
        java.lang.String[] strArray8 = new java.lang.String[] { "", "" };
        java.util.LinkedHashSet<java.lang.String> strSet9 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean10 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet9, strArray8);
        com.google.javascript.jscomp.parsing.Config config11 = com.google.javascript.jscomp.parsing.ParserRunner.createConfig(true, languageMode4, false, (java.util.Set<java.lang.String>) strSet9);
        compilerOptions0.setStripTypes((java.util.Set<java.lang.String>) strSet9);
        compilerOptions0.collapseProperties = true;
        com.google.javascript.jscomp.CompilerOptions.AliasTransformationHandler aliasTransformationHandler15 = compilerOptions0.getAliasTransformationHandler();
        com.google.javascript.rhino.SourcePosition<com.google.javascript.jscomp.CompilerOptions.AliasTransformation> aliasTransformationSourcePosition17 = null;
        try {
            com.google.javascript.jscomp.CompilerOptions.AliasTransformation aliasTransformation18 = aliasTransformationHandler15.logAliasTransformation("goog.exportProperty", aliasTransformationSourcePosition17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + anonymousFunctionNamingPolicy2 + "' != '" + com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF + "'", anonymousFunctionNamingPolicy2.equals(com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF));
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(config11);
        org.junit.Assert.assertNotNull(aliasTransformationHandler15);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.exportTestFunctions;
        boolean boolean2 = compilerOptions0.recordFunctionInformation;
        compilerOptions0.optimizeParameters = false;
        com.google.javascript.jscomp.parsing.Config.LanguageMode languageMode6 = null;
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.IR.block();
        com.google.javascript.jscomp.parsing.Config.LanguageMode languageMode10 = null;
        java.lang.String[] strArray14 = new java.lang.String[] { "", "" };
        java.util.LinkedHashSet<java.lang.String> strSet15 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean16 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet15, strArray14);
        com.google.javascript.jscomp.parsing.Config config17 = com.google.javascript.jscomp.parsing.ParserRunner.createConfig(true, languageMode10, false, (java.util.Set<java.lang.String>) strSet15);
        node8.setDirectives((java.util.Set<java.lang.String>) strSet15);
        com.google.javascript.jscomp.parsing.Config config19 = com.google.javascript.jscomp.parsing.ParserRunner.createConfig(true, languageMode6, false, (java.util.Set<java.lang.String>) strSet15);
        compilerOptions0.setStripTypes((java.util.Set<java.lang.String>) strSet15);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNotNull(strArray14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(config17);
        org.junit.Assert.assertNotNull(config19);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.exportTestFunctions;
        com.google.javascript.jscomp.AnonymousFunctionNamingPolicy anonymousFunctionNamingPolicy2 = compilerOptions0.anonymousFunctionNaming;
        boolean boolean3 = compilerOptions0.closurePass;
        com.google.javascript.jscomp.CheckLevel checkLevel4 = com.google.javascript.jscomp.CheckLevel.ERROR;
        compilerOptions0.reportMissingOverride = checkLevel4;
        compilerOptions0.setTweakToBooleanLiteral("Not declared as a constructor", true);
        boolean boolean9 = compilerOptions0.inlineLocalFunctions;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + anonymousFunctionNamingPolicy2 + "' != '" + com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF + "'", anonymousFunctionNamingPolicy2.equals(com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + checkLevel4 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel4.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        com.google.javascript.jscomp.JSModule jSModule1 = new com.google.javascript.jscomp.JSModule("Not declared as a type name");
        java.util.List<java.lang.String> strList2 = jSModule1.getRequires();
        boolean boolean4 = jSModule1.removeByName("module$.  at hi! line (unknown line) : 0");
        jSModule1.removeAll();
        org.junit.Assert.assertNotNull(strList2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.MessageFormatter messageFormatter1 = null;
        java.util.logging.Logger logger2 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager3 = new com.google.javascript.jscomp.LoggerErrorManager(messageFormatter1, logger2);
        compiler0.setErrorManager((com.google.javascript.jscomp.ErrorManager) loggerErrorManager3);
        com.google.javascript.jscomp.Compiler compiler5 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.PerformanceTracker performanceTracker6 = compiler5.tracker;
        com.google.javascript.jscomp.Compiler.IntermediateState intermediateState7 = compiler5.getState();
        compiler0.setState(intermediateState7);
        com.google.javascript.jscomp.JSModule jSModule10 = new com.google.javascript.jscomp.JSModule("Not declared as a type name");
        java.util.List<java.lang.String> strList11 = jSModule10.getRequires();
        try {
            java.lang.String str12 = compiler0.toSource(jSModule10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(performanceTracker6);
        org.junit.Assert.assertNotNull(intermediateState7);
        org.junit.Assert.assertNotNull(strList11);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.exportTestFunctions;
        boolean boolean2 = compilerOptions0.recordFunctionInformation;
        compilerOptions0.inlineFunctions = true;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.CHECK_VARIABLES;
        com.google.javascript.jscomp.DiagnosticGroups.TYPE_INVALIDATION = diagnosticGroup0;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        com.google.javascript.jscomp.JSModule jSModule1 = new com.google.javascript.jscomp.JSModule("Not declared as a type name");
        java.util.List<java.lang.String> strList2 = jSModule1.getRequires();
        boolean boolean4 = jSModule1.removeByName("module$.  at hi! line (unknown line) : 0");
        com.google.javascript.jscomp.Compiler compiler5 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.PerformanceTracker performanceTracker6 = compiler5.tracker;
        com.google.javascript.jscomp.Compiler.IntermediateState intermediateState7 = compiler5.getState();
        jSModule1.sortInputsByDeps(compiler5);
        org.junit.Assert.assertNotNull(strList2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(performanceTracker6);
        org.junit.Assert.assertNotNull(intermediateState7);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setCheckTypes(false);
        com.google.javascript.jscomp.CompilerOptions.LanguageMode languageMode3 = compilerOptions0.getLanguageOut();
        compilerOptions0.setInlineLocalVariables(false);
        compilerOptions0.setTightenTypes(true);
        java.util.Map<java.lang.String, com.google.javascript.rhino.Node> strMap8 = compilerOptions0.getDefineReplacements();
        boolean boolean9 = compilerOptions0.removeUnusedPrototypePropertiesInExterns;
        compilerOptions0.setConvertToDottedProperties(false);
        org.junit.Assert.assertNull(languageMode3);
        org.junit.Assert.assertNotNull(strMap8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        com.google.javascript.rhino.Node[] nodeArray2 = new com.google.javascript.rhino.Node[] {};
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.IR.block(nodeArray2);
        com.google.javascript.rhino.Node node6 = new com.google.javascript.rhino.Node((int) ' ', nodeArray2, (-1), 40);
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.IR.script(nodeArray2);
        com.google.javascript.rhino.Node node10 = new com.google.javascript.rhino.Node((int) (byte) 100, nodeArray2, 46, 0);
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.IR.paramList(nodeArray2);
        org.junit.Assert.assertNotNull(nodeArray2);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertNotNull(node11);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.empty();
        boolean boolean1 = node0.hasOneChild();
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        com.google.javascript.rhino.Node node1 = new com.google.javascript.rhino.Node(10);
        com.google.javascript.rhino.Node node3 = new com.google.javascript.rhino.Node(10);
        com.google.javascript.rhino.Node node4 = node3.cloneTree();
        com.google.javascript.rhino.Node node5 = node1.clonePropsFrom(node4);
        int int6 = node4.getSourceOffset();
        node4.setSourceFileForTesting(".  at hi! line (unknown line) : 0");
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.exportTestFunctions;
        boolean boolean2 = compilerOptions0.recordFunctionInformation;
        compilerOptions0.setAliasAllStrings(false);
        compilerOptions0.setExportTestFunctions(true);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope2 = null;
        jSTypeRegistry1.resolveTypesInScope(jSTypeStaticScope2);
        com.google.javascript.rhino.jstype.JSType jSType4 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray5 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList6 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean7 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList6, jSTypeArray5);
        com.google.javascript.rhino.jstype.FunctionType functionType8 = jSTypeRegistry1.createFunctionType(jSType4, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList6);
        com.google.javascript.rhino.JSDocInfo jSDocInfo10 = functionType8.getOwnPropertyJSDocInfo("");
        com.google.javascript.rhino.jstype.ObjectType objectType11 = functionType8.getImplicitPrototype();
        boolean boolean12 = objectType11.hasCachedValues();
        boolean boolean13 = objectType11.isObject();
        org.junit.Assert.assertNotNull(jSTypeArray5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(functionType8);
        org.junit.Assert.assertNull(jSDocInfo10);
        org.junit.Assert.assertNotNull(objectType11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        com.google.javascript.jscomp.CodingConvention codingConvention0 = com.google.javascript.jscomp.CodingConventions.getDefault();
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention1 = new com.google.javascript.jscomp.ClosureCodingConvention(codingConvention0);
        com.google.javascript.rhino.Node node2 = null;
        boolean boolean3 = closureCodingConvention1.isVarArgsParameter(node2);
        java.lang.String str4 = closureCodingConvention1.getExportPropertyFunction();
        com.google.javascript.rhino.Node node6 = new com.google.javascript.rhino.Node(10);
        com.google.javascript.rhino.Node node8 = new com.google.javascript.rhino.Node(10);
        boolean boolean9 = node6.isEquivalentToTyped(node8);
        java.lang.String str10 = node6.getQualifiedName();
        node6.setWasEmptyNode(false);
        com.google.javascript.rhino.Node node14 = new com.google.javascript.rhino.Node(10);
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.IR.comma(node6, node14);
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newString(": ");
        boolean boolean18 = node17.isTrue();
        java.lang.String str19 = closureCodingConvention1.extractClassNameIfRequire(node14, node17);
        com.google.javascript.rhino.Node node21 = new com.google.javascript.rhino.Node(10);
        com.google.javascript.rhino.Node node22 = node21.cloneTree();
        node22.setSourceEncodedPosition(15);
        try {
            java.util.List<java.lang.String> strList25 = closureCodingConvention1.identifyTypeDeclarationCall(node22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(codingConvention0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "goog.exportProperty" + "'", str4.equals("goog.exportProperty"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNull(str19);
        org.junit.Assert.assertNotNull(node22);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setCheckTypes(false);
        compilerOptions0.optimizeReturns = true;
        compilerOptions0.setFlowSensitiveInlineVariables(false);
        byte[] byteArray9 = new byte[] { (byte) -1, (byte) 100 };
        compilerOptions0.inputPropertyMapSerialized = byteArray9;
        boolean boolean11 = compilerOptions0.isExternExportsEnabled();
        boolean boolean12 = compilerOptions0.gatherCssNames;
        java.lang.String str13 = compilerOptions0.inputDelimiter;
        com.google.javascript.jscomp.CompilerOptions.LanguageMode languageMode14 = compilerOptions0.getLanguageOut();
        org.junit.Assert.assertNotNull(byteArray9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "// Input %num%" + "'", str13.equals("// Input %num%"));
        org.junit.Assert.assertNull(languageMode14);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.MessageFormatter messageFormatter1 = null;
        java.util.logging.Logger logger2 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager3 = new com.google.javascript.jscomp.LoggerErrorManager(messageFormatter1, logger2);
        compiler0.setErrorManager((com.google.javascript.jscomp.ErrorManager) loggerErrorManager3);
        com.google.javascript.jscomp.NodeTraversal.Callback callback5 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal6 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler0, callback5);
        java.util.List<com.google.javascript.rhino.Node> nodeList7 = null;
        com.google.javascript.jscomp.NodeTraversal.Callback callback8 = null;
        try {
            com.google.javascript.jscomp.NodeTraversal.traverseRoots((com.google.javascript.jscomp.AbstractCompiler) compiler0, nodeList7, callback8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        java.nio.charset.Charset charset1 = null;
        com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromFile(": ", charset1);
        java.lang.String str3 = sourceFile2.getOriginalPath();
        java.lang.String str4 = sourceFile2.getOriginalPath();
        try {
            int int6 = sourceFile2.getLineOffset(10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Expected line number between 1 and 1\nActual: 10");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(sourceFile2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + ": " + "'", str3.equals(": "));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + ": " + "'", str4.equals(": "));
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.block();
        com.google.javascript.jscomp.parsing.Config.LanguageMode languageMode2 = null;
        java.lang.String[] strArray6 = new java.lang.String[] { "", "" };
        java.util.LinkedHashSet<java.lang.String> strSet7 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean8 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet7, strArray6);
        com.google.javascript.jscomp.parsing.Config config9 = com.google.javascript.jscomp.parsing.ParserRunner.createConfig(true, languageMode2, false, (java.util.Set<java.lang.String>) strSet7);
        node0.setDirectives((java.util.Set<java.lang.String>) strSet7);
        node0.setIsSyntheticBlock(false);
        node0.addSuppression("hi!");
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(config9);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        int int0 = com.google.javascript.rhino.Node.LENGTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 52 + "'", int0 == 52);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.exportTestFunctions;
        com.google.javascript.jscomp.AnonymousFunctionNamingPolicy anonymousFunctionNamingPolicy2 = compilerOptions0.anonymousFunctionNaming;
        boolean boolean3 = compilerOptions0.closurePass;
        com.google.javascript.jscomp.CheckLevel checkLevel4 = com.google.javascript.jscomp.CheckLevel.ERROR;
        compilerOptions0.reportMissingOverride = checkLevel4;
        compilerOptions0.setTweakToBooleanLiteral("Not declared as a constructor", true);
        compilerOptions0.setInlineLocalFunctions(true);
        compilerOptions0.setInlineFunctions(true);
        compilerOptions0.setRemoveTryCatchFinally(false);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + anonymousFunctionNamingPolicy2 + "' != '" + com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF + "'", anonymousFunctionNamingPolicy2.equals(com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + checkLevel4 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel4.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        com.google.javascript.rhino.JSDocInfoBuilder jSDocInfoBuilder1 = new com.google.javascript.rhino.JSDocInfoBuilder(true);
        boolean boolean2 = jSDocInfoBuilder1.isPopulatedWithFileOverview();
        boolean boolean3 = jSDocInfoBuilder1.isConstructorRecorded();
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.IR.number((double) (byte) 10);
        boolean boolean7 = node6.isStringKey();
        com.google.javascript.rhino.JSTypeExpression jSTypeExpression9 = new com.google.javascript.rhino.JSTypeExpression(node6, "");
        boolean boolean10 = jSTypeExpression9.isVarArgs();
        boolean boolean11 = jSDocInfoBuilder1.recordParameter("", jSTypeExpression9);
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.IR.number((double) (byte) 10);
        boolean boolean15 = node14.isStringKey();
        com.google.javascript.rhino.JSTypeExpression jSTypeExpression17 = new com.google.javascript.rhino.JSTypeExpression(node14, "");
        boolean boolean18 = jSTypeExpression17.isVarArgs();
        com.google.javascript.rhino.JSTypeExpression jSTypeExpression19 = com.google.javascript.rhino.JSTypeExpression.makeOptionalArg(jSTypeExpression17);
        boolean boolean20 = jSDocInfoBuilder1.recordParameter("function (): {1800053647}", jSTypeExpression17);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(jSTypeExpression19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.exportTestFunctions;
        com.google.javascript.jscomp.AnonymousFunctionNamingPolicy anonymousFunctionNamingPolicy2 = compilerOptions0.anonymousFunctionNaming;
        com.google.javascript.jscomp.parsing.Config.LanguageMode languageMode4 = null;
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.IR.block();
        com.google.javascript.jscomp.parsing.Config.LanguageMode languageMode8 = null;
        java.lang.String[] strArray12 = new java.lang.String[] { "", "" };
        java.util.LinkedHashSet<java.lang.String> strSet13 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean14 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet13, strArray12);
        com.google.javascript.jscomp.parsing.Config config15 = com.google.javascript.jscomp.parsing.ParserRunner.createConfig(true, languageMode8, false, (java.util.Set<java.lang.String>) strSet13);
        node6.setDirectives((java.util.Set<java.lang.String>) strSet13);
        com.google.javascript.jscomp.parsing.Config config17 = com.google.javascript.jscomp.parsing.ParserRunner.createConfig(true, languageMode4, false, (java.util.Set<java.lang.String>) strSet13);
        compilerOptions0.setIdGenerators((java.util.Set<java.lang.String>) strSet13);
        compilerOptions0.setNameReferenceReportPath("Unknown class name");
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap21 = compilerOptions0.cssRenamingMap;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + anonymousFunctionNamingPolicy2 + "' != '" + com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF + "'", anonymousFunctionNamingPolicy2.equals(com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF));
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(strArray12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(config15);
        org.junit.Assert.assertNotNull(config17);
        org.junit.Assert.assertNull(cssRenamingMap21);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        jSTypeRegistry1.identifyNonNullableName("");
        com.google.javascript.rhino.ErrorReporter errorReporter4 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter4);
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope6 = null;
        jSTypeRegistry5.resolveTypesInScope(jSTypeStaticScope6);
        com.google.javascript.rhino.jstype.JSType jSType8 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray9 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList10 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean11 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList10, jSTypeArray9);
        com.google.javascript.rhino.jstype.FunctionType functionType12 = jSTypeRegistry5.createFunctionType(jSType8, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList10);
        com.google.javascript.rhino.ErrorReporter errorReporter14 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry15 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter14);
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope16 = null;
        jSTypeRegistry15.resolveTypesInScope(jSTypeStaticScope16);
        com.google.javascript.rhino.ErrorReporter errorReporter18 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry19 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter18);
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope20 = null;
        jSTypeRegistry19.resolveTypesInScope(jSTypeStaticScope20);
        com.google.javascript.rhino.jstype.JSType jSType22 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray23 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList24 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean25 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList24, jSTypeArray23);
        com.google.javascript.rhino.jstype.FunctionType functionType26 = jSTypeRegistry19.createFunctionType(jSType22, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList24);
        com.google.javascript.rhino.JSDocInfo jSDocInfo28 = functionType26.getOwnPropertyJSDocInfo("");
        com.google.javascript.rhino.ErrorReporter errorReporter29 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry30 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter29);
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope31 = null;
        jSTypeRegistry30.resolveTypesInScope(jSTypeStaticScope31);
        com.google.javascript.rhino.jstype.JSType jSType33 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray34 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList35 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean36 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList35, jSTypeArray34);
        com.google.javascript.rhino.jstype.FunctionType functionType37 = jSTypeRegistry30.createFunctionType(jSType33, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList35);
        com.google.javascript.rhino.JSDocInfo jSDocInfo39 = functionType37.getOwnPropertyJSDocInfo("");
        com.google.javascript.rhino.jstype.ObjectType objectType40 = functionType37.getImplicitPrototype();
        boolean boolean41 = objectType40.hasCachedValues();
        com.google.javascript.rhino.ErrorReporter errorReporter42 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry43 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter42);
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope44 = null;
        jSTypeRegistry43.resolveTypesInScope(jSTypeStaticScope44);
        com.google.javascript.rhino.jstype.JSType jSType46 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray47 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList48 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean49 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList48, jSTypeArray47);
        com.google.javascript.rhino.jstype.FunctionType functionType50 = jSTypeRegistry43.createFunctionType(jSType46, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList48);
        com.google.javascript.rhino.JSDocInfo jSDocInfo52 = functionType50.getOwnPropertyJSDocInfo("");
        boolean boolean54 = functionType50.removeProperty(".  at hi! line (unknown line) : 0");
        com.google.javascript.rhino.ErrorReporter errorReporter55 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry56 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter55);
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope57 = null;
        jSTypeRegistry56.resolveTypesInScope(jSTypeStaticScope57);
        com.google.javascript.rhino.jstype.JSType jSType59 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray60 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList61 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean62 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList61, jSTypeArray60);
        com.google.javascript.rhino.jstype.FunctionType functionType63 = jSTypeRegistry56.createFunctionType(jSType59, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList61);
        com.google.javascript.rhino.ErrorReporter errorReporter64 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry65 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter64);
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope66 = null;
        jSTypeRegistry65.resolveTypesInScope(jSTypeStaticScope66);
        com.google.javascript.rhino.jstype.JSType jSType68 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray69 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList70 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean71 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList70, jSTypeArray69);
        com.google.javascript.rhino.jstype.FunctionType functionType72 = jSTypeRegistry65.createFunctionType(jSType68, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList70);
        com.google.javascript.rhino.JSDocInfo jSDocInfo74 = functionType72.getOwnPropertyJSDocInfo("");
        com.google.javascript.rhino.ErrorReporter errorReporter75 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry76 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter75);
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope77 = null;
        jSTypeRegistry76.resolveTypesInScope(jSTypeStaticScope77);
        com.google.javascript.rhino.jstype.JSType jSType79 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray80 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList81 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean82 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList81, jSTypeArray80);
        com.google.javascript.rhino.jstype.FunctionType functionType83 = jSTypeRegistry76.createFunctionType(jSType79, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList81);
        com.google.javascript.rhino.JSDocInfo jSDocInfo85 = functionType83.getOwnPropertyJSDocInfo("");
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray86 = new com.google.javascript.rhino.jstype.JSType[] { objectType40, functionType50, functionType63, functionType72, functionType83 };
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList87 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean88 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList87, jSTypeArray86);
        com.google.javascript.rhino.jstype.FunctionType functionType89 = jSTypeRegistry15.createFunctionTypeWithVarArgs((com.google.javascript.rhino.jstype.JSType) functionType26, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList87);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray90 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.Node node91 = jSTypeRegistry15.createParameters(jSTypeArray90);
        com.google.javascript.rhino.jstype.FunctionType functionType92 = jSTypeRegistry1.createConstructorType(jSType8, false, jSTypeArray90);
        boolean boolean93 = functionType92.isNumberValueType();
        boolean boolean94 = functionType92.hasDisplayName();
        org.junit.Assert.assertNotNull(jSTypeArray9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(functionType12);
        org.junit.Assert.assertNotNull(jSTypeArray23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(functionType26);
        org.junit.Assert.assertNull(jSDocInfo28);
        org.junit.Assert.assertNotNull(jSTypeArray34);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(functionType37);
        org.junit.Assert.assertNull(jSDocInfo39);
        org.junit.Assert.assertNotNull(objectType40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(jSTypeArray47);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNotNull(functionType50);
        org.junit.Assert.assertNull(jSDocInfo52);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNotNull(jSTypeArray60);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertNotNull(functionType63);
        org.junit.Assert.assertNotNull(jSTypeArray69);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
        org.junit.Assert.assertNotNull(functionType72);
        org.junit.Assert.assertNull(jSDocInfo74);
        org.junit.Assert.assertNotNull(jSTypeArray80);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
        org.junit.Assert.assertNotNull(functionType83);
        org.junit.Assert.assertNull(jSDocInfo85);
        org.junit.Assert.assertNotNull(jSTypeArray86);
        org.junit.Assert.assertTrue("'" + boolean88 + "' != '" + true + "'", boolean88 == true);
        org.junit.Assert.assertNotNull(functionType89);
        org.junit.Assert.assertNotNull(jSTypeArray90);
        org.junit.Assert.assertNotNull(node91);
        org.junit.Assert.assertNotNull(functionType92);
        org.junit.Assert.assertTrue("'" + boolean93 + "' != '" + false + "'", boolean93 == false);
        org.junit.Assert.assertTrue("'" + boolean94 + "' != '" + false + "'", boolean94 == false);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setCheckTypes(false);
        boolean boolean3 = compilerOptions0.removeTryCatchFinally;
        com.google.javascript.jscomp.CheckLevel checkLevel4 = com.google.javascript.jscomp.CheckLevel.ERROR;
        compilerOptions0.setCheckProvides(checkLevel4);
        com.google.javascript.jscomp.CompilerOptions compilerOptions6 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions6.setCheckTypes(false);
        com.google.javascript.jscomp.CompilerOptions.LanguageMode languageMode9 = compilerOptions6.getLanguageOut();
        com.google.javascript.jscomp.CheckLevel checkLevel10 = com.google.javascript.jscomp.CheckLevel.ERROR;
        compilerOptions6.checkRequires = checkLevel10;
        compilerOptions0.setCheckRequires(checkLevel10);
        compilerOptions0.setPreferLineBreakAtEndOfFile(false);
        compilerOptions0.setDisambiguateProperties(false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + checkLevel4 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel4.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNull(languageMode9);
        org.junit.Assert.assertTrue("'" + checkLevel10 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel10.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        com.google.javascript.jscomp.SourceFile.Generator generator1 = null;
        com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromGenerator("DependencyInfo(relativePath='./', path=': ', provides=[DiagnosticGroup<checkRegExp>, : , , , hi!, .  at hi! line (unknown line) : 0], requires=[./])", generator1);
        org.junit.Assert.assertNotNull(sourceFile2);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope2 = null;
        jSTypeRegistry1.resolveTypesInScope(jSTypeStaticScope2);
        com.google.javascript.rhino.ErrorReporter errorReporter4 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter4);
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope6 = null;
        jSTypeRegistry5.resolveTypesInScope(jSTypeStaticScope6);
        com.google.javascript.rhino.jstype.JSType jSType8 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray9 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList10 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean11 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList10, jSTypeArray9);
        com.google.javascript.rhino.jstype.FunctionType functionType12 = jSTypeRegistry5.createFunctionType(jSType8, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList10);
        com.google.javascript.rhino.JSDocInfo jSDocInfo14 = functionType12.getOwnPropertyJSDocInfo("");
        com.google.javascript.rhino.ErrorReporter errorReporter15 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry16 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter15);
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope17 = null;
        jSTypeRegistry16.resolveTypesInScope(jSTypeStaticScope17);
        com.google.javascript.rhino.jstype.JSType jSType19 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray20 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList21 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean22 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList21, jSTypeArray20);
        com.google.javascript.rhino.jstype.FunctionType functionType23 = jSTypeRegistry16.createFunctionType(jSType19, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList21);
        com.google.javascript.rhino.JSDocInfo jSDocInfo25 = functionType23.getOwnPropertyJSDocInfo("");
        com.google.javascript.rhino.jstype.ObjectType objectType26 = functionType23.getImplicitPrototype();
        boolean boolean27 = objectType26.hasCachedValues();
        com.google.javascript.rhino.ErrorReporter errorReporter28 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry29 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter28);
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope30 = null;
        jSTypeRegistry29.resolveTypesInScope(jSTypeStaticScope30);
        com.google.javascript.rhino.jstype.JSType jSType32 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray33 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList34 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean35 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList34, jSTypeArray33);
        com.google.javascript.rhino.jstype.FunctionType functionType36 = jSTypeRegistry29.createFunctionType(jSType32, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList34);
        com.google.javascript.rhino.JSDocInfo jSDocInfo38 = functionType36.getOwnPropertyJSDocInfo("");
        boolean boolean40 = functionType36.removeProperty(".  at hi! line (unknown line) : 0");
        com.google.javascript.rhino.ErrorReporter errorReporter41 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry42 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter41);
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope43 = null;
        jSTypeRegistry42.resolveTypesInScope(jSTypeStaticScope43);
        com.google.javascript.rhino.jstype.JSType jSType45 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray46 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList47 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean48 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList47, jSTypeArray46);
        com.google.javascript.rhino.jstype.FunctionType functionType49 = jSTypeRegistry42.createFunctionType(jSType45, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList47);
        com.google.javascript.rhino.ErrorReporter errorReporter50 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry51 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter50);
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope52 = null;
        jSTypeRegistry51.resolveTypesInScope(jSTypeStaticScope52);
        com.google.javascript.rhino.jstype.JSType jSType54 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray55 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList56 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean57 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList56, jSTypeArray55);
        com.google.javascript.rhino.jstype.FunctionType functionType58 = jSTypeRegistry51.createFunctionType(jSType54, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList56);
        com.google.javascript.rhino.JSDocInfo jSDocInfo60 = functionType58.getOwnPropertyJSDocInfo("");
        com.google.javascript.rhino.ErrorReporter errorReporter61 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry62 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter61);
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope63 = null;
        jSTypeRegistry62.resolveTypesInScope(jSTypeStaticScope63);
        com.google.javascript.rhino.jstype.JSType jSType65 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray66 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList67 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean68 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList67, jSTypeArray66);
        com.google.javascript.rhino.jstype.FunctionType functionType69 = jSTypeRegistry62.createFunctionType(jSType65, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList67);
        com.google.javascript.rhino.JSDocInfo jSDocInfo71 = functionType69.getOwnPropertyJSDocInfo("");
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray72 = new com.google.javascript.rhino.jstype.JSType[] { objectType26, functionType36, functionType49, functionType58, functionType69 };
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList73 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean74 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList73, jSTypeArray72);
        com.google.javascript.rhino.jstype.FunctionType functionType75 = jSTypeRegistry1.createFunctionTypeWithVarArgs((com.google.javascript.rhino.jstype.JSType) functionType12, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList73);
        int int76 = functionType12.getMaxArguments();
        boolean boolean77 = functionType12.isNumber();
        boolean boolean78 = functionType12.isInstanceType();
        org.junit.Assert.assertNotNull(jSTypeArray9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(functionType12);
        org.junit.Assert.assertNull(jSDocInfo14);
        org.junit.Assert.assertNotNull(jSTypeArray20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(functionType23);
        org.junit.Assert.assertNull(jSDocInfo25);
        org.junit.Assert.assertNotNull(objectType26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(jSTypeArray33);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(functionType36);
        org.junit.Assert.assertNull(jSDocInfo38);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(jSTypeArray46);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(functionType49);
        org.junit.Assert.assertNotNull(jSTypeArray55);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertNotNull(functionType58);
        org.junit.Assert.assertNull(jSDocInfo60);
        org.junit.Assert.assertNotNull(jSTypeArray66);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertNotNull(functionType69);
        org.junit.Assert.assertNull(jSDocInfo71);
        org.junit.Assert.assertNotNull(jSTypeArray72);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + true + "'", boolean74 == true);
        org.junit.Assert.assertNotNull(functionType75);
        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 0 + "'", int76 == 0);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        com.google.javascript.rhino.Node node1 = com.google.javascript.jscomp.parsing.JsDocInfoParser.parseTypeString("hi!");
        boolean boolean2 = node1.isLabelName();
        node1.removeProp(53);
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.exportTestFunctions;
        boolean boolean2 = compilerOptions0.recordFunctionInformation;
        boolean boolean3 = compilerOptions0.removeDeadCode;
        com.google.javascript.jscomp.CompilerOptions.TracerMode tracerMode4 = compilerOptions0.getTracerMode();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + tracerMode4 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TracerMode.OFF + "'", tracerMode4.equals(com.google.javascript.jscomp.CompilerOptions.TracerMode.OFF));
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.MessageFormatter messageFormatter1 = null;
        java.util.logging.Logger logger2 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager3 = new com.google.javascript.jscomp.LoggerErrorManager(messageFormatter1, logger2);
        compiler0.setErrorManager((com.google.javascript.jscomp.ErrorManager) loggerErrorManager3);
        com.google.javascript.jscomp.NodeTraversal.Callback callback5 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal6 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler0, callback5);
        boolean boolean7 = nodeTraversal6.hasScope();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        com.google.javascript.jscomp.DiagnosticType diagnosticType2 = com.google.javascript.jscomp.DiagnosticType.warning("hi!", "");
        com.google.javascript.jscomp.DiagnosticType diagnosticType8 = com.google.javascript.jscomp.DiagnosticType.error("", "");
        java.lang.String str9 = diagnosticType8.toString();
        java.lang.String[] strArray12 = new java.lang.String[] { "", "" };
        com.google.javascript.jscomp.JSError jSError13 = com.google.javascript.jscomp.JSError.make("hi!", (-1), 0, diagnosticType8, strArray12);
        com.google.javascript.jscomp.DiagnosticType[] diagnosticTypeArray14 = new com.google.javascript.jscomp.DiagnosticType[] { diagnosticType2, diagnosticType8 };
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup15 = new com.google.javascript.jscomp.DiagnosticGroup(diagnosticTypeArray14);
        com.google.javascript.jscomp.CheckLevel checkLevel16 = null;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard17 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup15, checkLevel16);
        com.google.javascript.jscomp.DiagnosticType diagnosticType20 = com.google.javascript.jscomp.DiagnosticType.warning("hi!", "");
        com.google.javascript.jscomp.DiagnosticType diagnosticType26 = com.google.javascript.jscomp.DiagnosticType.error("", "");
        java.lang.String str27 = diagnosticType26.toString();
        java.lang.String[] strArray30 = new java.lang.String[] { "", "" };
        com.google.javascript.jscomp.JSError jSError31 = com.google.javascript.jscomp.JSError.make("hi!", (-1), 0, diagnosticType26, strArray30);
        com.google.javascript.jscomp.DiagnosticType[] diagnosticTypeArray32 = new com.google.javascript.jscomp.DiagnosticType[] { diagnosticType20, diagnosticType26 };
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup33 = new com.google.javascript.jscomp.DiagnosticGroup(diagnosticTypeArray32);
        com.google.javascript.jscomp.CheckLevel checkLevel34 = null;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard35 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup33, checkLevel34);
        com.google.javascript.jscomp.DiagnosticType diagnosticType38 = com.google.javascript.jscomp.DiagnosticType.warning("hi!", "");
        com.google.javascript.jscomp.DiagnosticType diagnosticType44 = com.google.javascript.jscomp.DiagnosticType.error("", "");
        java.lang.String str45 = diagnosticType44.toString();
        java.lang.String[] strArray48 = new java.lang.String[] { "", "" };
        com.google.javascript.jscomp.JSError jSError49 = com.google.javascript.jscomp.JSError.make("hi!", (-1), 0, diagnosticType44, strArray48);
        com.google.javascript.jscomp.DiagnosticType[] diagnosticTypeArray50 = new com.google.javascript.jscomp.DiagnosticType[] { diagnosticType38, diagnosticType44 };
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup51 = new com.google.javascript.jscomp.DiagnosticGroup(diagnosticTypeArray50);
        com.google.javascript.jscomp.CheckLevel checkLevel52 = null;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard53 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup51, checkLevel52);
        com.google.javascript.jscomp.DiagnosticType diagnosticType56 = com.google.javascript.jscomp.DiagnosticType.warning("hi!", "");
        com.google.javascript.jscomp.DiagnosticType diagnosticType62 = com.google.javascript.jscomp.DiagnosticType.error("", "");
        java.lang.String str63 = diagnosticType62.toString();
        java.lang.String[] strArray66 = new java.lang.String[] { "", "" };
        com.google.javascript.jscomp.JSError jSError67 = com.google.javascript.jscomp.JSError.make("hi!", (-1), 0, diagnosticType62, strArray66);
        com.google.javascript.jscomp.DiagnosticType[] diagnosticTypeArray68 = new com.google.javascript.jscomp.DiagnosticType[] { diagnosticType56, diagnosticType62 };
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup69 = new com.google.javascript.jscomp.DiagnosticGroup(diagnosticTypeArray68);
        com.google.javascript.jscomp.CheckLevel checkLevel70 = null;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard71 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup69, checkLevel70);
        com.google.javascript.jscomp.DiagnosticType diagnosticType74 = com.google.javascript.jscomp.DiagnosticType.warning("hi!", "");
        com.google.javascript.jscomp.DiagnosticType diagnosticType80 = com.google.javascript.jscomp.DiagnosticType.error("", "");
        java.lang.String str81 = diagnosticType80.toString();
        java.lang.String[] strArray84 = new java.lang.String[] { "", "" };
        com.google.javascript.jscomp.JSError jSError85 = com.google.javascript.jscomp.JSError.make("hi!", (-1), 0, diagnosticType80, strArray84);
        com.google.javascript.jscomp.DiagnosticType[] diagnosticTypeArray86 = new com.google.javascript.jscomp.DiagnosticType[] { diagnosticType74, diagnosticType80 };
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup87 = new com.google.javascript.jscomp.DiagnosticGroup(diagnosticTypeArray86);
        com.google.javascript.jscomp.CheckLevel checkLevel88 = null;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard89 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup87, checkLevel88);
        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray90 = new com.google.javascript.jscomp.WarningsGuard[] { diagnosticGroupWarningsGuard17, diagnosticGroupWarningsGuard35, diagnosticGroupWarningsGuard53, diagnosticGroupWarningsGuard71, diagnosticGroupWarningsGuard89 };
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard91 = new com.google.javascript.jscomp.ComposeWarningsGuard(warningsGuardArray90);
        com.google.javascript.jscomp.JSError jSError92 = null;
        try {
            com.google.javascript.jscomp.CheckLevel checkLevel93 = composeWarningsGuard91.level(jSError92);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(diagnosticType2);
        org.junit.Assert.assertNotNull(diagnosticType8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + ": " + "'", str9.equals(": "));
        org.junit.Assert.assertNotNull(strArray12);
        org.junit.Assert.assertNotNull(jSError13);
        org.junit.Assert.assertNotNull(diagnosticTypeArray14);
        org.junit.Assert.assertNotNull(diagnosticType20);
        org.junit.Assert.assertNotNull(diagnosticType26);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + ": " + "'", str27.equals(": "));
        org.junit.Assert.assertNotNull(strArray30);
        org.junit.Assert.assertNotNull(jSError31);
        org.junit.Assert.assertNotNull(diagnosticTypeArray32);
        org.junit.Assert.assertNotNull(diagnosticType38);
        org.junit.Assert.assertNotNull(diagnosticType44);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + ": " + "'", str45.equals(": "));
        org.junit.Assert.assertNotNull(strArray48);
        org.junit.Assert.assertNotNull(jSError49);
        org.junit.Assert.assertNotNull(diagnosticTypeArray50);
        org.junit.Assert.assertNotNull(diagnosticType56);
        org.junit.Assert.assertNotNull(diagnosticType62);
        org.junit.Assert.assertTrue("'" + str63 + "' != '" + ": " + "'", str63.equals(": "));
        org.junit.Assert.assertNotNull(strArray66);
        org.junit.Assert.assertNotNull(jSError67);
        org.junit.Assert.assertNotNull(diagnosticTypeArray68);
        org.junit.Assert.assertNotNull(diagnosticType74);
        org.junit.Assert.assertNotNull(diagnosticType80);
        org.junit.Assert.assertTrue("'" + str81 + "' != '" + ": " + "'", str81.equals(": "));
        org.junit.Assert.assertNotNull(strArray84);
        org.junit.Assert.assertNotNull(jSError85);
        org.junit.Assert.assertNotNull(diagnosticTypeArray86);
        org.junit.Assert.assertNotNull(warningsGuardArray90);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString((int) (short) -1, "");
        boolean boolean4 = node3.isThrow();
        com.google.javascript.rhino.Node node6 = new com.google.javascript.rhino.Node(10);
        com.google.javascript.rhino.Node node8 = new com.google.javascript.rhino.Node(10);
        boolean boolean9 = node6.isEquivalentToTyped(node8);
        boolean boolean10 = node6.isOnlyModifiesThisCall();
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.IR.throwNode(node6);
        com.google.javascript.rhino.Node node12 = node3.useSourceInfoIfMissingFrom(node6);
        int int13 = node6.getSourceOffset();
        java.lang.String str14 = com.google.javascript.jscomp.NodeUtil.getNearestFunctionName(node6);
        com.google.javascript.jscomp.DiagnosticType diagnosticType17 = com.google.javascript.jscomp.DiagnosticType.disabled("module$DiagnosticGroup<checkRegExp>", ".  at hi! line (unknown line) : 0");
        com.google.javascript.rhino.Node node20 = new com.google.javascript.rhino.Node(10);
        com.google.javascript.rhino.Node node22 = new com.google.javascript.rhino.Node(10);
        com.google.javascript.rhino.Node node23 = node22.cloneTree();
        com.google.javascript.rhino.Node node24 = node20.clonePropsFrom(node23);
        com.google.javascript.jscomp.DiagnosticType diagnosticType27 = com.google.javascript.jscomp.DiagnosticType.error("", "");
        com.google.javascript.jscomp.DiagnosticType diagnosticType33 = com.google.javascript.jscomp.DiagnosticType.error("", "");
        java.lang.String str34 = diagnosticType33.toString();
        java.lang.String[] strArray37 = new java.lang.String[] { "", "" };
        com.google.javascript.jscomp.JSError jSError38 = com.google.javascript.jscomp.JSError.make("hi!", (-1), 0, diagnosticType33, strArray37);
        com.google.javascript.jscomp.JSError jSError39 = com.google.javascript.jscomp.JSError.make("hi!", node20, diagnosticType27, strArray37);
        com.google.javascript.jscomp.JSError jSError40 = com.google.javascript.jscomp.JSError.make("module$DiagnosticGroup<checkRegExp>", node6, diagnosticType17, strArray37);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNotNull(diagnosticType17);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertNotNull(diagnosticType27);
        org.junit.Assert.assertNotNull(diagnosticType33);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + ": " + "'", str34.equals(": "));
        org.junit.Assert.assertNotNull(strArray37);
        org.junit.Assert.assertNotNull(jSError38);
        org.junit.Assert.assertNotNull(jSError39);
        org.junit.Assert.assertNotNull(jSError40);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        com.google.javascript.rhino.Node node0 = null;
        try {
            boolean boolean1 = com.google.javascript.jscomp.NodeUtil.isSymmetricOperation(node0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope2 = null;
        jSTypeRegistry1.resolveTypesInScope(jSTypeStaticScope2);
        com.google.javascript.rhino.ErrorReporter errorReporter4 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter4);
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope6 = null;
        jSTypeRegistry5.resolveTypesInScope(jSTypeStaticScope6);
        com.google.javascript.rhino.jstype.JSType jSType8 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray9 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList10 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean11 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList10, jSTypeArray9);
        com.google.javascript.rhino.jstype.FunctionType functionType12 = jSTypeRegistry5.createFunctionType(jSType8, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList10);
        com.google.javascript.rhino.JSDocInfo jSDocInfo14 = functionType12.getOwnPropertyJSDocInfo("");
        com.google.javascript.rhino.ErrorReporter errorReporter15 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry16 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter15);
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope17 = null;
        jSTypeRegistry16.resolveTypesInScope(jSTypeStaticScope17);
        com.google.javascript.rhino.jstype.JSType jSType19 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray20 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList21 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean22 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList21, jSTypeArray20);
        com.google.javascript.rhino.jstype.FunctionType functionType23 = jSTypeRegistry16.createFunctionType(jSType19, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList21);
        com.google.javascript.rhino.JSDocInfo jSDocInfo25 = functionType23.getOwnPropertyJSDocInfo("");
        com.google.javascript.rhino.jstype.ObjectType objectType26 = functionType23.getImplicitPrototype();
        boolean boolean27 = objectType26.hasCachedValues();
        com.google.javascript.rhino.ErrorReporter errorReporter28 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry29 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter28);
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope30 = null;
        jSTypeRegistry29.resolveTypesInScope(jSTypeStaticScope30);
        com.google.javascript.rhino.jstype.JSType jSType32 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray33 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList34 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean35 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList34, jSTypeArray33);
        com.google.javascript.rhino.jstype.FunctionType functionType36 = jSTypeRegistry29.createFunctionType(jSType32, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList34);
        com.google.javascript.rhino.JSDocInfo jSDocInfo38 = functionType36.getOwnPropertyJSDocInfo("");
        boolean boolean40 = functionType36.removeProperty(".  at hi! line (unknown line) : 0");
        com.google.javascript.rhino.ErrorReporter errorReporter41 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry42 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter41);
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope43 = null;
        jSTypeRegistry42.resolveTypesInScope(jSTypeStaticScope43);
        com.google.javascript.rhino.jstype.JSType jSType45 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray46 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList47 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean48 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList47, jSTypeArray46);
        com.google.javascript.rhino.jstype.FunctionType functionType49 = jSTypeRegistry42.createFunctionType(jSType45, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList47);
        com.google.javascript.rhino.ErrorReporter errorReporter50 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry51 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter50);
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope52 = null;
        jSTypeRegistry51.resolveTypesInScope(jSTypeStaticScope52);
        com.google.javascript.rhino.jstype.JSType jSType54 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray55 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList56 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean57 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList56, jSTypeArray55);
        com.google.javascript.rhino.jstype.FunctionType functionType58 = jSTypeRegistry51.createFunctionType(jSType54, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList56);
        com.google.javascript.rhino.JSDocInfo jSDocInfo60 = functionType58.getOwnPropertyJSDocInfo("");
        com.google.javascript.rhino.ErrorReporter errorReporter61 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry62 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter61);
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope63 = null;
        jSTypeRegistry62.resolveTypesInScope(jSTypeStaticScope63);
        com.google.javascript.rhino.jstype.JSType jSType65 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray66 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList67 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean68 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList67, jSTypeArray66);
        com.google.javascript.rhino.jstype.FunctionType functionType69 = jSTypeRegistry62.createFunctionType(jSType65, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList67);
        com.google.javascript.rhino.JSDocInfo jSDocInfo71 = functionType69.getOwnPropertyJSDocInfo("");
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray72 = new com.google.javascript.rhino.jstype.JSType[] { objectType26, functionType36, functionType49, functionType58, functionType69 };
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList73 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean74 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList73, jSTypeArray72);
        com.google.javascript.rhino.jstype.FunctionType functionType75 = jSTypeRegistry1.createFunctionTypeWithVarArgs((com.google.javascript.rhino.jstype.JSType) functionType12, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList73);
        boolean boolean76 = functionType12.isTemplateType();
        org.junit.Assert.assertNotNull(jSTypeArray9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(functionType12);
        org.junit.Assert.assertNull(jSDocInfo14);
        org.junit.Assert.assertNotNull(jSTypeArray20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(functionType23);
        org.junit.Assert.assertNull(jSDocInfo25);
        org.junit.Assert.assertNotNull(objectType26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(jSTypeArray33);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(functionType36);
        org.junit.Assert.assertNull(jSDocInfo38);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(jSTypeArray46);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(functionType49);
        org.junit.Assert.assertNotNull(jSTypeArray55);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertNotNull(functionType58);
        org.junit.Assert.assertNull(jSDocInfo60);
        org.junit.Assert.assertNotNull(jSTypeArray66);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertNotNull(functionType69);
        org.junit.Assert.assertNull(jSDocInfo71);
        org.junit.Assert.assertNotNull(jSTypeArray72);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + true + "'", boolean74 == true);
        org.junit.Assert.assertNotNull(functionType75);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry0 = null;
        com.google.javascript.rhino.jstype.FunctionBuilder functionBuilder1 = new com.google.javascript.rhino.jstype.FunctionBuilder(jSTypeRegistry0);
        com.google.javascript.rhino.jstype.FunctionBuilder functionBuilder3 = functionBuilder1.setIsConstructor(false);
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString((int) (short) -1, "");
        boolean boolean7 = node6.isThrow();
        com.google.javascript.rhino.Node node9 = new com.google.javascript.rhino.Node(10);
        com.google.javascript.rhino.Node node11 = new com.google.javascript.rhino.Node(10);
        boolean boolean12 = node9.isEquivalentToTyped(node11);
        boolean boolean13 = node9.isOnlyModifiesThisCall();
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.IR.throwNode(node9);
        com.google.javascript.rhino.Node node15 = node6.useSourceInfoIfMissingFrom(node9);
        com.google.javascript.rhino.jstype.FunctionBuilder functionBuilder16 = functionBuilder3.withSourceNode(node9);
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.IR.breakNode();
        com.google.javascript.rhino.jstype.FunctionBuilder functionBuilder18 = functionBuilder3.withParamsNode(node17);
        com.google.javascript.rhino.jstype.FunctionBuilder functionBuilder20 = functionBuilder18.withName("module$.  at hi! line (unknown line) : 0");
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry21 = null;
        com.google.javascript.rhino.jstype.FunctionParamBuilder functionParamBuilder22 = new com.google.javascript.rhino.jstype.FunctionParamBuilder(jSTypeRegistry21);
        com.google.javascript.rhino.Node node24 = new com.google.javascript.rhino.Node(10);
        com.google.javascript.rhino.Node node26 = new com.google.javascript.rhino.Node(10);
        boolean boolean27 = node24.isEquivalentToTyped(node26);
        java.lang.String str28 = node24.getQualifiedName();
        node24.setWasEmptyNode(false);
        com.google.javascript.rhino.Node node32 = new com.google.javascript.rhino.Node(10);
        com.google.javascript.rhino.Node node33 = com.google.javascript.rhino.IR.comma(node24, node32);
        com.google.javascript.rhino.Node node36 = new com.google.javascript.rhino.Node(10);
        com.google.javascript.rhino.Node node37 = node36.cloneTree();
        com.google.javascript.jscomp.DiagnosticType diagnosticType40 = com.google.javascript.jscomp.DiagnosticType.error("", "");
        com.google.javascript.jscomp.DiagnosticType diagnosticType46 = com.google.javascript.jscomp.DiagnosticType.error("", "");
        java.lang.String str47 = diagnosticType46.toString();
        java.lang.String[] strArray50 = new java.lang.String[] { "", "" };
        com.google.javascript.jscomp.JSError jSError51 = com.google.javascript.jscomp.JSError.make("hi!", (-1), 0, diagnosticType46, strArray50);
        com.google.javascript.jscomp.JSError jSError52 = com.google.javascript.jscomp.JSError.make("hi!", node36, diagnosticType40, strArray50);
        com.google.javascript.rhino.Node node54 = new com.google.javascript.rhino.Node(10);
        com.google.javascript.rhino.Node node56 = new com.google.javascript.rhino.Node(10);
        boolean boolean57 = node54.isEquivalentToTyped(node56);
        node36.addChildToFront(node54);
        boolean boolean59 = node54.isLabel();
        com.google.javascript.rhino.Node node60 = node33.srcref(node54);
        com.google.javascript.rhino.Node node61 = functionParamBuilder22.newOptionalParameterFromNode(node54);
        boolean boolean62 = functionParamBuilder22.hasVarArgs();
        com.google.javascript.rhino.jstype.FunctionBuilder functionBuilder63 = functionBuilder18.withParams(functionParamBuilder22);
        boolean boolean64 = functionParamBuilder22.hasVarArgs();
        org.junit.Assert.assertNotNull(functionBuilder3);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertNotNull(functionBuilder16);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(functionBuilder18);
        org.junit.Assert.assertNotNull(functionBuilder20);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertNull(str28);
        org.junit.Assert.assertNotNull(node33);
        org.junit.Assert.assertNotNull(node37);
        org.junit.Assert.assertNotNull(diagnosticType40);
        org.junit.Assert.assertNotNull(diagnosticType46);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + ": " + "'", str47.equals(": "));
        org.junit.Assert.assertNotNull(strArray50);
        org.junit.Assert.assertNotNull(jSError51);
        org.junit.Assert.assertNotNull(jSError52);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + true + "'", boolean57 == true);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertNotNull(node60);
        org.junit.Assert.assertNotNull(node61);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertNotNull(functionBuilder63);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.Node.newString((int) (short) -1, "");
        boolean boolean3 = node2.isObjectLit();
        com.google.javascript.rhino.Node node4 = node2.cloneTree();
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.IR.breakNode();
        boolean boolean6 = node5.isFor();
        com.google.javascript.rhino.Node node7 = node4.useSourceInfoIfMissingFromForTree(node5);
        node5.setSourceEncodedPositionForTree(32);
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(node7);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setCheckTypes(false);
        com.google.javascript.jscomp.CompilerOptions.LanguageMode languageMode3 = compilerOptions0.getLanguageOut();
        compilerOptions0.setInlineLocalVariables(false);
        compilerOptions0.setTightenTypes(true);
        java.util.Map<java.lang.String, com.google.javascript.rhino.Node> strMap8 = compilerOptions0.getDefineReplacements();
        boolean boolean9 = compilerOptions0.removeUnusedPrototypePropertiesInExterns;
        compilerOptions0.setConvertToDottedProperties(true);
        com.google.common.collect.Multimap<com.google.javascript.jscomp.CustomPassExecutionTime, com.google.javascript.jscomp.CompilerPass> customPassExecutionTimeMultimap12 = compilerOptions0.customPasses;
        org.junit.Assert.assertNull(languageMode3);
        org.junit.Assert.assertNotNull(strMap8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(customPassExecutionTimeMultimap12);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        jSTypeRegistry1.identifyNonNullableName("function (): ?");
        jSTypeRegistry1.clearNamedTypes();
        com.google.javascript.rhino.ErrorReporter errorReporter5 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry6 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter5);
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope7 = null;
        jSTypeRegistry6.resolveTypesInScope(jSTypeStaticScope7);
        com.google.javascript.rhino.ErrorReporter errorReporter9 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry10 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter9);
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope11 = null;
        jSTypeRegistry10.resolveTypesInScope(jSTypeStaticScope11);
        com.google.javascript.rhino.jstype.JSType jSType13 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray14 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList15 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean16 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList15, jSTypeArray14);
        com.google.javascript.rhino.jstype.FunctionType functionType17 = jSTypeRegistry10.createFunctionType(jSType13, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList15);
        com.google.javascript.rhino.JSDocInfo jSDocInfo19 = functionType17.getOwnPropertyJSDocInfo("");
        com.google.javascript.rhino.ErrorReporter errorReporter20 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry21 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter20);
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope22 = null;
        jSTypeRegistry21.resolveTypesInScope(jSTypeStaticScope22);
        com.google.javascript.rhino.jstype.JSType jSType24 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray25 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList26 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean27 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList26, jSTypeArray25);
        com.google.javascript.rhino.jstype.FunctionType functionType28 = jSTypeRegistry21.createFunctionType(jSType24, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList26);
        com.google.javascript.rhino.JSDocInfo jSDocInfo30 = functionType28.getOwnPropertyJSDocInfo("");
        com.google.javascript.rhino.jstype.ObjectType objectType31 = functionType28.getImplicitPrototype();
        boolean boolean32 = objectType31.hasCachedValues();
        com.google.javascript.rhino.ErrorReporter errorReporter33 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry34 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter33);
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope35 = null;
        jSTypeRegistry34.resolveTypesInScope(jSTypeStaticScope35);
        com.google.javascript.rhino.jstype.JSType jSType37 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray38 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList39 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean40 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList39, jSTypeArray38);
        com.google.javascript.rhino.jstype.FunctionType functionType41 = jSTypeRegistry34.createFunctionType(jSType37, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList39);
        com.google.javascript.rhino.JSDocInfo jSDocInfo43 = functionType41.getOwnPropertyJSDocInfo("");
        boolean boolean45 = functionType41.removeProperty(".  at hi! line (unknown line) : 0");
        com.google.javascript.rhino.ErrorReporter errorReporter46 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry47 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter46);
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope48 = null;
        jSTypeRegistry47.resolveTypesInScope(jSTypeStaticScope48);
        com.google.javascript.rhino.jstype.JSType jSType50 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray51 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList52 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean53 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList52, jSTypeArray51);
        com.google.javascript.rhino.jstype.FunctionType functionType54 = jSTypeRegistry47.createFunctionType(jSType50, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList52);
        com.google.javascript.rhino.ErrorReporter errorReporter55 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry56 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter55);
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope57 = null;
        jSTypeRegistry56.resolveTypesInScope(jSTypeStaticScope57);
        com.google.javascript.rhino.jstype.JSType jSType59 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray60 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList61 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean62 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList61, jSTypeArray60);
        com.google.javascript.rhino.jstype.FunctionType functionType63 = jSTypeRegistry56.createFunctionType(jSType59, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList61);
        com.google.javascript.rhino.JSDocInfo jSDocInfo65 = functionType63.getOwnPropertyJSDocInfo("");
        com.google.javascript.rhino.ErrorReporter errorReporter66 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry67 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter66);
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope68 = null;
        jSTypeRegistry67.resolveTypesInScope(jSTypeStaticScope68);
        com.google.javascript.rhino.jstype.JSType jSType70 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray71 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList72 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean73 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList72, jSTypeArray71);
        com.google.javascript.rhino.jstype.FunctionType functionType74 = jSTypeRegistry67.createFunctionType(jSType70, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList72);
        com.google.javascript.rhino.JSDocInfo jSDocInfo76 = functionType74.getOwnPropertyJSDocInfo("");
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray77 = new com.google.javascript.rhino.jstype.JSType[] { objectType31, functionType41, functionType54, functionType63, functionType74 };
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList78 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean79 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList78, jSTypeArray77);
        com.google.javascript.rhino.jstype.FunctionType functionType80 = jSTypeRegistry6.createFunctionTypeWithVarArgs((com.google.javascript.rhino.jstype.JSType) functionType17, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList78);
        boolean boolean82 = jSTypeRegistry1.canPropertyBeDefined((com.google.javascript.rhino.jstype.JSType) functionType80, "BITXOR");
        com.google.javascript.rhino.jstype.EnumElementType enumElementType83 = functionType80.toMaybeEnumElementType();
        org.junit.Assert.assertNotNull(jSTypeArray14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(functionType17);
        org.junit.Assert.assertNull(jSDocInfo19);
        org.junit.Assert.assertNotNull(jSTypeArray25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(functionType28);
        org.junit.Assert.assertNull(jSDocInfo30);
        org.junit.Assert.assertNotNull(objectType31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(jSTypeArray38);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(functionType41);
        org.junit.Assert.assertNull(jSDocInfo43);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(jSTypeArray51);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNotNull(functionType54);
        org.junit.Assert.assertNotNull(jSTypeArray60);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertNotNull(functionType63);
        org.junit.Assert.assertNull(jSDocInfo65);
        org.junit.Assert.assertNotNull(jSTypeArray71);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
        org.junit.Assert.assertNotNull(functionType74);
        org.junit.Assert.assertNull(jSDocInfo76);
        org.junit.Assert.assertNotNull(jSTypeArray77);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + true + "'", boolean79 == true);
        org.junit.Assert.assertNotNull(functionType80);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
        org.junit.Assert.assertNull(enumElementType83);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.empty();
        com.google.javascript.jscomp.SourceFile sourceFile3 = com.google.javascript.jscomp.SourceFile.fromCode("hi!", "module$DiagnosticGroup<checkRegExp>");
        node0.setStaticSourceFile((com.google.javascript.rhino.jstype.StaticSourceFile) sourceFile3);
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertNotNull(sourceFile3);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.exportTestFunctions;
        com.google.javascript.jscomp.AnonymousFunctionNamingPolicy anonymousFunctionNamingPolicy2 = compilerOptions0.anonymousFunctionNaming;
        boolean boolean3 = compilerOptions0.closurePass;
        com.google.javascript.jscomp.CheckLevel checkLevel4 = com.google.javascript.jscomp.CheckLevel.ERROR;
        compilerOptions0.reportMissingOverride = checkLevel4;
        compilerOptions0.setTweakToBooleanLiteral("Not declared as a constructor", true);
        compilerOptions0.setInlineLocalFunctions(true);
        compilerOptions0.renamePrefixNamespace = "";
        compilerOptions0.jqueryPass = true;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + anonymousFunctionNamingPolicy2 + "' != '" + com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF + "'", anonymousFunctionNamingPolicy2.equals(com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + checkLevel4 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel4.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope2 = null;
        jSTypeRegistry1.resolveTypesInScope(jSTypeStaticScope2);
        com.google.javascript.rhino.jstype.JSType jSType4 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray5 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList6 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean7 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList6, jSTypeArray5);
        com.google.javascript.rhino.jstype.FunctionType functionType8 = jSTypeRegistry1.createFunctionType(jSType4, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList6);
        com.google.javascript.rhino.ErrorReporter errorReporter9 = jSTypeRegistry1.getErrorReporter();
        jSTypeRegistry1.resetForTypeCheck();
        com.google.javascript.rhino.ErrorReporter errorReporter11 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry12 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter11);
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope13 = null;
        jSTypeRegistry12.resolveTypesInScope(jSTypeStaticScope13);
        com.google.javascript.rhino.jstype.ObjectType objectType15 = null;
        com.google.javascript.rhino.ErrorReporter errorReporter16 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry17 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter16);
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope18 = null;
        jSTypeRegistry17.resolveTypesInScope(jSTypeStaticScope18);
        com.google.javascript.rhino.jstype.JSType jSType20 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray21 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList22 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean23 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList22, jSTypeArray21);
        com.google.javascript.rhino.jstype.FunctionType functionType24 = jSTypeRegistry17.createFunctionType(jSType20, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList22);
        com.google.javascript.rhino.JSDocInfo jSDocInfo26 = functionType24.getOwnPropertyJSDocInfo("");
        com.google.javascript.rhino.jstype.ObjectType objectType27 = functionType24.getImplicitPrototype();
        int int28 = functionType24.getMinArguments();
        com.google.javascript.rhino.JSDocInfo jSDocInfo29 = functionType24.getJSDocInfo();
        com.google.javascript.rhino.ErrorReporter errorReporter30 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry31 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter30);
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope32 = null;
        jSTypeRegistry31.resolveTypesInScope(jSTypeStaticScope32);
        com.google.javascript.rhino.jstype.JSType jSType34 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray35 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList36 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean37 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList36, jSTypeArray35);
        com.google.javascript.rhino.jstype.FunctionType functionType38 = jSTypeRegistry31.createFunctionType(jSType34, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList36);
        com.google.javascript.rhino.jstype.JSType jSType39 = jSTypeRegistry12.createFunctionType(objectType15, (com.google.javascript.rhino.jstype.JSType) functionType24, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList36);
        com.google.javascript.rhino.Node node40 = jSTypeRegistry1.createParameters((java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList36);
        org.junit.Assert.assertNotNull(jSTypeArray5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(functionType8);
        org.junit.Assert.assertNull(errorReporter9);
        org.junit.Assert.assertNotNull(jSTypeArray21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(functionType24);
        org.junit.Assert.assertNull(jSDocInfo26);
        org.junit.Assert.assertNotNull(objectType27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertNull(jSDocInfo29);
        org.junit.Assert.assertNotNull(jSTypeArray35);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(functionType38);
        org.junit.Assert.assertNotNull(jSType39);
        org.junit.Assert.assertNotNull(node40);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        com.google.javascript.rhino.JSDocInfo jSDocInfo0 = new com.google.javascript.rhino.JSDocInfo();
        boolean boolean1 = jSDocInfo0.containsDeclaration();
        java.lang.String str2 = jSDocInfo0.getSourceName();
        java.lang.String str3 = jSDocInfo0.getSourceName();
        boolean boolean4 = jSDocInfo0.isConstant();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.exportTestFunctions;
        com.google.javascript.jscomp.AnonymousFunctionNamingPolicy anonymousFunctionNamingPolicy2 = compilerOptions0.anonymousFunctionNaming;
        boolean boolean3 = compilerOptions0.closurePass;
        com.google.javascript.jscomp.CheckLevel checkLevel4 = com.google.javascript.jscomp.CheckLevel.ERROR;
        compilerOptions0.reportMissingOverride = checkLevel4;
        compilerOptions0.setTweakToBooleanLiteral("Not declared as a constructor", true);
        compilerOptions0.setInlineLocalFunctions(true);
        compilerOptions0.renamePrefixNamespace = "";
        compilerOptions0.collapseAnonymousFunctions = true;
        boolean boolean15 = compilerOptions0.isRemoveUnusedClassProperties();
        boolean boolean16 = compilerOptions0.exportTestFunctions;
        boolean boolean17 = compilerOptions0.generateExports;
        com.google.javascript.jscomp.CheckLevel checkLevel18 = compilerOptions0.aggressiveVarCheck;
        compilerOptions0.setLineBreak(true);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + anonymousFunctionNamingPolicy2 + "' != '" + com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF + "'", anonymousFunctionNamingPolicy2.equals(com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + checkLevel4 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel4.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + checkLevel18 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel18.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        com.google.javascript.rhino.Node node1 = new com.google.javascript.rhino.Node(10);
        com.google.javascript.rhino.Node node3 = new com.google.javascript.rhino.Node(10);
        boolean boolean4 = node1.isEquivalentToTyped(node3);
        try {
            com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.IR.breakNode(node1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.exportTestFunctions;
        com.google.javascript.jscomp.AnonymousFunctionNamingPolicy anonymousFunctionNamingPolicy2 = compilerOptions0.anonymousFunctionNaming;
        boolean boolean3 = compilerOptions0.closurePass;
        com.google.javascript.jscomp.CheckLevel checkLevel4 = com.google.javascript.jscomp.CheckLevel.ERROR;
        compilerOptions0.reportMissingOverride = checkLevel4;
        compilerOptions0.setTweakToBooleanLiteral("Not declared as a constructor", true);
        compilerOptions0.setInlineLocalFunctions(true);
        compilerOptions0.renamePrefixNamespace = "";
        compilerOptions0.collapseAnonymousFunctions = true;
        boolean boolean15 = compilerOptions0.isRemoveUnusedClassProperties();
        boolean boolean16 = compilerOptions0.exportTestFunctions;
        compilerOptions0.setInlineProperties(false);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + anonymousFunctionNamingPolicy2 + "' != '" + com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF + "'", anonymousFunctionNamingPolicy2.equals(com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + checkLevel4 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel4.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope2 = null;
        jSTypeRegistry1.resolveTypesInScope(jSTypeStaticScope2);
        com.google.javascript.rhino.jstype.JSType jSType4 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray5 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList6 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean7 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList6, jSTypeArray5);
        com.google.javascript.rhino.jstype.FunctionType functionType8 = jSTypeRegistry1.createFunctionType(jSType4, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList6);
        com.google.javascript.rhino.JSDocInfo jSDocInfo10 = functionType8.getOwnPropertyJSDocInfo("");
        java.lang.Iterable iterable11 = functionType8.getCtorExtendedInterfaces();
        com.google.javascript.rhino.jstype.EnumType enumType12 = functionType8.toMaybeEnumType();
        com.google.javascript.rhino.ErrorReporter errorReporter13 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry14 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter13);
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope15 = null;
        jSTypeRegistry14.resolveTypesInScope(jSTypeStaticScope15);
        com.google.javascript.rhino.jstype.JSType jSType17 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray18 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList19 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean20 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList19, jSTypeArray18);
        com.google.javascript.rhino.jstype.FunctionType functionType21 = jSTypeRegistry14.createFunctionType(jSType17, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList19);
        boolean boolean22 = functionType21.hasInstanceType();
        int int23 = functionType21.getMinArguments();
        com.google.javascript.rhino.jstype.JSType jSType24 = functionType8.getLeastSupertype((com.google.javascript.rhino.jstype.JSType) functionType21);
        org.junit.Assert.assertNotNull(jSTypeArray5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(functionType8);
        org.junit.Assert.assertNull(jSDocInfo10);
        org.junit.Assert.assertNotNull(iterable11);
        org.junit.Assert.assertNull(enumType12);
        org.junit.Assert.assertNotNull(jSTypeArray18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(functionType21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertNotNull(jSType24);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        com.google.javascript.rhino.JSDocInfo jSDocInfo0 = new com.google.javascript.rhino.JSDocInfo();
        boolean boolean1 = jSDocInfo0.isNoShadow();
        boolean boolean2 = jSDocInfo0.hasType();
        boolean boolean3 = jSDocInfo0.hasBaseType();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.exportTestFunctions = false;
        boolean boolean3 = compilerOptions0.coalesceVariableNames;
        compilerOptions0.setCheckCaja(true);
        compilerOptions0.optimizeParameters = true;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.exportTestFunctions;
        com.google.javascript.jscomp.AnonymousFunctionNamingPolicy anonymousFunctionNamingPolicy2 = compilerOptions0.anonymousFunctionNaming;
        boolean boolean3 = compilerOptions0.closurePass;
        com.google.javascript.jscomp.CheckLevel checkLevel4 = com.google.javascript.jscomp.CheckLevel.ERROR;
        compilerOptions0.reportMissingOverride = checkLevel4;
        compilerOptions0.setTweakToBooleanLiteral("Not declared as a constructor", true);
        compilerOptions0.setInlineLocalFunctions(true);
        compilerOptions0.renamePrefixNamespace = "";
        compilerOptions0.collapseAnonymousFunctions = true;
        boolean boolean15 = compilerOptions0.isRemoveUnusedClassProperties();
        boolean boolean16 = compilerOptions0.exportTestFunctions;
        boolean boolean17 = compilerOptions0.generateExports;
        com.google.javascript.jscomp.CheckLevel checkLevel18 = compilerOptions0.aggressiveVarCheck;
        compilerOptions0.inlineVariables = true;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + anonymousFunctionNamingPolicy2 + "' != '" + com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF + "'", anonymousFunctionNamingPolicy2.equals(com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + checkLevel4 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel4.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + checkLevel18 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel18.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        com.google.javascript.jscomp.CodingConvention codingConvention0 = com.google.javascript.jscomp.CodingConventions.getDefault();
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention1 = new com.google.javascript.jscomp.ClosureCodingConvention(codingConvention0);
        com.google.javascript.rhino.Node node2 = null;
        boolean boolean3 = closureCodingConvention1.isVarArgsParameter(node2);
        java.lang.String str4 = closureCodingConvention1.getExportPropertyFunction();
        boolean boolean6 = closureCodingConvention1.isPrivate("./");
        org.junit.Assert.assertNotNull(codingConvention0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "goog.exportProperty" + "'", str4.equals("goog.exportProperty"));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        com.google.javascript.jscomp.CodingConvention codingConvention0 = null;
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention1 = new com.google.javascript.jscomp.GoogleCodingConvention(codingConvention0);
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention2 = new com.google.javascript.jscomp.GoogleCodingConvention((com.google.javascript.jscomp.CodingConvention) googleCodingConvention1);
        boolean boolean4 = googleCodingConvention1.isValidEnumKey("hi!");
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention5 = new com.google.javascript.jscomp.GoogleCodingConvention((com.google.javascript.jscomp.CodingConvention) googleCodingConvention1);
        boolean boolean7 = googleCodingConvention1.isConstantKey(".  at hi! line (unknown line) : 0");
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.Node.newString((int) (short) -1, "");
        boolean boolean3 = node2.isThrow();
        com.google.javascript.rhino.Node node5 = new com.google.javascript.rhino.Node(10);
        com.google.javascript.rhino.Node node7 = new com.google.javascript.rhino.Node(10);
        boolean boolean8 = node5.isEquivalentToTyped(node7);
        boolean boolean9 = node5.isOnlyModifiesThisCall();
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.IR.throwNode(node5);
        com.google.javascript.rhino.Node node11 = node2.useSourceInfoIfMissingFrom(node5);
        boolean boolean12 = node5.isInc();
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setDeadAssignmentElimination(false);
        compilerOptions0.ideMode = true;
        boolean boolean5 = compilerOptions0.ambiguateProperties;
        boolean boolean6 = compilerOptions0.prettyPrint;
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope2 = null;
        jSTypeRegistry1.resolveTypesInScope(jSTypeStaticScope2);
        com.google.javascript.rhino.jstype.JSType jSType4 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray5 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList6 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean7 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList6, jSTypeArray5);
        com.google.javascript.rhino.jstype.FunctionType functionType8 = jSTypeRegistry1.createFunctionType(jSType4, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList6);
        jSTypeRegistry1.identifyNonNullableName("DependencyInfo(relativePath='./', path=': ', provides=[DiagnosticGroup<checkRegExp>, : , , , hi!, .  at hi! line (unknown line) : 0], requires=[./])");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative11 = com.google.javascript.rhino.jstype.JSTypeNative.STRING_TYPE;
        try {
            com.google.javascript.rhino.jstype.FunctionType functionType12 = jSTypeRegistry1.getNativeFunctionType(jSTypeNative11);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: com.google.javascript.rhino.jstype.StringType cannot be cast to com.google.javascript.rhino.jstype.FunctionType");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(jSTypeArray5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(functionType8);
        org.junit.Assert.assertTrue("'" + jSTypeNative11 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.STRING_TYPE + "'", jSTypeNative11.equals(com.google.javascript.rhino.jstype.JSTypeNative.STRING_TYPE));
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        com.google.javascript.jscomp.AbstractCompiler abstractCompiler0 = null;
        com.google.javascript.jscomp.NodeTraversal.Callback callback1 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal2 = new com.google.javascript.jscomp.NodeTraversal(abstractCompiler0, callback1);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.Node.newString((int) (short) -1, "");
        boolean boolean3 = node2.isObjectLit();
        com.google.javascript.rhino.Node node4 = node2.cloneTree();
        java.lang.String str5 = node2.toString();
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "ERROR " + "'", str5.equals("ERROR "));
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setCheckTypes(false);
        com.google.javascript.jscomp.CompilerOptions.LanguageMode languageMode3 = compilerOptions0.getLanguageOut();
        compilerOptions0.setInlineLocalVariables(false);
        compilerOptions0.setTightenTypes(true);
        java.util.Map<java.lang.String, com.google.javascript.rhino.Node> strMap8 = compilerOptions0.getDefineReplacements();
        compilerOptions0.setInlineLocalVariables(false);
        boolean boolean11 = compilerOptions0.smartNameRemoval;
        java.util.Set<java.lang.String> strSet12 = compilerOptions0.stripTypePrefixes;
        compilerOptions0.collapseProperties = false;
        org.junit.Assert.assertNull(languageMode3);
        org.junit.Assert.assertNotNull(strMap8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(strSet12);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        com.google.javascript.jscomp.CodingConvention codingConvention0 = com.google.javascript.jscomp.CodingConventions.getDefault();
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention1 = new com.google.javascript.jscomp.ClosureCodingConvention(codingConvention0);
        com.google.javascript.rhino.Node node2 = null;
        boolean boolean3 = closureCodingConvention1.isVarArgsParameter(node2);
        com.google.javascript.rhino.Node node6 = new com.google.javascript.rhino.Node(10);
        com.google.javascript.rhino.Node node7 = node6.cloneTree();
        com.google.javascript.jscomp.DiagnosticType diagnosticType10 = com.google.javascript.jscomp.DiagnosticType.error("", "");
        com.google.javascript.jscomp.DiagnosticType diagnosticType16 = com.google.javascript.jscomp.DiagnosticType.error("", "");
        java.lang.String str17 = diagnosticType16.toString();
        java.lang.String[] strArray20 = new java.lang.String[] { "", "" };
        com.google.javascript.jscomp.JSError jSError21 = com.google.javascript.jscomp.JSError.make("hi!", (-1), 0, diagnosticType16, strArray20);
        com.google.javascript.jscomp.JSError jSError22 = com.google.javascript.jscomp.JSError.make("hi!", node6, diagnosticType10, strArray20);
        com.google.javascript.rhino.Node node24 = new com.google.javascript.rhino.Node(10);
        com.google.javascript.rhino.Node node26 = new com.google.javascript.rhino.Node(10);
        boolean boolean27 = node24.isEquivalentToTyped(node26);
        node6.addChildToFront(node24);
        boolean boolean29 = node24.isLabel();
        java.lang.String str30 = com.google.javascript.jscomp.NodeUtil.getNearestFunctionName(node24);
        boolean boolean31 = closureCodingConvention1.isVarArgsParameter(node24);
        com.google.javascript.jscomp.Compiler compiler32 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.Region region35 = compiler32.getSourceRegion(": ", (int) (byte) -1);
        com.google.javascript.jscomp.Scope scope36 = compiler32.getTopScope();
        java.nio.charset.Charset charset38 = null;
        com.google.javascript.jscomp.SourceFile sourceFile39 = com.google.javascript.jscomp.SourceFile.fromFile(": ", charset38);
        java.lang.String str40 = sourceFile39.getOriginalPath();
        com.google.javascript.rhino.Node node41 = compiler32.parse(sourceFile39);
        boolean boolean42 = node41.isIn();
        com.google.javascript.jscomp.CodingConvention.Bind bind43 = closureCodingConvention1.describeFunctionBind(node41);
        org.junit.Assert.assertNotNull(codingConvention0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertNotNull(diagnosticType10);
        org.junit.Assert.assertNotNull(diagnosticType16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + ": " + "'", str17.equals(": "));
        org.junit.Assert.assertNotNull(strArray20);
        org.junit.Assert.assertNotNull(jSError21);
        org.junit.Assert.assertNotNull(jSError22);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNull(str30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNull(region35);
        org.junit.Assert.assertNull(scope36);
        org.junit.Assert.assertNotNull(sourceFile39);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + ": " + "'", str40.equals(": "));
        org.junit.Assert.assertNotNull(node41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNull(bind43);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope2 = null;
        jSTypeRegistry1.resolveTypesInScope(jSTypeStaticScope2);
        com.google.javascript.rhino.jstype.JSType jSType4 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray5 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList6 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean7 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList6, jSTypeArray5);
        com.google.javascript.rhino.jstype.FunctionType functionType8 = jSTypeRegistry1.createFunctionType(jSType4, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList6);
        com.google.javascript.rhino.JSDocInfo jSDocInfo10 = functionType8.getOwnPropertyJSDocInfo("");
        com.google.javascript.rhino.JSDocInfo jSDocInfo11 = functionType8.getJSDocInfo();
        boolean boolean12 = functionType8.isNullable();
        com.google.javascript.rhino.ErrorReporter errorReporter14 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry15 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter14);
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope16 = null;
        jSTypeRegistry15.resolveTypesInScope(jSTypeStaticScope16);
        com.google.javascript.rhino.jstype.JSType jSType18 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray19 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList20 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean21 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList20, jSTypeArray19);
        com.google.javascript.rhino.jstype.FunctionType functionType22 = jSTypeRegistry15.createFunctionType(jSType18, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList20);
        boolean boolean23 = functionType22.hasInstanceType();
        boolean boolean24 = functionType22.isNominalConstructor();
        com.google.javascript.rhino.Node node27 = new com.google.javascript.rhino.Node(10);
        com.google.javascript.rhino.Node node28 = node27.cloneTree();
        com.google.javascript.jscomp.DiagnosticType diagnosticType31 = com.google.javascript.jscomp.DiagnosticType.error("", "");
        com.google.javascript.jscomp.DiagnosticType diagnosticType37 = com.google.javascript.jscomp.DiagnosticType.error("", "");
        java.lang.String str38 = diagnosticType37.toString();
        java.lang.String[] strArray41 = new java.lang.String[] { "", "" };
        com.google.javascript.jscomp.JSError jSError42 = com.google.javascript.jscomp.JSError.make("hi!", (-1), 0, diagnosticType37, strArray41);
        com.google.javascript.jscomp.JSError jSError43 = com.google.javascript.jscomp.JSError.make("hi!", node27, diagnosticType31, strArray41);
        boolean boolean44 = node27.isArrayLit();
        com.google.javascript.rhino.Node node45 = node27.removeFirstChild();
        boolean boolean46 = functionType8.defineDeclaredProperty("function (): ?", (com.google.javascript.rhino.jstype.JSType) functionType22, node45);
        boolean boolean47 = functionType22.isBooleanObjectType();
        org.junit.Assert.assertNotNull(jSTypeArray5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(functionType8);
        org.junit.Assert.assertNull(jSDocInfo10);
        org.junit.Assert.assertNull(jSDocInfo11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(jSTypeArray19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(functionType22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertNotNull(diagnosticType31);
        org.junit.Assert.assertNotNull(diagnosticType37);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + ": " + "'", str38.equals(": "));
        org.junit.Assert.assertNotNull(strArray41);
        org.junit.Assert.assertNotNull(jSError42);
        org.junit.Assert.assertNotNull(jSError43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNull(node45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.EXTERNS_VALIDATION;
        com.google.javascript.jscomp.DiagnosticGroups.CHECK_TYPES = diagnosticGroup0;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

//    @Test
//    public void test138() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test138");
//        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
//        jSTypeRegistry1.identifyNonNullableName("");
//        com.google.javascript.rhino.ErrorReporter errorReporter4 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter4);
//        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope6 = null;
//        jSTypeRegistry5.resolveTypesInScope(jSTypeStaticScope6);
//        com.google.javascript.rhino.jstype.JSType jSType8 = null;
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray9 = new com.google.javascript.rhino.jstype.JSType[] {};
//        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList10 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
//        boolean boolean11 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList10, jSTypeArray9);
//        com.google.javascript.rhino.jstype.FunctionType functionType12 = jSTypeRegistry5.createFunctionType(jSType8, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList10);
//        com.google.javascript.rhino.ErrorReporter errorReporter14 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry15 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter14);
//        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope16 = null;
//        jSTypeRegistry15.resolveTypesInScope(jSTypeStaticScope16);
//        com.google.javascript.rhino.ErrorReporter errorReporter18 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry19 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter18);
//        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope20 = null;
//        jSTypeRegistry19.resolveTypesInScope(jSTypeStaticScope20);
//        com.google.javascript.rhino.jstype.JSType jSType22 = null;
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray23 = new com.google.javascript.rhino.jstype.JSType[] {};
//        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList24 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
//        boolean boolean25 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList24, jSTypeArray23);
//        com.google.javascript.rhino.jstype.FunctionType functionType26 = jSTypeRegistry19.createFunctionType(jSType22, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList24);
//        com.google.javascript.rhino.JSDocInfo jSDocInfo28 = functionType26.getOwnPropertyJSDocInfo("");
//        com.google.javascript.rhino.ErrorReporter errorReporter29 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry30 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter29);
//        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope31 = null;
//        jSTypeRegistry30.resolveTypesInScope(jSTypeStaticScope31);
//        com.google.javascript.rhino.jstype.JSType jSType33 = null;
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray34 = new com.google.javascript.rhino.jstype.JSType[] {};
//        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList35 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
//        boolean boolean36 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList35, jSTypeArray34);
//        com.google.javascript.rhino.jstype.FunctionType functionType37 = jSTypeRegistry30.createFunctionType(jSType33, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList35);
//        com.google.javascript.rhino.JSDocInfo jSDocInfo39 = functionType37.getOwnPropertyJSDocInfo("");
//        com.google.javascript.rhino.jstype.ObjectType objectType40 = functionType37.getImplicitPrototype();
//        boolean boolean41 = objectType40.hasCachedValues();
//        com.google.javascript.rhino.ErrorReporter errorReporter42 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry43 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter42);
//        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope44 = null;
//        jSTypeRegistry43.resolveTypesInScope(jSTypeStaticScope44);
//        com.google.javascript.rhino.jstype.JSType jSType46 = null;
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray47 = new com.google.javascript.rhino.jstype.JSType[] {};
//        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList48 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
//        boolean boolean49 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList48, jSTypeArray47);
//        com.google.javascript.rhino.jstype.FunctionType functionType50 = jSTypeRegistry43.createFunctionType(jSType46, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList48);
//        com.google.javascript.rhino.JSDocInfo jSDocInfo52 = functionType50.getOwnPropertyJSDocInfo("");
//        boolean boolean54 = functionType50.removeProperty(".  at hi! line (unknown line) : 0");
//        com.google.javascript.rhino.ErrorReporter errorReporter55 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry56 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter55);
//        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope57 = null;
//        jSTypeRegistry56.resolveTypesInScope(jSTypeStaticScope57);
//        com.google.javascript.rhino.jstype.JSType jSType59 = null;
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray60 = new com.google.javascript.rhino.jstype.JSType[] {};
//        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList61 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
//        boolean boolean62 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList61, jSTypeArray60);
//        com.google.javascript.rhino.jstype.FunctionType functionType63 = jSTypeRegistry56.createFunctionType(jSType59, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList61);
//        com.google.javascript.rhino.ErrorReporter errorReporter64 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry65 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter64);
//        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope66 = null;
//        jSTypeRegistry65.resolveTypesInScope(jSTypeStaticScope66);
//        com.google.javascript.rhino.jstype.JSType jSType68 = null;
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray69 = new com.google.javascript.rhino.jstype.JSType[] {};
//        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList70 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
//        boolean boolean71 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList70, jSTypeArray69);
//        com.google.javascript.rhino.jstype.FunctionType functionType72 = jSTypeRegistry65.createFunctionType(jSType68, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList70);
//        com.google.javascript.rhino.JSDocInfo jSDocInfo74 = functionType72.getOwnPropertyJSDocInfo("");
//        com.google.javascript.rhino.ErrorReporter errorReporter75 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry76 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter75);
//        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope77 = null;
//        jSTypeRegistry76.resolveTypesInScope(jSTypeStaticScope77);
//        com.google.javascript.rhino.jstype.JSType jSType79 = null;
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray80 = new com.google.javascript.rhino.jstype.JSType[] {};
//        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList81 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
//        boolean boolean82 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList81, jSTypeArray80);
//        com.google.javascript.rhino.jstype.FunctionType functionType83 = jSTypeRegistry76.createFunctionType(jSType79, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList81);
//        com.google.javascript.rhino.JSDocInfo jSDocInfo85 = functionType83.getOwnPropertyJSDocInfo("");
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray86 = new com.google.javascript.rhino.jstype.JSType[] { objectType40, functionType50, functionType63, functionType72, functionType83 };
//        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList87 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
//        boolean boolean88 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList87, jSTypeArray86);
//        com.google.javascript.rhino.jstype.FunctionType functionType89 = jSTypeRegistry15.createFunctionTypeWithVarArgs((com.google.javascript.rhino.jstype.JSType) functionType26, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList87);
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray90 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.Node node91 = jSTypeRegistry15.createParameters(jSTypeArray90);
//        com.google.javascript.rhino.jstype.FunctionType functionType92 = jSTypeRegistry1.createConstructorType(jSType8, false, jSTypeArray90);
//        com.google.javascript.rhino.jstype.FunctionType functionType93 = functionType92.getSuperClassConstructor();
//        boolean boolean94 = functionType92.isNullable();
//        java.lang.String str95 = functionType92.toDebugHashCodeString();
//        org.junit.Assert.assertNotNull(jSTypeArray9);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertNotNull(functionType12);
//        org.junit.Assert.assertNotNull(jSTypeArray23);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertNotNull(functionType26);
//        org.junit.Assert.assertNull(jSDocInfo28);
//        org.junit.Assert.assertNotNull(jSTypeArray34);
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
//        org.junit.Assert.assertNotNull(functionType37);
//        org.junit.Assert.assertNull(jSDocInfo39);
//        org.junit.Assert.assertNotNull(objectType40);
//        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
//        org.junit.Assert.assertNotNull(jSTypeArray47);
//        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
//        org.junit.Assert.assertNotNull(functionType50);
//        org.junit.Assert.assertNull(jSDocInfo52);
//        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
//        org.junit.Assert.assertNotNull(jSTypeArray60);
//        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
//        org.junit.Assert.assertNotNull(functionType63);
//        org.junit.Assert.assertNotNull(jSTypeArray69);
//        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
//        org.junit.Assert.assertNotNull(functionType72);
//        org.junit.Assert.assertNull(jSDocInfo74);
//        org.junit.Assert.assertNotNull(jSTypeArray80);
//        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
//        org.junit.Assert.assertNotNull(functionType83);
//        org.junit.Assert.assertNull(jSDocInfo85);
//        org.junit.Assert.assertNotNull(jSTypeArray86);
//        org.junit.Assert.assertTrue("'" + boolean88 + "' != '" + true + "'", boolean88 == true);
//        org.junit.Assert.assertNotNull(functionType89);
//        org.junit.Assert.assertNotNull(jSTypeArray90);
//        org.junit.Assert.assertNotNull(node91);
//        org.junit.Assert.assertNotNull(functionType92);
//        org.junit.Assert.assertNull(functionType93);
//        org.junit.Assert.assertTrue("'" + boolean94 + "' != '" + false + "'", boolean94 == false);
//        org.junit.Assert.assertTrue("'" + str95 + "' != '" + "function (): {804251133}" + "'", str95.equals("function (): {804251133}"));
//    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        com.google.javascript.jscomp.ErrorFormat errorFormat0 = com.google.javascript.jscomp.ErrorFormat.SINGLELINE;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.MessageFormatter messageFormatter2 = null;
        java.util.logging.Logger logger3 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager4 = new com.google.javascript.jscomp.LoggerErrorManager(messageFormatter2, logger3);
        compiler1.setErrorManager((com.google.javascript.jscomp.ErrorManager) loggerErrorManager4);
        com.google.javascript.jscomp.Compiler compiler6 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager4);
        com.google.javascript.jscomp.MessageFormatter messageFormatter8 = errorFormat0.toFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler6, true);
        com.google.javascript.jscomp.Compiler compiler9 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.MessageFormatter messageFormatter10 = null;
        java.util.logging.Logger logger11 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager12 = new com.google.javascript.jscomp.LoggerErrorManager(messageFormatter10, logger11);
        compiler9.setErrorManager((com.google.javascript.jscomp.ErrorManager) loggerErrorManager12);
        com.google.javascript.jscomp.ErrorManager errorManager14 = compiler9.getErrorManager();
        double double15 = compiler9.getProgress();
        com.google.javascript.jscomp.JSError[] jSErrorArray16 = compiler9.getMessages();
        com.google.javascript.jscomp.MessageFormatter messageFormatter18 = errorFormat0.toFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler9, true);
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray19 = new com.google.javascript.jscomp.JSSourceFile[] {};
        com.google.javascript.jscomp.JSSourceFile jSSourceFile20 = null;
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray21 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile20 };
        com.google.javascript.jscomp.CompilerOptions compilerOptions22 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.MessageBundle messageBundle23 = compilerOptions22.messageBundle;
        try {
            com.google.javascript.jscomp.Result result24 = compiler9.compile(jSSourceFileArray19, jSSourceFileArray21, compilerOptions22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(errorFormat0);
        org.junit.Assert.assertNotNull(messageFormatter8);
        org.junit.Assert.assertNotNull(errorManager14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertNotNull(jSErrorArray16);
        org.junit.Assert.assertNotNull(messageFormatter18);
        org.junit.Assert.assertNotNull(jSSourceFileArray19);
        org.junit.Assert.assertNotNull(jSSourceFileArray21);
        org.junit.Assert.assertNull(messageBundle23);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        com.google.javascript.rhino.Node node1 = new com.google.javascript.rhino.Node(10);
        com.google.javascript.rhino.Node node3 = new com.google.javascript.rhino.Node(10);
        boolean boolean4 = node1.isEquivalentToTyped(node3);
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.IR.exprResult(node3);
        com.google.javascript.rhino.Node node6 = node3.cloneNode();
        boolean boolean7 = node3.hasOneChild();
        com.google.javascript.rhino.Node node8 = node3.cloneTree();
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder9 = node8.new FileLevelJsDocBuilder();
        fileLevelJsDocBuilder9.append("function (): ?");
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(node8);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setReplaceIdGenerators(false);
        compilerOptions0.setTransformAMDToCJSModules(false);
        compilerOptions0.setOptimizeReturns(false);
        compilerOptions0.setGroupVariableDeclarations(true);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.exportTestFunctions;
        com.google.javascript.jscomp.AnonymousFunctionNamingPolicy anonymousFunctionNamingPolicy2 = compilerOptions0.anonymousFunctionNaming;
        boolean boolean3 = compilerOptions0.closurePass;
        com.google.javascript.jscomp.CheckLevel checkLevel4 = com.google.javascript.jscomp.CheckLevel.ERROR;
        compilerOptions0.reportMissingOverride = checkLevel4;
        compilerOptions0.setTweakToBooleanLiteral("Not declared as a constructor", true);
        compilerOptions0.setInlineLocalFunctions(true);
        compilerOptions0.renamePrefixNamespace = "";
        boolean boolean13 = compilerOptions0.assumeClosuresOnlyCaptureReferences();
        compilerOptions0.moveFunctionDeclarations = false;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + anonymousFunctionNamingPolicy2 + "' != '" + com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF + "'", anonymousFunctionNamingPolicy2.equals(com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + checkLevel4 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel4.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        com.google.javascript.jscomp.SourceAst sourceAst0 = null;
        com.google.javascript.rhino.InputId inputId1 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(sourceAst0, inputId1, false);
        com.google.javascript.rhino.InputId inputId4 = compilerInput3.getInputId();
        com.google.javascript.jscomp.SourceAst sourceAst5 = compilerInput3.getAst();
        try {
            java.util.Collection<java.lang.String> strCollection6 = compilerInput3.getRequires();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(inputId4);
        org.junit.Assert.assertNull(sourceAst5);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.TWEAKS;
        com.google.javascript.jscomp.DiagnosticGroups.NON_STANDARD_JSDOC = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticGroups.CHECK_PROVIDES = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticGroups.STRICT_MODULE_DEP_CHECK = diagnosticGroup0;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        com.google.javascript.rhino.JSDocInfo.NamePosition namePosition0 = new com.google.javascript.rhino.JSDocInfo.NamePosition();
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.SourceExcerptProvider.SourceExcerpt sourceExcerpt1 = null;
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter2 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler0, sourceExcerpt1);
        try {
            com.google.javascript.jscomp.Result result3 = compiler0.getResult();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        com.google.javascript.rhino.Node node2 = new com.google.javascript.rhino.Node(10);
        com.google.javascript.rhino.Node node3 = node2.cloneTree();
        com.google.javascript.jscomp.DiagnosticType diagnosticType6 = com.google.javascript.jscomp.DiagnosticType.error("", "");
        com.google.javascript.jscomp.DiagnosticType diagnosticType12 = com.google.javascript.jscomp.DiagnosticType.error("", "");
        java.lang.String str13 = diagnosticType12.toString();
        java.lang.String[] strArray16 = new java.lang.String[] { "", "" };
        com.google.javascript.jscomp.JSError jSError17 = com.google.javascript.jscomp.JSError.make("hi!", (-1), 0, diagnosticType12, strArray16);
        com.google.javascript.jscomp.JSError jSError18 = com.google.javascript.jscomp.JSError.make("hi!", node2, diagnosticType6, strArray16);
        boolean boolean19 = node2.hasOneChild();
        com.google.javascript.rhino.Node node21 = new com.google.javascript.rhino.Node(10);
        com.google.javascript.rhino.Node node22 = node21.cloneTree();
        int int23 = node2.getIndexOfChild(node22);
        try {
            com.google.javascript.rhino.Node node24 = com.google.javascript.jscomp.NodeUtil.getFunctionParameters(node22);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(diagnosticType6);
        org.junit.Assert.assertNotNull(diagnosticType12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + ": " + "'", str13.equals(": "));
        org.junit.Assert.assertNotNull(strArray16);
        org.junit.Assert.assertNotNull(jSError17);
        org.junit.Assert.assertNotNull(jSError18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        com.google.javascript.rhino.Node node1 = new com.google.javascript.rhino.Node(10);
        com.google.javascript.rhino.Node node3 = new com.google.javascript.rhino.Node(10);
        boolean boolean4 = node1.isEquivalentToTyped(node3);
        java.lang.String str5 = node1.getQualifiedName();
        node1.setWasEmptyNode(false);
        com.google.javascript.rhino.Node node9 = new com.google.javascript.rhino.Node(10);
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.IR.comma(node1, node9);
        boolean boolean11 = node9.isThis();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        com.google.javascript.jscomp.AstValidator.ViolationHandler violationHandler0 = null;
        com.google.javascript.jscomp.AstValidator astValidator1 = new com.google.javascript.jscomp.AstValidator(violationHandler0);
        com.google.javascript.rhino.Node node3 = new com.google.javascript.rhino.Node(10);
        com.google.javascript.rhino.Node node5 = new com.google.javascript.rhino.Node(10);
        boolean boolean6 = node3.isEquivalentToTyped(node5);
        boolean boolean7 = node3.isOnlyModifiesThisCall();
        try {
            astValidator1.validateCodeRoot(node3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.MessageFormatter messageFormatter1 = null;
        java.util.logging.Logger logger2 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager3 = new com.google.javascript.jscomp.LoggerErrorManager(messageFormatter1, logger2);
        compiler0.setErrorManager((com.google.javascript.jscomp.ErrorManager) loggerErrorManager3);
        com.google.javascript.jscomp.ErrorManager errorManager5 = compiler0.getErrorManager();
        double double6 = compiler0.getProgress();
        com.google.javascript.jscomp.JSError[] jSErrorArray7 = compiler0.getMessages();
        com.google.javascript.jscomp.SourceFile sourceFile8 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile9 = null;
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray10 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile9 };
        com.google.javascript.jscomp.CompilerOptions compilerOptions11 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions11.setCheckTypes(false);
        com.google.javascript.jscomp.CompilerOptions.LanguageMode languageMode14 = compilerOptions11.getLanguageOut();
        compilerOptions11.setInlineLocalVariables(false);
        compilerOptions11.setOptimizeArgumentsArray(false);
        try {
            com.google.javascript.jscomp.Result result19 = compiler0.compile(sourceFile8, jSSourceFileArray10, compilerOptions11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(errorManager5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(jSErrorArray7);
        org.junit.Assert.assertNotNull(jSSourceFileArray10);
        org.junit.Assert.assertNull(languageMode14);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        com.google.javascript.rhino.Node node1 = new com.google.javascript.rhino.Node(10);
        com.google.javascript.rhino.Node node3 = new com.google.javascript.rhino.Node(10);
        com.google.javascript.rhino.Node node4 = node3.cloneTree();
        com.google.javascript.rhino.Node node5 = node1.clonePropsFrom(node4);
        com.google.javascript.rhino.Node[] nodeArray8 = new com.google.javascript.rhino.Node[] {};
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.IR.block(nodeArray8);
        com.google.javascript.rhino.Node node12 = new com.google.javascript.rhino.Node((int) ' ', nodeArray8, (-1), 40);
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.IR.script(nodeArray8);
        com.google.javascript.rhino.Node node14 = new com.google.javascript.rhino.Node(0, nodeArray8);
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.IR.newNode(node1, nodeArray8);
        boolean boolean16 = node15.isAssign();
        boolean boolean17 = node15.isQualifiedName();
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNotNull(nodeArray8);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.U2U_CONSTRUCTOR_TYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.U2U_CONSTRUCTOR_TYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.U2U_CONSTRUCTOR_TYPE));
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        com.google.javascript.jscomp.SourceAst sourceAst0 = null;
        com.google.javascript.rhino.InputId inputId1 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(sourceAst0, inputId1, false);
        com.google.javascript.jscomp.SourceAst sourceAst4 = compilerInput3.getAst();
        org.junit.Assert.assertNull(sourceAst4);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setCheckTypes(false);
        com.google.javascript.jscomp.CompilerOptions.LanguageMode languageMode3 = compilerOptions0.getLanguageOut();
        compilerOptions0.setInlineLocalVariables(false);
        compilerOptions0.setTightenTypes(true);
        java.util.Map<java.lang.String, com.google.javascript.rhino.Node> strMap8 = compilerOptions0.getDefineReplacements();
        compilerOptions0.setInlineLocalVariables(false);
        boolean boolean11 = compilerOptions0.smartNameRemoval;
        java.util.Set<java.lang.String> strSet12 = compilerOptions0.stripTypePrefixes;
        com.google.javascript.jscomp.CheckLevel checkLevel13 = compilerOptions0.aggressiveVarCheck;
        org.junit.Assert.assertNull(languageMode3);
        org.junit.Assert.assertNotNull(strMap8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(strSet12);
        org.junit.Assert.assertTrue("'" + checkLevel13 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel13.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.number((double) (byte) 10);
        boolean boolean2 = node1.isStringKey();
        com.google.javascript.rhino.JSTypeExpression jSTypeExpression4 = new com.google.javascript.rhino.JSTypeExpression(node1, "");
        boolean boolean5 = jSTypeExpression4.isVarArgs();
        com.google.javascript.rhino.JSTypeExpression jSTypeExpression6 = com.google.javascript.rhino.JSTypeExpression.makeOptionalArg(jSTypeExpression4);
        boolean boolean7 = jSTypeExpression4.isOptionalArg();
        boolean boolean8 = jSTypeExpression4.isVarArgs();
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(jSTypeExpression6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        jSTypeRegistry1.identifyNonNullableName("function (): ?");
        com.google.javascript.rhino.ErrorReporter errorReporter4 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter4);
        jSTypeRegistry5.identifyNonNullableName("");
        com.google.javascript.rhino.ErrorReporter errorReporter8 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry9 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter8);
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope10 = null;
        jSTypeRegistry9.resolveTypesInScope(jSTypeStaticScope10);
        com.google.javascript.rhino.jstype.JSType jSType12 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray13 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList14 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean15 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList14, jSTypeArray13);
        com.google.javascript.rhino.jstype.FunctionType functionType16 = jSTypeRegistry9.createFunctionType(jSType12, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList14);
        com.google.javascript.rhino.ErrorReporter errorReporter18 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry19 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter18);
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope20 = null;
        jSTypeRegistry19.resolveTypesInScope(jSTypeStaticScope20);
        com.google.javascript.rhino.ErrorReporter errorReporter22 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry23 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter22);
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope24 = null;
        jSTypeRegistry23.resolveTypesInScope(jSTypeStaticScope24);
        com.google.javascript.rhino.jstype.JSType jSType26 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray27 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList28 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean29 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList28, jSTypeArray27);
        com.google.javascript.rhino.jstype.FunctionType functionType30 = jSTypeRegistry23.createFunctionType(jSType26, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList28);
        com.google.javascript.rhino.JSDocInfo jSDocInfo32 = functionType30.getOwnPropertyJSDocInfo("");
        com.google.javascript.rhino.ErrorReporter errorReporter33 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry34 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter33);
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope35 = null;
        jSTypeRegistry34.resolveTypesInScope(jSTypeStaticScope35);
        com.google.javascript.rhino.jstype.JSType jSType37 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray38 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList39 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean40 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList39, jSTypeArray38);
        com.google.javascript.rhino.jstype.FunctionType functionType41 = jSTypeRegistry34.createFunctionType(jSType37, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList39);
        com.google.javascript.rhino.JSDocInfo jSDocInfo43 = functionType41.getOwnPropertyJSDocInfo("");
        com.google.javascript.rhino.jstype.ObjectType objectType44 = functionType41.getImplicitPrototype();
        boolean boolean45 = objectType44.hasCachedValues();
        com.google.javascript.rhino.ErrorReporter errorReporter46 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry47 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter46);
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope48 = null;
        jSTypeRegistry47.resolveTypesInScope(jSTypeStaticScope48);
        com.google.javascript.rhino.jstype.JSType jSType50 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray51 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList52 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean53 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList52, jSTypeArray51);
        com.google.javascript.rhino.jstype.FunctionType functionType54 = jSTypeRegistry47.createFunctionType(jSType50, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList52);
        com.google.javascript.rhino.JSDocInfo jSDocInfo56 = functionType54.getOwnPropertyJSDocInfo("");
        boolean boolean58 = functionType54.removeProperty(".  at hi! line (unknown line) : 0");
        com.google.javascript.rhino.ErrorReporter errorReporter59 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry60 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter59);
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope61 = null;
        jSTypeRegistry60.resolveTypesInScope(jSTypeStaticScope61);
        com.google.javascript.rhino.jstype.JSType jSType63 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray64 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList65 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean66 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList65, jSTypeArray64);
        com.google.javascript.rhino.jstype.FunctionType functionType67 = jSTypeRegistry60.createFunctionType(jSType63, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList65);
        com.google.javascript.rhino.ErrorReporter errorReporter68 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry69 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter68);
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope70 = null;
        jSTypeRegistry69.resolveTypesInScope(jSTypeStaticScope70);
        com.google.javascript.rhino.jstype.JSType jSType72 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray73 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList74 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean75 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList74, jSTypeArray73);
        com.google.javascript.rhino.jstype.FunctionType functionType76 = jSTypeRegistry69.createFunctionType(jSType72, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList74);
        com.google.javascript.rhino.JSDocInfo jSDocInfo78 = functionType76.getOwnPropertyJSDocInfo("");
        com.google.javascript.rhino.ErrorReporter errorReporter79 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry80 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter79);
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope81 = null;
        jSTypeRegistry80.resolveTypesInScope(jSTypeStaticScope81);
        com.google.javascript.rhino.jstype.JSType jSType83 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray84 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList85 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean86 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList85, jSTypeArray84);
        com.google.javascript.rhino.jstype.FunctionType functionType87 = jSTypeRegistry80.createFunctionType(jSType83, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList85);
        com.google.javascript.rhino.JSDocInfo jSDocInfo89 = functionType87.getOwnPropertyJSDocInfo("");
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray90 = new com.google.javascript.rhino.jstype.JSType[] { objectType44, functionType54, functionType67, functionType76, functionType87 };
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList91 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean92 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList91, jSTypeArray90);
        com.google.javascript.rhino.jstype.FunctionType functionType93 = jSTypeRegistry19.createFunctionTypeWithVarArgs((com.google.javascript.rhino.jstype.JSType) functionType30, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList91);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray94 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.Node node95 = jSTypeRegistry19.createParameters(jSTypeArray94);
        com.google.javascript.rhino.jstype.FunctionType functionType96 = jSTypeRegistry5.createConstructorType(jSType12, false, jSTypeArray94);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray97 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType98 = jSTypeRegistry1.createFunctionType((com.google.javascript.rhino.jstype.JSType) functionType96, jSTypeArray97);
        org.junit.Assert.assertNotNull(jSTypeArray13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(functionType16);
        org.junit.Assert.assertNotNull(jSTypeArray27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(functionType30);
        org.junit.Assert.assertNull(jSDocInfo32);
        org.junit.Assert.assertNotNull(jSTypeArray38);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(functionType41);
        org.junit.Assert.assertNull(jSDocInfo43);
        org.junit.Assert.assertNotNull(objectType44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(jSTypeArray51);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNotNull(functionType54);
        org.junit.Assert.assertNull(jSDocInfo56);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(jSTypeArray64);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertNotNull(functionType67);
        org.junit.Assert.assertNotNull(jSTypeArray73);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
        org.junit.Assert.assertNotNull(functionType76);
        org.junit.Assert.assertNull(jSDocInfo78);
        org.junit.Assert.assertNotNull(jSTypeArray84);
        org.junit.Assert.assertTrue("'" + boolean86 + "' != '" + false + "'", boolean86 == false);
        org.junit.Assert.assertNotNull(functionType87);
        org.junit.Assert.assertNull(jSDocInfo89);
        org.junit.Assert.assertNotNull(jSTypeArray90);
        org.junit.Assert.assertTrue("'" + boolean92 + "' != '" + true + "'", boolean92 == true);
        org.junit.Assert.assertNotNull(functionType93);
        org.junit.Assert.assertNotNull(jSTypeArray94);
        org.junit.Assert.assertNotNull(node95);
        org.junit.Assert.assertNotNull(functionType96);
        org.junit.Assert.assertNotNull(jSTypeArray97);
        org.junit.Assert.assertNotNull(functionType98);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.exportTestFunctions;
        com.google.javascript.jscomp.AnonymousFunctionNamingPolicy anonymousFunctionNamingPolicy2 = compilerOptions0.anonymousFunctionNaming;
        boolean boolean3 = compilerOptions0.closurePass;
        com.google.javascript.jscomp.CheckLevel checkLevel4 = com.google.javascript.jscomp.CheckLevel.ERROR;
        compilerOptions0.reportMissingOverride = checkLevel4;
        compilerOptions0.setTweakToBooleanLiteral("Not declared as a constructor", true);
        compilerOptions0.setInlineLocalFunctions(true);
        compilerOptions0.renamePrefixNamespace = "";
        compilerOptions0.collapseAnonymousFunctions = true;
        boolean boolean15 = compilerOptions0.isRemoveUnusedClassProperties();
        com.google.javascript.jscomp.CompilerOptions.LanguageMode languageMode16 = compilerOptions0.getLanguageOut();
        com.google.javascript.jscomp.CompilerOptions compilerOptions17 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean18 = compilerOptions17.exportTestFunctions;
        com.google.javascript.jscomp.AnonymousFunctionNamingPolicy anonymousFunctionNamingPolicy19 = compilerOptions17.anonymousFunctionNaming;
        com.google.javascript.jscomp.parsing.Config.LanguageMode languageMode21 = null;
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.IR.block();
        com.google.javascript.jscomp.parsing.Config.LanguageMode languageMode25 = null;
        java.lang.String[] strArray29 = new java.lang.String[] { "", "" };
        java.util.LinkedHashSet<java.lang.String> strSet30 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean31 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet30, strArray29);
        com.google.javascript.jscomp.parsing.Config config32 = com.google.javascript.jscomp.parsing.ParserRunner.createConfig(true, languageMode25, false, (java.util.Set<java.lang.String>) strSet30);
        node23.setDirectives((java.util.Set<java.lang.String>) strSet30);
        com.google.javascript.jscomp.parsing.Config config34 = com.google.javascript.jscomp.parsing.ParserRunner.createConfig(true, languageMode21, false, (java.util.Set<java.lang.String>) strSet30);
        compilerOptions17.setIdGenerators((java.util.Set<java.lang.String>) strSet30);
        compilerOptions17.setExtractPrototypeMemberDeclarations(false);
        java.lang.String[] strArray41 = new java.lang.String[] { "module$DiagnosticGroup<checkRegExp>", "function ({-444333608}, function (): {516604112}, function (): {288925563}, function (): {511411474}, {(function (): {1085384306},{424560384})}): function (): {1063088224}", "function ({-444333608}, function (): {516604112}, function (): {288925563}, function (): {511411474}, {(function (): {1085384306},{424560384})}): function (): {1063088224}" };
        java.util.LinkedHashSet<java.lang.String> strSet42 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean43 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet42, strArray41);
        compilerOptions17.aliasableStrings = strSet42;
        compilerOptions0.setStripNameSuffixes((java.util.Set<java.lang.String>) strSet42);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + anonymousFunctionNamingPolicy2 + "' != '" + com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF + "'", anonymousFunctionNamingPolicy2.equals(com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + checkLevel4 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel4.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNull(languageMode16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + anonymousFunctionNamingPolicy19 + "' != '" + com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF + "'", anonymousFunctionNamingPolicy19.equals(com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF));
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(strArray29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertNotNull(config32);
        org.junit.Assert.assertNotNull(config34);
        org.junit.Assert.assertNotNull(strArray41);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setCheckTypes(false);
        boolean boolean3 = compilerOptions0.moveFunctionDeclarations;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newString(": ");
        com.google.javascript.rhino.Node node3 = new com.google.javascript.rhino.Node(10);
        com.google.javascript.rhino.Node node5 = new com.google.javascript.rhino.Node(10);
        boolean boolean6 = node3.isEquivalentToTyped(node5);
        java.lang.String str7 = node3.getQualifiedName();
        node3.setWasEmptyNode(false);
        boolean boolean10 = node3.isSyntheticBlock();
        boolean boolean11 = node1.isEquivalentToTyped(node3);
        int int12 = node3.getChildCount();
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.MessageFormatter messageFormatter1 = null;
        java.util.logging.Logger logger2 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager3 = new com.google.javascript.jscomp.LoggerErrorManager(messageFormatter1, logger2);
        compiler0.setErrorManager((com.google.javascript.jscomp.ErrorManager) loggerErrorManager3);
        com.google.javascript.jscomp.Compiler compiler5 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.PerformanceTracker performanceTracker6 = compiler5.tracker;
        com.google.javascript.jscomp.Compiler.IntermediateState intermediateState7 = compiler5.getState();
        compiler0.setState(intermediateState7);
        com.google.javascript.rhino.Node node11 = new com.google.javascript.rhino.Node(10);
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node(10);
        com.google.javascript.rhino.Node node14 = node13.cloneTree();
        com.google.javascript.rhino.Node node15 = node11.clonePropsFrom(node14);
        com.google.javascript.jscomp.DiagnosticType diagnosticType18 = com.google.javascript.jscomp.DiagnosticType.error("", "");
        com.google.javascript.jscomp.DiagnosticType diagnosticType24 = com.google.javascript.jscomp.DiagnosticType.error("", "");
        java.lang.String str25 = diagnosticType24.toString();
        java.lang.String[] strArray28 = new java.lang.String[] { "", "" };
        com.google.javascript.jscomp.JSError jSError29 = com.google.javascript.jscomp.JSError.make("hi!", (-1), 0, diagnosticType24, strArray28);
        com.google.javascript.jscomp.JSError jSError30 = com.google.javascript.jscomp.JSError.make("hi!", node11, diagnosticType18, strArray28);
        int int31 = jSError30.getLineNumber();
        try {
            compiler0.report(jSError30);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(performanceTracker6);
        org.junit.Assert.assertNotNull(intermediateState7);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertNotNull(diagnosticType18);
        org.junit.Assert.assertNotNull(diagnosticType24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + ": " + "'", str25.equals(": "));
        org.junit.Assert.assertNotNull(strArray28);
        org.junit.Assert.assertNotNull(jSError29);
        org.junit.Assert.assertNotNull(jSError30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + (-1) + "'", int31 == (-1));
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        com.google.javascript.rhino.JSDocInfoBuilder jSDocInfoBuilder1 = new com.google.javascript.rhino.JSDocInfoBuilder(true);
        com.google.javascript.rhino.JSDocInfo.Visibility visibility2 = null;
        boolean boolean3 = jSDocInfoBuilder1.recordVisibility(visibility2);
        boolean boolean4 = jSDocInfoBuilder1.recordNoSideEffects();
        boolean boolean5 = jSDocInfoBuilder1.recordImplicitCast();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        int int0 = com.google.javascript.rhino.Node.VAR_ARGS_NAME;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 30 + "'", int0 == 30);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        com.google.javascript.rhino.Node node1 = new com.google.javascript.rhino.Node(10);
        com.google.javascript.rhino.Node node3 = new com.google.javascript.rhino.Node(10);
        boolean boolean4 = node1.isEquivalentToTyped(node3);
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.IR.exprResult(node3);
        com.google.javascript.rhino.Node node6 = node3.cloneNode();
        boolean boolean7 = node6.isVoid();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.exportTestFunctions;
        com.google.javascript.jscomp.AnonymousFunctionNamingPolicy anonymousFunctionNamingPolicy2 = compilerOptions0.anonymousFunctionNaming;
        com.google.javascript.jscomp.parsing.Config.LanguageMode languageMode4 = null;
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.IR.block();
        com.google.javascript.jscomp.parsing.Config.LanguageMode languageMode8 = null;
        java.lang.String[] strArray12 = new java.lang.String[] { "", "" };
        java.util.LinkedHashSet<java.lang.String> strSet13 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean14 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet13, strArray12);
        com.google.javascript.jscomp.parsing.Config config15 = com.google.javascript.jscomp.parsing.ParserRunner.createConfig(true, languageMode8, false, (java.util.Set<java.lang.String>) strSet13);
        node6.setDirectives((java.util.Set<java.lang.String>) strSet13);
        com.google.javascript.jscomp.parsing.Config config17 = com.google.javascript.jscomp.parsing.ParserRunner.createConfig(true, languageMode4, false, (java.util.Set<java.lang.String>) strSet13);
        compilerOptions0.setIdGenerators((java.util.Set<java.lang.String>) strSet13);
        compilerOptions0.setExtractPrototypeMemberDeclarations(false);
        compilerOptions0.setTightenTypes(false);
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap23 = compilerOptions0.cssRenamingMap;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + anonymousFunctionNamingPolicy2 + "' != '" + com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF + "'", anonymousFunctionNamingPolicy2.equals(com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF));
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(strArray12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(config15);
        org.junit.Assert.assertNotNull(config17);
        org.junit.Assert.assertNull(cssRenamingMap23);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setCheckTypes(false);
        com.google.javascript.jscomp.CompilerOptions.LanguageMode languageMode3 = compilerOptions0.getLanguageOut();
        compilerOptions0.setInlineLocalVariables(false);
        com.google.javascript.jscomp.Compiler compiler6 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.MessageFormatter messageFormatter7 = null;
        java.util.logging.Logger logger8 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager9 = new com.google.javascript.jscomp.LoggerErrorManager(messageFormatter7, logger8);
        compiler6.setErrorManager((com.google.javascript.jscomp.ErrorManager) loggerErrorManager9);
        int int11 = loggerErrorManager9.getErrorCount();
        compilerOptions0.setErrorHandler((com.google.javascript.jscomp.ErrorHandler) loggerErrorManager9);
        boolean boolean13 = compilerOptions0.gatherCssNames;
        org.junit.Assert.assertNull(languageMode3);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setCheckTypes(false);
        compilerOptions0.optimizeReturns = true;
        compilerOptions0.setFlowSensitiveInlineVariables(false);
        byte[] byteArray9 = new byte[] { (byte) -1, (byte) 100 };
        compilerOptions0.inputPropertyMapSerialized = byteArray9;
        boolean boolean11 = compilerOptions0.isExternExportsEnabled();
        compilerOptions0.setInstrumentationTemplate("");
        org.junit.Assert.assertNotNull(byteArray9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope2 = null;
        jSTypeRegistry1.resolveTypesInScope(jSTypeStaticScope2);
        com.google.javascript.rhino.jstype.JSType jSType4 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray5 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList6 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean7 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList6, jSTypeArray5);
        com.google.javascript.rhino.jstype.FunctionType functionType8 = jSTypeRegistry1.createFunctionType(jSType4, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList6);
        jSTypeRegistry1.identifyNonNullableName("DependencyInfo(relativePath='./', path=': ', provides=[DiagnosticGroup<checkRegExp>, : , , , hi!, .  at hi! line (unknown line) : 0], requires=[./])");
        boolean boolean12 = jSTypeRegistry1.isForwardDeclaredType("module$DiagnosticGroup<checkRegExp>");
        org.junit.Assert.assertNotNull(jSTypeArray5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(functionType8);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        com.google.javascript.rhino.Node node1 = new com.google.javascript.rhino.Node(10);
        com.google.javascript.rhino.Node node3 = new com.google.javascript.rhino.Node(10);
        boolean boolean4 = node1.isEquivalentToTyped(node3);
        java.lang.String str5 = node1.getQualifiedName();
        node1.setWasEmptyNode(false);
        boolean boolean8 = node1.isDo();
        com.google.javascript.rhino.Node node10 = new com.google.javascript.rhino.Node(10);
        com.google.javascript.rhino.Node node12 = new com.google.javascript.rhino.Node(10);
        boolean boolean13 = node10.isEquivalentToTyped(node12);
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.IR.exprResult(node12);
        com.google.javascript.rhino.Node node15 = node1.useSourceInfoIfMissingFrom(node12);
        com.google.javascript.rhino.Node node16 = node1.cloneTree();
        boolean boolean17 = node1.isExprResult();
        boolean boolean18 = node1.isQualifiedName();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        com.google.javascript.jscomp.JSModule[] jSModuleArray0 = new com.google.javascript.jscomp.JSModule[] {};
        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList1 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList1, jSModuleArray0);
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph3 = new com.google.javascript.jscomp.JSModuleGraph((java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList1);
        com.google.javascript.jscomp.DependencyOptions dependencyOptions4 = new com.google.javascript.jscomp.DependencyOptions();
        com.google.javascript.jscomp.DependencyOptions dependencyOptions6 = dependencyOptions4.setDependencySorting(false);
        java.util.List<com.google.javascript.jscomp.CompilerInput> compilerInputList7 = null;
        try {
            java.util.List<com.google.javascript.jscomp.CompilerInput> compilerInputList8 = jSModuleGraph3.manageDependencies(dependencyOptions4, compilerInputList7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jSModuleArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(dependencyOptions6);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        com.google.javascript.jscomp.CodingConvention codingConvention0 = null;
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention1 = new com.google.javascript.jscomp.GoogleCodingConvention(codingConvention0);
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention2 = new com.google.javascript.jscomp.GoogleCodingConvention((com.google.javascript.jscomp.CodingConvention) googleCodingConvention1);
        boolean boolean4 = googleCodingConvention1.isValidEnumKey("hi!");
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention5 = new com.google.javascript.jscomp.GoogleCodingConvention((com.google.javascript.jscomp.CodingConvention) googleCodingConvention1);
        boolean boolean7 = googleCodingConvention1.isConstant("goog.exportProperty");
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention8 = new com.google.javascript.jscomp.GoogleCodingConvention((com.google.javascript.jscomp.CodingConvention) googleCodingConvention1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.exportTestFunctions;
        com.google.javascript.jscomp.AnonymousFunctionNamingPolicy anonymousFunctionNamingPolicy2 = compilerOptions0.anonymousFunctionNaming;
        boolean boolean3 = compilerOptions0.closurePass;
        com.google.javascript.jscomp.CheckLevel checkLevel4 = com.google.javascript.jscomp.CheckLevel.ERROR;
        compilerOptions0.reportMissingOverride = checkLevel4;
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy6 = compilerOptions0.propertyRenaming;
        com.google.javascript.jscomp.CheckLevel checkLevel7 = compilerOptions0.checkRequires;
        compilerOptions0.setAppNameStr("");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + anonymousFunctionNamingPolicy2 + "' != '" + com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF + "'", anonymousFunctionNamingPolicy2.equals(com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + checkLevel4 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel4.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy6 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.OFF + "'", propertyRenamingPolicy6.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.OFF));
        org.junit.Assert.assertTrue("'" + checkLevel7 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel7.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setCheckTypes(false);
        com.google.javascript.jscomp.CompilerOptions.LanguageMode languageMode3 = compilerOptions0.getLanguageOut();
        compilerOptions0.setInlineLocalVariables(false);
        compilerOptions0.setTightenTypes(true);
        java.util.Map<java.lang.String, com.google.javascript.rhino.Node> strMap8 = compilerOptions0.getDefineReplacements();
        compilerOptions0.setInlineLocalVariables(false);
        com.google.javascript.jscomp.CompilerOptions compilerOptions11 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions11.setDeadAssignmentElimination(false);
        com.google.javascript.jscomp.CompilerOptions compilerOptions14 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean15 = compilerOptions14.exportTestFunctions;
        com.google.javascript.jscomp.AnonymousFunctionNamingPolicy anonymousFunctionNamingPolicy16 = compilerOptions14.anonymousFunctionNaming;
        com.google.javascript.jscomp.parsing.Config.LanguageMode languageMode18 = null;
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.IR.block();
        com.google.javascript.jscomp.parsing.Config.LanguageMode languageMode22 = null;
        java.lang.String[] strArray26 = new java.lang.String[] { "", "" };
        java.util.LinkedHashSet<java.lang.String> strSet27 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean28 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet27, strArray26);
        com.google.javascript.jscomp.parsing.Config config29 = com.google.javascript.jscomp.parsing.ParserRunner.createConfig(true, languageMode22, false, (java.util.Set<java.lang.String>) strSet27);
        node20.setDirectives((java.util.Set<java.lang.String>) strSet27);
        com.google.javascript.jscomp.parsing.Config config31 = com.google.javascript.jscomp.parsing.ParserRunner.createConfig(true, languageMode18, false, (java.util.Set<java.lang.String>) strSet27);
        compilerOptions14.setIdGenerators((java.util.Set<java.lang.String>) strSet27);
        java.util.Set<java.lang.String> strSet33 = compilerOptions14.aliasableStrings;
        compilerOptions11.setStripNameSuffixes(strSet33);
        compilerOptions0.setIdGenerators(strSet33);
        org.junit.Assert.assertNull(languageMode3);
        org.junit.Assert.assertNotNull(strMap8);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + anonymousFunctionNamingPolicy16 + "' != '" + com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF + "'", anonymousFunctionNamingPolicy16.equals(com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF));
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNotNull(strArray26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(config29);
        org.junit.Assert.assertNotNull(config31);
        org.junit.Assert.assertNotNull(strSet33);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        com.google.javascript.rhino.JSDocInfo jSDocInfo0 = new com.google.javascript.rhino.JSDocInfo();
        boolean boolean1 = jSDocInfo0.containsDeclaration();
        com.google.javascript.rhino.JSTypeExpression jSTypeExpression2 = jSDocInfo0.getThisType();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNull(jSTypeExpression2);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        com.google.javascript.rhino.Node node1 = new com.google.javascript.rhino.Node(10);
        com.google.javascript.rhino.Node node3 = new com.google.javascript.rhino.Node(10);
        boolean boolean4 = node1.isEquivalentToTyped(node3);
        java.lang.String str5 = node1.getQualifiedName();
        node1.setWasEmptyNode(false);
        boolean boolean8 = node1.isDo();
        com.google.javascript.rhino.Node node10 = new com.google.javascript.rhino.Node(10);
        com.google.javascript.rhino.Node node12 = new com.google.javascript.rhino.Node(10);
        boolean boolean13 = node10.isEquivalentToTyped(node12);
        java.lang.String str14 = node10.getQualifiedName();
        node10.setWasEmptyNode(false);
        boolean boolean17 = node10.isDo();
        com.google.javascript.rhino.Node node19 = new com.google.javascript.rhino.Node(10);
        com.google.javascript.rhino.Node node21 = new com.google.javascript.rhino.Node(10);
        boolean boolean22 = node19.isEquivalentToTyped(node21);
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.IR.exprResult(node21);
        com.google.javascript.rhino.Node node24 = node10.useSourceInfoIfMissingFrom(node21);
        com.google.javascript.rhino.Node node25 = node10.cloneTree();
        com.google.javascript.rhino.Node node26 = node1.copyInformationFrom(node10);
        boolean boolean27 = node10.isVoid();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = null;
        com.google.javascript.rhino.jstype.FunctionBuilder functionBuilder2 = new com.google.javascript.rhino.jstype.FunctionBuilder(jSTypeRegistry1);
        com.google.javascript.rhino.jstype.FunctionBuilder functionBuilder4 = functionBuilder2.setIsConstructor(false);
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.Node.newString((int) (short) -1, "");
        boolean boolean8 = node7.isThrow();
        com.google.javascript.rhino.Node node10 = new com.google.javascript.rhino.Node(10);
        com.google.javascript.rhino.Node node12 = new com.google.javascript.rhino.Node(10);
        boolean boolean13 = node10.isEquivalentToTyped(node12);
        boolean boolean14 = node10.isOnlyModifiesThisCall();
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.IR.throwNode(node10);
        com.google.javascript.rhino.Node node16 = node7.useSourceInfoIfMissingFrom(node10);
        com.google.javascript.rhino.jstype.FunctionBuilder functionBuilder17 = functionBuilder4.withSourceNode(node10);
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.IR.breakNode();
        com.google.javascript.rhino.jstype.FunctionBuilder functionBuilder19 = functionBuilder4.withParamsNode(node18);
        com.google.javascript.rhino.Node node21 = new com.google.javascript.rhino.Node(10);
        com.google.javascript.rhino.Node node23 = new com.google.javascript.rhino.Node(10);
        boolean boolean24 = node21.isEquivalentToTyped(node23);
        java.lang.String str25 = node21.getQualifiedName();
        com.google.javascript.rhino.Node node26 = com.google.javascript.rhino.IR.throwNode(node21);
        try {
            com.google.javascript.rhino.Node node27 = new com.google.javascript.rhino.Node((int) (byte) 100, node18, node21);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: second new child has existing parent");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(functionBuilder4);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertNotNull(functionBuilder17);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNotNull(functionBuilder19);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNull(str25);
        org.junit.Assert.assertNotNull(node26);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setCheckTypes(false);
        com.google.javascript.jscomp.CompilerOptions.LanguageMode languageMode3 = compilerOptions0.getLanguageOut();
        compilerOptions0.setInlineLocalVariables(false);
        compilerOptions0.setTightenTypes(true);
        java.util.Map<java.lang.String, com.google.javascript.rhino.Node> strMap8 = compilerOptions0.getDefineReplacements();
        compilerOptions0.setInlineLocalVariables(false);
        com.google.javascript.jscomp.CompilerOptions.Reach reach11 = com.google.javascript.jscomp.CompilerOptions.Reach.ALL;
        compilerOptions0.setRemoveUnusedVariables(reach11);
        org.junit.Assert.assertNull(languageMode3);
        org.junit.Assert.assertNotNull(strMap8);
        org.junit.Assert.assertTrue("'" + reach11 + "' != '" + com.google.javascript.jscomp.CompilerOptions.Reach.ALL + "'", reach11.equals(com.google.javascript.jscomp.CompilerOptions.Reach.ALL));
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope2 = null;
        jSTypeRegistry1.resolveTypesInScope(jSTypeStaticScope2);
        com.google.javascript.rhino.ErrorReporter errorReporter4 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter4);
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope6 = null;
        jSTypeRegistry5.resolveTypesInScope(jSTypeStaticScope6);
        com.google.javascript.rhino.jstype.JSType jSType8 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray9 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList10 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean11 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList10, jSTypeArray9);
        com.google.javascript.rhino.jstype.FunctionType functionType12 = jSTypeRegistry5.createFunctionType(jSType8, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList10);
        com.google.javascript.rhino.JSDocInfo jSDocInfo14 = functionType12.getOwnPropertyJSDocInfo("");
        com.google.javascript.rhino.ErrorReporter errorReporter15 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry16 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter15);
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope17 = null;
        jSTypeRegistry16.resolveTypesInScope(jSTypeStaticScope17);
        com.google.javascript.rhino.jstype.JSType jSType19 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray20 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList21 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean22 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList21, jSTypeArray20);
        com.google.javascript.rhino.jstype.FunctionType functionType23 = jSTypeRegistry16.createFunctionType(jSType19, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList21);
        com.google.javascript.rhino.JSDocInfo jSDocInfo25 = functionType23.getOwnPropertyJSDocInfo("");
        com.google.javascript.rhino.jstype.ObjectType objectType26 = functionType23.getImplicitPrototype();
        boolean boolean27 = objectType26.hasCachedValues();
        com.google.javascript.rhino.ErrorReporter errorReporter28 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry29 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter28);
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope30 = null;
        jSTypeRegistry29.resolveTypesInScope(jSTypeStaticScope30);
        com.google.javascript.rhino.jstype.JSType jSType32 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray33 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList34 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean35 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList34, jSTypeArray33);
        com.google.javascript.rhino.jstype.FunctionType functionType36 = jSTypeRegistry29.createFunctionType(jSType32, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList34);
        com.google.javascript.rhino.JSDocInfo jSDocInfo38 = functionType36.getOwnPropertyJSDocInfo("");
        boolean boolean40 = functionType36.removeProperty(".  at hi! line (unknown line) : 0");
        com.google.javascript.rhino.ErrorReporter errorReporter41 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry42 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter41);
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope43 = null;
        jSTypeRegistry42.resolveTypesInScope(jSTypeStaticScope43);
        com.google.javascript.rhino.jstype.JSType jSType45 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray46 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList47 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean48 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList47, jSTypeArray46);
        com.google.javascript.rhino.jstype.FunctionType functionType49 = jSTypeRegistry42.createFunctionType(jSType45, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList47);
        com.google.javascript.rhino.ErrorReporter errorReporter50 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry51 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter50);
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope52 = null;
        jSTypeRegistry51.resolveTypesInScope(jSTypeStaticScope52);
        com.google.javascript.rhino.jstype.JSType jSType54 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray55 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList56 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean57 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList56, jSTypeArray55);
        com.google.javascript.rhino.jstype.FunctionType functionType58 = jSTypeRegistry51.createFunctionType(jSType54, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList56);
        com.google.javascript.rhino.JSDocInfo jSDocInfo60 = functionType58.getOwnPropertyJSDocInfo("");
        com.google.javascript.rhino.ErrorReporter errorReporter61 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry62 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter61);
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope63 = null;
        jSTypeRegistry62.resolveTypesInScope(jSTypeStaticScope63);
        com.google.javascript.rhino.jstype.JSType jSType65 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray66 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList67 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean68 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList67, jSTypeArray66);
        com.google.javascript.rhino.jstype.FunctionType functionType69 = jSTypeRegistry62.createFunctionType(jSType65, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList67);
        com.google.javascript.rhino.JSDocInfo jSDocInfo71 = functionType69.getOwnPropertyJSDocInfo("");
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray72 = new com.google.javascript.rhino.jstype.JSType[] { objectType26, functionType36, functionType49, functionType58, functionType69 };
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList73 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean74 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList73, jSTypeArray72);
        com.google.javascript.rhino.jstype.FunctionType functionType75 = jSTypeRegistry1.createFunctionTypeWithVarArgs((com.google.javascript.rhino.jstype.JSType) functionType12, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList73);
        boolean boolean77 = functionType75.isPropertyInExterns("");
        boolean boolean78 = functionType75.isNumberValueType();
        boolean boolean80 = functionType75.hasProperty("DiagnosticGroup<checkRegExp>");
        org.junit.Assert.assertNotNull(jSTypeArray9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(functionType12);
        org.junit.Assert.assertNull(jSDocInfo14);
        org.junit.Assert.assertNotNull(jSTypeArray20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(functionType23);
        org.junit.Assert.assertNull(jSDocInfo25);
        org.junit.Assert.assertNotNull(objectType26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(jSTypeArray33);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(functionType36);
        org.junit.Assert.assertNull(jSDocInfo38);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(jSTypeArray46);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(functionType49);
        org.junit.Assert.assertNotNull(jSTypeArray55);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertNotNull(functionType58);
        org.junit.Assert.assertNull(jSDocInfo60);
        org.junit.Assert.assertNotNull(jSTypeArray66);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertNotNull(functionType69);
        org.junit.Assert.assertNull(jSDocInfo71);
        org.junit.Assert.assertNotNull(jSTypeArray72);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + true + "'", boolean74 == true);
        org.junit.Assert.assertNotNull(functionType75);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + false + "'", boolean80 == false);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        com.google.javascript.jscomp.CodingConvention codingConvention0 = com.google.javascript.jscomp.CodingConventions.getDefault();
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention1 = new com.google.javascript.jscomp.ClosureCodingConvention(codingConvention0);
        com.google.javascript.rhino.Node node2 = null;
        boolean boolean3 = closureCodingConvention1.isVarArgsParameter(node2);
        java.lang.String str4 = closureCodingConvention1.getExportPropertyFunction();
        com.google.javascript.rhino.Node node6 = new com.google.javascript.rhino.Node(10);
        com.google.javascript.rhino.Node node8 = new com.google.javascript.rhino.Node(10);
        boolean boolean9 = node6.isEquivalentToTyped(node8);
        java.lang.String str10 = node6.getQualifiedName();
        node6.setWasEmptyNode(false);
        com.google.javascript.rhino.Node node14 = new com.google.javascript.rhino.Node(10);
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.IR.comma(node6, node14);
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newString(": ");
        boolean boolean18 = node17.isTrue();
        java.lang.String str19 = closureCodingConvention1.extractClassNameIfRequire(node14, node17);
        java.lang.String str20 = closureCodingConvention1.getExportSymbolFunction();
        org.junit.Assert.assertNotNull(codingConvention0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "goog.exportProperty" + "'", str4.equals("goog.exportProperty"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNull(str19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "goog.exportSymbol" + "'", str20.equals("goog.exportSymbol"));
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope2 = null;
        jSTypeRegistry1.resolveTypesInScope(jSTypeStaticScope2);
        com.google.javascript.rhino.jstype.JSType jSType4 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray5 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList6 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean7 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList6, jSTypeArray5);
        com.google.javascript.rhino.jstype.FunctionType functionType8 = jSTypeRegistry1.createFunctionType(jSType4, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList6);
        com.google.javascript.rhino.JSDocInfo jSDocInfo10 = functionType8.getOwnPropertyJSDocInfo("");
        com.google.javascript.rhino.jstype.ObjectType objectType11 = functionType8.getImplicitPrototype();
        boolean boolean12 = objectType11.hasCachedValues();
        com.google.javascript.rhino.jstype.JSType jSType14 = objectType11.findPropertyType("./");
        java.lang.String str15 = objectType11.toAnnotationString();
        org.junit.Assert.assertNotNull(jSTypeArray5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(functionType8);
        org.junit.Assert.assertNull(jSDocInfo10);
        org.junit.Assert.assertNotNull(objectType11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNull(jSType14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Function" + "'", str15.equals("Function"));
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.Node.newString((int) (short) -1, "");
        boolean boolean3 = node2.isThrow();
        com.google.javascript.rhino.Node node5 = new com.google.javascript.rhino.Node(10);
        com.google.javascript.rhino.Node node7 = new com.google.javascript.rhino.Node(10);
        boolean boolean8 = node5.isEquivalentToTyped(node7);
        boolean boolean9 = node5.isOnlyModifiesThisCall();
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.IR.throwNode(node5);
        com.google.javascript.rhino.Node node11 = node2.useSourceInfoIfMissingFrom(node5);
        com.google.javascript.rhino.Node node12 = null;
        try {
            node2.addChildToBack(node12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(node11);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry0 = null;
        com.google.javascript.rhino.jstype.FunctionBuilder functionBuilder1 = new com.google.javascript.rhino.jstype.FunctionBuilder(jSTypeRegistry0);
        com.google.javascript.rhino.jstype.FunctionBuilder functionBuilder3 = functionBuilder1.withName("module$DiagnosticGroup<checkRegExp>");
        com.google.javascript.rhino.jstype.FunctionBuilder functionBuilder5 = functionBuilder1.setIsConstructor(false);
        com.google.javascript.rhino.jstype.FunctionBuilder functionBuilder7 = functionBuilder1.withName("");
        com.google.javascript.rhino.ErrorReporter errorReporter8 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry9 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter8);
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope10 = null;
        jSTypeRegistry9.resolveTypesInScope(jSTypeStaticScope10);
        com.google.javascript.rhino.jstype.JSType jSType12 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray13 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList14 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean15 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList14, jSTypeArray13);
        com.google.javascript.rhino.jstype.FunctionType functionType16 = jSTypeRegistry9.createFunctionType(jSType12, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList14);
        boolean boolean17 = functionType16.hasReferenceName();
        com.google.javascript.rhino.jstype.ObjectType objectType18 = functionType16.getTypeOfThis();
        com.google.javascript.rhino.ErrorReporter errorReporter19 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry20 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter19);
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope21 = null;
        jSTypeRegistry20.resolveTypesInScope(jSTypeStaticScope21);
        com.google.javascript.rhino.jstype.JSType jSType23 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray24 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList25 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean26 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList25, jSTypeArray24);
        com.google.javascript.rhino.jstype.FunctionType functionType27 = jSTypeRegistry20.createFunctionType(jSType23, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList25);
        com.google.javascript.rhino.JSDocInfo jSDocInfo29 = functionType27.getOwnPropertyJSDocInfo("");
        com.google.javascript.rhino.JSDocInfo jSDocInfo30 = functionType27.getJSDocInfo();
        com.google.javascript.rhino.jstype.TernaryValue ternaryValue31 = functionType16.testForEquality((com.google.javascript.rhino.jstype.JSType) functionType27);
        com.google.javascript.rhino.jstype.FunctionBuilder functionBuilder32 = functionBuilder7.withInferredReturnType((com.google.javascript.rhino.jstype.JSType) functionType16);
        java.lang.String str33 = functionType16.getNormalizedReferenceName();
        org.junit.Assert.assertNotNull(functionBuilder3);
        org.junit.Assert.assertNotNull(functionBuilder5);
        org.junit.Assert.assertNotNull(functionBuilder7);
        org.junit.Assert.assertNotNull(jSTypeArray13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(functionType16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(objectType18);
        org.junit.Assert.assertNotNull(jSTypeArray24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(functionType27);
        org.junit.Assert.assertNull(jSDocInfo29);
        org.junit.Assert.assertNull(jSDocInfo30);
        org.junit.Assert.assertNotNull(ternaryValue31);
        org.junit.Assert.assertNotNull(functionBuilder32);
        org.junit.Assert.assertNull(str33);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        java.nio.charset.Charset charset1 = null;
        com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromFile(": ", charset1);
        com.google.javascript.jscomp.JsAst jsAst3 = new com.google.javascript.jscomp.JsAst(sourceFile2);
        com.google.javascript.jscomp.SourceFile sourceFile4 = jsAst3.getSourceFile();
        com.google.javascript.jscomp.SourceFile sourceFile5 = jsAst3.getSourceFile();
        org.junit.Assert.assertNotNull(sourceFile2);
        org.junit.Assert.assertNotNull(sourceFile4);
        org.junit.Assert.assertNotNull(sourceFile5);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        com.google.javascript.rhino.JSDocInfoBuilder jSDocInfoBuilder1 = new com.google.javascript.rhino.JSDocInfoBuilder(true);
        boolean boolean4 = jSDocInfoBuilder1.recordParameterDescription("function (): ?", "hi!");
        boolean boolean6 = jSDocInfoBuilder1.addReference("Not declared as a constructor");
        boolean boolean7 = jSDocInfoBuilder1.recordPreserveTry();
        java.util.List<java.lang.String> strList10 = null;
        java.lang.String[] strArray19 = new java.lang.String[] { "DiagnosticGroup<checkRegExp>", ": ", "", "", "hi!", ".  at hi! line (unknown line) : 0" };
        java.util.ArrayList<java.lang.String> strList20 = new java.util.ArrayList<java.lang.String>();
        boolean boolean21 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strList20, strArray19);
        java.lang.String[] strArray23 = new java.lang.String[] { "./" };
        java.util.ArrayList<java.lang.String> strList24 = new java.util.ArrayList<java.lang.String>();
        boolean boolean25 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strList24, strArray23);
        com.google.javascript.jscomp.deps.SimpleDependencyInfo simpleDependencyInfo26 = new com.google.javascript.jscomp.deps.SimpleDependencyInfo("./", ": ", (java.util.List<java.lang.String>) strList20, (java.util.List<java.lang.String>) strList24);
        com.google.javascript.jscomp.deps.SimpleDependencyInfo simpleDependencyInfo27 = new com.google.javascript.jscomp.deps.SimpleDependencyInfo("", "", strList10, (java.util.List<java.lang.String>) strList24);
        try {
            boolean boolean28 = jSDocInfoBuilder1.recordTemplateTypeNames(strList10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(strArray19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(strArray23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        com.google.javascript.rhino.Node node1 = new com.google.javascript.rhino.Node(10);
        com.google.javascript.rhino.Node node3 = new com.google.javascript.rhino.Node(10);
        boolean boolean4 = node1.isEquivalentToTyped(node3);
        java.lang.String str5 = node1.getQualifiedName();
        node1.setWasEmptyNode(false);
        boolean boolean8 = node1.isDo();
        com.google.javascript.rhino.Node node10 = new com.google.javascript.rhino.Node(10);
        com.google.javascript.rhino.Node node12 = new com.google.javascript.rhino.Node(10);
        boolean boolean13 = node10.isEquivalentToTyped(node12);
        java.lang.String str14 = node10.getQualifiedName();
        node10.setWasEmptyNode(false);
        boolean boolean17 = node10.isDo();
        com.google.javascript.rhino.Node node19 = new com.google.javascript.rhino.Node(10);
        com.google.javascript.rhino.Node node21 = new com.google.javascript.rhino.Node(10);
        boolean boolean22 = node19.isEquivalentToTyped(node21);
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.IR.exprResult(node21);
        com.google.javascript.rhino.Node node24 = node10.useSourceInfoIfMissingFrom(node21);
        com.google.javascript.rhino.Node node25 = node10.cloneTree();
        com.google.javascript.rhino.Node node26 = node1.copyInformationFrom(node10);
        com.google.javascript.rhino.Node node29 = new com.google.javascript.rhino.Node(10);
        com.google.javascript.rhino.Node node31 = new com.google.javascript.rhino.Node(10);
        com.google.javascript.rhino.Node node32 = node31.cloneTree();
        com.google.javascript.rhino.Node node33 = node29.clonePropsFrom(node32);
        com.google.javascript.jscomp.DiagnosticType diagnosticType36 = com.google.javascript.jscomp.DiagnosticType.error("", "");
        com.google.javascript.jscomp.DiagnosticType diagnosticType42 = com.google.javascript.jscomp.DiagnosticType.error("", "");
        java.lang.String str43 = diagnosticType42.toString();
        java.lang.String[] strArray46 = new java.lang.String[] { "", "" };
        com.google.javascript.jscomp.JSError jSError47 = com.google.javascript.jscomp.JSError.make("hi!", (-1), 0, diagnosticType42, strArray46);
        com.google.javascript.jscomp.JSError jSError48 = com.google.javascript.jscomp.JSError.make("hi!", node29, diagnosticType36, strArray46);
        com.google.javascript.rhino.Node node49 = node10.srcref(node29);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertNotNull(node32);
        org.junit.Assert.assertNotNull(node33);
        org.junit.Assert.assertNotNull(diagnosticType36);
        org.junit.Assert.assertNotNull(diagnosticType42);
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + ": " + "'", str43.equals(": "));
        org.junit.Assert.assertNotNull(strArray46);
        org.junit.Assert.assertNotNull(jSError47);
        org.junit.Assert.assertNotNull(jSError48);
        org.junit.Assert.assertNotNull(node49);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.exportTestFunctions;
        boolean boolean2 = compilerOptions0.recordFunctionInformation;
        compilerOptions0.optimizeParameters = false;
        boolean boolean5 = compilerOptions0.devirtualizePrototypeMethods;
        compilerOptions0.setCrossModuleCodeMotion(true);
        compilerOptions0.setPropertyAffinity(false);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setCheckTypes(false);
        compilerOptions0.optimizeReturns = true;
        compilerOptions0.setFlowSensitiveInlineVariables(false);
        com.google.common.collect.Multimap<com.google.javascript.jscomp.CustomPassExecutionTime, com.google.javascript.jscomp.CompilerPass> customPassExecutionTimeMultimap7 = null;
        compilerOptions0.customPasses = customPassExecutionTimeMultimap7;
        compilerOptions0.setRemoveUnusedClassProperties(true);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setCheckTypes(false);
        com.google.javascript.jscomp.CompilerOptions.LanguageMode languageMode3 = compilerOptions0.getLanguageOut();
        compilerOptions0.setInlineLocalVariables(false);
        compilerOptions0.setTightenTypes(true);
        compilerOptions0.setGroupVariableDeclarations(false);
        boolean boolean10 = compilerOptions0.aliasKeywords;
        compilerOptions0.setColorizeErrorOutput(false);
        org.junit.Assert.assertNull(languageMode3);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        com.google.javascript.rhino.JSDocInfo.Visibility visibility0 = com.google.javascript.rhino.JSDocInfo.Visibility.PROTECTED;
        org.junit.Assert.assertTrue("'" + visibility0 + "' != '" + com.google.javascript.rhino.JSDocInfo.Visibility.PROTECTED + "'", visibility0.equals(com.google.javascript.rhino.JSDocInfo.Visibility.PROTECTED));
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        com.google.javascript.rhino.JSDocInfoBuilder jSDocInfoBuilder1 = new com.google.javascript.rhino.JSDocInfoBuilder(true);
        jSDocInfoBuilder1.markAnnotation("Not declared as a constructor", (int) (byte) 100, 40);
        boolean boolean6 = jSDocInfoBuilder1.recordNoShadow();
        com.google.javascript.rhino.JSDocInfoBuilder jSDocInfoBuilder8 = new com.google.javascript.rhino.JSDocInfoBuilder(true);
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.IR.number((double) (byte) 10);
        boolean boolean11 = node10.isStringKey();
        com.google.javascript.rhino.JSTypeExpression jSTypeExpression13 = new com.google.javascript.rhino.JSTypeExpression(node10, "");
        boolean boolean14 = jSTypeExpression13.isVarArgs();
        boolean boolean15 = jSDocInfoBuilder8.recordBaseType(jSTypeExpression13);
        boolean boolean16 = jSTypeExpression13.isVarArgs();
        boolean boolean17 = jSDocInfoBuilder1.recordThrowType(jSTypeExpression13);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        com.google.javascript.rhino.Node node1 = new com.google.javascript.rhino.Node(10);
        com.google.javascript.rhino.Node node2 = node1.cloneTree();
        node1.setType((int) '#');
        com.google.javascript.jscomp.SourceMap.DetailLevel detailLevel5 = com.google.javascript.jscomp.SourceMap.DetailLevel.ALL;
        com.google.javascript.rhino.Node node8 = new com.google.javascript.rhino.Node(10);
        com.google.javascript.rhino.Node node10 = new com.google.javascript.rhino.Node(10);
        boolean boolean11 = node8.isEquivalentToTyped(node10);
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node(10);
        com.google.javascript.rhino.Node node15 = new com.google.javascript.rhino.Node(10);
        boolean boolean16 = node13.isEquivalentToTyped(node15);
        java.lang.String str17 = node13.getQualifiedName();
        com.google.javascript.rhino.Node node18 = node10.srcrefTree(node13);
        boolean boolean19 = node10.isTrue();
        com.google.javascript.rhino.Node node22 = com.google.javascript.rhino.Node.newString((int) (short) -1, "");
        boolean boolean23 = node22.isObjectLit();
        com.google.javascript.rhino.Node node25 = new com.google.javascript.rhino.Node(10);
        com.google.javascript.rhino.Node node27 = new com.google.javascript.rhino.Node(10);
        com.google.javascript.rhino.Node node28 = node27.cloneTree();
        com.google.javascript.rhino.Node node29 = node25.clonePropsFrom(node28);
        com.google.javascript.rhino.Node node32 = com.google.javascript.rhino.Node.newString((int) (short) -1, "");
        boolean boolean33 = node32.isObjectLit();
        com.google.javascript.rhino.Node node34 = node32.cloneTree();
        com.google.javascript.rhino.Node node35 = new com.google.javascript.rhino.Node((int) (byte) 0, node10, node22, node25, node34);
        boolean boolean36 = detailLevel5.apply(node10);
        int int37 = node1.getIndexOfChild(node10);
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertNotNull(detailLevel5);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNotNull(node32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(node34);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + (-1) + "'", int37 == (-1));
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.Region region3 = compiler0.getSourceRegion(": ", (int) (byte) -1);
        com.google.javascript.jscomp.Scope scope4 = compiler0.getTopScope();
        java.nio.charset.Charset charset6 = null;
        com.google.javascript.jscomp.SourceFile sourceFile7 = com.google.javascript.jscomp.SourceFile.fromFile(": ", charset6);
        java.lang.String str8 = sourceFile7.getOriginalPath();
        com.google.javascript.rhino.Node node9 = compiler0.parse(sourceFile7);
        java.lang.String str10 = sourceFile7.getOriginalPath();
        com.google.javascript.jscomp.CompilerInput compilerInput12 = new com.google.javascript.jscomp.CompilerInput(sourceFile7, false);
        java.lang.String str14 = compilerInput12.getLine(0);
        compilerInput12.clearAst();
        com.google.javascript.jscomp.SourceAst sourceAst16 = compilerInput12.getSourceAst();
        java.lang.String str17 = compilerInput12.getName();
        org.junit.Assert.assertNull(region3);
        org.junit.Assert.assertNull(scope4);
        org.junit.Assert.assertNotNull(sourceFile7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + ": " + "'", str8.equals(": "));
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + ": " + "'", str10.equals(": "));
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNotNull(sourceAst16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + ": " + "'", str17.equals(": "));
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.MessageFormatter messageFormatter1 = null;
        java.util.logging.Logger logger2 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager3 = new com.google.javascript.jscomp.LoggerErrorManager(messageFormatter1, logger2);
        compiler0.setErrorManager((com.google.javascript.jscomp.ErrorManager) loggerErrorManager3);
        com.google.javascript.jscomp.ErrorManager errorManager5 = compiler0.getErrorManager();
        double double6 = compiler0.getProgress();
        com.google.javascript.jscomp.JSError[] jSErrorArray7 = compiler0.getWarnings();
        com.google.javascript.jscomp.CompilerOptions.LanguageMode languageMode8 = compiler0.languageMode();
        com.google.javascript.jscomp.Compiler.IntermediateState intermediateState9 = compiler0.getState();
        org.junit.Assert.assertNotNull(errorManager5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(jSErrorArray7);
        org.junit.Assert.assertTrue("'" + languageMode8 + "' != '" + com.google.javascript.jscomp.CompilerOptions.LanguageMode.ECMASCRIPT3 + "'", languageMode8.equals(com.google.javascript.jscomp.CompilerOptions.LanguageMode.ECMASCRIPT3));
        org.junit.Assert.assertNotNull(intermediateState9);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.thisNode();
        org.junit.Assert.assertNotNull(node0);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope2 = null;
        jSTypeRegistry1.resolveTypesInScope(jSTypeStaticScope2);
        com.google.javascript.rhino.ErrorReporter errorReporter4 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter4);
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope6 = null;
        jSTypeRegistry5.resolveTypesInScope(jSTypeStaticScope6);
        com.google.javascript.rhino.jstype.JSType jSType8 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray9 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList10 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean11 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList10, jSTypeArray9);
        com.google.javascript.rhino.jstype.FunctionType functionType12 = jSTypeRegistry5.createFunctionType(jSType8, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList10);
        com.google.javascript.rhino.JSDocInfo jSDocInfo14 = functionType12.getOwnPropertyJSDocInfo("");
        com.google.javascript.rhino.ErrorReporter errorReporter15 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry16 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter15);
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope17 = null;
        jSTypeRegistry16.resolveTypesInScope(jSTypeStaticScope17);
        com.google.javascript.rhino.jstype.JSType jSType19 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray20 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList21 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean22 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList21, jSTypeArray20);
        com.google.javascript.rhino.jstype.FunctionType functionType23 = jSTypeRegistry16.createFunctionType(jSType19, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList21);
        com.google.javascript.rhino.JSDocInfo jSDocInfo25 = functionType23.getOwnPropertyJSDocInfo("");
        com.google.javascript.rhino.jstype.ObjectType objectType26 = functionType23.getImplicitPrototype();
        boolean boolean27 = objectType26.hasCachedValues();
        com.google.javascript.rhino.ErrorReporter errorReporter28 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry29 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter28);
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope30 = null;
        jSTypeRegistry29.resolveTypesInScope(jSTypeStaticScope30);
        com.google.javascript.rhino.jstype.JSType jSType32 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray33 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList34 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean35 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList34, jSTypeArray33);
        com.google.javascript.rhino.jstype.FunctionType functionType36 = jSTypeRegistry29.createFunctionType(jSType32, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList34);
        com.google.javascript.rhino.JSDocInfo jSDocInfo38 = functionType36.getOwnPropertyJSDocInfo("");
        boolean boolean40 = functionType36.removeProperty(".  at hi! line (unknown line) : 0");
        com.google.javascript.rhino.ErrorReporter errorReporter41 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry42 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter41);
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope43 = null;
        jSTypeRegistry42.resolveTypesInScope(jSTypeStaticScope43);
        com.google.javascript.rhino.jstype.JSType jSType45 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray46 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList47 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean48 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList47, jSTypeArray46);
        com.google.javascript.rhino.jstype.FunctionType functionType49 = jSTypeRegistry42.createFunctionType(jSType45, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList47);
        com.google.javascript.rhino.ErrorReporter errorReporter50 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry51 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter50);
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope52 = null;
        jSTypeRegistry51.resolveTypesInScope(jSTypeStaticScope52);
        com.google.javascript.rhino.jstype.JSType jSType54 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray55 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList56 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean57 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList56, jSTypeArray55);
        com.google.javascript.rhino.jstype.FunctionType functionType58 = jSTypeRegistry51.createFunctionType(jSType54, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList56);
        com.google.javascript.rhino.JSDocInfo jSDocInfo60 = functionType58.getOwnPropertyJSDocInfo("");
        com.google.javascript.rhino.ErrorReporter errorReporter61 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry62 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter61);
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope63 = null;
        jSTypeRegistry62.resolveTypesInScope(jSTypeStaticScope63);
        com.google.javascript.rhino.jstype.JSType jSType65 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray66 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList67 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean68 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList67, jSTypeArray66);
        com.google.javascript.rhino.jstype.FunctionType functionType69 = jSTypeRegistry62.createFunctionType(jSType65, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList67);
        com.google.javascript.rhino.JSDocInfo jSDocInfo71 = functionType69.getOwnPropertyJSDocInfo("");
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray72 = new com.google.javascript.rhino.jstype.JSType[] { objectType26, functionType36, functionType49, functionType58, functionType69 };
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList73 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean74 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList73, jSTypeArray72);
        com.google.javascript.rhino.jstype.FunctionType functionType75 = jSTypeRegistry1.createFunctionTypeWithVarArgs((com.google.javascript.rhino.jstype.JSType) functionType12, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList73);
        com.google.javascript.rhino.ErrorReporter errorReporter76 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry77 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter76);
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope78 = null;
        jSTypeRegistry77.resolveTypesInScope(jSTypeStaticScope78);
        com.google.javascript.rhino.jstype.JSType jSType80 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray81 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList82 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean83 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList82, jSTypeArray81);
        com.google.javascript.rhino.jstype.FunctionType functionType84 = jSTypeRegistry77.createFunctionType(jSType80, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList82);
        com.google.javascript.rhino.JSDocInfo jSDocInfo86 = functionType84.getOwnPropertyJSDocInfo("");
        com.google.javascript.rhino.jstype.ObjectType objectType87 = functionType84.getImplicitPrototype();
        com.google.javascript.rhino.jstype.JSType.TypePair typePair88 = functionType12.getTypesUnderShallowEquality((com.google.javascript.rhino.jstype.JSType) objectType87);
        boolean boolean89 = functionType12.isOrdinaryFunction();
        com.google.javascript.rhino.jstype.EnumElementType enumElementType90 = functionType12.toMaybeEnumElementType();
        boolean boolean91 = functionType12.isResolved();
        boolean boolean92 = functionType12.isRegexpType();
        org.junit.Assert.assertNotNull(jSTypeArray9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(functionType12);
        org.junit.Assert.assertNull(jSDocInfo14);
        org.junit.Assert.assertNotNull(jSTypeArray20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(functionType23);
        org.junit.Assert.assertNull(jSDocInfo25);
        org.junit.Assert.assertNotNull(objectType26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(jSTypeArray33);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(functionType36);
        org.junit.Assert.assertNull(jSDocInfo38);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(jSTypeArray46);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(functionType49);
        org.junit.Assert.assertNotNull(jSTypeArray55);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertNotNull(functionType58);
        org.junit.Assert.assertNull(jSDocInfo60);
        org.junit.Assert.assertNotNull(jSTypeArray66);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertNotNull(functionType69);
        org.junit.Assert.assertNull(jSDocInfo71);
        org.junit.Assert.assertNotNull(jSTypeArray72);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + true + "'", boolean74 == true);
        org.junit.Assert.assertNotNull(functionType75);
        org.junit.Assert.assertNotNull(jSTypeArray81);
        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + false + "'", boolean83 == false);
        org.junit.Assert.assertNotNull(functionType84);
        org.junit.Assert.assertNull(jSDocInfo86);
        org.junit.Assert.assertNotNull(objectType87);
        org.junit.Assert.assertNotNull(typePair88);
        org.junit.Assert.assertTrue("'" + boolean89 + "' != '" + true + "'", boolean89 == true);
        org.junit.Assert.assertNull(enumElementType90);
        org.junit.Assert.assertTrue("'" + boolean91 + "' != '" + false + "'", boolean91 == false);
        org.junit.Assert.assertTrue("'" + boolean92 + "' != '" + false + "'", boolean92 == false);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.MessageFormatter messageFormatter1 = null;
        java.util.logging.Logger logger2 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager3 = new com.google.javascript.jscomp.LoggerErrorManager(messageFormatter1, logger2);
        compiler0.setErrorManager((com.google.javascript.jscomp.ErrorManager) loggerErrorManager3);
        com.google.javascript.jscomp.ErrorManager errorManager5 = compiler0.getErrorManager();
        double double6 = compiler0.getProgress();
        com.google.javascript.jscomp.JSError[] jSErrorArray7 = compiler0.getWarnings();
        com.google.javascript.jscomp.CompilerOptions.LanguageMode languageMode8 = compiler0.languageMode();
        com.google.javascript.jscomp.SourceMap sourceMap9 = compiler0.getSourceMap();
        org.junit.Assert.assertNotNull(errorManager5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(jSErrorArray7);
        org.junit.Assert.assertTrue("'" + languageMode8 + "' != '" + com.google.javascript.jscomp.CompilerOptions.LanguageMode.ECMASCRIPT3 + "'", languageMode8.equals(com.google.javascript.jscomp.CompilerOptions.LanguageMode.ECMASCRIPT3));
        org.junit.Assert.assertNull(sourceMap9);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        com.google.javascript.rhino.Node node2 = new com.google.javascript.rhino.Node(10);
        com.google.javascript.rhino.Node node3 = node2.cloneTree();
        com.google.javascript.jscomp.DiagnosticType diagnosticType6 = com.google.javascript.jscomp.DiagnosticType.error("", "");
        com.google.javascript.jscomp.DiagnosticType diagnosticType12 = com.google.javascript.jscomp.DiagnosticType.error("", "");
        java.lang.String str13 = diagnosticType12.toString();
        java.lang.String[] strArray16 = new java.lang.String[] { "", "" };
        com.google.javascript.jscomp.JSError jSError17 = com.google.javascript.jscomp.JSError.make("hi!", (-1), 0, diagnosticType12, strArray16);
        com.google.javascript.jscomp.JSError jSError18 = com.google.javascript.jscomp.JSError.make("hi!", node2, diagnosticType6, strArray16);
        com.google.javascript.rhino.Node node20 = new com.google.javascript.rhino.Node(10);
        com.google.javascript.rhino.Node node22 = new com.google.javascript.rhino.Node(10);
        boolean boolean23 = node20.isEquivalentToTyped(node22);
        node2.addChildToFront(node20);
        boolean boolean25 = node20.isLabel();
        java.lang.String str26 = com.google.javascript.jscomp.NodeUtil.getNearestFunctionName(node20);
        com.google.javascript.rhino.Node node29 = new com.google.javascript.rhino.Node(10);
        com.google.javascript.rhino.Node node30 = node29.cloneTree();
        com.google.javascript.jscomp.DiagnosticType diagnosticType33 = com.google.javascript.jscomp.DiagnosticType.error("", "");
        com.google.javascript.jscomp.DiagnosticType diagnosticType39 = com.google.javascript.jscomp.DiagnosticType.error("", "");
        java.lang.String str40 = diagnosticType39.toString();
        java.lang.String[] strArray43 = new java.lang.String[] { "", "" };
        com.google.javascript.jscomp.JSError jSError44 = com.google.javascript.jscomp.JSError.make("hi!", (-1), 0, diagnosticType39, strArray43);
        com.google.javascript.jscomp.JSError jSError45 = com.google.javascript.jscomp.JSError.make("hi!", node29, diagnosticType33, strArray43);
        com.google.javascript.rhino.Node node47 = new com.google.javascript.rhino.Node(10);
        com.google.javascript.rhino.Node node49 = new com.google.javascript.rhino.Node(10);
        boolean boolean50 = node47.isEquivalentToTyped(node49);
        node29.addChildToFront(node47);
        int int52 = node29.getCharno();
        com.google.javascript.rhino.Node node53 = node20.srcref(node29);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(diagnosticType6);
        org.junit.Assert.assertNotNull(diagnosticType12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + ": " + "'", str13.equals(": "));
        org.junit.Assert.assertNotNull(strArray16);
        org.junit.Assert.assertNotNull(jSError17);
        org.junit.Assert.assertNotNull(jSError18);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNull(str26);
        org.junit.Assert.assertNotNull(node30);
        org.junit.Assert.assertNotNull(diagnosticType33);
        org.junit.Assert.assertNotNull(diagnosticType39);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + ": " + "'", str40.equals(": "));
        org.junit.Assert.assertNotNull(strArray43);
        org.junit.Assert.assertNotNull(jSError44);
        org.junit.Assert.assertNotNull(jSError45);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + true + "'", boolean50 == true);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + (-1) + "'", int52 == (-1));
        org.junit.Assert.assertNotNull(node53);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.Node.newString((int) (short) -1, "");
        boolean boolean3 = node2.isThrow();
        com.google.javascript.rhino.Node node5 = new com.google.javascript.rhino.Node(10);
        com.google.javascript.rhino.Node node7 = new com.google.javascript.rhino.Node(10);
        boolean boolean8 = node5.isEquivalentToTyped(node7);
        boolean boolean9 = node5.isOnlyModifiesThisCall();
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.IR.throwNode(node5);
        com.google.javascript.rhino.Node node11 = node2.useSourceInfoIfMissingFrom(node5);
        int int12 = node5.getSourceOffset();
        com.google.javascript.rhino.Node node14 = new com.google.javascript.rhino.Node(10);
        com.google.javascript.rhino.Node node16 = new com.google.javascript.rhino.Node(10);
        boolean boolean17 = node14.isEquivalentToTyped(node16);
        com.google.javascript.rhino.Node node19 = new com.google.javascript.rhino.Node(10);
        com.google.javascript.rhino.Node node21 = new com.google.javascript.rhino.Node(10);
        boolean boolean22 = node19.isEquivalentToTyped(node21);
        java.lang.String str23 = node19.getQualifiedName();
        com.google.javascript.rhino.Node node24 = node16.srcrefTree(node19);
        boolean boolean25 = node16.isTrue();
        int int26 = node5.getIndexOfChild(node16);
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNull(str23);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.INVALID_CASTS;
        com.google.javascript.jscomp.DiagnosticGroups.CHECK_USELESS_CODE = diagnosticGroup0;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope2 = null;
        jSTypeRegistry1.resolveTypesInScope(jSTypeStaticScope2);
        com.google.javascript.rhino.jstype.JSType jSType4 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray5 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList6 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean7 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList6, jSTypeArray5);
        com.google.javascript.rhino.jstype.FunctionType functionType8 = jSTypeRegistry1.createFunctionType(jSType4, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList6);
        boolean boolean9 = functionType8.hasInstanceType();
        int int10 = functionType8.getMinArguments();
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable11 = functionType8.getAllImplementedInterfaces();
        com.google.javascript.rhino.jstype.ObjectType objectType12 = functionType8.getTypeOfThis();
        org.junit.Assert.assertNotNull(jSTypeArray5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(functionType8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(objectTypeIterable11);
        org.junit.Assert.assertNotNull(objectType12);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        com.google.javascript.jscomp.JSModule jSModule1 = new com.google.javascript.jscomp.JSModule("Not declared as a type name");
        java.util.List<java.lang.String> strList2 = jSModule1.getRequires();
        com.google.javascript.jscomp.JSModule jSModule4 = new com.google.javascript.jscomp.JSModule("Not declared as a type name");
        java.util.List<java.lang.String> strList5 = jSModule4.getRequires();
        com.google.javascript.jscomp.JSModule jSModule7 = new com.google.javascript.jscomp.JSModule("Not declared as a type name");
        com.google.javascript.jscomp.JSModule[] jSModuleArray8 = new com.google.javascript.jscomp.JSModule[] { jSModule1, jSModule4, jSModule7 };
        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList9 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
        boolean boolean10 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList9, jSModuleArray8);
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph11 = new com.google.javascript.jscomp.JSModuleGraph((java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList9);
        org.junit.Assert.assertNotNull(strList2);
        org.junit.Assert.assertNotNull(strList5);
        org.junit.Assert.assertNotNull(jSModuleArray8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        com.google.javascript.jscomp.DiagnosticType diagnosticType2 = com.google.javascript.jscomp.DiagnosticType.disabled("module$DiagnosticGroup<checkRegExp>", ".  at hi! line (unknown line) : 0");
        java.lang.String str3 = diagnosticType2.key;
        java.lang.String str4 = diagnosticType2.key;
        org.junit.Assert.assertNotNull(diagnosticType2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "module$DiagnosticGroup<checkRegExp>" + "'", str3.equals("module$DiagnosticGroup<checkRegExp>"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "module$DiagnosticGroup<checkRegExp>" + "'", str4.equals("module$DiagnosticGroup<checkRegExp>"));
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.exportTestFunctions;
        compilerOptions0.inlineFunctions = true;
        compilerOptions0.setSyntheticBlockEndMarker("module$.  at hi! line (unknown line) : 0");
        boolean boolean6 = compilerOptions0.closurePass;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setCheckTypes(false);
        com.google.javascript.jscomp.CompilerOptions.LanguageMode languageMode3 = compilerOptions0.getLanguageOut();
        compilerOptions0.setInlineLocalVariables(false);
        compilerOptions0.setTightenTypes(true);
        compilerOptions0.setRemoveUnusedPrototypeProperties(false);
        compilerOptions0.setSourceMapOutputPath("function ({-444333608}, function (): {516604112}, function (): {288925563}, function (): {511411474}, {(function (): {1085384306},{424560384})}): function (): {1063088224}");
        org.junit.Assert.assertNull(languageMode3);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        com.google.javascript.rhino.Node node1 = new com.google.javascript.rhino.Node(10);
        com.google.javascript.rhino.Node node3 = new com.google.javascript.rhino.Node(10);
        com.google.javascript.rhino.Node node4 = node3.cloneTree();
        com.google.javascript.rhino.Node node5 = node1.clonePropsFrom(node4);
        node4.setLineno((int) (byte) -1);
        boolean boolean8 = node4.isSyntheticBlock();
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder9 = node4.getJsDocBuilderForNode();
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder9);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        com.google.javascript.jscomp.ClosureCodingConvention.AssertInstanceofSpec assertInstanceofSpec1 = new com.google.javascript.jscomp.ClosureCodingConvention.AssertInstanceofSpec("");
        com.google.javascript.rhino.Node node3 = new com.google.javascript.rhino.Node(10);
        com.google.javascript.rhino.Node node5 = new com.google.javascript.rhino.Node(10);
        boolean boolean6 = node3.isEquivalentToTyped(node5);
        com.google.javascript.rhino.Node node7 = assertInstanceofSpec1.getAssertedParam(node5);
        int int8 = node5.getSideEffectFlags();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setDeadAssignmentElimination(false);
        compilerOptions0.ideMode = true;
        boolean boolean5 = compilerOptions0.preferLineBreakAtEndOfFile;
        compilerOptions0.setRenamePrefix("");
        boolean boolean8 = compilerOptions0.closurePass;
        boolean boolean9 = compilerOptions0.recordFunctionInformation;
        compilerOptions0.flowSensitiveInlineVariables = false;
        com.google.javascript.jscomp.CompilerOptions compilerOptions12 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean13 = compilerOptions12.exportTestFunctions;
        com.google.javascript.jscomp.AnonymousFunctionNamingPolicy anonymousFunctionNamingPolicy14 = compilerOptions12.anonymousFunctionNaming;
        com.google.javascript.jscomp.parsing.Config.LanguageMode languageMode16 = null;
        java.lang.String[] strArray20 = new java.lang.String[] { "", "" };
        java.util.LinkedHashSet<java.lang.String> strSet21 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean22 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet21, strArray20);
        com.google.javascript.jscomp.parsing.Config config23 = com.google.javascript.jscomp.parsing.ParserRunner.createConfig(true, languageMode16, false, (java.util.Set<java.lang.String>) strSet21);
        compilerOptions12.setStripTypes((java.util.Set<java.lang.String>) strSet21);
        compilerOptions12.collapseProperties = true;
        com.google.javascript.jscomp.CompilerOptions.AliasTransformationHandler aliasTransformationHandler27 = compilerOptions12.getAliasTransformationHandler();
        compilerOptions0.setAliasTransformationHandler(aliasTransformationHandler27);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + anonymousFunctionNamingPolicy14 + "' != '" + com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF + "'", anonymousFunctionNamingPolicy14.equals(com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF));
        org.junit.Assert.assertNotNull(strArray20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(config23);
        org.junit.Assert.assertNotNull(aliasTransformationHandler27);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        com.google.javascript.rhino.Node node1 = new com.google.javascript.rhino.Node(10);
        com.google.javascript.rhino.Node node3 = new com.google.javascript.rhino.Node(10);
        com.google.javascript.rhino.Node node4 = node3.cloneTree();
        com.google.javascript.rhino.Node node5 = node1.clonePropsFrom(node4);
        boolean boolean6 = node1.isSyntheticBlock();
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup8 = com.google.javascript.jscomp.DiagnosticGroups.TYPE_INVALIDATION;
        node1.putProp(32, (java.lang.Object) diagnosticGroup8);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(diagnosticGroup8);
    }
}

