import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        com.google.javascript.jscomp.JSModule jSModule3 = new com.google.javascript.jscomp.JSModule("hi!");
        java.util.List<java.lang.String> strList4 = jSModule3.getProvides();
        com.google.javascript.jscomp.JSModule jSModule6 = new com.google.javascript.jscomp.JSModule("hi!");
        java.util.List<java.lang.String> strList7 = jSModule6.getProvides();
        com.google.javascript.jscomp.deps.SimpleDependencyInfo simpleDependencyInfo8 = new com.google.javascript.jscomp.deps.SimpleDependencyInfo("", "GETELEM", strList4, strList7);
        java.lang.String str9 = simpleDependencyInfo8.getName();
        java.lang.String str10 = simpleDependencyInfo8.toString();
        java.lang.Object obj11 = null;
        boolean boolean12 = simpleDependencyInfo8.equals(obj11);
        org.junit.Assert.assertNotNull(strList4);
        org.junit.Assert.assertNotNull(strList7);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "GETELEM" + "'", str9.equals("GETELEM"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "DependencyInfo(relativePath='', path='GETELEM', provides=[hi!], requires=[hi!])" + "'", str10.equals("DependencyInfo(relativePath='', path='GETELEM', provides=[hi!], requires=[hi!])"));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, true);
        com.google.javascript.rhino.jstype.JSType jSType7 = jSTypeRegistry2.createNamedType("GETELEM", "hi!", 0, 38);
        jSTypeRegistry2.incrementGeneration();
        com.google.javascript.rhino.ErrorReporter errorReporter9 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry11 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter9, true);
        com.google.javascript.rhino.ErrorReporter errorReporter12 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry14 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter12, true);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative15 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative16 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative17 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray18 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative15, jSTypeNative16, jSTypeNative17 };
        com.google.javascript.rhino.jstype.JSType jSType19 = jSTypeRegistry14.createUnionType(jSTypeNativeArray18);
        boolean boolean20 = jSType19.isRegexpType();
        boolean boolean21 = jSType19.isNullable();
        com.google.javascript.rhino.ErrorReporter errorReporter22 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry24 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter22, true);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative25 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative26 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative27 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray28 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative25, jSTypeNative26, jSTypeNative27 };
        com.google.javascript.rhino.jstype.JSType jSType29 = jSTypeRegistry24.createUnionType(jSTypeNativeArray28);
        com.google.javascript.rhino.ErrorReporter errorReporter30 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry32 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter30, true);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative33 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative34 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative35 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray36 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative33, jSTypeNative34, jSTypeNative35 };
        com.google.javascript.rhino.jstype.JSType jSType37 = jSTypeRegistry32.createUnionType(jSTypeNativeArray36);
        com.google.javascript.rhino.JSDocInfo jSDocInfo38 = jSType37.getJSDocInfo();
        com.google.javascript.rhino.jstype.ObjectType objectType39 = jSType37.toObjectType();
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray40 = new com.google.javascript.rhino.jstype.JSType[] { jSType29, jSType37 };
        com.google.javascript.rhino.jstype.FunctionType functionType41 = jSTypeRegistry11.createConstructorTypeWithVarArgs(jSType19, jSTypeArray40);
        java.lang.Iterable iterable42 = functionType41.getCtorImplementedInterfaces();
        jSTypeRegistry2.resolveTypesInScope((com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType>) functionType41);
        boolean boolean44 = functionType41.isNativeObjectType();
        boolean boolean45 = functionType41.canBeCalled();
        com.google.common.collect.ImmutableList<java.lang.String> strList46 = functionType41.getTemplateTypeNames();
        boolean boolean47 = functionType41.isString();
        java.util.Set<java.lang.String> strSet48 = functionType41.getOwnPropertyNames();
        com.google.javascript.rhino.jstype.JSType jSType50 = functionType41.findPropertyType("module$GETELEM");
        org.junit.Assert.assertNotNull(jSType7);
        org.junit.Assert.assertTrue("'" + jSTypeNative15 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative15.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative16 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative16.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative17 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative17.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray18);
        org.junit.Assert.assertNotNull(jSType19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + jSTypeNative25 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative25.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative26 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative26.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative27 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative27.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray28);
        org.junit.Assert.assertNotNull(jSType29);
        org.junit.Assert.assertTrue("'" + jSTypeNative33 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative33.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative34 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative34.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative35 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative35.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray36);
        org.junit.Assert.assertNotNull(jSType37);
        org.junit.Assert.assertNull(jSDocInfo38);
        org.junit.Assert.assertNull(objectType39);
        org.junit.Assert.assertNotNull(jSTypeArray40);
        org.junit.Assert.assertNotNull(functionType41);
        org.junit.Assert.assertNotNull(iterable42);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
        org.junit.Assert.assertNotNull(strList46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(strSet48);
        org.junit.Assert.assertNull(jSType50);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newNumber((double) (short) -1, (int) (byte) 1, 0);
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newNumber((double) (short) -1, (int) (byte) 1, 0);
        boolean boolean9 = node8.isArrayLit();
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newNumber((double) (short) -1, (int) (byte) 1, 0);
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.IR.getelem(node8, node13);
        com.google.javascript.rhino.Node node15 = node4.copyInformationFrom(node14);
        com.google.javascript.rhino.Node node16 = node14.cloneNode();
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder17 = node14.getJsDocBuilderForNode();
        boolean boolean18 = node14.isHook();
        com.google.javascript.rhino.Node node21 = new com.google.javascript.rhino.Node(45, node14, 38, 30);
        int int22 = node21.getCharno();
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 30 + "'", int22 == 30);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.REGEXP_FUNCTION_TYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.REGEXP_FUNCTION_TYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.REGEXP_FUNCTION_TYPE));
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.NULL_VOID;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.NULL_VOID + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.NULL_VOID));
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        int int0 = com.google.javascript.rhino.Node.INCRDECR_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 32 + "'", int0 == 32);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString(10, "hi!");
        com.google.javascript.rhino.Node node4 = new com.google.javascript.rhino.Node(4, node3);
        com.google.javascript.rhino.ErrorReporter errorReporter6 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry8 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter6, true);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative9 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative10 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative11 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray12 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative9, jSTypeNative10, jSTypeNative11 };
        com.google.javascript.rhino.jstype.JSType jSType13 = jSTypeRegistry8.createUnionType(jSTypeNativeArray12);
        jSTypeRegistry8.clearTemplateTypeNames();
        com.google.javascript.rhino.ErrorReporter errorReporter15 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry17 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter15, true);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative18 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative19 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative20 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray21 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative18, jSTypeNative19, jSTypeNative20 };
        com.google.javascript.rhino.jstype.JSType jSType22 = jSTypeRegistry17.createUnionType(jSTypeNativeArray21);
        com.google.javascript.rhino.ErrorReporter errorReporter23 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry25 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter23, true);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative26 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative27 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative28 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray29 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative26, jSTypeNative27, jSTypeNative28 };
        com.google.javascript.rhino.jstype.JSType jSType30 = jSTypeRegistry25.createUnionType(jSTypeNativeArray29);
        boolean boolean31 = jSType30.isRegexpType();
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray32 = new com.google.javascript.rhino.jstype.JSType[] { jSType30 };
        com.google.javascript.rhino.jstype.JSType jSType33 = jSTypeRegistry17.createUnionType(jSTypeArray32);
        com.google.javascript.rhino.Node node34 = jSTypeRegistry8.createParameters(jSTypeArray32);
        com.google.javascript.rhino.Node node38 = com.google.javascript.rhino.Node.newNumber(0.0d, 1, (-1));
        com.google.javascript.rhino.Node node39 = new com.google.javascript.rhino.Node((int) '#', node34, node38);
        boolean boolean40 = node38.hasChildren();
        boolean boolean41 = node38.isTypeOf();
        try {
            node4.removeChild(node38);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: node is not a child");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + jSTypeNative9 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative9.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative10 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative10.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative11 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative11.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray12);
        org.junit.Assert.assertNotNull(jSType13);
        org.junit.Assert.assertTrue("'" + jSTypeNative18 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative18.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative19 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative19.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative20 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative20.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray21);
        org.junit.Assert.assertNotNull(jSType22);
        org.junit.Assert.assertTrue("'" + jSTypeNative26 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative26.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative27 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative27.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative28 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative28.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray29);
        org.junit.Assert.assertNotNull(jSType30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(jSTypeArray32);
        org.junit.Assert.assertNotNull(jSType33);
        org.junit.Assert.assertNotNull(node34);
        org.junit.Assert.assertNotNull(node38);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newNumber((double) (short) -1, (int) (byte) 1, 0);
        boolean boolean4 = node3.isArrayLit();
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newNumber((double) (short) -1, (int) (byte) 1, 0);
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.IR.getelem(node3, node8);
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.Node.newNumber((double) (short) -1, (int) (byte) 1, 0);
        boolean boolean15 = node14.isArrayLit();
        boolean boolean16 = node14.isLabelName();
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.Node.newNumber((double) (short) -1, (int) (byte) 1, 0);
        boolean boolean21 = node20.isArrayLit();
        com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.Node.newNumber((double) (short) -1, (int) (byte) 1, 0);
        com.google.javascript.rhino.Node node26 = new com.google.javascript.rhino.Node((int) '#', node14, node20, node25);
        com.google.javascript.rhino.Node node28 = com.google.javascript.rhino.Node.newNumber(0.0d);
        com.google.javascript.rhino.Node node29 = node14.copyInformationFromForTree(node28);
        com.google.javascript.rhino.Node node30 = node3.copyInformationFrom(node29);
        com.google.javascript.rhino.Node node32 = com.google.javascript.rhino.IR.stringKey("");
        boolean boolean33 = node29.isEquivalentToTyped(node32);
        node32.addSuppression("{proxy:function ({1566169663}, {({1804413486},{656799354})}): {1133890062}}");
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNotNull(node30);
        org.junit.Assert.assertNotNull(node32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        com.google.javascript.jscomp.SourceFile sourceFile4 = com.google.javascript.jscomp.SourceFile.fromCode("hi!", "Unknown class name", "Unknown class name");
        java.io.Reader reader5 = sourceFile4.getCodeReader();
        com.google.javascript.jscomp.SourceFile sourceFile6 = com.google.javascript.jscomp.SourceFile.fromReader("function ({973952929}, {({834630149},{962344528})}): {100783531}", reader5);
        org.junit.Assert.assertNotNull(sourceFile4);
        org.junit.Assert.assertNotNull(reader5);
        org.junit.Assert.assertNotNull(sourceFile6);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention0 = new com.google.javascript.jscomp.GoogleCodingConvention();
        boolean boolean2 = googleCodingConvention0.isConstantKey("hi!");
        boolean boolean4 = googleCodingConvention0.isExported("GETELEM");
        java.lang.String str5 = googleCodingConvention0.getAbstractMethodName();
        boolean boolean7 = googleCodingConvention0.isValidEnumKey("module$GETELEM");
        boolean boolean9 = googleCodingConvention0.isValidEnumKey("function ({1202537494}, {({832896807},{1788511964})}): {2020739816}");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "goog.abstractMethod" + "'", str5.equals("goog.abstractMethod"));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.DiagnosticType diagnosticType4 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        com.google.javascript.jscomp.CheckLevel checkLevel5 = null;
        diagnosticType4.level = checkLevel5;
        java.lang.String[] strArray12 = new java.lang.String[] { "GETELEM", "./", "GETELEM", "GETELEM", "NUMBER -1.0 1" };
        com.google.javascript.jscomp.JSError jSError13 = com.google.javascript.jscomp.JSError.make("hi!", 8, (int) (short) 0, diagnosticType4, strArray12);
        com.google.javascript.jscomp.CheckLevel checkLevel14 = jSError13.getDefaultLevel();
        try {
            compiler0.report(jSError13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(diagnosticType4);
        org.junit.Assert.assertNotNull(strArray12);
        org.junit.Assert.assertNotNull(jSError13);
        org.junit.Assert.assertNull(checkLevel14);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.trueNode();
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.IR.exprResult(node1);
        boolean boolean3 = node2.isAssign();
        com.google.javascript.rhino.Node node4 = node2.removeFirstChild();
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.IR.paramList();
        com.google.javascript.rhino.Node node6 = node4.useSourceInfoIfMissingFromForTree(node5);
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newNumber((double) (short) -1, (int) (byte) 1, 0);
        boolean boolean11 = node10.isArrayLit();
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.Node.newNumber((double) (short) -1, (int) (byte) 1, 0);
        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.IR.getelem(node10, node15);
        boolean boolean17 = node16.isCall();
        com.google.javascript.rhino.Node node20 = new com.google.javascript.rhino.Node((int) '4', node5, node16, 48, (int) (short) 100);
        boolean boolean21 = node20.isCall();
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        com.google.javascript.rhino.JSDocInfo jSDocInfo0 = new com.google.javascript.rhino.JSDocInfo();
        boolean boolean1 = jSDocInfo0.isDeprecated();
        int int2 = jSDocInfo0.getExtendedInterfacesCount();
        java.util.Set<java.lang.String> strSet3 = jSDocInfo0.getParameterNames();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(strSet3);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newNumber((double) 29, 130, 4);
        org.junit.Assert.assertNotNull(node3);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newNumber((double) (short) -1, (int) (byte) 1, 0);
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newNumber((double) (short) -1, (int) (byte) 1, 0);
        boolean boolean9 = node8.isArrayLit();
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newNumber((double) (short) -1, (int) (byte) 1, 0);
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.IR.getelem(node8, node13);
        com.google.javascript.rhino.Node node15 = node4.copyInformationFrom(node14);
        com.google.javascript.rhino.Node node16 = node14.cloneNode();
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder17 = node14.getJsDocBuilderForNode();
        boolean boolean18 = node14.isHook();
        com.google.javascript.rhino.Node node21 = new com.google.javascript.rhino.Node(45, node14, 38, 30);
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable22 = node14.siblings();
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(nodeIterable22);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        com.google.javascript.jscomp.AnonymousFunctionNamingPolicy anonymousFunctionNamingPolicy0 = com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.UNMAPPED;
        org.junit.Assert.assertTrue("'" + anonymousFunctionNamingPolicy0 + "' != '" + com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.UNMAPPED + "'", anonymousFunctionNamingPolicy0.equals(com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.UNMAPPED));
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, true);
        com.google.javascript.rhino.ErrorReporter errorReporter3 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter3, true);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative6 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative7 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative8 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray9 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative6, jSTypeNative7, jSTypeNative8 };
        com.google.javascript.rhino.jstype.JSType jSType10 = jSTypeRegistry5.createUnionType(jSTypeNativeArray9);
        boolean boolean11 = jSType10.isRegexpType();
        boolean boolean12 = jSType10.isNullable();
        com.google.javascript.rhino.ErrorReporter errorReporter13 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry15 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter13, true);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative16 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative17 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative18 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray19 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative16, jSTypeNative17, jSTypeNative18 };
        com.google.javascript.rhino.jstype.JSType jSType20 = jSTypeRegistry15.createUnionType(jSTypeNativeArray19);
        com.google.javascript.rhino.ErrorReporter errorReporter21 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry23 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter21, true);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative24 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative25 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative26 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray27 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative24, jSTypeNative25, jSTypeNative26 };
        com.google.javascript.rhino.jstype.JSType jSType28 = jSTypeRegistry23.createUnionType(jSTypeNativeArray27);
        com.google.javascript.rhino.JSDocInfo jSDocInfo29 = jSType28.getJSDocInfo();
        com.google.javascript.rhino.jstype.ObjectType objectType30 = jSType28.toObjectType();
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray31 = new com.google.javascript.rhino.jstype.JSType[] { jSType20, jSType28 };
        com.google.javascript.rhino.jstype.FunctionType functionType32 = jSTypeRegistry2.createConstructorTypeWithVarArgs(jSType10, jSTypeArray31);
        java.lang.Iterable iterable33 = functionType32.getCtorImplementedInterfaces();
        com.google.javascript.rhino.Node node34 = functionType32.getSource();
        com.google.javascript.rhino.jstype.ObjectType objectType36 = com.google.javascript.rhino.jstype.FunctionType.getTopDefiningInterface((com.google.javascript.rhino.jstype.ObjectType) functionType32, "function ({1262020967}, {({954206644},{1279119928})}): {1555607401}");
        boolean boolean37 = functionType32.matchesNumberContext();
        boolean boolean38 = functionType32.hasCachedValues();
        boolean boolean39 = functionType32.hasAnyTemplateInternal();
        org.junit.Assert.assertTrue("'" + jSTypeNative6 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative6.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative7 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative7.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative8 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative8.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray9);
        org.junit.Assert.assertNotNull(jSType10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + jSTypeNative16 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative16.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative17 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative17.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative18 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative18.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray19);
        org.junit.Assert.assertNotNull(jSType20);
        org.junit.Assert.assertTrue("'" + jSTypeNative24 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative24.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative25 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative25.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative26 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative26.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray27);
        org.junit.Assert.assertNotNull(jSType28);
        org.junit.Assert.assertNull(jSDocInfo29);
        org.junit.Assert.assertNull(objectType30);
        org.junit.Assert.assertNotNull(jSTypeArray31);
        org.junit.Assert.assertNotNull(functionType32);
        org.junit.Assert.assertNotNull(iterable33);
        org.junit.Assert.assertNull(node34);
        org.junit.Assert.assertNull(objectType36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        com.google.javascript.jscomp.JSModule jSModule3 = new com.google.javascript.jscomp.JSModule("hi!");
        java.util.List<java.lang.String> strList4 = jSModule3.getProvides();
        com.google.javascript.jscomp.JSModule jSModule6 = new com.google.javascript.jscomp.JSModule("hi!");
        java.util.List<java.lang.String> strList7 = jSModule6.getProvides();
        com.google.javascript.jscomp.deps.SimpleDependencyInfo simpleDependencyInfo8 = new com.google.javascript.jscomp.deps.SimpleDependencyInfo("", "GETELEM", strList4, strList7);
        java.lang.String str9 = simpleDependencyInfo8.getName();
        java.lang.String str10 = simpleDependencyInfo8.toString();
        java.lang.String str11 = simpleDependencyInfo8.getName();
        org.junit.Assert.assertNotNull(strList4);
        org.junit.Assert.assertNotNull(strList7);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "GETELEM" + "'", str9.equals("GETELEM"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "DependencyInfo(relativePath='', path='GETELEM', provides=[hi!], requires=[hi!])" + "'", str10.equals("DependencyInfo(relativePath='', path='GETELEM', provides=[hi!], requires=[hi!])"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "GETELEM" + "'", str11.equals("GETELEM"));
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention0 = new com.google.javascript.jscomp.GoogleCodingConvention();
        boolean boolean2 = googleCodingConvention0.isConstantKey("hi!");
        boolean boolean4 = googleCodingConvention0.isExported("GETELEM");
        boolean boolean6 = googleCodingConvention0.isConstant("hi!");
        com.google.javascript.rhino.Node node7 = null;
        try {
            com.google.javascript.jscomp.CodingConvention.Bind bind8 = googleCodingConvention0.describeFunctionBind(node7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        com.google.javascript.jscomp.ClosureCodingConvention.AssertInstanceofSpec assertInstanceofSpec1 = new com.google.javascript.jscomp.ClosureCodingConvention.AssertInstanceofSpec("");
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newNumber((double) (short) -1, (int) (byte) 1, 0);
        boolean boolean6 = node5.isArrayLit();
        boolean boolean7 = node5.isLabelName();
        com.google.javascript.rhino.Node node8 = node5.cloneNode();
        com.google.javascript.rhino.ErrorReporter errorReporter9 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry11 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter9, true);
        com.google.javascript.rhino.jstype.JSType jSType16 = jSTypeRegistry11.createNamedType("GETELEM", "hi!", 0, 38);
        jSTypeRegistry11.incrementGeneration();
        com.google.javascript.rhino.ErrorReporter errorReporter18 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry20 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter18, true);
        com.google.javascript.rhino.ErrorReporter errorReporter21 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry23 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter21, true);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative24 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative25 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative26 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray27 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative24, jSTypeNative25, jSTypeNative26 };
        com.google.javascript.rhino.jstype.JSType jSType28 = jSTypeRegistry23.createUnionType(jSTypeNativeArray27);
        boolean boolean29 = jSType28.isRegexpType();
        boolean boolean30 = jSType28.isNullable();
        com.google.javascript.rhino.ErrorReporter errorReporter31 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry33 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter31, true);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative34 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative35 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative36 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray37 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative34, jSTypeNative35, jSTypeNative36 };
        com.google.javascript.rhino.jstype.JSType jSType38 = jSTypeRegistry33.createUnionType(jSTypeNativeArray37);
        com.google.javascript.rhino.ErrorReporter errorReporter39 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry41 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter39, true);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative42 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative43 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative44 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray45 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative42, jSTypeNative43, jSTypeNative44 };
        com.google.javascript.rhino.jstype.JSType jSType46 = jSTypeRegistry41.createUnionType(jSTypeNativeArray45);
        com.google.javascript.rhino.JSDocInfo jSDocInfo47 = jSType46.getJSDocInfo();
        com.google.javascript.rhino.jstype.ObjectType objectType48 = jSType46.toObjectType();
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray49 = new com.google.javascript.rhino.jstype.JSType[] { jSType38, jSType46 };
        com.google.javascript.rhino.jstype.FunctionType functionType50 = jSTypeRegistry20.createConstructorTypeWithVarArgs(jSType28, jSTypeArray49);
        java.lang.Iterable iterable51 = functionType50.getCtorImplementedInterfaces();
        jSTypeRegistry11.resolveTypesInScope((com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType>) functionType50);
        com.google.javascript.rhino.jstype.JSType jSType53 = assertInstanceofSpec1.getAssertedType(node8, jSTypeRegistry11);
        com.google.javascript.rhino.jstype.JSTypeRegistry.ResolveMode resolveMode54 = com.google.javascript.rhino.jstype.JSTypeRegistry.ResolveMode.LAZY_EXPRESSIONS;
        jSTypeRegistry11.setResolveMode(resolveMode54);
        boolean boolean57 = jSTypeRegistry11.hasNamespace("function (new:?, boolean, ...[boolean]): boolean");
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNotNull(jSType16);
        org.junit.Assert.assertTrue("'" + jSTypeNative24 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative24.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative25 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative25.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative26 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative26.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray27);
        org.junit.Assert.assertNotNull(jSType28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + jSTypeNative34 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative34.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative35 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative35.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative36 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative36.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray37);
        org.junit.Assert.assertNotNull(jSType38);
        org.junit.Assert.assertTrue("'" + jSTypeNative42 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative42.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative43 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative43.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative44 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative44.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray45);
        org.junit.Assert.assertNotNull(jSType46);
        org.junit.Assert.assertNull(jSDocInfo47);
        org.junit.Assert.assertNull(objectType48);
        org.junit.Assert.assertNotNull(jSTypeArray49);
        org.junit.Assert.assertNotNull(functionType50);
        org.junit.Assert.assertNotNull(iterable51);
        org.junit.Assert.assertNotNull(jSType53);
        org.junit.Assert.assertTrue("'" + resolveMode54 + "' != '" + com.google.javascript.rhino.jstype.JSTypeRegistry.ResolveMode.LAZY_EXPRESSIONS + "'", resolveMode54.equals(com.google.javascript.rhino.jstype.JSTypeRegistry.ResolveMode.LAZY_EXPRESSIONS));
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newNumber((double) (short) -1, (int) (byte) 1, 0);
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.Node.newNumber((double) (short) -1, (int) (byte) 1, 0);
        boolean boolean8 = node7.isArrayLit();
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newNumber((double) (short) -1, (int) (byte) 1, 0);
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.IR.getelem(node7, node12);
        com.google.javascript.rhino.Node node14 = node3.copyInformationFrom(node13);
        com.google.javascript.rhino.Node node15 = node13.cloneNode();
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention16 = new com.google.javascript.jscomp.ClosureCodingConvention();
        boolean boolean18 = closureCodingConvention16.isSuperClassReference("hi!");
        boolean boolean20 = closureCodingConvention16.isSuperClassReference("{proxy:function ({1566169663}, {({1804413486},{656799354})}): {1133890062}}");
        com.google.javascript.rhino.Node node24 = com.google.javascript.rhino.Node.newNumber((double) (short) -1, (int) (byte) 1, 0);
        com.google.javascript.rhino.Node node28 = com.google.javascript.rhino.Node.newNumber((double) (short) -1, (int) (byte) 1, 0);
        boolean boolean29 = node28.isArrayLit();
        com.google.javascript.rhino.Node node33 = com.google.javascript.rhino.Node.newNumber((double) (short) -1, (int) (byte) 1, 0);
        com.google.javascript.rhino.Node node34 = com.google.javascript.rhino.IR.getelem(node28, node33);
        com.google.javascript.rhino.Node node35 = node24.copyInformationFrom(node34);
        com.google.javascript.rhino.Node node36 = node34.cloneNode();
        com.google.javascript.rhino.Node node37 = com.google.javascript.rhino.IR.voidNode(node36);
        com.google.javascript.rhino.Node node41 = com.google.javascript.rhino.Node.newNumber((double) (short) -1, (int) (byte) 1, 0);
        boolean boolean42 = node41.isArrayLit();
        boolean boolean43 = node41.isLabelName();
        com.google.javascript.rhino.Node node44 = node41.getLastChild();
        java.lang.String str45 = closureCodingConvention16.extractClassNameIfRequire(node37, node41);
        com.google.javascript.rhino.Node node46 = com.google.javascript.rhino.IR.sheq(node15, node37);
        boolean boolean47 = node37.isOptionalArg();
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(node33);
        org.junit.Assert.assertNotNull(node34);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertNotNull(node36);
        org.junit.Assert.assertNotNull(node37);
        org.junit.Assert.assertNotNull(node41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNull(node44);
        org.junit.Assert.assertNull(str45);
        org.junit.Assert.assertNotNull(node46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, true);
        com.google.javascript.rhino.ErrorReporter errorReporter3 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter3, true);
        com.google.javascript.rhino.ErrorReporter errorReporter6 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry8 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter6, true);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative9 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative10 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative11 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray12 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative9, jSTypeNative10, jSTypeNative11 };
        com.google.javascript.rhino.jstype.JSType jSType13 = jSTypeRegistry8.createUnionType(jSTypeNativeArray12);
        boolean boolean14 = jSType13.isRegexpType();
        boolean boolean15 = jSType13.isNullable();
        com.google.javascript.rhino.ErrorReporter errorReporter16 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry18 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter16, true);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative19 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative20 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative21 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray22 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative19, jSTypeNative20, jSTypeNative21 };
        com.google.javascript.rhino.jstype.JSType jSType23 = jSTypeRegistry18.createUnionType(jSTypeNativeArray22);
        com.google.javascript.rhino.ErrorReporter errorReporter24 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry26 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter24, true);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative27 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative28 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative29 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray30 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative27, jSTypeNative28, jSTypeNative29 };
        com.google.javascript.rhino.jstype.JSType jSType31 = jSTypeRegistry26.createUnionType(jSTypeNativeArray30);
        com.google.javascript.rhino.JSDocInfo jSDocInfo32 = jSType31.getJSDocInfo();
        com.google.javascript.rhino.jstype.ObjectType objectType33 = jSType31.toObjectType();
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray34 = new com.google.javascript.rhino.jstype.JSType[] { jSType23, jSType31 };
        com.google.javascript.rhino.jstype.FunctionType functionType35 = jSTypeRegistry5.createConstructorTypeWithVarArgs(jSType13, jSTypeArray34);
        com.google.javascript.rhino.ErrorReporter errorReporter36 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry38 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter36, true);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative39 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative40 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative41 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray42 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative39, jSTypeNative40, jSTypeNative41 };
        com.google.javascript.rhino.jstype.JSType jSType43 = jSTypeRegistry38.createUnionType(jSTypeNativeArray42);
        boolean boolean44 = jSType43.isStringObjectType();
        com.google.javascript.rhino.jstype.ParameterizedType parameterizedType45 = jSTypeRegistry2.createParameterizedType((com.google.javascript.rhino.jstype.ObjectType) functionType35, jSType43);
        com.google.javascript.rhino.jstype.JSType jSType47 = functionType35.getRestrictedTypeGivenToBooleanOutcome(false);
        com.google.javascript.rhino.jstype.ObjectType.Property property49 = functionType35.getSlot("Unknown class name");
        java.lang.String str50 = functionType35.getDisplayName();
        org.junit.Assert.assertTrue("'" + jSTypeNative9 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative9.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative10 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative10.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative11 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative11.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray12);
        org.junit.Assert.assertNotNull(jSType13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + jSTypeNative19 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative19.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative20 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative20.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative21 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative21.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray22);
        org.junit.Assert.assertNotNull(jSType23);
        org.junit.Assert.assertTrue("'" + jSTypeNative27 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative27.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative28 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative28.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative29 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative29.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray30);
        org.junit.Assert.assertNotNull(jSType31);
        org.junit.Assert.assertNull(jSDocInfo32);
        org.junit.Assert.assertNull(objectType33);
        org.junit.Assert.assertNotNull(jSTypeArray34);
        org.junit.Assert.assertNotNull(functionType35);
        org.junit.Assert.assertTrue("'" + jSTypeNative39 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative39.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative40 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative40.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative41 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative41.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray42);
        org.junit.Assert.assertNotNull(jSType43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(parameterizedType45);
        org.junit.Assert.assertNotNull(jSType47);
        org.junit.Assert.assertNull(property49);
        org.junit.Assert.assertNull(str50);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, true);
        com.google.javascript.rhino.ErrorReporter errorReporter3 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter3, true);
        com.google.javascript.rhino.ErrorReporter errorReporter6 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry8 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter6, true);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative9 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative10 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative11 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray12 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative9, jSTypeNative10, jSTypeNative11 };
        com.google.javascript.rhino.jstype.JSType jSType13 = jSTypeRegistry8.createUnionType(jSTypeNativeArray12);
        boolean boolean14 = jSType13.isRegexpType();
        boolean boolean15 = jSType13.isNullable();
        com.google.javascript.rhino.ErrorReporter errorReporter16 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry18 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter16, true);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative19 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative20 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative21 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray22 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative19, jSTypeNative20, jSTypeNative21 };
        com.google.javascript.rhino.jstype.JSType jSType23 = jSTypeRegistry18.createUnionType(jSTypeNativeArray22);
        com.google.javascript.rhino.ErrorReporter errorReporter24 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry26 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter24, true);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative27 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative28 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative29 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray30 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative27, jSTypeNative28, jSTypeNative29 };
        com.google.javascript.rhino.jstype.JSType jSType31 = jSTypeRegistry26.createUnionType(jSTypeNativeArray30);
        com.google.javascript.rhino.JSDocInfo jSDocInfo32 = jSType31.getJSDocInfo();
        com.google.javascript.rhino.jstype.ObjectType objectType33 = jSType31.toObjectType();
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray34 = new com.google.javascript.rhino.jstype.JSType[] { jSType23, jSType31 };
        com.google.javascript.rhino.jstype.FunctionType functionType35 = jSTypeRegistry5.createConstructorTypeWithVarArgs(jSType13, jSTypeArray34);
        com.google.javascript.rhino.ErrorReporter errorReporter36 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry38 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter36, true);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative39 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative40 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative41 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray42 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative39, jSTypeNative40, jSTypeNative41 };
        com.google.javascript.rhino.jstype.JSType jSType43 = jSTypeRegistry38.createUnionType(jSTypeNativeArray42);
        boolean boolean44 = jSType43.isStringObjectType();
        com.google.javascript.rhino.jstype.ParameterizedType parameterizedType45 = jSTypeRegistry2.createParameterizedType((com.google.javascript.rhino.jstype.ObjectType) functionType35, jSType43);
        com.google.javascript.rhino.jstype.JSType jSType47 = functionType35.findPropertyType("GETELEM");
        int int48 = functionType35.getExtendedInterfacesCount();
        boolean boolean49 = functionType35.isConstructor();
        org.junit.Assert.assertTrue("'" + jSTypeNative9 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative9.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative10 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative10.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative11 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative11.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray12);
        org.junit.Assert.assertNotNull(jSType13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + jSTypeNative19 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative19.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative20 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative20.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative21 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative21.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray22);
        org.junit.Assert.assertNotNull(jSType23);
        org.junit.Assert.assertTrue("'" + jSTypeNative27 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative27.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative28 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative28.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative29 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative29.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray30);
        org.junit.Assert.assertNotNull(jSType31);
        org.junit.Assert.assertNull(jSDocInfo32);
        org.junit.Assert.assertNull(objectType33);
        org.junit.Assert.assertNotNull(jSTypeArray34);
        org.junit.Assert.assertNotNull(functionType35);
        org.junit.Assert.assertTrue("'" + jSTypeNative39 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative39.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative40 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative40.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative41 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative41.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray42);
        org.junit.Assert.assertNotNull(jSType43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(parameterizedType45);
        org.junit.Assert.assertNull(jSType47);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 0 + "'", int48 == 0);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newNumber((double) (short) -1, (int) (byte) 1, 0);
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.Node.newNumber((double) (short) -1, (int) (byte) 1, 0);
        boolean boolean8 = node7.isArrayLit();
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newNumber((double) (short) -1, (int) (byte) 1, 0);
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.IR.getelem(node7, node12);
        com.google.javascript.rhino.Node node14 = node3.copyInformationFrom(node13);
        com.google.javascript.rhino.Node node15 = node13.cloneNode();
        boolean boolean16 = node15.isStringKey();
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.IR.breakNode();
        boolean boolean18 = node15.hasChild(node17);
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.IR.voidNode(node15);
        boolean boolean20 = node19.isFromExterns();
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, true);
        com.google.javascript.rhino.ErrorReporter errorReporter3 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter3, true);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative6 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative7 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative8 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray9 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative6, jSTypeNative7, jSTypeNative8 };
        com.google.javascript.rhino.jstype.JSType jSType10 = jSTypeRegistry5.createUnionType(jSTypeNativeArray9);
        boolean boolean11 = jSType10.isRegexpType();
        boolean boolean12 = jSType10.isNullable();
        com.google.javascript.rhino.ErrorReporter errorReporter13 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry15 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter13, true);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative16 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative17 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative18 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray19 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative16, jSTypeNative17, jSTypeNative18 };
        com.google.javascript.rhino.jstype.JSType jSType20 = jSTypeRegistry15.createUnionType(jSTypeNativeArray19);
        com.google.javascript.rhino.ErrorReporter errorReporter21 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry23 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter21, true);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative24 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative25 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative26 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray27 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative24, jSTypeNative25, jSTypeNative26 };
        com.google.javascript.rhino.jstype.JSType jSType28 = jSTypeRegistry23.createUnionType(jSTypeNativeArray27);
        com.google.javascript.rhino.JSDocInfo jSDocInfo29 = jSType28.getJSDocInfo();
        com.google.javascript.rhino.jstype.ObjectType objectType30 = jSType28.toObjectType();
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray31 = new com.google.javascript.rhino.jstype.JSType[] { jSType20, jSType28 };
        com.google.javascript.rhino.jstype.FunctionType functionType32 = jSTypeRegistry2.createConstructorTypeWithVarArgs(jSType10, jSTypeArray31);
        boolean boolean34 = functionType32.hasProperty("hi!");
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable35 = functionType32.getParameters();
        com.google.javascript.rhino.jstype.JSType jSType36 = functionType32.unboxesTo();
        com.google.javascript.rhino.jstype.BooleanLiteralSet booleanLiteralSet37 = functionType32.getPossibleToBooleanOutcomes();
        com.google.javascript.rhino.jstype.EnumType enumType38 = functionType32.toMaybeEnumType();
        boolean boolean39 = functionType32.hasCachedValues();
        boolean boolean41 = functionType32.hasProperty("./");
        org.junit.Assert.assertTrue("'" + jSTypeNative6 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative6.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative7 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative7.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative8 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative8.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray9);
        org.junit.Assert.assertNotNull(jSType10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + jSTypeNative16 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative16.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative17 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative17.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative18 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative18.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray19);
        org.junit.Assert.assertNotNull(jSType20);
        org.junit.Assert.assertTrue("'" + jSTypeNative24 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative24.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative25 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative25.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative26 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative26.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray27);
        org.junit.Assert.assertNotNull(jSType28);
        org.junit.Assert.assertNull(jSDocInfo29);
        org.junit.Assert.assertNull(objectType30);
        org.junit.Assert.assertNotNull(jSTypeArray31);
        org.junit.Assert.assertNotNull(functionType32);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(nodeIterable35);
        org.junit.Assert.assertNull(jSType36);
        org.junit.Assert.assertTrue("'" + booleanLiteralSet37 + "' != '" + com.google.javascript.rhino.jstype.BooleanLiteralSet.TRUE + "'", booleanLiteralSet37.equals(com.google.javascript.rhino.jstype.BooleanLiteralSet.TRUE));
        org.junit.Assert.assertNull(enumType38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, true);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative3 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative4 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative5 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray6 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative3, jSTypeNative4, jSTypeNative5 };
        com.google.javascript.rhino.jstype.JSType jSType7 = jSTypeRegistry2.createUnionType(jSTypeNativeArray6);
        jSTypeRegistry2.clearTemplateTypeNames();
        com.google.javascript.rhino.ErrorReporter errorReporter9 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry11 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter9, true);
        com.google.javascript.rhino.ErrorReporter errorReporter12 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry14 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter12, true);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative15 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative16 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative17 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray18 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative15, jSTypeNative16, jSTypeNative17 };
        com.google.javascript.rhino.jstype.JSType jSType19 = jSTypeRegistry14.createUnionType(jSTypeNativeArray18);
        boolean boolean20 = jSType19.isRegexpType();
        boolean boolean21 = jSType19.isNullable();
        com.google.javascript.rhino.ErrorReporter errorReporter22 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry24 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter22, true);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative25 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative26 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative27 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray28 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative25, jSTypeNative26, jSTypeNative27 };
        com.google.javascript.rhino.jstype.JSType jSType29 = jSTypeRegistry24.createUnionType(jSTypeNativeArray28);
        com.google.javascript.rhino.ErrorReporter errorReporter30 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry32 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter30, true);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative33 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative34 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative35 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray36 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative33, jSTypeNative34, jSTypeNative35 };
        com.google.javascript.rhino.jstype.JSType jSType37 = jSTypeRegistry32.createUnionType(jSTypeNativeArray36);
        com.google.javascript.rhino.JSDocInfo jSDocInfo38 = jSType37.getJSDocInfo();
        com.google.javascript.rhino.jstype.ObjectType objectType39 = jSType37.toObjectType();
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray40 = new com.google.javascript.rhino.jstype.JSType[] { jSType29, jSType37 };
        com.google.javascript.rhino.jstype.FunctionType functionType41 = jSTypeRegistry11.createConstructorTypeWithVarArgs(jSType19, jSTypeArray40);
        java.lang.Iterable iterable42 = functionType41.getCtorImplementedInterfaces();
        com.google.javascript.rhino.Node node43 = functionType41.getSource();
        com.google.javascript.rhino.ErrorReporter errorReporter45 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry47 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter45, true);
        com.google.javascript.rhino.ErrorReporter errorReporter48 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry50 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter48, true);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative51 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative52 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative53 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray54 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative51, jSTypeNative52, jSTypeNative53 };
        com.google.javascript.rhino.jstype.JSType jSType55 = jSTypeRegistry50.createUnionType(jSTypeNativeArray54);
        boolean boolean56 = jSType55.isRegexpType();
        boolean boolean57 = jSType55.isNullable();
        com.google.javascript.rhino.ErrorReporter errorReporter58 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry60 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter58, true);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative61 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative62 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative63 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray64 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative61, jSTypeNative62, jSTypeNative63 };
        com.google.javascript.rhino.jstype.JSType jSType65 = jSTypeRegistry60.createUnionType(jSTypeNativeArray64);
        com.google.javascript.rhino.ErrorReporter errorReporter66 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry68 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter66, true);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative69 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative70 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative71 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray72 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative69, jSTypeNative70, jSTypeNative71 };
        com.google.javascript.rhino.jstype.JSType jSType73 = jSTypeRegistry68.createUnionType(jSTypeNativeArray72);
        com.google.javascript.rhino.JSDocInfo jSDocInfo74 = jSType73.getJSDocInfo();
        com.google.javascript.rhino.jstype.ObjectType objectType75 = jSType73.toObjectType();
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray76 = new com.google.javascript.rhino.jstype.JSType[] { jSType65, jSType73 };
        com.google.javascript.rhino.jstype.FunctionType functionType77 = jSTypeRegistry47.createConstructorTypeWithVarArgs(jSType55, jSTypeArray76);
        com.google.javascript.rhino.jstype.FunctionType functionType78 = jSTypeRegistry2.createFunctionType((com.google.javascript.rhino.jstype.JSType) functionType41, true, jSTypeArray76);
        boolean boolean80 = functionType41.hasOwnProperty("hi!");
        java.util.Set<java.lang.String> strSet81 = functionType41.getOwnPropertyNames();
        org.junit.Assert.assertTrue("'" + jSTypeNative3 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative3.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative4 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative4.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative5 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative5.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray6);
        org.junit.Assert.assertNotNull(jSType7);
        org.junit.Assert.assertTrue("'" + jSTypeNative15 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative15.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative16 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative16.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative17 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative17.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray18);
        org.junit.Assert.assertNotNull(jSType19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + jSTypeNative25 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative25.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative26 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative26.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative27 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative27.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray28);
        org.junit.Assert.assertNotNull(jSType29);
        org.junit.Assert.assertTrue("'" + jSTypeNative33 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative33.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative34 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative34.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative35 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative35.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray36);
        org.junit.Assert.assertNotNull(jSType37);
        org.junit.Assert.assertNull(jSDocInfo38);
        org.junit.Assert.assertNull(objectType39);
        org.junit.Assert.assertNotNull(jSTypeArray40);
        org.junit.Assert.assertNotNull(functionType41);
        org.junit.Assert.assertNotNull(iterable42);
        org.junit.Assert.assertNull(node43);
        org.junit.Assert.assertTrue("'" + jSTypeNative51 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative51.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative52 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative52.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative53 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative53.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray54);
        org.junit.Assert.assertNotNull(jSType55);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertTrue("'" + jSTypeNative61 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative61.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative62 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative62.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative63 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative63.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray64);
        org.junit.Assert.assertNotNull(jSType65);
        org.junit.Assert.assertTrue("'" + jSTypeNative69 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative69.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative70 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative70.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative71 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative71.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray72);
        org.junit.Assert.assertNotNull(jSType73);
        org.junit.Assert.assertNull(jSDocInfo74);
        org.junit.Assert.assertNull(objectType75);
        org.junit.Assert.assertNotNull(jSTypeArray76);
        org.junit.Assert.assertNotNull(functionType77);
        org.junit.Assert.assertNotNull(functionType78);
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + false + "'", boolean80 == false);
        org.junit.Assert.assertNotNull(strSet81);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.INTERNET_EXPLORER_CHECKS;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        com.google.javascript.jscomp.SourceAst sourceAst0 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(sourceAst0, "", false);
        com.google.javascript.jscomp.AbstractCompiler abstractCompiler4 = null;
        compilerInput3.setCompiler(abstractCompiler4);
        com.google.javascript.rhino.InputId inputId6 = compilerInput3.getInputId();
        com.google.javascript.jscomp.SourceAst sourceAst7 = compilerInput3.getAst();
        com.google.javascript.jscomp.SourceFile sourceFile11 = com.google.javascript.jscomp.SourceFile.fromCode("hi!", "Unknown class name", "Unknown class name");
        com.google.javascript.jscomp.Region region13 = sourceFile11.getRegion(2147483647);
        com.google.javascript.jscomp.CompilerInput compilerInput14 = new com.google.javascript.jscomp.CompilerInput(sourceFile11);
        com.google.javascript.jscomp.SourceAst sourceAst15 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput18 = new com.google.javascript.jscomp.CompilerInput(sourceAst15, "", false);
        com.google.javascript.rhino.InputId inputId19 = compilerInput18.getInputId();
        com.google.javascript.jscomp.CompilerInput compilerInput21 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput14, inputId19, false);
        com.google.javascript.rhino.InputId inputId22 = compilerInput21.getInputId();
        try {
            com.google.javascript.jscomp.CompilerInput compilerInput24 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput3, inputId22, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(inputId6);
        org.junit.Assert.assertNull(sourceAst7);
        org.junit.Assert.assertNotNull(sourceFile11);
        org.junit.Assert.assertNull(region13);
        org.junit.Assert.assertNotNull(inputId19);
        org.junit.Assert.assertNotNull(inputId22);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        com.google.javascript.jscomp.AbstractCompiler abstractCompiler0 = null;
        com.google.javascript.jscomp.NodeTraversal.Callback callback1 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal2 = new com.google.javascript.jscomp.NodeTraversal(abstractCompiler0, callback1);
        try {
            com.google.javascript.jscomp.CompilerInput compilerInput3 = nodeTraversal2.getInput();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.STRING_OBJECT_TYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.STRING_OBJECT_TYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.STRING_OBJECT_TYPE));
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, true);
        com.google.javascript.rhino.ErrorReporter errorReporter3 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter3, true);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative6 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative7 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative8 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray9 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative6, jSTypeNative7, jSTypeNative8 };
        com.google.javascript.rhino.jstype.JSType jSType10 = jSTypeRegistry5.createUnionType(jSTypeNativeArray9);
        boolean boolean11 = jSType10.isRegexpType();
        boolean boolean12 = jSType10.isNullable();
        com.google.javascript.rhino.ErrorReporter errorReporter13 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry15 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter13, true);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative16 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative17 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative18 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray19 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative16, jSTypeNative17, jSTypeNative18 };
        com.google.javascript.rhino.jstype.JSType jSType20 = jSTypeRegistry15.createUnionType(jSTypeNativeArray19);
        com.google.javascript.rhino.ErrorReporter errorReporter21 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry23 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter21, true);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative24 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative25 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative26 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray27 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative24, jSTypeNative25, jSTypeNative26 };
        com.google.javascript.rhino.jstype.JSType jSType28 = jSTypeRegistry23.createUnionType(jSTypeNativeArray27);
        com.google.javascript.rhino.JSDocInfo jSDocInfo29 = jSType28.getJSDocInfo();
        com.google.javascript.rhino.jstype.ObjectType objectType30 = jSType28.toObjectType();
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray31 = new com.google.javascript.rhino.jstype.JSType[] { jSType20, jSType28 };
        com.google.javascript.rhino.jstype.FunctionType functionType32 = jSTypeRegistry2.createConstructorTypeWithVarArgs(jSType10, jSTypeArray31);
        java.lang.Iterable iterable33 = functionType32.getCtorImplementedInterfaces();
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable34 = functionType32.getImplementedInterfaces();
        com.google.javascript.rhino.jstype.FunctionType functionType35 = functionType32.toMaybeFunctionType();
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable36 = functionType35.getOwnImplementedInterfaces();
        org.junit.Assert.assertTrue("'" + jSTypeNative6 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative6.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative7 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative7.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative8 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative8.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray9);
        org.junit.Assert.assertNotNull(jSType10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + jSTypeNative16 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative16.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative17 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative17.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative18 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative18.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray19);
        org.junit.Assert.assertNotNull(jSType20);
        org.junit.Assert.assertTrue("'" + jSTypeNative24 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative24.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative25 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative25.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative26 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative26.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray27);
        org.junit.Assert.assertNotNull(jSType28);
        org.junit.Assert.assertNull(jSDocInfo29);
        org.junit.Assert.assertNull(objectType30);
        org.junit.Assert.assertNotNull(jSTypeArray31);
        org.junit.Assert.assertNotNull(functionType32);
        org.junit.Assert.assertNotNull(iterable33);
        org.junit.Assert.assertNotNull(objectTypeIterable34);
        org.junit.Assert.assertNotNull(functionType35);
        org.junit.Assert.assertNotNull(objectTypeIterable36);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, true);
        com.google.javascript.rhino.ErrorReporter errorReporter3 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter3, true);
        com.google.javascript.rhino.ErrorReporter errorReporter6 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry8 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter6, true);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative9 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative10 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative11 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray12 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative9, jSTypeNative10, jSTypeNative11 };
        com.google.javascript.rhino.jstype.JSType jSType13 = jSTypeRegistry8.createUnionType(jSTypeNativeArray12);
        boolean boolean14 = jSType13.isRegexpType();
        boolean boolean15 = jSType13.isNullable();
        com.google.javascript.rhino.ErrorReporter errorReporter16 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry18 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter16, true);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative19 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative20 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative21 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray22 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative19, jSTypeNative20, jSTypeNative21 };
        com.google.javascript.rhino.jstype.JSType jSType23 = jSTypeRegistry18.createUnionType(jSTypeNativeArray22);
        com.google.javascript.rhino.ErrorReporter errorReporter24 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry26 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter24, true);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative27 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative28 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative29 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray30 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative27, jSTypeNative28, jSTypeNative29 };
        com.google.javascript.rhino.jstype.JSType jSType31 = jSTypeRegistry26.createUnionType(jSTypeNativeArray30);
        com.google.javascript.rhino.JSDocInfo jSDocInfo32 = jSType31.getJSDocInfo();
        com.google.javascript.rhino.jstype.ObjectType objectType33 = jSType31.toObjectType();
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray34 = new com.google.javascript.rhino.jstype.JSType[] { jSType23, jSType31 };
        com.google.javascript.rhino.jstype.FunctionType functionType35 = jSTypeRegistry5.createConstructorTypeWithVarArgs(jSType13, jSTypeArray34);
        com.google.javascript.rhino.ErrorReporter errorReporter36 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry38 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter36, true);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative39 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative40 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative41 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray42 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative39, jSTypeNative40, jSTypeNative41 };
        com.google.javascript.rhino.jstype.JSType jSType43 = jSTypeRegistry38.createUnionType(jSTypeNativeArray42);
        boolean boolean44 = jSType43.isStringObjectType();
        com.google.javascript.rhino.jstype.ParameterizedType parameterizedType45 = jSTypeRegistry2.createParameterizedType((com.google.javascript.rhino.jstype.ObjectType) functionType35, jSType43);
        boolean boolean46 = parameterizedType45.hasAnyTemplateInternal();
        com.google.javascript.rhino.jstype.FunctionType functionType47 = parameterizedType45.getConstructor();
        java.util.Set set48 = parameterizedType45.getOwnPropertyNames();
        java.lang.String str49 = parameterizedType45.getReferenceName();
        com.google.javascript.rhino.JSDocInfo jSDocInfo51 = parameterizedType45.getOwnPropertyJSDocInfo("NUMBER -1.0 1");
        com.google.javascript.rhino.ErrorReporter errorReporter52 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry54 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter52, true);
        com.google.javascript.rhino.ErrorReporter errorReporter55 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry57 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter55, true);
        com.google.javascript.rhino.ErrorReporter errorReporter58 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry60 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter58, true);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative61 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative62 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative63 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray64 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative61, jSTypeNative62, jSTypeNative63 };
        com.google.javascript.rhino.jstype.JSType jSType65 = jSTypeRegistry60.createUnionType(jSTypeNativeArray64);
        boolean boolean66 = jSType65.isRegexpType();
        boolean boolean67 = jSType65.isNullable();
        com.google.javascript.rhino.ErrorReporter errorReporter68 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry70 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter68, true);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative71 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative72 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative73 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray74 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative71, jSTypeNative72, jSTypeNative73 };
        com.google.javascript.rhino.jstype.JSType jSType75 = jSTypeRegistry70.createUnionType(jSTypeNativeArray74);
        com.google.javascript.rhino.ErrorReporter errorReporter76 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry78 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter76, true);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative79 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative80 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative81 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray82 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative79, jSTypeNative80, jSTypeNative81 };
        com.google.javascript.rhino.jstype.JSType jSType83 = jSTypeRegistry78.createUnionType(jSTypeNativeArray82);
        com.google.javascript.rhino.JSDocInfo jSDocInfo84 = jSType83.getJSDocInfo();
        com.google.javascript.rhino.jstype.ObjectType objectType85 = jSType83.toObjectType();
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray86 = new com.google.javascript.rhino.jstype.JSType[] { jSType75, jSType83 };
        com.google.javascript.rhino.jstype.FunctionType functionType87 = jSTypeRegistry57.createConstructorTypeWithVarArgs(jSType65, jSTypeArray86);
        com.google.javascript.rhino.Node node91 = com.google.javascript.rhino.Node.newNumber((double) (short) -1, (int) (byte) 1, 0);
        boolean boolean92 = node91.isArrayLit();
        boolean boolean93 = node91.isLabelName();
        com.google.javascript.rhino.Node node94 = node91.cloneNode();
        com.google.javascript.rhino.Node node95 = com.google.javascript.rhino.IR.neg(node94);
        com.google.javascript.rhino.jstype.FunctionType functionType96 = jSTypeRegistry54.createFunctionType(jSType65, node94);
        com.google.javascript.rhino.jstype.TernaryValue ternaryValue97 = parameterizedType45.testForEquality((com.google.javascript.rhino.jstype.JSType) functionType96);
        org.junit.Assert.assertTrue("'" + jSTypeNative9 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative9.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative10 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative10.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative11 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative11.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray12);
        org.junit.Assert.assertNotNull(jSType13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + jSTypeNative19 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative19.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative20 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative20.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative21 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative21.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray22);
        org.junit.Assert.assertNotNull(jSType23);
        org.junit.Assert.assertTrue("'" + jSTypeNative27 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative27.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative28 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative28.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative29 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative29.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray30);
        org.junit.Assert.assertNotNull(jSType31);
        org.junit.Assert.assertNull(jSDocInfo32);
        org.junit.Assert.assertNull(objectType33);
        org.junit.Assert.assertNotNull(jSTypeArray34);
        org.junit.Assert.assertNotNull(functionType35);
        org.junit.Assert.assertTrue("'" + jSTypeNative39 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative39.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative40 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative40.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative41 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative41.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray42);
        org.junit.Assert.assertNotNull(jSType43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(parameterizedType45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNull(functionType47);
        org.junit.Assert.assertNotNull(set48);
        org.junit.Assert.assertNull(str49);
        org.junit.Assert.assertNull(jSDocInfo51);
        org.junit.Assert.assertTrue("'" + jSTypeNative61 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative61.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative62 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative62.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative63 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative63.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray64);
        org.junit.Assert.assertNotNull(jSType65);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
        org.junit.Assert.assertTrue("'" + jSTypeNative71 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative71.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative72 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative72.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative73 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative73.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray74);
        org.junit.Assert.assertNotNull(jSType75);
        org.junit.Assert.assertTrue("'" + jSTypeNative79 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative79.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative80 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative80.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative81 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative81.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray82);
        org.junit.Assert.assertNotNull(jSType83);
        org.junit.Assert.assertNull(jSDocInfo84);
        org.junit.Assert.assertNull(objectType85);
        org.junit.Assert.assertNotNull(jSTypeArray86);
        org.junit.Assert.assertNotNull(functionType87);
        org.junit.Assert.assertNotNull(node91);
        org.junit.Assert.assertTrue("'" + boolean92 + "' != '" + false + "'", boolean92 == false);
        org.junit.Assert.assertTrue("'" + boolean93 + "' != '" + false + "'", boolean93 == false);
        org.junit.Assert.assertNotNull(node94);
        org.junit.Assert.assertNotNull(node95);
        org.junit.Assert.assertNotNull(functionType96);
        org.junit.Assert.assertNotNull(ternaryValue97);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        com.google.javascript.jscomp.MessageFormatter messageFormatter0 = null;
        java.util.logging.Logger logger1 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager2 = new com.google.javascript.jscomp.LoggerErrorManager(messageFormatter0, logger1);
        int int3 = loggerErrorManager2.getErrorCount();
        int int4 = loggerErrorManager2.getErrorCount();
        int int5 = loggerErrorManager2.getWarningCount();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newNumber((double) (short) -1, (int) (byte) 1, 0);
        boolean boolean4 = node3.isArrayLit();
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newNumber((double) (short) -1, (int) (byte) 1, 0);
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.IR.getelem(node3, node8);
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.Node.newNumber((double) (short) -1, (int) (byte) 1, 0);
        boolean boolean15 = node14.isArrayLit();
        boolean boolean16 = node14.isLabelName();
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.Node.newNumber((double) (short) -1, (int) (byte) 1, 0);
        boolean boolean21 = node20.isArrayLit();
        com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.Node.newNumber((double) (short) -1, (int) (byte) 1, 0);
        com.google.javascript.rhino.Node node26 = new com.google.javascript.rhino.Node((int) '#', node14, node20, node25);
        com.google.javascript.rhino.Node node28 = com.google.javascript.rhino.Node.newNumber(0.0d);
        com.google.javascript.rhino.Node node29 = node14.copyInformationFromForTree(node28);
        com.google.javascript.rhino.Node node30 = node3.copyInformationFrom(node29);
        boolean boolean31 = node30.isSwitch();
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNotNull(node30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        com.google.javascript.jscomp.JSModule jSModule1 = new com.google.javascript.jscomp.JSModule("hi!");
        java.util.List<java.lang.String> strList2 = jSModule1.getProvides();
        com.google.javascript.jscomp.SourceFile sourceFile6 = com.google.javascript.jscomp.SourceFile.fromCode("hi!", "Unknown class name", "Unknown class name");
        com.google.javascript.jscomp.Region region8 = sourceFile6.getRegion(2147483647);
        jSModule1.add(sourceFile6);
        java.util.List<com.google.javascript.jscomp.CompilerInput> compilerInputList10 = jSModule1.getInputs();
        com.google.javascript.jscomp.Compiler compiler11 = null;
        try {
            jSModule1.sortInputsByDeps(compiler11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Expected setCompiler to be called first: hi!");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(strList2);
        org.junit.Assert.assertNotNull(sourceFile6);
        org.junit.Assert.assertNull(region8);
        org.junit.Assert.assertNotNull(compilerInputList10);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, true);
        com.google.javascript.rhino.ErrorReporter errorReporter3 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter3, true);
        com.google.javascript.rhino.ErrorReporter errorReporter6 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry8 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter6, true);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative9 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative10 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative11 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray12 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative9, jSTypeNative10, jSTypeNative11 };
        com.google.javascript.rhino.jstype.JSType jSType13 = jSTypeRegistry8.createUnionType(jSTypeNativeArray12);
        boolean boolean14 = jSType13.isRegexpType();
        boolean boolean15 = jSType13.isNullable();
        com.google.javascript.rhino.ErrorReporter errorReporter16 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry18 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter16, true);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative19 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative20 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative21 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray22 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative19, jSTypeNative20, jSTypeNative21 };
        com.google.javascript.rhino.jstype.JSType jSType23 = jSTypeRegistry18.createUnionType(jSTypeNativeArray22);
        com.google.javascript.rhino.ErrorReporter errorReporter24 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry26 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter24, true);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative27 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative28 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative29 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray30 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative27, jSTypeNative28, jSTypeNative29 };
        com.google.javascript.rhino.jstype.JSType jSType31 = jSTypeRegistry26.createUnionType(jSTypeNativeArray30);
        com.google.javascript.rhino.JSDocInfo jSDocInfo32 = jSType31.getJSDocInfo();
        com.google.javascript.rhino.jstype.ObjectType objectType33 = jSType31.toObjectType();
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray34 = new com.google.javascript.rhino.jstype.JSType[] { jSType23, jSType31 };
        com.google.javascript.rhino.jstype.FunctionType functionType35 = jSTypeRegistry5.createConstructorTypeWithVarArgs(jSType13, jSTypeArray34);
        com.google.javascript.rhino.ErrorReporter errorReporter36 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry38 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter36, true);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative39 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative40 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative41 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray42 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative39, jSTypeNative40, jSTypeNative41 };
        com.google.javascript.rhino.jstype.JSType jSType43 = jSTypeRegistry38.createUnionType(jSTypeNativeArray42);
        boolean boolean44 = jSType43.isStringObjectType();
        com.google.javascript.rhino.jstype.ParameterizedType parameterizedType45 = jSTypeRegistry2.createParameterizedType((com.google.javascript.rhino.jstype.ObjectType) functionType35, jSType43);
        boolean boolean46 = parameterizedType45.hasAnyTemplateInternal();
        com.google.javascript.rhino.jstype.FunctionType functionType47 = parameterizedType45.getConstructor();
        boolean boolean48 = parameterizedType45.canBeCalled();
        com.google.javascript.rhino.jstype.ObjectType.Property property50 = parameterizedType45.getOwnSlot("hi!");
        com.google.javascript.rhino.ErrorReporter errorReporter51 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry53 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter51, true);
        com.google.javascript.rhino.jstype.JSType jSType58 = jSTypeRegistry53.createNamedType("GETELEM", "hi!", 0, 38);
        jSTypeRegistry53.incrementGeneration();
        com.google.javascript.rhino.ErrorReporter errorReporter60 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry62 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter60, true);
        com.google.javascript.rhino.ErrorReporter errorReporter63 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry65 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter63, true);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative66 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative67 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative68 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray69 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative66, jSTypeNative67, jSTypeNative68 };
        com.google.javascript.rhino.jstype.JSType jSType70 = jSTypeRegistry65.createUnionType(jSTypeNativeArray69);
        boolean boolean71 = jSType70.isRegexpType();
        boolean boolean72 = jSType70.isNullable();
        com.google.javascript.rhino.ErrorReporter errorReporter73 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry75 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter73, true);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative76 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative77 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative78 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray79 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative76, jSTypeNative77, jSTypeNative78 };
        com.google.javascript.rhino.jstype.JSType jSType80 = jSTypeRegistry75.createUnionType(jSTypeNativeArray79);
        com.google.javascript.rhino.ErrorReporter errorReporter81 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry83 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter81, true);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative84 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative85 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative86 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray87 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative84, jSTypeNative85, jSTypeNative86 };
        com.google.javascript.rhino.jstype.JSType jSType88 = jSTypeRegistry83.createUnionType(jSTypeNativeArray87);
        com.google.javascript.rhino.JSDocInfo jSDocInfo89 = jSType88.getJSDocInfo();
        com.google.javascript.rhino.jstype.ObjectType objectType90 = jSType88.toObjectType();
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray91 = new com.google.javascript.rhino.jstype.JSType[] { jSType80, jSType88 };
        com.google.javascript.rhino.jstype.FunctionType functionType92 = jSTypeRegistry62.createConstructorTypeWithVarArgs(jSType70, jSTypeArray91);
        java.lang.Iterable iterable93 = functionType92.getCtorImplementedInterfaces();
        jSTypeRegistry53.resolveTypesInScope((com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType>) functionType92);
        boolean boolean95 = parameterizedType45.canAssignTo((com.google.javascript.rhino.jstype.JSType) functionType92);
        com.google.common.base.Predicate<com.google.javascript.rhino.jstype.JSType> jSTypePredicate96 = null;
        try {
            boolean boolean97 = functionType92.setValidator(jSTypePredicate96);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + jSTypeNative9 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative9.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative10 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative10.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative11 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative11.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray12);
        org.junit.Assert.assertNotNull(jSType13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + jSTypeNative19 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative19.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative20 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative20.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative21 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative21.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray22);
        org.junit.Assert.assertNotNull(jSType23);
        org.junit.Assert.assertTrue("'" + jSTypeNative27 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative27.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative28 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative28.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative29 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative29.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray30);
        org.junit.Assert.assertNotNull(jSType31);
        org.junit.Assert.assertNull(jSDocInfo32);
        org.junit.Assert.assertNull(objectType33);
        org.junit.Assert.assertNotNull(jSTypeArray34);
        org.junit.Assert.assertNotNull(functionType35);
        org.junit.Assert.assertTrue("'" + jSTypeNative39 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative39.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative40 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative40.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative41 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative41.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray42);
        org.junit.Assert.assertNotNull(jSType43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(parameterizedType45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNull(functionType47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + true + "'", boolean48 == true);
        org.junit.Assert.assertNull(property50);
        org.junit.Assert.assertNotNull(jSType58);
        org.junit.Assert.assertTrue("'" + jSTypeNative66 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative66.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative67 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative67.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative68 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative68.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray69);
        org.junit.Assert.assertNotNull(jSType70);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
        org.junit.Assert.assertTrue("'" + jSTypeNative76 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative76.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative77 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative77.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative78 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative78.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray79);
        org.junit.Assert.assertNotNull(jSType80);
        org.junit.Assert.assertTrue("'" + jSTypeNative84 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative84.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative85 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative85.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative86 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative86.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray87);
        org.junit.Assert.assertNotNull(jSType88);
        org.junit.Assert.assertNull(jSDocInfo89);
        org.junit.Assert.assertNull(objectType90);
        org.junit.Assert.assertNotNull(jSTypeArray91);
        org.junit.Assert.assertNotNull(functionType92);
        org.junit.Assert.assertNotNull(iterable93);
        org.junit.Assert.assertTrue("'" + boolean95 + "' != '" + false + "'", boolean95 == false);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, true);
        com.google.javascript.rhino.ErrorReporter errorReporter3 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter3, true);
        com.google.javascript.rhino.ErrorReporter errorReporter6 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry8 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter6, true);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative9 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative10 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative11 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray12 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative9, jSTypeNative10, jSTypeNative11 };
        com.google.javascript.rhino.jstype.JSType jSType13 = jSTypeRegistry8.createUnionType(jSTypeNativeArray12);
        boolean boolean14 = jSType13.isRegexpType();
        boolean boolean15 = jSType13.isNullable();
        com.google.javascript.rhino.ErrorReporter errorReporter16 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry18 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter16, true);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative19 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative20 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative21 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray22 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative19, jSTypeNative20, jSTypeNative21 };
        com.google.javascript.rhino.jstype.JSType jSType23 = jSTypeRegistry18.createUnionType(jSTypeNativeArray22);
        com.google.javascript.rhino.ErrorReporter errorReporter24 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry26 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter24, true);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative27 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative28 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative29 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray30 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative27, jSTypeNative28, jSTypeNative29 };
        com.google.javascript.rhino.jstype.JSType jSType31 = jSTypeRegistry26.createUnionType(jSTypeNativeArray30);
        com.google.javascript.rhino.JSDocInfo jSDocInfo32 = jSType31.getJSDocInfo();
        com.google.javascript.rhino.jstype.ObjectType objectType33 = jSType31.toObjectType();
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray34 = new com.google.javascript.rhino.jstype.JSType[] { jSType23, jSType31 };
        com.google.javascript.rhino.jstype.FunctionType functionType35 = jSTypeRegistry5.createConstructorTypeWithVarArgs(jSType13, jSTypeArray34);
        com.google.javascript.rhino.ErrorReporter errorReporter36 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry38 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter36, true);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative39 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative40 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative41 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray42 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative39, jSTypeNative40, jSTypeNative41 };
        com.google.javascript.rhino.jstype.JSType jSType43 = jSTypeRegistry38.createUnionType(jSTypeNativeArray42);
        boolean boolean44 = jSType43.isStringObjectType();
        com.google.javascript.rhino.jstype.ParameterizedType parameterizedType45 = jSTypeRegistry2.createParameterizedType((com.google.javascript.rhino.jstype.ObjectType) functionType35, jSType43);
        com.google.javascript.rhino.jstype.JSType jSType47 = functionType35.findPropertyType("GETELEM");
        java.lang.String str48 = functionType35.getReferenceName();
        com.google.javascript.rhino.jstype.BooleanLiteralSet booleanLiteralSet49 = functionType35.getPossibleToBooleanOutcomes();
        org.junit.Assert.assertTrue("'" + jSTypeNative9 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative9.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative10 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative10.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative11 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative11.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray12);
        org.junit.Assert.assertNotNull(jSType13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + jSTypeNative19 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative19.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative20 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative20.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative21 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative21.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray22);
        org.junit.Assert.assertNotNull(jSType23);
        org.junit.Assert.assertTrue("'" + jSTypeNative27 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative27.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative28 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative28.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative29 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative29.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray30);
        org.junit.Assert.assertNotNull(jSType31);
        org.junit.Assert.assertNull(jSDocInfo32);
        org.junit.Assert.assertNull(objectType33);
        org.junit.Assert.assertNotNull(jSTypeArray34);
        org.junit.Assert.assertNotNull(functionType35);
        org.junit.Assert.assertTrue("'" + jSTypeNative39 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative39.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative40 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative40.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative41 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative41.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray42);
        org.junit.Assert.assertNotNull(jSType43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(parameterizedType45);
        org.junit.Assert.assertNull(jSType47);
        org.junit.Assert.assertNull(str48);
        org.junit.Assert.assertTrue("'" + booleanLiteralSet49 + "' != '" + com.google.javascript.rhino.jstype.BooleanLiteralSet.TRUE + "'", booleanLiteralSet49.equals(com.google.javascript.rhino.jstype.BooleanLiteralSet.TRUE));
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, true);
        com.google.javascript.rhino.ErrorReporter errorReporter3 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter3, true);
        com.google.javascript.rhino.ErrorReporter errorReporter6 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry8 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter6, true);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative9 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative10 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative11 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray12 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative9, jSTypeNative10, jSTypeNative11 };
        com.google.javascript.rhino.jstype.JSType jSType13 = jSTypeRegistry8.createUnionType(jSTypeNativeArray12);
        boolean boolean14 = jSType13.isRegexpType();
        boolean boolean15 = jSType13.isNullable();
        com.google.javascript.rhino.ErrorReporter errorReporter16 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry18 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter16, true);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative19 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative20 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative21 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray22 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative19, jSTypeNative20, jSTypeNative21 };
        com.google.javascript.rhino.jstype.JSType jSType23 = jSTypeRegistry18.createUnionType(jSTypeNativeArray22);
        com.google.javascript.rhino.ErrorReporter errorReporter24 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry26 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter24, true);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative27 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative28 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative29 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray30 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative27, jSTypeNative28, jSTypeNative29 };
        com.google.javascript.rhino.jstype.JSType jSType31 = jSTypeRegistry26.createUnionType(jSTypeNativeArray30);
        com.google.javascript.rhino.JSDocInfo jSDocInfo32 = jSType31.getJSDocInfo();
        com.google.javascript.rhino.jstype.ObjectType objectType33 = jSType31.toObjectType();
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray34 = new com.google.javascript.rhino.jstype.JSType[] { jSType23, jSType31 };
        com.google.javascript.rhino.jstype.FunctionType functionType35 = jSTypeRegistry5.createConstructorTypeWithVarArgs(jSType13, jSTypeArray34);
        com.google.javascript.rhino.ErrorReporter errorReporter36 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry38 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter36, true);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative39 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative40 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative41 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray42 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative39, jSTypeNative40, jSTypeNative41 };
        com.google.javascript.rhino.jstype.JSType jSType43 = jSTypeRegistry38.createUnionType(jSTypeNativeArray42);
        boolean boolean44 = jSType43.isStringObjectType();
        com.google.javascript.rhino.jstype.ParameterizedType parameterizedType45 = jSTypeRegistry2.createParameterizedType((com.google.javascript.rhino.jstype.ObjectType) functionType35, jSType43);
        boolean boolean46 = parameterizedType45.hasAnyTemplateInternal();
        com.google.javascript.rhino.jstype.FunctionType functionType47 = parameterizedType45.getConstructor();
        boolean boolean48 = parameterizedType45.isBooleanValueType();
        com.google.javascript.rhino.Node node50 = parameterizedType45.getPropertyNode("Unknown class name");
        boolean boolean51 = parameterizedType45.matchesObjectContext();
        boolean boolean52 = parameterizedType45.hasAnyTemplate();
        boolean boolean53 = parameterizedType45.isObject();
        org.junit.Assert.assertTrue("'" + jSTypeNative9 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative9.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative10 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative10.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative11 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative11.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray12);
        org.junit.Assert.assertNotNull(jSType13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + jSTypeNative19 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative19.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative20 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative20.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative21 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative21.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray22);
        org.junit.Assert.assertNotNull(jSType23);
        org.junit.Assert.assertTrue("'" + jSTypeNative27 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative27.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative28 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative28.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative29 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative29.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray30);
        org.junit.Assert.assertNotNull(jSType31);
        org.junit.Assert.assertNull(jSDocInfo32);
        org.junit.Assert.assertNull(objectType33);
        org.junit.Assert.assertNotNull(jSTypeArray34);
        org.junit.Assert.assertNotNull(functionType35);
        org.junit.Assert.assertTrue("'" + jSTypeNative39 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative39.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative40 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative40.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative41 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative41.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray42);
        org.junit.Assert.assertNotNull(jSType43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(parameterizedType45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNull(functionType47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNull(node50);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + true + "'", boolean51 == true);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + true + "'", boolean53 == true);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        com.google.javascript.rhino.JSDocInfo jSDocInfo0 = new com.google.javascript.rhino.JSDocInfo();
        java.lang.String str1 = jSDocInfo0.getBlockDescription();
        boolean boolean2 = jSDocInfo0.isNoAlias();
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

//    @Test
//    public void test040() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test040");
//        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = null;
//        com.google.javascript.jscomp.DiagnosticType diagnosticType1 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
//        com.google.javascript.jscomp.CheckLevel checkLevel2 = null;
//        diagnosticType1.level = checkLevel2;
//        com.google.javascript.jscomp.CheckLevel checkLevel4 = diagnosticType1.defaultLevel;
//        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard5 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup0, checkLevel4);
//        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup6 = com.google.javascript.jscomp.DiagnosticGroups.CHECK_VARIABLES;
//        try {
//            boolean boolean7 = diagnosticGroupWarningsGuard5.enables(diagnosticGroup6);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(diagnosticType1);
//        org.junit.Assert.assertTrue("'" + checkLevel4 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel4.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
//        org.junit.Assert.assertNull(diagnosticGroup6);
//    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        com.google.javascript.jscomp.SourceAst sourceAst0 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(sourceAst0, "", false);
        com.google.javascript.jscomp.AbstractCompiler abstractCompiler4 = null;
        compilerInput3.setCompiler(abstractCompiler4);
        com.google.javascript.rhino.InputId inputId6 = compilerInput3.getInputId();
        com.google.javascript.jscomp.SourceAst sourceAst7 = compilerInput3.getAst();
        try {
            java.util.Collection<java.lang.String> strCollection8 = compilerInput3.getRequires();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Expected setCompiler to be called first: ");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(inputId6);
        org.junit.Assert.assertNull(sourceAst7);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        com.google.javascript.jscomp.SourceFile sourceFile3 = com.google.javascript.jscomp.SourceFile.fromCode("hi!", "Unknown class name", "Unknown class name");
        com.google.javascript.jscomp.Region region5 = sourceFile3.getRegion(2147483647);
        com.google.javascript.jscomp.CompilerInput compilerInput6 = new com.google.javascript.jscomp.CompilerInput(sourceFile3);
        com.google.javascript.rhino.InputId inputId7 = compilerInput6.getInputId();
        java.io.PrintStream printStream8 = null;
        com.google.javascript.jscomp.Compiler compiler9 = new com.google.javascript.jscomp.Compiler(printStream8);
        compilerInput6.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler9);
        com.google.javascript.rhino.Node node11 = compiler9.getRoot();
        com.google.javascript.jscomp.NodeTraversal.Callback callback12 = null;
        com.google.javascript.rhino.Node[] nodeArray13 = new com.google.javascript.rhino.Node[] {};
        com.google.javascript.jscomp.NodeTraversal.traverseRoots((com.google.javascript.jscomp.AbstractCompiler) compiler9, callback12, nodeArray13);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile15 = null;
        com.google.javascript.jscomp.SourceAst sourceAst16 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput19 = new com.google.javascript.jscomp.CompilerInput(sourceAst16, "", false);
        com.google.javascript.jscomp.AbstractCompiler abstractCompiler20 = null;
        compilerInput19.setCompiler(abstractCompiler20);
        com.google.javascript.rhino.InputId inputId22 = compilerInput19.getInputId();
        com.google.javascript.jscomp.JSModule jSModule24 = new com.google.javascript.jscomp.JSModule("hi!");
        com.google.javascript.jscomp.Compiler compiler25 = null;
        jSModule24.sortInputsByDeps(compiler25);
        jSModule24.setDepth(50);
        compilerInput19.setModule(jSModule24);
        com.google.javascript.jscomp.JSModule jSModule31 = new com.google.javascript.jscomp.JSModule("hi!");
        java.util.List<java.lang.String> strList32 = jSModule31.getProvides();
        com.google.javascript.jscomp.SourceFile sourceFile36 = com.google.javascript.jscomp.SourceFile.fromCode("hi!", "Unknown class name", "Unknown class name");
        com.google.javascript.jscomp.Region region38 = sourceFile36.getRegion(2147483647);
        jSModule31.add(sourceFile36);
        com.google.javascript.jscomp.JSModule jSModule41 = new com.google.javascript.jscomp.JSModule("hi!");
        com.google.javascript.jscomp.Compiler compiler42 = null;
        jSModule41.sortInputsByDeps(compiler42);
        jSModule41.setDepth(50);
        com.google.javascript.jscomp.JSModule jSModule47 = new com.google.javascript.jscomp.JSModule("hi!");
        java.lang.String str48 = jSModule47.toString();
        com.google.javascript.jscomp.SourceFile sourceFile52 = com.google.javascript.jscomp.SourceFile.fromCode("hi!", "Unknown class name", "Unknown class name");
        java.io.Reader reader53 = sourceFile52.getCodeReader();
        jSModule47.addFirst(sourceFile52);
        com.google.javascript.jscomp.SourceFile sourceFile58 = com.google.javascript.jscomp.SourceFile.fromCode("hi!", "Unknown class name", "Unknown class name");
        com.google.javascript.jscomp.Region region60 = sourceFile58.getRegion(2147483647);
        com.google.javascript.jscomp.CompilerInput compilerInput61 = new com.google.javascript.jscomp.CompilerInput(sourceFile58);
        com.google.javascript.jscomp.SourceAst sourceAst62 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput65 = new com.google.javascript.jscomp.CompilerInput(sourceAst62, "", false);
        com.google.javascript.rhino.InputId inputId66 = compilerInput65.getInputId();
        com.google.javascript.jscomp.CompilerInput compilerInput68 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput61, inputId66, false);
        jSModule47.addFirst(compilerInput61);
        com.google.javascript.jscomp.JSModule[] jSModuleArray70 = new com.google.javascript.jscomp.JSModule[] { jSModule24, jSModule31, jSModule41, jSModule47 };
        com.google.javascript.jscomp.CompilerOptions compilerOptions71 = null;
        try {
            com.google.javascript.jscomp.Result result72 = compiler9.compile(jSSourceFile15, jSModuleArray70, compilerOptions71);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(sourceFile3);
        org.junit.Assert.assertNull(region5);
        org.junit.Assert.assertNotNull(inputId7);
        org.junit.Assert.assertNull(node11);
        org.junit.Assert.assertNotNull(nodeArray13);
        org.junit.Assert.assertNotNull(inputId22);
        org.junit.Assert.assertNotNull(strList32);
        org.junit.Assert.assertNotNull(sourceFile36);
        org.junit.Assert.assertNull(region38);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "hi!" + "'", str48.equals("hi!"));
        org.junit.Assert.assertNotNull(sourceFile52);
        org.junit.Assert.assertNotNull(reader53);
        org.junit.Assert.assertNotNull(sourceFile58);
        org.junit.Assert.assertNull(region60);
        org.junit.Assert.assertNotNull(inputId66);
        org.junit.Assert.assertNotNull(jSModuleArray70);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newNumber((double) (short) -1, (int) (byte) 1, 0);
        boolean boolean4 = node3.isContinue();
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        com.google.javascript.jscomp.AnonymousFunctionNamingPolicy anonymousFunctionNamingPolicy0 = com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF;
        char[] charArray1 = anonymousFunctionNamingPolicy0.getReservedCharacters();
        char[] charArray2 = anonymousFunctionNamingPolicy0.getReservedCharacters();
        org.junit.Assert.assertTrue("'" + anonymousFunctionNamingPolicy0 + "' != '" + com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF + "'", anonymousFunctionNamingPolicy0.equals(com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF));
        org.junit.Assert.assertNull(charArray1);
        org.junit.Assert.assertNull(charArray2);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        boolean boolean2 = closureCodingConvention0.isSuperClassReference("hi!");
        boolean boolean4 = closureCodingConvention0.isSuperClassReference("{proxy:function ({1566169663}, {({1804413486},{656799354})}): {1133890062}}");
        boolean boolean6 = closureCodingConvention0.isPrivate("function ({1262020967}, {({954206644},{1279119928})}): {1555607401}");
        com.google.javascript.rhino.Node node8 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode((com.google.javascript.jscomp.CodingConvention) closureCodingConvention0, "function ({704695011}, {({259914045},{1783918382})}): {426199371}");
        boolean boolean10 = closureCodingConvention0.isSuperClassReference("function ({973952929}, {({834630149},{962344528})}): {100783531}");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        boolean boolean2 = closureCodingConvention0.isSuperClassReference("hi!");
        boolean boolean4 = closureCodingConvention0.isSuperClassReference("{proxy:function ({1566169663}, {({1804413486},{656799354})}): {1133890062}}");
        com.google.javascript.rhino.Node node5 = null;
        try {
            com.google.javascript.jscomp.CodingConvention.ObjectLiteralCast objectLiteralCast6 = closureCodingConvention0.getObjectLiteralCast(node5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        java.util.Collection<com.google.javascript.jscomp.CodingConvention.AssertionFunctionSpec> assertionFunctionSpecCollection1 = closureCodingConvention0.getAssertionFunctions();
        boolean boolean3 = closureCodingConvention0.isSuperClassReference("");
        java.lang.String str4 = closureCodingConvention0.getExportSymbolFunction();
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newNumber((double) (short) 100);
        boolean boolean7 = closureCodingConvention0.isVarArgsParameter(node6);
        org.junit.Assert.assertNotNull(assertionFunctionSpecCollection1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "goog.exportSymbol" + "'", str4.equals("goog.exportSymbol"));
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        com.google.javascript.rhino.JSDocInfo.NamePosition namePosition0 = new com.google.javascript.rhino.JSDocInfo.NamePosition();
        int int1 = namePosition0.getEndLine();
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newNumber((double) (short) -1, (int) (byte) 1, 0);
        boolean boolean6 = node5.isArrayLit();
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newNumber((double) (short) -1, (int) (byte) 1, 0);
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.IR.getelem(node5, node10);
        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.Node.newNumber((double) (short) -1, (int) (byte) 1, 0);
        boolean boolean17 = node16.isArrayLit();
        boolean boolean18 = node16.isLabelName();
        com.google.javascript.rhino.Node node22 = com.google.javascript.rhino.Node.newNumber((double) (short) -1, (int) (byte) 1, 0);
        boolean boolean23 = node22.isArrayLit();
        com.google.javascript.rhino.Node node27 = com.google.javascript.rhino.Node.newNumber((double) (short) -1, (int) (byte) 1, 0);
        com.google.javascript.rhino.Node node28 = new com.google.javascript.rhino.Node((int) '#', node16, node22, node27);
        com.google.javascript.rhino.Node node30 = com.google.javascript.rhino.Node.newNumber(0.0d);
        com.google.javascript.rhino.Node node31 = node16.copyInformationFromForTree(node30);
        com.google.javascript.rhino.Node node32 = node5.copyInformationFrom(node31);
        boolean boolean33 = node5.isRegExp();
        node5.setLineno(15);
        namePosition0.setItem(node5);
        com.google.javascript.rhino.Node node40 = com.google.javascript.rhino.Node.newNumber((double) (short) -1, (int) (byte) 1, 0);
        boolean boolean41 = node40.isArrayLit();
        com.google.javascript.rhino.Node node45 = com.google.javascript.rhino.Node.newNumber((double) (short) -1, (int) (byte) 1, 0);
        com.google.javascript.rhino.Node node46 = com.google.javascript.rhino.IR.getelem(node40, node45);
        boolean boolean47 = node46.isCatch();
        boolean boolean48 = node46.isIf();
        node46.removeProp((int) '#');
        java.lang.Object obj52 = node46.getProp(38);
        boolean boolean54 = node46.getBooleanProp((int) (byte) 100);
        namePosition0.setItem(node46);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(node27);
        org.junit.Assert.assertNotNull(node30);
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertNotNull(node32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(node40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(node45);
        org.junit.Assert.assertNotNull(node46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNull(obj52);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        com.google.javascript.jscomp.ClosureCodingConvention.AssertInstanceofSpec assertInstanceofSpec1 = new com.google.javascript.jscomp.ClosureCodingConvention.AssertInstanceofSpec("");
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newNumber((double) (short) -1, (int) (byte) 1, 0);
        boolean boolean6 = node5.isArrayLit();
        boolean boolean7 = node5.isLabelName();
        com.google.javascript.rhino.Node node8 = node5.cloneNode();
        com.google.javascript.rhino.ErrorReporter errorReporter9 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry11 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter9, true);
        com.google.javascript.rhino.jstype.JSType jSType16 = jSTypeRegistry11.createNamedType("GETELEM", "hi!", 0, 38);
        jSTypeRegistry11.incrementGeneration();
        com.google.javascript.rhino.ErrorReporter errorReporter18 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry20 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter18, true);
        com.google.javascript.rhino.ErrorReporter errorReporter21 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry23 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter21, true);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative24 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative25 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative26 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray27 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative24, jSTypeNative25, jSTypeNative26 };
        com.google.javascript.rhino.jstype.JSType jSType28 = jSTypeRegistry23.createUnionType(jSTypeNativeArray27);
        boolean boolean29 = jSType28.isRegexpType();
        boolean boolean30 = jSType28.isNullable();
        com.google.javascript.rhino.ErrorReporter errorReporter31 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry33 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter31, true);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative34 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative35 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative36 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray37 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative34, jSTypeNative35, jSTypeNative36 };
        com.google.javascript.rhino.jstype.JSType jSType38 = jSTypeRegistry33.createUnionType(jSTypeNativeArray37);
        com.google.javascript.rhino.ErrorReporter errorReporter39 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry41 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter39, true);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative42 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative43 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative44 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray45 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative42, jSTypeNative43, jSTypeNative44 };
        com.google.javascript.rhino.jstype.JSType jSType46 = jSTypeRegistry41.createUnionType(jSTypeNativeArray45);
        com.google.javascript.rhino.JSDocInfo jSDocInfo47 = jSType46.getJSDocInfo();
        com.google.javascript.rhino.jstype.ObjectType objectType48 = jSType46.toObjectType();
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray49 = new com.google.javascript.rhino.jstype.JSType[] { jSType38, jSType46 };
        com.google.javascript.rhino.jstype.FunctionType functionType50 = jSTypeRegistry20.createConstructorTypeWithVarArgs(jSType28, jSTypeArray49);
        java.lang.Iterable iterable51 = functionType50.getCtorImplementedInterfaces();
        jSTypeRegistry11.resolveTypesInScope((com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType>) functionType50);
        com.google.javascript.rhino.jstype.JSType jSType53 = assertInstanceofSpec1.getAssertedType(node8, jSTypeRegistry11);
        boolean boolean54 = node8.isName();
        com.google.javascript.rhino.Node node55 = node8.getParent();
        node8.setWasEmptyNode(true);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNotNull(jSType16);
        org.junit.Assert.assertTrue("'" + jSTypeNative24 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative24.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative25 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative25.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative26 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative26.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray27);
        org.junit.Assert.assertNotNull(jSType28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + jSTypeNative34 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative34.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative35 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative35.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative36 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative36.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray37);
        org.junit.Assert.assertNotNull(jSType38);
        org.junit.Assert.assertTrue("'" + jSTypeNative42 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative42.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative43 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative43.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative44 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative44.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray45);
        org.junit.Assert.assertNotNull(jSType46);
        org.junit.Assert.assertNull(jSDocInfo47);
        org.junit.Assert.assertNull(objectType48);
        org.junit.Assert.assertNotNull(jSTypeArray49);
        org.junit.Assert.assertNotNull(functionType50);
        org.junit.Assert.assertNotNull(iterable51);
        org.junit.Assert.assertNotNull(jSType53);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNull(node55);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, true);
        com.google.javascript.rhino.ErrorReporter errorReporter3 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter3, true);
        com.google.javascript.rhino.ErrorReporter errorReporter6 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry8 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter6, true);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative9 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative10 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative11 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray12 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative9, jSTypeNative10, jSTypeNative11 };
        com.google.javascript.rhino.jstype.JSType jSType13 = jSTypeRegistry8.createUnionType(jSTypeNativeArray12);
        boolean boolean14 = jSType13.isRegexpType();
        boolean boolean15 = jSType13.isNullable();
        com.google.javascript.rhino.ErrorReporter errorReporter16 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry18 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter16, true);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative19 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative20 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative21 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray22 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative19, jSTypeNative20, jSTypeNative21 };
        com.google.javascript.rhino.jstype.JSType jSType23 = jSTypeRegistry18.createUnionType(jSTypeNativeArray22);
        com.google.javascript.rhino.ErrorReporter errorReporter24 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry26 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter24, true);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative27 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative28 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative29 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray30 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative27, jSTypeNative28, jSTypeNative29 };
        com.google.javascript.rhino.jstype.JSType jSType31 = jSTypeRegistry26.createUnionType(jSTypeNativeArray30);
        com.google.javascript.rhino.JSDocInfo jSDocInfo32 = jSType31.getJSDocInfo();
        com.google.javascript.rhino.jstype.ObjectType objectType33 = jSType31.toObjectType();
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray34 = new com.google.javascript.rhino.jstype.JSType[] { jSType23, jSType31 };
        com.google.javascript.rhino.jstype.FunctionType functionType35 = jSTypeRegistry5.createConstructorTypeWithVarArgs(jSType13, jSTypeArray34);
        com.google.javascript.rhino.ErrorReporter errorReporter36 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry38 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter36, true);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative39 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative40 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative41 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray42 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative39, jSTypeNative40, jSTypeNative41 };
        com.google.javascript.rhino.jstype.JSType jSType43 = jSTypeRegistry38.createUnionType(jSTypeNativeArray42);
        boolean boolean44 = jSType43.isStringObjectType();
        com.google.javascript.rhino.jstype.ParameterizedType parameterizedType45 = jSTypeRegistry2.createParameterizedType((com.google.javascript.rhino.jstype.ObjectType) functionType35, jSType43);
        boolean boolean46 = parameterizedType45.hasAnyTemplateInternal();
        com.google.javascript.rhino.jstype.FunctionType functionType47 = parameterizedType45.getConstructor();
        com.google.javascript.rhino.jstype.JSType jSType49 = parameterizedType45.getPropertyType("{proxy:function ({1047075399}, {({605412354},{558514873})}): {1793560964}}");
        boolean boolean50 = parameterizedType45.isNoObjectType();
        boolean boolean52 = parameterizedType45.hasOwnProperty("Unversioned directory");
        org.junit.Assert.assertTrue("'" + jSTypeNative9 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative9.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative10 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative10.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative11 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative11.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray12);
        org.junit.Assert.assertNotNull(jSType13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + jSTypeNative19 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative19.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative20 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative20.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative21 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative21.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray22);
        org.junit.Assert.assertNotNull(jSType23);
        org.junit.Assert.assertTrue("'" + jSTypeNative27 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative27.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative28 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative28.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative29 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative29.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray30);
        org.junit.Assert.assertNotNull(jSType31);
        org.junit.Assert.assertNull(jSDocInfo32);
        org.junit.Assert.assertNull(objectType33);
        org.junit.Assert.assertNotNull(jSTypeArray34);
        org.junit.Assert.assertNotNull(functionType35);
        org.junit.Assert.assertTrue("'" + jSTypeNative39 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative39.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative40 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative40.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative41 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative41.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray42);
        org.junit.Assert.assertNotNull(jSType43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(parameterizedType45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNull(functionType47);
        org.junit.Assert.assertNotNull(jSType49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        com.google.javascript.jscomp.CustomPassExecutionTime customPassExecutionTime0 = com.google.javascript.jscomp.CustomPassExecutionTime.BEFORE_OPTIMIZATION_LOOP;
        org.junit.Assert.assertTrue("'" + customPassExecutionTime0 + "' != '" + com.google.javascript.jscomp.CustomPassExecutionTime.BEFORE_OPTIMIZATION_LOOP + "'", customPassExecutionTime0.equals(com.google.javascript.jscomp.CustomPassExecutionTime.BEFORE_OPTIMIZATION_LOOP));
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        com.google.javascript.rhino.ErrorReporter errorReporter1 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry3 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter1, true);
        com.google.javascript.rhino.ErrorReporter errorReporter4 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry6 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter4, true);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative7 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative8 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative9 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray10 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative7, jSTypeNative8, jSTypeNative9 };
        com.google.javascript.rhino.jstype.JSType jSType11 = jSTypeRegistry6.createUnionType(jSTypeNativeArray10);
        boolean boolean12 = jSType11.isRegexpType();
        boolean boolean13 = jSType11.isNullable();
        com.google.javascript.rhino.ErrorReporter errorReporter14 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry16 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter14, true);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative17 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative18 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative19 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray20 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative17, jSTypeNative18, jSTypeNative19 };
        com.google.javascript.rhino.jstype.JSType jSType21 = jSTypeRegistry16.createUnionType(jSTypeNativeArray20);
        com.google.javascript.rhino.ErrorReporter errorReporter22 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry24 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter22, true);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative25 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative26 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative27 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray28 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative25, jSTypeNative26, jSTypeNative27 };
        com.google.javascript.rhino.jstype.JSType jSType29 = jSTypeRegistry24.createUnionType(jSTypeNativeArray28);
        com.google.javascript.rhino.JSDocInfo jSDocInfo30 = jSType29.getJSDocInfo();
        com.google.javascript.rhino.jstype.ObjectType objectType31 = jSType29.toObjectType();
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray32 = new com.google.javascript.rhino.jstype.JSType[] { jSType21, jSType29 };
        com.google.javascript.rhino.jstype.FunctionType functionType33 = jSTypeRegistry3.createConstructorTypeWithVarArgs(jSType11, jSTypeArray32);
        boolean boolean34 = functionType33.isConstructor();
        java.lang.String str35 = functionType33.toAnnotationString();
        com.google.javascript.rhino.Node node40 = com.google.javascript.rhino.Node.newNumber((double) (short) -1, (int) (byte) 1, 0);
        boolean boolean41 = node40.isArrayLit();
        boolean boolean42 = node40.isLabelName();
        com.google.javascript.rhino.Node node46 = com.google.javascript.rhino.Node.newNumber((double) (short) -1, (int) (byte) 1, 0);
        boolean boolean47 = node46.isArrayLit();
        com.google.javascript.rhino.Node node51 = com.google.javascript.rhino.Node.newNumber((double) (short) -1, (int) (byte) 1, 0);
        com.google.javascript.rhino.Node node52 = new com.google.javascript.rhino.Node((int) '#', node40, node46, node51);
        com.google.javascript.rhino.Node node54 = com.google.javascript.rhino.Node.newNumber(0.0d);
        com.google.javascript.rhino.Node node55 = node40.copyInformationFromForTree(node54);
        boolean boolean56 = node55.isAssign();
        functionType33.setSource(node55);
        try {
            com.google.javascript.rhino.Node node58 = new com.google.javascript.rhino.Node(36, node55);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: new child has existing parent");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + jSTypeNative7 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative7.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative8 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative8.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative9 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative9.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray10);
        org.junit.Assert.assertNotNull(jSType11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + jSTypeNative17 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative17.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative18 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative18.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative19 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative19.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray20);
        org.junit.Assert.assertNotNull(jSType21);
        org.junit.Assert.assertTrue("'" + jSTypeNative25 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative25.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative26 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative26.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative27 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative27.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray28);
        org.junit.Assert.assertNotNull(jSType29);
        org.junit.Assert.assertNull(jSDocInfo30);
        org.junit.Assert.assertNull(objectType31);
        org.junit.Assert.assertNotNull(jSTypeArray32);
        org.junit.Assert.assertNotNull(functionType33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "function (new:?, boolean, ...[boolean]): boolean" + "'", str35.equals("function (new:?, boolean, ...[boolean]): boolean"));
        org.junit.Assert.assertNotNull(node40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(node46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(node51);
        org.junit.Assert.assertNotNull(node54);
        org.junit.Assert.assertNotNull(node55);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        com.google.javascript.jscomp.MessageFormatter messageFormatter0 = null;
        java.util.logging.Logger logger1 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager2 = new com.google.javascript.jscomp.LoggerErrorManager(messageFormatter0, logger1);
        loggerErrorManager2.setTypedPercent((double) 100);
        com.google.javascript.jscomp.CheckLevel checkLevel5 = null;
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newNumber((double) (short) -1, (int) (byte) 1, 0);
        boolean boolean11 = node10.isArrayLit();
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.Node.newNumber((double) (short) -1, (int) (byte) 1, 0);
        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.IR.getelem(node10, node15);
        boolean boolean17 = node15.isTrue();
        com.google.javascript.jscomp.CheckLevel checkLevel18 = null;
        com.google.javascript.jscomp.DiagnosticType diagnosticType19 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        java.lang.String[] strArray20 = new java.lang.String[] {};
        com.google.javascript.jscomp.JSError jSError21 = com.google.javascript.jscomp.JSError.make("GETELEM", node15, checkLevel18, diagnosticType19, strArray20);
        loggerErrorManager2.report(checkLevel5, jSError21);
        int int23 = jSError21.getLineNumber();
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(diagnosticType19);
        org.junit.Assert.assertNotNull(strArray20);
        org.junit.Assert.assertNotNull(jSError21);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        com.google.javascript.jscomp.SourceMap.Format format0 = com.google.javascript.jscomp.SourceMap.Format.DEFAULT;
        org.junit.Assert.assertNotNull(format0);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        com.google.javascript.jscomp.Compiler.CodeBuilder codeBuilder0 = new com.google.javascript.jscomp.Compiler.CodeBuilder();
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, true);
        com.google.javascript.rhino.ErrorReporter errorReporter3 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter3, true);
        com.google.javascript.rhino.ErrorReporter errorReporter6 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry8 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter6, true);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative9 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative10 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative11 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray12 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative9, jSTypeNative10, jSTypeNative11 };
        com.google.javascript.rhino.jstype.JSType jSType13 = jSTypeRegistry8.createUnionType(jSTypeNativeArray12);
        boolean boolean14 = jSType13.isRegexpType();
        boolean boolean15 = jSType13.isNullable();
        com.google.javascript.rhino.ErrorReporter errorReporter16 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry18 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter16, true);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative19 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative20 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative21 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray22 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative19, jSTypeNative20, jSTypeNative21 };
        com.google.javascript.rhino.jstype.JSType jSType23 = jSTypeRegistry18.createUnionType(jSTypeNativeArray22);
        com.google.javascript.rhino.ErrorReporter errorReporter24 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry26 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter24, true);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative27 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative28 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative29 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray30 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative27, jSTypeNative28, jSTypeNative29 };
        com.google.javascript.rhino.jstype.JSType jSType31 = jSTypeRegistry26.createUnionType(jSTypeNativeArray30);
        com.google.javascript.rhino.JSDocInfo jSDocInfo32 = jSType31.getJSDocInfo();
        com.google.javascript.rhino.jstype.ObjectType objectType33 = jSType31.toObjectType();
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray34 = new com.google.javascript.rhino.jstype.JSType[] { jSType23, jSType31 };
        com.google.javascript.rhino.jstype.FunctionType functionType35 = jSTypeRegistry5.createConstructorTypeWithVarArgs(jSType13, jSTypeArray34);
        com.google.javascript.rhino.ErrorReporter errorReporter36 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry38 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter36, true);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative39 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative40 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative41 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray42 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative39, jSTypeNative40, jSTypeNative41 };
        com.google.javascript.rhino.jstype.JSType jSType43 = jSTypeRegistry38.createUnionType(jSTypeNativeArray42);
        boolean boolean44 = jSType43.isStringObjectType();
        com.google.javascript.rhino.jstype.ParameterizedType parameterizedType45 = jSTypeRegistry2.createParameterizedType((com.google.javascript.rhino.jstype.ObjectType) functionType35, jSType43);
        int int46 = functionType35.getMinArguments();
        boolean boolean47 = functionType35.isVoidType();
        com.google.javascript.rhino.jstype.JSType jSType48 = functionType35.getParameterType();
        boolean boolean49 = functionType35.isInstanceType();
        com.google.javascript.rhino.jstype.JSType jSType50 = functionType35.unboxesTo();
        com.google.javascript.rhino.JSDocInfo jSDocInfo52 = functionType35.getOwnPropertyJSDocInfo("function (new:?, boolean, ...[boolean]): boolean");
        org.junit.Assert.assertTrue("'" + jSTypeNative9 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative9.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative10 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative10.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative11 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative11.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray12);
        org.junit.Assert.assertNotNull(jSType13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + jSTypeNative19 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative19.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative20 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative20.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative21 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative21.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray22);
        org.junit.Assert.assertNotNull(jSType23);
        org.junit.Assert.assertTrue("'" + jSTypeNative27 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative27.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative28 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative28.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative29 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative29.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray30);
        org.junit.Assert.assertNotNull(jSType31);
        org.junit.Assert.assertNull(jSDocInfo32);
        org.junit.Assert.assertNull(objectType33);
        org.junit.Assert.assertNotNull(jSTypeArray34);
        org.junit.Assert.assertNotNull(functionType35);
        org.junit.Assert.assertTrue("'" + jSTypeNative39 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative39.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative40 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative40.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative41 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative41.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray42);
        org.junit.Assert.assertNotNull(jSType43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(parameterizedType45);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 1 + "'", int46 == 1);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNull(jSType48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNull(jSType50);
        org.junit.Assert.assertNull(jSDocInfo52);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.GLOBAL_THIS;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.GLOBAL_THIS + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.GLOBAL_THIS));
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        com.google.javascript.jscomp.DiagnosticType diagnosticType0 = com.google.javascript.jscomp.Compiler.MOTION_ITERATIONS_ERROR;
        com.google.javascript.jscomp.CheckLevel checkLevel1 = diagnosticType0.defaultLevel;
        org.junit.Assert.assertNotNull(diagnosticType0);
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        com.google.javascript.rhino.Node node0 = null;
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newNumber(0.0d);
        com.google.javascript.rhino.Node[] nodeArray4 = new com.google.javascript.rhino.Node[] { node3 };
        com.google.javascript.rhino.Node node7 = new com.google.javascript.rhino.Node(4, nodeArray4, 1, (int) (short) 100);
        try {
            com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.IR.newNode(node0, nodeArray4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(nodeArray4);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        com.google.javascript.jscomp.SourceFile sourceFile3 = com.google.javascript.jscomp.SourceFile.fromCode("hi!", "Unknown class name", "Unknown class name");
        com.google.javascript.jscomp.Region region5 = sourceFile3.getRegion(2147483647);
        com.google.javascript.jscomp.CompilerInput compilerInput6 = new com.google.javascript.jscomp.CompilerInput(sourceFile3);
        com.google.javascript.rhino.InputId inputId7 = compilerInput6.getInputId();
        java.io.PrintStream printStream8 = null;
        com.google.javascript.jscomp.Compiler compiler9 = new com.google.javascript.jscomp.Compiler(printStream8);
        compilerInput6.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler9);
        com.google.javascript.jscomp.NodeTraversal.Callback callback11 = null;
        com.google.javascript.rhino.Node[] nodeArray12 = new com.google.javascript.rhino.Node[] {};
        com.google.javascript.jscomp.NodeTraversal.traverseRoots((com.google.javascript.jscomp.AbstractCompiler) compiler9, callback11, nodeArray12);
        try {
            com.google.javascript.jscomp.type.ReverseAbstractInterpreter reverseAbstractInterpreter14 = compiler9.getReverseAbstractInterpreter();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(sourceFile3);
        org.junit.Assert.assertNull(region5);
        org.junit.Assert.assertNotNull(inputId7);
        org.junit.Assert.assertNotNull(nodeArray12);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, true);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative3 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative4 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative5 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray6 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative3, jSTypeNative4, jSTypeNative5 };
        com.google.javascript.rhino.jstype.JSType jSType7 = jSTypeRegistry2.createUnionType(jSTypeNativeArray6);
        com.google.javascript.rhino.ErrorReporter errorReporter8 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry10 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter8, true);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative11 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative12 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative13 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray14 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative11, jSTypeNative12, jSTypeNative13 };
        com.google.javascript.rhino.jstype.JSType jSType15 = jSTypeRegistry10.createUnionType(jSTypeNativeArray14);
        boolean boolean16 = jSType15.isRegexpType();
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray17 = new com.google.javascript.rhino.jstype.JSType[] { jSType15 };
        com.google.javascript.rhino.jstype.JSType jSType18 = jSTypeRegistry2.createUnionType(jSTypeArray17);
        java.lang.String str19 = jSType18.toAnnotationString();
        boolean boolean20 = jSType18.isString();
        boolean boolean21 = jSType18.isOrdinaryFunction();
        org.junit.Assert.assertTrue("'" + jSTypeNative3 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative3.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative4 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative4.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative5 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative5.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray6);
        org.junit.Assert.assertNotNull(jSType7);
        org.junit.Assert.assertTrue("'" + jSTypeNative11 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative11.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative12 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative12.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative13 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative13.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray14);
        org.junit.Assert.assertNotNull(jSType15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(jSTypeArray17);
        org.junit.Assert.assertNotNull(jSType18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "boolean" + "'", str19.equals("boolean"));
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, true);
        com.google.javascript.rhino.ErrorReporter errorReporter3 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter3, true);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative6 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative7 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative8 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray9 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative6, jSTypeNative7, jSTypeNative8 };
        com.google.javascript.rhino.jstype.JSType jSType10 = jSTypeRegistry5.createUnionType(jSTypeNativeArray9);
        boolean boolean11 = jSType10.isRegexpType();
        boolean boolean12 = jSType10.isNullable();
        com.google.javascript.rhino.ErrorReporter errorReporter13 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry15 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter13, true);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative16 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative17 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative18 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray19 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative16, jSTypeNative17, jSTypeNative18 };
        com.google.javascript.rhino.jstype.JSType jSType20 = jSTypeRegistry15.createUnionType(jSTypeNativeArray19);
        com.google.javascript.rhino.ErrorReporter errorReporter21 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry23 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter21, true);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative24 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative25 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative26 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray27 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative24, jSTypeNative25, jSTypeNative26 };
        com.google.javascript.rhino.jstype.JSType jSType28 = jSTypeRegistry23.createUnionType(jSTypeNativeArray27);
        com.google.javascript.rhino.JSDocInfo jSDocInfo29 = jSType28.getJSDocInfo();
        com.google.javascript.rhino.jstype.ObjectType objectType30 = jSType28.toObjectType();
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray31 = new com.google.javascript.rhino.jstype.JSType[] { jSType20, jSType28 };
        com.google.javascript.rhino.jstype.FunctionType functionType32 = jSTypeRegistry2.createConstructorTypeWithVarArgs(jSType10, jSTypeArray31);
        java.lang.Iterable iterable33 = functionType32.getCtorImplementedInterfaces();
        com.google.javascript.rhino.Node node34 = functionType32.getSource();
        com.google.javascript.rhino.jstype.ObjectType objectType36 = com.google.javascript.rhino.jstype.FunctionType.getTopDefiningInterface((com.google.javascript.rhino.jstype.ObjectType) functionType32, "function ({1262020967}, {({954206644},{1279119928})}): {1555607401}");
        com.google.javascript.rhino.jstype.FunctionType functionType37 = functionType32.cloneWithoutArrowType();
        org.junit.Assert.assertTrue("'" + jSTypeNative6 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative6.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative7 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative7.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative8 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative8.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray9);
        org.junit.Assert.assertNotNull(jSType10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + jSTypeNative16 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative16.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative17 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative17.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative18 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative18.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray19);
        org.junit.Assert.assertNotNull(jSType20);
        org.junit.Assert.assertTrue("'" + jSTypeNative24 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative24.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative25 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative25.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative26 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative26.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray27);
        org.junit.Assert.assertNotNull(jSType28);
        org.junit.Assert.assertNull(jSDocInfo29);
        org.junit.Assert.assertNull(objectType30);
        org.junit.Assert.assertNotNull(jSTypeArray31);
        org.junit.Assert.assertNotNull(functionType32);
        org.junit.Assert.assertNotNull(iterable33);
        org.junit.Assert.assertNull(node34);
        org.junit.Assert.assertNull(objectType36);
        org.junit.Assert.assertNotNull(functionType37);
    }

//    @Test
//    public void test063() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test063");
//        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, true);
//        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative3 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
//        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative4 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
//        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative5 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
//        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray6 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative3, jSTypeNative4, jSTypeNative5 };
//        com.google.javascript.rhino.jstype.JSType jSType7 = jSTypeRegistry2.createUnionType(jSTypeNativeArray6);
//        jSTypeRegistry2.clearTemplateTypeNames();
//        com.google.javascript.rhino.ErrorReporter errorReporter9 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry11 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter9, true);
//        com.google.javascript.rhino.ErrorReporter errorReporter12 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry14 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter12, true);
//        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative15 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
//        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative16 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
//        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative17 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
//        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray18 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative15, jSTypeNative16, jSTypeNative17 };
//        com.google.javascript.rhino.jstype.JSType jSType19 = jSTypeRegistry14.createUnionType(jSTypeNativeArray18);
//        boolean boolean20 = jSType19.isRegexpType();
//        boolean boolean21 = jSType19.isNullable();
//        com.google.javascript.rhino.ErrorReporter errorReporter22 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry24 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter22, true);
//        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative25 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
//        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative26 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
//        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative27 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
//        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray28 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative25, jSTypeNative26, jSTypeNative27 };
//        com.google.javascript.rhino.jstype.JSType jSType29 = jSTypeRegistry24.createUnionType(jSTypeNativeArray28);
//        com.google.javascript.rhino.ErrorReporter errorReporter30 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry32 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter30, true);
//        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative33 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
//        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative34 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
//        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative35 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
//        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray36 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative33, jSTypeNative34, jSTypeNative35 };
//        com.google.javascript.rhino.jstype.JSType jSType37 = jSTypeRegistry32.createUnionType(jSTypeNativeArray36);
//        com.google.javascript.rhino.JSDocInfo jSDocInfo38 = jSType37.getJSDocInfo();
//        com.google.javascript.rhino.jstype.ObjectType objectType39 = jSType37.toObjectType();
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray40 = new com.google.javascript.rhino.jstype.JSType[] { jSType29, jSType37 };
//        com.google.javascript.rhino.jstype.FunctionType functionType41 = jSTypeRegistry11.createConstructorTypeWithVarArgs(jSType19, jSTypeArray40);
//        java.lang.Iterable iterable42 = functionType41.getCtorImplementedInterfaces();
//        com.google.javascript.rhino.Node node43 = functionType41.getSource();
//        com.google.javascript.rhino.ErrorReporter errorReporter45 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry47 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter45, true);
//        com.google.javascript.rhino.ErrorReporter errorReporter48 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry50 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter48, true);
//        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative51 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
//        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative52 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
//        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative53 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
//        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray54 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative51, jSTypeNative52, jSTypeNative53 };
//        com.google.javascript.rhino.jstype.JSType jSType55 = jSTypeRegistry50.createUnionType(jSTypeNativeArray54);
//        boolean boolean56 = jSType55.isRegexpType();
//        boolean boolean57 = jSType55.isNullable();
//        com.google.javascript.rhino.ErrorReporter errorReporter58 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry60 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter58, true);
//        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative61 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
//        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative62 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
//        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative63 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
//        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray64 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative61, jSTypeNative62, jSTypeNative63 };
//        com.google.javascript.rhino.jstype.JSType jSType65 = jSTypeRegistry60.createUnionType(jSTypeNativeArray64);
//        com.google.javascript.rhino.ErrorReporter errorReporter66 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry68 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter66, true);
//        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative69 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
//        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative70 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
//        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative71 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
//        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray72 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative69, jSTypeNative70, jSTypeNative71 };
//        com.google.javascript.rhino.jstype.JSType jSType73 = jSTypeRegistry68.createUnionType(jSTypeNativeArray72);
//        com.google.javascript.rhino.JSDocInfo jSDocInfo74 = jSType73.getJSDocInfo();
//        com.google.javascript.rhino.jstype.ObjectType objectType75 = jSType73.toObjectType();
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray76 = new com.google.javascript.rhino.jstype.JSType[] { jSType65, jSType73 };
//        com.google.javascript.rhino.jstype.FunctionType functionType77 = jSTypeRegistry47.createConstructorTypeWithVarArgs(jSType55, jSTypeArray76);
//        com.google.javascript.rhino.jstype.FunctionType functionType78 = jSTypeRegistry2.createFunctionType((com.google.javascript.rhino.jstype.JSType) functionType41, true, jSTypeArray76);
//        boolean boolean80 = functionType78.isPropertyInExterns("hi!");
//        com.google.javascript.rhino.JSDocInfo jSDocInfo82 = functionType78.getOwnPropertyJSDocInfo("({proxy:function ({1047075399}, {({605412354},{558514873})}): {1793560964}})");
//        java.lang.String str83 = functionType78.toDebugHashCodeString();
//        boolean boolean85 = functionType78.isPropertyTypeDeclared("JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of optimization iterations: {0}");
//        org.junit.Assert.assertTrue("'" + jSTypeNative3 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative3.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
//        org.junit.Assert.assertTrue("'" + jSTypeNative4 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative4.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
//        org.junit.Assert.assertTrue("'" + jSTypeNative5 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative5.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
//        org.junit.Assert.assertNotNull(jSTypeNativeArray6);
//        org.junit.Assert.assertNotNull(jSType7);
//        org.junit.Assert.assertTrue("'" + jSTypeNative15 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative15.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
//        org.junit.Assert.assertTrue("'" + jSTypeNative16 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative16.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
//        org.junit.Assert.assertTrue("'" + jSTypeNative17 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative17.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
//        org.junit.Assert.assertNotNull(jSTypeNativeArray18);
//        org.junit.Assert.assertNotNull(jSType19);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertTrue("'" + jSTypeNative25 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative25.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
//        org.junit.Assert.assertTrue("'" + jSTypeNative26 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative26.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
//        org.junit.Assert.assertTrue("'" + jSTypeNative27 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative27.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
//        org.junit.Assert.assertNotNull(jSTypeNativeArray28);
//        org.junit.Assert.assertNotNull(jSType29);
//        org.junit.Assert.assertTrue("'" + jSTypeNative33 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative33.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
//        org.junit.Assert.assertTrue("'" + jSTypeNative34 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative34.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
//        org.junit.Assert.assertTrue("'" + jSTypeNative35 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative35.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
//        org.junit.Assert.assertNotNull(jSTypeNativeArray36);
//        org.junit.Assert.assertNotNull(jSType37);
//        org.junit.Assert.assertNull(jSDocInfo38);
//        org.junit.Assert.assertNull(objectType39);
//        org.junit.Assert.assertNotNull(jSTypeArray40);
//        org.junit.Assert.assertNotNull(functionType41);
//        org.junit.Assert.assertNotNull(iterable42);
//        org.junit.Assert.assertNull(node43);
//        org.junit.Assert.assertTrue("'" + jSTypeNative51 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative51.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
//        org.junit.Assert.assertTrue("'" + jSTypeNative52 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative52.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
//        org.junit.Assert.assertTrue("'" + jSTypeNative53 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative53.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
//        org.junit.Assert.assertNotNull(jSTypeNativeArray54);
//        org.junit.Assert.assertNotNull(jSType55);
//        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
//        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
//        org.junit.Assert.assertTrue("'" + jSTypeNative61 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative61.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
//        org.junit.Assert.assertTrue("'" + jSTypeNative62 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative62.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
//        org.junit.Assert.assertTrue("'" + jSTypeNative63 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative63.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
//        org.junit.Assert.assertNotNull(jSTypeNativeArray64);
//        org.junit.Assert.assertNotNull(jSType65);
//        org.junit.Assert.assertTrue("'" + jSTypeNative69 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative69.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
//        org.junit.Assert.assertTrue("'" + jSTypeNative70 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative70.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
//        org.junit.Assert.assertTrue("'" + jSTypeNative71 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative71.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
//        org.junit.Assert.assertNotNull(jSTypeNativeArray72);
//        org.junit.Assert.assertNotNull(jSType73);
//        org.junit.Assert.assertNull(jSDocInfo74);
//        org.junit.Assert.assertNull(objectType75);
//        org.junit.Assert.assertNotNull(jSTypeArray76);
//        org.junit.Assert.assertNotNull(functionType77);
//        org.junit.Assert.assertNotNull(functionType78);
//        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + false + "'", boolean80 == false);
//        org.junit.Assert.assertNull(jSDocInfo82);
//        org.junit.Assert.assertTrue("'" + str83 + "' != '" + "function ({1448401802}, {({485960443},{11478486})}): function ({1404200755}, {({2081673381},{610413360})}): {1122382433}" + "'", str83.equals("function ({1448401802}, {({485960443},{11478486})}): function ({1404200755}, {({2081673381},{610413360})}): {1122382433}"));
//        org.junit.Assert.assertTrue("'" + boolean85 + "' != '" + false + "'", boolean85 == false);
//    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        com.google.javascript.jscomp.JSModule jSModule5 = new com.google.javascript.jscomp.JSModule("hi!");
        java.util.List<java.lang.String> strList6 = jSModule5.getProvides();
        com.google.javascript.jscomp.JSModule jSModule8 = new com.google.javascript.jscomp.JSModule("hi!");
        java.util.List<java.lang.String> strList9 = jSModule8.getProvides();
        com.google.javascript.jscomp.deps.SimpleDependencyInfo simpleDependencyInfo10 = new com.google.javascript.jscomp.deps.SimpleDependencyInfo("", "GETELEM", strList6, strList9);
        com.google.javascript.rhino.ErrorReporter errorReporter11 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry13 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter11, true);
        com.google.javascript.rhino.jstype.JSType jSType18 = jSTypeRegistry13.createNamedType("GETELEM", "hi!", 0, 38);
        jSTypeRegistry13.incrementGeneration();
        com.google.javascript.rhino.ErrorReporter errorReporter20 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry22 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter20, true);
        com.google.javascript.rhino.ErrorReporter errorReporter23 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry25 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter23, true);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative26 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative27 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative28 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray29 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative26, jSTypeNative27, jSTypeNative28 };
        com.google.javascript.rhino.jstype.JSType jSType30 = jSTypeRegistry25.createUnionType(jSTypeNativeArray29);
        boolean boolean31 = jSType30.isRegexpType();
        boolean boolean32 = jSType30.isNullable();
        com.google.javascript.rhino.ErrorReporter errorReporter33 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry35 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter33, true);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative36 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative37 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative38 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray39 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative36, jSTypeNative37, jSTypeNative38 };
        com.google.javascript.rhino.jstype.JSType jSType40 = jSTypeRegistry35.createUnionType(jSTypeNativeArray39);
        com.google.javascript.rhino.ErrorReporter errorReporter41 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry43 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter41, true);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative44 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative45 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative46 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray47 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative44, jSTypeNative45, jSTypeNative46 };
        com.google.javascript.rhino.jstype.JSType jSType48 = jSTypeRegistry43.createUnionType(jSTypeNativeArray47);
        com.google.javascript.rhino.JSDocInfo jSDocInfo49 = jSType48.getJSDocInfo();
        com.google.javascript.rhino.jstype.ObjectType objectType50 = jSType48.toObjectType();
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray51 = new com.google.javascript.rhino.jstype.JSType[] { jSType40, jSType48 };
        com.google.javascript.rhino.jstype.FunctionType functionType52 = jSTypeRegistry22.createConstructorTypeWithVarArgs(jSType30, jSTypeArray51);
        java.lang.Iterable iterable53 = functionType52.getCtorImplementedInterfaces();
        jSTypeRegistry13.resolveTypesInScope((com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType>) functionType52);
        boolean boolean55 = functionType52.isNativeObjectType();
        boolean boolean56 = functionType52.canBeCalled();
        com.google.common.collect.ImmutableList<java.lang.String> strList57 = functionType52.getTemplateTypeNames();
        com.google.javascript.jscomp.deps.SimpleDependencyInfo simpleDependencyInfo58 = new com.google.javascript.jscomp.deps.SimpleDependencyInfo("", "({proxy:function ({1047075399}, {({605412354},{558514873})}): {1793560964}})", strList9, (java.util.List<java.lang.String>) strList57);
        java.lang.String str59 = simpleDependencyInfo58.getName();
        org.junit.Assert.assertNotNull(strList6);
        org.junit.Assert.assertNotNull(strList9);
        org.junit.Assert.assertNotNull(jSType18);
        org.junit.Assert.assertTrue("'" + jSTypeNative26 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative26.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative27 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative27.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative28 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative28.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray29);
        org.junit.Assert.assertNotNull(jSType30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + jSTypeNative36 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative36.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative37 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative37.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative38 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative38.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray39);
        org.junit.Assert.assertNotNull(jSType40);
        org.junit.Assert.assertTrue("'" + jSTypeNative44 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative44.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative45 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative45.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative46 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative46.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray47);
        org.junit.Assert.assertNotNull(jSType48);
        org.junit.Assert.assertNull(jSDocInfo49);
        org.junit.Assert.assertNull(objectType50);
        org.junit.Assert.assertNotNull(jSTypeArray51);
        org.junit.Assert.assertNotNull(functionType52);
        org.junit.Assert.assertNotNull(iterable53);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + true + "'", boolean56 == true);
        org.junit.Assert.assertNotNull(strList57);
        org.junit.Assert.assertTrue("'" + str59 + "' != '" + "({proxy:function ({1047075399}, {({605412354},{558514873})}): {1793560964}})" + "'", str59.equals("({proxy:function ({1047075399}, {({605412354},{558514873})}): {1793560964}})"));
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, true);
        com.google.javascript.rhino.jstype.JSType jSType7 = jSTypeRegistry2.createNamedType("GETELEM", "hi!", 0, 38);
        jSTypeRegistry2.incrementGeneration();
        com.google.javascript.rhino.ErrorReporter errorReporter9 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry11 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter9, true);
        com.google.javascript.rhino.ErrorReporter errorReporter12 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry14 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter12, true);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative15 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative16 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative17 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray18 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative15, jSTypeNative16, jSTypeNative17 };
        com.google.javascript.rhino.jstype.JSType jSType19 = jSTypeRegistry14.createUnionType(jSTypeNativeArray18);
        boolean boolean20 = jSType19.isRegexpType();
        boolean boolean21 = jSType19.isNullable();
        com.google.javascript.rhino.ErrorReporter errorReporter22 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry24 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter22, true);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative25 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative26 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative27 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray28 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative25, jSTypeNative26, jSTypeNative27 };
        com.google.javascript.rhino.jstype.JSType jSType29 = jSTypeRegistry24.createUnionType(jSTypeNativeArray28);
        com.google.javascript.rhino.ErrorReporter errorReporter30 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry32 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter30, true);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative33 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative34 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative35 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray36 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative33, jSTypeNative34, jSTypeNative35 };
        com.google.javascript.rhino.jstype.JSType jSType37 = jSTypeRegistry32.createUnionType(jSTypeNativeArray36);
        com.google.javascript.rhino.JSDocInfo jSDocInfo38 = jSType37.getJSDocInfo();
        com.google.javascript.rhino.jstype.ObjectType objectType39 = jSType37.toObjectType();
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray40 = new com.google.javascript.rhino.jstype.JSType[] { jSType29, jSType37 };
        com.google.javascript.rhino.jstype.FunctionType functionType41 = jSTypeRegistry11.createConstructorTypeWithVarArgs(jSType19, jSTypeArray40);
        java.lang.Iterable iterable42 = functionType41.getCtorImplementedInterfaces();
        jSTypeRegistry2.resolveTypesInScope((com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType>) functionType41);
        boolean boolean44 = functionType41.isInterface();
        boolean boolean45 = functionType41.isEnumType();
        org.junit.Assert.assertNotNull(jSType7);
        org.junit.Assert.assertTrue("'" + jSTypeNative15 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative15.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative16 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative16.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative17 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative17.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray18);
        org.junit.Assert.assertNotNull(jSType19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + jSTypeNative25 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative25.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative26 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative26.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative27 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative27.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray28);
        org.junit.Assert.assertNotNull(jSType29);
        org.junit.Assert.assertTrue("'" + jSTypeNative33 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative33.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative34 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative34.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative35 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative35.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray36);
        org.junit.Assert.assertNotNull(jSType37);
        org.junit.Assert.assertNull(jSDocInfo38);
        org.junit.Assert.assertNull(objectType39);
        org.junit.Assert.assertNotNull(jSTypeArray40);
        org.junit.Assert.assertNotNull(functionType41);
        org.junit.Assert.assertNotNull(iterable42);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        com.google.javascript.rhino.JSDocInfo jSDocInfo0 = new com.google.javascript.rhino.JSDocInfo();
        boolean boolean1 = jSDocInfo0.hasModifies();
        java.lang.String str2 = jSDocInfo0.getDescription();
        java.lang.String str3 = jSDocInfo0.getBlockDescription();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        com.google.javascript.rhino.JSDocInfo jSDocInfo0 = new com.google.javascript.rhino.JSDocInfo();
        java.lang.String str1 = jSDocInfo0.getBlockDescription();
        com.google.javascript.rhino.JSTypeExpression jSTypeExpression2 = jSDocInfo0.getEnumParameterType();
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertNull(jSTypeExpression2);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        com.google.javascript.jscomp.JSModule jSModule1 = new com.google.javascript.jscomp.JSModule("hi!");
        com.google.javascript.jscomp.Compiler compiler2 = null;
        jSModule1.sortInputsByDeps(compiler2);
        jSModule1.setDepth(12);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        com.google.javascript.jscomp.SourceFile.Builder builder0 = new com.google.javascript.jscomp.SourceFile.Builder();
        com.google.javascript.jscomp.SourceFile sourceFile5 = com.google.javascript.jscomp.SourceFile.fromCode("hi!", "Unknown class name", "Unknown class name");
        java.io.Reader reader6 = sourceFile5.getCodeReader();
        com.google.javascript.jscomp.SourceFile sourceFile7 = builder0.buildFromReader("({proxy:function ({1047075399}, {({605412354},{558514873})}): {1793560964}})", reader6);
        org.junit.Assert.assertNotNull(sourceFile5);
        org.junit.Assert.assertNotNull(reader6);
        org.junit.Assert.assertNotNull(sourceFile7);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        java.util.Collection<com.google.javascript.jscomp.CodingConvention.AssertionFunctionSpec> assertionFunctionSpecCollection1 = closureCodingConvention0.getAssertionFunctions();
        java.util.Collection<java.lang.String> strCollection2 = closureCodingConvention0.getIndirectlyDeclaredProperties();
        com.google.javascript.rhino.Node node4 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode((com.google.javascript.jscomp.CodingConvention) closureCodingConvention0, "({proxy:function ({1047075399}, {({605412354},{558514873})}): {1793560964}})");
        org.junit.Assert.assertNotNull(assertionFunctionSpecCollection1);
        org.junit.Assert.assertNotNull(strCollection2);
        org.junit.Assert.assertNotNull(node4);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newNumber((double) (short) -1, (int) (byte) 1, 0);
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.Node.newNumber((double) (short) -1, (int) (byte) 1, 0);
        boolean boolean8 = node7.isArrayLit();
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newNumber((double) (short) -1, (int) (byte) 1, 0);
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.IR.getelem(node7, node12);
        com.google.javascript.rhino.Node node14 = node3.copyInformationFrom(node13);
        com.google.javascript.rhino.Node node15 = node13.cloneNode();
        boolean boolean16 = node15.isStringKey();
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.IR.breakNode();
        boolean boolean18 = node15.hasChild(node17);
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.IR.voidNode(node15);
        com.google.javascript.rhino.Node node20 = null;
        com.google.javascript.rhino.Node node21 = com.google.javascript.rhino.IR.breakNode();
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.IR.trueNode();
        com.google.javascript.rhino.Node node24 = com.google.javascript.rhino.IR.exprResult(node23);
        boolean boolean25 = node24.isAssign();
        com.google.javascript.rhino.Node node26 = node24.removeFirstChild();
        com.google.javascript.rhino.Node node27 = com.google.javascript.rhino.IR.paramList();
        com.google.javascript.rhino.Node node28 = node26.useSourceInfoIfMissingFromForTree(node27);
        com.google.javascript.rhino.Node node32 = com.google.javascript.rhino.Node.newNumber((double) (short) -1, (int) (byte) 1, 0);
        boolean boolean33 = node32.isArrayLit();
        com.google.javascript.rhino.Node node37 = com.google.javascript.rhino.Node.newNumber((double) (short) -1, (int) (byte) 1, 0);
        com.google.javascript.rhino.Node node38 = com.google.javascript.rhino.IR.getelem(node32, node37);
        boolean boolean39 = node38.isCall();
        com.google.javascript.rhino.Node node42 = new com.google.javascript.rhino.Node((int) '4', node27, node38, 48, (int) (short) 100);
        java.lang.String str43 = node21.checkTreeEquals(node42);
        try {
            node15.replaceChild(node20, node21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertNotNull(node27);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertNotNull(node32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(node37);
        org.junit.Assert.assertNotNull(node38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "Node tree inequality:\nTree1:\nBREAK\n\n\nTree2:\nINSTANCEOF 48\n    PARAM_LIST\n    GETELEM\n        NUMBER -1.0 1\n        NUMBER -1.0 1\n\n\nSubtree1: BREAK\n\n\nSubtree2: INSTANCEOF 48\n    PARAM_LIST\n    GETELEM\n        NUMBER -1.0 1\n        NUMBER -1.0 1\n" + "'", str43.equals("Node tree inequality:\nTree1:\nBREAK\n\n\nTree2:\nINSTANCEOF 48\n    PARAM_LIST\n    GETELEM\n        NUMBER -1.0 1\n        NUMBER -1.0 1\n\n\nSubtree1: BREAK\n\n\nSubtree2: INSTANCEOF 48\n    PARAM_LIST\n    GETELEM\n        NUMBER -1.0 1\n        NUMBER -1.0 1\n"));
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newNumber((double) (short) 100, 0, 12);
        try {
            com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.IR.defaultCase(node3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(node3);
    }

//    @Test
//    public void test073() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test073");
//        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.CHECK_VARIABLES;
//        com.google.javascript.jscomp.DiagnosticGroups.DEPRECATED = diagnosticGroup0;
//        com.google.javascript.jscomp.DiagnosticGroups.DEBUGGER_STATEMENT_PRESENT = diagnosticGroup0;
//        com.google.javascript.jscomp.DiagnosticGroups.EXTERNS_VALIDATION = diagnosticGroup0;
//        org.junit.Assert.assertNull(diagnosticGroup0);
//    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newNumber((double) (short) -1, (int) (byte) 1, 0);
        boolean boolean4 = node3.isArrayLit();
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newNumber((double) (short) -1, (int) (byte) 1, 0);
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.IR.getelem(node3, node8);
        com.google.javascript.rhino.Node node10 = node9.cloneTree();
        boolean boolean11 = node9.isTry();
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newNumber((double) (short) 100, 0, 12);
        boolean boolean4 = node3.isLabel();
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        com.google.javascript.jscomp.SourceFile sourceFile3 = com.google.javascript.jscomp.SourceFile.fromCode("hi!", "Unknown class name", "Unknown class name");
        com.google.javascript.jscomp.Region region5 = sourceFile3.getRegion(2147483647);
        com.google.javascript.jscomp.CompilerInput compilerInput6 = new com.google.javascript.jscomp.CompilerInput(sourceFile3);
        com.google.javascript.rhino.InputId inputId7 = compilerInput6.getInputId();
        java.io.PrintStream printStream8 = null;
        com.google.javascript.jscomp.Compiler compiler9 = new com.google.javascript.jscomp.Compiler(printStream8);
        compilerInput6.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler9);
        com.google.javascript.jscomp.NodeTraversal.Callback callback11 = null;
        com.google.javascript.rhino.Node[] nodeArray12 = new com.google.javascript.rhino.Node[] {};
        com.google.javascript.jscomp.NodeTraversal.traverseRoots((com.google.javascript.jscomp.AbstractCompiler) compiler9, callback11, nodeArray12);
        com.google.javascript.jscomp.SourceMap sourceMap14 = compiler9.getSourceMap();
        try {
            com.google.javascript.jscomp.JSError[] jSErrorArray15 = compiler9.getErrors();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(sourceFile3);
        org.junit.Assert.assertNull(region5);
        org.junit.Assert.assertNotNull(inputId7);
        org.junit.Assert.assertNotNull(nodeArray12);
        org.junit.Assert.assertNull(sourceMap14);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, true);
        com.google.javascript.rhino.ErrorReporter errorReporter3 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter3, true);
        com.google.javascript.rhino.ErrorReporter errorReporter6 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry8 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter6, true);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative9 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative10 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative11 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray12 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative9, jSTypeNative10, jSTypeNative11 };
        com.google.javascript.rhino.jstype.JSType jSType13 = jSTypeRegistry8.createUnionType(jSTypeNativeArray12);
        boolean boolean14 = jSType13.isRegexpType();
        boolean boolean15 = jSType13.isNullable();
        com.google.javascript.rhino.ErrorReporter errorReporter16 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry18 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter16, true);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative19 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative20 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative21 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray22 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative19, jSTypeNative20, jSTypeNative21 };
        com.google.javascript.rhino.jstype.JSType jSType23 = jSTypeRegistry18.createUnionType(jSTypeNativeArray22);
        com.google.javascript.rhino.ErrorReporter errorReporter24 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry26 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter24, true);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative27 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative28 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative29 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray30 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative27, jSTypeNative28, jSTypeNative29 };
        com.google.javascript.rhino.jstype.JSType jSType31 = jSTypeRegistry26.createUnionType(jSTypeNativeArray30);
        com.google.javascript.rhino.JSDocInfo jSDocInfo32 = jSType31.getJSDocInfo();
        com.google.javascript.rhino.jstype.ObjectType objectType33 = jSType31.toObjectType();
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray34 = new com.google.javascript.rhino.jstype.JSType[] { jSType23, jSType31 };
        com.google.javascript.rhino.jstype.FunctionType functionType35 = jSTypeRegistry5.createConstructorTypeWithVarArgs(jSType13, jSTypeArray34);
        com.google.javascript.rhino.ErrorReporter errorReporter36 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry38 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter36, true);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative39 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative40 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative41 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray42 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative39, jSTypeNative40, jSTypeNative41 };
        com.google.javascript.rhino.jstype.JSType jSType43 = jSTypeRegistry38.createUnionType(jSTypeNativeArray42);
        boolean boolean44 = jSType43.isStringObjectType();
        com.google.javascript.rhino.jstype.ParameterizedType parameterizedType45 = jSTypeRegistry2.createParameterizedType((com.google.javascript.rhino.jstype.ObjectType) functionType35, jSType43);
        boolean boolean46 = parameterizedType45.hasAnyTemplateInternal();
        com.google.javascript.rhino.jstype.FunctionType functionType47 = parameterizedType45.getConstructor();
        java.util.Set set48 = parameterizedType45.getOwnPropertyNames();
        com.google.javascript.rhino.JSDocInfo jSDocInfo50 = new com.google.javascript.rhino.JSDocInfo();
        boolean boolean51 = jSDocInfo50.isDeprecated();
        parameterizedType45.setPropertyJSDocInfo("function ({1262020967}, {({954206644},{1279119928})}): {1555607401}", jSDocInfo50);
        com.google.javascript.rhino.jstype.JSType jSType54 = parameterizedType45.getPropertyType("function (new:?, boolean, ...[boolean]): boolean");
        org.junit.Assert.assertTrue("'" + jSTypeNative9 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative9.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative10 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative10.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative11 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative11.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray12);
        org.junit.Assert.assertNotNull(jSType13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + jSTypeNative19 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative19.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative20 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative20.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative21 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative21.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray22);
        org.junit.Assert.assertNotNull(jSType23);
        org.junit.Assert.assertTrue("'" + jSTypeNative27 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative27.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative28 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative28.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative29 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative29.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray30);
        org.junit.Assert.assertNotNull(jSType31);
        org.junit.Assert.assertNull(jSDocInfo32);
        org.junit.Assert.assertNull(objectType33);
        org.junit.Assert.assertNotNull(jSTypeArray34);
        org.junit.Assert.assertNotNull(functionType35);
        org.junit.Assert.assertTrue("'" + jSTypeNative39 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative39.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative40 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative40.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative41 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative41.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray42);
        org.junit.Assert.assertNotNull(jSType43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(parameterizedType45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNull(functionType47);
        org.junit.Assert.assertNotNull(set48);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertNotNull(jSType54);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        com.google.javascript.jscomp.SourceFile sourceFile3 = com.google.javascript.jscomp.SourceFile.fromCode("hi!", "Unknown class name", "Unknown class name");
        com.google.javascript.jscomp.Region region5 = sourceFile3.getRegion(2147483647);
        com.google.javascript.jscomp.CompilerInput compilerInput6 = new com.google.javascript.jscomp.CompilerInput(sourceFile3);
        int int7 = compilerInput6.getNumLines();
        int int8 = compilerInput6.getNumLines();
        org.junit.Assert.assertNotNull(sourceFile3);
        org.junit.Assert.assertNull(region5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newNumber((double) (short) -1, (int) (byte) 1, 0);
        boolean boolean4 = node3.isArrayLit();
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newNumber((double) (short) -1, (int) (byte) 1, 0);
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.IR.getelem(node3, node8);
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newNumber((double) (short) -1, (int) (byte) 1, 0);
        boolean boolean14 = node13.isArrayLit();
        com.google.javascript.rhino.Node node15 = node8.srcrefTree(node13);
        com.google.javascript.rhino.jstype.StaticSourceFile staticSourceFile16 = com.google.javascript.jscomp.NodeUtil.getSourceFile(node13);
        int int18 = node13.getIntProp(35);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertNull(staticSourceFile16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.CHECK_REGEXP;
        com.google.javascript.jscomp.DiagnosticGroups.GLOBAL_THIS = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticGroups.INTERNET_EXPLORER_CHECKS = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticGroups.CHECK_PROVIDES = diagnosticGroup0;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        try {
            com.google.javascript.jscomp.DiagnosticType diagnosticType2 = com.google.javascript.jscomp.DiagnosticType.warning("function ({962984521}, {({423566980},{1800598354})}): {1258877602}", "{proxy:function ({1047075399}, {({605412354},{558514873})}): {1793560964}}");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: can't parse argument number: proxy:function ({1047075399}");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newNumber((double) (short) -1, (int) (byte) 1, 0);
        boolean boolean4 = node3.isArrayLit();
        boolean boolean5 = node3.isLabelName();
        com.google.javascript.rhino.Node node6 = node3.cloneNode();
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.IR.neg(node3);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(node7);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, true);
        com.google.javascript.rhino.ErrorReporter errorReporter3 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter3, true);
        com.google.javascript.rhino.ErrorReporter errorReporter6 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry8 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter6, true);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative9 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative10 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative11 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray12 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative9, jSTypeNative10, jSTypeNative11 };
        com.google.javascript.rhino.jstype.JSType jSType13 = jSTypeRegistry8.createUnionType(jSTypeNativeArray12);
        boolean boolean14 = jSType13.isRegexpType();
        boolean boolean15 = jSType13.isNullable();
        com.google.javascript.rhino.ErrorReporter errorReporter16 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry18 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter16, true);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative19 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative20 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative21 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray22 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative19, jSTypeNative20, jSTypeNative21 };
        com.google.javascript.rhino.jstype.JSType jSType23 = jSTypeRegistry18.createUnionType(jSTypeNativeArray22);
        com.google.javascript.rhino.ErrorReporter errorReporter24 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry26 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter24, true);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative27 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative28 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative29 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray30 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative27, jSTypeNative28, jSTypeNative29 };
        com.google.javascript.rhino.jstype.JSType jSType31 = jSTypeRegistry26.createUnionType(jSTypeNativeArray30);
        com.google.javascript.rhino.JSDocInfo jSDocInfo32 = jSType31.getJSDocInfo();
        com.google.javascript.rhino.jstype.ObjectType objectType33 = jSType31.toObjectType();
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray34 = new com.google.javascript.rhino.jstype.JSType[] { jSType23, jSType31 };
        com.google.javascript.rhino.jstype.FunctionType functionType35 = jSTypeRegistry5.createConstructorTypeWithVarArgs(jSType13, jSTypeArray34);
        com.google.javascript.rhino.ErrorReporter errorReporter36 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry38 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter36, true);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative39 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative40 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative41 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray42 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative39, jSTypeNative40, jSTypeNative41 };
        com.google.javascript.rhino.jstype.JSType jSType43 = jSTypeRegistry38.createUnionType(jSTypeNativeArray42);
        boolean boolean44 = jSType43.isStringObjectType();
        com.google.javascript.rhino.jstype.ParameterizedType parameterizedType45 = jSTypeRegistry2.createParameterizedType((com.google.javascript.rhino.jstype.ObjectType) functionType35, jSType43);
        boolean boolean46 = parameterizedType45.hasAnyTemplateInternal();
        boolean boolean47 = parameterizedType45.hasAnyTemplateInternal();
        com.google.javascript.rhino.jstype.EnumElementType enumElementType48 = parameterizedType45.toMaybeEnumElementType();
        try {
            boolean boolean49 = enumElementType48.isRegexpType();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + jSTypeNative9 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative9.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative10 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative10.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative11 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative11.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray12);
        org.junit.Assert.assertNotNull(jSType13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + jSTypeNative19 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative19.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative20 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative20.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative21 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative21.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray22);
        org.junit.Assert.assertNotNull(jSType23);
        org.junit.Assert.assertTrue("'" + jSTypeNative27 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative27.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative28 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative28.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative29 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative29.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray30);
        org.junit.Assert.assertNotNull(jSType31);
        org.junit.Assert.assertNull(jSDocInfo32);
        org.junit.Assert.assertNull(objectType33);
        org.junit.Assert.assertNotNull(jSTypeArray34);
        org.junit.Assert.assertNotNull(functionType35);
        org.junit.Assert.assertTrue("'" + jSTypeNative39 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative39.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative40 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative40.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative41 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative41.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray42);
        org.junit.Assert.assertNotNull(jSType43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(parameterizedType45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNull(enumElementType48);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        com.google.javascript.rhino.Node.SideEffectFlags sideEffectFlags1 = new com.google.javascript.rhino.Node.SideEffectFlags((int) (short) 100);
        sideEffectFlags1.setAllFlags();
        sideEffectFlags1.clearSideEffectFlags();
        sideEffectFlags1.setReturnsTainted();
        sideEffectFlags1.setMutatesArguments();
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, true);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative3 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative4 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative5 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray6 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative3, jSTypeNative4, jSTypeNative5 };
        com.google.javascript.rhino.jstype.JSType jSType7 = jSTypeRegistry2.createUnionType(jSTypeNativeArray6);
        jSTypeRegistry2.clearTemplateTypeNames();
        com.google.javascript.rhino.ErrorReporter errorReporter9 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry11 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter9, true);
        com.google.javascript.rhino.ErrorReporter errorReporter12 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry14 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter12, true);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative15 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative16 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative17 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray18 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative15, jSTypeNative16, jSTypeNative17 };
        com.google.javascript.rhino.jstype.JSType jSType19 = jSTypeRegistry14.createUnionType(jSTypeNativeArray18);
        boolean boolean20 = jSType19.isRegexpType();
        boolean boolean21 = jSType19.isNullable();
        com.google.javascript.rhino.ErrorReporter errorReporter22 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry24 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter22, true);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative25 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative26 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative27 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray28 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative25, jSTypeNative26, jSTypeNative27 };
        com.google.javascript.rhino.jstype.JSType jSType29 = jSTypeRegistry24.createUnionType(jSTypeNativeArray28);
        com.google.javascript.rhino.ErrorReporter errorReporter30 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry32 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter30, true);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative33 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative34 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative35 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray36 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative33, jSTypeNative34, jSTypeNative35 };
        com.google.javascript.rhino.jstype.JSType jSType37 = jSTypeRegistry32.createUnionType(jSTypeNativeArray36);
        com.google.javascript.rhino.JSDocInfo jSDocInfo38 = jSType37.getJSDocInfo();
        com.google.javascript.rhino.jstype.ObjectType objectType39 = jSType37.toObjectType();
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray40 = new com.google.javascript.rhino.jstype.JSType[] { jSType29, jSType37 };
        com.google.javascript.rhino.jstype.FunctionType functionType41 = jSTypeRegistry11.createConstructorTypeWithVarArgs(jSType19, jSTypeArray40);
        java.lang.Iterable iterable42 = functionType41.getCtorImplementedInterfaces();
        com.google.javascript.rhino.Node node43 = functionType41.getSource();
        com.google.javascript.rhino.ErrorReporter errorReporter45 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry47 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter45, true);
        com.google.javascript.rhino.ErrorReporter errorReporter48 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry50 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter48, true);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative51 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative52 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative53 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray54 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative51, jSTypeNative52, jSTypeNative53 };
        com.google.javascript.rhino.jstype.JSType jSType55 = jSTypeRegistry50.createUnionType(jSTypeNativeArray54);
        boolean boolean56 = jSType55.isRegexpType();
        boolean boolean57 = jSType55.isNullable();
        com.google.javascript.rhino.ErrorReporter errorReporter58 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry60 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter58, true);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative61 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative62 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative63 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray64 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative61, jSTypeNative62, jSTypeNative63 };
        com.google.javascript.rhino.jstype.JSType jSType65 = jSTypeRegistry60.createUnionType(jSTypeNativeArray64);
        com.google.javascript.rhino.ErrorReporter errorReporter66 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry68 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter66, true);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative69 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative70 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative71 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray72 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative69, jSTypeNative70, jSTypeNative71 };
        com.google.javascript.rhino.jstype.JSType jSType73 = jSTypeRegistry68.createUnionType(jSTypeNativeArray72);
        com.google.javascript.rhino.JSDocInfo jSDocInfo74 = jSType73.getJSDocInfo();
        com.google.javascript.rhino.jstype.ObjectType objectType75 = jSType73.toObjectType();
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray76 = new com.google.javascript.rhino.jstype.JSType[] { jSType65, jSType73 };
        com.google.javascript.rhino.jstype.FunctionType functionType77 = jSTypeRegistry47.createConstructorTypeWithVarArgs(jSType55, jSTypeArray76);
        com.google.javascript.rhino.jstype.FunctionType functionType78 = jSTypeRegistry2.createFunctionType((com.google.javascript.rhino.jstype.JSType) functionType41, true, jSTypeArray76);
        boolean boolean80 = jSTypeRegistry2.hasNamespace("{proxy:function ({1047075399}, {({605412354},{558514873})}): {1793560964}}");
        com.google.javascript.rhino.jstype.FunctionBuilder functionBuilder81 = new com.google.javascript.rhino.jstype.FunctionBuilder(jSTypeRegistry2);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative82 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_NUMBER_STRING_BOOLEAN;
        com.google.javascript.rhino.jstype.JSType jSType83 = jSTypeRegistry2.getNativeType(jSTypeNative82);
        org.junit.Assert.assertTrue("'" + jSTypeNative3 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative3.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative4 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative4.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative5 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative5.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray6);
        org.junit.Assert.assertNotNull(jSType7);
        org.junit.Assert.assertTrue("'" + jSTypeNative15 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative15.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative16 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative16.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative17 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative17.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray18);
        org.junit.Assert.assertNotNull(jSType19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + jSTypeNative25 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative25.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative26 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative26.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative27 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative27.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray28);
        org.junit.Assert.assertNotNull(jSType29);
        org.junit.Assert.assertTrue("'" + jSTypeNative33 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative33.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative34 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative34.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative35 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative35.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray36);
        org.junit.Assert.assertNotNull(jSType37);
        org.junit.Assert.assertNull(jSDocInfo38);
        org.junit.Assert.assertNull(objectType39);
        org.junit.Assert.assertNotNull(jSTypeArray40);
        org.junit.Assert.assertNotNull(functionType41);
        org.junit.Assert.assertNotNull(iterable42);
        org.junit.Assert.assertNull(node43);
        org.junit.Assert.assertTrue("'" + jSTypeNative51 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative51.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative52 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative52.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative53 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative53.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray54);
        org.junit.Assert.assertNotNull(jSType55);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertTrue("'" + jSTypeNative61 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative61.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative62 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative62.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative63 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative63.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray64);
        org.junit.Assert.assertNotNull(jSType65);
        org.junit.Assert.assertTrue("'" + jSTypeNative69 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative69.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative70 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative70.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative71 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative71.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray72);
        org.junit.Assert.assertNotNull(jSType73);
        org.junit.Assert.assertNull(jSDocInfo74);
        org.junit.Assert.assertNull(objectType75);
        org.junit.Assert.assertNotNull(jSTypeArray76);
        org.junit.Assert.assertNotNull(functionType77);
        org.junit.Assert.assertNotNull(functionType78);
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + false + "'", boolean80 == false);
        org.junit.Assert.assertTrue("'" + jSTypeNative82 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_NUMBER_STRING_BOOLEAN + "'", jSTypeNative82.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_NUMBER_STRING_BOOLEAN));
        org.junit.Assert.assertNotNull(jSType83);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, true);
        com.google.javascript.rhino.ErrorReporter errorReporter3 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter3, true);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative6 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative7 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative8 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray9 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative6, jSTypeNative7, jSTypeNative8 };
        com.google.javascript.rhino.jstype.JSType jSType10 = jSTypeRegistry5.createUnionType(jSTypeNativeArray9);
        boolean boolean11 = jSType10.isRegexpType();
        boolean boolean12 = jSType10.isNullable();
        com.google.javascript.rhino.ErrorReporter errorReporter13 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry15 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter13, true);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative16 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative17 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative18 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray19 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative16, jSTypeNative17, jSTypeNative18 };
        com.google.javascript.rhino.jstype.JSType jSType20 = jSTypeRegistry15.createUnionType(jSTypeNativeArray19);
        com.google.javascript.rhino.ErrorReporter errorReporter21 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry23 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter21, true);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative24 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative25 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative26 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray27 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative24, jSTypeNative25, jSTypeNative26 };
        com.google.javascript.rhino.jstype.JSType jSType28 = jSTypeRegistry23.createUnionType(jSTypeNativeArray27);
        com.google.javascript.rhino.JSDocInfo jSDocInfo29 = jSType28.getJSDocInfo();
        com.google.javascript.rhino.jstype.ObjectType objectType30 = jSType28.toObjectType();
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray31 = new com.google.javascript.rhino.jstype.JSType[] { jSType20, jSType28 };
        com.google.javascript.rhino.jstype.FunctionType functionType32 = jSTypeRegistry2.createConstructorTypeWithVarArgs(jSType10, jSTypeArray31);
        java.lang.Iterable iterable33 = functionType32.getCtorImplementedInterfaces();
        boolean boolean35 = functionType32.removeProperty("function ({962984521}, {({423566980},{1800598354})}): {1258877602}");
        boolean boolean37 = functionType32.isPropertyInExterns("Unversioned directory");
        com.google.javascript.rhino.jstype.JSType jSType38 = null;
        try {
            boolean boolean39 = functionType32.isSubtype(jSType38);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + jSTypeNative6 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative6.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative7 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative7.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative8 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative8.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray9);
        org.junit.Assert.assertNotNull(jSType10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + jSTypeNative16 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative16.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative17 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative17.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative18 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative18.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray19);
        org.junit.Assert.assertNotNull(jSType20);
        org.junit.Assert.assertTrue("'" + jSTypeNative24 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative24.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative25 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative25.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative26 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative26.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray27);
        org.junit.Assert.assertNotNull(jSType28);
        org.junit.Assert.assertNull(jSDocInfo29);
        org.junit.Assert.assertNull(objectType30);
        org.junit.Assert.assertNotNull(jSTypeArray31);
        org.junit.Assert.assertNotNull(functionType32);
        org.junit.Assert.assertNotNull(iterable33);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newNumber((double) (short) -1, (int) (byte) 1, 0);
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.Node.newNumber((double) (short) -1, (int) (byte) 1, 0);
        boolean boolean8 = node7.isArrayLit();
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newNumber((double) (short) -1, (int) (byte) 1, 0);
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.IR.getelem(node7, node12);
        com.google.javascript.rhino.Node node14 = node3.copyInformationFrom(node13);
        com.google.javascript.rhino.Node node15 = node13.cloneNode();
        boolean boolean16 = node15.isStringKey();
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.Node.newNumber((double) (short) -1, (int) (byte) 1, 0);
        boolean boolean21 = node20.isArrayLit();
        com.google.javascript.rhino.Node node22 = node20.cloneTree();
        boolean boolean23 = node22.isVar();
        com.google.javascript.rhino.Node node28 = com.google.javascript.rhino.Node.newNumber((double) (short) -1, (int) (byte) 1, 0);
        boolean boolean29 = node28.isArrayLit();
        boolean boolean30 = node28.isLabelName();
        com.google.javascript.rhino.Node node34 = com.google.javascript.rhino.Node.newNumber((double) (short) -1, (int) (byte) 1, 0);
        boolean boolean35 = node34.isArrayLit();
        com.google.javascript.rhino.Node node39 = com.google.javascript.rhino.Node.newNumber((double) (short) -1, (int) (byte) 1, 0);
        com.google.javascript.rhino.Node node40 = new com.google.javascript.rhino.Node((int) '#', node28, node34, node39);
        java.lang.String str41 = node39.toString();
        com.google.javascript.rhino.Node node42 = node22.useSourceInfoFrom(node39);
        boolean boolean43 = node39.isCatch();
        com.google.javascript.rhino.Node node44 = node15.copyInformationFrom(node39);
        boolean boolean45 = node39.isBreak();
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(node34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(node39);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "NUMBER -1.0 1" + "'", str41.equals("NUMBER -1.0 1"));
        org.junit.Assert.assertNotNull(node42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(node44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString(12, "{proxy:function ({1047075399}, {({605412354},{558514873})}): {1793560964}}", (int) 'a', (int) (byte) 0);
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newNumber((double) (short) -1, (int) (byte) 1, 0);
        boolean boolean9 = node8.isArrayLit();
        com.google.javascript.rhino.Node node10 = node8.cloneTree();
        com.google.javascript.rhino.Node node11 = node4.useSourceInfoFrom(node8);
        node8.setSourceEncodedPosition((int) (byte) 100);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(node11);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        com.google.javascript.jscomp.SourceFile.Generator generator1 = null;
        com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromGenerator("function ({962984521}, {({423566980},{1800598354})}): {1258877602}", generator1);
        org.junit.Assert.assertNotNull(sourceFile2);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, true);
        com.google.javascript.rhino.ErrorReporter errorReporter3 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter3, true);
        com.google.javascript.rhino.ErrorReporter errorReporter6 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry8 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter6, true);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative9 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative10 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative11 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray12 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative9, jSTypeNative10, jSTypeNative11 };
        com.google.javascript.rhino.jstype.JSType jSType13 = jSTypeRegistry8.createUnionType(jSTypeNativeArray12);
        boolean boolean14 = jSType13.isRegexpType();
        boolean boolean15 = jSType13.isNullable();
        com.google.javascript.rhino.ErrorReporter errorReporter16 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry18 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter16, true);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative19 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative20 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative21 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray22 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative19, jSTypeNative20, jSTypeNative21 };
        com.google.javascript.rhino.jstype.JSType jSType23 = jSTypeRegistry18.createUnionType(jSTypeNativeArray22);
        com.google.javascript.rhino.ErrorReporter errorReporter24 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry26 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter24, true);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative27 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative28 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative29 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray30 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative27, jSTypeNative28, jSTypeNative29 };
        com.google.javascript.rhino.jstype.JSType jSType31 = jSTypeRegistry26.createUnionType(jSTypeNativeArray30);
        com.google.javascript.rhino.JSDocInfo jSDocInfo32 = jSType31.getJSDocInfo();
        com.google.javascript.rhino.jstype.ObjectType objectType33 = jSType31.toObjectType();
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray34 = new com.google.javascript.rhino.jstype.JSType[] { jSType23, jSType31 };
        com.google.javascript.rhino.jstype.FunctionType functionType35 = jSTypeRegistry5.createConstructorTypeWithVarArgs(jSType13, jSTypeArray34);
        com.google.javascript.rhino.ErrorReporter errorReporter36 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry38 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter36, true);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative39 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative40 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative41 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray42 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative39, jSTypeNative40, jSTypeNative41 };
        com.google.javascript.rhino.jstype.JSType jSType43 = jSTypeRegistry38.createUnionType(jSTypeNativeArray42);
        boolean boolean44 = jSType43.isStringObjectType();
        com.google.javascript.rhino.jstype.ParameterizedType parameterizedType45 = jSTypeRegistry2.createParameterizedType((com.google.javascript.rhino.jstype.ObjectType) functionType35, jSType43);
        boolean boolean46 = parameterizedType45.hasAnyTemplateInternal();
        com.google.javascript.rhino.jstype.FunctionType functionType47 = parameterizedType45.getConstructor();
        boolean boolean48 = parameterizedType45.isBooleanValueType();
        boolean boolean49 = parameterizedType45.isNoType();
        boolean boolean50 = parameterizedType45.isTemplateType();
        com.google.javascript.rhino.jstype.ObjectType objectType51 = parameterizedType45.getImplicitPrototype();
        com.google.javascript.rhino.jstype.JSType jSType52 = parameterizedType45.collapseUnion();
        org.junit.Assert.assertTrue("'" + jSTypeNative9 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative9.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative10 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative10.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative11 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative11.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray12);
        org.junit.Assert.assertNotNull(jSType13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + jSTypeNative19 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative19.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative20 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative20.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative21 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative21.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray22);
        org.junit.Assert.assertNotNull(jSType23);
        org.junit.Assert.assertTrue("'" + jSTypeNative27 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative27.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative28 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative28.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative29 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative29.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray30);
        org.junit.Assert.assertNotNull(jSType31);
        org.junit.Assert.assertNull(jSDocInfo32);
        org.junit.Assert.assertNull(objectType33);
        org.junit.Assert.assertNotNull(jSTypeArray34);
        org.junit.Assert.assertNotNull(functionType35);
        org.junit.Assert.assertTrue("'" + jSTypeNative39 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative39.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative40 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative40.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative41 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative41.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray42);
        org.junit.Assert.assertNotNull(jSType43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(parameterizedType45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNull(functionType47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(objectType51);
        org.junit.Assert.assertNotNull(jSType52);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        com.google.javascript.jscomp.JSModule jSModule1 = new com.google.javascript.jscomp.JSModule("hi!");
        java.util.List<java.lang.String> strList2 = jSModule1.getProvides();
        com.google.javascript.jscomp.JSModule jSModule4 = new com.google.javascript.jscomp.JSModule("hi!");
        java.lang.String str5 = jSModule4.toString();
        com.google.javascript.jscomp.SourceFile sourceFile9 = com.google.javascript.jscomp.SourceFile.fromCode("hi!", "Unknown class name", "Unknown class name");
        java.io.Reader reader10 = sourceFile9.getCodeReader();
        jSModule4.addFirst(sourceFile9);
        jSModule1.addFirst(sourceFile9);
        jSModule1.removeAll();
        java.util.List<java.lang.String> strList14 = jSModule1.getProvides();
        org.junit.Assert.assertNotNull(strList2);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        org.junit.Assert.assertNotNull(sourceFile9);
        org.junit.Assert.assertNotNull(reader10);
        org.junit.Assert.assertNotNull(strList14);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        com.google.javascript.rhino.JSDocInfo jSDocInfo0 = new com.google.javascript.rhino.JSDocInfo();
        boolean boolean1 = jSDocInfo0.isDeprecated();
        java.lang.String str2 = jSDocInfo0.getLendsName();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, true);
        com.google.javascript.rhino.ErrorReporter errorReporter3 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter3, true);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative6 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative7 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative8 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray9 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative6, jSTypeNative7, jSTypeNative8 };
        com.google.javascript.rhino.jstype.JSType jSType10 = jSTypeRegistry5.createUnionType(jSTypeNativeArray9);
        boolean boolean11 = jSType10.isRegexpType();
        boolean boolean12 = jSType10.isNullable();
        com.google.javascript.rhino.ErrorReporter errorReporter13 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry15 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter13, true);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative16 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative17 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative18 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray19 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative16, jSTypeNative17, jSTypeNative18 };
        com.google.javascript.rhino.jstype.JSType jSType20 = jSTypeRegistry15.createUnionType(jSTypeNativeArray19);
        com.google.javascript.rhino.ErrorReporter errorReporter21 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry23 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter21, true);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative24 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative25 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative26 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray27 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative24, jSTypeNative25, jSTypeNative26 };
        com.google.javascript.rhino.jstype.JSType jSType28 = jSTypeRegistry23.createUnionType(jSTypeNativeArray27);
        com.google.javascript.rhino.JSDocInfo jSDocInfo29 = jSType28.getJSDocInfo();
        com.google.javascript.rhino.jstype.ObjectType objectType30 = jSType28.toObjectType();
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray31 = new com.google.javascript.rhino.jstype.JSType[] { jSType20, jSType28 };
        com.google.javascript.rhino.jstype.FunctionType functionType32 = jSTypeRegistry2.createConstructorTypeWithVarArgs(jSType10, jSTypeArray31);
        java.lang.Iterable iterable33 = functionType32.getCtorImplementedInterfaces();
        com.google.javascript.rhino.Node node34 = functionType32.getSource();
        com.google.javascript.rhino.jstype.ObjectType objectType36 = com.google.javascript.rhino.jstype.FunctionType.getTopDefiningInterface((com.google.javascript.rhino.jstype.ObjectType) functionType32, "function ({1262020967}, {({954206644},{1279119928})}): {1555607401}");
        boolean boolean37 = functionType32.matchesNumberContext();
        boolean boolean38 = functionType32.isNativeObjectType();
        com.google.javascript.rhino.jstype.JSType jSType40 = functionType32.findPropertyType("function ({704695011}, {({259914045},{1783918382})}): {426199371}");
        org.junit.Assert.assertTrue("'" + jSTypeNative6 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative6.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative7 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative7.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative8 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative8.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray9);
        org.junit.Assert.assertNotNull(jSType10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + jSTypeNative16 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative16.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative17 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative17.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative18 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative18.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray19);
        org.junit.Assert.assertNotNull(jSType20);
        org.junit.Assert.assertTrue("'" + jSTypeNative24 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative24.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative25 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative25.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative26 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative26.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray27);
        org.junit.Assert.assertNotNull(jSType28);
        org.junit.Assert.assertNull(jSDocInfo29);
        org.junit.Assert.assertNull(objectType30);
        org.junit.Assert.assertNotNull(jSTypeArray31);
        org.junit.Assert.assertNotNull(functionType32);
        org.junit.Assert.assertNotNull(iterable33);
        org.junit.Assert.assertNull(node34);
        org.junit.Assert.assertNull(objectType36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNull(jSType40);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, true);
        com.google.javascript.rhino.ErrorReporter errorReporter3 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter3, true);
        com.google.javascript.rhino.ErrorReporter errorReporter6 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry8 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter6, true);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative9 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative10 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative11 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray12 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative9, jSTypeNative10, jSTypeNative11 };
        com.google.javascript.rhino.jstype.JSType jSType13 = jSTypeRegistry8.createUnionType(jSTypeNativeArray12);
        boolean boolean14 = jSType13.isRegexpType();
        boolean boolean15 = jSType13.isNullable();
        com.google.javascript.rhino.ErrorReporter errorReporter16 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry18 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter16, true);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative19 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative20 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative21 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray22 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative19, jSTypeNative20, jSTypeNative21 };
        com.google.javascript.rhino.jstype.JSType jSType23 = jSTypeRegistry18.createUnionType(jSTypeNativeArray22);
        com.google.javascript.rhino.ErrorReporter errorReporter24 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry26 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter24, true);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative27 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative28 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative29 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray30 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative27, jSTypeNative28, jSTypeNative29 };
        com.google.javascript.rhino.jstype.JSType jSType31 = jSTypeRegistry26.createUnionType(jSTypeNativeArray30);
        com.google.javascript.rhino.JSDocInfo jSDocInfo32 = jSType31.getJSDocInfo();
        com.google.javascript.rhino.jstype.ObjectType objectType33 = jSType31.toObjectType();
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray34 = new com.google.javascript.rhino.jstype.JSType[] { jSType23, jSType31 };
        com.google.javascript.rhino.jstype.FunctionType functionType35 = jSTypeRegistry5.createConstructorTypeWithVarArgs(jSType13, jSTypeArray34);
        com.google.javascript.rhino.ErrorReporter errorReporter36 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry38 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter36, true);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative39 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative40 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative41 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray42 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative39, jSTypeNative40, jSTypeNative41 };
        com.google.javascript.rhino.jstype.JSType jSType43 = jSTypeRegistry38.createUnionType(jSTypeNativeArray42);
        boolean boolean44 = jSType43.isStringObjectType();
        com.google.javascript.rhino.jstype.ParameterizedType parameterizedType45 = jSTypeRegistry2.createParameterizedType((com.google.javascript.rhino.jstype.ObjectType) functionType35, jSType43);
        boolean boolean46 = parameterizedType45.hasAnyTemplateInternal();
        com.google.javascript.rhino.jstype.FunctionType functionType47 = parameterizedType45.getConstructor();
        boolean boolean48 = parameterizedType45.isBooleanValueType();
        boolean boolean49 = parameterizedType45.isNoType();
        boolean boolean50 = parameterizedType45.isTemplateType();
        parameterizedType45.clearCachedValues();
        boolean boolean52 = parameterizedType45.matchesStringContext();
        boolean boolean53 = parameterizedType45.isOrdinaryFunction();
        org.junit.Assert.assertTrue("'" + jSTypeNative9 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative9.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative10 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative10.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative11 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative11.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray12);
        org.junit.Assert.assertNotNull(jSType13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + jSTypeNative19 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative19.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative20 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative20.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative21 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative21.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray22);
        org.junit.Assert.assertNotNull(jSType23);
        org.junit.Assert.assertTrue("'" + jSTypeNative27 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative27.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative28 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative28.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative29 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative29.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray30);
        org.junit.Assert.assertNotNull(jSType31);
        org.junit.Assert.assertNull(jSDocInfo32);
        org.junit.Assert.assertNull(objectType33);
        org.junit.Assert.assertNotNull(jSTypeArray34);
        org.junit.Assert.assertNotNull(functionType35);
        org.junit.Assert.assertTrue("'" + jSTypeNative39 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative39.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative40 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative40.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative41 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative41.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray42);
        org.junit.Assert.assertNotNull(jSType43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(parameterizedType45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNull(functionType47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        try {
            int int2 = compiler1.getWarningCount();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newNumber((double) (short) -1, (int) (byte) 1, 0);
        boolean boolean4 = node3.isArrayLit();
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newNumber((double) (short) -1, (int) (byte) 1, 0);
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.IR.getelem(node3, node8);
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newNumber((double) (short) -1, (int) (byte) 1, 0);
        boolean boolean14 = node13.isArrayLit();
        com.google.javascript.rhino.Node node15 = node8.srcrefTree(node13);
        com.google.javascript.rhino.jstype.StaticSourceFile staticSourceFile16 = com.google.javascript.jscomp.NodeUtil.getSourceFile(node13);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder17 = node13.getJsDocBuilderForNode();
        com.google.javascript.rhino.Node node18 = node13.cloneTree();
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertNull(staticSourceFile16);
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder17);
        org.junit.Assert.assertNotNull(node18);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        com.google.javascript.jscomp.AnonymousFunctionNamingPolicy anonymousFunctionNamingPolicy0 = com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.MAPPED;
        org.junit.Assert.assertTrue("'" + anonymousFunctionNamingPolicy0 + "' != '" + com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.MAPPED + "'", anonymousFunctionNamingPolicy0.equals(com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.MAPPED));
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, true);
        com.google.javascript.rhino.ErrorReporter errorReporter3 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter3, true);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative6 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative7 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative8 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray9 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative6, jSTypeNative7, jSTypeNative8 };
        com.google.javascript.rhino.jstype.JSType jSType10 = jSTypeRegistry5.createUnionType(jSTypeNativeArray9);
        boolean boolean11 = jSType10.isRegexpType();
        boolean boolean12 = jSType10.isNullable();
        com.google.javascript.rhino.ErrorReporter errorReporter13 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry15 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter13, true);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative16 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative17 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative18 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray19 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative16, jSTypeNative17, jSTypeNative18 };
        com.google.javascript.rhino.jstype.JSType jSType20 = jSTypeRegistry15.createUnionType(jSTypeNativeArray19);
        com.google.javascript.rhino.ErrorReporter errorReporter21 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry23 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter21, true);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative24 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative25 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative26 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray27 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative24, jSTypeNative25, jSTypeNative26 };
        com.google.javascript.rhino.jstype.JSType jSType28 = jSTypeRegistry23.createUnionType(jSTypeNativeArray27);
        com.google.javascript.rhino.JSDocInfo jSDocInfo29 = jSType28.getJSDocInfo();
        com.google.javascript.rhino.jstype.ObjectType objectType30 = jSType28.toObjectType();
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray31 = new com.google.javascript.rhino.jstype.JSType[] { jSType20, jSType28 };
        com.google.javascript.rhino.jstype.FunctionType functionType32 = jSTypeRegistry2.createConstructorTypeWithVarArgs(jSType10, jSTypeArray31);
        boolean boolean34 = functionType32.hasProperty("hi!");
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable35 = functionType32.getParameters();
        com.google.javascript.rhino.jstype.JSType jSType36 = functionType32.unboxesTo();
        com.google.javascript.rhino.jstype.BooleanLiteralSet booleanLiteralSet37 = functionType32.getPossibleToBooleanOutcomes();
        com.google.javascript.rhino.jstype.EnumType enumType38 = functionType32.toMaybeEnumType();
        com.google.javascript.rhino.jstype.ObjectType objectType39 = functionType32.getTypeOfThis();
        org.junit.Assert.assertTrue("'" + jSTypeNative6 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative6.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative7 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative7.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative8 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative8.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray9);
        org.junit.Assert.assertNotNull(jSType10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + jSTypeNative16 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative16.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative17 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative17.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative18 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative18.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray19);
        org.junit.Assert.assertNotNull(jSType20);
        org.junit.Assert.assertTrue("'" + jSTypeNative24 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative24.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative25 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative25.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative26 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative26.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray27);
        org.junit.Assert.assertNotNull(jSType28);
        org.junit.Assert.assertNull(jSDocInfo29);
        org.junit.Assert.assertNull(objectType30);
        org.junit.Assert.assertNotNull(jSTypeArray31);
        org.junit.Assert.assertNotNull(functionType32);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(nodeIterable35);
        org.junit.Assert.assertNull(jSType36);
        org.junit.Assert.assertTrue("'" + booleanLiteralSet37 + "' != '" + com.google.javascript.rhino.jstype.BooleanLiteralSet.TRUE + "'", booleanLiteralSet37.equals(com.google.javascript.rhino.jstype.BooleanLiteralSet.TRUE));
        org.junit.Assert.assertNull(enumType38);
        org.junit.Assert.assertNotNull(objectType39);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, true);
        com.google.javascript.rhino.ErrorReporter errorReporter3 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter3, true);
        com.google.javascript.rhino.ErrorReporter errorReporter6 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry8 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter6, true);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative9 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative10 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative11 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray12 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative9, jSTypeNative10, jSTypeNative11 };
        com.google.javascript.rhino.jstype.JSType jSType13 = jSTypeRegistry8.createUnionType(jSTypeNativeArray12);
        boolean boolean14 = jSType13.isRegexpType();
        boolean boolean15 = jSType13.isNullable();
        com.google.javascript.rhino.ErrorReporter errorReporter16 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry18 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter16, true);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative19 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative20 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative21 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray22 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative19, jSTypeNative20, jSTypeNative21 };
        com.google.javascript.rhino.jstype.JSType jSType23 = jSTypeRegistry18.createUnionType(jSTypeNativeArray22);
        com.google.javascript.rhino.ErrorReporter errorReporter24 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry26 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter24, true);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative27 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative28 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative29 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray30 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative27, jSTypeNative28, jSTypeNative29 };
        com.google.javascript.rhino.jstype.JSType jSType31 = jSTypeRegistry26.createUnionType(jSTypeNativeArray30);
        com.google.javascript.rhino.JSDocInfo jSDocInfo32 = jSType31.getJSDocInfo();
        com.google.javascript.rhino.jstype.ObjectType objectType33 = jSType31.toObjectType();
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray34 = new com.google.javascript.rhino.jstype.JSType[] { jSType23, jSType31 };
        com.google.javascript.rhino.jstype.FunctionType functionType35 = jSTypeRegistry5.createConstructorTypeWithVarArgs(jSType13, jSTypeArray34);
        com.google.javascript.rhino.ErrorReporter errorReporter36 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry38 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter36, true);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative39 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative40 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative41 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray42 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative39, jSTypeNative40, jSTypeNative41 };
        com.google.javascript.rhino.jstype.JSType jSType43 = jSTypeRegistry38.createUnionType(jSTypeNativeArray42);
        boolean boolean44 = jSType43.isStringObjectType();
        com.google.javascript.rhino.jstype.ParameterizedType parameterizedType45 = jSTypeRegistry2.createParameterizedType((com.google.javascript.rhino.jstype.ObjectType) functionType35, jSType43);
        boolean boolean46 = parameterizedType45.hasAnyTemplateInternal();
        boolean boolean48 = parameterizedType45.isPropertyTypeDeclared("");
        boolean boolean49 = parameterizedType45.isInterface();
        org.junit.Assert.assertTrue("'" + jSTypeNative9 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative9.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative10 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative10.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative11 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative11.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray12);
        org.junit.Assert.assertNotNull(jSType13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + jSTypeNative19 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative19.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative20 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative20.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative21 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative21.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray22);
        org.junit.Assert.assertNotNull(jSType23);
        org.junit.Assert.assertTrue("'" + jSTypeNative27 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative27.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative28 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative28.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative29 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative29.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray30);
        org.junit.Assert.assertNotNull(jSType31);
        org.junit.Assert.assertNull(jSDocInfo32);
        org.junit.Assert.assertNull(objectType33);
        org.junit.Assert.assertNotNull(jSTypeArray34);
        org.junit.Assert.assertNotNull(functionType35);
        org.junit.Assert.assertTrue("'" + jSTypeNative39 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative39.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative40 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative40.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative41 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative41.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray42);
        org.junit.Assert.assertNotNull(jSType43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(parameterizedType45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, true);
        com.google.javascript.rhino.ErrorReporter errorReporter3 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter3, true);
        com.google.javascript.rhino.ErrorReporter errorReporter6 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry8 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter6, true);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative9 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative10 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative11 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray12 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative9, jSTypeNative10, jSTypeNative11 };
        com.google.javascript.rhino.jstype.JSType jSType13 = jSTypeRegistry8.createUnionType(jSTypeNativeArray12);
        boolean boolean14 = jSType13.isRegexpType();
        boolean boolean15 = jSType13.isNullable();
        com.google.javascript.rhino.ErrorReporter errorReporter16 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry18 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter16, true);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative19 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative20 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative21 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray22 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative19, jSTypeNative20, jSTypeNative21 };
        com.google.javascript.rhino.jstype.JSType jSType23 = jSTypeRegistry18.createUnionType(jSTypeNativeArray22);
        com.google.javascript.rhino.ErrorReporter errorReporter24 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry26 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter24, true);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative27 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative28 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative29 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray30 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative27, jSTypeNative28, jSTypeNative29 };
        com.google.javascript.rhino.jstype.JSType jSType31 = jSTypeRegistry26.createUnionType(jSTypeNativeArray30);
        com.google.javascript.rhino.JSDocInfo jSDocInfo32 = jSType31.getJSDocInfo();
        com.google.javascript.rhino.jstype.ObjectType objectType33 = jSType31.toObjectType();
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray34 = new com.google.javascript.rhino.jstype.JSType[] { jSType23, jSType31 };
        com.google.javascript.rhino.jstype.FunctionType functionType35 = jSTypeRegistry5.createConstructorTypeWithVarArgs(jSType13, jSTypeArray34);
        com.google.javascript.rhino.ErrorReporter errorReporter36 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry38 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter36, true);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative39 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative40 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative41 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray42 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative39, jSTypeNative40, jSTypeNative41 };
        com.google.javascript.rhino.jstype.JSType jSType43 = jSTypeRegistry38.createUnionType(jSTypeNativeArray42);
        boolean boolean44 = jSType43.isStringObjectType();
        com.google.javascript.rhino.jstype.ParameterizedType parameterizedType45 = jSTypeRegistry2.createParameterizedType((com.google.javascript.rhino.jstype.ObjectType) functionType35, jSType43);
        int int46 = functionType35.getMinArguments();
        boolean boolean47 = functionType35.isVoidType();
        com.google.javascript.rhino.jstype.JSType jSType48 = functionType35.getParameterType();
        functionType35.clearCachedValues();
        boolean boolean51 = functionType35.isPropertyTypeDeclared("function ({1448401802}, {({485960443},{11478486})}): function ({1404200755}, {({2081673381},{610413360})}): {1122382433}");
        org.junit.Assert.assertTrue("'" + jSTypeNative9 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative9.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative10 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative10.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative11 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative11.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray12);
        org.junit.Assert.assertNotNull(jSType13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + jSTypeNative19 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative19.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative20 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative20.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative21 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative21.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray22);
        org.junit.Assert.assertNotNull(jSType23);
        org.junit.Assert.assertTrue("'" + jSTypeNative27 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative27.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative28 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative28.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative29 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative29.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray30);
        org.junit.Assert.assertNotNull(jSType31);
        org.junit.Assert.assertNull(jSDocInfo32);
        org.junit.Assert.assertNull(objectType33);
        org.junit.Assert.assertNotNull(jSTypeArray34);
        org.junit.Assert.assertNotNull(functionType35);
        org.junit.Assert.assertTrue("'" + jSTypeNative39 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative39.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative40 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative40.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative41 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative41.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray42);
        org.junit.Assert.assertNotNull(jSType43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(parameterizedType45);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 1 + "'", int46 == 1);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNull(jSType48);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        com.google.javascript.jscomp.SourceFile sourceFile3 = com.google.javascript.jscomp.SourceFile.fromCode("hi!", "Unknown class name", "Unknown class name");
        java.io.Reader reader4 = sourceFile3.getCodeReader();
        java.lang.String str5 = sourceFile3.toString();
        java.io.Reader reader6 = sourceFile3.getCodeReader();
        org.junit.Assert.assertNotNull(sourceFile3);
        org.junit.Assert.assertNotNull(reader4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        org.junit.Assert.assertNotNull(reader6);
    }

//    @Test
//    public void test102() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test102");
//        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.CHECK_VARIABLES;
//        com.google.javascript.jscomp.DiagnosticGroups.TYPE_INVALIDATION = diagnosticGroup0;
//        org.junit.Assert.assertNull(diagnosticGroup0);
//    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        com.google.javascript.rhino.Node node0 = null;
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newNumber((double) (short) -1, (int) (byte) 1, 0);
        boolean boolean5 = node4.isArrayLit();
        com.google.javascript.rhino.Node node6 = node4.cloneTree();
        boolean boolean7 = node6.isVar();
        try {
            com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.IR.or(node0, node6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, true);
        com.google.javascript.rhino.ErrorReporter errorReporter3 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter3, true);
        com.google.javascript.rhino.ErrorReporter errorReporter6 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry8 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter6, true);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative9 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative10 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative11 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray12 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative9, jSTypeNative10, jSTypeNative11 };
        com.google.javascript.rhino.jstype.JSType jSType13 = jSTypeRegistry8.createUnionType(jSTypeNativeArray12);
        boolean boolean14 = jSType13.isRegexpType();
        boolean boolean15 = jSType13.isNullable();
        com.google.javascript.rhino.ErrorReporter errorReporter16 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry18 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter16, true);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative19 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative20 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative21 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray22 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative19, jSTypeNative20, jSTypeNative21 };
        com.google.javascript.rhino.jstype.JSType jSType23 = jSTypeRegistry18.createUnionType(jSTypeNativeArray22);
        com.google.javascript.rhino.ErrorReporter errorReporter24 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry26 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter24, true);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative27 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative28 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative29 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray30 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative27, jSTypeNative28, jSTypeNative29 };
        com.google.javascript.rhino.jstype.JSType jSType31 = jSTypeRegistry26.createUnionType(jSTypeNativeArray30);
        com.google.javascript.rhino.JSDocInfo jSDocInfo32 = jSType31.getJSDocInfo();
        com.google.javascript.rhino.jstype.ObjectType objectType33 = jSType31.toObjectType();
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray34 = new com.google.javascript.rhino.jstype.JSType[] { jSType23, jSType31 };
        com.google.javascript.rhino.jstype.FunctionType functionType35 = jSTypeRegistry5.createConstructorTypeWithVarArgs(jSType13, jSTypeArray34);
        com.google.javascript.rhino.ErrorReporter errorReporter36 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry38 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter36, true);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative39 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative40 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative41 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray42 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative39, jSTypeNative40, jSTypeNative41 };
        com.google.javascript.rhino.jstype.JSType jSType43 = jSTypeRegistry38.createUnionType(jSTypeNativeArray42);
        boolean boolean44 = jSType43.isStringObjectType();
        com.google.javascript.rhino.jstype.ParameterizedType parameterizedType45 = jSTypeRegistry2.createParameterizedType((com.google.javascript.rhino.jstype.ObjectType) functionType35, jSType43);
        boolean boolean46 = parameterizedType45.hasAnyTemplateInternal();
        com.google.javascript.rhino.jstype.JSType jSType47 = parameterizedType45.getIndexType();
        boolean boolean48 = parameterizedType45.isNominalType();
        boolean boolean49 = parameterizedType45.isOrdinaryFunction();
        org.junit.Assert.assertTrue("'" + jSTypeNative9 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative9.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative10 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative10.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative11 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative11.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray12);
        org.junit.Assert.assertNotNull(jSType13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + jSTypeNative19 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative19.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative20 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative20.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative21 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative21.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray22);
        org.junit.Assert.assertNotNull(jSType23);
        org.junit.Assert.assertTrue("'" + jSTypeNative27 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative27.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative28 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative28.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative29 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative29.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray30);
        org.junit.Assert.assertNotNull(jSType31);
        org.junit.Assert.assertNull(jSDocInfo32);
        org.junit.Assert.assertNull(objectType33);
        org.junit.Assert.assertNotNull(jSTypeArray34);
        org.junit.Assert.assertNotNull(functionType35);
        org.junit.Assert.assertTrue("'" + jSTypeNative39 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative39.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative40 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative40.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative41 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative41.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray42);
        org.junit.Assert.assertNotNull(jSType43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(parameterizedType45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNull(jSType47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newNumber((double) (short) -1, (int) (byte) 1, 0);
        boolean boolean5 = node4.isArrayLit();
        boolean boolean6 = node4.isLabelName();
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newNumber((double) (short) -1, (int) (byte) 1, 0);
        boolean boolean11 = node10.isArrayLit();
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.Node.newNumber((double) (short) -1, (int) (byte) 1, 0);
        com.google.javascript.rhino.Node node16 = new com.google.javascript.rhino.Node((int) '#', node4, node10, node15);
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.Node.newNumber(0.0d);
        com.google.javascript.rhino.Node node19 = node4.copyInformationFromForTree(node18);
        boolean boolean20 = node19.isAssign();
        com.google.javascript.rhino.Node node24 = com.google.javascript.rhino.Node.newNumber((double) (short) -1, (int) (byte) 1, 0);
        node19.addChildrenToFront(node24);
        node24.setLineno((int) (byte) 1);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder28 = node24.getJsDocBuilderForNode();
        fileLevelJsDocBuilder28.append("Unversioned directory");
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder28);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newNumber((double) (short) -1, (int) (byte) 1, 0);
        int int4 = node3.getSourcePosition();
        com.google.javascript.rhino.jstype.StaticSourceFile staticSourceFile5 = com.google.javascript.jscomp.NodeUtil.getSourceFile(node3);
        boolean boolean6 = node3.isSetterDef();
        boolean boolean7 = node3.isCatch();
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 4096 + "'", int4 == 4096);
        org.junit.Assert.assertNull(staticSourceFile5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        com.google.javascript.jscomp.MessageFormatter messageFormatter0 = null;
        java.util.logging.Logger logger1 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager2 = new com.google.javascript.jscomp.LoggerErrorManager(messageFormatter0, logger1);
        com.google.javascript.jscomp.CheckLevel checkLevel3 = com.google.javascript.jscomp.CheckLevel.WARNING;
        com.google.javascript.jscomp.DiagnosticType diagnosticType7 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        com.google.javascript.jscomp.CheckLevel checkLevel8 = null;
        diagnosticType7.level = checkLevel8;
        java.lang.String[] strArray15 = new java.lang.String[] { "GETELEM", "./", "GETELEM", "GETELEM", "NUMBER -1.0 1" };
        com.google.javascript.jscomp.JSError jSError16 = com.google.javascript.jscomp.JSError.make("hi!", 8, (int) (short) 0, diagnosticType7, strArray15);
        loggerErrorManager2.report(checkLevel3, jSError16);
        com.google.javascript.jscomp.CheckLevel checkLevel18 = jSError16.getDefaultLevel();
        com.google.javascript.jscomp.DiagnosticType diagnosticType19 = com.google.javascript.jscomp.Compiler.MOTION_ITERATIONS_ERROR;
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup20 = com.google.javascript.jscomp.DiagnosticGroup.forType(diagnosticType19);
        com.google.javascript.jscomp.DiagnosticType diagnosticType21 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        com.google.javascript.jscomp.CheckLevel checkLevel22 = null;
        diagnosticType21.level = checkLevel22;
        com.google.javascript.jscomp.CheckLevel checkLevel24 = diagnosticType21.defaultLevel;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard25 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup20, checkLevel24);
        com.google.javascript.jscomp.DiagnosticType diagnosticType26 = com.google.javascript.jscomp.Compiler.MOTION_ITERATIONS_ERROR;
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup27 = com.google.javascript.jscomp.DiagnosticGroup.forType(diagnosticType26);
        com.google.javascript.jscomp.DiagnosticType diagnosticType28 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        com.google.javascript.jscomp.CheckLevel checkLevel29 = null;
        diagnosticType28.level = checkLevel29;
        com.google.javascript.jscomp.CheckLevel checkLevel31 = diagnosticType28.defaultLevel;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard32 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup27, checkLevel31);
        com.google.javascript.jscomp.StrictWarningsGuard strictWarningsGuard33 = new com.google.javascript.jscomp.StrictWarningsGuard();
        com.google.javascript.jscomp.StrictWarningsGuard strictWarningsGuard34 = new com.google.javascript.jscomp.StrictWarningsGuard();
        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray35 = new com.google.javascript.jscomp.WarningsGuard[] { diagnosticGroupWarningsGuard25, diagnosticGroupWarningsGuard32, strictWarningsGuard33, strictWarningsGuard34 };
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard36 = new com.google.javascript.jscomp.ComposeWarningsGuard(warningsGuardArray35);
        com.google.javascript.jscomp.MessageFormatter messageFormatter37 = null;
        java.util.logging.Logger logger38 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager39 = new com.google.javascript.jscomp.LoggerErrorManager(messageFormatter37, logger38);
        loggerErrorManager39.setTypedPercent((double) 100);
        com.google.javascript.jscomp.CheckLevel checkLevel42 = null;
        com.google.javascript.rhino.Node node47 = com.google.javascript.rhino.Node.newNumber((double) (short) -1, (int) (byte) 1, 0);
        boolean boolean48 = node47.isArrayLit();
        com.google.javascript.rhino.Node node52 = com.google.javascript.rhino.Node.newNumber((double) (short) -1, (int) (byte) 1, 0);
        com.google.javascript.rhino.Node node53 = com.google.javascript.rhino.IR.getelem(node47, node52);
        boolean boolean54 = node52.isTrue();
        com.google.javascript.jscomp.CheckLevel checkLevel55 = null;
        com.google.javascript.jscomp.DiagnosticType diagnosticType56 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        java.lang.String[] strArray57 = new java.lang.String[] {};
        com.google.javascript.jscomp.JSError jSError58 = com.google.javascript.jscomp.JSError.make("GETELEM", node52, checkLevel55, diagnosticType56, strArray57);
        loggerErrorManager39.report(checkLevel42, jSError58);
        java.lang.String str60 = jSError58.sourceName;
        com.google.javascript.jscomp.CheckLevel checkLevel61 = composeWarningsGuard36.level(jSError58);
        com.google.javascript.jscomp.MessageFormatter messageFormatter62 = null;
        try {
            java.lang.String str63 = jSError16.format(checkLevel61, messageFormatter62);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + checkLevel3 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel3.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
        org.junit.Assert.assertNotNull(diagnosticType7);
        org.junit.Assert.assertNotNull(strArray15);
        org.junit.Assert.assertNotNull(jSError16);
        org.junit.Assert.assertNull(checkLevel18);
        org.junit.Assert.assertNotNull(diagnosticType19);
        org.junit.Assert.assertNotNull(diagnosticGroup20);
        org.junit.Assert.assertNotNull(diagnosticType21);
        org.junit.Assert.assertTrue("'" + checkLevel24 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel24.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticType26);
        org.junit.Assert.assertNotNull(diagnosticGroup27);
        org.junit.Assert.assertNotNull(diagnosticType28);
        org.junit.Assert.assertTrue("'" + checkLevel31 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel31.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(warningsGuardArray35);
        org.junit.Assert.assertNotNull(node47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(node52);
        org.junit.Assert.assertNotNull(node53);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNotNull(diagnosticType56);
        org.junit.Assert.assertNotNull(strArray57);
        org.junit.Assert.assertNotNull(jSError58);
        org.junit.Assert.assertTrue("'" + str60 + "' != '" + "GETELEM" + "'", str60.equals("GETELEM"));
        org.junit.Assert.assertTrue("'" + checkLevel61 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel61.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        com.google.javascript.jscomp.SourceFile sourceFile3 = com.google.javascript.jscomp.SourceFile.fromCode("hi!", "Unknown class name", "Unknown class name");
        com.google.javascript.jscomp.Region region5 = sourceFile3.getRegion(2147483647);
        com.google.javascript.jscomp.CompilerInput compilerInput7 = new com.google.javascript.jscomp.CompilerInput(sourceFile3, false);
        org.junit.Assert.assertNotNull(sourceFile3);
        org.junit.Assert.assertNull(region5);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newNumber((double) (short) -1, (int) (byte) 1, 0);
        boolean boolean5 = node4.isArrayLit();
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newNumber((double) (short) -1, (int) (byte) 1, 0);
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.IR.getelem(node4, node9);
        boolean boolean11 = node9.isTrue();
        com.google.javascript.jscomp.CheckLevel checkLevel12 = null;
        com.google.javascript.jscomp.DiagnosticType diagnosticType13 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        java.lang.String[] strArray14 = new java.lang.String[] {};
        com.google.javascript.jscomp.JSError jSError15 = com.google.javascript.jscomp.JSError.make("GETELEM", node9, checkLevel12, diagnosticType13, strArray14);
        com.google.javascript.jscomp.MessageFormatter messageFormatter16 = null;
        java.util.logging.Logger logger17 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager18 = new com.google.javascript.jscomp.LoggerErrorManager(messageFormatter16, logger17);
        com.google.javascript.jscomp.CheckLevel checkLevel19 = com.google.javascript.jscomp.CheckLevel.WARNING;
        com.google.javascript.jscomp.DiagnosticType diagnosticType23 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        com.google.javascript.jscomp.CheckLevel checkLevel24 = null;
        diagnosticType23.level = checkLevel24;
        java.lang.String[] strArray31 = new java.lang.String[] { "GETELEM", "./", "GETELEM", "GETELEM", "NUMBER -1.0 1" };
        com.google.javascript.jscomp.JSError jSError32 = com.google.javascript.jscomp.JSError.make("hi!", 8, (int) (short) 0, diagnosticType23, strArray31);
        loggerErrorManager18.report(checkLevel19, jSError32);
        com.google.javascript.jscomp.MessageFormatter messageFormatter34 = null;
        try {
            java.lang.String str35 = jSError15.format(checkLevel19, messageFormatter34);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(diagnosticType13);
        org.junit.Assert.assertNotNull(strArray14);
        org.junit.Assert.assertNotNull(jSError15);
        org.junit.Assert.assertTrue("'" + checkLevel19 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel19.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
        org.junit.Assert.assertNotNull(diagnosticType23);
        org.junit.Assert.assertNotNull(strArray31);
        org.junit.Assert.assertNotNull(jSError32);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, true);
        com.google.javascript.rhino.ErrorReporter errorReporter3 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter3, true);
        com.google.javascript.rhino.ErrorReporter errorReporter6 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry8 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter6, true);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative9 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative10 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative11 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray12 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative9, jSTypeNative10, jSTypeNative11 };
        com.google.javascript.rhino.jstype.JSType jSType13 = jSTypeRegistry8.createUnionType(jSTypeNativeArray12);
        boolean boolean14 = jSType13.isRegexpType();
        boolean boolean15 = jSType13.isNullable();
        com.google.javascript.rhino.ErrorReporter errorReporter16 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry18 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter16, true);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative19 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative20 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative21 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray22 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative19, jSTypeNative20, jSTypeNative21 };
        com.google.javascript.rhino.jstype.JSType jSType23 = jSTypeRegistry18.createUnionType(jSTypeNativeArray22);
        com.google.javascript.rhino.ErrorReporter errorReporter24 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry26 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter24, true);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative27 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative28 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative29 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray30 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative27, jSTypeNative28, jSTypeNative29 };
        com.google.javascript.rhino.jstype.JSType jSType31 = jSTypeRegistry26.createUnionType(jSTypeNativeArray30);
        com.google.javascript.rhino.JSDocInfo jSDocInfo32 = jSType31.getJSDocInfo();
        com.google.javascript.rhino.jstype.ObjectType objectType33 = jSType31.toObjectType();
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray34 = new com.google.javascript.rhino.jstype.JSType[] { jSType23, jSType31 };
        com.google.javascript.rhino.jstype.FunctionType functionType35 = jSTypeRegistry5.createConstructorTypeWithVarArgs(jSType13, jSTypeArray34);
        com.google.javascript.rhino.ErrorReporter errorReporter36 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry38 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter36, true);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative39 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative40 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative41 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray42 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative39, jSTypeNative40, jSTypeNative41 };
        com.google.javascript.rhino.jstype.JSType jSType43 = jSTypeRegistry38.createUnionType(jSTypeNativeArray42);
        boolean boolean44 = jSType43.isStringObjectType();
        com.google.javascript.rhino.jstype.ParameterizedType parameterizedType45 = jSTypeRegistry2.createParameterizedType((com.google.javascript.rhino.jstype.ObjectType) functionType35, jSType43);
        boolean boolean46 = parameterizedType45.hasAnyTemplateInternal();
        com.google.javascript.rhino.jstype.FunctionType functionType47 = parameterizedType45.getConstructor();
        java.util.Set set48 = parameterizedType45.getOwnPropertyNames();
        com.google.javascript.rhino.JSDocInfo jSDocInfo50 = new com.google.javascript.rhino.JSDocInfo();
        boolean boolean51 = jSDocInfo50.isDeprecated();
        parameterizedType45.setPropertyJSDocInfo("function ({1262020967}, {({954206644},{1279119928})}): {1555607401}", jSDocInfo50);
        boolean boolean53 = parameterizedType45.isGlobalThisType();
        org.junit.Assert.assertTrue("'" + jSTypeNative9 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative9.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative10 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative10.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative11 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative11.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray12);
        org.junit.Assert.assertNotNull(jSType13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + jSTypeNative19 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative19.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative20 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative20.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative21 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative21.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray22);
        org.junit.Assert.assertNotNull(jSType23);
        org.junit.Assert.assertTrue("'" + jSTypeNative27 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative27.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative28 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative28.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative29 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative29.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray30);
        org.junit.Assert.assertNotNull(jSType31);
        org.junit.Assert.assertNull(jSDocInfo32);
        org.junit.Assert.assertNull(objectType33);
        org.junit.Assert.assertNotNull(jSTypeArray34);
        org.junit.Assert.assertNotNull(functionType35);
        org.junit.Assert.assertTrue("'" + jSTypeNative39 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative39.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative40 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative40.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative41 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative41.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray42);
        org.junit.Assert.assertNotNull(jSType43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(parameterizedType45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNull(functionType47);
        org.junit.Assert.assertNotNull(set48);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, true);
        com.google.javascript.rhino.ErrorReporter errorReporter3 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter3, true);
        com.google.javascript.rhino.ErrorReporter errorReporter6 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry8 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter6, true);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative9 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative10 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative11 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray12 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative9, jSTypeNative10, jSTypeNative11 };
        com.google.javascript.rhino.jstype.JSType jSType13 = jSTypeRegistry8.createUnionType(jSTypeNativeArray12);
        boolean boolean14 = jSType13.isRegexpType();
        boolean boolean15 = jSType13.isNullable();
        com.google.javascript.rhino.ErrorReporter errorReporter16 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry18 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter16, true);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative19 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative20 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative21 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray22 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative19, jSTypeNative20, jSTypeNative21 };
        com.google.javascript.rhino.jstype.JSType jSType23 = jSTypeRegistry18.createUnionType(jSTypeNativeArray22);
        com.google.javascript.rhino.ErrorReporter errorReporter24 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry26 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter24, true);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative27 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative28 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative29 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray30 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative27, jSTypeNative28, jSTypeNative29 };
        com.google.javascript.rhino.jstype.JSType jSType31 = jSTypeRegistry26.createUnionType(jSTypeNativeArray30);
        com.google.javascript.rhino.JSDocInfo jSDocInfo32 = jSType31.getJSDocInfo();
        com.google.javascript.rhino.jstype.ObjectType objectType33 = jSType31.toObjectType();
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray34 = new com.google.javascript.rhino.jstype.JSType[] { jSType23, jSType31 };
        com.google.javascript.rhino.jstype.FunctionType functionType35 = jSTypeRegistry5.createConstructorTypeWithVarArgs(jSType13, jSTypeArray34);
        com.google.javascript.rhino.ErrorReporter errorReporter36 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry38 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter36, true);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative39 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative40 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative41 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray42 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative39, jSTypeNative40, jSTypeNative41 };
        com.google.javascript.rhino.jstype.JSType jSType43 = jSTypeRegistry38.createUnionType(jSTypeNativeArray42);
        boolean boolean44 = jSType43.isStringObjectType();
        com.google.javascript.rhino.jstype.ParameterizedType parameterizedType45 = jSTypeRegistry2.createParameterizedType((com.google.javascript.rhino.jstype.ObjectType) functionType35, jSType43);
        boolean boolean46 = parameterizedType45.hasAnyTemplateInternal();
        com.google.javascript.rhino.jstype.FunctionType functionType47 = parameterizedType45.getConstructor();
        boolean boolean48 = parameterizedType45.isBooleanValueType();
        boolean boolean49 = parameterizedType45.isNoType();
        boolean boolean50 = parameterizedType45.isTemplateType();
        parameterizedType45.clearCachedValues();
        boolean boolean52 = parameterizedType45.matchesStringContext();
        boolean boolean53 = parameterizedType45.isRecordType();
        boolean boolean54 = parameterizedType45.hasCachedValues();
        boolean boolean55 = parameterizedType45.isInstanceType();
        org.junit.Assert.assertTrue("'" + jSTypeNative9 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative9.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative10 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative10.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative11 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative11.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray12);
        org.junit.Assert.assertNotNull(jSType13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + jSTypeNative19 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative19.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative20 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative20.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative21 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative21.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray22);
        org.junit.Assert.assertNotNull(jSType23);
        org.junit.Assert.assertTrue("'" + jSTypeNative27 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative27.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative28 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative28.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative29 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative29.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray30);
        org.junit.Assert.assertNotNull(jSType31);
        org.junit.Assert.assertNull(jSDocInfo32);
        org.junit.Assert.assertNull(objectType33);
        org.junit.Assert.assertNotNull(jSTypeArray34);
        org.junit.Assert.assertNotNull(functionType35);
        org.junit.Assert.assertTrue("'" + jSTypeNative39 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative39.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative40 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative40.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative41 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative41.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray42);
        org.junit.Assert.assertNotNull(jSType43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(parameterizedType45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNull(functionType47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.DUPLICATE_VARS;
        com.google.javascript.jscomp.DiagnosticGroups.ES5_STRICT = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticGroups.TYPE_INVALIDATION = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticGroups.STRICT_MODULE_DEP_CHECK = diagnosticGroup0;
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newNumber((double) (short) -1, (int) (byte) 1, 0);
        boolean boolean9 = node8.isArrayLit();
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newNumber((double) (short) -1, (int) (byte) 1, 0);
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.IR.getelem(node8, node13);
        boolean boolean15 = node13.isTrue();
        com.google.javascript.jscomp.CheckLevel checkLevel16 = null;
        com.google.javascript.jscomp.DiagnosticType diagnosticType17 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        java.lang.String[] strArray18 = new java.lang.String[] {};
        com.google.javascript.jscomp.JSError jSError19 = com.google.javascript.jscomp.JSError.make("GETELEM", node13, checkLevel16, diagnosticType17, strArray18);
        int int20 = jSError19.getLineNumber();
        com.google.javascript.jscomp.CheckLevel checkLevel21 = jSError19.level;
        boolean boolean22 = diagnosticGroup0.matches(jSError19);
        org.junit.Assert.assertNotNull(diagnosticGroup0);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(diagnosticType17);
        org.junit.Assert.assertNotNull(strArray18);
        org.junit.Assert.assertNotNull(jSError19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertNull(checkLevel21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newNumber((double) (short) -1, (int) (byte) 1, 0);
        boolean boolean4 = node3.isArrayLit();
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newNumber((double) (short) -1, (int) (byte) 1, 0);
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.IR.getelem(node3, node8);
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.Node.newNumber((double) (short) -1, (int) (byte) 1, 0);
        boolean boolean15 = node14.isArrayLit();
        boolean boolean16 = node14.isLabelName();
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.Node.newNumber((double) (short) -1, (int) (byte) 1, 0);
        boolean boolean21 = node20.isArrayLit();
        com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.Node.newNumber((double) (short) -1, (int) (byte) 1, 0);
        com.google.javascript.rhino.Node node26 = new com.google.javascript.rhino.Node((int) '#', node14, node20, node25);
        com.google.javascript.rhino.Node node28 = com.google.javascript.rhino.Node.newNumber(0.0d);
        com.google.javascript.rhino.Node node29 = node14.copyInformationFromForTree(node28);
        com.google.javascript.rhino.Node node30 = node3.copyInformationFrom(node29);
        java.util.Set<java.lang.String> strSet31 = node3.getDirectives();
        boolean boolean32 = node3.isLabel();
        int int33 = node3.getLength();
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNotNull(node30);
        org.junit.Assert.assertNull(strSet31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        com.google.javascript.jscomp.AbstractCompiler abstractCompiler0 = null;
        com.google.javascript.jscomp.NodeTraversal.Callback callback1 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal2 = new com.google.javascript.jscomp.NodeTraversal(abstractCompiler0, callback1);
        java.lang.String str3 = nodeTraversal2.getSourceName();
        com.google.javascript.rhino.Node node4 = nodeTraversal2.getEnclosingFunction();
        com.google.javascript.rhino.Node[] nodeArray5 = new com.google.javascript.rhino.Node[] {};
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.IR.script(nodeArray5);
        nodeTraversal2.traverseRoots(nodeArray5);
        com.google.javascript.jscomp.Compiler compiler8 = nodeTraversal2.getCompiler();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
        org.junit.Assert.assertNull(node4);
        org.junit.Assert.assertNotNull(nodeArray5);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNull(compiler8);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        com.google.javascript.jscomp.JSModule jSModule1 = new com.google.javascript.jscomp.JSModule("hi!");
        com.google.javascript.jscomp.Compiler compiler2 = null;
        jSModule1.sortInputsByDeps(compiler2);
        jSModule1.setDepth((int) (byte) -1);
        java.util.Set<com.google.javascript.jscomp.JSModule> jSModuleSet6 = jSModule1.getThisAndAllDependencies();
        com.google.javascript.jscomp.JSModule[] jSModuleArray7 = com.google.javascript.jscomp.JSModule.sortJsModules((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleSet6);
        com.google.javascript.jscomp.JSModule[] jSModuleArray8 = com.google.javascript.jscomp.JSModule.sortJsModules((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleSet6);
        org.junit.Assert.assertNotNull(jSModuleSet6);
        org.junit.Assert.assertNotNull(jSModuleArray7);
        org.junit.Assert.assertNotNull(jSModuleArray8);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newNumber((double) (short) -1, (int) (byte) 1, 0);
        boolean boolean4 = node3.isArrayLit();
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newNumber((double) (short) -1, (int) (byte) 1, 0);
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.IR.getelem(node3, node8);
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.Node.newNumber((double) (short) -1, (int) (byte) 1, 0);
        boolean boolean15 = node14.isArrayLit();
        boolean boolean16 = node14.isLabelName();
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.Node.newNumber((double) (short) -1, (int) (byte) 1, 0);
        boolean boolean21 = node20.isArrayLit();
        com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.Node.newNumber((double) (short) -1, (int) (byte) 1, 0);
        com.google.javascript.rhino.Node node26 = new com.google.javascript.rhino.Node((int) '#', node14, node20, node25);
        com.google.javascript.rhino.Node node28 = com.google.javascript.rhino.Node.newNumber(0.0d);
        com.google.javascript.rhino.Node node29 = node14.copyInformationFromForTree(node28);
        com.google.javascript.rhino.Node node30 = node3.copyInformationFrom(node29);
        boolean boolean31 = node3.isRegExp();
        com.google.javascript.rhino.Node node36 = com.google.javascript.rhino.Node.newNumber((double) (short) -1, (int) (byte) 1, 0);
        boolean boolean37 = node36.isArrayLit();
        boolean boolean38 = node36.isLabelName();
        com.google.javascript.rhino.Node node42 = com.google.javascript.rhino.Node.newNumber((double) (short) -1, (int) (byte) 1, 0);
        boolean boolean43 = node42.isArrayLit();
        com.google.javascript.rhino.Node node47 = com.google.javascript.rhino.Node.newNumber((double) (short) -1, (int) (byte) 1, 0);
        com.google.javascript.rhino.Node node48 = new com.google.javascript.rhino.Node((int) '#', node36, node42, node47);
        com.google.javascript.rhino.Node node50 = com.google.javascript.rhino.Node.newNumber(0.0d);
        com.google.javascript.rhino.Node node51 = node36.copyInformationFromForTree(node50);
        boolean boolean52 = node51.isAssign();
        boolean boolean53 = node51.isRegExp();
        int int54 = node3.getIndexOfChild(node51);
        try {
            com.google.javascript.rhino.Node node55 = com.google.javascript.rhino.IR.voidNode(node51);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: new child has existing parent");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNotNull(node30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(node36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(node42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(node47);
        org.junit.Assert.assertNotNull(node50);
        org.junit.Assert.assertNotNull(node51);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + (-1) + "'", int54 == (-1));
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, true);
        com.google.javascript.rhino.ErrorReporter errorReporter3 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter3, true);
        com.google.javascript.rhino.ErrorReporter errorReporter6 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry8 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter6, true);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative9 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative10 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative11 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray12 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative9, jSTypeNative10, jSTypeNative11 };
        com.google.javascript.rhino.jstype.JSType jSType13 = jSTypeRegistry8.createUnionType(jSTypeNativeArray12);
        boolean boolean14 = jSType13.isRegexpType();
        boolean boolean15 = jSType13.isNullable();
        com.google.javascript.rhino.ErrorReporter errorReporter16 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry18 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter16, true);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative19 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative20 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative21 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray22 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative19, jSTypeNative20, jSTypeNative21 };
        com.google.javascript.rhino.jstype.JSType jSType23 = jSTypeRegistry18.createUnionType(jSTypeNativeArray22);
        com.google.javascript.rhino.ErrorReporter errorReporter24 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry26 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter24, true);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative27 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative28 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative29 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray30 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative27, jSTypeNative28, jSTypeNative29 };
        com.google.javascript.rhino.jstype.JSType jSType31 = jSTypeRegistry26.createUnionType(jSTypeNativeArray30);
        com.google.javascript.rhino.JSDocInfo jSDocInfo32 = jSType31.getJSDocInfo();
        com.google.javascript.rhino.jstype.ObjectType objectType33 = jSType31.toObjectType();
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray34 = new com.google.javascript.rhino.jstype.JSType[] { jSType23, jSType31 };
        com.google.javascript.rhino.jstype.FunctionType functionType35 = jSTypeRegistry5.createConstructorTypeWithVarArgs(jSType13, jSTypeArray34);
        com.google.javascript.rhino.ErrorReporter errorReporter36 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry38 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter36, true);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative39 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative40 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative41 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray42 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative39, jSTypeNative40, jSTypeNative41 };
        com.google.javascript.rhino.jstype.JSType jSType43 = jSTypeRegistry38.createUnionType(jSTypeNativeArray42);
        boolean boolean44 = jSType43.isStringObjectType();
        com.google.javascript.rhino.jstype.ParameterizedType parameterizedType45 = jSTypeRegistry2.createParameterizedType((com.google.javascript.rhino.jstype.ObjectType) functionType35, jSType43);
        boolean boolean46 = parameterizedType45.hasAnyTemplateInternal();
        com.google.javascript.rhino.jstype.JSType jSType47 = parameterizedType45.getIndexType();
        boolean boolean49 = parameterizedType45.isPropertyTypeInferred("NUMBER -1.0 1");
        boolean boolean51 = parameterizedType45.hasOwnProperty("({proxy:function ({1047075399}, {({605412354},{558514873})}): {1793560964}})");
        com.google.javascript.rhino.jstype.TemplateType templateType52 = parameterizedType45.toMaybeTemplateType();
        try {
            com.google.javascript.rhino.jstype.TemplateType templateType53 = templateType52.toMaybeTemplateType();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + jSTypeNative9 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative9.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative10 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative10.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative11 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative11.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray12);
        org.junit.Assert.assertNotNull(jSType13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + jSTypeNative19 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative19.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative20 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative20.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative21 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative21.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray22);
        org.junit.Assert.assertNotNull(jSType23);
        org.junit.Assert.assertTrue("'" + jSTypeNative27 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative27.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative28 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative28.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative29 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative29.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray30);
        org.junit.Assert.assertNotNull(jSType31);
        org.junit.Assert.assertNull(jSDocInfo32);
        org.junit.Assert.assertNull(objectType33);
        org.junit.Assert.assertNotNull(jSTypeArray34);
        org.junit.Assert.assertNotNull(functionType35);
        org.junit.Assert.assertTrue("'" + jSTypeNative39 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative39.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative40 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative40.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative41 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative41.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray42);
        org.junit.Assert.assertNotNull(jSType43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(parameterizedType45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNull(jSType47);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertNull(templateType52);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, true);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative3 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative4 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative5 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray6 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative3, jSTypeNative4, jSTypeNative5 };
        com.google.javascript.rhino.jstype.JSType jSType7 = jSTypeRegistry2.createUnionType(jSTypeNativeArray6);
        com.google.javascript.rhino.ErrorReporter errorReporter8 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry10 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter8, true);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative11 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative12 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative13 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray14 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative11, jSTypeNative12, jSTypeNative13 };
        com.google.javascript.rhino.jstype.JSType jSType15 = jSTypeRegistry10.createUnionType(jSTypeNativeArray14);
        boolean boolean16 = jSType15.isRegexpType();
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray17 = new com.google.javascript.rhino.jstype.JSType[] { jSType15 };
        com.google.javascript.rhino.jstype.JSType jSType18 = jSTypeRegistry2.createUnionType(jSTypeArray17);
        com.google.javascript.rhino.ErrorReporter errorReporter20 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry22 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter20, true);
        com.google.javascript.rhino.ErrorReporter errorReporter23 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry25 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter23, true);
        com.google.javascript.rhino.ErrorReporter errorReporter26 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry28 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter26, true);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative29 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative30 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative31 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray32 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative29, jSTypeNative30, jSTypeNative31 };
        com.google.javascript.rhino.jstype.JSType jSType33 = jSTypeRegistry28.createUnionType(jSTypeNativeArray32);
        boolean boolean34 = jSType33.isRegexpType();
        boolean boolean35 = jSType33.isNullable();
        com.google.javascript.rhino.ErrorReporter errorReporter36 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry38 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter36, true);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative39 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative40 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative41 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray42 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative39, jSTypeNative40, jSTypeNative41 };
        com.google.javascript.rhino.jstype.JSType jSType43 = jSTypeRegistry38.createUnionType(jSTypeNativeArray42);
        com.google.javascript.rhino.ErrorReporter errorReporter44 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry46 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter44, true);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative47 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative48 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative49 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray50 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative47, jSTypeNative48, jSTypeNative49 };
        com.google.javascript.rhino.jstype.JSType jSType51 = jSTypeRegistry46.createUnionType(jSTypeNativeArray50);
        com.google.javascript.rhino.JSDocInfo jSDocInfo52 = jSType51.getJSDocInfo();
        com.google.javascript.rhino.jstype.ObjectType objectType53 = jSType51.toObjectType();
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray54 = new com.google.javascript.rhino.jstype.JSType[] { jSType43, jSType51 };
        com.google.javascript.rhino.jstype.FunctionType functionType55 = jSTypeRegistry25.createConstructorTypeWithVarArgs(jSType33, jSTypeArray54);
        com.google.javascript.rhino.ErrorReporter errorReporter56 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry58 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter56, true);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative59 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative60 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative61 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray62 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative59, jSTypeNative60, jSTypeNative61 };
        com.google.javascript.rhino.jstype.JSType jSType63 = jSTypeRegistry58.createUnionType(jSTypeNativeArray62);
        boolean boolean64 = jSType63.isStringObjectType();
        com.google.javascript.rhino.jstype.ParameterizedType parameterizedType65 = jSTypeRegistry22.createParameterizedType((com.google.javascript.rhino.jstype.ObjectType) functionType55, jSType63);
        com.google.javascript.rhino.jstype.JSType jSType66 = parameterizedType65.getParameterType();
        jSTypeRegistry2.registerPropertyOnType("function ({973952929}, {({834630149},{962344528})}): {100783531}", (com.google.javascript.rhino.jstype.JSType) parameterizedType65);
        boolean boolean68 = parameterizedType65.isNumberObjectType();
        org.junit.Assert.assertTrue("'" + jSTypeNative3 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative3.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative4 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative4.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative5 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative5.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray6);
        org.junit.Assert.assertNotNull(jSType7);
        org.junit.Assert.assertTrue("'" + jSTypeNative11 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative11.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative12 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative12.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative13 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative13.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray14);
        org.junit.Assert.assertNotNull(jSType15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(jSTypeArray17);
        org.junit.Assert.assertNotNull(jSType18);
        org.junit.Assert.assertTrue("'" + jSTypeNative29 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative29.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative30 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative30.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative31 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative31.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray32);
        org.junit.Assert.assertNotNull(jSType33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + jSTypeNative39 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative39.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative40 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative40.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative41 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative41.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray42);
        org.junit.Assert.assertNotNull(jSType43);
        org.junit.Assert.assertTrue("'" + jSTypeNative47 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative47.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative48 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative48.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative49 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative49.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray50);
        org.junit.Assert.assertNotNull(jSType51);
        org.junit.Assert.assertNull(jSDocInfo52);
        org.junit.Assert.assertNull(objectType53);
        org.junit.Assert.assertNotNull(jSTypeArray54);
        org.junit.Assert.assertNotNull(functionType55);
        org.junit.Assert.assertTrue("'" + jSTypeNative59 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative59.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative60 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative60.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative61 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative61.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray62);
        org.junit.Assert.assertNotNull(jSType63);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertNotNull(parameterizedType65);
        org.junit.Assert.assertNotNull(jSType66);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
    }

//    @Test
//    public void test119() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test119");
//        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, true);
//        com.google.javascript.rhino.jstype.JSType jSType7 = jSTypeRegistry2.createNamedType("GETELEM", "hi!", 0, 38);
//        jSTypeRegistry2.incrementGeneration();
//        com.google.javascript.rhino.ErrorReporter errorReporter9 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry11 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter9, true);
//        com.google.javascript.rhino.ErrorReporter errorReporter12 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry14 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter12, true);
//        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative15 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
//        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative16 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
//        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative17 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
//        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray18 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative15, jSTypeNative16, jSTypeNative17 };
//        com.google.javascript.rhino.jstype.JSType jSType19 = jSTypeRegistry14.createUnionType(jSTypeNativeArray18);
//        boolean boolean20 = jSType19.isRegexpType();
//        boolean boolean21 = jSType19.isNullable();
//        com.google.javascript.rhino.ErrorReporter errorReporter22 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry24 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter22, true);
//        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative25 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
//        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative26 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
//        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative27 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
//        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray28 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative25, jSTypeNative26, jSTypeNative27 };
//        com.google.javascript.rhino.jstype.JSType jSType29 = jSTypeRegistry24.createUnionType(jSTypeNativeArray28);
//        com.google.javascript.rhino.ErrorReporter errorReporter30 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry32 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter30, true);
//        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative33 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
//        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative34 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
//        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative35 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
//        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray36 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative33, jSTypeNative34, jSTypeNative35 };
//        com.google.javascript.rhino.jstype.JSType jSType37 = jSTypeRegistry32.createUnionType(jSTypeNativeArray36);
//        com.google.javascript.rhino.JSDocInfo jSDocInfo38 = jSType37.getJSDocInfo();
//        com.google.javascript.rhino.jstype.ObjectType objectType39 = jSType37.toObjectType();
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray40 = new com.google.javascript.rhino.jstype.JSType[] { jSType29, jSType37 };
//        com.google.javascript.rhino.jstype.FunctionType functionType41 = jSTypeRegistry11.createConstructorTypeWithVarArgs(jSType19, jSTypeArray40);
//        java.lang.Iterable iterable42 = functionType41.getCtorImplementedInterfaces();
//        jSTypeRegistry2.resolveTypesInScope((com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType>) functionType41);
//        int int44 = functionType41.getMaxArguments();
//        java.lang.String str45 = functionType41.toDebugHashCodeString();
//        boolean boolean46 = functionType41.hasAnyTemplateInternal();
//        org.junit.Assert.assertNotNull(jSType7);
//        org.junit.Assert.assertTrue("'" + jSTypeNative15 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative15.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
//        org.junit.Assert.assertTrue("'" + jSTypeNative16 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative16.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
//        org.junit.Assert.assertTrue("'" + jSTypeNative17 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative17.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
//        org.junit.Assert.assertNotNull(jSTypeNativeArray18);
//        org.junit.Assert.assertNotNull(jSType19);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertTrue("'" + jSTypeNative25 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative25.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
//        org.junit.Assert.assertTrue("'" + jSTypeNative26 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative26.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
//        org.junit.Assert.assertTrue("'" + jSTypeNative27 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative27.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
//        org.junit.Assert.assertNotNull(jSTypeNativeArray28);
//        org.junit.Assert.assertNotNull(jSType29);
//        org.junit.Assert.assertTrue("'" + jSTypeNative33 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative33.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
//        org.junit.Assert.assertTrue("'" + jSTypeNative34 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative34.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
//        org.junit.Assert.assertTrue("'" + jSTypeNative35 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative35.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
//        org.junit.Assert.assertNotNull(jSTypeNativeArray36);
//        org.junit.Assert.assertNotNull(jSType37);
//        org.junit.Assert.assertNull(jSDocInfo38);
//        org.junit.Assert.assertNull(objectType39);
//        org.junit.Assert.assertNotNull(jSTypeArray40);
//        org.junit.Assert.assertNotNull(functionType41);
//        org.junit.Assert.assertNotNull(iterable42);
//        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 2147483647 + "'", int44 == 2147483647);
//        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "function ({279409314}, {({1801698464},{250356442})}): {491005509}" + "'", str45.equals("function ({279409314}, {({1801698464},{250356442})}): {491005509}"));
//        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
//    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, true);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative3 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative4 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative5 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray6 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative3, jSTypeNative4, jSTypeNative5 };
        com.google.javascript.rhino.jstype.JSType jSType7 = jSTypeRegistry2.createUnionType(jSTypeNativeArray6);
        jSTypeRegistry2.clearTemplateTypeNames();
        boolean boolean10 = jSTypeRegistry2.hasNamespace("Unknown class name");
        com.google.javascript.rhino.ErrorReporter errorReporter11 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry13 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter11, true);
        com.google.javascript.rhino.ErrorReporter errorReporter14 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry16 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter14, true);
        com.google.javascript.rhino.ErrorReporter errorReporter17 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry19 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter17, true);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative20 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative21 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative22 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray23 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative20, jSTypeNative21, jSTypeNative22 };
        com.google.javascript.rhino.jstype.JSType jSType24 = jSTypeRegistry19.createUnionType(jSTypeNativeArray23);
        boolean boolean25 = jSType24.isRegexpType();
        boolean boolean26 = jSType24.isNullable();
        com.google.javascript.rhino.ErrorReporter errorReporter27 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry29 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter27, true);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative30 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative31 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative32 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray33 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative30, jSTypeNative31, jSTypeNative32 };
        com.google.javascript.rhino.jstype.JSType jSType34 = jSTypeRegistry29.createUnionType(jSTypeNativeArray33);
        com.google.javascript.rhino.ErrorReporter errorReporter35 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry37 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter35, true);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative38 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative39 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative40 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray41 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative38, jSTypeNative39, jSTypeNative40 };
        com.google.javascript.rhino.jstype.JSType jSType42 = jSTypeRegistry37.createUnionType(jSTypeNativeArray41);
        com.google.javascript.rhino.JSDocInfo jSDocInfo43 = jSType42.getJSDocInfo();
        com.google.javascript.rhino.jstype.ObjectType objectType44 = jSType42.toObjectType();
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray45 = new com.google.javascript.rhino.jstype.JSType[] { jSType34, jSType42 };
        com.google.javascript.rhino.jstype.FunctionType functionType46 = jSTypeRegistry16.createConstructorTypeWithVarArgs(jSType24, jSTypeArray45);
        com.google.javascript.rhino.ErrorReporter errorReporter47 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry49 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter47, true);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative50 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative51 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative52 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray53 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative50, jSTypeNative51, jSTypeNative52 };
        com.google.javascript.rhino.jstype.JSType jSType54 = jSTypeRegistry49.createUnionType(jSTypeNativeArray53);
        boolean boolean55 = jSType54.isStringObjectType();
        com.google.javascript.rhino.jstype.ParameterizedType parameterizedType56 = jSTypeRegistry13.createParameterizedType((com.google.javascript.rhino.jstype.ObjectType) functionType46, jSType54);
        com.google.javascript.rhino.jstype.JSType jSType57 = parameterizedType56.getParameterType();
        com.google.javascript.rhino.jstype.JSType jSType58 = parameterizedType56.getIndexType();
        com.google.javascript.rhino.jstype.ObjectType objectType59 = null;
        boolean boolean60 = jSTypeRegistry2.resetImplicitPrototype((com.google.javascript.rhino.jstype.JSType) parameterizedType56, objectType59);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative61 = com.google.javascript.rhino.jstype.JSTypeNative.REGEXP_TYPE;
        try {
            com.google.javascript.rhino.jstype.FunctionType functionType62 = jSTypeRegistry2.getNativeFunctionType(jSTypeNative61);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: com.google.javascript.rhino.jstype.InstanceObjectType cannot be cast to com.google.javascript.rhino.jstype.FunctionType");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertTrue("'" + jSTypeNative3 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative3.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative4 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative4.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative5 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative5.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray6);
        org.junit.Assert.assertNotNull(jSType7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + jSTypeNative20 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative20.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative21 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative21.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative22 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative22.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray23);
        org.junit.Assert.assertNotNull(jSType24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + jSTypeNative30 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative30.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative31 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative31.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative32 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative32.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray33);
        org.junit.Assert.assertNotNull(jSType34);
        org.junit.Assert.assertTrue("'" + jSTypeNative38 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative38.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative39 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative39.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative40 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative40.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray41);
        org.junit.Assert.assertNotNull(jSType42);
        org.junit.Assert.assertNull(jSDocInfo43);
        org.junit.Assert.assertNull(objectType44);
        org.junit.Assert.assertNotNull(jSTypeArray45);
        org.junit.Assert.assertNotNull(functionType46);
        org.junit.Assert.assertTrue("'" + jSTypeNative50 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative50.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative51 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative51.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative52 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative52.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray53);
        org.junit.Assert.assertNotNull(jSType54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNotNull(parameterizedType56);
        org.junit.Assert.assertNotNull(jSType57);
        org.junit.Assert.assertNull(jSType58);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertTrue("'" + jSTypeNative61 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.REGEXP_TYPE + "'", jSTypeNative61.equals(com.google.javascript.rhino.jstype.JSTypeNative.REGEXP_TYPE));
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newNumber((double) (short) -1, (int) (byte) 1, 0);
        boolean boolean6 = node5.isArrayLit();
        boolean boolean7 = node5.isLabelName();
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.Node.newNumber((double) (short) -1, (int) (byte) 1, 0);
        boolean boolean12 = node11.isArrayLit();
        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.Node.newNumber((double) (short) -1, (int) (byte) 1, 0);
        com.google.javascript.rhino.Node node17 = new com.google.javascript.rhino.Node((int) '#', node5, node11, node16);
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.Node.newNumber(0.0d);
        com.google.javascript.rhino.Node node20 = node5.copyInformationFromForTree(node19);
        com.google.javascript.rhino.Node node21 = com.google.javascript.rhino.IR.exprResult(node19);
        com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.Node.newNumber((double) (short) -1, (int) (byte) 1, 0);
        boolean boolean26 = node25.isArrayLit();
        com.google.javascript.rhino.Node node30 = com.google.javascript.rhino.Node.newNumber((double) (short) -1, (int) (byte) 1, 0);
        com.google.javascript.rhino.Node node31 = com.google.javascript.rhino.IR.getelem(node25, node30);
        com.google.javascript.rhino.Node node32 = node31.cloneTree();
        node21.addChildrenToFront(node32);
        com.google.javascript.rhino.Node node37 = com.google.javascript.rhino.Node.newNumber((double) (short) -1, (int) (byte) 1, 0);
        int int38 = node37.getSourcePosition();
        java.lang.String str39 = closureCodingConvention0.extractClassNameIfProvide(node21, node37);
        java.lang.String str40 = closureCodingConvention0.getExportPropertyFunction();
        java.lang.String str41 = closureCodingConvention0.getAbstractMethodName();
        boolean boolean43 = closureCodingConvention0.isValidEnumKey("");
        com.google.javascript.rhino.Node node47 = com.google.javascript.rhino.Node.newNumber((double) (short) -1, (int) (byte) 1, 0);
        boolean boolean48 = node47.isArrayLit();
        com.google.javascript.rhino.Node node52 = com.google.javascript.rhino.Node.newNumber((double) (short) -1, (int) (byte) 1, 0);
        com.google.javascript.rhino.Node node53 = com.google.javascript.rhino.IR.getelem(node47, node52);
        boolean boolean54 = node52.isName();
        boolean boolean55 = node52.isEmpty();
        try {
            boolean boolean56 = closureCodingConvention0.isPropertyTestFunction(node52);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(node30);
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertNotNull(node32);
        org.junit.Assert.assertNotNull(node37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 4096 + "'", int38 == 4096);
        org.junit.Assert.assertNull(str39);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "goog.exportProperty" + "'", str40.equals("goog.exportProperty"));
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "goog.abstractMethod" + "'", str41.equals("goog.abstractMethod"));
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(node47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(node52);
        org.junit.Assert.assertNotNull(node53);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        com.google.javascript.rhino.JSDocInfo jSDocInfo0 = new com.google.javascript.rhino.JSDocInfo();
        java.lang.String str1 = jSDocInfo0.getBlockDescription();
        boolean boolean2 = jSDocInfo0.hasType();
        java.util.List<com.google.javascript.rhino.JSTypeExpression> jSTypeExpressionList3 = jSDocInfo0.getExtendedInterfaces();
        jSDocInfo0.setLicense("function ({1484049866}, {({215943824},{120125150})}): function ({667211928}, {({1273211292},{1386380896})}): {1660739335}");
        boolean boolean6 = jSDocInfo0.hasThisType();
        boolean boolean7 = jSDocInfo0.isDeprecated();
        java.util.List<com.google.javascript.rhino.JSTypeExpression> jSTypeExpressionList8 = jSDocInfo0.getImplementedInterfaces();
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(jSTypeExpressionList3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(jSTypeExpressionList8);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        com.google.javascript.rhino.Node node0 = null;
        try {
            com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.defaultCase(node0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newNumber((double) (short) -1, (int) (byte) 1, 0);
        boolean boolean4 = node3.isArrayLit();
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newNumber((double) (short) -1, (int) (byte) 1, 0);
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.IR.getelem(node3, node8);
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.Node.newNumber((double) (short) -1, (int) (byte) 1, 0);
        boolean boolean15 = node14.isArrayLit();
        boolean boolean16 = node14.isLabelName();
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.Node.newNumber((double) (short) -1, (int) (byte) 1, 0);
        boolean boolean21 = node20.isArrayLit();
        com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.Node.newNumber((double) (short) -1, (int) (byte) 1, 0);
        com.google.javascript.rhino.Node node26 = new com.google.javascript.rhino.Node((int) '#', node14, node20, node25);
        com.google.javascript.rhino.Node node28 = com.google.javascript.rhino.Node.newNumber(0.0d);
        com.google.javascript.rhino.Node node29 = node14.copyInformationFromForTree(node28);
        com.google.javascript.rhino.Node node30 = node3.copyInformationFrom(node29);
        boolean boolean31 = node3.isRegExp();
        com.google.javascript.rhino.Node node36 = com.google.javascript.rhino.Node.newNumber((double) (short) -1, (int) (byte) 1, 0);
        boolean boolean37 = node36.isArrayLit();
        boolean boolean38 = node36.isLabelName();
        com.google.javascript.rhino.Node node42 = com.google.javascript.rhino.Node.newNumber((double) (short) -1, (int) (byte) 1, 0);
        boolean boolean43 = node42.isArrayLit();
        com.google.javascript.rhino.Node node47 = com.google.javascript.rhino.Node.newNumber((double) (short) -1, (int) (byte) 1, 0);
        com.google.javascript.rhino.Node node48 = new com.google.javascript.rhino.Node((int) '#', node36, node42, node47);
        com.google.javascript.rhino.Node node50 = com.google.javascript.rhino.Node.newNumber(0.0d);
        com.google.javascript.rhino.Node node51 = node36.copyInformationFromForTree(node50);
        boolean boolean52 = node51.isAssign();
        boolean boolean53 = node51.isRegExp();
        int int54 = node3.getIndexOfChild(node51);
        com.google.javascript.rhino.Node node55 = node51.cloneNode();
        boolean boolean56 = node55.hasOneChild();
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNotNull(node30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(node36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(node42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(node47);
        org.junit.Assert.assertNotNull(node50);
        org.junit.Assert.assertNotNull(node51);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + (-1) + "'", int54 == (-1));
        org.junit.Assert.assertNotNull(node55);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        com.google.javascript.jscomp.ClosureCodingConvention.AssertInstanceofSpec assertInstanceofSpec1 = new com.google.javascript.jscomp.ClosureCodingConvention.AssertInstanceofSpec("");
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newNumber((double) (short) -1, (int) (byte) 1, 0);
        boolean boolean6 = node5.isArrayLit();
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newNumber((double) (short) -1, (int) (byte) 1, 0);
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.IR.getelem(node5, node10);
        boolean boolean12 = node11.isCatch();
        boolean boolean13 = node11.isIf();
        com.google.javascript.rhino.ErrorReporter errorReporter14 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry16 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter14, true);
        com.google.javascript.rhino.ErrorReporter errorReporter17 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry19 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter17, true);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative20 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative21 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative22 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray23 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative20, jSTypeNative21, jSTypeNative22 };
        com.google.javascript.rhino.jstype.JSType jSType24 = jSTypeRegistry19.createUnionType(jSTypeNativeArray23);
        boolean boolean25 = jSType24.isRegexpType();
        boolean boolean26 = jSType24.isNullable();
        com.google.javascript.rhino.ErrorReporter errorReporter27 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry29 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter27, true);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative30 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative31 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative32 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray33 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative30, jSTypeNative31, jSTypeNative32 };
        com.google.javascript.rhino.jstype.JSType jSType34 = jSTypeRegistry29.createUnionType(jSTypeNativeArray33);
        com.google.javascript.rhino.ErrorReporter errorReporter35 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry37 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter35, true);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative38 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative39 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative40 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray41 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative38, jSTypeNative39, jSTypeNative40 };
        com.google.javascript.rhino.jstype.JSType jSType42 = jSTypeRegistry37.createUnionType(jSTypeNativeArray41);
        com.google.javascript.rhino.JSDocInfo jSDocInfo43 = jSType42.getJSDocInfo();
        com.google.javascript.rhino.jstype.ObjectType objectType44 = jSType42.toObjectType();
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray45 = new com.google.javascript.rhino.jstype.JSType[] { jSType34, jSType42 };
        com.google.javascript.rhino.jstype.FunctionType functionType46 = jSTypeRegistry16.createConstructorTypeWithVarArgs(jSType24, jSTypeArray45);
        com.google.javascript.rhino.jstype.JSType jSType48 = jSTypeRegistry16.getType("GETELEM");
        com.google.javascript.rhino.ErrorReporter errorReporter49 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry51 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter49, true);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative52 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative53 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative54 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray55 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative52, jSTypeNative53, jSTypeNative54 };
        com.google.javascript.rhino.jstype.JSType jSType56 = jSTypeRegistry51.createUnionType(jSTypeNativeArray55);
        com.google.javascript.rhino.ErrorReporter errorReporter57 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry59 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter57, true);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative60 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative61 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative62 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray63 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative60, jSTypeNative61, jSTypeNative62 };
        com.google.javascript.rhino.jstype.JSType jSType64 = jSTypeRegistry59.createUnionType(jSTypeNativeArray63);
        boolean boolean65 = jSType64.isRegexpType();
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray66 = new com.google.javascript.rhino.jstype.JSType[] { jSType64 };
        com.google.javascript.rhino.jstype.JSType jSType67 = jSTypeRegistry51.createUnionType(jSTypeArray66);
        com.google.javascript.rhino.jstype.JSType jSType68 = jSTypeRegistry16.createUnionType(jSTypeArray66);
        com.google.javascript.rhino.jstype.JSType jSType69 = assertInstanceofSpec1.getAssertedType(node11, jSTypeRegistry16);
        com.google.javascript.rhino.Node node71 = com.google.javascript.rhino.IR.number((double) 54);
        com.google.javascript.rhino.ErrorReporter errorReporter72 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry74 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter72, true);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative75 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative76 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative77 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray78 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative75, jSTypeNative76, jSTypeNative77 };
        com.google.javascript.rhino.jstype.JSType jSType79 = jSTypeRegistry74.createUnionType(jSTypeNativeArray78);
        jSTypeRegistry74.forwardDeclareType("");
        com.google.javascript.rhino.jstype.JSType jSType82 = assertInstanceofSpec1.getAssertedType(node71, jSTypeRegistry74);
        try {
            com.google.javascript.rhino.Node node83 = com.google.javascript.rhino.IR.regexp(node71);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + jSTypeNative20 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative20.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative21 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative21.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative22 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative22.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray23);
        org.junit.Assert.assertNotNull(jSType24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + jSTypeNative30 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative30.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative31 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative31.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative32 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative32.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray33);
        org.junit.Assert.assertNotNull(jSType34);
        org.junit.Assert.assertTrue("'" + jSTypeNative38 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative38.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative39 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative39.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative40 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative40.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray41);
        org.junit.Assert.assertNotNull(jSType42);
        org.junit.Assert.assertNull(jSDocInfo43);
        org.junit.Assert.assertNull(objectType44);
        org.junit.Assert.assertNotNull(jSTypeArray45);
        org.junit.Assert.assertNotNull(functionType46);
        org.junit.Assert.assertNull(jSType48);
        org.junit.Assert.assertTrue("'" + jSTypeNative52 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative52.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative53 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative53.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative54 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative54.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray55);
        org.junit.Assert.assertNotNull(jSType56);
        org.junit.Assert.assertTrue("'" + jSTypeNative60 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative60.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative61 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative61.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative62 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative62.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray63);
        org.junit.Assert.assertNotNull(jSType64);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertNotNull(jSTypeArray66);
        org.junit.Assert.assertNotNull(jSType67);
        org.junit.Assert.assertNotNull(jSType68);
        org.junit.Assert.assertNotNull(jSType69);
        org.junit.Assert.assertNotNull(node71);
        org.junit.Assert.assertTrue("'" + jSTypeNative75 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative75.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative76 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative76.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative77 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative77.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray78);
        org.junit.Assert.assertNotNull(jSType79);
        org.junit.Assert.assertNotNull(jSType82);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newNumber(0.0d);
        com.google.javascript.rhino.Node node2 = node1.getLastChild();
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertNull(node2);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        boolean boolean2 = closureCodingConvention0.isSuperClassReference("hi!");
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.Node.newNumber((double) (short) -1, (int) (byte) 1, 0);
        boolean boolean8 = node7.isArrayLit();
        boolean boolean9 = node7.isLabelName();
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newNumber((double) (short) -1, (int) (byte) 1, 0);
        boolean boolean14 = node13.isArrayLit();
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.Node.newNumber((double) (short) -1, (int) (byte) 1, 0);
        com.google.javascript.rhino.Node node19 = new com.google.javascript.rhino.Node((int) '#', node7, node13, node18);
        com.google.javascript.rhino.jstype.StaticSourceFile staticSourceFile20 = node13.getStaticSourceFile();
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship21 = closureCodingConvention0.getDelegateRelationship(node13);
        com.google.javascript.rhino.Node node26 = com.google.javascript.rhino.Node.newNumber((double) (short) -1, (int) (byte) 1, 0);
        boolean boolean27 = node26.isArrayLit();
        boolean boolean28 = node26.isLabelName();
        com.google.javascript.rhino.Node node32 = com.google.javascript.rhino.Node.newNumber((double) (short) -1, (int) (byte) 1, 0);
        boolean boolean33 = node32.isArrayLit();
        com.google.javascript.rhino.Node node37 = com.google.javascript.rhino.Node.newNumber((double) (short) -1, (int) (byte) 1, 0);
        com.google.javascript.rhino.Node node38 = new com.google.javascript.rhino.Node((int) '#', node26, node32, node37);
        com.google.javascript.rhino.Node node40 = com.google.javascript.rhino.Node.newNumber(0.0d);
        com.google.javascript.rhino.Node node41 = node26.copyInformationFromForTree(node40);
        try {
            boolean boolean42 = closureCodingConvention0.isInlinableFunction(node40);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNull(staticSourceFile20);
        org.junit.Assert.assertNull(delegateRelationship21);
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(node32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(node37);
        org.junit.Assert.assertNotNull(node40);
        org.junit.Assert.assertNotNull(node41);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        com.google.javascript.rhino.JSDocInfo jSDocInfo0 = new com.google.javascript.rhino.JSDocInfo();
        java.lang.String str1 = jSDocInfo0.getBlockDescription();
        boolean boolean2 = jSDocInfo0.hasType();
        java.util.List<com.google.javascript.rhino.JSTypeExpression> jSTypeExpressionList3 = jSDocInfo0.getExtendedInterfaces();
        jSDocInfo0.setLicense("function ({1484049866}, {({215943824},{120125150})}): function ({667211928}, {({1273211292},{1386380896})}): {1660739335}");
        boolean boolean6 = jSDocInfo0.hasThisType();
        boolean boolean7 = jSDocInfo0.isConstant();
        java.util.Collection<com.google.javascript.rhino.Node> nodeCollection8 = jSDocInfo0.getTypeNodes();
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(jSTypeExpressionList3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(nodeCollection8);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        com.google.javascript.rhino.JSDocInfo jSDocInfo0 = new com.google.javascript.rhino.JSDocInfo();
        java.lang.String str1 = jSDocInfo0.getBlockDescription();
        boolean boolean2 = jSDocInfo0.hasType();
        java.util.List<com.google.javascript.rhino.JSTypeExpression> jSTypeExpressionList3 = jSDocInfo0.getExtendedInterfaces();
        com.google.javascript.rhino.JSDocInfo.Visibility visibility4 = com.google.javascript.rhino.JSDocInfo.Visibility.PRIVATE;
        jSDocInfo0.setVisibility(visibility4);
        boolean boolean7 = jSDocInfo0.hasDescriptionForParameter("");
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(jSTypeExpressionList3);
        org.junit.Assert.assertTrue("'" + visibility4 + "' != '" + com.google.javascript.rhino.JSDocInfo.Visibility.PRIVATE + "'", visibility4.equals(com.google.javascript.rhino.JSDocInfo.Visibility.PRIVATE));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention0 = new com.google.javascript.jscomp.GoogleCodingConvention();
        boolean boolean2 = googleCodingConvention0.isConstantKey("hi!");
        com.google.javascript.rhino.Node node3 = null;
        java.util.Map<java.lang.String, java.lang.String> strMap4 = null;
        googleCodingConvention0.checkForCallingConventionDefiningCalls(node3, strMap4);
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newNumber((double) (short) -1, (int) (byte) 1, 0);
        boolean boolean11 = node10.isArrayLit();
        boolean boolean12 = node10.isLabelName();
        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.Node.newNumber((double) (short) -1, (int) (byte) 1, 0);
        boolean boolean17 = node16.isArrayLit();
        com.google.javascript.rhino.Node node21 = com.google.javascript.rhino.Node.newNumber((double) (short) -1, (int) (byte) 1, 0);
        com.google.javascript.rhino.Node node22 = new com.google.javascript.rhino.Node((int) '#', node10, node16, node21);
        node21.removeProp((int) '#');
        com.google.javascript.jscomp.CodingConvention.Bind bind25 = googleCodingConvention0.describeFunctionBind(node21);
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention26 = new com.google.javascript.jscomp.ClosureCodingConvention();
        boolean boolean28 = closureCodingConvention26.isSuperClassReference("hi!");
        boolean boolean30 = closureCodingConvention26.isSuperClassReference("{proxy:function ({1566169663}, {({1804413486},{656799354})}): {1133890062}}");
        com.google.javascript.rhino.Node node35 = com.google.javascript.rhino.Node.newNumber((double) (short) -1, (int) (byte) 1, 0);
        boolean boolean36 = node35.isArrayLit();
        boolean boolean37 = node35.isLabelName();
        com.google.javascript.rhino.Node node41 = com.google.javascript.rhino.Node.newNumber((double) (short) -1, (int) (byte) 1, 0);
        boolean boolean42 = node41.isArrayLit();
        com.google.javascript.rhino.Node node46 = com.google.javascript.rhino.Node.newNumber((double) (short) -1, (int) (byte) 1, 0);
        com.google.javascript.rhino.Node node47 = new com.google.javascript.rhino.Node((int) '#', node35, node41, node46);
        com.google.javascript.rhino.Node node49 = com.google.javascript.rhino.Node.newNumber(0.0d);
        com.google.javascript.rhino.Node node50 = node35.copyInformationFromForTree(node49);
        boolean boolean51 = node50.isAssign();
        com.google.javascript.rhino.Node node55 = com.google.javascript.rhino.Node.newNumber((double) (short) -1, (int) (byte) 1, 0);
        node50.addChildrenToFront(node55);
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable57 = node50.siblings();
        com.google.javascript.rhino.Node node58 = com.google.javascript.rhino.IR.trueNode();
        boolean boolean59 = node58.hasOneChild();
        java.lang.String str60 = closureCodingConvention26.extractClassNameIfRequire(node50, node58);
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship61 = googleCodingConvention0.getDelegateRelationship(node58);
        com.google.javascript.rhino.Node node64 = com.google.javascript.rhino.Node.newNumber(0.0d);
        com.google.javascript.rhino.Node[] nodeArray65 = new com.google.javascript.rhino.Node[] { node64 };
        com.google.javascript.rhino.Node node68 = new com.google.javascript.rhino.Node(4, nodeArray65, 1, (int) (short) 100);
        java.util.List<java.lang.String> strList69 = googleCodingConvention0.identifyTypeDeclarationCall(node68);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertNull(bind25);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(node41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(node46);
        org.junit.Assert.assertNotNull(node49);
        org.junit.Assert.assertNotNull(node50);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertNotNull(node55);
        org.junit.Assert.assertNotNull(nodeIterable57);
        org.junit.Assert.assertNotNull(node58);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertNull(str60);
        org.junit.Assert.assertNull(delegateRelationship61);
        org.junit.Assert.assertNotNull(node64);
        org.junit.Assert.assertNotNull(nodeArray65);
        org.junit.Assert.assertNull(strList69);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        com.google.javascript.jscomp.SourceFile sourceFile3 = com.google.javascript.jscomp.SourceFile.fromCode("hi!", "Unknown class name", "Unknown class name");
        com.google.javascript.jscomp.Region region5 = sourceFile3.getRegion(2147483647);
        com.google.javascript.jscomp.CompilerInput compilerInput6 = new com.google.javascript.jscomp.CompilerInput(sourceFile3);
        com.google.javascript.rhino.InputId inputId7 = compilerInput6.getInputId();
        java.io.PrintStream printStream8 = null;
        com.google.javascript.jscomp.Compiler compiler9 = new com.google.javascript.jscomp.Compiler(printStream8);
        compilerInput6.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler9);
        com.google.javascript.jscomp.NodeTraversal.Callback callback11 = null;
        com.google.javascript.rhino.Node[] nodeArray12 = new com.google.javascript.rhino.Node[] {};
        com.google.javascript.jscomp.NodeTraversal.traverseRoots((com.google.javascript.jscomp.AbstractCompiler) compiler9, callback11, nodeArray12);
        com.google.javascript.jscomp.SourceMap sourceMap14 = compiler9.getSourceMap();
        com.google.javascript.jscomp.SourceMap sourceMap15 = compiler9.getSourceMap();
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter16 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler9);
        org.junit.Assert.assertNotNull(sourceFile3);
        org.junit.Assert.assertNull(region5);
        org.junit.Assert.assertNotNull(inputId7);
        org.junit.Assert.assertNotNull(nodeArray12);
        org.junit.Assert.assertNull(sourceMap14);
        org.junit.Assert.assertNull(sourceMap15);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        com.google.javascript.rhino.JSDocInfo.Marker marker0 = new com.google.javascript.rhino.JSDocInfo.Marker();
        com.google.javascript.rhino.JSDocInfo.StringPosition stringPosition1 = marker0.getDescription();
        com.google.javascript.rhino.JSDocInfo.StringPosition stringPosition2 = marker0.getName();
        org.junit.Assert.assertNull(stringPosition1);
        org.junit.Assert.assertNull(stringPosition2);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        com.google.javascript.rhino.Node.SideEffectFlags sideEffectFlags1 = new com.google.javascript.rhino.Node.SideEffectFlags((int) (short) 100);
        sideEffectFlags1.setMutatesArguments();
        sideEffectFlags1.clearSideEffectFlags();
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        boolean boolean2 = closureCodingConvention0.isSuperClassReference("hi!");
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention3 = new com.google.javascript.jscomp.GoogleCodingConvention((com.google.javascript.jscomp.CodingConvention) closureCodingConvention0);
        com.google.javascript.rhino.Node node4 = null;
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newNumber((double) (short) -1, (int) (byte) 1, 0);
        boolean boolean10 = node9.isArrayLit();
        boolean boolean11 = node9.isLabelName();
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.Node.newNumber((double) (short) -1, (int) (byte) 1, 0);
        boolean boolean16 = node15.isArrayLit();
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.Node.newNumber((double) (short) -1, (int) (byte) 1, 0);
        com.google.javascript.rhino.Node node21 = new com.google.javascript.rhino.Node((int) '#', node9, node15, node20);
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newNumber(0.0d);
        com.google.javascript.rhino.Node node24 = node9.copyInformationFromForTree(node23);
        boolean boolean25 = node24.isAssign();
        java.lang.String str26 = googleCodingConvention3.extractClassNameIfProvide(node4, node24);
        boolean boolean27 = node24.isNot();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNull(str26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, true);
        com.google.javascript.rhino.ErrorReporter errorReporter3 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter3, true);
        com.google.javascript.rhino.ErrorReporter errorReporter6 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry8 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter6, true);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative9 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative10 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative11 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray12 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative9, jSTypeNative10, jSTypeNative11 };
        com.google.javascript.rhino.jstype.JSType jSType13 = jSTypeRegistry8.createUnionType(jSTypeNativeArray12);
        boolean boolean14 = jSType13.isRegexpType();
        boolean boolean15 = jSType13.isNullable();
        com.google.javascript.rhino.ErrorReporter errorReporter16 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry18 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter16, true);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative19 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative20 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative21 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray22 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative19, jSTypeNative20, jSTypeNative21 };
        com.google.javascript.rhino.jstype.JSType jSType23 = jSTypeRegistry18.createUnionType(jSTypeNativeArray22);
        com.google.javascript.rhino.ErrorReporter errorReporter24 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry26 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter24, true);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative27 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative28 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative29 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray30 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative27, jSTypeNative28, jSTypeNative29 };
        com.google.javascript.rhino.jstype.JSType jSType31 = jSTypeRegistry26.createUnionType(jSTypeNativeArray30);
        com.google.javascript.rhino.JSDocInfo jSDocInfo32 = jSType31.getJSDocInfo();
        com.google.javascript.rhino.jstype.ObjectType objectType33 = jSType31.toObjectType();
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray34 = new com.google.javascript.rhino.jstype.JSType[] { jSType23, jSType31 };
        com.google.javascript.rhino.jstype.FunctionType functionType35 = jSTypeRegistry5.createConstructorTypeWithVarArgs(jSType13, jSTypeArray34);
        com.google.javascript.rhino.Node node39 = com.google.javascript.rhino.Node.newNumber((double) (short) -1, (int) (byte) 1, 0);
        boolean boolean40 = node39.isArrayLit();
        boolean boolean41 = node39.isLabelName();
        com.google.javascript.rhino.Node node42 = node39.cloneNode();
        com.google.javascript.rhino.Node node43 = com.google.javascript.rhino.IR.neg(node42);
        com.google.javascript.rhino.jstype.FunctionType functionType44 = jSTypeRegistry2.createFunctionType(jSType13, node42);
        com.google.javascript.rhino.Node node48 = com.google.javascript.rhino.Node.newNumber((double) (short) -1, (int) (byte) 1, 0);
        boolean boolean49 = node48.isArrayLit();
        com.google.javascript.rhino.jstype.StaticSourceFile staticSourceFile50 = com.google.javascript.jscomp.NodeUtil.getSourceFile(node48);
        com.google.javascript.rhino.Node node51 = com.google.javascript.rhino.IR.trueNode();
        com.google.javascript.rhino.Node node52 = com.google.javascript.rhino.IR.exprResult(node51);
        boolean boolean53 = node52.isAssign();
        int int54 = node52.getType();
        boolean boolean55 = node52.isAdd();
        try {
            node42.replaceChildAfter(node48, node52);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: prev is not a child of this node.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + jSTypeNative9 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative9.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative10 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative10.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative11 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative11.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray12);
        org.junit.Assert.assertNotNull(jSType13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + jSTypeNative19 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative19.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative20 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative20.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative21 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative21.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray22);
        org.junit.Assert.assertNotNull(jSType23);
        org.junit.Assert.assertTrue("'" + jSTypeNative27 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative27.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative28 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative28.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative29 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative29.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray30);
        org.junit.Assert.assertNotNull(jSType31);
        org.junit.Assert.assertNull(jSDocInfo32);
        org.junit.Assert.assertNull(objectType33);
        org.junit.Assert.assertNotNull(jSTypeArray34);
        org.junit.Assert.assertNotNull(functionType35);
        org.junit.Assert.assertNotNull(node39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(node42);
        org.junit.Assert.assertNotNull(node43);
        org.junit.Assert.assertNotNull(functionType44);
        org.junit.Assert.assertNotNull(node48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNull(staticSourceFile50);
        org.junit.Assert.assertNotNull(node51);
        org.junit.Assert.assertNotNull(node52);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 130 + "'", int54 == 130);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, true);
        com.google.javascript.rhino.ErrorReporter errorReporter3 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter3, true);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative6 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative7 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative8 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray9 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative6, jSTypeNative7, jSTypeNative8 };
        com.google.javascript.rhino.jstype.JSType jSType10 = jSTypeRegistry5.createUnionType(jSTypeNativeArray9);
        boolean boolean11 = jSType10.isRegexpType();
        boolean boolean12 = jSType10.isNullable();
        com.google.javascript.rhino.ErrorReporter errorReporter13 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry15 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter13, true);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative16 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative17 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative18 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray19 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative16, jSTypeNative17, jSTypeNative18 };
        com.google.javascript.rhino.jstype.JSType jSType20 = jSTypeRegistry15.createUnionType(jSTypeNativeArray19);
        com.google.javascript.rhino.ErrorReporter errorReporter21 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry23 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter21, true);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative24 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative25 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative26 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray27 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative24, jSTypeNative25, jSTypeNative26 };
        com.google.javascript.rhino.jstype.JSType jSType28 = jSTypeRegistry23.createUnionType(jSTypeNativeArray27);
        com.google.javascript.rhino.JSDocInfo jSDocInfo29 = jSType28.getJSDocInfo();
        com.google.javascript.rhino.jstype.ObjectType objectType30 = jSType28.toObjectType();
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray31 = new com.google.javascript.rhino.jstype.JSType[] { jSType20, jSType28 };
        com.google.javascript.rhino.jstype.FunctionType functionType32 = jSTypeRegistry2.createConstructorTypeWithVarArgs(jSType10, jSTypeArray31);
        boolean boolean33 = functionType32.isConstructor();
        java.lang.String str34 = functionType32.toAnnotationString();
        com.google.javascript.rhino.Node node39 = com.google.javascript.rhino.Node.newNumber((double) (short) -1, (int) (byte) 1, 0);
        boolean boolean40 = node39.isArrayLit();
        boolean boolean41 = node39.isLabelName();
        com.google.javascript.rhino.Node node45 = com.google.javascript.rhino.Node.newNumber((double) (short) -1, (int) (byte) 1, 0);
        boolean boolean46 = node45.isArrayLit();
        com.google.javascript.rhino.Node node50 = com.google.javascript.rhino.Node.newNumber((double) (short) -1, (int) (byte) 1, 0);
        com.google.javascript.rhino.Node node51 = new com.google.javascript.rhino.Node((int) '#', node39, node45, node50);
        com.google.javascript.rhino.Node node53 = com.google.javascript.rhino.Node.newNumber(0.0d);
        com.google.javascript.rhino.Node node54 = node39.copyInformationFromForTree(node53);
        boolean boolean55 = node54.isAssign();
        functionType32.setSource(node54);
        boolean boolean57 = node54.isDefaultCase();
        org.junit.Assert.assertTrue("'" + jSTypeNative6 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative6.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative7 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative7.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative8 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative8.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray9);
        org.junit.Assert.assertNotNull(jSType10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + jSTypeNative16 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative16.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative17 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative17.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative18 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative18.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray19);
        org.junit.Assert.assertNotNull(jSType20);
        org.junit.Assert.assertTrue("'" + jSTypeNative24 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative24.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative25 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative25.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative26 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative26.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray27);
        org.junit.Assert.assertNotNull(jSType28);
        org.junit.Assert.assertNull(jSDocInfo29);
        org.junit.Assert.assertNull(objectType30);
        org.junit.Assert.assertNotNull(jSTypeArray31);
        org.junit.Assert.assertNotNull(functionType32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "function (new:?, boolean, ...[boolean]): boolean" + "'", str34.equals("function (new:?, boolean, ...[boolean]): boolean"));
        org.junit.Assert.assertNotNull(node39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(node45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(node50);
        org.junit.Assert.assertNotNull(node53);
        org.junit.Assert.assertNotNull(node54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, true);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative3 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative4 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative5 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray6 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative3, jSTypeNative4, jSTypeNative5 };
        com.google.javascript.rhino.jstype.JSType jSType7 = jSTypeRegistry2.createUnionType(jSTypeNativeArray6);
        jSTypeRegistry2.forwardDeclareType("");
        com.google.javascript.rhino.ErrorReporter errorReporter10 = jSTypeRegistry2.getErrorReporter();
        org.junit.Assert.assertTrue("'" + jSTypeNative3 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative3.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative4 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative4.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative5 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative5.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray6);
        org.junit.Assert.assertNotNull(jSType7);
        org.junit.Assert.assertNull(errorReporter10);
    }

//    @Test
//    public void test138() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test138");
//        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.CHECK_VARIABLES;
//        com.google.javascript.jscomp.DiagnosticGroups.DEPRECATED = diagnosticGroup0;
//        com.google.javascript.jscomp.DiagnosticGroups.DEBUGGER_STATEMENT_PRESENT = diagnosticGroup0;
//        com.google.javascript.jscomp.DiagnosticGroups.FILEOVERVIEW_JSDOC = diagnosticGroup0;
//        org.junit.Assert.assertNull(diagnosticGroup0);
//    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        com.google.javascript.jscomp.DiagnosticType diagnosticType0 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention1 = new com.google.javascript.jscomp.GoogleCodingConvention();
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention2 = new com.google.javascript.jscomp.GoogleCodingConvention((com.google.javascript.jscomp.CodingConvention) googleCodingConvention1);
        boolean boolean3 = diagnosticType0.equals((java.lang.Object) googleCodingConvention2);
        boolean boolean5 = googleCodingConvention2.isPrivate("GETELEM");
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newNumber((double) (short) -1, (int) (byte) 1, 0);
        boolean boolean10 = node9.isArrayLit();
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.Node.newNumber((double) (short) -1, (int) (byte) 1, 0);
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.IR.getelem(node9, node14);
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.Node.newNumber((double) (short) -1, (int) (byte) 1, 0);
        boolean boolean21 = node20.isArrayLit();
        boolean boolean22 = node20.isLabelName();
        com.google.javascript.rhino.Node node26 = com.google.javascript.rhino.Node.newNumber((double) (short) -1, (int) (byte) 1, 0);
        boolean boolean27 = node26.isArrayLit();
        com.google.javascript.rhino.Node node31 = com.google.javascript.rhino.Node.newNumber((double) (short) -1, (int) (byte) 1, 0);
        com.google.javascript.rhino.Node node32 = new com.google.javascript.rhino.Node((int) '#', node20, node26, node31);
        com.google.javascript.rhino.Node node34 = com.google.javascript.rhino.Node.newNumber(0.0d);
        com.google.javascript.rhino.Node node35 = node20.copyInformationFromForTree(node34);
        com.google.javascript.rhino.Node node36 = node9.copyInformationFrom(node35);
        com.google.javascript.rhino.Node node38 = com.google.javascript.rhino.IR.stringKey("");
        boolean boolean39 = node35.isEquivalentToTyped(node38);
        boolean boolean40 = googleCodingConvention2.isVarArgsParameter(node38);
        org.junit.Assert.assertNotNull(diagnosticType0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertNotNull(node34);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertNotNull(node36);
        org.junit.Assert.assertNotNull(node38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, true);
        com.google.javascript.rhino.ErrorReporter errorReporter3 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter3, true);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative6 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative7 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative8 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray9 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative6, jSTypeNative7, jSTypeNative8 };
        com.google.javascript.rhino.jstype.JSType jSType10 = jSTypeRegistry5.createUnionType(jSTypeNativeArray9);
        boolean boolean11 = jSType10.isRegexpType();
        boolean boolean12 = jSType10.isNullable();
        com.google.javascript.rhino.ErrorReporter errorReporter13 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry15 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter13, true);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative16 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative17 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative18 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray19 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative16, jSTypeNative17, jSTypeNative18 };
        com.google.javascript.rhino.jstype.JSType jSType20 = jSTypeRegistry15.createUnionType(jSTypeNativeArray19);
        com.google.javascript.rhino.ErrorReporter errorReporter21 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry23 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter21, true);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative24 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative25 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative26 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray27 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative24, jSTypeNative25, jSTypeNative26 };
        com.google.javascript.rhino.jstype.JSType jSType28 = jSTypeRegistry23.createUnionType(jSTypeNativeArray27);
        com.google.javascript.rhino.JSDocInfo jSDocInfo29 = jSType28.getJSDocInfo();
        com.google.javascript.rhino.jstype.ObjectType objectType30 = jSType28.toObjectType();
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray31 = new com.google.javascript.rhino.jstype.JSType[] { jSType20, jSType28 };
        com.google.javascript.rhino.jstype.FunctionType functionType32 = jSTypeRegistry2.createConstructorTypeWithVarArgs(jSType10, jSTypeArray31);
        boolean boolean33 = jSType10.isUnionType();
        com.google.javascript.rhino.jstype.JSType jSType34 = jSType10.collapseUnion();
        boolean boolean35 = jSType10.isNullable();
        org.junit.Assert.assertTrue("'" + jSTypeNative6 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative6.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative7 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative7.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative8 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative8.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray9);
        org.junit.Assert.assertNotNull(jSType10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + jSTypeNative16 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative16.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative17 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative17.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative18 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative18.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray19);
        org.junit.Assert.assertNotNull(jSType20);
        org.junit.Assert.assertTrue("'" + jSTypeNative24 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative24.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative25 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative25.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative26 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative26.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray27);
        org.junit.Assert.assertNotNull(jSType28);
        org.junit.Assert.assertNull(jSDocInfo29);
        org.junit.Assert.assertNull(objectType30);
        org.junit.Assert.assertNotNull(jSTypeArray31);
        org.junit.Assert.assertNotNull(functionType32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(jSType34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        com.google.javascript.rhino.JSDocInfo.NamePosition namePosition0 = new com.google.javascript.rhino.JSDocInfo.NamePosition();
        int int1 = namePosition0.getEndLine();
        int int2 = namePosition0.getPositionOnEndLine();
        int int3 = namePosition0.getEndLine();
        namePosition0.setPositionInformation(4, 41, 100, 0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, true);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative3 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative4 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative5 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray6 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative3, jSTypeNative4, jSTypeNative5 };
        com.google.javascript.rhino.jstype.JSType jSType7 = jSTypeRegistry2.createUnionType(jSTypeNativeArray6);
        com.google.javascript.rhino.ErrorReporter errorReporter8 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry10 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter8, true);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative11 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative12 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative13 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray14 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative11, jSTypeNative12, jSTypeNative13 };
        com.google.javascript.rhino.jstype.JSType jSType15 = jSTypeRegistry10.createUnionType(jSTypeNativeArray14);
        boolean boolean16 = jSType15.isRegexpType();
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray17 = new com.google.javascript.rhino.jstype.JSType[] { jSType15 };
        com.google.javascript.rhino.jstype.JSType jSType18 = jSTypeRegistry2.createUnionType(jSTypeArray17);
        com.google.javascript.rhino.jstype.JSType jSType19 = null;
        boolean boolean21 = jSTypeRegistry2.canPropertyBeDefined(jSType19, "NUMBER -1.0 1");
        org.junit.Assert.assertTrue("'" + jSTypeNative3 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative3.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative4 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative4.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative5 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative5.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray6);
        org.junit.Assert.assertNotNull(jSType7);
        org.junit.Assert.assertTrue("'" + jSTypeNative11 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative11.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative12 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative12.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative13 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative13.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray14);
        org.junit.Assert.assertNotNull(jSType15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(jSTypeArray17);
        org.junit.Assert.assertNotNull(jSType18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.Node.newString(10, "hi!");
        boolean boolean3 = node2.isFor();
        boolean boolean4 = node2.isComma();
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        com.google.javascript.jscomp.ClosureCodingConvention.AssertInstanceofSpec assertInstanceofSpec1 = new com.google.javascript.jscomp.ClosureCodingConvention.AssertInstanceofSpec("");
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newNumber((double) (short) -1, (int) (byte) 1, 0);
        boolean boolean6 = node5.isArrayLit();
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newNumber((double) (short) -1, (int) (byte) 1, 0);
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.IR.getelem(node5, node10);
        boolean boolean12 = node11.isCatch();
        boolean boolean13 = node11.isIf();
        com.google.javascript.rhino.ErrorReporter errorReporter14 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry16 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter14, true);
        com.google.javascript.rhino.ErrorReporter errorReporter17 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry19 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter17, true);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative20 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative21 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative22 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray23 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative20, jSTypeNative21, jSTypeNative22 };
        com.google.javascript.rhino.jstype.JSType jSType24 = jSTypeRegistry19.createUnionType(jSTypeNativeArray23);
        boolean boolean25 = jSType24.isRegexpType();
        boolean boolean26 = jSType24.isNullable();
        com.google.javascript.rhino.ErrorReporter errorReporter27 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry29 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter27, true);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative30 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative31 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative32 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray33 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative30, jSTypeNative31, jSTypeNative32 };
        com.google.javascript.rhino.jstype.JSType jSType34 = jSTypeRegistry29.createUnionType(jSTypeNativeArray33);
        com.google.javascript.rhino.ErrorReporter errorReporter35 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry37 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter35, true);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative38 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative39 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative40 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray41 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative38, jSTypeNative39, jSTypeNative40 };
        com.google.javascript.rhino.jstype.JSType jSType42 = jSTypeRegistry37.createUnionType(jSTypeNativeArray41);
        com.google.javascript.rhino.JSDocInfo jSDocInfo43 = jSType42.getJSDocInfo();
        com.google.javascript.rhino.jstype.ObjectType objectType44 = jSType42.toObjectType();
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray45 = new com.google.javascript.rhino.jstype.JSType[] { jSType34, jSType42 };
        com.google.javascript.rhino.jstype.FunctionType functionType46 = jSTypeRegistry16.createConstructorTypeWithVarArgs(jSType24, jSTypeArray45);
        com.google.javascript.rhino.jstype.JSType jSType48 = jSTypeRegistry16.getType("GETELEM");
        com.google.javascript.rhino.ErrorReporter errorReporter49 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry51 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter49, true);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative52 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative53 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative54 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray55 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative52, jSTypeNative53, jSTypeNative54 };
        com.google.javascript.rhino.jstype.JSType jSType56 = jSTypeRegistry51.createUnionType(jSTypeNativeArray55);
        com.google.javascript.rhino.ErrorReporter errorReporter57 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry59 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter57, true);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative60 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative61 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative62 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray63 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative60, jSTypeNative61, jSTypeNative62 };
        com.google.javascript.rhino.jstype.JSType jSType64 = jSTypeRegistry59.createUnionType(jSTypeNativeArray63);
        boolean boolean65 = jSType64.isRegexpType();
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray66 = new com.google.javascript.rhino.jstype.JSType[] { jSType64 };
        com.google.javascript.rhino.jstype.JSType jSType67 = jSTypeRegistry51.createUnionType(jSTypeArray66);
        com.google.javascript.rhino.jstype.JSType jSType68 = jSTypeRegistry16.createUnionType(jSTypeArray66);
        com.google.javascript.rhino.jstype.JSType jSType69 = assertInstanceofSpec1.getAssertedType(node11, jSTypeRegistry16);
        com.google.javascript.rhino.Node node71 = com.google.javascript.rhino.IR.number((double) 54);
        com.google.javascript.rhino.ErrorReporter errorReporter72 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry74 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter72, true);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative75 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative76 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative77 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray78 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative75, jSTypeNative76, jSTypeNative77 };
        com.google.javascript.rhino.jstype.JSType jSType79 = jSTypeRegistry74.createUnionType(jSTypeNativeArray78);
        jSTypeRegistry74.forwardDeclareType("");
        com.google.javascript.rhino.jstype.JSType jSType82 = assertInstanceofSpec1.getAssertedType(node71, jSTypeRegistry74);
        com.google.javascript.rhino.JSDocInfo jSDocInfo83 = new com.google.javascript.rhino.JSDocInfo();
        boolean boolean84 = jSDocInfo83.isDeprecated();
        node71.setJSDocInfo(jSDocInfo83);
        java.util.List<com.google.javascript.rhino.JSTypeExpression> jSTypeExpressionList86 = jSDocInfo83.getThrownTypes();
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + jSTypeNative20 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative20.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative21 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative21.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative22 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative22.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray23);
        org.junit.Assert.assertNotNull(jSType24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + jSTypeNative30 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative30.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative31 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative31.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative32 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative32.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray33);
        org.junit.Assert.assertNotNull(jSType34);
        org.junit.Assert.assertTrue("'" + jSTypeNative38 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative38.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative39 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative39.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative40 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative40.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray41);
        org.junit.Assert.assertNotNull(jSType42);
        org.junit.Assert.assertNull(jSDocInfo43);
        org.junit.Assert.assertNull(objectType44);
        org.junit.Assert.assertNotNull(jSTypeArray45);
        org.junit.Assert.assertNotNull(functionType46);
        org.junit.Assert.assertNull(jSType48);
        org.junit.Assert.assertTrue("'" + jSTypeNative52 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative52.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative53 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative53.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative54 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative54.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray55);
        org.junit.Assert.assertNotNull(jSType56);
        org.junit.Assert.assertTrue("'" + jSTypeNative60 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative60.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative61 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative61.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative62 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative62.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray63);
        org.junit.Assert.assertNotNull(jSType64);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertNotNull(jSTypeArray66);
        org.junit.Assert.assertNotNull(jSType67);
        org.junit.Assert.assertNotNull(jSType68);
        org.junit.Assert.assertNotNull(jSType69);
        org.junit.Assert.assertNotNull(node71);
        org.junit.Assert.assertTrue("'" + jSTypeNative75 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative75.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative76 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative76.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative77 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative77.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray78);
        org.junit.Assert.assertNotNull(jSType79);
        org.junit.Assert.assertNotNull(jSType82);
        org.junit.Assert.assertTrue("'" + boolean84 + "' != '" + false + "'", boolean84 == false);
        org.junit.Assert.assertNotNull(jSTypeExpressionList86);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        com.google.javascript.rhino.JSDocInfo jSDocInfo0 = new com.google.javascript.rhino.JSDocInfo();
        boolean boolean1 = jSDocInfo0.hasModifies();
        java.lang.String str2 = jSDocInfo0.getDescription();
        boolean boolean3 = jSDocInfo0.isHidden();
        boolean boolean4 = jSDocInfo0.shouldPreserveTry();
        boolean boolean5 = jSDocInfo0.isConstant();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        com.google.javascript.jscomp.JSModule jSModule3 = new com.google.javascript.jscomp.JSModule("hi!");
        java.util.List<java.lang.String> strList4 = jSModule3.getProvides();
        com.google.javascript.jscomp.JSModule jSModule6 = new com.google.javascript.jscomp.JSModule("hi!");
        java.util.List<java.lang.String> strList7 = jSModule6.getProvides();
        com.google.javascript.jscomp.deps.SimpleDependencyInfo simpleDependencyInfo8 = new com.google.javascript.jscomp.deps.SimpleDependencyInfo("", "GETELEM", strList4, strList7);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative9 = com.google.javascript.rhino.jstype.JSTypeNative.NO_OBJECT_TYPE;
        boolean boolean10 = simpleDependencyInfo8.equals((java.lang.Object) jSTypeNative9);
        java.lang.String str11 = simpleDependencyInfo8.toString();
        java.lang.String str12 = simpleDependencyInfo8.getName();
        org.junit.Assert.assertNotNull(strList4);
        org.junit.Assert.assertNotNull(strList7);
        org.junit.Assert.assertTrue("'" + jSTypeNative9 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.NO_OBJECT_TYPE + "'", jSTypeNative9.equals(com.google.javascript.rhino.jstype.JSTypeNative.NO_OBJECT_TYPE));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "DependencyInfo(relativePath='', path='GETELEM', provides=[hi!], requires=[hi!])" + "'", str11.equals("DependencyInfo(relativePath='', path='GETELEM', provides=[hi!], requires=[hi!])"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "GETELEM" + "'", str12.equals("GETELEM"));
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, true);
        com.google.javascript.rhino.jstype.JSType jSType7 = jSTypeRegistry2.createNamedType("GETELEM", "hi!", 0, 38);
        jSTypeRegistry2.incrementGeneration();
        com.google.javascript.rhino.ErrorReporter errorReporter9 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry11 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter9, true);
        com.google.javascript.rhino.ErrorReporter errorReporter12 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry14 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter12, true);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative15 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative16 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative17 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray18 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative15, jSTypeNative16, jSTypeNative17 };
        com.google.javascript.rhino.jstype.JSType jSType19 = jSTypeRegistry14.createUnionType(jSTypeNativeArray18);
        boolean boolean20 = jSType19.isRegexpType();
        boolean boolean21 = jSType19.isNullable();
        com.google.javascript.rhino.ErrorReporter errorReporter22 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry24 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter22, true);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative25 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative26 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative27 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray28 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative25, jSTypeNative26, jSTypeNative27 };
        com.google.javascript.rhino.jstype.JSType jSType29 = jSTypeRegistry24.createUnionType(jSTypeNativeArray28);
        com.google.javascript.rhino.ErrorReporter errorReporter30 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry32 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter30, true);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative33 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative34 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative35 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray36 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative33, jSTypeNative34, jSTypeNative35 };
        com.google.javascript.rhino.jstype.JSType jSType37 = jSTypeRegistry32.createUnionType(jSTypeNativeArray36);
        com.google.javascript.rhino.JSDocInfo jSDocInfo38 = jSType37.getJSDocInfo();
        com.google.javascript.rhino.jstype.ObjectType objectType39 = jSType37.toObjectType();
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray40 = new com.google.javascript.rhino.jstype.JSType[] { jSType29, jSType37 };
        com.google.javascript.rhino.jstype.FunctionType functionType41 = jSTypeRegistry11.createConstructorTypeWithVarArgs(jSType19, jSTypeArray40);
        java.lang.Iterable iterable42 = functionType41.getCtorImplementedInterfaces();
        jSTypeRegistry2.resolveTypesInScope((com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType>) functionType41);
        int int44 = functionType41.getMaxArguments();
        boolean boolean45 = functionType41.isObject();
        com.google.javascript.rhino.jstype.JSType jSType46 = functionType41.getReturnType();
        org.junit.Assert.assertNotNull(jSType7);
        org.junit.Assert.assertTrue("'" + jSTypeNative15 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative15.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative16 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative16.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative17 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative17.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray18);
        org.junit.Assert.assertNotNull(jSType19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + jSTypeNative25 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative25.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative26 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative26.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative27 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative27.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray28);
        org.junit.Assert.assertNotNull(jSType29);
        org.junit.Assert.assertTrue("'" + jSTypeNative33 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative33.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative34 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative34.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative35 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative35.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray36);
        org.junit.Assert.assertNotNull(jSType37);
        org.junit.Assert.assertNull(jSDocInfo38);
        org.junit.Assert.assertNull(objectType39);
        org.junit.Assert.assertNotNull(jSTypeArray40);
        org.junit.Assert.assertNotNull(functionType41);
        org.junit.Assert.assertNotNull(iterable42);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 2147483647 + "'", int44 == 2147483647);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
        org.junit.Assert.assertNotNull(jSType46);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, true);
        com.google.javascript.rhino.ErrorReporter errorReporter3 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter3, true);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative6 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative7 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative8 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray9 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative6, jSTypeNative7, jSTypeNative8 };
        com.google.javascript.rhino.jstype.JSType jSType10 = jSTypeRegistry5.createUnionType(jSTypeNativeArray9);
        boolean boolean11 = jSType10.isRegexpType();
        boolean boolean12 = jSType10.isNullable();
        com.google.javascript.rhino.ErrorReporter errorReporter13 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry15 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter13, true);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative16 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative17 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative18 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray19 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative16, jSTypeNative17, jSTypeNative18 };
        com.google.javascript.rhino.jstype.JSType jSType20 = jSTypeRegistry15.createUnionType(jSTypeNativeArray19);
        com.google.javascript.rhino.ErrorReporter errorReporter21 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry23 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter21, true);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative24 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative25 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative26 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray27 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative24, jSTypeNative25, jSTypeNative26 };
        com.google.javascript.rhino.jstype.JSType jSType28 = jSTypeRegistry23.createUnionType(jSTypeNativeArray27);
        com.google.javascript.rhino.JSDocInfo jSDocInfo29 = jSType28.getJSDocInfo();
        com.google.javascript.rhino.jstype.ObjectType objectType30 = jSType28.toObjectType();
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray31 = new com.google.javascript.rhino.jstype.JSType[] { jSType20, jSType28 };
        com.google.javascript.rhino.jstype.FunctionType functionType32 = jSTypeRegistry2.createConstructorTypeWithVarArgs(jSType10, jSTypeArray31);
        jSTypeRegistry2.identifyNonNullableName("boolean");
        jSTypeRegistry2.setLastGeneration(false);
        org.junit.Assert.assertTrue("'" + jSTypeNative6 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative6.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative7 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative7.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative8 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative8.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray9);
        org.junit.Assert.assertNotNull(jSType10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + jSTypeNative16 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative16.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative17 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative17.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative18 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative18.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray19);
        org.junit.Assert.assertNotNull(jSType20);
        org.junit.Assert.assertTrue("'" + jSTypeNative24 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative24.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative25 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative25.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative26 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative26.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray27);
        org.junit.Assert.assertNotNull(jSType28);
        org.junit.Assert.assertNull(jSDocInfo29);
        org.junit.Assert.assertNull(objectType30);
        org.junit.Assert.assertNotNull(jSTypeArray31);
        org.junit.Assert.assertNotNull(functionType32);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        com.google.javascript.jscomp.DiagnosticType diagnosticType0 = com.google.javascript.jscomp.Compiler.MOTION_ITERATIONS_ERROR;
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup1 = com.google.javascript.jscomp.DiagnosticGroup.forType(diagnosticType0);
        com.google.javascript.jscomp.DiagnosticGroups.EXTERNS_VALIDATION = diagnosticGroup1;
        org.junit.Assert.assertNotNull(diagnosticType0);
        org.junit.Assert.assertNotNull(diagnosticGroup1);
    }

//    @Test
//    public void test150() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test150");
//        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, true);
//        com.google.javascript.rhino.jstype.JSType jSType7 = jSTypeRegistry2.createNamedType("GETELEM", "hi!", 0, 38);
//        jSTypeRegistry2.incrementGeneration();
//        com.google.javascript.rhino.ErrorReporter errorReporter9 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry11 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter9, true);
//        com.google.javascript.rhino.ErrorReporter errorReporter12 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry14 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter12, true);
//        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative15 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
//        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative16 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
//        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative17 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
//        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray18 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative15, jSTypeNative16, jSTypeNative17 };
//        com.google.javascript.rhino.jstype.JSType jSType19 = jSTypeRegistry14.createUnionType(jSTypeNativeArray18);
//        boolean boolean20 = jSType19.isRegexpType();
//        boolean boolean21 = jSType19.isNullable();
//        com.google.javascript.rhino.ErrorReporter errorReporter22 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry24 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter22, true);
//        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative25 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
//        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative26 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
//        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative27 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
//        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray28 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative25, jSTypeNative26, jSTypeNative27 };
//        com.google.javascript.rhino.jstype.JSType jSType29 = jSTypeRegistry24.createUnionType(jSTypeNativeArray28);
//        com.google.javascript.rhino.ErrorReporter errorReporter30 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry32 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter30, true);
//        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative33 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
//        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative34 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
//        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative35 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
//        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray36 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative33, jSTypeNative34, jSTypeNative35 };
//        com.google.javascript.rhino.jstype.JSType jSType37 = jSTypeRegistry32.createUnionType(jSTypeNativeArray36);
//        com.google.javascript.rhino.JSDocInfo jSDocInfo38 = jSType37.getJSDocInfo();
//        com.google.javascript.rhino.jstype.ObjectType objectType39 = jSType37.toObjectType();
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray40 = new com.google.javascript.rhino.jstype.JSType[] { jSType29, jSType37 };
//        com.google.javascript.rhino.jstype.FunctionType functionType41 = jSTypeRegistry11.createConstructorTypeWithVarArgs(jSType19, jSTypeArray40);
//        java.lang.Iterable iterable42 = functionType41.getCtorImplementedInterfaces();
//        jSTypeRegistry2.resolveTypesInScope((com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType>) functionType41);
//        int int44 = functionType41.getMaxArguments();
//        java.lang.String str45 = functionType41.toDebugHashCodeString();
//        boolean boolean47 = functionType41.removeProperty("function (new:?, boolean, ...[boolean]): boolean");
//        com.google.javascript.rhino.jstype.FunctionType functionType48 = functionType41.toMaybeFunctionType();
//        java.lang.String str49 = functionType41.toDebugHashCodeString();
//        org.junit.Assert.assertNotNull(jSType7);
//        org.junit.Assert.assertTrue("'" + jSTypeNative15 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative15.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
//        org.junit.Assert.assertTrue("'" + jSTypeNative16 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative16.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
//        org.junit.Assert.assertTrue("'" + jSTypeNative17 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative17.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
//        org.junit.Assert.assertNotNull(jSTypeNativeArray18);
//        org.junit.Assert.assertNotNull(jSType19);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertTrue("'" + jSTypeNative25 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative25.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
//        org.junit.Assert.assertTrue("'" + jSTypeNative26 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative26.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
//        org.junit.Assert.assertTrue("'" + jSTypeNative27 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative27.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
//        org.junit.Assert.assertNotNull(jSTypeNativeArray28);
//        org.junit.Assert.assertNotNull(jSType29);
//        org.junit.Assert.assertTrue("'" + jSTypeNative33 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative33.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
//        org.junit.Assert.assertTrue("'" + jSTypeNative34 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative34.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
//        org.junit.Assert.assertTrue("'" + jSTypeNative35 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative35.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
//        org.junit.Assert.assertNotNull(jSTypeNativeArray36);
//        org.junit.Assert.assertNotNull(jSType37);
//        org.junit.Assert.assertNull(jSDocInfo38);
//        org.junit.Assert.assertNull(objectType39);
//        org.junit.Assert.assertNotNull(jSTypeArray40);
//        org.junit.Assert.assertNotNull(functionType41);
//        org.junit.Assert.assertNotNull(iterable42);
//        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 2147483647 + "'", int44 == 2147483647);
//        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "function ({419073557}, {({1331019649},{1959849755})}): {1183832447}" + "'", str45.equals("function ({419073557}, {({1331019649},{1959849755})}): {1183832447}"));
//        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
//        org.junit.Assert.assertNotNull(functionType48);
//        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "function ({419073557}, {({1331019649},{1959849755})}): {1183832447}" + "'", str49.equals("function ({419073557}, {({1331019649},{1959849755})}): {1183832447}"));
//    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        int int0 = com.google.javascript.rhino.Node.STATIC_SOURCE_FILE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 51 + "'", int0 == 51);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        com.google.javascript.rhino.JSDocInfo.NamePosition namePosition0 = new com.google.javascript.rhino.JSDocInfo.NamePosition();
        int int1 = namePosition0.getEndLine();
        int int2 = namePosition0.getPositionOnEndLine();
        int int3 = namePosition0.getPositionOnEndLine();
        com.google.javascript.rhino.Node node4 = namePosition0.getItem();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNull(node4);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, true);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative3 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative4 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative5 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray6 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative3, jSTypeNative4, jSTypeNative5 };
        com.google.javascript.rhino.jstype.JSType jSType7 = jSTypeRegistry2.createUnionType(jSTypeNativeArray6);
        jSTypeRegistry2.clearTemplateTypeNames();
        com.google.javascript.rhino.ErrorReporter errorReporter9 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry11 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter9, true);
        com.google.javascript.rhino.ErrorReporter errorReporter12 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry14 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter12, true);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative15 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative16 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative17 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray18 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative15, jSTypeNative16, jSTypeNative17 };
        com.google.javascript.rhino.jstype.JSType jSType19 = jSTypeRegistry14.createUnionType(jSTypeNativeArray18);
        boolean boolean20 = jSType19.isRegexpType();
        boolean boolean21 = jSType19.isNullable();
        com.google.javascript.rhino.ErrorReporter errorReporter22 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry24 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter22, true);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative25 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative26 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative27 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray28 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative25, jSTypeNative26, jSTypeNative27 };
        com.google.javascript.rhino.jstype.JSType jSType29 = jSTypeRegistry24.createUnionType(jSTypeNativeArray28);
        com.google.javascript.rhino.ErrorReporter errorReporter30 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry32 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter30, true);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative33 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative34 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative35 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray36 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative33, jSTypeNative34, jSTypeNative35 };
        com.google.javascript.rhino.jstype.JSType jSType37 = jSTypeRegistry32.createUnionType(jSTypeNativeArray36);
        com.google.javascript.rhino.JSDocInfo jSDocInfo38 = jSType37.getJSDocInfo();
        com.google.javascript.rhino.jstype.ObjectType objectType39 = jSType37.toObjectType();
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray40 = new com.google.javascript.rhino.jstype.JSType[] { jSType29, jSType37 };
        com.google.javascript.rhino.jstype.FunctionType functionType41 = jSTypeRegistry11.createConstructorTypeWithVarArgs(jSType19, jSTypeArray40);
        java.lang.Iterable iterable42 = functionType41.getCtorImplementedInterfaces();
        com.google.javascript.rhino.Node node43 = functionType41.getSource();
        com.google.javascript.rhino.ErrorReporter errorReporter45 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry47 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter45, true);
        com.google.javascript.rhino.ErrorReporter errorReporter48 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry50 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter48, true);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative51 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative52 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative53 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray54 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative51, jSTypeNative52, jSTypeNative53 };
        com.google.javascript.rhino.jstype.JSType jSType55 = jSTypeRegistry50.createUnionType(jSTypeNativeArray54);
        boolean boolean56 = jSType55.isRegexpType();
        boolean boolean57 = jSType55.isNullable();
        com.google.javascript.rhino.ErrorReporter errorReporter58 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry60 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter58, true);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative61 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative62 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative63 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray64 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative61, jSTypeNative62, jSTypeNative63 };
        com.google.javascript.rhino.jstype.JSType jSType65 = jSTypeRegistry60.createUnionType(jSTypeNativeArray64);
        com.google.javascript.rhino.ErrorReporter errorReporter66 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry68 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter66, true);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative69 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative70 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative71 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray72 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative69, jSTypeNative70, jSTypeNative71 };
        com.google.javascript.rhino.jstype.JSType jSType73 = jSTypeRegistry68.createUnionType(jSTypeNativeArray72);
        com.google.javascript.rhino.JSDocInfo jSDocInfo74 = jSType73.getJSDocInfo();
        com.google.javascript.rhino.jstype.ObjectType objectType75 = jSType73.toObjectType();
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray76 = new com.google.javascript.rhino.jstype.JSType[] { jSType65, jSType73 };
        com.google.javascript.rhino.jstype.FunctionType functionType77 = jSTypeRegistry47.createConstructorTypeWithVarArgs(jSType55, jSTypeArray76);
        com.google.javascript.rhino.jstype.FunctionType functionType78 = jSTypeRegistry2.createFunctionType((com.google.javascript.rhino.jstype.JSType) functionType41, true, jSTypeArray76);
        boolean boolean79 = functionType41.matchesObjectContext();
        org.junit.Assert.assertTrue("'" + jSTypeNative3 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative3.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative4 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative4.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative5 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative5.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray6);
        org.junit.Assert.assertNotNull(jSType7);
        org.junit.Assert.assertTrue("'" + jSTypeNative15 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative15.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative16 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative16.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative17 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative17.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray18);
        org.junit.Assert.assertNotNull(jSType19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + jSTypeNative25 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative25.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative26 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative26.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative27 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative27.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray28);
        org.junit.Assert.assertNotNull(jSType29);
        org.junit.Assert.assertTrue("'" + jSTypeNative33 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative33.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative34 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative34.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative35 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative35.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray36);
        org.junit.Assert.assertNotNull(jSType37);
        org.junit.Assert.assertNull(jSDocInfo38);
        org.junit.Assert.assertNull(objectType39);
        org.junit.Assert.assertNotNull(jSTypeArray40);
        org.junit.Assert.assertNotNull(functionType41);
        org.junit.Assert.assertNotNull(iterable42);
        org.junit.Assert.assertNull(node43);
        org.junit.Assert.assertTrue("'" + jSTypeNative51 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative51.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative52 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative52.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative53 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative53.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray54);
        org.junit.Assert.assertNotNull(jSType55);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertTrue("'" + jSTypeNative61 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative61.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative62 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative62.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative63 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative63.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray64);
        org.junit.Assert.assertNotNull(jSType65);
        org.junit.Assert.assertTrue("'" + jSTypeNative69 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative69.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative70 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative70.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative71 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative71.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray72);
        org.junit.Assert.assertNotNull(jSType73);
        org.junit.Assert.assertNull(jSDocInfo74);
        org.junit.Assert.assertNull(objectType75);
        org.junit.Assert.assertNotNull(jSTypeArray76);
        org.junit.Assert.assertNotNull(functionType77);
        org.junit.Assert.assertNotNull(functionType78);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + true + "'", boolean79 == true);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, true);
        com.google.javascript.rhino.ErrorReporter errorReporter3 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter3, true);
        com.google.javascript.rhino.ErrorReporter errorReporter6 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry8 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter6, true);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative9 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative10 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative11 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray12 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative9, jSTypeNative10, jSTypeNative11 };
        com.google.javascript.rhino.jstype.JSType jSType13 = jSTypeRegistry8.createUnionType(jSTypeNativeArray12);
        boolean boolean14 = jSType13.isRegexpType();
        boolean boolean15 = jSType13.isNullable();
        com.google.javascript.rhino.ErrorReporter errorReporter16 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry18 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter16, true);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative19 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative20 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative21 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray22 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative19, jSTypeNative20, jSTypeNative21 };
        com.google.javascript.rhino.jstype.JSType jSType23 = jSTypeRegistry18.createUnionType(jSTypeNativeArray22);
        com.google.javascript.rhino.ErrorReporter errorReporter24 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry26 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter24, true);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative27 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative28 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative29 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray30 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative27, jSTypeNative28, jSTypeNative29 };
        com.google.javascript.rhino.jstype.JSType jSType31 = jSTypeRegistry26.createUnionType(jSTypeNativeArray30);
        com.google.javascript.rhino.JSDocInfo jSDocInfo32 = jSType31.getJSDocInfo();
        com.google.javascript.rhino.jstype.ObjectType objectType33 = jSType31.toObjectType();
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray34 = new com.google.javascript.rhino.jstype.JSType[] { jSType23, jSType31 };
        com.google.javascript.rhino.jstype.FunctionType functionType35 = jSTypeRegistry5.createConstructorTypeWithVarArgs(jSType13, jSTypeArray34);
        com.google.javascript.rhino.ErrorReporter errorReporter36 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry38 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter36, true);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative39 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative40 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative41 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray42 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative39, jSTypeNative40, jSTypeNative41 };
        com.google.javascript.rhino.jstype.JSType jSType43 = jSTypeRegistry38.createUnionType(jSTypeNativeArray42);
        boolean boolean44 = jSType43.isStringObjectType();
        com.google.javascript.rhino.jstype.ParameterizedType parameterizedType45 = jSTypeRegistry2.createParameterizedType((com.google.javascript.rhino.jstype.ObjectType) functionType35, jSType43);
        com.google.javascript.rhino.jstype.ObjectType.Property property47 = parameterizedType45.getSlot("");
        boolean boolean48 = parameterizedType45.matchesNumberContext();
        com.google.javascript.rhino.ErrorReporter errorReporter49 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry51 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter49, true);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative52 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative53 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative54 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray55 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative52, jSTypeNative53, jSTypeNative54 };
        com.google.javascript.rhino.jstype.JSType jSType56 = jSTypeRegistry51.createUnionType(jSTypeNativeArray55);
        com.google.javascript.rhino.ErrorReporter errorReporter57 = null;
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope58 = null;
        com.google.javascript.rhino.jstype.JSType jSType59 = jSType56.resolve(errorReporter57, jSTypeStaticScope58);
        boolean boolean60 = jSType56.isNumberObjectType();
        boolean boolean61 = jSType56.isNominalConstructor();
        boolean boolean62 = parameterizedType45.isSubtype(jSType56);
        com.google.javascript.rhino.JSDocInfo jSDocInfo63 = parameterizedType45.getJSDocInfo();
        com.google.javascript.rhino.jstype.TemplateType templateType64 = parameterizedType45.toMaybeTemplateType();
        try {
            com.google.javascript.rhino.jstype.ObjectType objectType65 = templateType64.getTypeOfThis();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + jSTypeNative9 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative9.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative10 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative10.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative11 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative11.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray12);
        org.junit.Assert.assertNotNull(jSType13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + jSTypeNative19 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative19.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative20 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative20.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative21 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative21.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray22);
        org.junit.Assert.assertNotNull(jSType23);
        org.junit.Assert.assertTrue("'" + jSTypeNative27 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative27.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative28 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative28.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative29 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative29.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray30);
        org.junit.Assert.assertNotNull(jSType31);
        org.junit.Assert.assertNull(jSDocInfo32);
        org.junit.Assert.assertNull(objectType33);
        org.junit.Assert.assertNotNull(jSTypeArray34);
        org.junit.Assert.assertNotNull(functionType35);
        org.junit.Assert.assertTrue("'" + jSTypeNative39 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative39.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative40 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative40.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative41 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative41.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray42);
        org.junit.Assert.assertNotNull(jSType43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(parameterizedType45);
        org.junit.Assert.assertNull(property47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertTrue("'" + jSTypeNative52 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative52.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative53 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative53.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative54 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative54.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray55);
        org.junit.Assert.assertNotNull(jSType56);
        org.junit.Assert.assertNotNull(jSType59);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertNull(jSDocInfo63);
        org.junit.Assert.assertNull(templateType64);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, true);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative3 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative4 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative5 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray6 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative3, jSTypeNative4, jSTypeNative5 };
        com.google.javascript.rhino.jstype.JSType jSType7 = jSTypeRegistry2.createUnionType(jSTypeNativeArray6);
        jSTypeRegistry2.clearTemplateTypeNames();
        boolean boolean10 = jSTypeRegistry2.hasNamespace("Unknown class name");
        com.google.javascript.rhino.ErrorReporter errorReporter11 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry13 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter11, true);
        com.google.javascript.rhino.ErrorReporter errorReporter14 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry16 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter14, true);
        com.google.javascript.rhino.ErrorReporter errorReporter17 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry19 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter17, true);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative20 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative21 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative22 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray23 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative20, jSTypeNative21, jSTypeNative22 };
        com.google.javascript.rhino.jstype.JSType jSType24 = jSTypeRegistry19.createUnionType(jSTypeNativeArray23);
        boolean boolean25 = jSType24.isRegexpType();
        boolean boolean26 = jSType24.isNullable();
        com.google.javascript.rhino.ErrorReporter errorReporter27 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry29 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter27, true);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative30 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative31 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative32 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray33 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative30, jSTypeNative31, jSTypeNative32 };
        com.google.javascript.rhino.jstype.JSType jSType34 = jSTypeRegistry29.createUnionType(jSTypeNativeArray33);
        com.google.javascript.rhino.ErrorReporter errorReporter35 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry37 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter35, true);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative38 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative39 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative40 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray41 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative38, jSTypeNative39, jSTypeNative40 };
        com.google.javascript.rhino.jstype.JSType jSType42 = jSTypeRegistry37.createUnionType(jSTypeNativeArray41);
        com.google.javascript.rhino.JSDocInfo jSDocInfo43 = jSType42.getJSDocInfo();
        com.google.javascript.rhino.jstype.ObjectType objectType44 = jSType42.toObjectType();
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray45 = new com.google.javascript.rhino.jstype.JSType[] { jSType34, jSType42 };
        com.google.javascript.rhino.jstype.FunctionType functionType46 = jSTypeRegistry16.createConstructorTypeWithVarArgs(jSType24, jSTypeArray45);
        com.google.javascript.rhino.ErrorReporter errorReporter47 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry49 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter47, true);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative50 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative51 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative52 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray53 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative50, jSTypeNative51, jSTypeNative52 };
        com.google.javascript.rhino.jstype.JSType jSType54 = jSTypeRegistry49.createUnionType(jSTypeNativeArray53);
        boolean boolean55 = jSType54.isStringObjectType();
        com.google.javascript.rhino.jstype.ParameterizedType parameterizedType56 = jSTypeRegistry13.createParameterizedType((com.google.javascript.rhino.jstype.ObjectType) functionType46, jSType54);
        com.google.javascript.rhino.jstype.JSType jSType57 = parameterizedType56.getParameterType();
        com.google.javascript.rhino.jstype.JSType jSType58 = parameterizedType56.getIndexType();
        com.google.javascript.rhino.jstype.ObjectType objectType59 = null;
        boolean boolean60 = jSTypeRegistry2.resetImplicitPrototype((com.google.javascript.rhino.jstype.JSType) parameterizedType56, objectType59);
        boolean boolean62 = parameterizedType56.isPropertyInExterns("{proxy:function ({1047075399}, {({605412354},{558514873})}): {1793560964}}");
        com.google.javascript.rhino.jstype.ObjectType objectType64 = com.google.javascript.rhino.jstype.FunctionType.getTopDefiningInterface((com.google.javascript.rhino.jstype.ObjectType) parameterizedType56, "{proxy:function ({1620316444}, {({2132754871},{558740021})}): {133945447}}");
        org.junit.Assert.assertTrue("'" + jSTypeNative3 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative3.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative4 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative4.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative5 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative5.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray6);
        org.junit.Assert.assertNotNull(jSType7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + jSTypeNative20 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative20.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative21 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative21.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative22 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative22.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray23);
        org.junit.Assert.assertNotNull(jSType24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + jSTypeNative30 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative30.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative31 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative31.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative32 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative32.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray33);
        org.junit.Assert.assertNotNull(jSType34);
        org.junit.Assert.assertTrue("'" + jSTypeNative38 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative38.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative39 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative39.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative40 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative40.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray41);
        org.junit.Assert.assertNotNull(jSType42);
        org.junit.Assert.assertNull(jSDocInfo43);
        org.junit.Assert.assertNull(objectType44);
        org.junit.Assert.assertNotNull(jSTypeArray45);
        org.junit.Assert.assertNotNull(functionType46);
        org.junit.Assert.assertTrue("'" + jSTypeNative50 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative50.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative51 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative51.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative52 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative52.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray53);
        org.junit.Assert.assertNotNull(jSType54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNotNull(parameterizedType56);
        org.junit.Assert.assertNotNull(jSType57);
        org.junit.Assert.assertNull(jSType58);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertNull(objectType64);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        com.google.javascript.jscomp.DiagnosticType diagnosticType0 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        java.lang.String[] strArray2 = new java.lang.String[] { "Unknown class name" };
        com.google.javascript.jscomp.JSError jSError3 = com.google.javascript.jscomp.JSError.make(diagnosticType0, strArray2);
        java.lang.String str4 = jSError3.toString();
        org.junit.Assert.assertNotNull(diagnosticType0);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(jSError3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "JSC_OPTIMIZE_LOOP_ERROR. Exceeded max number of optimization iterations: Unknown class name at (unknown source) line (unknown line) : (unknown column)" + "'", str4.equals("JSC_OPTIMIZE_LOOP_ERROR. Exceeded max number of optimization iterations: Unknown class name at (unknown source) line (unknown line) : (unknown column)"));
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, true);
        com.google.javascript.rhino.ErrorReporter errorReporter3 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter3, true);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative6 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative7 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative8 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray9 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative6, jSTypeNative7, jSTypeNative8 };
        com.google.javascript.rhino.jstype.JSType jSType10 = jSTypeRegistry5.createUnionType(jSTypeNativeArray9);
        boolean boolean11 = jSType10.isRegexpType();
        boolean boolean12 = jSType10.isNullable();
        com.google.javascript.rhino.ErrorReporter errorReporter13 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry15 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter13, true);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative16 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative17 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative18 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray19 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative16, jSTypeNative17, jSTypeNative18 };
        com.google.javascript.rhino.jstype.JSType jSType20 = jSTypeRegistry15.createUnionType(jSTypeNativeArray19);
        com.google.javascript.rhino.ErrorReporter errorReporter21 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry23 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter21, true);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative24 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative25 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative26 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray27 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative24, jSTypeNative25, jSTypeNative26 };
        com.google.javascript.rhino.jstype.JSType jSType28 = jSTypeRegistry23.createUnionType(jSTypeNativeArray27);
        com.google.javascript.rhino.JSDocInfo jSDocInfo29 = jSType28.getJSDocInfo();
        com.google.javascript.rhino.jstype.ObjectType objectType30 = jSType28.toObjectType();
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray31 = new com.google.javascript.rhino.jstype.JSType[] { jSType20, jSType28 };
        com.google.javascript.rhino.jstype.FunctionType functionType32 = jSTypeRegistry2.createConstructorTypeWithVarArgs(jSType10, jSTypeArray31);
        boolean boolean34 = functionType32.hasProperty("hi!");
        boolean boolean35 = functionType32.hasAnyTemplateInternal();
        org.junit.Assert.assertTrue("'" + jSTypeNative6 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative6.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative7 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative7.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative8 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative8.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray9);
        org.junit.Assert.assertNotNull(jSType10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + jSTypeNative16 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative16.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative17 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative17.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative18 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative18.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray19);
        org.junit.Assert.assertNotNull(jSType20);
        org.junit.Assert.assertTrue("'" + jSTypeNative24 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative24.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative25 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative25.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative26 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative26.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray27);
        org.junit.Assert.assertNotNull(jSType28);
        org.junit.Assert.assertNull(jSDocInfo29);
        org.junit.Assert.assertNull(objectType30);
        org.junit.Assert.assertNotNull(jSTypeArray31);
        org.junit.Assert.assertNotNull(functionType32);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        com.google.javascript.jscomp.JSModule jSModule1 = new com.google.javascript.jscomp.JSModule("hi!");
        com.google.javascript.jscomp.SourceAst sourceAst2 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput5 = new com.google.javascript.jscomp.CompilerInput(sourceAst2, "", false);
        com.google.javascript.jscomp.AbstractCompiler abstractCompiler6 = null;
        compilerInput5.setCompiler(abstractCompiler6);
        com.google.javascript.rhino.InputId inputId8 = compilerInput5.getInputId();
        jSModule1.remove(compilerInput5);
        com.google.javascript.jscomp.SourceFile sourceFile13 = com.google.javascript.jscomp.SourceFile.fromCode("hi!", "Unknown class name", "Unknown class name");
        com.google.javascript.jscomp.Region region15 = sourceFile13.getRegion(2147483647);
        com.google.javascript.jscomp.CompilerInput compilerInput16 = new com.google.javascript.jscomp.CompilerInput(sourceFile13);
        com.google.javascript.rhino.InputId inputId17 = compilerInput16.getInputId();
        jSModule1.remove(compilerInput16);
        boolean boolean19 = compilerInput16.isExtern();
        org.junit.Assert.assertNotNull(inputId8);
        org.junit.Assert.assertNotNull(sourceFile13);
        org.junit.Assert.assertNull(region15);
        org.junit.Assert.assertNotNull(inputId17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        com.google.javascript.jscomp.JSModule jSModule3 = new com.google.javascript.jscomp.JSModule("hi!");
        java.util.List<java.lang.String> strList4 = jSModule3.getProvides();
        com.google.javascript.jscomp.JSModule jSModule6 = new com.google.javascript.jscomp.JSModule("hi!");
        java.util.List<java.lang.String> strList7 = jSModule6.getProvides();
        com.google.javascript.jscomp.deps.SimpleDependencyInfo simpleDependencyInfo8 = new com.google.javascript.jscomp.deps.SimpleDependencyInfo("", "GETELEM", strList4, strList7);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative9 = com.google.javascript.rhino.jstype.JSTypeNative.NO_OBJECT_TYPE;
        boolean boolean10 = simpleDependencyInfo8.equals((java.lang.Object) jSTypeNative9);
        java.lang.String str11 = simpleDependencyInfo8.getPathRelativeToClosureBase();
        org.junit.Assert.assertNotNull(strList4);
        org.junit.Assert.assertNotNull(strList7);
        org.junit.Assert.assertTrue("'" + jSTypeNative9 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.NO_OBJECT_TYPE + "'", jSTypeNative9.equals(com.google.javascript.rhino.jstype.JSTypeNative.NO_OBJECT_TYPE));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newNumber((double) (short) -1, (int) (byte) 1, 0);
        boolean boolean5 = node4.isArrayLit();
        boolean boolean6 = node4.isLabelName();
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newNumber((double) (short) -1, (int) (byte) 1, 0);
        boolean boolean11 = node10.isArrayLit();
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.Node.newNumber((double) (short) -1, (int) (byte) 1, 0);
        com.google.javascript.rhino.Node node16 = new com.google.javascript.rhino.Node((int) '#', node4, node10, node15);
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.Node.newNumber(0.0d);
        com.google.javascript.rhino.Node node19 = node4.copyInformationFromForTree(node18);
        boolean boolean20 = node19.isAssign();
        com.google.javascript.rhino.Node node24 = com.google.javascript.rhino.Node.newNumber((double) (short) -1, (int) (byte) 1, 0);
        node19.addChildrenToFront(node24);
        boolean boolean26 = node24.isNoSideEffectsCall();
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newNumber((double) (short) -1, (int) (byte) 1, 0);
        boolean boolean5 = node4.isArrayLit();
        boolean boolean6 = node4.isLabelName();
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newNumber((double) (short) -1, (int) (byte) 1, 0);
        boolean boolean11 = node10.isArrayLit();
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.Node.newNumber((double) (short) -1, (int) (byte) 1, 0);
        com.google.javascript.rhino.Node node16 = new com.google.javascript.rhino.Node((int) '#', node4, node10, node15);
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.Node.newNumber(0.0d);
        com.google.javascript.rhino.Node node19 = node4.copyInformationFromForTree(node18);
        node18.setIsSyntheticBlock(false);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNotNull(node19);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        com.google.javascript.rhino.jstype.JSTypeRegistry.ResolveMode resolveMode0 = com.google.javascript.rhino.jstype.JSTypeRegistry.ResolveMode.LAZY_NAMES;
        org.junit.Assert.assertTrue("'" + resolveMode0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeRegistry.ResolveMode.LAZY_NAMES + "'", resolveMode0.equals(com.google.javascript.rhino.jstype.JSTypeRegistry.ResolveMode.LAZY_NAMES));
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newNumber((double) (short) -1, (int) (byte) 1, 0);
        boolean boolean4 = node3.isArrayLit();
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newNumber((double) (short) -1, (int) (byte) 1, 0);
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.IR.getelem(node3, node8);
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.Node.newNumber((double) (short) -1, (int) (byte) 1, 0);
        boolean boolean15 = node14.isArrayLit();
        boolean boolean16 = node14.isLabelName();
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.Node.newNumber((double) (short) -1, (int) (byte) 1, 0);
        boolean boolean21 = node20.isArrayLit();
        com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.Node.newNumber((double) (short) -1, (int) (byte) 1, 0);
        com.google.javascript.rhino.Node node26 = new com.google.javascript.rhino.Node((int) '#', node14, node20, node25);
        com.google.javascript.rhino.Node node28 = com.google.javascript.rhino.Node.newNumber(0.0d);
        com.google.javascript.rhino.Node node29 = node14.copyInformationFromForTree(node28);
        com.google.javascript.rhino.Node node30 = node3.copyInformationFrom(node29);
        boolean boolean31 = node3.isRegExp();
        com.google.javascript.rhino.Node node36 = com.google.javascript.rhino.Node.newNumber((double) (short) -1, (int) (byte) 1, 0);
        boolean boolean37 = node36.isArrayLit();
        boolean boolean38 = node36.isLabelName();
        com.google.javascript.rhino.Node node42 = com.google.javascript.rhino.Node.newNumber((double) (short) -1, (int) (byte) 1, 0);
        boolean boolean43 = node42.isArrayLit();
        com.google.javascript.rhino.Node node47 = com.google.javascript.rhino.Node.newNumber((double) (short) -1, (int) (byte) 1, 0);
        com.google.javascript.rhino.Node node48 = new com.google.javascript.rhino.Node((int) '#', node36, node42, node47);
        com.google.javascript.rhino.Node node50 = com.google.javascript.rhino.Node.newNumber(0.0d);
        com.google.javascript.rhino.Node node51 = node36.copyInformationFromForTree(node50);
        boolean boolean52 = node51.isAssign();
        boolean boolean53 = node51.isRegExp();
        int int54 = node3.getIndexOfChild(node51);
        com.google.javascript.rhino.Node node55 = node51.cloneNode();
        com.google.javascript.rhino.JSTypeExpression jSTypeExpression57 = new com.google.javascript.rhino.JSTypeExpression(node55, "JSC_OPTIMIZE_LOOP_ERROR");
        boolean boolean58 = jSTypeExpression57.isVarArgs();
        com.google.javascript.rhino.JSTypeExpression jSTypeExpression59 = com.google.javascript.rhino.JSTypeExpression.makeOptionalArg(jSTypeExpression57);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNotNull(node30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(node36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(node42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(node47);
        org.junit.Assert.assertNotNull(node50);
        org.junit.Assert.assertNotNull(node51);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + (-1) + "'", int54 == (-1));
        org.junit.Assert.assertNotNull(node55);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(jSTypeExpression59);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, true);
        com.google.javascript.rhino.ErrorReporter errorReporter3 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter3, true);
        com.google.javascript.rhino.ErrorReporter errorReporter6 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry8 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter6, true);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative9 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative10 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative11 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray12 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative9, jSTypeNative10, jSTypeNative11 };
        com.google.javascript.rhino.jstype.JSType jSType13 = jSTypeRegistry8.createUnionType(jSTypeNativeArray12);
        boolean boolean14 = jSType13.isRegexpType();
        boolean boolean15 = jSType13.isNullable();
        com.google.javascript.rhino.ErrorReporter errorReporter16 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry18 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter16, true);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative19 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative20 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative21 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray22 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative19, jSTypeNative20, jSTypeNative21 };
        com.google.javascript.rhino.jstype.JSType jSType23 = jSTypeRegistry18.createUnionType(jSTypeNativeArray22);
        com.google.javascript.rhino.ErrorReporter errorReporter24 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry26 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter24, true);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative27 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative28 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative29 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray30 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative27, jSTypeNative28, jSTypeNative29 };
        com.google.javascript.rhino.jstype.JSType jSType31 = jSTypeRegistry26.createUnionType(jSTypeNativeArray30);
        com.google.javascript.rhino.JSDocInfo jSDocInfo32 = jSType31.getJSDocInfo();
        com.google.javascript.rhino.jstype.ObjectType objectType33 = jSType31.toObjectType();
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray34 = new com.google.javascript.rhino.jstype.JSType[] { jSType23, jSType31 };
        com.google.javascript.rhino.jstype.FunctionType functionType35 = jSTypeRegistry5.createConstructorTypeWithVarArgs(jSType13, jSTypeArray34);
        com.google.javascript.rhino.ErrorReporter errorReporter36 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry38 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter36, true);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative39 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative40 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative41 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray42 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative39, jSTypeNative40, jSTypeNative41 };
        com.google.javascript.rhino.jstype.JSType jSType43 = jSTypeRegistry38.createUnionType(jSTypeNativeArray42);
        boolean boolean44 = jSType43.isStringObjectType();
        com.google.javascript.rhino.jstype.ParameterizedType parameterizedType45 = jSTypeRegistry2.createParameterizedType((com.google.javascript.rhino.jstype.ObjectType) functionType35, jSType43);
        com.google.javascript.rhino.jstype.ObjectType.Property property47 = parameterizedType45.getSlot("");
        boolean boolean48 = parameterizedType45.matchesNumberContext();
        com.google.javascript.rhino.jstype.FunctionType functionType49 = parameterizedType45.toMaybeFunctionType();
        boolean boolean50 = parameterizedType45.isInstanceType();
        boolean boolean51 = parameterizedType45.isUnknownType();
        boolean boolean52 = parameterizedType45.isConstructor();
        org.junit.Assert.assertTrue("'" + jSTypeNative9 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative9.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative10 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative10.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative11 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative11.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray12);
        org.junit.Assert.assertNotNull(jSType13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + jSTypeNative19 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative19.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative20 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative20.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative21 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative21.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray22);
        org.junit.Assert.assertNotNull(jSType23);
        org.junit.Assert.assertTrue("'" + jSTypeNative27 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative27.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative28 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative28.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative29 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative29.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray30);
        org.junit.Assert.assertNotNull(jSType31);
        org.junit.Assert.assertNull(jSDocInfo32);
        org.junit.Assert.assertNull(objectType33);
        org.junit.Assert.assertNotNull(jSTypeArray34);
        org.junit.Assert.assertNotNull(functionType35);
        org.junit.Assert.assertTrue("'" + jSTypeNative39 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative39.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative40 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative40.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative41 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative41.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray42);
        org.junit.Assert.assertNotNull(jSType43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(parameterizedType45);
        org.junit.Assert.assertNull(property47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(functionType49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        com.google.javascript.jscomp.DiagnosticType diagnosticType0 = com.google.javascript.jscomp.Compiler.MOTION_ITERATIONS_ERROR;
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup1 = com.google.javascript.jscomp.DiagnosticGroup.forType(diagnosticType0);
        com.google.javascript.jscomp.DiagnosticType diagnosticType2 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        com.google.javascript.jscomp.CheckLevel checkLevel3 = null;
        diagnosticType2.level = checkLevel3;
        com.google.javascript.jscomp.CheckLevel checkLevel5 = diagnosticType2.defaultLevel;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard6 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup1, checkLevel5);
        com.google.javascript.jscomp.DiagnosticType diagnosticType7 = com.google.javascript.jscomp.Compiler.MOTION_ITERATIONS_ERROR;
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup8 = com.google.javascript.jscomp.DiagnosticGroup.forType(diagnosticType7);
        com.google.javascript.jscomp.DiagnosticType diagnosticType9 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        com.google.javascript.jscomp.CheckLevel checkLevel10 = null;
        diagnosticType9.level = checkLevel10;
        com.google.javascript.jscomp.CheckLevel checkLevel12 = diagnosticType9.defaultLevel;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard13 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup8, checkLevel12);
        com.google.javascript.jscomp.StrictWarningsGuard strictWarningsGuard14 = new com.google.javascript.jscomp.StrictWarningsGuard();
        com.google.javascript.jscomp.StrictWarningsGuard strictWarningsGuard15 = new com.google.javascript.jscomp.StrictWarningsGuard();
        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray16 = new com.google.javascript.jscomp.WarningsGuard[] { diagnosticGroupWarningsGuard6, diagnosticGroupWarningsGuard13, strictWarningsGuard14, strictWarningsGuard15 };
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard17 = new com.google.javascript.jscomp.ComposeWarningsGuard(warningsGuardArray16);
        com.google.javascript.jscomp.MessageFormatter messageFormatter18 = null;
        java.util.logging.Logger logger19 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager20 = new com.google.javascript.jscomp.LoggerErrorManager(messageFormatter18, logger19);
        loggerErrorManager20.setTypedPercent((double) 100);
        com.google.javascript.jscomp.CheckLevel checkLevel23 = null;
        com.google.javascript.rhino.Node node28 = com.google.javascript.rhino.Node.newNumber((double) (short) -1, (int) (byte) 1, 0);
        boolean boolean29 = node28.isArrayLit();
        com.google.javascript.rhino.Node node33 = com.google.javascript.rhino.Node.newNumber((double) (short) -1, (int) (byte) 1, 0);
        com.google.javascript.rhino.Node node34 = com.google.javascript.rhino.IR.getelem(node28, node33);
        boolean boolean35 = node33.isTrue();
        com.google.javascript.jscomp.CheckLevel checkLevel36 = null;
        com.google.javascript.jscomp.DiagnosticType diagnosticType37 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        java.lang.String[] strArray38 = new java.lang.String[] {};
        com.google.javascript.jscomp.JSError jSError39 = com.google.javascript.jscomp.JSError.make("GETELEM", node33, checkLevel36, diagnosticType37, strArray38);
        loggerErrorManager20.report(checkLevel23, jSError39);
        java.lang.String str41 = jSError39.sourceName;
        com.google.javascript.jscomp.CheckLevel checkLevel42 = composeWarningsGuard17.level(jSError39);
        int int43 = jSError39.lineNumber;
        org.junit.Assert.assertNotNull(diagnosticType0);
        org.junit.Assert.assertNotNull(diagnosticGroup1);
        org.junit.Assert.assertNotNull(diagnosticType2);
        org.junit.Assert.assertTrue("'" + checkLevel5 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel5.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticType7);
        org.junit.Assert.assertNotNull(diagnosticGroup8);
        org.junit.Assert.assertNotNull(diagnosticType9);
        org.junit.Assert.assertTrue("'" + checkLevel12 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel12.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(warningsGuardArray16);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(node33);
        org.junit.Assert.assertNotNull(node34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(diagnosticType37);
        org.junit.Assert.assertNotNull(strArray38);
        org.junit.Assert.assertNotNull(jSError39);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "GETELEM" + "'", str41.equals("GETELEM"));
        org.junit.Assert.assertTrue("'" + checkLevel42 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel42.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 1 + "'", int43 == 1);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, true);
        com.google.javascript.rhino.ErrorReporter errorReporter3 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter3, true);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative6 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative7 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative8 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray9 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative6, jSTypeNative7, jSTypeNative8 };
        com.google.javascript.rhino.jstype.JSType jSType10 = jSTypeRegistry5.createUnionType(jSTypeNativeArray9);
        boolean boolean11 = jSType10.isRegexpType();
        boolean boolean12 = jSType10.isNullable();
        com.google.javascript.rhino.ErrorReporter errorReporter13 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry15 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter13, true);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative16 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative17 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative18 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray19 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative16, jSTypeNative17, jSTypeNative18 };
        com.google.javascript.rhino.jstype.JSType jSType20 = jSTypeRegistry15.createUnionType(jSTypeNativeArray19);
        com.google.javascript.rhino.ErrorReporter errorReporter21 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry23 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter21, true);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative24 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative25 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative26 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray27 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative24, jSTypeNative25, jSTypeNative26 };
        com.google.javascript.rhino.jstype.JSType jSType28 = jSTypeRegistry23.createUnionType(jSTypeNativeArray27);
        com.google.javascript.rhino.JSDocInfo jSDocInfo29 = jSType28.getJSDocInfo();
        com.google.javascript.rhino.jstype.ObjectType objectType30 = jSType28.toObjectType();
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray31 = new com.google.javascript.rhino.jstype.JSType[] { jSType20, jSType28 };
        com.google.javascript.rhino.jstype.FunctionType functionType32 = jSTypeRegistry2.createConstructorTypeWithVarArgs(jSType10, jSTypeArray31);
        com.google.javascript.rhino.jstype.JSType jSType34 = jSTypeRegistry2.getType("GETELEM");
        com.google.javascript.rhino.ErrorReporter errorReporter35 = jSTypeRegistry2.getErrorReporter();
        boolean boolean36 = jSTypeRegistry2.shouldTolerateUndefinedValues();
        org.junit.Assert.assertTrue("'" + jSTypeNative6 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative6.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative7 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative7.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative8 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative8.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray9);
        org.junit.Assert.assertNotNull(jSType10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + jSTypeNative16 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative16.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative17 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative17.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative18 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative18.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray19);
        org.junit.Assert.assertNotNull(jSType20);
        org.junit.Assert.assertTrue("'" + jSTypeNative24 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative24.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative25 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative25.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative26 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative26.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray27);
        org.junit.Assert.assertNotNull(jSType28);
        org.junit.Assert.assertNull(jSDocInfo29);
        org.junit.Assert.assertNull(objectType30);
        org.junit.Assert.assertNotNull(jSTypeArray31);
        org.junit.Assert.assertNotNull(functionType32);
        org.junit.Assert.assertNull(jSType34);
        org.junit.Assert.assertNull(errorReporter35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, true);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative3 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative4 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative5 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray6 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative3, jSTypeNative4, jSTypeNative5 };
        com.google.javascript.rhino.jstype.JSType jSType7 = jSTypeRegistry2.createUnionType(jSTypeNativeArray6);
        jSTypeRegistry2.clearTemplateTypeNames();
        com.google.javascript.rhino.ErrorReporter errorReporter9 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry11 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter9, true);
        com.google.javascript.rhino.ErrorReporter errorReporter12 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry14 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter12, true);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative15 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative16 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative17 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray18 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative15, jSTypeNative16, jSTypeNative17 };
        com.google.javascript.rhino.jstype.JSType jSType19 = jSTypeRegistry14.createUnionType(jSTypeNativeArray18);
        boolean boolean20 = jSType19.isRegexpType();
        boolean boolean21 = jSType19.isNullable();
        com.google.javascript.rhino.ErrorReporter errorReporter22 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry24 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter22, true);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative25 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative26 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative27 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray28 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative25, jSTypeNative26, jSTypeNative27 };
        com.google.javascript.rhino.jstype.JSType jSType29 = jSTypeRegistry24.createUnionType(jSTypeNativeArray28);
        com.google.javascript.rhino.ErrorReporter errorReporter30 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry32 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter30, true);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative33 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative34 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative35 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray36 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative33, jSTypeNative34, jSTypeNative35 };
        com.google.javascript.rhino.jstype.JSType jSType37 = jSTypeRegistry32.createUnionType(jSTypeNativeArray36);
        com.google.javascript.rhino.JSDocInfo jSDocInfo38 = jSType37.getJSDocInfo();
        com.google.javascript.rhino.jstype.ObjectType objectType39 = jSType37.toObjectType();
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray40 = new com.google.javascript.rhino.jstype.JSType[] { jSType29, jSType37 };
        com.google.javascript.rhino.jstype.FunctionType functionType41 = jSTypeRegistry11.createConstructorTypeWithVarArgs(jSType19, jSTypeArray40);
        java.lang.Iterable iterable42 = functionType41.getCtorImplementedInterfaces();
        com.google.javascript.rhino.Node node43 = functionType41.getSource();
        com.google.javascript.rhino.ErrorReporter errorReporter45 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry47 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter45, true);
        com.google.javascript.rhino.ErrorReporter errorReporter48 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry50 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter48, true);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative51 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative52 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative53 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray54 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative51, jSTypeNative52, jSTypeNative53 };
        com.google.javascript.rhino.jstype.JSType jSType55 = jSTypeRegistry50.createUnionType(jSTypeNativeArray54);
        boolean boolean56 = jSType55.isRegexpType();
        boolean boolean57 = jSType55.isNullable();
        com.google.javascript.rhino.ErrorReporter errorReporter58 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry60 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter58, true);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative61 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative62 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative63 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray64 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative61, jSTypeNative62, jSTypeNative63 };
        com.google.javascript.rhino.jstype.JSType jSType65 = jSTypeRegistry60.createUnionType(jSTypeNativeArray64);
        com.google.javascript.rhino.ErrorReporter errorReporter66 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry68 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter66, true);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative69 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative70 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative71 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray72 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative69, jSTypeNative70, jSTypeNative71 };
        com.google.javascript.rhino.jstype.JSType jSType73 = jSTypeRegistry68.createUnionType(jSTypeNativeArray72);
        com.google.javascript.rhino.JSDocInfo jSDocInfo74 = jSType73.getJSDocInfo();
        com.google.javascript.rhino.jstype.ObjectType objectType75 = jSType73.toObjectType();
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray76 = new com.google.javascript.rhino.jstype.JSType[] { jSType65, jSType73 };
        com.google.javascript.rhino.jstype.FunctionType functionType77 = jSTypeRegistry47.createConstructorTypeWithVarArgs(jSType55, jSTypeArray76);
        com.google.javascript.rhino.jstype.FunctionType functionType78 = jSTypeRegistry2.createFunctionType((com.google.javascript.rhino.jstype.JSType) functionType41, true, jSTypeArray76);
        java.lang.String str79 = functionType41.getReferenceName();
        org.junit.Assert.assertTrue("'" + jSTypeNative3 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative3.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative4 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative4.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative5 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative5.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray6);
        org.junit.Assert.assertNotNull(jSType7);
        org.junit.Assert.assertTrue("'" + jSTypeNative15 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative15.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative16 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative16.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative17 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative17.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray18);
        org.junit.Assert.assertNotNull(jSType19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + jSTypeNative25 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative25.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative26 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative26.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative27 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative27.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray28);
        org.junit.Assert.assertNotNull(jSType29);
        org.junit.Assert.assertTrue("'" + jSTypeNative33 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative33.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative34 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative34.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative35 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative35.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray36);
        org.junit.Assert.assertNotNull(jSType37);
        org.junit.Assert.assertNull(jSDocInfo38);
        org.junit.Assert.assertNull(objectType39);
        org.junit.Assert.assertNotNull(jSTypeArray40);
        org.junit.Assert.assertNotNull(functionType41);
        org.junit.Assert.assertNotNull(iterable42);
        org.junit.Assert.assertNull(node43);
        org.junit.Assert.assertTrue("'" + jSTypeNative51 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative51.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative52 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative52.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative53 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative53.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray54);
        org.junit.Assert.assertNotNull(jSType55);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertTrue("'" + jSTypeNative61 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative61.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative62 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative62.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative63 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative63.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray64);
        org.junit.Assert.assertNotNull(jSType65);
        org.junit.Assert.assertTrue("'" + jSTypeNative69 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative69.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative70 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative70.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative71 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative71.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray72);
        org.junit.Assert.assertNotNull(jSType73);
        org.junit.Assert.assertNull(jSDocInfo74);
        org.junit.Assert.assertNull(objectType75);
        org.junit.Assert.assertNotNull(jSTypeArray76);
        org.junit.Assert.assertNotNull(functionType77);
        org.junit.Assert.assertNotNull(functionType78);
        org.junit.Assert.assertNull(str79);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention0 = new com.google.javascript.jscomp.GoogleCodingConvention();
        boolean boolean2 = googleCodingConvention0.isConstantKey("hi!");
        boolean boolean4 = googleCodingConvention0.isExported("GETELEM");
        java.lang.String str5 = googleCodingConvention0.getAbstractMethodName();
        boolean boolean7 = googleCodingConvention0.isValidEnumKey("module$GETELEM");
        boolean boolean9 = googleCodingConvention0.isValidEnumKey("Node tree inequality:\nTree1:\nBREAK\n\n\nTree2:\nINSTANCEOF 48\n    PARAM_LIST\n    GETELEM\n        NUMBER -1.0 1\n        NUMBER -1.0 1\n\n\nSubtree1: BREAK\n\n\nSubtree2: INSTANCEOF 48\n    PARAM_LIST\n    GETELEM\n        NUMBER -1.0 1\n        NUMBER -1.0 1\n");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "goog.abstractMethod" + "'", str5.equals("goog.abstractMethod"));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newNumber((double) (short) -1, (int) (byte) 1, 0);
        boolean boolean4 = node3.isArrayLit();
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newNumber((double) (short) -1, (int) (byte) 1, 0);
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.IR.getelem(node3, node8);
        boolean boolean10 = node9.isCall();
        java.lang.String str11 = node9.toString();
        node9.putBooleanProp((int) (short) -1, true);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "GETELEM" + "'", str11.equals("GETELEM"));
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newNumber((double) (short) -1, (int) (byte) 1, 0);
        boolean boolean5 = node4.isArrayLit();
        boolean boolean6 = node4.isLabelName();
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newNumber((double) (short) -1, (int) (byte) 1, 0);
        boolean boolean11 = node10.isArrayLit();
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.Node.newNumber((double) (short) -1, (int) (byte) 1, 0);
        com.google.javascript.rhino.Node node16 = new com.google.javascript.rhino.Node((int) '#', node4, node10, node15);
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.Node.newNumber(0.0d);
        com.google.javascript.rhino.Node node19 = node4.copyInformationFromForTree(node18);
        boolean boolean20 = node19.isAssign();
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable21 = node19.siblings();
        boolean boolean22 = node19.isLocalResultCall();
        boolean boolean23 = node19.isThrow();
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(nodeIterable21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newNumber((double) (short) -1, (int) (byte) 1, 0);
        boolean boolean6 = node5.isArrayLit();
        boolean boolean7 = node5.isLabelName();
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.Node.newNumber((double) (short) -1, (int) (byte) 1, 0);
        boolean boolean12 = node11.isArrayLit();
        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.Node.newNumber((double) (short) -1, (int) (byte) 1, 0);
        com.google.javascript.rhino.Node node17 = new com.google.javascript.rhino.Node((int) '#', node5, node11, node16);
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.Node.newNumber(0.0d);
        com.google.javascript.rhino.Node node20 = node5.copyInformationFromForTree(node19);
        com.google.javascript.rhino.Node node21 = com.google.javascript.rhino.IR.exprResult(node19);
        com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.Node.newNumber((double) (short) -1, (int) (byte) 1, 0);
        boolean boolean26 = node25.isArrayLit();
        com.google.javascript.rhino.Node node30 = com.google.javascript.rhino.Node.newNumber((double) (short) -1, (int) (byte) 1, 0);
        com.google.javascript.rhino.Node node31 = com.google.javascript.rhino.IR.getelem(node25, node30);
        com.google.javascript.rhino.Node node32 = node31.cloneTree();
        node21.addChildrenToFront(node32);
        com.google.javascript.rhino.Node node37 = com.google.javascript.rhino.Node.newNumber((double) (short) -1, (int) (byte) 1, 0);
        int int38 = node37.getSourcePosition();
        java.lang.String str39 = closureCodingConvention0.extractClassNameIfProvide(node21, node37);
        com.google.javascript.rhino.Node node40 = com.google.javascript.rhino.IR.falseNode();
        boolean boolean41 = closureCodingConvention0.isOptionalParameter(node40);
        java.lang.String str42 = closureCodingConvention0.getExportSymbolFunction();
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(node30);
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertNotNull(node32);
        org.junit.Assert.assertNotNull(node37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 4096 + "'", int38 == 4096);
        org.junit.Assert.assertNull(str39);
        org.junit.Assert.assertNotNull(node40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "goog.exportSymbol" + "'", str42.equals("goog.exportSymbol"));
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        com.google.javascript.jscomp.AbstractCompiler abstractCompiler0 = null;
        com.google.javascript.jscomp.NodeTraversal.Callback callback1 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal2 = new com.google.javascript.jscomp.NodeTraversal(abstractCompiler0, callback1);
        java.lang.String str3 = nodeTraversal2.getSourceName();
        com.google.javascript.rhino.Node node4 = nodeTraversal2.getEnclosingFunction();
        com.google.javascript.jscomp.Compiler compiler5 = nodeTraversal2.getCompiler();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
        org.junit.Assert.assertNull(node4);
        org.junit.Assert.assertNull(compiler5);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention0 = new com.google.javascript.jscomp.GoogleCodingConvention();
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention1 = new com.google.javascript.jscomp.GoogleCodingConvention((com.google.javascript.jscomp.CodingConvention) googleCodingConvention0);
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newNumber((double) (short) -1, (int) (byte) 1, 0);
        boolean boolean6 = node5.isArrayLit();
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newNumber((double) (short) -1, (int) (byte) 1, 0);
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.IR.getelem(node5, node10);
        boolean boolean12 = node11.isCatch();
        boolean boolean13 = node11.isInc();
        try {
            boolean boolean14 = googleCodingConvention0.isInlinableFunction(node11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, true);
        com.google.javascript.rhino.ErrorReporter errorReporter3 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter3, true);
        com.google.javascript.rhino.ErrorReporter errorReporter6 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry8 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter6, true);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative9 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative10 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative11 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray12 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative9, jSTypeNative10, jSTypeNative11 };
        com.google.javascript.rhino.jstype.JSType jSType13 = jSTypeRegistry8.createUnionType(jSTypeNativeArray12);
        boolean boolean14 = jSType13.isRegexpType();
        boolean boolean15 = jSType13.isNullable();
        com.google.javascript.rhino.ErrorReporter errorReporter16 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry18 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter16, true);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative19 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative20 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative21 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray22 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative19, jSTypeNative20, jSTypeNative21 };
        com.google.javascript.rhino.jstype.JSType jSType23 = jSTypeRegistry18.createUnionType(jSTypeNativeArray22);
        com.google.javascript.rhino.ErrorReporter errorReporter24 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry26 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter24, true);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative27 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative28 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative29 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray30 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative27, jSTypeNative28, jSTypeNative29 };
        com.google.javascript.rhino.jstype.JSType jSType31 = jSTypeRegistry26.createUnionType(jSTypeNativeArray30);
        com.google.javascript.rhino.JSDocInfo jSDocInfo32 = jSType31.getJSDocInfo();
        com.google.javascript.rhino.jstype.ObjectType objectType33 = jSType31.toObjectType();
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray34 = new com.google.javascript.rhino.jstype.JSType[] { jSType23, jSType31 };
        com.google.javascript.rhino.jstype.FunctionType functionType35 = jSTypeRegistry5.createConstructorTypeWithVarArgs(jSType13, jSTypeArray34);
        com.google.javascript.rhino.ErrorReporter errorReporter36 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry38 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter36, true);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative39 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative40 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative41 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray42 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative39, jSTypeNative40, jSTypeNative41 };
        com.google.javascript.rhino.jstype.JSType jSType43 = jSTypeRegistry38.createUnionType(jSTypeNativeArray42);
        boolean boolean44 = jSType43.isStringObjectType();
        com.google.javascript.rhino.jstype.ParameterizedType parameterizedType45 = jSTypeRegistry2.createParameterizedType((com.google.javascript.rhino.jstype.ObjectType) functionType35, jSType43);
        com.google.javascript.rhino.jstype.ObjectType.Property property47 = parameterizedType45.getSlot("");
        boolean boolean48 = parameterizedType45.isInterface();
        com.google.javascript.rhino.Node node50 = parameterizedType45.getPropertyNode("Unknown class name");
        boolean boolean51 = parameterizedType45.isTemplateType();
        org.junit.Assert.assertTrue("'" + jSTypeNative9 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative9.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative10 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative10.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative11 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative11.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray12);
        org.junit.Assert.assertNotNull(jSType13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + jSTypeNative19 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative19.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative20 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative20.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative21 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative21.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray22);
        org.junit.Assert.assertNotNull(jSType23);
        org.junit.Assert.assertTrue("'" + jSTypeNative27 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative27.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative28 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative28.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative29 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative29.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray30);
        org.junit.Assert.assertNotNull(jSType31);
        org.junit.Assert.assertNull(jSDocInfo32);
        org.junit.Assert.assertNull(objectType33);
        org.junit.Assert.assertNotNull(jSTypeArray34);
        org.junit.Assert.assertNotNull(functionType35);
        org.junit.Assert.assertTrue("'" + jSTypeNative39 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative39.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative40 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative40.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative41 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative41.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray42);
        org.junit.Assert.assertNotNull(jSType43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(parameterizedType45);
        org.junit.Assert.assertNull(property47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNull(node50);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        com.google.javascript.jscomp.MessageFormatter messageFormatter0 = null;
        java.util.logging.Logger logger1 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager2 = new com.google.javascript.jscomp.LoggerErrorManager(messageFormatter0, logger1);
        int int3 = loggerErrorManager2.getErrorCount();
        int int4 = loggerErrorManager2.getErrorCount();
        com.google.javascript.jscomp.CheckLevel checkLevel5 = com.google.javascript.jscomp.CheckLevel.WARNING;
        com.google.javascript.jscomp.DiagnosticType diagnosticType6 = com.google.javascript.jscomp.Compiler.MOTION_ITERATIONS_ERROR;
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup7 = com.google.javascript.jscomp.DiagnosticGroup.forType(diagnosticType6);
        com.google.javascript.jscomp.DiagnosticType diagnosticType8 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        com.google.javascript.jscomp.CheckLevel checkLevel9 = null;
        diagnosticType8.level = checkLevel9;
        com.google.javascript.jscomp.CheckLevel checkLevel11 = diagnosticType8.defaultLevel;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard12 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup7, checkLevel11);
        com.google.javascript.jscomp.DiagnosticType diagnosticType13 = com.google.javascript.jscomp.Compiler.MOTION_ITERATIONS_ERROR;
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup14 = com.google.javascript.jscomp.DiagnosticGroup.forType(diagnosticType13);
        com.google.javascript.jscomp.DiagnosticType diagnosticType15 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        com.google.javascript.jscomp.CheckLevel checkLevel16 = null;
        diagnosticType15.level = checkLevel16;
        com.google.javascript.jscomp.CheckLevel checkLevel18 = diagnosticType15.defaultLevel;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard19 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup14, checkLevel18);
        com.google.javascript.jscomp.StrictWarningsGuard strictWarningsGuard20 = new com.google.javascript.jscomp.StrictWarningsGuard();
        com.google.javascript.jscomp.StrictWarningsGuard strictWarningsGuard21 = new com.google.javascript.jscomp.StrictWarningsGuard();
        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray22 = new com.google.javascript.jscomp.WarningsGuard[] { diagnosticGroupWarningsGuard12, diagnosticGroupWarningsGuard19, strictWarningsGuard20, strictWarningsGuard21 };
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard23 = new com.google.javascript.jscomp.ComposeWarningsGuard(warningsGuardArray22);
        com.google.javascript.jscomp.DiagnosticType diagnosticType24 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        java.lang.String[] strArray26 = new java.lang.String[] { "Unknown class name" };
        com.google.javascript.jscomp.JSError jSError27 = com.google.javascript.jscomp.JSError.make(diagnosticType24, strArray26);
        com.google.javascript.jscomp.CheckLevel checkLevel28 = composeWarningsGuard23.level(jSError27);
        int int29 = jSError27.getCharno();
        try {
            loggerErrorManager2.println(checkLevel5, jSError27);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + checkLevel5 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel5.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
        org.junit.Assert.assertNotNull(diagnosticType6);
        org.junit.Assert.assertNotNull(diagnosticGroup7);
        org.junit.Assert.assertNotNull(diagnosticType8);
        org.junit.Assert.assertTrue("'" + checkLevel11 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel11.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticType13);
        org.junit.Assert.assertNotNull(diagnosticGroup14);
        org.junit.Assert.assertNotNull(diagnosticType15);
        org.junit.Assert.assertTrue("'" + checkLevel18 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel18.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(warningsGuardArray22);
        org.junit.Assert.assertNotNull(diagnosticType24);
        org.junit.Assert.assertNotNull(strArray26);
        org.junit.Assert.assertNotNull(jSError27);
        org.junit.Assert.assertTrue("'" + checkLevel28 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel28.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        com.google.javascript.jscomp.SourceMap.DetailLevel detailLevel0 = com.google.javascript.jscomp.SourceMap.DetailLevel.ALL;
        org.junit.Assert.assertNotNull(detailLevel0);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        com.google.javascript.jscomp.SourceFile sourceFile3 = com.google.javascript.jscomp.SourceFile.fromCode("hi!", "Unknown class name", "Unknown class name");
        com.google.javascript.jscomp.Region region5 = sourceFile3.getRegion(2147483647);
        com.google.javascript.jscomp.CompilerInput compilerInput6 = new com.google.javascript.jscomp.CompilerInput(sourceFile3);
        com.google.javascript.rhino.InputId inputId7 = compilerInput6.getInputId();
        java.io.PrintStream printStream8 = null;
        com.google.javascript.jscomp.Compiler compiler9 = new com.google.javascript.jscomp.Compiler(printStream8);
        compilerInput6.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler9);
        com.google.javascript.rhino.Node node11 = compiler9.getRoot();
        try {
            boolean boolean12 = compiler9.isIdeMode();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(sourceFile3);
        org.junit.Assert.assertNull(region5);
        org.junit.Assert.assertNotNull(inputId7);
        org.junit.Assert.assertNull(node11);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        com.google.javascript.jscomp.SourceFile sourceFile3 = com.google.javascript.jscomp.SourceFile.fromCode("hi!", "Unknown class name", "Unknown class name");
        com.google.javascript.jscomp.Region region5 = sourceFile3.getRegion(2147483647);
        com.google.javascript.jscomp.CompilerInput compilerInput6 = new com.google.javascript.jscomp.CompilerInput(sourceFile3);
        com.google.javascript.rhino.InputId inputId7 = compilerInput6.getInputId();
        java.io.PrintStream printStream8 = null;
        com.google.javascript.jscomp.Compiler compiler9 = new com.google.javascript.jscomp.Compiler(printStream8);
        compilerInput6.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler9);
        com.google.javascript.jscomp.CompilerInput compilerInput12 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput6, true);
        org.junit.Assert.assertNotNull(sourceFile3);
        org.junit.Assert.assertNull(region5);
        org.junit.Assert.assertNotNull(inputId7);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, true);
        com.google.javascript.rhino.ErrorReporter errorReporter3 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter3, true);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative6 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative7 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative8 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray9 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative6, jSTypeNative7, jSTypeNative8 };
        com.google.javascript.rhino.jstype.JSType jSType10 = jSTypeRegistry5.createUnionType(jSTypeNativeArray9);
        boolean boolean11 = jSType10.isRegexpType();
        boolean boolean12 = jSType10.isNullable();
        com.google.javascript.rhino.ErrorReporter errorReporter13 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry15 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter13, true);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative16 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative17 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative18 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray19 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative16, jSTypeNative17, jSTypeNative18 };
        com.google.javascript.rhino.jstype.JSType jSType20 = jSTypeRegistry15.createUnionType(jSTypeNativeArray19);
        com.google.javascript.rhino.ErrorReporter errorReporter21 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry23 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter21, true);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative24 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative25 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative26 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray27 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative24, jSTypeNative25, jSTypeNative26 };
        com.google.javascript.rhino.jstype.JSType jSType28 = jSTypeRegistry23.createUnionType(jSTypeNativeArray27);
        com.google.javascript.rhino.JSDocInfo jSDocInfo29 = jSType28.getJSDocInfo();
        com.google.javascript.rhino.jstype.ObjectType objectType30 = jSType28.toObjectType();
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray31 = new com.google.javascript.rhino.jstype.JSType[] { jSType20, jSType28 };
        com.google.javascript.rhino.jstype.FunctionType functionType32 = jSTypeRegistry2.createConstructorTypeWithVarArgs(jSType10, jSTypeArray31);
        boolean boolean33 = functionType32.isConstructor();
        java.lang.String str34 = functionType32.toAnnotationString();
        com.google.javascript.rhino.jstype.FunctionType functionType35 = functionType32.getSuperClassConstructor();
        try {
            boolean boolean36 = functionType35.isInterface();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + jSTypeNative6 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative6.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative7 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative7.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative8 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative8.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray9);
        org.junit.Assert.assertNotNull(jSType10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + jSTypeNative16 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative16.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative17 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative17.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative18 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative18.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray19);
        org.junit.Assert.assertNotNull(jSType20);
        org.junit.Assert.assertTrue("'" + jSTypeNative24 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative24.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative25 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative25.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative26 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative26.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray27);
        org.junit.Assert.assertNotNull(jSType28);
        org.junit.Assert.assertNull(jSDocInfo29);
        org.junit.Assert.assertNull(objectType30);
        org.junit.Assert.assertNotNull(jSTypeArray31);
        org.junit.Assert.assertNotNull(functionType32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "function (new:?, boolean, ...[boolean]): boolean" + "'", str34.equals("function (new:?, boolean, ...[boolean]): boolean"));
        org.junit.Assert.assertNull(functionType35);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, true);
        com.google.javascript.rhino.Node node4 = null;
        com.google.javascript.rhino.ErrorReporter errorReporter5 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry7 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter5, true);
        com.google.javascript.rhino.ErrorReporter errorReporter8 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry10 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter8, true);
        com.google.javascript.rhino.ErrorReporter errorReporter11 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry13 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter11, true);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative14 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative15 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative16 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray17 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative14, jSTypeNative15, jSTypeNative16 };
        com.google.javascript.rhino.jstype.JSType jSType18 = jSTypeRegistry13.createUnionType(jSTypeNativeArray17);
        boolean boolean19 = jSType18.isRegexpType();
        boolean boolean20 = jSType18.isNullable();
        com.google.javascript.rhino.ErrorReporter errorReporter21 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry23 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter21, true);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative24 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative25 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative26 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray27 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative24, jSTypeNative25, jSTypeNative26 };
        com.google.javascript.rhino.jstype.JSType jSType28 = jSTypeRegistry23.createUnionType(jSTypeNativeArray27);
        com.google.javascript.rhino.ErrorReporter errorReporter29 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry31 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter29, true);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative32 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative33 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative34 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray35 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative32, jSTypeNative33, jSTypeNative34 };
        com.google.javascript.rhino.jstype.JSType jSType36 = jSTypeRegistry31.createUnionType(jSTypeNativeArray35);
        com.google.javascript.rhino.JSDocInfo jSDocInfo37 = jSType36.getJSDocInfo();
        com.google.javascript.rhino.jstype.ObjectType objectType38 = jSType36.toObjectType();
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray39 = new com.google.javascript.rhino.jstype.JSType[] { jSType28, jSType36 };
        com.google.javascript.rhino.jstype.FunctionType functionType40 = jSTypeRegistry10.createConstructorTypeWithVarArgs(jSType18, jSTypeArray39);
        com.google.javascript.rhino.ErrorReporter errorReporter41 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry43 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter41, true);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative44 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative45 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative46 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray47 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative44, jSTypeNative45, jSTypeNative46 };
        com.google.javascript.rhino.jstype.JSType jSType48 = jSTypeRegistry43.createUnionType(jSTypeNativeArray47);
        boolean boolean49 = jSType48.isStringObjectType();
        com.google.javascript.rhino.jstype.ParameterizedType parameterizedType50 = jSTypeRegistry7.createParameterizedType((com.google.javascript.rhino.jstype.ObjectType) functionType40, jSType48);
        boolean boolean51 = functionType40.isObject();
        boolean boolean52 = functionType40.isFunctionPrototypeType();
        java.lang.Object obj53 = functionType40.getTypeOfThis();
        com.google.javascript.rhino.jstype.ObjectType objectType54 = jSTypeRegistry2.createObjectType("JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of optimization iterations: {0}", node4, (com.google.javascript.rhino.jstype.ObjectType) functionType40);
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention56 = new com.google.javascript.jscomp.ClosureCodingConvention();
        boolean boolean58 = closureCodingConvention56.isSuperClassReference("hi!");
        boolean boolean60 = closureCodingConvention56.isSuperClassReference("{proxy:function ({1566169663}, {({1804413486},{656799354})}): {1133890062}}");
        com.google.javascript.rhino.Node node64 = com.google.javascript.rhino.Node.newNumber((double) (short) -1, (int) (byte) 1, 0);
        com.google.javascript.rhino.Node node68 = com.google.javascript.rhino.Node.newNumber((double) (short) -1, (int) (byte) 1, 0);
        boolean boolean69 = node68.isArrayLit();
        com.google.javascript.rhino.Node node73 = com.google.javascript.rhino.Node.newNumber((double) (short) -1, (int) (byte) 1, 0);
        com.google.javascript.rhino.Node node74 = com.google.javascript.rhino.IR.getelem(node68, node73);
        com.google.javascript.rhino.Node node75 = node64.copyInformationFrom(node74);
        com.google.javascript.rhino.Node node76 = node74.cloneNode();
        com.google.javascript.rhino.Node node77 = com.google.javascript.rhino.IR.voidNode(node76);
        com.google.javascript.rhino.Node node81 = com.google.javascript.rhino.Node.newNumber((double) (short) -1, (int) (byte) 1, 0);
        boolean boolean82 = node81.isArrayLit();
        boolean boolean83 = node81.isLabelName();
        com.google.javascript.rhino.Node node84 = node81.getLastChild();
        java.lang.String str85 = closureCodingConvention56.extractClassNameIfRequire(node77, node81);
        com.google.javascript.rhino.jstype.JSType jSType86 = null;
        try {
            com.google.javascript.rhino.jstype.EnumType enumType87 = jSTypeRegistry2.createEnumType("boolean", node77, jSType86);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + jSTypeNative14 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative14.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative15 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative15.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative16 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative16.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray17);
        org.junit.Assert.assertNotNull(jSType18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + jSTypeNative24 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative24.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative25 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative25.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative26 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative26.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray27);
        org.junit.Assert.assertNotNull(jSType28);
        org.junit.Assert.assertTrue("'" + jSTypeNative32 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative32.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative33 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative33.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative34 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative34.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray35);
        org.junit.Assert.assertNotNull(jSType36);
        org.junit.Assert.assertNull(jSDocInfo37);
        org.junit.Assert.assertNull(objectType38);
        org.junit.Assert.assertNotNull(jSTypeArray39);
        org.junit.Assert.assertNotNull(functionType40);
        org.junit.Assert.assertTrue("'" + jSTypeNative44 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative44.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative45 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative45.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative46 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative46.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray47);
        org.junit.Assert.assertNotNull(jSType48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNotNull(parameterizedType50);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + true + "'", boolean51 == true);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertNotNull(obj53);
        org.junit.Assert.assertNotNull(objectType54);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertNotNull(node64);
        org.junit.Assert.assertNotNull(node68);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
        org.junit.Assert.assertNotNull(node73);
        org.junit.Assert.assertNotNull(node74);
        org.junit.Assert.assertNotNull(node75);
        org.junit.Assert.assertNotNull(node76);
        org.junit.Assert.assertNotNull(node77);
        org.junit.Assert.assertNotNull(node81);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + false + "'", boolean83 == false);
        org.junit.Assert.assertNull(node84);
        org.junit.Assert.assertNull(str85);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.DUPLICATE_VARS;
        com.google.javascript.jscomp.DiagnosticGroups.ES5_STRICT = diagnosticGroup0;
        java.lang.Iterable<com.google.javascript.jscomp.DiagnosticType> diagnosticTypeIterable2 = diagnosticGroup0.getTypes();
        com.google.javascript.jscomp.DiagnosticGroups.INTERNET_EXPLORER_CHECKS = diagnosticGroup0;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
        org.junit.Assert.assertNotNull(diagnosticTypeIterable2);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, true);
        com.google.javascript.rhino.ErrorReporter errorReporter3 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter3, true);
        com.google.javascript.rhino.ErrorReporter errorReporter6 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry8 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter6, true);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative9 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative10 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative11 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray12 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative9, jSTypeNative10, jSTypeNative11 };
        com.google.javascript.rhino.jstype.JSType jSType13 = jSTypeRegistry8.createUnionType(jSTypeNativeArray12);
        boolean boolean14 = jSType13.isRegexpType();
        boolean boolean15 = jSType13.isNullable();
        com.google.javascript.rhino.ErrorReporter errorReporter16 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry18 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter16, true);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative19 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative20 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative21 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray22 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative19, jSTypeNative20, jSTypeNative21 };
        com.google.javascript.rhino.jstype.JSType jSType23 = jSTypeRegistry18.createUnionType(jSTypeNativeArray22);
        com.google.javascript.rhino.ErrorReporter errorReporter24 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry26 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter24, true);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative27 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative28 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative29 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray30 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative27, jSTypeNative28, jSTypeNative29 };
        com.google.javascript.rhino.jstype.JSType jSType31 = jSTypeRegistry26.createUnionType(jSTypeNativeArray30);
        com.google.javascript.rhino.JSDocInfo jSDocInfo32 = jSType31.getJSDocInfo();
        com.google.javascript.rhino.jstype.ObjectType objectType33 = jSType31.toObjectType();
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray34 = new com.google.javascript.rhino.jstype.JSType[] { jSType23, jSType31 };
        com.google.javascript.rhino.jstype.FunctionType functionType35 = jSTypeRegistry5.createConstructorTypeWithVarArgs(jSType13, jSTypeArray34);
        com.google.javascript.rhino.ErrorReporter errorReporter36 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry38 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter36, true);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative39 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative40 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative41 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray42 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative39, jSTypeNative40, jSTypeNative41 };
        com.google.javascript.rhino.jstype.JSType jSType43 = jSTypeRegistry38.createUnionType(jSTypeNativeArray42);
        boolean boolean44 = jSType43.isStringObjectType();
        com.google.javascript.rhino.jstype.ParameterizedType parameterizedType45 = jSTypeRegistry2.createParameterizedType((com.google.javascript.rhino.jstype.ObjectType) functionType35, jSType43);
        int int46 = functionType35.getMinArguments();
        boolean boolean47 = functionType35.isVoidType();
        com.google.javascript.rhino.jstype.JSType jSType48 = functionType35.getParameterType();
        boolean boolean49 = functionType35.isInstanceType();
        boolean boolean50 = functionType35.hasAnyTemplateInternal();
        com.google.javascript.rhino.Node node52 = functionType35.getPropertyNode("{proxy:function ({1566169663}, {({1804413486},{656799354})}): {1133890062}}");
        org.junit.Assert.assertTrue("'" + jSTypeNative9 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative9.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative10 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative10.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative11 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative11.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray12);
        org.junit.Assert.assertNotNull(jSType13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + jSTypeNative19 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative19.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative20 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative20.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative21 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative21.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray22);
        org.junit.Assert.assertNotNull(jSType23);
        org.junit.Assert.assertTrue("'" + jSTypeNative27 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative27.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative28 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative28.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative29 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative29.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray30);
        org.junit.Assert.assertNotNull(jSType31);
        org.junit.Assert.assertNull(jSDocInfo32);
        org.junit.Assert.assertNull(objectType33);
        org.junit.Assert.assertNotNull(jSTypeArray34);
        org.junit.Assert.assertNotNull(functionType35);
        org.junit.Assert.assertTrue("'" + jSTypeNative39 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative39.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative40 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative40.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative41 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative41.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray42);
        org.junit.Assert.assertNotNull(jSType43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(parameterizedType45);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 1 + "'", int46 == 1);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNull(jSType48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNull(node52);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newNumber(0.0d, 29, 38);
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newNumber((double) (short) -1, (int) (byte) 1, 0);
        boolean boolean9 = node8.isArrayLit();
        boolean boolean10 = node8.isLabelName();
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.Node.newNumber((double) (short) -1, (int) (byte) 1, 0);
        boolean boolean15 = node14.isArrayLit();
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.Node.newNumber((double) (short) -1, (int) (byte) 1, 0);
        com.google.javascript.rhino.Node node20 = new com.google.javascript.rhino.Node((int) '#', node8, node14, node19);
        com.google.javascript.rhino.Node node22 = com.google.javascript.rhino.Node.newNumber(0.0d);
        com.google.javascript.rhino.Node node23 = node8.copyInformationFromForTree(node22);
        boolean boolean24 = node23.isAssign();
        com.google.javascript.rhino.Node node28 = com.google.javascript.rhino.Node.newNumber((double) (short) -1, (int) (byte) 1, 0);
        node23.addChildrenToFront(node28);
        node28.setLineno((int) (byte) 1);
        boolean boolean32 = node3.hasChild(node28);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        com.google.javascript.jscomp.DiagnosticType diagnosticType0 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention1 = new com.google.javascript.jscomp.GoogleCodingConvention();
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention2 = new com.google.javascript.jscomp.GoogleCodingConvention((com.google.javascript.jscomp.CodingConvention) googleCodingConvention1);
        boolean boolean3 = diagnosticType0.equals((java.lang.Object) googleCodingConvention2);
        boolean boolean5 = googleCodingConvention2.isConstantKey("hi!");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention6 = new com.google.javascript.jscomp.ClosureCodingConvention((com.google.javascript.jscomp.CodingConvention) googleCodingConvention2);
        boolean boolean8 = closureCodingConvention6.isSuperClassReference("DiagnosticGroup<duplicate>");
        org.junit.Assert.assertNotNull(diagnosticType0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention0 = new com.google.javascript.jscomp.GoogleCodingConvention();
        boolean boolean3 = googleCodingConvention0.isExported("", false);
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.Node.newNumber((double) (short) -1, (int) (byte) 1, 0);
        int int8 = node7.getSourcePosition();
        boolean boolean9 = node7.isWith();
        com.google.javascript.jscomp.CodingConvention.Bind bind10 = googleCodingConvention0.describeFunctionBind(node7);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 4096 + "'", int8 == 4096);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(bind10);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.trueNode();
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.exprResult(node0);
        boolean boolean2 = node1.isAssign();
        com.google.javascript.rhino.Node.AncestorIterable ancestorIterable3 = node1.getAncestors();
        int int4 = node1.getCharno();
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newNumber((double) (short) -1, (int) (byte) 1, 0);
        boolean boolean9 = node8.isArrayLit();
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newNumber((double) (short) -1, (int) (byte) 1, 0);
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.IR.getelem(node8, node13);
        boolean boolean15 = node13.isTrue();
        try {
            com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.IR.sub(node1, node13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(ancestorIterable3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, true);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative3 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative4 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative5 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray6 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative3, jSTypeNative4, jSTypeNative5 };
        com.google.javascript.rhino.jstype.JSType jSType7 = jSTypeRegistry2.createUnionType(jSTypeNativeArray6);
        jSTypeRegistry2.clearTemplateTypeNames();
        boolean boolean10 = jSTypeRegistry2.hasNamespace("Unknown class name");
        com.google.javascript.rhino.ErrorReporter errorReporter11 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry13 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter11, true);
        com.google.javascript.rhino.ErrorReporter errorReporter14 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry16 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter14, true);
        com.google.javascript.rhino.ErrorReporter errorReporter17 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry19 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter17, true);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative20 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative21 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative22 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray23 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative20, jSTypeNative21, jSTypeNative22 };
        com.google.javascript.rhino.jstype.JSType jSType24 = jSTypeRegistry19.createUnionType(jSTypeNativeArray23);
        boolean boolean25 = jSType24.isRegexpType();
        boolean boolean26 = jSType24.isNullable();
        com.google.javascript.rhino.ErrorReporter errorReporter27 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry29 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter27, true);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative30 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative31 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative32 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray33 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative30, jSTypeNative31, jSTypeNative32 };
        com.google.javascript.rhino.jstype.JSType jSType34 = jSTypeRegistry29.createUnionType(jSTypeNativeArray33);
        com.google.javascript.rhino.ErrorReporter errorReporter35 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry37 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter35, true);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative38 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative39 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative40 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray41 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative38, jSTypeNative39, jSTypeNative40 };
        com.google.javascript.rhino.jstype.JSType jSType42 = jSTypeRegistry37.createUnionType(jSTypeNativeArray41);
        com.google.javascript.rhino.JSDocInfo jSDocInfo43 = jSType42.getJSDocInfo();
        com.google.javascript.rhino.jstype.ObjectType objectType44 = jSType42.toObjectType();
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray45 = new com.google.javascript.rhino.jstype.JSType[] { jSType34, jSType42 };
        com.google.javascript.rhino.jstype.FunctionType functionType46 = jSTypeRegistry16.createConstructorTypeWithVarArgs(jSType24, jSTypeArray45);
        com.google.javascript.rhino.ErrorReporter errorReporter47 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry49 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter47, true);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative50 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative51 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative52 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray53 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative50, jSTypeNative51, jSTypeNative52 };
        com.google.javascript.rhino.jstype.JSType jSType54 = jSTypeRegistry49.createUnionType(jSTypeNativeArray53);
        boolean boolean55 = jSType54.isStringObjectType();
        com.google.javascript.rhino.jstype.ParameterizedType parameterizedType56 = jSTypeRegistry13.createParameterizedType((com.google.javascript.rhino.jstype.ObjectType) functionType46, jSType54);
        com.google.javascript.rhino.jstype.JSType jSType57 = parameterizedType56.getParameterType();
        com.google.javascript.rhino.jstype.JSType jSType58 = parameterizedType56.getIndexType();
        com.google.javascript.rhino.jstype.ObjectType objectType59 = null;
        boolean boolean60 = jSTypeRegistry2.resetImplicitPrototype((com.google.javascript.rhino.jstype.JSType) parameterizedType56, objectType59);
        boolean boolean62 = parameterizedType56.isPropertyInExterns("{proxy:function ({1047075399}, {({605412354},{558514873})}): {1793560964}}");
        com.google.javascript.rhino.jstype.UnionType unionType63 = parameterizedType56.toMaybeUnionType();
        com.google.javascript.rhino.jstype.JSType jSType65 = parameterizedType56.getPropertyType("DependencyInfo(relativePath='', path='GETELEM', provides=[hi!], requires=[hi!])");
        org.junit.Assert.assertTrue("'" + jSTypeNative3 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative3.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative4 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative4.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative5 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative5.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray6);
        org.junit.Assert.assertNotNull(jSType7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + jSTypeNative20 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative20.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative21 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative21.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative22 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative22.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray23);
        org.junit.Assert.assertNotNull(jSType24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + jSTypeNative30 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative30.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative31 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative31.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative32 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative32.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray33);
        org.junit.Assert.assertNotNull(jSType34);
        org.junit.Assert.assertTrue("'" + jSTypeNative38 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative38.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative39 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative39.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative40 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative40.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray41);
        org.junit.Assert.assertNotNull(jSType42);
        org.junit.Assert.assertNull(jSDocInfo43);
        org.junit.Assert.assertNull(objectType44);
        org.junit.Assert.assertNotNull(jSTypeArray45);
        org.junit.Assert.assertNotNull(functionType46);
        org.junit.Assert.assertTrue("'" + jSTypeNative50 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative50.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative51 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative51.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative52 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative52.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray53);
        org.junit.Assert.assertNotNull(jSType54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNotNull(parameterizedType56);
        org.junit.Assert.assertNotNull(jSType57);
        org.junit.Assert.assertNull(jSType58);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertNull(unionType63);
        org.junit.Assert.assertNotNull(jSType65);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newNumber((double) (short) -1, (int) (byte) 1, 0);
        boolean boolean4 = node3.isArrayLit();
        com.google.javascript.rhino.jstype.StaticSourceFile staticSourceFile5 = com.google.javascript.jscomp.NodeUtil.getSourceFile(node3);
        boolean boolean6 = node3.hasOneChild();
        java.util.Set<java.lang.String> strSet7 = node3.getDirectives();
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder8 = node3.getJsDocBuilderForNode();
        boolean boolean9 = node3.isLocalResultCall();
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(staticSourceFile5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(strSet7);
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        com.google.javascript.jscomp.ClosureCodingConvention.AssertInstanceofSpec assertInstanceofSpec2 = new com.google.javascript.jscomp.ClosureCodingConvention.AssertInstanceofSpec("");
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newNumber((double) (short) -1, (int) (byte) 1, 0);
        boolean boolean7 = node6.isArrayLit();
        boolean boolean8 = node6.isLabelName();
        com.google.javascript.rhino.Node node9 = node6.cloneNode();
        com.google.javascript.rhino.ErrorReporter errorReporter10 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry12 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter10, true);
        com.google.javascript.rhino.jstype.JSType jSType17 = jSTypeRegistry12.createNamedType("GETELEM", "hi!", 0, 38);
        jSTypeRegistry12.incrementGeneration();
        com.google.javascript.rhino.ErrorReporter errorReporter19 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry21 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter19, true);
        com.google.javascript.rhino.ErrorReporter errorReporter22 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry24 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter22, true);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative25 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative26 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative27 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray28 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative25, jSTypeNative26, jSTypeNative27 };
        com.google.javascript.rhino.jstype.JSType jSType29 = jSTypeRegistry24.createUnionType(jSTypeNativeArray28);
        boolean boolean30 = jSType29.isRegexpType();
        boolean boolean31 = jSType29.isNullable();
        com.google.javascript.rhino.ErrorReporter errorReporter32 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry34 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter32, true);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative35 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative36 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative37 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray38 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative35, jSTypeNative36, jSTypeNative37 };
        com.google.javascript.rhino.jstype.JSType jSType39 = jSTypeRegistry34.createUnionType(jSTypeNativeArray38);
        com.google.javascript.rhino.ErrorReporter errorReporter40 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry42 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter40, true);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative43 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative44 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative45 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray46 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative43, jSTypeNative44, jSTypeNative45 };
        com.google.javascript.rhino.jstype.JSType jSType47 = jSTypeRegistry42.createUnionType(jSTypeNativeArray46);
        com.google.javascript.rhino.JSDocInfo jSDocInfo48 = jSType47.getJSDocInfo();
        com.google.javascript.rhino.jstype.ObjectType objectType49 = jSType47.toObjectType();
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray50 = new com.google.javascript.rhino.jstype.JSType[] { jSType39, jSType47 };
        com.google.javascript.rhino.jstype.FunctionType functionType51 = jSTypeRegistry21.createConstructorTypeWithVarArgs(jSType29, jSTypeArray50);
        java.lang.Iterable iterable52 = functionType51.getCtorImplementedInterfaces();
        jSTypeRegistry12.resolveTypesInScope((com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType>) functionType51);
        com.google.javascript.rhino.jstype.JSType jSType54 = assertInstanceofSpec2.getAssertedType(node9, jSTypeRegistry12);
        boolean boolean55 = node9.isName();
        boolean boolean56 = node9.isCatch();
        com.google.javascript.rhino.Node node59 = new com.google.javascript.rhino.Node(100, node9, 52, 1);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(jSType17);
        org.junit.Assert.assertTrue("'" + jSTypeNative25 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative25.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative26 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative26.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative27 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative27.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray28);
        org.junit.Assert.assertNotNull(jSType29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + jSTypeNative35 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative35.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative36 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative36.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative37 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative37.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray38);
        org.junit.Assert.assertNotNull(jSType39);
        org.junit.Assert.assertTrue("'" + jSTypeNative43 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative43.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative44 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative44.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative45 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative45.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray46);
        org.junit.Assert.assertNotNull(jSType47);
        org.junit.Assert.assertNull(jSDocInfo48);
        org.junit.Assert.assertNull(objectType49);
        org.junit.Assert.assertNotNull(jSTypeArray50);
        org.junit.Assert.assertNotNull(functionType51);
        org.junit.Assert.assertNotNull(iterable52);
        org.junit.Assert.assertNotNull(jSType54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
    }
}

