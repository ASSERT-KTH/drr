import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        int int0 = com.google.javascript.rhino.Context.VERSION_1_0;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 100 + "'", int0 == 100);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.brokenClosureRequiresLevel;
        com.google.javascript.jscomp.CheckLevel checkLevel2 = com.google.javascript.jscomp.CheckLevel.WARNING;
        compilerOptions0.checkGlobalNamesLevel = checkLevel2;
        compilerOptions0.computeFunctionSideEffects = true;
        compilerOptions0.setShadowVariables(true);
        compilerOptions0.debugFunctionSideEffectsPath = "goog.global";
        boolean boolean10 = compilerOptions0.instrumentForCoverageOnly;
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + checkLevel2 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel2.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.brokenClosureRequiresLevel;
        com.google.javascript.jscomp.CheckLevel checkLevel2 = com.google.javascript.jscomp.CheckLevel.WARNING;
        compilerOptions0.checkGlobalNamesLevel = checkLevel2;
        compilerOptions0.computeFunctionSideEffects = true;
        boolean boolean6 = compilerOptions0.removeDeadCode;
        compilerOptions0.removeUnusedLocalVars = true;
        boolean boolean9 = compilerOptions0.optimizeArgumentsArray;
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + checkLevel2 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel2.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        com.google.javascript.rhino.Context context0 = com.google.javascript.rhino.Context.enter();
        boolean boolean1 = context0.isGeneratingSource();
        com.google.javascript.rhino.ErrorReporter errorReporter2 = context0.getErrorReporter();
        com.google.javascript.rhino.ErrorReporter errorReporter3 = context0.getErrorReporter();
        context0.setLanguageVersion(120);
        org.junit.Assert.assertNotNull(context0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNull(errorReporter2);
        org.junit.Assert.assertNull(errorReporter3);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.brokenClosureRequiresLevel;
        com.google.javascript.jscomp.CheckLevel checkLevel2 = com.google.javascript.jscomp.CheckLevel.WARNING;
        compilerOptions0.checkGlobalNamesLevel = checkLevel2;
        compilerOptions0.computeFunctionSideEffects = true;
        boolean boolean6 = compilerOptions0.removeDeadCode;
        compilerOptions0.inlineVariables = true;
        compilerOptions0.reserveRawExports = false;
        com.google.javascript.jscomp.SourceMap.DetailLevel detailLevel11 = compilerOptions0.sourceMapDetailLevel;
        compilerOptions0.jsOutputFile = "";
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + checkLevel2 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel2.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(detailLevel11);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile5 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.CompilerInput compilerInput6 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile5);
        com.google.javascript.jscomp.CompilerInput compilerInput9 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput6, "hi!", false);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile11 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        compilerInput6.setSourceFile((com.google.javascript.jscomp.SourceFile) jSSourceFile11);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile14 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray15 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile2, jSSourceFile11, jSSourceFile14 };
        java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList16 = new java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile>();
        boolean boolean17 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList16, jSSourceFileArray15);
        com.google.javascript.jscomp.JSModule[] jSModuleArray18 = new com.google.javascript.jscomp.JSModule[] {};
        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList19 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
        boolean boolean20 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList19, jSModuleArray18);
        com.google.javascript.jscomp.CompilerOptions compilerOptions21 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions21.checkDuplicateMessages = false;
        boolean boolean24 = compilerOptions21.inlineAnonymousFunctionExpressions;
        compilerOptions21.crossModuleMethodMotion = true;
        com.google.javascript.jscomp.Result result27 = compiler0.compileModules((java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList16, (java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList19, compilerOptions21);
        boolean boolean28 = compiler0.acceptConstKeyword();
        boolean boolean29 = compiler0.hasErrors();
        org.junit.Assert.assertNotNull(jSSourceFile2);
        org.junit.Assert.assertNotNull(jSSourceFile5);
        org.junit.Assert.assertNotNull(jSSourceFile11);
        org.junit.Assert.assertNotNull(jSSourceFile14);
        org.junit.Assert.assertNotNull(jSSourceFileArray15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(jSModuleArray18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(result27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.brokenClosureRequiresLevel;
        com.google.javascript.jscomp.CheckLevel checkLevel2 = com.google.javascript.jscomp.CheckLevel.WARNING;
        compilerOptions0.checkGlobalNamesLevel = checkLevel2;
        compilerOptions0.computeFunctionSideEffects = true;
        compilerOptions0.closurePass = false;
        boolean boolean8 = compilerOptions0.crossModuleMethodMotion;
        compilerOptions0.inlineLocalVariables = true;
        compilerOptions0.checkSymbols = true;
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + checkLevel2 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel2.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray13 = new com.google.javascript.rhino.Node[] { node4, node6, node8, node10, node12 };
        com.google.javascript.rhino.Node node14 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray13);
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node21 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray26 = new com.google.javascript.rhino.Node[] { node17, node19, node21, node23, node25 };
        com.google.javascript.rhino.Node node27 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray26);
        com.google.javascript.rhino.Node node28 = new com.google.javascript.rhino.Node(100, node14, node27);
        boolean boolean29 = closureCodingConvention0.isVarArgsParameter(node28);
        java.lang.String str30 = closureCodingConvention0.getExportPropertyFunction();
        boolean boolean32 = closureCodingConvention0.isConstant("hi!");
        com.google.javascript.rhino.jstype.FunctionType functionType33 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType34 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType35 = null;
        closureCodingConvention0.applySubclassRelationship(functionType33, functionType34, subclassType35);
        boolean boolean38 = closureCodingConvention0.isPrivate("JSC_OPTIMIZE_LOOP_ERROR");
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(nodeArray13);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNotNull(nodeArray26);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "goog.exportProperty" + "'", str30.equals("goog.exportProperty"));
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray11 = new com.google.javascript.rhino.Node[] { node2, node4, node6, node8, node10 };
        com.google.javascript.rhino.Node node12 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray11);
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node15 = node12.copyInformationFrom(node14);
        node14.setIsSyntheticBlock(true);
        com.google.javascript.rhino.Node node18 = node14.getLastSibling();
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(nodeArray11);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertNotNull(node18);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.brokenClosureRequiresLevel;
        com.google.javascript.jscomp.CheckLevel checkLevel2 = com.google.javascript.jscomp.CheckLevel.WARNING;
        compilerOptions0.checkGlobalNamesLevel = checkLevel2;
        compilerOptions0.computeFunctionSideEffects = true;
        compilerOptions0.closurePass = false;
        boolean boolean8 = compilerOptions0.crossModuleMethodMotion;
        compilerOptions0.inlineLocalVariables = true;
        compilerOptions0.setTweakToNumberLiteral(": WARNING - {0}\n", 0);
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + checkLevel2 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel2.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        com.google.javascript.rhino.Node.SideEffectFlags sideEffectFlags1 = new com.google.javascript.rhino.Node.SideEffectFlags(17);
        sideEffectFlags1.setAllFlags();
        int int3 = sideEffectFlags1.valueOf();
        sideEffectFlags1.setReturnsTainted();
        sideEffectFlags1.clearAllFlags();
        sideEffectFlags1.setMutatesThis();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.brokenClosureRequiresLevel;
        com.google.javascript.jscomp.CheckLevel checkLevel2 = com.google.javascript.jscomp.CheckLevel.WARNING;
        compilerOptions0.checkGlobalNamesLevel = checkLevel2;
        compilerOptions0.renamePrefix = "hi!";
        compilerOptions0.inferTypesInGlobalScope = true;
        compilerOptions0.crossModuleMethodMotion = false;
        boolean boolean10 = compilerOptions0.ignoreCajaProperties;
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + checkLevel2 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel2.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        java.lang.String str1 = com.google.javascript.rhino.jstype.ObjectType.createDelegateSuffix(": WARNING - {0}\n");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "(: WARNING - {0}\n)" + "'", str1.equals("(: WARNING - {0}\n)"));
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.brokenClosureRequiresLevel;
        com.google.javascript.jscomp.CheckLevel checkLevel2 = com.google.javascript.jscomp.CheckLevel.WARNING;
        compilerOptions0.checkGlobalNamesLevel = checkLevel2;
        compilerOptions0.computeFunctionSideEffects = true;
        compilerOptions0.closurePass = false;
        com.google.javascript.jscomp.CompilerOptions compilerOptions8 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel9 = compilerOptions8.brokenClosureRequiresLevel;
        compilerOptions0.checkGlobalThisLevel = checkLevel9;
        compilerOptions0.collapseVariableDeclarations = false;
        compilerOptions0.generateExports = false;
        boolean boolean15 = compilerOptions0.moveFunctionDeclarations;
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + checkLevel2 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel2.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
        org.junit.Assert.assertTrue("'" + checkLevel9 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel9.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile3 = com.google.javascript.jscomp.JSSourceFile.fromFile("Not declared as a constructor");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile5 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.CompilerInput compilerInput6 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile5);
        com.google.javascript.jscomp.CompilerInput compilerInput9 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput6, "hi!", false);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile11 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        compilerInput6.setSourceFile((com.google.javascript.jscomp.SourceFile) jSSourceFile11);
        java.lang.String str13 = jSSourceFile11.toString();
        com.google.javascript.jscomp.CompilerOptions compilerOptions14 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean15 = compilerOptions14.aliasAllStrings;
        compilerOptions14.setGenerateExports(true);
        com.google.javascript.jscomp.Result result18 = compiler1.compile(jSSourceFile3, jSSourceFile11, compilerOptions14);
        compilerOptions14.syntheticBlockEndMarker = "Not declared as a type name";
        compilerOptions14.generatePseudoNames = true;
        compilerOptions14.locale = "TypeError: ";
        org.junit.Assert.assertNotNull(jSSourceFile3);
        org.junit.Assert.assertNotNull(jSSourceFile5);
        org.junit.Assert.assertNotNull(jSSourceFile11);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(result18);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention1 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray14 = new com.google.javascript.rhino.Node[] { node5, node7, node9, node11, node13 };
        com.google.javascript.rhino.Node node15 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray14);
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node22 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node24 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node26 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray27 = new com.google.javascript.rhino.Node[] { node18, node20, node22, node24, node26 };
        com.google.javascript.rhino.Node node28 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray27);
        com.google.javascript.rhino.Node node29 = new com.google.javascript.rhino.Node(100, node15, node28);
        boolean boolean30 = closureCodingConvention1.isVarArgsParameter(node29);
        com.google.javascript.rhino.Node node31 = new com.google.javascript.rhino.Node(0, node29);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(nodeArray14);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertNotNull(nodeArray27);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray12 = new com.google.javascript.rhino.Node[] { node3, node5, node7, node9, node11 };
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray12);
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node16 = node13.copyInformationFrom(node15);
        com.google.javascript.rhino.Node node17 = node13.getParent();
        com.google.javascript.rhino.Node node18 = new com.google.javascript.rhino.Node((int) (short) -1, node13);
        boolean boolean19 = node13.isSyntheticBlock();
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertNotNull(nodeArray12);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertNull(node17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.CHECK_VARIABLES;
        com.google.javascript.jscomp.DiagnosticGroups.TWEAKS = diagnosticGroup0;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile3 = com.google.javascript.jscomp.JSSourceFile.fromFile("Not declared as a constructor");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile5 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.CompilerInput compilerInput6 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile5);
        com.google.javascript.jscomp.CompilerInput compilerInput9 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput6, "hi!", false);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile11 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        compilerInput6.setSourceFile((com.google.javascript.jscomp.SourceFile) jSSourceFile11);
        java.lang.String str13 = jSSourceFile11.toString();
        com.google.javascript.jscomp.CompilerOptions compilerOptions14 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean15 = compilerOptions14.aliasAllStrings;
        compilerOptions14.setGenerateExports(true);
        com.google.javascript.jscomp.Result result18 = compiler1.compile(jSSourceFile3, jSSourceFile11, compilerOptions14);
        com.google.javascript.jscomp.Compiler.IntermediateState intermediateState19 = compiler1.getState();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile21 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.CompilerInput compilerInput22 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile21);
        com.google.javascript.jscomp.JSModule[] jSModuleArray23 = new com.google.javascript.jscomp.JSModule[] {};
        java.io.PrintStream printStream24 = null;
        com.google.javascript.jscomp.Compiler compiler25 = new com.google.javascript.jscomp.Compiler(printStream24);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile27 = com.google.javascript.jscomp.JSSourceFile.fromFile("Not declared as a constructor");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile29 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.CompilerInput compilerInput30 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile29);
        com.google.javascript.jscomp.CompilerInput compilerInput33 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput30, "hi!", false);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile35 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        compilerInput30.setSourceFile((com.google.javascript.jscomp.SourceFile) jSSourceFile35);
        java.lang.String str37 = jSSourceFile35.toString();
        com.google.javascript.jscomp.CompilerOptions compilerOptions38 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean39 = compilerOptions38.aliasAllStrings;
        compilerOptions38.setGenerateExports(true);
        com.google.javascript.jscomp.Result result42 = compiler25.compile(jSSourceFile27, jSSourceFile35, compilerOptions38);
        compilerOptions38.inlineLocalFunctions = true;
        compilerOptions38.devirtualizePrototypeMethods = true;
        try {
            com.google.javascript.jscomp.Result result47 = compiler1.compile(jSSourceFile21, jSModuleArray23, compilerOptions38);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile3);
        org.junit.Assert.assertNotNull(jSSourceFile5);
        org.junit.Assert.assertNotNull(jSSourceFile11);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(result18);
        org.junit.Assert.assertNotNull(intermediateState19);
        org.junit.Assert.assertNotNull(jSSourceFile21);
        org.junit.Assert.assertNotNull(jSModuleArray23);
        org.junit.Assert.assertNotNull(jSSourceFile27);
        org.junit.Assert.assertNotNull(jSSourceFile29);
        org.junit.Assert.assertNotNull(jSSourceFile35);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "" + "'", str37.equals(""));
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(result42);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.brokenClosureRequiresLevel;
        compilerOptions0.setManageClosureDependencies(true);
        java.lang.String[] strArray11 = new java.lang.String[] { "goog.exportProperty", "Not declared as a type name", "error reporter", "DiagnosticGroup<undefinedVars>", "goog.exportProperty", "Not declared as a constructor" };
        java.util.ArrayList<java.lang.String> strList12 = new java.util.ArrayList<java.lang.String>();
        boolean boolean13 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strList12, strArray11);
        compilerOptions0.setReplaceStringsConfiguration("goog.exportProperty", (java.util.List<java.lang.String>) strList12);
        compilerOptions0.ideMode = false;
        byte[] byteArray22 = new byte[] { (byte) 100, (byte) 1, (byte) 10, (byte) 10, (byte) 1 };
        compilerOptions0.inputVariableMapSerialized = byteArray22;
        com.google.javascript.jscomp.MessageBundle messageBundle24 = compilerOptions0.messageBundle;
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(strArray11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(byteArray22);
        org.junit.Assert.assertNull(messageBundle24);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.aliasAllStrings;
        compilerOptions0.setGenerateExports(true);
        compilerOptions0.setDefineToStringLiteral("JSC_OPTIMIZE_LOOP_ERROR", "1");
        compilerOptions0.allowLegacyJsMessages = false;
        boolean boolean9 = compilerOptions0.removeEmptyFunctions;
        boolean boolean10 = compilerOptions0.groupVariableDeclarations;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.checkDuplicateMessages = false;
        boolean boolean3 = compilerOptions0.inlineAnonymousFunctionExpressions;
        compilerOptions0.recordFunctionInformation = true;
        boolean boolean6 = compilerOptions0.checkCaja;
        compilerOptions0.aliasableGlobals = "EOF 0";
        boolean boolean9 = compilerOptions0.removeEmptyFunctions;
        boolean boolean10 = compilerOptions0.deadAssignmentElimination;
        com.google.javascript.jscomp.CompilerOptions compilerOptions11 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel12 = compilerOptions11.brokenClosureRequiresLevel;
        com.google.javascript.jscomp.CheckLevel checkLevel13 = com.google.javascript.jscomp.CheckLevel.WARNING;
        compilerOptions11.checkGlobalNamesLevel = checkLevel13;
        com.google.javascript.jscomp.ErrorFormat errorFormat15 = null;
        compilerOptions11.errorFormat = errorFormat15;
        boolean boolean17 = compilerOptions11.ambiguateProperties;
        com.google.javascript.jscomp.CompilerOptions compilerOptions18 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel19 = compilerOptions18.brokenClosureRequiresLevel;
        compilerOptions18.setManageClosureDependencies(true);
        java.lang.String[] strArray29 = new java.lang.String[] { "goog.exportProperty", "Not declared as a type name", "error reporter", "DiagnosticGroup<undefinedVars>", "goog.exportProperty", "Not declared as a constructor" };
        java.util.ArrayList<java.lang.String> strList30 = new java.util.ArrayList<java.lang.String>();
        boolean boolean31 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strList30, strArray29);
        compilerOptions18.setReplaceStringsConfiguration("goog.exportProperty", (java.util.List<java.lang.String>) strList30);
        compilerOptions18.decomposeExpressions = false;
        com.google.javascript.jscomp.CheckLevel checkLevel35 = compilerOptions18.checkMissingGetCssNameLevel;
        compilerOptions11.checkGlobalThisLevel = checkLevel35;
        compilerOptions0.checkMethods = checkLevel35;
        java.util.Set<java.lang.String> strSet38 = compilerOptions0.stripTypePrefixes;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + checkLevel12 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel12.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + checkLevel13 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel13.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + checkLevel19 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel19.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(strArray29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertTrue("'" + checkLevel35 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel35.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(strSet38);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.brokenClosureRequiresLevel;
        java.util.Map<java.lang.String, com.google.javascript.rhino.Node> strMap2 = compilerOptions0.getDefineReplacements();
        boolean boolean3 = compilerOptions0.reserveRawExports;
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(strMap2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        com.google.javascript.jscomp.AbstractCompiler abstractCompiler0 = null;
        com.google.javascript.jscomp.NodeTraversal.Callback callback1 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal2 = new com.google.javascript.jscomp.NodeTraversal(abstractCompiler0, callback1);
        boolean boolean3 = nodeTraversal2.hasScope();
        com.google.javascript.rhino.Node node4 = nodeTraversal2.getEnclosingFunction();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(node4);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray13 = new com.google.javascript.rhino.Node[] { node4, node6, node8, node10, node12 };
        com.google.javascript.rhino.Node node14 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray13);
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node21 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray26 = new com.google.javascript.rhino.Node[] { node17, node19, node21, node23, node25 };
        com.google.javascript.rhino.Node node27 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray26);
        com.google.javascript.rhino.Node node28 = new com.google.javascript.rhino.Node(100, node14, node27);
        boolean boolean29 = closureCodingConvention0.isVarArgsParameter(node28);
        java.lang.String str30 = closureCodingConvention0.getExportPropertyFunction();
        boolean boolean33 = closureCodingConvention0.isExported("goog.exportProperty", false);
        com.google.javascript.rhino.Node node37 = com.google.javascript.rhino.Node.newNumber(100.0d, 4095, 9);
        java.util.Set<java.lang.String> strSet38 = node37.getDirectives();
        boolean boolean39 = closureCodingConvention0.isVarArgsParameter(node37);
        com.google.javascript.rhino.jstype.FunctionType functionType40 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType41 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType42 = null;
        closureCodingConvention0.applySubclassRelationship(functionType40, functionType41, subclassType42);
        com.google.javascript.rhino.Node node46 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node48 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node50 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node52 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node54 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray55 = new com.google.javascript.rhino.Node[] { node46, node48, node50, node52, node54 };
        com.google.javascript.rhino.Node node56 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray55);
        com.google.javascript.rhino.Node node60 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node62 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node64 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node66 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node68 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray69 = new com.google.javascript.rhino.Node[] { node60, node62, node64, node66, node68 };
        com.google.javascript.rhino.Node node70 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray69);
        com.google.javascript.rhino.Node node72 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node73 = node70.copyInformationFrom(node72);
        com.google.javascript.rhino.Node node74 = node70.getParent();
        com.google.javascript.rhino.Node node75 = new com.google.javascript.rhino.Node((int) (short) -1, node70);
        com.google.javascript.rhino.Node node80 = com.google.javascript.rhino.Node.newString((int) (short) 0, "hi!", 100, (-2));
        boolean boolean81 = node70.isEquivalentTo(node80);
        com.google.javascript.rhino.Node node82 = node56.clonePropsFrom(node80);
        java.lang.String str83 = com.google.javascript.rhino.ScriptRuntime.toString((java.lang.Object) node56);
        com.google.javascript.rhino.Node node87 = com.google.javascript.rhino.Node.newNumber(100.0d, 4095, 9);
        java.lang.String str88 = closureCodingConvention0.extractClassNameIfProvide(node56, node87);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(nodeArray13);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNotNull(nodeArray26);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "goog.exportProperty" + "'", str30.equals("goog.exportProperty"));
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(node37);
        org.junit.Assert.assertNull(strSet38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(node46);
        org.junit.Assert.assertNotNull(node48);
        org.junit.Assert.assertNotNull(node50);
        org.junit.Assert.assertNotNull(node52);
        org.junit.Assert.assertNotNull(node54);
        org.junit.Assert.assertNotNull(nodeArray55);
        org.junit.Assert.assertNotNull(node60);
        org.junit.Assert.assertNotNull(node62);
        org.junit.Assert.assertNotNull(node64);
        org.junit.Assert.assertNotNull(node66);
        org.junit.Assert.assertNotNull(node68);
        org.junit.Assert.assertNotNull(nodeArray69);
        org.junit.Assert.assertNotNull(node72);
        org.junit.Assert.assertNotNull(node73);
        org.junit.Assert.assertNull(node74);
        org.junit.Assert.assertNotNull(node80);
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + false + "'", boolean81 == false);
        org.junit.Assert.assertNotNull(node82);
        org.junit.Assert.assertTrue("'" + str83 + "' != '" + "EOF 0" + "'", str83.equals("EOF 0"));
        org.junit.Assert.assertNotNull(node87);
        org.junit.Assert.assertNull(str88);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.brokenClosureRequiresLevel;
        com.google.javascript.jscomp.CheckLevel checkLevel2 = com.google.javascript.jscomp.CheckLevel.WARNING;
        compilerOptions0.checkGlobalNamesLevel = checkLevel2;
        compilerOptions0.computeFunctionSideEffects = true;
        compilerOptions0.closurePass = false;
        compilerOptions0.markAsCompiled = true;
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + checkLevel2 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel2.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.brokenClosureRequiresLevel;
        com.google.javascript.jscomp.CheckLevel checkLevel2 = com.google.javascript.jscomp.CheckLevel.WARNING;
        compilerOptions0.checkGlobalNamesLevel = checkLevel2;
        compilerOptions0.computeFunctionSideEffects = true;
        compilerOptions0.setDefineToStringLiteral("", "Unknown class name");
        java.lang.String str9 = compilerOptions0.aliasableGlobals;
        byte[] byteArray10 = compilerOptions0.inputVariableMapSerialized;
        compilerOptions0.removeTryCatchFinally = false;
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + checkLevel2 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel2.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertNull(byteArray10);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray12 = new com.google.javascript.rhino.Node[] { node3, node5, node7, node9, node11 };
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray12);
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node16 = node13.copyInformationFrom(node15);
        com.google.javascript.rhino.Node node17 = node13.getParent();
        com.google.javascript.rhino.Node node18 = new com.google.javascript.rhino.Node((int) (short) -1, node13);
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newString((int) (short) 0, "hi!", 100, (-2));
        boolean boolean24 = node13.isEquivalentTo(node23);
        com.google.javascript.rhino.Node node27 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node29 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node31 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node33 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node35 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray36 = new com.google.javascript.rhino.Node[] { node27, node29, node31, node33, node35 };
        com.google.javascript.rhino.Node node37 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray36);
        com.google.javascript.rhino.Node node39 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node40 = node37.copyInformationFrom(node39);
        node23.addChildrenToFront(node37);
        com.google.javascript.rhino.Node node42 = node23.getLastChild();
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertNotNull(nodeArray12);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertNull(node17);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(node27);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertNotNull(node33);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertNotNull(nodeArray36);
        org.junit.Assert.assertNotNull(node39);
        org.junit.Assert.assertNotNull(node40);
        org.junit.Assert.assertNotNull(node42);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.aliasAllStrings;
        compilerOptions0.setGenerateExports(true);
        compilerOptions0.setDefineToStringLiteral("JSC_OPTIMIZE_LOOP_ERROR", "1");
        boolean boolean7 = compilerOptions0.printInputDelimiter;
        compilerOptions0.collapseProperties = false;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.brokenClosureRequiresLevel;
        com.google.javascript.jscomp.CheckLevel checkLevel2 = com.google.javascript.jscomp.CheckLevel.WARNING;
        compilerOptions0.checkGlobalNamesLevel = checkLevel2;
        compilerOptions0.computeFunctionSideEffects = true;
        compilerOptions0.closurePass = false;
        com.google.javascript.jscomp.CompilerOptions compilerOptions8 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel9 = compilerOptions8.brokenClosureRequiresLevel;
        compilerOptions0.checkGlobalThisLevel = checkLevel9;
        compilerOptions0.inlineLocalFunctions = false;
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + checkLevel2 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel2.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
        org.junit.Assert.assertTrue("'" + checkLevel9 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel9.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.brokenClosureRequiresLevel;
        com.google.javascript.jscomp.CheckLevel checkLevel2 = com.google.javascript.jscomp.CheckLevel.WARNING;
        compilerOptions0.checkGlobalNamesLevel = checkLevel2;
        compilerOptions0.computeFunctionSideEffects = true;
        compilerOptions0.setShadowVariables(true);
        compilerOptions0.debugFunctionSideEffectsPath = "goog.global";
        compilerOptions0.checkTypes = false;
        compilerOptions0.decomposeExpressions = false;
        boolean boolean14 = compilerOptions0.collapseAnonymousFunctions;
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + checkLevel2 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel2.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray13 = new com.google.javascript.rhino.Node[] { node4, node6, node8, node10, node12 };
        com.google.javascript.rhino.Node node14 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray13);
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node21 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray26 = new com.google.javascript.rhino.Node[] { node17, node19, node21, node23, node25 };
        com.google.javascript.rhino.Node node27 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray26);
        com.google.javascript.rhino.Node node28 = new com.google.javascript.rhino.Node(100, node14, node27);
        boolean boolean29 = closureCodingConvention0.isVarArgsParameter(node28);
        java.lang.String str30 = closureCodingConvention0.getExportPropertyFunction();
        boolean boolean33 = closureCodingConvention0.isExported("goog.exportProperty", false);
        com.google.javascript.rhino.Node node37 = com.google.javascript.rhino.Node.newNumber(100.0d, 4095, 9);
        java.util.Set<java.lang.String> strSet38 = node37.getDirectives();
        boolean boolean39 = closureCodingConvention0.isVarArgsParameter(node37);
        com.google.javascript.rhino.Node node42 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node44 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node46 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node48 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node50 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray51 = new com.google.javascript.rhino.Node[] { node42, node44, node46, node48, node50 };
        com.google.javascript.rhino.Node node52 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray51);
        int int53 = node52.getSideEffectFlags();
        node37.addChildrenToFront(node52);
        java.lang.String str55 = node52.toString();
        int int56 = node52.getChildCount();
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(nodeArray13);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNotNull(nodeArray26);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "goog.exportProperty" + "'", str30.equals("goog.exportProperty"));
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(node37);
        org.junit.Assert.assertNull(strSet38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(node42);
        org.junit.Assert.assertNotNull(node44);
        org.junit.Assert.assertNotNull(node46);
        org.junit.Assert.assertNotNull(node48);
        org.junit.Assert.assertNotNull(node50);
        org.junit.Assert.assertNotNull(nodeArray51);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 0 + "'", int53 == 0);
        org.junit.Assert.assertTrue("'" + str55 + "' != '" + "EOF 0" + "'", str55.equals("EOF 0"));
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 5 + "'", int56 == 5);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.NodeTraversal.Callback callback1 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal2 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler0, callback1);
        compiler0.disableThreads();
        java.lang.String str4 = compiler0.getAstDotGraph();
        com.google.javascript.jscomp.Compiler.IntermediateState intermediateState5 = null;
        try {
            compiler0.setState(intermediateState5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.checkDuplicateMessages = false;
        boolean boolean3 = compilerOptions0.inlineAnonymousFunctionExpressions;
        java.lang.String str4 = compilerOptions0.checkMissingGetCssNameBlacklist;
        compilerOptions0.inlineAnonymousFunctionExpressions = false;
        boolean boolean7 = compilerOptions0.checkSymbols;
        boolean boolean8 = compilerOptions0.checkTypes;
        java.lang.String str9 = compilerOptions0.instrumentationTemplate;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNull(str9);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        com.google.javascript.jscomp.MessageFormatter messageFormatter0 = null;
        java.util.logging.Logger logger1 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager2 = new com.google.javascript.jscomp.LoggerErrorManager(messageFormatter0, logger1);
        int int3 = loggerErrorManager2.getWarningCount();
        loggerErrorManager2.generateReport();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.brokenClosureRequiresLevel;
        compilerOptions0.setManageClosureDependencies(true);
        java.lang.String[] strArray11 = new java.lang.String[] { "goog.exportProperty", "Not declared as a type name", "error reporter", "DiagnosticGroup<undefinedVars>", "goog.exportProperty", "Not declared as a constructor" };
        java.util.ArrayList<java.lang.String> strList12 = new java.util.ArrayList<java.lang.String>();
        boolean boolean13 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strList12, strArray11);
        compilerOptions0.setReplaceStringsConfiguration("goog.exportProperty", (java.util.List<java.lang.String>) strList12);
        compilerOptions0.decomposeExpressions = false;
        com.google.javascript.jscomp.CheckLevel checkLevel17 = compilerOptions0.checkMissingGetCssNameLevel;
        byte[] byteArray18 = compilerOptions0.inputPropertyMapSerialized;
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(strArray11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + checkLevel17 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel17.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNull(byteArray18);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray13 = new com.google.javascript.rhino.Node[] { node4, node6, node8, node10, node12 };
        com.google.javascript.rhino.Node node14 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray13);
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node21 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray26 = new com.google.javascript.rhino.Node[] { node17, node19, node21, node23, node25 };
        com.google.javascript.rhino.Node node27 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray26);
        com.google.javascript.rhino.Node node28 = new com.google.javascript.rhino.Node(100, node14, node27);
        boolean boolean29 = closureCodingConvention0.isVarArgsParameter(node28);
        java.lang.String str30 = closureCodingConvention0.getExportPropertyFunction();
        boolean boolean33 = closureCodingConvention0.isExported("goog.exportProperty", false);
        com.google.javascript.rhino.Node node37 = com.google.javascript.rhino.Node.newNumber(100.0d, 4095, 9);
        java.util.Set<java.lang.String> strSet38 = node37.getDirectives();
        boolean boolean39 = closureCodingConvention0.isVarArgsParameter(node37);
        com.google.javascript.rhino.Node node42 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node44 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node46 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node48 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node50 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray51 = new com.google.javascript.rhino.Node[] { node42, node44, node46, node48, node50 };
        com.google.javascript.rhino.Node node52 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray51);
        com.google.javascript.rhino.Node node53 = node52.getNext();
        com.google.javascript.rhino.Node node57 = com.google.javascript.rhino.Node.newNumber(100.0d, 4095, 9);
        java.lang.String str58 = closureCodingConvention0.extractClassNameIfRequire(node52, node57);
        java.lang.String str59 = closureCodingConvention0.getGlobalObject();
        com.google.javascript.rhino.jstype.FunctionType functionType60 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType61 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType62 = null;
        try {
            closureCodingConvention0.applySingletonGetter(functionType60, functionType61, objectType62);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(nodeArray13);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNotNull(nodeArray26);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "goog.exportProperty" + "'", str30.equals("goog.exportProperty"));
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(node37);
        org.junit.Assert.assertNull(strSet38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(node42);
        org.junit.Assert.assertNotNull(node44);
        org.junit.Assert.assertNotNull(node46);
        org.junit.Assert.assertNotNull(node48);
        org.junit.Assert.assertNotNull(node50);
        org.junit.Assert.assertNotNull(nodeArray51);
        org.junit.Assert.assertNull(node53);
        org.junit.Assert.assertNotNull(node57);
        org.junit.Assert.assertNull(str58);
        org.junit.Assert.assertTrue("'" + str59 + "' != '" + "goog.global" + "'", str59.equals("goog.global"));
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.brokenClosureRequiresLevel;
        com.google.javascript.jscomp.CheckLevel checkLevel2 = com.google.javascript.jscomp.CheckLevel.WARNING;
        compilerOptions0.checkGlobalNamesLevel = checkLevel2;
        compilerOptions0.computeFunctionSideEffects = true;
        compilerOptions0.setDefineToStringLiteral("", "Unknown class name");
        compilerOptions0.checkTypedPropertyCalls = true;
        com.google.javascript.jscomp.ErrorFormat errorFormat11 = compilerOptions0.errorFormat;
        boolean boolean12 = compilerOptions0.gatherCssNames;
        com.google.javascript.jscomp.CheckLevel checkLevel13 = compilerOptions0.checkRequires;
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + checkLevel2 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel2.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
        org.junit.Assert.assertNotNull(errorFormat11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + checkLevel13 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel13.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        double double0 = com.google.javascript.rhino.ScriptRuntime.negativeZero;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + (-0.0d) + "'", double0 == (-0.0d));
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile3 = com.google.javascript.jscomp.JSSourceFile.fromFile("Not declared as a constructor");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile5 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.CompilerInput compilerInput6 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile5);
        com.google.javascript.jscomp.CompilerInput compilerInput9 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput6, "hi!", false);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile11 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        compilerInput6.setSourceFile((com.google.javascript.jscomp.SourceFile) jSSourceFile11);
        java.lang.String str13 = jSSourceFile11.toString();
        com.google.javascript.jscomp.CompilerOptions compilerOptions14 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean15 = compilerOptions14.aliasAllStrings;
        compilerOptions14.setGenerateExports(true);
        com.google.javascript.jscomp.Result result18 = compiler1.compile(jSSourceFile3, jSSourceFile11, compilerOptions14);
        com.google.javascript.jscomp.JsAst jsAst19 = new com.google.javascript.jscomp.JsAst((com.google.javascript.jscomp.SourceFile) jSSourceFile11);
        com.google.javascript.jscomp.SourceFile sourceFile23 = com.google.javascript.jscomp.SourceFile.fromCode("", "goog.exportProperty", "goog.exportSymbol");
        jsAst19.setSourceFile(sourceFile23);
        java.io.PrintStream printStream25 = null;
        com.google.javascript.jscomp.Compiler compiler26 = new com.google.javascript.jscomp.Compiler(printStream25);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile28 = com.google.javascript.jscomp.JSSourceFile.fromFile("Not declared as a constructor");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile30 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.CompilerInput compilerInput31 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile30);
        com.google.javascript.jscomp.CompilerInput compilerInput34 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput31, "hi!", false);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile36 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        compilerInput31.setSourceFile((com.google.javascript.jscomp.SourceFile) jSSourceFile36);
        java.lang.String str38 = jSSourceFile36.toString();
        com.google.javascript.jscomp.CompilerOptions compilerOptions39 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean40 = compilerOptions39.aliasAllStrings;
        compilerOptions39.setGenerateExports(true);
        com.google.javascript.jscomp.Result result43 = compiler26.compile(jSSourceFile28, jSSourceFile36, compilerOptions39);
        com.google.javascript.jscomp.CompilerInput compilerInput44 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile36);
        com.google.javascript.jscomp.CompilerInput compilerInput45 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput44);
        com.google.javascript.jscomp.JSModule jSModule46 = null;
        compilerInput44.setModule(jSModule46);
        com.google.javascript.jscomp.SourceAst sourceAst48 = compilerInput44.getSourceAst();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile50 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.CompilerInput compilerInput51 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile50);
        com.google.javascript.jscomp.CompilerInput compilerInput54 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput51, "hi!", false);
        com.google.javascript.jscomp.Compiler compiler55 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile57 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.CompilerInput compilerInput58 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile57);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile60 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.CompilerInput compilerInput61 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile60);
        com.google.javascript.jscomp.CompilerInput compilerInput64 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput61, "hi!", false);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile66 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        compilerInput61.setSourceFile((com.google.javascript.jscomp.SourceFile) jSSourceFile66);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile69 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray70 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile57, jSSourceFile66, jSSourceFile69 };
        java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList71 = new java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile>();
        boolean boolean72 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList71, jSSourceFileArray70);
        com.google.javascript.jscomp.JSModule[] jSModuleArray73 = new com.google.javascript.jscomp.JSModule[] {};
        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList74 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
        boolean boolean75 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList74, jSModuleArray73);
        com.google.javascript.jscomp.CompilerOptions compilerOptions76 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions76.checkDuplicateMessages = false;
        boolean boolean79 = compilerOptions76.inlineAnonymousFunctionExpressions;
        compilerOptions76.crossModuleMethodMotion = true;
        com.google.javascript.jscomp.Result result82 = compiler55.compileModules((java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList71, (java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList74, compilerOptions76);
        compilerInput51.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler55);
        com.google.javascript.jscomp.Scope scope84 = compiler55.getTopScope();
        com.google.javascript.rhino.Node node85 = compilerInput44.getAstRoot((com.google.javascript.jscomp.AbstractCompiler) compiler55);
        com.google.javascript.rhino.Node node86 = jsAst19.getAstRoot((com.google.javascript.jscomp.AbstractCompiler) compiler55);
        com.google.javascript.jscomp.Compiler compiler87 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.NodeTraversal.Callback callback88 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal89 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler87, callback88);
        com.google.javascript.rhino.Node node90 = jsAst19.getAstRoot((com.google.javascript.jscomp.AbstractCompiler) compiler87);
        org.junit.Assert.assertNotNull(jSSourceFile3);
        org.junit.Assert.assertNotNull(jSSourceFile5);
        org.junit.Assert.assertNotNull(jSSourceFile11);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(result18);
        org.junit.Assert.assertNotNull(sourceFile23);
        org.junit.Assert.assertNotNull(jSSourceFile28);
        org.junit.Assert.assertNotNull(jSSourceFile30);
        org.junit.Assert.assertNotNull(jSSourceFile36);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "" + "'", str38.equals(""));
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(result43);
        org.junit.Assert.assertNotNull(sourceAst48);
        org.junit.Assert.assertNotNull(jSSourceFile50);
        org.junit.Assert.assertNotNull(jSSourceFile57);
        org.junit.Assert.assertNotNull(jSSourceFile60);
        org.junit.Assert.assertNotNull(jSSourceFile66);
        org.junit.Assert.assertNotNull(jSSourceFile69);
        org.junit.Assert.assertNotNull(jSSourceFileArray70);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + true + "'", boolean72 == true);
        org.junit.Assert.assertNotNull(jSModuleArray73);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
        org.junit.Assert.assertNotNull(result82);
        org.junit.Assert.assertNull(scope84);
        org.junit.Assert.assertNull(node85);
        org.junit.Assert.assertNotNull(node86);
        org.junit.Assert.assertNotNull(node90);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile3 = com.google.javascript.jscomp.JSSourceFile.fromFile("Not declared as a constructor");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile5 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.CompilerInput compilerInput6 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile5);
        com.google.javascript.jscomp.CompilerInput compilerInput9 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput6, "hi!", false);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile11 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        compilerInput6.setSourceFile((com.google.javascript.jscomp.SourceFile) jSSourceFile11);
        java.lang.String str13 = jSSourceFile11.toString();
        com.google.javascript.jscomp.CompilerOptions compilerOptions14 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean15 = compilerOptions14.aliasAllStrings;
        compilerOptions14.setGenerateExports(true);
        com.google.javascript.jscomp.Result result18 = compiler1.compile(jSSourceFile3, jSSourceFile11, compilerOptions14);
        com.google.javascript.jscomp.CompilerInput compilerInput19 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile11);
        java.lang.String str20 = jSSourceFile11.toString();
        org.junit.Assert.assertNotNull(jSSourceFile3);
        org.junit.Assert.assertNotNull(jSSourceFile5);
        org.junit.Assert.assertNotNull(jSSourceFile11);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(result18);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "" + "'", str20.equals(""));
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.checkDuplicateMessages = false;
        boolean boolean3 = compilerOptions0.inlineAnonymousFunctionExpressions;
        compilerOptions0.recordFunctionInformation = true;
        boolean boolean6 = compilerOptions0.checkCaja;
        com.google.javascript.jscomp.CheckLevel checkLevel7 = compilerOptions0.checkUndefinedProperties;
        compilerOptions0.ideMode = false;
        compilerOptions0.strictMessageReplacement = false;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + checkLevel7 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel7.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.checkDuplicateMessages = false;
        boolean boolean3 = compilerOptions0.inlineAnonymousFunctionExpressions;
        java.lang.String str4 = compilerOptions0.checkMissingGetCssNameBlacklist;
        compilerOptions0.removeUnusedLocalVars = true;
        boolean boolean7 = compilerOptions0.collapseProperties;
        boolean boolean8 = compilerOptions0.prettyPrint;
        com.google.javascript.jscomp.CheckLevel checkLevel9 = compilerOptions0.brokenClosureRequiresLevel;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + checkLevel9 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel9.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
    }

//    @Test
//    public void test044() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test044");
//        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.CONSTANT_PROPERTY;
//        java.lang.String str1 = diagnosticGroup0.toString();
//        org.junit.Assert.assertNotNull(diagnosticGroup0);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "DiagnosticGroup<goog.exportSymbol>" + "'", str1.equals("DiagnosticGroup<goog.exportSymbol>"));
//    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile1 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.CompilerInput compilerInput2 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile1);
        com.google.javascript.jscomp.CompilerInput compilerInput5 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput2, "hi!", false);
        com.google.javascript.jscomp.CompilerInput compilerInput7 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput5, true);
        try {
            java.lang.String str8 = compilerInput7.getCode();
            org.junit.Assert.fail("Expected exception of type java.io.FileNotFoundException; message:  (No such file or directory)");
        } catch (java.io.FileNotFoundException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile1);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray13 = new com.google.javascript.rhino.Node[] { node4, node6, node8, node10, node12 };
        com.google.javascript.rhino.Node node14 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray13);
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node21 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray26 = new com.google.javascript.rhino.Node[] { node17, node19, node21, node23, node25 };
        com.google.javascript.rhino.Node node27 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray26);
        com.google.javascript.rhino.Node node28 = new com.google.javascript.rhino.Node(100, node14, node27);
        boolean boolean29 = closureCodingConvention0.isVarArgsParameter(node28);
        java.lang.String str30 = closureCodingConvention0.getExportPropertyFunction();
        boolean boolean32 = closureCodingConvention0.isConstant("hi!");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention33 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node37 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node39 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node41 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node43 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node45 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray46 = new com.google.javascript.rhino.Node[] { node37, node39, node41, node43, node45 };
        com.google.javascript.rhino.Node node47 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray46);
        com.google.javascript.rhino.Node node50 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node52 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node54 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node56 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node58 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray59 = new com.google.javascript.rhino.Node[] { node50, node52, node54, node56, node58 };
        com.google.javascript.rhino.Node node60 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray59);
        com.google.javascript.rhino.Node node61 = new com.google.javascript.rhino.Node(100, node47, node60);
        boolean boolean62 = closureCodingConvention33.isVarArgsParameter(node61);
        java.lang.String str63 = closureCodingConvention33.getExportPropertyFunction();
        boolean boolean66 = closureCodingConvention33.isExported("goog.exportProperty", false);
        com.google.javascript.rhino.Node node70 = com.google.javascript.rhino.Node.newNumber(100.0d, 4095, 9);
        java.util.Set<java.lang.String> strSet71 = node70.getDirectives();
        boolean boolean72 = closureCodingConvention33.isVarArgsParameter(node70);
        com.google.javascript.rhino.Node node75 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node77 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node79 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node81 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node83 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray84 = new com.google.javascript.rhino.Node[] { node75, node77, node79, node81, node83 };
        com.google.javascript.rhino.Node node85 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray84);
        int int86 = node85.getSideEffectFlags();
        node70.addChildrenToFront(node85);
        java.lang.String str88 = closureCodingConvention0.getSingletonGetterClassName(node85);
        boolean boolean90 = closureCodingConvention0.isValidEnumKey("1");
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(nodeArray13);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNotNull(nodeArray26);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "goog.exportProperty" + "'", str30.equals("goog.exportProperty"));
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(node37);
        org.junit.Assert.assertNotNull(node39);
        org.junit.Assert.assertNotNull(node41);
        org.junit.Assert.assertNotNull(node43);
        org.junit.Assert.assertNotNull(node45);
        org.junit.Assert.assertNotNull(nodeArray46);
        org.junit.Assert.assertNotNull(node50);
        org.junit.Assert.assertNotNull(node52);
        org.junit.Assert.assertNotNull(node54);
        org.junit.Assert.assertNotNull(node56);
        org.junit.Assert.assertNotNull(node58);
        org.junit.Assert.assertNotNull(nodeArray59);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertTrue("'" + str63 + "' != '" + "goog.exportProperty" + "'", str63.equals("goog.exportProperty"));
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertNotNull(node70);
        org.junit.Assert.assertNull(strSet71);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
        org.junit.Assert.assertNotNull(node75);
        org.junit.Assert.assertNotNull(node77);
        org.junit.Assert.assertNotNull(node79);
        org.junit.Assert.assertNotNull(node81);
        org.junit.Assert.assertNotNull(node83);
        org.junit.Assert.assertNotNull(nodeArray84);
        org.junit.Assert.assertTrue("'" + int86 + "' != '" + 0 + "'", int86 == 0);
        org.junit.Assert.assertNull(str88);
        org.junit.Assert.assertTrue("'" + boolean90 + "' != '" + true + "'", boolean90 == true);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.brokenClosureRequiresLevel;
        compilerOptions0.setManageClosureDependencies(true);
        java.lang.String[] strArray11 = new java.lang.String[] { "goog.exportProperty", "Not declared as a type name", "error reporter", "DiagnosticGroup<undefinedVars>", "goog.exportProperty", "Not declared as a constructor" };
        java.util.ArrayList<java.lang.String> strList12 = new java.util.ArrayList<java.lang.String>();
        boolean boolean13 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strList12, strArray11);
        compilerOptions0.setReplaceStringsConfiguration("goog.exportProperty", (java.util.List<java.lang.String>) strList12);
        compilerOptions0.decomposeExpressions = false;
        com.google.javascript.jscomp.CheckLevel checkLevel17 = compilerOptions0.checkMissingGetCssNameLevel;
        compilerOptions0.groupVariableDeclarations = true;
        com.google.javascript.jscomp.CompilerOptions compilerOptions20 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions20.checkDuplicateMessages = false;
        boolean boolean23 = compilerOptions20.inlineAnonymousFunctionExpressions;
        compilerOptions20.recordFunctionInformation = true;
        boolean boolean26 = compilerOptions20.checkCaja;
        compilerOptions20.aliasableGlobals = "EOF 0";
        boolean boolean29 = compilerOptions20.removeEmptyFunctions;
        boolean boolean30 = compilerOptions20.deadAssignmentElimination;
        com.google.javascript.jscomp.CheckLevel checkLevel31 = com.google.javascript.jscomp.CheckLevel.ERROR;
        compilerOptions20.checkUndefinedProperties = checkLevel31;
        com.google.javascript.jscomp.CheckLevel checkLevel33 = com.google.javascript.jscomp.CheckLevel.OFF;
        compilerOptions20.checkFunctions = checkLevel33;
        compilerOptions0.checkMethods = checkLevel33;
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(strArray11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + checkLevel17 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel17.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + checkLevel31 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel31.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + checkLevel33 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel33.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        com.google.javascript.rhino.Context context0 = new com.google.javascript.rhino.Context();
        context0.addActivationName("com.google.javascript.rhino.EcmaError: TypeError: ");
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        com.google.javascript.jscomp.mozilla.rhino.ast.AstRoot astRoot0 = null;
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray14 = new com.google.javascript.rhino.Node[] { node5, node7, node9, node11, node13 };
        com.google.javascript.rhino.Node node15 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray14);
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node18 = node15.copyInformationFrom(node17);
        com.google.javascript.jscomp.parsing.Config.LanguageMode languageMode20 = com.google.javascript.jscomp.parsing.Config.LanguageMode.ECMASCRIPT5;
        node18.putProp(24, (java.lang.Object) languageMode20);
        com.google.javascript.jscomp.parsing.Config config23 = com.google.javascript.jscomp.parsing.ParserRunner.createConfig(true, languageMode20, true);
        com.google.javascript.jscomp.mozilla.rhino.ErrorReporter errorReporter24 = null;
        try {
            com.google.javascript.rhino.Node node25 = com.google.javascript.jscomp.parsing.IRFactory.transformTree(astRoot0, "JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of optimization iterations: {0}", config23, errorReporter24);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(nodeArray14);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertTrue("'" + languageMode20 + "' != '" + com.google.javascript.jscomp.parsing.Config.LanguageMode.ECMASCRIPT5 + "'", languageMode20.equals(com.google.javascript.jscomp.parsing.Config.LanguageMode.ECMASCRIPT5));
        org.junit.Assert.assertNotNull(config23);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray13 = new com.google.javascript.rhino.Node[] { node4, node6, node8, node10, node12 };
        com.google.javascript.rhino.Node node14 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray13);
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node21 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray26 = new com.google.javascript.rhino.Node[] { node17, node19, node21, node23, node25 };
        com.google.javascript.rhino.Node node27 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray26);
        com.google.javascript.rhino.Node node28 = new com.google.javascript.rhino.Node(100, node14, node27);
        boolean boolean29 = closureCodingConvention0.isVarArgsParameter(node28);
        java.lang.String str30 = closureCodingConvention0.getExportPropertyFunction();
        boolean boolean33 = closureCodingConvention0.isExported("goog.exportProperty", false);
        com.google.javascript.rhino.Node node37 = com.google.javascript.rhino.Node.newNumber(100.0d, 4095, 9);
        java.util.Set<java.lang.String> strSet38 = node37.getDirectives();
        boolean boolean39 = closureCodingConvention0.isVarArgsParameter(node37);
        com.google.javascript.rhino.Node node42 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node44 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node46 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node48 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node50 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray51 = new com.google.javascript.rhino.Node[] { node42, node44, node46, node48, node50 };
        com.google.javascript.rhino.Node node52 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray51);
        com.google.javascript.rhino.Node node54 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node55 = node52.copyInformationFrom(node54);
        try {
            boolean boolean56 = closureCodingConvention0.isPropertyTestFunction(node55);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(nodeArray13);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNotNull(nodeArray26);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "goog.exportProperty" + "'", str30.equals("goog.exportProperty"));
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(node37);
        org.junit.Assert.assertNull(strSet38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(node42);
        org.junit.Assert.assertNotNull(node44);
        org.junit.Assert.assertNotNull(node46);
        org.junit.Assert.assertNotNull(node48);
        org.junit.Assert.assertNotNull(node50);
        org.junit.Assert.assertNotNull(nodeArray51);
        org.junit.Assert.assertNotNull(node54);
        org.junit.Assert.assertNotNull(node55);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray11 = new com.google.javascript.rhino.Node[] { node2, node4, node6, node8, node10 };
        com.google.javascript.rhino.Node node12 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray11);
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node15 = node12.copyInformationFrom(node14);
        com.google.javascript.jscomp.parsing.Config.LanguageMode languageMode17 = com.google.javascript.jscomp.parsing.Config.LanguageMode.ECMASCRIPT5;
        node15.putProp(24, (java.lang.Object) languageMode17);
        com.google.javascript.rhino.Node node19 = node15.cloneTree();
        int int20 = node19.getSourcePosition();
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(nodeArray11);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertTrue("'" + languageMode17 + "' != '" + com.google.javascript.jscomp.parsing.Config.LanguageMode.ECMASCRIPT5 + "'", languageMode17.equals(com.google.javascript.jscomp.parsing.Config.LanguageMode.ECMASCRIPT5));
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.brokenClosureRequiresLevel;
        com.google.javascript.jscomp.CheckLevel checkLevel2 = com.google.javascript.jscomp.CheckLevel.WARNING;
        compilerOptions0.checkGlobalNamesLevel = checkLevel2;
        compilerOptions0.computeFunctionSideEffects = true;
        compilerOptions0.closurePass = false;
        com.google.javascript.jscomp.CompilerOptions compilerOptions8 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel9 = compilerOptions8.brokenClosureRequiresLevel;
        compilerOptions0.checkGlobalThisLevel = checkLevel9;
        compilerOptions0.collapseVariableDeclarations = false;
        compilerOptions0.removeEmptyFunctions = false;
        compilerOptions0.crossModuleMethodMotion = true;
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + checkLevel2 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel2.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
        org.junit.Assert.assertTrue("'" + checkLevel9 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel9.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.brokenClosureRequiresLevel;
        compilerOptions0.setManageClosureDependencies(true);
        java.lang.String[] strArray11 = new java.lang.String[] { "goog.exportProperty", "Not declared as a type name", "error reporter", "DiagnosticGroup<undefinedVars>", "goog.exportProperty", "Not declared as a constructor" };
        java.util.ArrayList<java.lang.String> strList12 = new java.util.ArrayList<java.lang.String>();
        boolean boolean13 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strList12, strArray11);
        compilerOptions0.setReplaceStringsConfiguration("goog.exportProperty", (java.util.List<java.lang.String>) strList12);
        compilerOptions0.setDefineToNumberLiteral("DiagnosticGroup<strictModuleDepCheck>", (int) (short) 1);
        com.google.javascript.jscomp.CompilerOptions compilerOptions18 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions18.checkDuplicateMessages = false;
        compilerOptions18.tightenTypes = true;
        compilerOptions18.sourceMapOutputPath = "JSC_OPTIMIZE_LOOP_ERROR";
        com.google.javascript.jscomp.SourceMap.Format format25 = com.google.javascript.jscomp.SourceMap.Format.DEFAULT;
        compilerOptions18.sourceMapFormat = format25;
        compilerOptions0.sourceMapFormat = format25;
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(strArray11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(format25);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.checkDuplicateMessages = false;
        boolean boolean3 = compilerOptions0.inlineAnonymousFunctionExpressions;
        compilerOptions0.recordFunctionInformation = true;
        boolean boolean6 = compilerOptions0.checkCaja;
        com.google.javascript.jscomp.CheckLevel checkLevel7 = compilerOptions0.checkUndefinedProperties;
        compilerOptions0.ideMode = false;
        compilerOptions0.inlineLocalFunctions = true;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + checkLevel7 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel7.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.brokenClosureRequiresLevel;
        com.google.javascript.jscomp.CheckLevel checkLevel2 = com.google.javascript.jscomp.CheckLevel.WARNING;
        compilerOptions0.checkGlobalNamesLevel = checkLevel2;
        compilerOptions0.computeFunctionSideEffects = true;
        boolean boolean6 = compilerOptions0.removeDeadCode;
        com.google.javascript.jscomp.SourceMap.DetailLevel detailLevel7 = null;
        compilerOptions0.sourceMapDetailLevel = detailLevel7;
        compilerOptions0.collapseAnonymousFunctions = false;
        com.google.javascript.jscomp.CodingConvention codingConvention11 = compilerOptions0.getCodingConvention();
        boolean boolean12 = compilerOptions0.tightenTypes;
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + checkLevel2 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel2.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(codingConvention11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        com.google.javascript.rhino.Context context0 = com.google.javascript.rhino.Context.enter();
        boolean boolean1 = context0.isGeneratingSource();
        com.google.javascript.rhino.ErrorReporter errorReporter2 = context0.getErrorReporter();
        com.google.javascript.rhino.ErrorReporter errorReporter3 = context0.getErrorReporter();
        boolean boolean4 = context0.isSealed();
        try {
            context0.setLanguageVersion(2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Bad language version: 2");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(context0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNull(errorReporter2);
        org.junit.Assert.assertNull(errorReporter3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        com.google.javascript.jscomp.DiagnosticType diagnosticType2 = com.google.javascript.jscomp.DiagnosticType.warning("(DiagnosticGroup<strictModuleDepCheck>)", "1");
        com.google.javascript.jscomp.DiagnosticType diagnosticType3 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        java.lang.String str4 = diagnosticType3.key;
        java.lang.String str5 = diagnosticType3.toString();
        int int6 = diagnosticType2.compareTo(diagnosticType3);
        org.junit.Assert.assertNotNull(diagnosticType2);
        org.junit.Assert.assertNotNull(diagnosticType3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "JSC_OPTIMIZE_LOOP_ERROR" + "'", str4.equals("JSC_OPTIMIZE_LOOP_ERROR"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of optimization iterations: {0}" + "'", str5.equals("JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of optimization iterations: {0}"));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-34) + "'", int6 == (-34));
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.brokenClosureRequiresLevel;
        com.google.javascript.jscomp.CheckLevel checkLevel2 = com.google.javascript.jscomp.CheckLevel.WARNING;
        compilerOptions0.checkGlobalNamesLevel = checkLevel2;
        com.google.javascript.jscomp.ErrorFormat errorFormat4 = null;
        compilerOptions0.errorFormat = errorFormat4;
        boolean boolean6 = compilerOptions0.ambiguateProperties;
        boolean boolean7 = compilerOptions0.decomposeExpressions;
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + checkLevel2 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel2.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile1 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        java.lang.String str2 = jSSourceFile1.toString();
        com.google.javascript.jscomp.Region region4 = jSSourceFile1.getRegion(12);
        try {
            java.lang.String str5 = jSSourceFile1.getCode();
            org.junit.Assert.fail("Expected exception of type java.io.FileNotFoundException; message:  (No such file or directory)");
        } catch (java.io.FileNotFoundException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertNull(region4);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.brokenClosureRequiresLevel;
        com.google.javascript.jscomp.CheckLevel checkLevel2 = com.google.javascript.jscomp.CheckLevel.WARNING;
        compilerOptions0.checkGlobalNamesLevel = checkLevel2;
        compilerOptions0.computeFunctionSideEffects = true;
        boolean boolean6 = compilerOptions0.removeDeadCode;
        com.google.javascript.jscomp.SourceMap.DetailLevel detailLevel7 = null;
        compilerOptions0.sourceMapDetailLevel = detailLevel7;
        compilerOptions0.removeUnusedLocalVars = false;
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + checkLevel2 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel2.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.brokenClosureRequiresLevel;
        com.google.javascript.jscomp.CheckLevel checkLevel2 = com.google.javascript.jscomp.CheckLevel.WARNING;
        compilerOptions0.checkGlobalNamesLevel = checkLevel2;
        com.google.javascript.jscomp.ErrorFormat errorFormat4 = null;
        compilerOptions0.errorFormat = errorFormat4;
        boolean boolean6 = compilerOptions0.ambiguateProperties;
        com.google.javascript.jscomp.CompilerOptions compilerOptions7 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel8 = compilerOptions7.brokenClosureRequiresLevel;
        com.google.javascript.jscomp.CheckLevel checkLevel9 = com.google.javascript.jscomp.CheckLevel.WARNING;
        compilerOptions7.checkGlobalNamesLevel = checkLevel9;
        compilerOptions7.computeFunctionSideEffects = true;
        boolean boolean13 = compilerOptions7.removeDeadCode;
        compilerOptions7.inlineVariables = true;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy16 = com.google.javascript.jscomp.VariableRenamingPolicy.OFF;
        compilerOptions7.variableRenaming = variableRenamingPolicy16;
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy18 = com.google.javascript.jscomp.PropertyRenamingPolicy.HEURISTIC;
        compilerOptions0.setRenamingPolicy(variableRenamingPolicy16, propertyRenamingPolicy18);
        compilerOptions0.markNoSideEffectCalls = false;
        boolean boolean22 = compilerOptions0.moveFunctionDeclarations;
        compilerOptions0.strictMessageReplacement = false;
        boolean boolean25 = compilerOptions0.ambiguateProperties;
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + checkLevel2 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel2.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + checkLevel8 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel8.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + checkLevel9 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel9.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy16 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.OFF + "'", variableRenamingPolicy16.equals(com.google.javascript.jscomp.VariableRenamingPolicy.OFF));
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy18 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.HEURISTIC + "'", propertyRenamingPolicy18.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.HEURISTIC));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile5 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.CompilerInput compilerInput6 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile5);
        com.google.javascript.jscomp.CompilerInput compilerInput9 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput6, "hi!", false);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile11 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        compilerInput6.setSourceFile((com.google.javascript.jscomp.SourceFile) jSSourceFile11);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile14 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray15 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile2, jSSourceFile11, jSSourceFile14 };
        java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList16 = new java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile>();
        boolean boolean17 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList16, jSSourceFileArray15);
        com.google.javascript.jscomp.JSModule[] jSModuleArray18 = new com.google.javascript.jscomp.JSModule[] {};
        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList19 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
        boolean boolean20 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList19, jSModuleArray18);
        com.google.javascript.jscomp.CompilerOptions compilerOptions21 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions21.checkDuplicateMessages = false;
        boolean boolean24 = compilerOptions21.inlineAnonymousFunctionExpressions;
        compilerOptions21.crossModuleMethodMotion = true;
        com.google.javascript.jscomp.Result result27 = compiler0.compileModules((java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList16, (java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList19, compilerOptions21);
        boolean boolean28 = compiler0.acceptConstKeyword();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile30 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.CompilerInput compilerInput31 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile30);
        com.google.javascript.jscomp.JsAst jsAst32 = new com.google.javascript.jscomp.JsAst((com.google.javascript.jscomp.SourceFile) jSSourceFile30);
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray33 = null;
        com.google.javascript.jscomp.CompilerOptions compilerOptions34 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel35 = compilerOptions34.brokenClosureRequiresLevel;
        com.google.javascript.jscomp.CheckLevel checkLevel36 = com.google.javascript.jscomp.CheckLevel.WARNING;
        compilerOptions34.checkGlobalNamesLevel = checkLevel36;
        compilerOptions34.computeFunctionSideEffects = true;
        boolean boolean40 = compilerOptions34.removeDeadCode;
        com.google.javascript.jscomp.SourceMap.DetailLevel detailLevel41 = null;
        compilerOptions34.sourceMapDetailLevel = detailLevel41;
        boolean boolean43 = compilerOptions34.prettyPrint;
        compilerOptions34.setSummaryDetailLevel(0);
        try {
            com.google.javascript.jscomp.Result result46 = compiler0.compile(jSSourceFile30, jSSourceFileArray33, compilerOptions34);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile2);
        org.junit.Assert.assertNotNull(jSSourceFile5);
        org.junit.Assert.assertNotNull(jSSourceFile11);
        org.junit.Assert.assertNotNull(jSSourceFile14);
        org.junit.Assert.assertNotNull(jSSourceFileArray15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(jSModuleArray18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(result27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(jSSourceFile30);
        org.junit.Assert.assertTrue("'" + checkLevel35 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel35.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + checkLevel36 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel36.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
    }

//    @Test
//    public void test063() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test063");
//        com.google.javascript.rhino.Context context0 = com.google.javascript.rhino.Context.enter();
//        boolean boolean1 = context0.isGeneratingSource();
//        java.lang.Object obj2 = context0.getDebuggerContextData();
//        boolean boolean3 = context0.isGeneratingSource();
//        int int4 = context0.getLanguageVersion();
//        org.junit.Assert.assertNotNull(context0);
//        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
//        org.junit.Assert.assertNull(obj2);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
//    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.checkDuplicateMessages = false;
        boolean boolean3 = compilerOptions0.inlineAnonymousFunctionExpressions;
        compilerOptions0.recordFunctionInformation = true;
        boolean boolean6 = compilerOptions0.checkCaja;
        compilerOptions0.aliasableGlobals = "EOF 0";
        com.google.javascript.jscomp.CheckLevel checkLevel9 = com.google.javascript.jscomp.CheckLevel.OFF;
        compilerOptions0.reportUnknownTypes = checkLevel9;
        com.google.javascript.jscomp.CompilerOptions compilerOptions11 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions11.checkDuplicateMessages = false;
        boolean boolean14 = compilerOptions11.inlineAnonymousFunctionExpressions;
        compilerOptions11.recordFunctionInformation = true;
        boolean boolean17 = compilerOptions11.checkCaja;
        java.util.Set<java.lang.String> strSet18 = compilerOptions11.stripNamePrefixes;
        compilerOptions0.setIdGenerators(strSet18);
        compilerOptions0.extractPrototypeMemberDeclarations = true;
        boolean boolean22 = compilerOptions0.disambiguateProperties;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + checkLevel9 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel9.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(strSet18);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.brokenClosureRequiresLevel;
        com.google.javascript.jscomp.CheckLevel checkLevel2 = com.google.javascript.jscomp.CheckLevel.WARNING;
        compilerOptions0.checkGlobalNamesLevel = checkLevel2;
        com.google.javascript.jscomp.ErrorFormat errorFormat4 = null;
        compilerOptions0.errorFormat = errorFormat4;
        boolean boolean6 = compilerOptions0.ambiguateProperties;
        com.google.javascript.jscomp.CompilerOptions compilerOptions7 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel8 = compilerOptions7.brokenClosureRequiresLevel;
        com.google.javascript.jscomp.CheckLevel checkLevel9 = com.google.javascript.jscomp.CheckLevel.WARNING;
        compilerOptions7.checkGlobalNamesLevel = checkLevel9;
        compilerOptions7.computeFunctionSideEffects = true;
        boolean boolean13 = compilerOptions7.removeDeadCode;
        compilerOptions7.inlineVariables = true;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy16 = com.google.javascript.jscomp.VariableRenamingPolicy.OFF;
        compilerOptions7.variableRenaming = variableRenamingPolicy16;
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy18 = com.google.javascript.jscomp.PropertyRenamingPolicy.HEURISTIC;
        compilerOptions0.setRenamingPolicy(variableRenamingPolicy16, propertyRenamingPolicy18);
        compilerOptions0.markNoSideEffectCalls = false;
        boolean boolean22 = compilerOptions0.moveFunctionDeclarations;
        compilerOptions0.strictMessageReplacement = false;
        java.lang.String str25 = compilerOptions0.syntheticBlockEndMarker;
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + checkLevel2 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel2.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + checkLevel8 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel8.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + checkLevel9 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel9.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy16 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.OFF + "'", variableRenamingPolicy16.equals(com.google.javascript.jscomp.VariableRenamingPolicy.OFF));
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy18 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.HEURISTIC + "'", propertyRenamingPolicy18.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.HEURISTIC));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNull(str25);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newNumber((double) 1, 29, (int) '4');
        org.junit.Assert.assertNotNull(node3);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newNumber(100.0d, 4095, 9);
        java.lang.String str4 = node3.toStringTree();
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "NUMBER 100.0 4095\n" + "'", str4.equals("NUMBER 100.0 4095\n"));
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.brokenClosureRequiresLevel;
        com.google.javascript.jscomp.CheckLevel checkLevel2 = com.google.javascript.jscomp.CheckLevel.WARNING;
        compilerOptions0.checkGlobalNamesLevel = checkLevel2;
        compilerOptions0.computeFunctionSideEffects = true;
        boolean boolean6 = compilerOptions0.removeDeadCode;
        compilerOptions0.inlineVariables = true;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy9 = com.google.javascript.jscomp.VariableRenamingPolicy.OFF;
        compilerOptions0.variableRenaming = variableRenamingPolicy9;
        com.google.javascript.jscomp.CheckLevel checkLevel11 = compilerOptions0.checkShadowVars;
        compilerOptions0.lineLengthThreshold(11);
        boolean boolean14 = compilerOptions0.checkCaja;
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + checkLevel2 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel2.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy9 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.OFF + "'", variableRenamingPolicy9.equals(com.google.javascript.jscomp.VariableRenamingPolicy.OFF));
        org.junit.Assert.assertTrue("'" + checkLevel11 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel11.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.checkDuplicateMessages = false;
        compilerOptions0.tightenTypes = true;
        compilerOptions0.setNameAnonymousFunctionsOnly(false);
        boolean boolean7 = compilerOptions0.allowLegacyJsMessages;
        boolean boolean8 = compilerOptions0.deadAssignmentElimination;
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.brokenClosureRequiresLevel;
        com.google.javascript.jscomp.CheckLevel checkLevel2 = com.google.javascript.jscomp.CheckLevel.WARNING;
        compilerOptions0.checkGlobalNamesLevel = checkLevel2;
        compilerOptions0.computeFunctionSideEffects = true;
        compilerOptions0.setShadowVariables(true);
        compilerOptions0.debugFunctionSideEffectsPath = "goog.global";
        compilerOptions0.checkTypes = false;
        compilerOptions0.decomposeExpressions = false;
        compilerOptions0.inlineLocalVariables = false;
        compilerOptions0.setNameAnonymousFunctionsOnly(false);
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + checkLevel2 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel2.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newString((int) (short) 0, "hi!", 100, (-2));
        com.google.javascript.rhino.Node node6 = new com.google.javascript.rhino.Node(10, node5);
        com.google.javascript.rhino.Node node7 = node6.getLastSibling();
        node7.setIsSyntheticBlock(true);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNotNull(node7);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.brokenClosureRequiresLevel;
        com.google.javascript.jscomp.CheckLevel checkLevel2 = com.google.javascript.jscomp.CheckLevel.WARNING;
        compilerOptions0.checkGlobalNamesLevel = checkLevel2;
        compilerOptions0.computeFunctionSideEffects = true;
        compilerOptions0.closurePass = false;
        com.google.javascript.jscomp.ErrorFormat errorFormat8 = compilerOptions0.errorFormat;
        com.google.javascript.jscomp.CompilerOptions compilerOptions9 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel10 = compilerOptions9.brokenClosureRequiresLevel;
        compilerOptions0.reportMissingOverride = checkLevel10;
        boolean boolean12 = compilerOptions0.optimizeCalls;
        boolean boolean13 = compilerOptions0.collapseVariableDeclarations;
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + checkLevel2 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel2.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
        org.junit.Assert.assertNotNull(errorFormat8);
        org.junit.Assert.assertTrue("'" + checkLevel10 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel10.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        com.google.javascript.jscomp.SourceFile sourceFile1 = com.google.javascript.jscomp.SourceFile.fromFile("");
        org.junit.Assert.assertNotNull(sourceFile1);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        com.google.javascript.rhino.EcmaError ecmaError1 = com.google.javascript.rhino.ScriptRuntime.typeError("");
        java.lang.String str2 = ecmaError1.getSourceName();
        ecmaError1.initSourceName("error reporter");
        int int5 = ecmaError1.getColumnNumber();
        java.lang.String str6 = ecmaError1.getName();
        org.junit.Assert.assertNotNull(ecmaError1);
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "TypeError" + "'", str6.equals("TypeError"));
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.brokenClosureRequiresLevel;
        com.google.javascript.jscomp.CheckLevel checkLevel2 = com.google.javascript.jscomp.CheckLevel.WARNING;
        compilerOptions0.checkGlobalNamesLevel = checkLevel2;
        compilerOptions0.computeFunctionSideEffects = true;
        compilerOptions0.closurePass = false;
        com.google.javascript.jscomp.CompilerOptions compilerOptions8 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel9 = compilerOptions8.brokenClosureRequiresLevel;
        compilerOptions0.checkGlobalThisLevel = checkLevel9;
        compilerOptions0.collapseVariableDeclarations = false;
        com.google.common.collect.Multimap<com.google.javascript.jscomp.CustomPassExecutionTime, com.google.javascript.jscomp.CompilerPass> customPassExecutionTimeMultimap13 = null;
        compilerOptions0.customPasses = customPassExecutionTimeMultimap13;
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + checkLevel2 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel2.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
        org.junit.Assert.assertTrue("'" + checkLevel9 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel9.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.brokenClosureRequiresLevel;
        java.util.Map<java.lang.String, com.google.javascript.rhino.Node> strMap2 = compilerOptions0.getDefineReplacements();
        boolean boolean3 = compilerOptions0.ideMode;
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(strMap2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        boolean boolean2 = closureCodingConvention0.isConstant("");
        boolean boolean4 = closureCodingConvention0.isValidEnumKey("hi!");
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray17 = new com.google.javascript.rhino.Node[] { node8, node10, node12, node14, node16 };
        com.google.javascript.rhino.Node node18 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray17);
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node21 = node18.copyInformationFrom(node20);
        com.google.javascript.rhino.Node node22 = node18.getParent();
        com.google.javascript.rhino.Node node23 = new com.google.javascript.rhino.Node((int) (short) -1, node18);
        com.google.javascript.rhino.Node node28 = com.google.javascript.rhino.Node.newString((int) (short) 0, "hi!", 100, (-2));
        boolean boolean29 = node18.isEquivalentTo(node28);
        com.google.javascript.rhino.Node node32 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node34 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node36 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node38 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node40 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray41 = new com.google.javascript.rhino.Node[] { node32, node34, node36, node38, node40 };
        com.google.javascript.rhino.Node node42 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray41);
        com.google.javascript.rhino.Node node44 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node45 = node42.copyInformationFrom(node44);
        com.google.javascript.jscomp.parsing.Config.LanguageMode languageMode47 = com.google.javascript.jscomp.parsing.Config.LanguageMode.ECMASCRIPT5;
        node45.putProp(24, (java.lang.Object) languageMode47);
        java.lang.String str49 = closureCodingConvention0.extractClassNameIfRequire(node18, node45);
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention50 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node54 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node56 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node58 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node60 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node62 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray63 = new com.google.javascript.rhino.Node[] { node54, node56, node58, node60, node62 };
        com.google.javascript.rhino.Node node64 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray63);
        com.google.javascript.rhino.Node node67 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node69 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node71 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node73 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node75 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray76 = new com.google.javascript.rhino.Node[] { node67, node69, node71, node73, node75 };
        com.google.javascript.rhino.Node node77 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray76);
        com.google.javascript.rhino.Node node78 = new com.google.javascript.rhino.Node(100, node64, node77);
        java.lang.String str79 = closureCodingConvention50.getSingletonGetterClassName(node78);
        com.google.javascript.rhino.Node node82 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node84 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node86 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node88 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node90 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray91 = new com.google.javascript.rhino.Node[] { node82, node84, node86, node88, node90 };
        com.google.javascript.rhino.Node node92 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray91);
        com.google.javascript.rhino.Node node94 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node95 = node92.copyInformationFrom(node94);
        java.lang.String str96 = node94.getString();
        node45.addChildAfter(node78, node94);
        node78.detachChildren();
        try {
            com.google.javascript.rhino.Node node99 = node78.detachFromParent();
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: node is not a child");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertNotNull(nodeArray17);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertNull(node22);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(node32);
        org.junit.Assert.assertNotNull(node34);
        org.junit.Assert.assertNotNull(node36);
        org.junit.Assert.assertNotNull(node38);
        org.junit.Assert.assertNotNull(node40);
        org.junit.Assert.assertNotNull(nodeArray41);
        org.junit.Assert.assertNotNull(node44);
        org.junit.Assert.assertNotNull(node45);
        org.junit.Assert.assertTrue("'" + languageMode47 + "' != '" + com.google.javascript.jscomp.parsing.Config.LanguageMode.ECMASCRIPT5 + "'", languageMode47.equals(com.google.javascript.jscomp.parsing.Config.LanguageMode.ECMASCRIPT5));
        org.junit.Assert.assertNull(str49);
        org.junit.Assert.assertNotNull(node54);
        org.junit.Assert.assertNotNull(node56);
        org.junit.Assert.assertNotNull(node58);
        org.junit.Assert.assertNotNull(node60);
        org.junit.Assert.assertNotNull(node62);
        org.junit.Assert.assertNotNull(nodeArray63);
        org.junit.Assert.assertNotNull(node67);
        org.junit.Assert.assertNotNull(node69);
        org.junit.Assert.assertNotNull(node71);
        org.junit.Assert.assertNotNull(node73);
        org.junit.Assert.assertNotNull(node75);
        org.junit.Assert.assertNotNull(nodeArray76);
        org.junit.Assert.assertNull(str79);
        org.junit.Assert.assertNotNull(node82);
        org.junit.Assert.assertNotNull(node84);
        org.junit.Assert.assertNotNull(node86);
        org.junit.Assert.assertNotNull(node88);
        org.junit.Assert.assertNotNull(node90);
        org.junit.Assert.assertNotNull(nodeArray91);
        org.junit.Assert.assertNotNull(node94);
        org.junit.Assert.assertNotNull(node95);
        org.junit.Assert.assertTrue("'" + str96 + "' != '" + "" + "'", str96.equals(""));
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.brokenClosureRequiresLevel;
        com.google.javascript.jscomp.CheckLevel checkLevel2 = com.google.javascript.jscomp.CheckLevel.WARNING;
        compilerOptions0.checkGlobalNamesLevel = checkLevel2;
        compilerOptions0.computeFunctionSideEffects = true;
        compilerOptions0.setShadowVariables(true);
        compilerOptions0.debugFunctionSideEffectsPath = "goog.global";
        compilerOptions0.checkTypes = false;
        compilerOptions0.setManageClosureDependencies(false);
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + checkLevel2 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel2.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray13 = new com.google.javascript.rhino.Node[] { node4, node6, node8, node10, node12 };
        com.google.javascript.rhino.Node node14 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray13);
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node21 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray26 = new com.google.javascript.rhino.Node[] { node17, node19, node21, node23, node25 };
        com.google.javascript.rhino.Node node27 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray26);
        com.google.javascript.rhino.Node node28 = new com.google.javascript.rhino.Node(100, node14, node27);
        boolean boolean29 = closureCodingConvention0.isVarArgsParameter(node28);
        java.lang.String str30 = closureCodingConvention0.getExportPropertyFunction();
        boolean boolean33 = closureCodingConvention0.isExported("goog.exportProperty", false);
        com.google.javascript.rhino.Node node37 = com.google.javascript.rhino.Node.newNumber(100.0d, 4095, 9);
        java.util.Set<java.lang.String> strSet38 = node37.getDirectives();
        boolean boolean39 = closureCodingConvention0.isVarArgsParameter(node37);
        com.google.javascript.rhino.Node node42 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node44 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node46 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node48 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node50 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray51 = new com.google.javascript.rhino.Node[] { node42, node44, node46, node48, node50 };
        com.google.javascript.rhino.Node node52 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray51);
        int int53 = node52.getSideEffectFlags();
        node37.addChildrenToFront(node52);
        int int56 = node52.getIntProp((int) (short) 10);
        node52.setIsSyntheticBlock(true);
        boolean boolean59 = node52.wasEmptyNode();
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(nodeArray13);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNotNull(nodeArray26);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "goog.exportProperty" + "'", str30.equals("goog.exportProperty"));
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(node37);
        org.junit.Assert.assertNull(strSet38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(node42);
        org.junit.Assert.assertNotNull(node44);
        org.junit.Assert.assertNotNull(node46);
        org.junit.Assert.assertNotNull(node48);
        org.junit.Assert.assertNotNull(node50);
        org.junit.Assert.assertNotNull(nodeArray51);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 0 + "'", int53 == 0);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 0 + "'", int56 == 0);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        boolean boolean2 = closureCodingConvention0.isConstant("");
        boolean boolean4 = closureCodingConvention0.isValidEnumKey("hi!");
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray17 = new com.google.javascript.rhino.Node[] { node8, node10, node12, node14, node16 };
        com.google.javascript.rhino.Node node18 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray17);
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node21 = node18.copyInformationFrom(node20);
        com.google.javascript.rhino.Node node22 = node18.getParent();
        com.google.javascript.rhino.Node node23 = new com.google.javascript.rhino.Node((int) (short) -1, node18);
        com.google.javascript.rhino.Node node28 = com.google.javascript.rhino.Node.newString((int) (short) 0, "hi!", 100, (-2));
        boolean boolean29 = node18.isEquivalentTo(node28);
        com.google.javascript.rhino.Node node32 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node34 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node36 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node38 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node40 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray41 = new com.google.javascript.rhino.Node[] { node32, node34, node36, node38, node40 };
        com.google.javascript.rhino.Node node42 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray41);
        com.google.javascript.rhino.Node node44 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node45 = node42.copyInformationFrom(node44);
        com.google.javascript.jscomp.parsing.Config.LanguageMode languageMode47 = com.google.javascript.jscomp.parsing.Config.LanguageMode.ECMASCRIPT5;
        node45.putProp(24, (java.lang.Object) languageMode47);
        java.lang.String str49 = closureCodingConvention0.extractClassNameIfRequire(node18, node45);
        node45.setType(100);
        com.google.javascript.rhino.Node node52 = node45.getLastSibling();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertNotNull(nodeArray17);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertNull(node22);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(node32);
        org.junit.Assert.assertNotNull(node34);
        org.junit.Assert.assertNotNull(node36);
        org.junit.Assert.assertNotNull(node38);
        org.junit.Assert.assertNotNull(node40);
        org.junit.Assert.assertNotNull(nodeArray41);
        org.junit.Assert.assertNotNull(node44);
        org.junit.Assert.assertNotNull(node45);
        org.junit.Assert.assertTrue("'" + languageMode47 + "' != '" + com.google.javascript.jscomp.parsing.Config.LanguageMode.ECMASCRIPT5 + "'", languageMode47.equals(com.google.javascript.jscomp.parsing.Config.LanguageMode.ECMASCRIPT5));
        org.junit.Assert.assertNull(str49);
        org.junit.Assert.assertNotNull(node52);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray13 = new com.google.javascript.rhino.Node[] { node4, node6, node8, node10, node12 };
        com.google.javascript.rhino.Node node14 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray13);
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node21 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray26 = new com.google.javascript.rhino.Node[] { node17, node19, node21, node23, node25 };
        com.google.javascript.rhino.Node node27 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray26);
        com.google.javascript.rhino.Node node28 = new com.google.javascript.rhino.Node(100, node14, node27);
        boolean boolean29 = closureCodingConvention0.isVarArgsParameter(node28);
        java.lang.String str30 = closureCodingConvention0.getExportPropertyFunction();
        boolean boolean33 = closureCodingConvention0.isExported("goog.exportProperty", false);
        com.google.javascript.rhino.Node node37 = com.google.javascript.rhino.Node.newNumber(100.0d, 4095, 9);
        java.util.Set<java.lang.String> strSet38 = node37.getDirectives();
        boolean boolean39 = closureCodingConvention0.isVarArgsParameter(node37);
        com.google.javascript.rhino.Node node42 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node44 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node46 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node48 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node50 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray51 = new com.google.javascript.rhino.Node[] { node42, node44, node46, node48, node50 };
        com.google.javascript.rhino.Node node52 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray51);
        com.google.javascript.rhino.Node node53 = node52.getNext();
        com.google.javascript.rhino.Node node57 = com.google.javascript.rhino.Node.newNumber(100.0d, 4095, 9);
        java.lang.String str58 = closureCodingConvention0.extractClassNameIfRequire(node52, node57);
        com.google.javascript.rhino.jstype.ObjectType objectType59 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType60 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType61 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType62 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType63 = null;
        closureCodingConvention0.applyDelegateRelationship(objectType59, objectType60, objectType61, functionType62, functionType63);
        java.lang.String str65 = closureCodingConvention0.getGlobalObject();
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(nodeArray13);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNotNull(nodeArray26);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "goog.exportProperty" + "'", str30.equals("goog.exportProperty"));
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(node37);
        org.junit.Assert.assertNull(strSet38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(node42);
        org.junit.Assert.assertNotNull(node44);
        org.junit.Assert.assertNotNull(node46);
        org.junit.Assert.assertNotNull(node48);
        org.junit.Assert.assertNotNull(node50);
        org.junit.Assert.assertNotNull(nodeArray51);
        org.junit.Assert.assertNull(node53);
        org.junit.Assert.assertNotNull(node57);
        org.junit.Assert.assertNull(str58);
        org.junit.Assert.assertTrue("'" + str65 + "' != '" + "goog.global" + "'", str65.equals("goog.global"));
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.checkDuplicateMessages = false;
        boolean boolean3 = compilerOptions0.inlineAnonymousFunctionExpressions;
        compilerOptions0.recordFunctionInformation = true;
        boolean boolean6 = compilerOptions0.checkCaja;
        com.google.javascript.jscomp.CheckLevel checkLevel7 = compilerOptions0.checkUndefinedProperties;
        compilerOptions0.ideMode = false;
        compilerOptions0.setDefineToBooleanLiteral("", false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + checkLevel7 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel7.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        int int0 = com.google.javascript.rhino.Node.FREE_CALL;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 49 + "'", int0 == 49);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile3 = com.google.javascript.jscomp.JSSourceFile.fromFile("Not declared as a constructor");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile5 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.CompilerInput compilerInput6 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile5);
        com.google.javascript.jscomp.CompilerInput compilerInput9 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput6, "hi!", false);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile11 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        compilerInput6.setSourceFile((com.google.javascript.jscomp.SourceFile) jSSourceFile11);
        java.lang.String str13 = jSSourceFile11.toString();
        com.google.javascript.jscomp.CompilerOptions compilerOptions14 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean15 = compilerOptions14.aliasAllStrings;
        compilerOptions14.setGenerateExports(true);
        com.google.javascript.jscomp.Result result18 = compiler1.compile(jSSourceFile3, jSSourceFile11, compilerOptions14);
        compilerOptions14.inlineLocalFunctions = true;
        compilerOptions14.devirtualizePrototypeMethods = true;
        compilerOptions14.lineBreak = false;
        org.junit.Assert.assertNotNull(jSSourceFile3);
        org.junit.Assert.assertNotNull(jSSourceFile5);
        org.junit.Assert.assertNotNull(jSSourceFile11);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(result18);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray12 = new com.google.javascript.rhino.Node[] { node3, node5, node7, node9, node11 };
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray12);
        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node22 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node24 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray25 = new com.google.javascript.rhino.Node[] { node16, node18, node20, node22, node24 };
        com.google.javascript.rhino.Node node26 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray25);
        com.google.javascript.rhino.Node node27 = new com.google.javascript.rhino.Node(100, node13, node26);
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable28 = node27.siblings();
        com.google.javascript.rhino.Node node30 = node27.getChildAtIndex((-2));
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertNotNull(nodeArray12);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertNotNull(nodeArray25);
        org.junit.Assert.assertNotNull(nodeIterable28);
        org.junit.Assert.assertNotNull(node30);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray13 = new com.google.javascript.rhino.Node[] { node4, node6, node8, node10, node12 };
        com.google.javascript.rhino.Node node14 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray13);
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node21 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray26 = new com.google.javascript.rhino.Node[] { node17, node19, node21, node23, node25 };
        com.google.javascript.rhino.Node node27 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray26);
        com.google.javascript.rhino.Node node28 = new com.google.javascript.rhino.Node(100, node14, node27);
        boolean boolean29 = closureCodingConvention0.isVarArgsParameter(node28);
        java.lang.String str30 = closureCodingConvention0.getGlobalObject();
        com.google.javascript.rhino.Node node35 = com.google.javascript.rhino.Node.newNumber(100.0d, 4095, 9);
        java.util.Set<java.lang.String> strSet36 = node35.getDirectives();
        com.google.javascript.rhino.Node node39 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node41 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node43 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node45 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node47 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray48 = new com.google.javascript.rhino.Node[] { node39, node41, node43, node45, node47 };
        com.google.javascript.rhino.Node node49 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray48);
        com.google.javascript.rhino.Node node51 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node52 = node49.copyInformationFrom(node51);
        com.google.javascript.rhino.Node node55 = new com.google.javascript.rhino.Node(28, node35, node49, (-2), (int) (byte) -1);
        boolean boolean56 = node55.isNoSideEffectsCall();
        com.google.javascript.rhino.Node node60 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node62 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node64 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node66 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node68 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray69 = new com.google.javascript.rhino.Node[] { node60, node62, node64, node66, node68 };
        com.google.javascript.rhino.Node node70 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray69);
        com.google.javascript.rhino.Node node72 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node73 = node70.copyInformationFrom(node72);
        com.google.javascript.rhino.Node node74 = node70.getParent();
        com.google.javascript.rhino.Node node75 = new com.google.javascript.rhino.Node((int) (short) -1, node70);
        boolean boolean76 = node70.wasEmptyNode();
        com.google.javascript.rhino.Node node78 = node70.getAncestor(0);
        java.lang.String str79 = closureCodingConvention0.extractClassNameIfProvide(node55, node70);
        com.google.javascript.rhino.Node node81 = node70.getAncestor(18);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(nodeArray13);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNotNull(nodeArray26);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "goog.global" + "'", str30.equals("goog.global"));
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertNull(strSet36);
        org.junit.Assert.assertNotNull(node39);
        org.junit.Assert.assertNotNull(node41);
        org.junit.Assert.assertNotNull(node43);
        org.junit.Assert.assertNotNull(node45);
        org.junit.Assert.assertNotNull(node47);
        org.junit.Assert.assertNotNull(nodeArray48);
        org.junit.Assert.assertNotNull(node51);
        org.junit.Assert.assertNotNull(node52);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertNotNull(node60);
        org.junit.Assert.assertNotNull(node62);
        org.junit.Assert.assertNotNull(node64);
        org.junit.Assert.assertNotNull(node66);
        org.junit.Assert.assertNotNull(node68);
        org.junit.Assert.assertNotNull(nodeArray69);
        org.junit.Assert.assertNotNull(node72);
        org.junit.Assert.assertNotNull(node73);
        org.junit.Assert.assertNull(node74);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
        org.junit.Assert.assertNotNull(node78);
        org.junit.Assert.assertNull(str79);
        org.junit.Assert.assertNull(node81);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.VISIBILITY;
        com.google.javascript.jscomp.DiagnosticType diagnosticType3 = com.google.javascript.jscomp.DiagnosticType.warning("com.google.javascript.rhino.EcmaError: TypeError: ", "com.google.javascript.rhino.EcmaError: TypeError: -1 is not a function, it is java.lang.Byte.");
        boolean boolean4 = diagnosticGroup0.matches(diagnosticType3);
        org.junit.Assert.assertNotNull(diagnosticGroup0);
        org.junit.Assert.assertNotNull(diagnosticType3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile3 = com.google.javascript.jscomp.JSSourceFile.fromFile("Not declared as a constructor");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile5 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.CompilerInput compilerInput6 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile5);
        com.google.javascript.jscomp.CompilerInput compilerInput9 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput6, "hi!", false);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile11 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        compilerInput6.setSourceFile((com.google.javascript.jscomp.SourceFile) jSSourceFile11);
        java.lang.String str13 = jSSourceFile11.toString();
        com.google.javascript.jscomp.CompilerOptions compilerOptions14 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean15 = compilerOptions14.aliasAllStrings;
        compilerOptions14.setGenerateExports(true);
        com.google.javascript.jscomp.Result result18 = compiler1.compile(jSSourceFile3, jSSourceFile11, compilerOptions14);
        com.google.javascript.jscomp.CompilerInput compilerInput19 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile11);
        java.lang.String str20 = jSSourceFile11.getName();
        org.junit.Assert.assertNotNull(jSSourceFile3);
        org.junit.Assert.assertNotNull(jSSourceFile5);
        org.junit.Assert.assertNotNull(jSSourceFile11);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(result18);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "" + "'", str20.equals(""));
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        int int0 = com.google.javascript.rhino.Context.FEATURE_TO_STRING_AS_SOURCE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        com.google.javascript.rhino.EcmaError ecmaError1 = com.google.javascript.rhino.ScriptRuntime.typeError("");
        java.lang.String str2 = ecmaError1.getSourceName();
        java.lang.Throwable[] throwableArray3 = ecmaError1.getSuppressed();
        org.junit.Assert.assertNotNull(ecmaError1);
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNotNull(throwableArray3);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString((int) (short) 0, "hi!", 100, (-2));
        com.google.javascript.rhino.Node node7 = new com.google.javascript.rhino.Node(10, node6);
        com.google.javascript.rhino.Node node8 = null;
        try {
            com.google.javascript.rhino.Node node9 = new com.google.javascript.rhino.Node(6, node6, node8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: first new child has existing parent");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node6);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray13 = new com.google.javascript.rhino.Node[] { node4, node6, node8, node10, node12 };
        com.google.javascript.rhino.Node node14 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray13);
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node21 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray26 = new com.google.javascript.rhino.Node[] { node17, node19, node21, node23, node25 };
        com.google.javascript.rhino.Node node27 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray26);
        com.google.javascript.rhino.Node node28 = new com.google.javascript.rhino.Node(100, node14, node27);
        boolean boolean29 = closureCodingConvention0.isVarArgsParameter(node28);
        java.util.Collection<com.google.javascript.jscomp.CodingConvention.AssertionFunctionSpec> assertionFunctionSpecCollection30 = closureCodingConvention0.getAssertionFunctions();
        boolean boolean32 = closureCodingConvention0.isConstant("NUMBER 100.0 4095\n");
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(nodeArray13);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNotNull(nodeArray26);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(assertionFunctionSpecCollection30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        com.google.javascript.rhino.Context.checkOptimizationLevel(0);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.checkDuplicateMessages = false;
        boolean boolean3 = compilerOptions0.inlineAnonymousFunctionExpressions;
        java.lang.String str4 = compilerOptions0.checkMissingGetCssNameBlacklist;
        compilerOptions0.removeUnusedLocalVars = true;
        com.google.javascript.jscomp.ErrorFormat errorFormat7 = compilerOptions0.errorFormat;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNotNull(errorFormat7);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile3 = com.google.javascript.jscomp.JSSourceFile.fromFile("Not declared as a constructor");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile5 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.CompilerInput compilerInput6 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile5);
        com.google.javascript.jscomp.CompilerInput compilerInput9 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput6, "hi!", false);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile11 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        compilerInput6.setSourceFile((com.google.javascript.jscomp.SourceFile) jSSourceFile11);
        java.lang.String str13 = jSSourceFile11.toString();
        com.google.javascript.jscomp.CompilerOptions compilerOptions14 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean15 = compilerOptions14.aliasAllStrings;
        compilerOptions14.setGenerateExports(true);
        com.google.javascript.jscomp.Result result18 = compiler1.compile(jSSourceFile3, jSSourceFile11, compilerOptions14);
        compilerOptions14.inlineLocalFunctions = true;
        compilerOptions14.devirtualizePrototypeMethods = true;
        compilerOptions14.skipAllCompilerPasses();
        org.junit.Assert.assertNotNull(jSSourceFile3);
        org.junit.Assert.assertNotNull(jSSourceFile5);
        org.junit.Assert.assertNotNull(jSSourceFile11);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(result18);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        int int0 = com.google.javascript.rhino.Node.FLAG_ARGUMENTS_UNMODIFIED;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        com.google.javascript.rhino.EcmaError ecmaError1 = com.google.javascript.rhino.ScriptRuntime.typeError("");
        int int2 = ecmaError1.columnNumber();
        java.lang.String str3 = ecmaError1.details();
        org.junit.Assert.assertNotNull(ecmaError1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "TypeError: " + "'", str3.equals("TypeError: "));
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.brokenClosureRequiresLevel;
        compilerOptions0.setManageClosureDependencies(true);
        java.lang.String[] strArray11 = new java.lang.String[] { "goog.exportProperty", "Not declared as a type name", "error reporter", "DiagnosticGroup<undefinedVars>", "goog.exportProperty", "Not declared as a constructor" };
        java.util.ArrayList<java.lang.String> strList12 = new java.util.ArrayList<java.lang.String>();
        boolean boolean13 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strList12, strArray11);
        compilerOptions0.setReplaceStringsConfiguration("goog.exportProperty", (java.util.List<java.lang.String>) strList12);
        compilerOptions0.ideMode = false;
        byte[] byteArray22 = new byte[] { (byte) 100, (byte) 1, (byte) 10, (byte) 10, (byte) 1 };
        compilerOptions0.inputVariableMapSerialized = byteArray22;
        compilerOptions0.checkCaja = true;
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(strArray11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(byteArray22);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        int int0 = com.google.javascript.rhino.Node.SIDE_EFFECTS_FLAGS_MASK;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 31 + "'", int0 == 31);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.brokenClosureRequiresLevel;
        com.google.javascript.jscomp.CheckLevel checkLevel2 = com.google.javascript.jscomp.CheckLevel.WARNING;
        compilerOptions0.checkGlobalNamesLevel = checkLevel2;
        compilerOptions0.computeFunctionSideEffects = true;
        boolean boolean6 = compilerOptions0.removeDeadCode;
        compilerOptions0.removeDeadCode = false;
        compilerOptions0.aliasExternals = true;
        boolean boolean11 = compilerOptions0.deadAssignmentElimination;
        com.google.javascript.jscomp.CheckLevel checkLevel12 = compilerOptions0.checkUndefinedProperties;
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + checkLevel2 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel2.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + checkLevel12 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel12.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.brokenClosureRequiresLevel;
        boolean boolean2 = compilerOptions0.collapseAnonymousFunctions;
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray15 = new com.google.javascript.rhino.Node[] { node6, node8, node10, node12, node14 };
        com.google.javascript.rhino.Node node16 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray15);
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node19 = node16.copyInformationFrom(node18);
        com.google.javascript.rhino.Node node20 = node16.getParent();
        com.google.javascript.rhino.Node node21 = new com.google.javascript.rhino.Node((int) (short) -1, node16);
        node16.detachChildren();
        com.google.javascript.jscomp.CompilerOptions compilerOptions24 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions24.checkDuplicateMessages = false;
        boolean boolean27 = compilerOptions24.inlineAnonymousFunctionExpressions;
        compilerOptions24.recordFunctionInformation = true;
        boolean boolean30 = compilerOptions24.checkCaja;
        compilerOptions24.aliasableGlobals = "EOF 0";
        boolean boolean33 = compilerOptions24.removeEmptyFunctions;
        boolean boolean34 = compilerOptions24.deadAssignmentElimination;
        com.google.javascript.jscomp.CheckLevel checkLevel35 = com.google.javascript.jscomp.CheckLevel.ERROR;
        compilerOptions24.checkUndefinedProperties = checkLevel35;
        node16.putProp(41, (java.lang.Object) checkLevel35);
        compilerOptions0.aggressiveVarCheck = checkLevel35;
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNotNull(nodeArray15);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNull(node20);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + checkLevel35 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel35.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        com.google.javascript.jscomp.DiagnosticType diagnosticType0 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        java.lang.String[] strArray1 = com.google.javascript.rhino.ScriptRuntime.emptyStrings;
        com.google.javascript.jscomp.JSError jSError2 = com.google.javascript.jscomp.JSError.make(diagnosticType0, strArray1);
        com.google.javascript.jscomp.DiagnosticType diagnosticType3 = jSError2.getType();
        com.google.javascript.jscomp.CompilerOptions compilerOptions4 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel5 = compilerOptions4.brokenClosureRequiresLevel;
        com.google.javascript.jscomp.CheckLevel checkLevel6 = com.google.javascript.jscomp.CheckLevel.WARNING;
        compilerOptions4.checkGlobalNamesLevel = checkLevel6;
        compilerOptions4.computeFunctionSideEffects = true;
        compilerOptions4.closurePass = false;
        com.google.javascript.jscomp.CompilerOptions compilerOptions12 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel13 = compilerOptions12.brokenClosureRequiresLevel;
        com.google.javascript.jscomp.CheckLevel checkLevel14 = com.google.javascript.jscomp.CheckLevel.WARNING;
        compilerOptions12.checkGlobalNamesLevel = checkLevel14;
        compilerOptions12.computeFunctionSideEffects = true;
        boolean boolean18 = compilerOptions12.removeDeadCode;
        compilerOptions12.inlineVariables = true;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy21 = com.google.javascript.jscomp.VariableRenamingPolicy.OFF;
        compilerOptions12.variableRenaming = variableRenamingPolicy21;
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy23 = com.google.javascript.jscomp.PropertyRenamingPolicy.HEURISTIC;
        compilerOptions4.setRenamingPolicy(variableRenamingPolicy21, propertyRenamingPolicy23);
        boolean boolean25 = jSError2.equals((java.lang.Object) compilerOptions4);
        org.junit.Assert.assertNotNull(diagnosticType0);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(jSError2);
        org.junit.Assert.assertNotNull(diagnosticType3);
        org.junit.Assert.assertTrue("'" + checkLevel5 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel5.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + checkLevel6 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel6.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
        org.junit.Assert.assertTrue("'" + checkLevel13 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel13.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + checkLevel14 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel14.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy21 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.OFF + "'", variableRenamingPolicy21.equals(com.google.javascript.jscomp.VariableRenamingPolicy.OFF));
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy23 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.HEURISTIC + "'", propertyRenamingPolicy23.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.HEURISTIC));
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.brokenClosureRequiresLevel;
        com.google.javascript.jscomp.CheckLevel checkLevel2 = com.google.javascript.jscomp.CheckLevel.WARNING;
        compilerOptions0.checkGlobalNamesLevel = checkLevel2;
        compilerOptions0.computeFunctionSideEffects = true;
        boolean boolean6 = compilerOptions0.removeDeadCode;
        compilerOptions0.inlineVariables = true;
        boolean boolean9 = compilerOptions0.removeDeadCode;
        com.google.common.collect.Multimap<com.google.javascript.jscomp.CustomPassExecutionTime, com.google.javascript.jscomp.CompilerPass> customPassExecutionTimeMultimap10 = null;
        compilerOptions0.customPasses = customPassExecutionTimeMultimap10;
        boolean boolean12 = compilerOptions0.groupVariableDeclarations;
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + checkLevel2 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel2.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile3 = com.google.javascript.jscomp.JSSourceFile.fromFile("Not declared as a constructor");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile5 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.CompilerInput compilerInput6 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile5);
        com.google.javascript.jscomp.CompilerInput compilerInput9 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput6, "hi!", false);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile11 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        compilerInput6.setSourceFile((com.google.javascript.jscomp.SourceFile) jSSourceFile11);
        java.lang.String str13 = jSSourceFile11.toString();
        com.google.javascript.jscomp.CompilerOptions compilerOptions14 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean15 = compilerOptions14.aliasAllStrings;
        compilerOptions14.setGenerateExports(true);
        com.google.javascript.jscomp.Result result18 = compiler1.compile(jSSourceFile3, jSSourceFile11, compilerOptions14);
        compilerOptions14.inlineLocalFunctions = true;
        compilerOptions14.devirtualizePrototypeMethods = true;
        java.lang.String str23 = compilerOptions14.syntheticBlockEndMarker;
        java.util.Set<java.lang.String> strSet24 = compilerOptions14.stripNameSuffixes;
        org.junit.Assert.assertNotNull(jSSourceFile3);
        org.junit.Assert.assertNotNull(jSSourceFile5);
        org.junit.Assert.assertNotNull(jSSourceFile11);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(result18);
        org.junit.Assert.assertNull(str23);
        org.junit.Assert.assertNotNull(strSet24);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        java.io.InputStream inputStream1 = null;
        try {
            com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromInputStream("1", inputStream1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test106() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test106");
//        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.CHECK_REGEXP;
//        com.google.javascript.jscomp.DiagnosticGroups.NON_STANDARD_JSDOC = diagnosticGroup0;
//        org.junit.Assert.assertNull(diagnosticGroup0);
//    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.NodeTraversal.Callback callback1 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal2 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler0, callback1);
        com.google.javascript.jscomp.PerformanceTracker performanceTracker3 = null;
        compiler0.tracker = performanceTracker3;
        try {
            boolean boolean5 = compiler0.isIdeMode();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.NodeTraversal.Callback callback1 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal2 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler0, callback1);
        com.google.javascript.jscomp.PerformanceTracker performanceTracker3 = null;
        compiler0.tracker = performanceTracker3;
        try {
            int int5 = compiler0.getWarningCount();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray13 = new com.google.javascript.rhino.Node[] { node4, node6, node8, node10, node12 };
        com.google.javascript.rhino.Node node14 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray13);
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node21 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray26 = new com.google.javascript.rhino.Node[] { node17, node19, node21, node23, node25 };
        com.google.javascript.rhino.Node node27 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray26);
        com.google.javascript.rhino.Node node28 = new com.google.javascript.rhino.Node(100, node14, node27);
        boolean boolean29 = closureCodingConvention0.isVarArgsParameter(node28);
        java.lang.String str30 = closureCodingConvention0.getGlobalObject();
        boolean boolean32 = closureCodingConvention0.isValidEnumKey("goog.global");
        com.google.javascript.rhino.Node node36 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node38 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node40 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node42 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node44 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray45 = new com.google.javascript.rhino.Node[] { node36, node38, node40, node42, node44 };
        com.google.javascript.rhino.Node node46 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray45);
        com.google.javascript.rhino.Node node48 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node49 = node46.copyInformationFrom(node48);
        com.google.javascript.rhino.Node node50 = node46.getParent();
        com.google.javascript.rhino.Node node51 = new com.google.javascript.rhino.Node((int) (short) -1, node46);
        boolean boolean52 = node46.wasEmptyNode();
        java.lang.String str53 = closureCodingConvention0.getSingletonGetterClassName(node46);
        com.google.javascript.rhino.jstype.FunctionType functionType54 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType55 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType56 = null;
        closureCodingConvention0.applySubclassRelationship(functionType54, functionType55, subclassType56);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(nodeArray13);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNotNull(nodeArray26);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "goog.global" + "'", str30.equals("goog.global"));
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNotNull(node36);
        org.junit.Assert.assertNotNull(node38);
        org.junit.Assert.assertNotNull(node40);
        org.junit.Assert.assertNotNull(node42);
        org.junit.Assert.assertNotNull(node44);
        org.junit.Assert.assertNotNull(nodeArray45);
        org.junit.Assert.assertNotNull(node48);
        org.junit.Assert.assertNotNull(node49);
        org.junit.Assert.assertNull(node50);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertNull(str53);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        com.google.javascript.rhino.EcmaError ecmaError1 = com.google.javascript.rhino.ScriptRuntime.typeError("");
        java.lang.String str2 = ecmaError1.details();
        java.lang.String str3 = ecmaError1.getName();
        java.lang.String str4 = ecmaError1.sourceName();
        com.google.javascript.rhino.EcmaError ecmaError7 = com.google.javascript.rhino.ScriptRuntime.constructError("", "language version");
        ecmaError7.initColumnNumber((int) (byte) 10);
        ecmaError1.addSuppressed((java.lang.Throwable) ecmaError7);
        java.lang.String str11 = ecmaError7.getScriptStackTrace();
        org.junit.Assert.assertNotNull(ecmaError1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "TypeError: " + "'", str2.equals("TypeError: "));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "TypeError" + "'", str3.equals("TypeError"));
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNotNull(ecmaError7);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "<No stack trace available>" + "'", str11.equals("<No stack trace available>"));
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.brokenClosureRequiresLevel;
        com.google.javascript.jscomp.CheckLevel checkLevel2 = com.google.javascript.jscomp.CheckLevel.WARNING;
        compilerOptions0.checkGlobalNamesLevel = checkLevel2;
        compilerOptions0.computeFunctionSideEffects = true;
        boolean boolean6 = compilerOptions0.removeDeadCode;
        compilerOptions0.inlineVariables = true;
        compilerOptions0.instrumentationTemplate = "Not declared as a constructor";
        java.util.Set<java.lang.String> strSet11 = compilerOptions0.stripNameSuffixes;
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + checkLevel2 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel2.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(strSet11);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.brokenClosureRequiresLevel;
        com.google.javascript.jscomp.CheckLevel checkLevel2 = com.google.javascript.jscomp.CheckLevel.WARNING;
        compilerOptions0.checkGlobalNamesLevel = checkLevel2;
        compilerOptions0.computeFunctionSideEffects = true;
        boolean boolean6 = compilerOptions0.removeDeadCode;
        compilerOptions0.inlineLocalVariables = false;
        compilerOptions0.setPropertyAffinity(true);
        compilerOptions0.setSummaryDetailLevel(14);
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + checkLevel2 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel2.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.AMBIGUOUS_FUNCTION_DECL;
        com.google.javascript.jscomp.DiagnosticGroups.TYPE_INVALIDATION = diagnosticGroup0;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray12 = new com.google.javascript.rhino.Node[] { node3, node5, node7, node9, node11 };
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray12);
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node16 = node13.copyInformationFrom(node15);
        com.google.javascript.rhino.Node node17 = node13.getParent();
        com.google.javascript.rhino.Node node18 = new com.google.javascript.rhino.Node((int) (short) -1, node13);
        node13.detachChildren();
        com.google.javascript.jscomp.CompilerOptions compilerOptions21 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions21.checkDuplicateMessages = false;
        boolean boolean24 = compilerOptions21.inlineAnonymousFunctionExpressions;
        compilerOptions21.recordFunctionInformation = true;
        boolean boolean27 = compilerOptions21.checkCaja;
        compilerOptions21.aliasableGlobals = "EOF 0";
        boolean boolean30 = compilerOptions21.removeEmptyFunctions;
        boolean boolean31 = compilerOptions21.deadAssignmentElimination;
        com.google.javascript.jscomp.CheckLevel checkLevel32 = com.google.javascript.jscomp.CheckLevel.ERROR;
        compilerOptions21.checkUndefinedProperties = checkLevel32;
        node13.putProp(41, (java.lang.Object) checkLevel32);
        boolean boolean35 = node13.hasOneChild();
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertNotNull(nodeArray12);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertNull(node17);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + checkLevel32 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel32.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.checkDuplicateMessages = false;
        boolean boolean3 = compilerOptions0.inlineAnonymousFunctionExpressions;
        compilerOptions0.recordFunctionInformation = true;
        boolean boolean6 = compilerOptions0.checkCaja;
        compilerOptions0.aliasableGlobals = "EOF 0";
        boolean boolean9 = compilerOptions0.removeEmptyFunctions;
        boolean boolean10 = compilerOptions0.deadAssignmentElimination;
        boolean boolean11 = compilerOptions0.optimizeCalls;
        compilerOptions0.moveFunctionDeclarations = false;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile3 = com.google.javascript.jscomp.JSSourceFile.fromFile("Not declared as a constructor");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile5 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.CompilerInput compilerInput6 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile5);
        com.google.javascript.jscomp.CompilerInput compilerInput9 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput6, "hi!", false);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile11 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        compilerInput6.setSourceFile((com.google.javascript.jscomp.SourceFile) jSSourceFile11);
        java.lang.String str13 = jSSourceFile11.toString();
        com.google.javascript.jscomp.CompilerOptions compilerOptions14 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean15 = compilerOptions14.aliasAllStrings;
        compilerOptions14.setGenerateExports(true);
        com.google.javascript.jscomp.Result result18 = compiler1.compile(jSSourceFile3, jSSourceFile11, compilerOptions14);
        java.lang.String str19 = compilerOptions14.syntheticBlockStartMarker;
        java.util.Set<java.lang.String> strSet20 = compilerOptions14.stripNamePrefixes;
        org.junit.Assert.assertNotNull(jSSourceFile3);
        org.junit.Assert.assertNotNull(jSSourceFile5);
        org.junit.Assert.assertNotNull(jSSourceFile11);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(result18);
        org.junit.Assert.assertNull(str19);
        org.junit.Assert.assertNotNull(strSet20);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray12 = new com.google.javascript.rhino.Node[] { node3, node5, node7, node9, node11 };
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray12);
        int int14 = node13.getSideEffectFlags();
        com.google.javascript.rhino.Node node15 = node13.getNext();
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention16 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node22 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node24 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node26 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node28 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray29 = new com.google.javascript.rhino.Node[] { node20, node22, node24, node26, node28 };
        com.google.javascript.rhino.Node node30 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray29);
        com.google.javascript.rhino.Node node33 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node35 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node37 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node39 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node41 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray42 = new com.google.javascript.rhino.Node[] { node33, node35, node37, node39, node41 };
        com.google.javascript.rhino.Node node43 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray42);
        com.google.javascript.rhino.Node node44 = new com.google.javascript.rhino.Node(100, node30, node43);
        java.lang.String str45 = closureCodingConvention16.getSingletonGetterClassName(node44);
        node44.setWasEmptyNode(true);
        com.google.javascript.rhino.Node node51 = com.google.javascript.rhino.Node.newNumber(100.0d, 4095, 9);
        java.util.Set<java.lang.String> strSet52 = node51.getDirectives();
        com.google.javascript.rhino.Node node55 = new com.google.javascript.rhino.Node((int) (short) 0, node13, node44, node51, (int) (short) 10, (int) ' ');
        boolean boolean56 = node55.isNoSideEffectsCall();
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertNotNull(nodeArray12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNull(node15);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertNotNull(nodeArray29);
        org.junit.Assert.assertNotNull(node33);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertNotNull(node37);
        org.junit.Assert.assertNotNull(node39);
        org.junit.Assert.assertNotNull(node41);
        org.junit.Assert.assertNotNull(nodeArray42);
        org.junit.Assert.assertNull(str45);
        org.junit.Assert.assertNotNull(node51);
        org.junit.Assert.assertNull(strSet52);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.checkDuplicateMessages = false;
        compilerOptions0.collapseProperties = false;
        java.lang.String str5 = compilerOptions0.nameReferenceReportPath;
        com.google.javascript.jscomp.CompilerOptions compilerOptions6 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel7 = compilerOptions6.brokenClosureRequiresLevel;
        com.google.javascript.jscomp.CheckLevel checkLevel8 = com.google.javascript.jscomp.CheckLevel.WARNING;
        compilerOptions6.checkGlobalNamesLevel = checkLevel8;
        compilerOptions6.computeFunctionSideEffects = true;
        boolean boolean12 = compilerOptions6.removeDeadCode;
        compilerOptions6.inlineVariables = true;
        boolean boolean15 = compilerOptions6.removeDeadCode;
        compilerOptions6.closurePass = true;
        com.google.javascript.jscomp.CompilerOptions compilerOptions18 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions18.checkDuplicateMessages = false;
        boolean boolean21 = compilerOptions18.inlineAnonymousFunctionExpressions;
        compilerOptions18.recordFunctionInformation = true;
        boolean boolean24 = compilerOptions18.checkCaja;
        compilerOptions18.aliasableGlobals = "EOF 0";
        com.google.javascript.jscomp.CheckLevel checkLevel27 = com.google.javascript.jscomp.CheckLevel.OFF;
        compilerOptions18.reportUnknownTypes = checkLevel27;
        com.google.javascript.jscomp.CompilerOptions compilerOptions29 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions29.checkDuplicateMessages = false;
        boolean boolean32 = compilerOptions29.inlineAnonymousFunctionExpressions;
        compilerOptions29.recordFunctionInformation = true;
        boolean boolean35 = compilerOptions29.checkCaja;
        java.util.Set<java.lang.String> strSet36 = compilerOptions29.stripNamePrefixes;
        compilerOptions18.setIdGenerators(strSet36);
        compilerOptions6.stripTypes = strSet36;
        compilerOptions0.stripNamePrefixes = strSet36;
        compilerOptions0.locale = "hi!";
        java.lang.String str42 = compilerOptions0.nameReferenceReportPath;
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertTrue("'" + checkLevel7 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel7.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + checkLevel8 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel8.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + checkLevel27 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel27.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(strSet36);
        org.junit.Assert.assertNull(str42);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.checkDuplicateMessages = false;
        compilerOptions0.tightenTypes = true;
        boolean boolean5 = compilerOptions0.closurePass;
        boolean boolean6 = compilerOptions0.optimizeParameters;
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.checkDuplicateMessages = false;
        boolean boolean3 = compilerOptions0.inlineAnonymousFunctionExpressions;
        compilerOptions0.recordFunctionInformation = true;
        boolean boolean6 = compilerOptions0.checkCaja;
        compilerOptions0.aliasableGlobals = "EOF 0";
        boolean boolean9 = compilerOptions0.removeEmptyFunctions;
        boolean boolean10 = compilerOptions0.deadAssignmentElimination;
        com.google.javascript.jscomp.CheckLevel checkLevel11 = compilerOptions0.checkMethods;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + checkLevel11 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel11.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.checkDuplicateMessages = false;
        boolean boolean3 = compilerOptions0.inlineAnonymousFunctionExpressions;
        java.lang.String str4 = compilerOptions0.checkMissingGetCssNameBlacklist;
        compilerOptions0.inlineAnonymousFunctionExpressions = false;
        com.google.javascript.jscomp.CheckLevel checkLevel7 = null;
        compilerOptions0.checkGlobalThisLevel = checkLevel7;
        com.google.javascript.jscomp.CheckLevel checkLevel9 = compilerOptions0.checkMethods;
        boolean boolean10 = compilerOptions0.checkDuplicateMessages;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + checkLevel9 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel9.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.brokenClosureRequiresLevel;
        com.google.javascript.jscomp.CheckLevel checkLevel2 = com.google.javascript.jscomp.CheckLevel.WARNING;
        compilerOptions0.checkGlobalNamesLevel = checkLevel2;
        compilerOptions0.computeFunctionSideEffects = true;
        boolean boolean6 = compilerOptions0.removeDeadCode;
        compilerOptions0.setManageClosureDependencies(false);
        compilerOptions0.nameReferenceGraphPath = "";
        java.lang.String str11 = compilerOptions0.syntheticBlockStartMarker;
        compilerOptions0.inputDelimiter = "// Input %num%";
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + checkLevel2 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel2.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(str11);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.checkDuplicateMessages = false;
        boolean boolean3 = compilerOptions0.inlineAnonymousFunctionExpressions;
        compilerOptions0.recordFunctionInformation = true;
        boolean boolean6 = compilerOptions0.checkCaja;
        compilerOptions0.aliasableGlobals = "EOF 0";
        com.google.javascript.jscomp.CheckLevel checkLevel9 = com.google.javascript.jscomp.CheckLevel.OFF;
        compilerOptions0.reportUnknownTypes = checkLevel9;
        com.google.javascript.jscomp.CompilerOptions compilerOptions11 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions11.checkDuplicateMessages = false;
        boolean boolean14 = compilerOptions11.inlineAnonymousFunctionExpressions;
        compilerOptions11.recordFunctionInformation = true;
        boolean boolean17 = compilerOptions11.checkCaja;
        java.util.Set<java.lang.String> strSet18 = compilerOptions11.stripNamePrefixes;
        compilerOptions0.setIdGenerators(strSet18);
        compilerOptions0.extractPrototypeMemberDeclarations = true;
        byte[] byteArray22 = compilerOptions0.inputVariableMapSerialized;
        compilerOptions0.crossModuleCodeMotion = false;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + checkLevel9 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel9.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(strSet18);
        org.junit.Assert.assertNull(byteArray22);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.brokenClosureRequiresLevel;
        com.google.javascript.jscomp.CheckLevel checkLevel2 = com.google.javascript.jscomp.CheckLevel.WARNING;
        compilerOptions0.checkGlobalNamesLevel = checkLevel2;
        compilerOptions0.checkMissingGetCssNameBlacklist = "JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of optimization iterations: {0}";
        com.google.javascript.jscomp.CompilerOptions compilerOptions6 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel7 = compilerOptions6.brokenClosureRequiresLevel;
        java.util.Set<java.lang.String> strSet8 = compilerOptions6.aliasableStrings;
        boolean boolean9 = compilerOptions6.decomposeExpressions;
        java.util.Set<java.lang.String> strSet10 = compilerOptions6.stripNamePrefixes;
        boolean boolean11 = compilerOptions6.instrumentForCoverageOnly;
        com.google.javascript.jscomp.CheckLevel checkLevel12 = compilerOptions6.checkMissingReturn;
        compilerOptions6.labelRenaming = false;
        java.lang.RuntimeException runtimeException15 = com.google.javascript.rhino.ScriptRuntime.undefReadError((java.lang.Object) compilerOptions0, (java.lang.Object) false);
        java.lang.String str16 = compilerOptions0.renamePrefix;
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + checkLevel2 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel2.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
        org.junit.Assert.assertTrue("'" + checkLevel7 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel7.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(strSet8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(strSet10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + checkLevel12 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel12.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(runtimeException15);
        org.junit.Assert.assertNull(str16);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.checkDuplicateMessages = false;
        boolean boolean3 = compilerOptions0.inlineAnonymousFunctionExpressions;
        compilerOptions0.recordFunctionInformation = true;
        boolean boolean6 = compilerOptions0.checkCaja;
        compilerOptions0.allowLegacyJsMessages = true;
        compilerOptions0.aliasKeywords = false;
        boolean boolean11 = compilerOptions0.collapseAnonymousFunctions;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile3 = com.google.javascript.jscomp.JSSourceFile.fromFile("Not declared as a constructor");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile5 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.CompilerInput compilerInput6 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile5);
        com.google.javascript.jscomp.CompilerInput compilerInput9 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput6, "hi!", false);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile11 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        compilerInput6.setSourceFile((com.google.javascript.jscomp.SourceFile) jSSourceFile11);
        java.lang.String str13 = jSSourceFile11.toString();
        com.google.javascript.jscomp.CompilerOptions compilerOptions14 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean15 = compilerOptions14.aliasAllStrings;
        compilerOptions14.setGenerateExports(true);
        com.google.javascript.jscomp.Result result18 = compiler1.compile(jSSourceFile3, jSSourceFile11, compilerOptions14);
        com.google.javascript.jscomp.CompilerInput compilerInput19 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile11);
        com.google.javascript.jscomp.CompilerInput compilerInput20 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput19);
        com.google.javascript.jscomp.JSModule jSModule21 = null;
        compilerInput19.setModule(jSModule21);
        com.google.javascript.jscomp.SourceAst sourceAst23 = compilerInput19.getSourceAst();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile25 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.CompilerInput compilerInput26 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile25);
        com.google.javascript.jscomp.CompilerInput compilerInput29 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput26, "hi!", false);
        com.google.javascript.jscomp.Compiler compiler30 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile32 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.CompilerInput compilerInput33 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile32);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile35 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.CompilerInput compilerInput36 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile35);
        com.google.javascript.jscomp.CompilerInput compilerInput39 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput36, "hi!", false);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile41 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        compilerInput36.setSourceFile((com.google.javascript.jscomp.SourceFile) jSSourceFile41);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile44 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray45 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile32, jSSourceFile41, jSSourceFile44 };
        java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList46 = new java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile>();
        boolean boolean47 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList46, jSSourceFileArray45);
        com.google.javascript.jscomp.JSModule[] jSModuleArray48 = new com.google.javascript.jscomp.JSModule[] {};
        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList49 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
        boolean boolean50 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList49, jSModuleArray48);
        com.google.javascript.jscomp.CompilerOptions compilerOptions51 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions51.checkDuplicateMessages = false;
        boolean boolean54 = compilerOptions51.inlineAnonymousFunctionExpressions;
        compilerOptions51.crossModuleMethodMotion = true;
        com.google.javascript.jscomp.Result result57 = compiler30.compileModules((java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList46, (java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList49, compilerOptions51);
        compilerInput26.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler30);
        com.google.javascript.jscomp.Scope scope59 = compiler30.getTopScope();
        com.google.javascript.rhino.Node node60 = compilerInput19.getAstRoot((com.google.javascript.jscomp.AbstractCompiler) compiler30);
        com.google.javascript.jscomp.JSError[] jSErrorArray61 = compiler30.getMessages();
        com.google.javascript.jscomp.Region region64 = compiler30.getSourceRegion("com.google.javascript.rhino.EcmaError: TypeError: -1 is not a function, it is java.lang.Byte.", 15);
        org.junit.Assert.assertNotNull(jSSourceFile3);
        org.junit.Assert.assertNotNull(jSSourceFile5);
        org.junit.Assert.assertNotNull(jSSourceFile11);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(result18);
        org.junit.Assert.assertNotNull(sourceAst23);
        org.junit.Assert.assertNotNull(jSSourceFile25);
        org.junit.Assert.assertNotNull(jSSourceFile32);
        org.junit.Assert.assertNotNull(jSSourceFile35);
        org.junit.Assert.assertNotNull(jSSourceFile41);
        org.junit.Assert.assertNotNull(jSSourceFile44);
        org.junit.Assert.assertNotNull(jSSourceFileArray45);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
        org.junit.Assert.assertNotNull(jSModuleArray48);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNotNull(result57);
        org.junit.Assert.assertNull(scope59);
        org.junit.Assert.assertNull(node60);
        org.junit.Assert.assertNotNull(jSErrorArray61);
        org.junit.Assert.assertNull(region64);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile3 = com.google.javascript.jscomp.JSSourceFile.fromFile("Not declared as a constructor");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile5 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.CompilerInput compilerInput6 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile5);
        com.google.javascript.jscomp.CompilerInput compilerInput9 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput6, "hi!", false);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile11 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        compilerInput6.setSourceFile((com.google.javascript.jscomp.SourceFile) jSSourceFile11);
        java.lang.String str13 = jSSourceFile11.toString();
        com.google.javascript.jscomp.CompilerOptions compilerOptions14 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean15 = compilerOptions14.aliasAllStrings;
        compilerOptions14.setGenerateExports(true);
        com.google.javascript.jscomp.Result result18 = compiler1.compile(jSSourceFile3, jSSourceFile11, compilerOptions14);
        com.google.javascript.jscomp.CompilerInput compilerInput19 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile11);
        com.google.javascript.jscomp.CompilerInput compilerInput20 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput19);
        com.google.javascript.jscomp.SourceFile sourceFile21 = compilerInput19.getSourceFile();
        java.lang.String str22 = sourceFile21.getOriginalPath();
        org.junit.Assert.assertNotNull(jSSourceFile3);
        org.junit.Assert.assertNotNull(jSSourceFile5);
        org.junit.Assert.assertNotNull(jSSourceFile11);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(result18);
        org.junit.Assert.assertNotNull(sourceFile21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "" + "'", str22.equals(""));
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.brokenClosureRequiresLevel;
        com.google.javascript.jscomp.CheckLevel checkLevel2 = com.google.javascript.jscomp.CheckLevel.WARNING;
        compilerOptions0.checkGlobalNamesLevel = checkLevel2;
        compilerOptions0.computeFunctionSideEffects = true;
        compilerOptions0.closurePass = false;
        com.google.javascript.jscomp.CompilerOptions compilerOptions8 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel9 = compilerOptions8.brokenClosureRequiresLevel;
        compilerOptions0.checkGlobalThisLevel = checkLevel9;
        compilerOptions0.collapseVariableDeclarations = false;
        com.google.javascript.jscomp.CheckLevel checkLevel13 = compilerOptions0.checkGlobalNamesLevel;
        compilerOptions0.setSummaryDetailLevel((int) (byte) 1);
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + checkLevel2 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel2.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
        org.junit.Assert.assertTrue("'" + checkLevel9 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel9.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + checkLevel13 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel13.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.Compiler compiler2 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile4 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.CompilerInput compilerInput5 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile4);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile7 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.CompilerInput compilerInput8 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile7);
        com.google.javascript.jscomp.CompilerInput compilerInput11 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput8, "hi!", false);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile13 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        compilerInput8.setSourceFile((com.google.javascript.jscomp.SourceFile) jSSourceFile13);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile16 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray17 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile4, jSSourceFile13, jSSourceFile16 };
        java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList18 = new java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile>();
        boolean boolean19 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList18, jSSourceFileArray17);
        com.google.javascript.jscomp.JSModule[] jSModuleArray20 = new com.google.javascript.jscomp.JSModule[] {};
        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList21 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
        boolean boolean22 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList21, jSModuleArray20);
        com.google.javascript.jscomp.CompilerOptions compilerOptions23 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions23.checkDuplicateMessages = false;
        boolean boolean26 = compilerOptions23.inlineAnonymousFunctionExpressions;
        compilerOptions23.crossModuleMethodMotion = true;
        com.google.javascript.jscomp.Result result29 = compiler2.compileModules((java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList18, (java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList21, compilerOptions23);
        com.google.javascript.jscomp.Compiler compiler30 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile32 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.CompilerInput compilerInput33 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile32);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile35 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.CompilerInput compilerInput36 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile35);
        com.google.javascript.jscomp.CompilerInput compilerInput39 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput36, "hi!", false);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile41 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        compilerInput36.setSourceFile((com.google.javascript.jscomp.SourceFile) jSSourceFile41);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile44 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray45 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile32, jSSourceFile41, jSSourceFile44 };
        java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList46 = new java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile>();
        boolean boolean47 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList46, jSSourceFileArray45);
        com.google.javascript.jscomp.JSModule[] jSModuleArray48 = new com.google.javascript.jscomp.JSModule[] {};
        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList49 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
        boolean boolean50 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList49, jSModuleArray48);
        com.google.javascript.jscomp.CompilerOptions compilerOptions51 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions51.checkDuplicateMessages = false;
        boolean boolean54 = compilerOptions51.inlineAnonymousFunctionExpressions;
        compilerOptions51.crossModuleMethodMotion = true;
        com.google.javascript.jscomp.Result result57 = compiler30.compileModules((java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList46, (java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList49, compilerOptions51);
        com.google.javascript.jscomp.CompilerOptions compilerOptions58 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel59 = compilerOptions58.brokenClosureRequiresLevel;
        java.util.Set<java.lang.String> strSet60 = compilerOptions58.aliasableStrings;
        boolean boolean61 = compilerOptions58.decomposeExpressions;
        java.util.Set<java.lang.String> strSet62 = compilerOptions58.stripNamePrefixes;
        com.google.javascript.jscomp.Result result63 = compiler1.compile((java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList18, (java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList46, compilerOptions58);
        compiler1.rebuildInputsFromModules();
        try {
            compiler1.check();
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: INTERNAL COMPILER ERROR.\nPlease report this problem.\nnull");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile4);
        org.junit.Assert.assertNotNull(jSSourceFile7);
        org.junit.Assert.assertNotNull(jSSourceFile13);
        org.junit.Assert.assertNotNull(jSSourceFile16);
        org.junit.Assert.assertNotNull(jSSourceFileArray17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(jSModuleArray20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(result29);
        org.junit.Assert.assertNotNull(jSSourceFile32);
        org.junit.Assert.assertNotNull(jSSourceFile35);
        org.junit.Assert.assertNotNull(jSSourceFile41);
        org.junit.Assert.assertNotNull(jSSourceFile44);
        org.junit.Assert.assertNotNull(jSSourceFileArray45);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
        org.junit.Assert.assertNotNull(jSModuleArray48);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNotNull(result57);
        org.junit.Assert.assertTrue("'" + checkLevel59 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel59.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(strSet60);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertNotNull(strSet62);
        org.junit.Assert.assertNotNull(result63);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray13 = new com.google.javascript.rhino.Node[] { node4, node6, node8, node10, node12 };
        com.google.javascript.rhino.Node node14 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray13);
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node21 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray26 = new com.google.javascript.rhino.Node[] { node17, node19, node21, node23, node25 };
        com.google.javascript.rhino.Node node27 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray26);
        com.google.javascript.rhino.Node node28 = new com.google.javascript.rhino.Node(100, node14, node27);
        boolean boolean29 = closureCodingConvention0.isVarArgsParameter(node28);
        java.lang.String str30 = closureCodingConvention0.getGlobalObject();
        boolean boolean32 = closureCodingConvention0.isValidEnumKey("goog.global");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention33 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node37 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node39 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node41 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node43 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node45 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray46 = new com.google.javascript.rhino.Node[] { node37, node39, node41, node43, node45 };
        com.google.javascript.rhino.Node node47 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray46);
        com.google.javascript.rhino.Node node50 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node52 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node54 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node56 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node58 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray59 = new com.google.javascript.rhino.Node[] { node50, node52, node54, node56, node58 };
        com.google.javascript.rhino.Node node60 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray59);
        com.google.javascript.rhino.Node node61 = new com.google.javascript.rhino.Node(100, node47, node60);
        java.lang.String str62 = closureCodingConvention33.getSingletonGetterClassName(node61);
        com.google.javascript.rhino.Node node68 = com.google.javascript.rhino.Node.newString((int) (short) 0, "hi!", 100, (-2));
        com.google.javascript.rhino.Node node69 = new com.google.javascript.rhino.Node(10, node68);
        java.lang.String str70 = closureCodingConvention33.identifyTypeDefAssign(node69);
        com.google.javascript.rhino.Node node71 = node69.cloneNode();
        com.google.javascript.rhino.Node node74 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node76 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node78 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node80 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node82 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray83 = new com.google.javascript.rhino.Node[] { node74, node76, node78, node80, node82 };
        com.google.javascript.rhino.Node node84 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray83);
        int int85 = node84.getSideEffectFlags();
        java.lang.String str86 = closureCodingConvention0.extractClassNameIfProvide(node71, node84);
        boolean boolean87 = node71.isQualifiedName();
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(nodeArray13);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNotNull(nodeArray26);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "goog.global" + "'", str30.equals("goog.global"));
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNotNull(node37);
        org.junit.Assert.assertNotNull(node39);
        org.junit.Assert.assertNotNull(node41);
        org.junit.Assert.assertNotNull(node43);
        org.junit.Assert.assertNotNull(node45);
        org.junit.Assert.assertNotNull(nodeArray46);
        org.junit.Assert.assertNotNull(node50);
        org.junit.Assert.assertNotNull(node52);
        org.junit.Assert.assertNotNull(node54);
        org.junit.Assert.assertNotNull(node56);
        org.junit.Assert.assertNotNull(node58);
        org.junit.Assert.assertNotNull(nodeArray59);
        org.junit.Assert.assertNull(str62);
        org.junit.Assert.assertNotNull(node68);
        org.junit.Assert.assertNull(str70);
        org.junit.Assert.assertNotNull(node71);
        org.junit.Assert.assertNotNull(node74);
        org.junit.Assert.assertNotNull(node76);
        org.junit.Assert.assertNotNull(node78);
        org.junit.Assert.assertNotNull(node80);
        org.junit.Assert.assertNotNull(node82);
        org.junit.Assert.assertNotNull(nodeArray83);
        org.junit.Assert.assertTrue("'" + int85 + "' != '" + 0 + "'", int85 == 0);
        org.junit.Assert.assertNull(str86);
        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + false + "'", boolean87 == false);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        com.google.javascript.jscomp.CompilerOptions.TracerMode tracerMode0 = com.google.javascript.jscomp.CompilerOptions.TracerMode.OFF;
        org.junit.Assert.assertTrue("'" + tracerMode0 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TracerMode.OFF + "'", tracerMode0.equals(com.google.javascript.jscomp.CompilerOptions.TracerMode.OFF));
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        boolean boolean2 = closureCodingConvention0.isConstant("");
        boolean boolean4 = closureCodingConvention0.isValidEnumKey("hi!");
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray17 = new com.google.javascript.rhino.Node[] { node8, node10, node12, node14, node16 };
        com.google.javascript.rhino.Node node18 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray17);
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node21 = node18.copyInformationFrom(node20);
        com.google.javascript.rhino.Node node22 = node18.getParent();
        com.google.javascript.rhino.Node node23 = new com.google.javascript.rhino.Node((int) (short) -1, node18);
        com.google.javascript.rhino.Node node28 = com.google.javascript.rhino.Node.newString((int) (short) 0, "hi!", 100, (-2));
        boolean boolean29 = node18.isEquivalentTo(node28);
        com.google.javascript.rhino.Node node32 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node34 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node36 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node38 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node40 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray41 = new com.google.javascript.rhino.Node[] { node32, node34, node36, node38, node40 };
        com.google.javascript.rhino.Node node42 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray41);
        com.google.javascript.rhino.Node node44 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node45 = node42.copyInformationFrom(node44);
        com.google.javascript.jscomp.parsing.Config.LanguageMode languageMode47 = com.google.javascript.jscomp.parsing.Config.LanguageMode.ECMASCRIPT5;
        node45.putProp(24, (java.lang.Object) languageMode47);
        java.lang.String str49 = closureCodingConvention0.extractClassNameIfRequire(node18, node45);
        node45.setType(100);
        boolean boolean52 = node45.isOnlyModifiesThisCall();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertNotNull(nodeArray17);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertNull(node22);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(node32);
        org.junit.Assert.assertNotNull(node34);
        org.junit.Assert.assertNotNull(node36);
        org.junit.Assert.assertNotNull(node38);
        org.junit.Assert.assertNotNull(node40);
        org.junit.Assert.assertNotNull(nodeArray41);
        org.junit.Assert.assertNotNull(node44);
        org.junit.Assert.assertNotNull(node45);
        org.junit.Assert.assertTrue("'" + languageMode47 + "' != '" + com.google.javascript.jscomp.parsing.Config.LanguageMode.ECMASCRIPT5 + "'", languageMode47.equals(com.google.javascript.jscomp.parsing.Config.LanguageMode.ECMASCRIPT5));
        org.junit.Assert.assertNull(str49);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray11 = new com.google.javascript.rhino.Node[] { node2, node4, node6, node8, node10 };
        com.google.javascript.rhino.Node node12 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray11);
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node15 = node12.copyInformationFrom(node14);
        node12.setCharno((-1));
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(nodeArray11);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNotNull(node15);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.brokenClosureRequiresLevel;
        com.google.javascript.jscomp.CheckLevel checkLevel2 = com.google.javascript.jscomp.CheckLevel.WARNING;
        compilerOptions0.checkGlobalNamesLevel = checkLevel2;
        com.google.javascript.jscomp.ErrorFormat errorFormat4 = null;
        compilerOptions0.errorFormat = errorFormat4;
        java.lang.String str6 = compilerOptions0.checkMissingGetCssNameBlacklist;
        compilerOptions0.locale = "DiagnosticGroup<deprecated>";
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + checkLevel2 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel2.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
        org.junit.Assert.assertNull(str6);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.brokenClosureRequiresLevel;
        com.google.javascript.jscomp.CheckLevel checkLevel2 = com.google.javascript.jscomp.CheckLevel.WARNING;
        compilerOptions0.checkGlobalNamesLevel = checkLevel2;
        compilerOptions0.computeFunctionSideEffects = true;
        compilerOptions0.setShadowVariables(true);
        compilerOptions0.debugFunctionSideEffectsPath = "goog.global";
        java.lang.String str10 = compilerOptions0.inputDelimiter;
        compilerOptions0.decomposeExpressions = false;
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + checkLevel2 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel2.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "// Input %num%" + "'", str10.equals("// Input %num%"));
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newString((int) (short) 0, "hi!", 100, (-2));
        com.google.javascript.rhino.Node node6 = new com.google.javascript.rhino.Node(10, node5);
        node5.setLineno((-1));
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newNumber(0.0d, (int) (short) 1, (int) ' ');
        int int14 = node12.getIntProp(10);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder15 = node12.getJsDocBuilderForNode();
        java.lang.String str16 = node5.checkTreeEquals(node12);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Node tree inequality:\nTree1:\nEOF hi!\n\n\nTree2:\nNUMBER 0.0 1\n\n\nSubtree1: EOF hi!\n\n\nSubtree2: NUMBER 0.0 1\n" + "'", str16.equals("Node tree inequality:\nTree1:\nEOF hi!\n\n\nTree2:\nNUMBER 0.0 1\n\n\nSubtree1: EOF hi!\n\n\nSubtree2: NUMBER 0.0 1\n"));
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray0 = new com.google.javascript.jscomp.WarningsGuard[] {};
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard1 = new com.google.javascript.jscomp.ComposeWarningsGuard(warningsGuardArray0);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup2 = com.google.javascript.jscomp.DiagnosticGroups.STRICT_MODULE_DEP_CHECK;
        boolean boolean3 = composeWarningsGuard1.disables(diagnosticGroup2);
        com.google.javascript.jscomp.DiagnosticGroups.CHECK_VARIABLES = diagnosticGroup2;
        com.google.javascript.jscomp.CheckLevel checkLevel5 = com.google.javascript.jscomp.CheckLevel.ERROR;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard6 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup2, checkLevel5);
        org.junit.Assert.assertNotNull(warningsGuardArray0);
        org.junit.Assert.assertNotNull(diagnosticGroup2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + checkLevel5 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel5.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.brokenClosureRequiresLevel;
        com.google.javascript.jscomp.CheckLevel checkLevel2 = com.google.javascript.jscomp.CheckLevel.WARNING;
        compilerOptions0.checkGlobalNamesLevel = checkLevel2;
        compilerOptions0.computeFunctionSideEffects = true;
        boolean boolean6 = compilerOptions0.removeDeadCode;
        compilerOptions0.removeUnusedLocalVars = true;
        com.google.javascript.jscomp.AnonymousFunctionNamingPolicy anonymousFunctionNamingPolicy9 = com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.MAPPED;
        char[] charArray10 = anonymousFunctionNamingPolicy9.getReservedCharacters();
        compilerOptions0.anonymousFunctionNaming = anonymousFunctionNamingPolicy9;
        compilerOptions0.optimizeArgumentsArray = false;
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + checkLevel2 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel2.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + anonymousFunctionNamingPolicy9 + "' != '" + com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.MAPPED + "'", anonymousFunctionNamingPolicy9.equals(com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.MAPPED));
        org.junit.Assert.assertNotNull(charArray10);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        com.google.javascript.jscomp.MessageFormatter messageFormatter0 = null;
        java.util.logging.Logger logger1 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager2 = new com.google.javascript.jscomp.LoggerErrorManager(messageFormatter0, logger1);
        com.google.javascript.jscomp.Compiler compiler3 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager2);
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter4 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler3);
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString((int) (short) 0, "hi!", 100, (-2));
        com.google.javascript.jscomp.DiagnosticType diagnosticType11 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray12 = com.google.javascript.rhino.ScriptRuntime.emptyStrings;
        com.google.javascript.jscomp.JSError jSError13 = com.google.javascript.jscomp.JSError.make("", node10, diagnosticType11, strArray12);
        java.lang.String str14 = jSError13.description;
        com.google.javascript.jscomp.CompilerOptions compilerOptions15 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel16 = compilerOptions15.brokenClosureRequiresLevel;
        com.google.javascript.jscomp.CheckLevel checkLevel17 = com.google.javascript.jscomp.CheckLevel.WARNING;
        compilerOptions15.checkGlobalNamesLevel = checkLevel17;
        compilerOptions15.computeFunctionSideEffects = true;
        boolean boolean21 = compilerOptions15.removeDeadCode;
        compilerOptions15.removeUnusedLocalVars = true;
        com.google.javascript.jscomp.CheckLevel checkLevel24 = compilerOptions15.checkGlobalNamesLevel;
        com.google.javascript.jscomp.ErrorFormat errorFormat25 = com.google.javascript.jscomp.ErrorFormat.SINGLELINE;
        java.io.PrintStream printStream26 = null;
        com.google.javascript.jscomp.Compiler compiler27 = new com.google.javascript.jscomp.Compiler(printStream26);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile29 = com.google.javascript.jscomp.JSSourceFile.fromFile("Not declared as a constructor");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile31 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.CompilerInput compilerInput32 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile31);
        com.google.javascript.jscomp.CompilerInput compilerInput35 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput32, "hi!", false);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile37 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        compilerInput32.setSourceFile((com.google.javascript.jscomp.SourceFile) jSSourceFile37);
        java.lang.String str39 = jSSourceFile37.toString();
        com.google.javascript.jscomp.CompilerOptions compilerOptions40 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean41 = compilerOptions40.aliasAllStrings;
        compilerOptions40.setGenerateExports(true);
        com.google.javascript.jscomp.Result result44 = compiler27.compile(jSSourceFile29, jSSourceFile37, compilerOptions40);
        com.google.javascript.jscomp.MessageFormatter messageFormatter46 = errorFormat25.toFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler27, false);
        java.lang.String str47 = jSError13.format(checkLevel24, messageFormatter46);
        java.lang.String str48 = lightweightMessageFormatter4.formatError(jSError13);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(diagnosticType11);
        org.junit.Assert.assertNotNull(strArray12);
        org.junit.Assert.assertNotNull(jSError13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "{0}" + "'", str14.equals("{0}"));
        org.junit.Assert.assertTrue("'" + checkLevel16 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel16.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + checkLevel17 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel17.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + checkLevel24 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel24.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
        org.junit.Assert.assertNotNull(errorFormat25);
        org.junit.Assert.assertNotNull(jSSourceFile29);
        org.junit.Assert.assertNotNull(jSSourceFile31);
        org.junit.Assert.assertNotNull(jSSourceFile37);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "" + "'", str39.equals(""));
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(result44);
        org.junit.Assert.assertNotNull(messageFormatter46);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + ": WARNING - {0}\n" + "'", str47.equals(": WARNING - {0}\n"));
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + ": ERROR - {0}\n" + "'", str48.equals(": ERROR - {0}\n"));
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray12 = new com.google.javascript.rhino.Node[] { node3, node5, node7, node9, node11 };
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray12);
        try {
            com.google.javascript.rhino.Node node14 = new com.google.javascript.rhino.Node(21, nodeArray12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: duplicate child");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertNotNull(nodeArray12);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.brokenClosureRequiresLevel;
        com.google.javascript.jscomp.CheckLevel checkLevel2 = com.google.javascript.jscomp.CheckLevel.WARNING;
        compilerOptions0.checkGlobalNamesLevel = checkLevel2;
        compilerOptions0.computeFunctionSideEffects = true;
        boolean boolean6 = compilerOptions0.removeDeadCode;
        compilerOptions0.removeDeadCode = false;
        compilerOptions0.aliasExternals = true;
        boolean boolean11 = compilerOptions0.inlineLocalFunctions;
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + checkLevel2 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel2.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray12 = new com.google.javascript.rhino.Node[] { node3, node5, node7, node9, node11 };
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray12);
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node16 = node13.copyInformationFrom(node15);
        com.google.javascript.rhino.Node node17 = node13.getParent();
        com.google.javascript.rhino.Node node18 = new com.google.javascript.rhino.Node((int) (short) -1, node13);
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newString((int) (short) 0, "hi!", 100, (-2));
        boolean boolean24 = node13.isEquivalentTo(node23);
        com.google.javascript.rhino.Node node25 = node23.getLastSibling();
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertNotNull(nodeArray12);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertNull(node17);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(node25);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        java.lang.RuntimeException runtimeException1 = com.google.javascript.rhino.ScriptRuntime.notFunctionError((java.lang.Object) (byte) -1);
        java.lang.Throwable[] throwableArray2 = runtimeException1.getSuppressed();
        org.junit.Assert.assertNotNull(runtimeException1);
        org.junit.Assert.assertNotNull(throwableArray2);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.brokenClosureRequiresLevel;
        com.google.javascript.jscomp.CheckLevel checkLevel2 = com.google.javascript.jscomp.CheckLevel.WARNING;
        compilerOptions0.checkGlobalNamesLevel = checkLevel2;
        compilerOptions0.computeFunctionSideEffects = true;
        boolean boolean6 = compilerOptions0.removeDeadCode;
        compilerOptions0.setManageClosureDependencies(false);
        compilerOptions0.nameReferenceGraphPath = "";
        java.lang.String str11 = compilerOptions0.syntheticBlockStartMarker;
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup12 = com.google.javascript.jscomp.DiagnosticGroups.STRICT_MODULE_DEP_CHECK;
        java.lang.String str13 = diagnosticGroup12.toString();
        com.google.javascript.jscomp.CheckLevel checkLevel14 = com.google.javascript.jscomp.CheckLevel.WARNING;
        compilerOptions0.setWarningLevel(diagnosticGroup12, checkLevel14);
        boolean boolean16 = compilerOptions0.checkUnusedPropertiesEarly;
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + checkLevel2 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel2.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(str11);
        org.junit.Assert.assertNotNull(diagnosticGroup12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "DiagnosticGroup<strictModuleDepCheck>" + "'", str13.equals("DiagnosticGroup<strictModuleDepCheck>"));
        org.junit.Assert.assertTrue("'" + checkLevel14 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel14.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.brokenClosureRequiresLevel;
        java.util.Set<java.lang.String> strSet2 = compilerOptions0.aliasableStrings;
        boolean boolean3 = compilerOptions0.decomposeExpressions;
        java.util.Set<java.lang.String> strSet4 = compilerOptions0.stripNamePrefixes;
        boolean boolean5 = compilerOptions0.instrumentForCoverageOnly;
        com.google.javascript.jscomp.CheckLevel checkLevel6 = compilerOptions0.checkMissingReturn;
        com.google.javascript.jscomp.CompilerOptions.TracerMode tracerMode7 = com.google.javascript.jscomp.CompilerOptions.TracerMode.ALL;
        compilerOptions0.tracer = tracerMode7;
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(strSet2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(strSet4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + checkLevel6 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel6.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + tracerMode7 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TracerMode.ALL + "'", tracerMode7.equals(com.google.javascript.jscomp.CompilerOptions.TracerMode.ALL));
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile1 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.CompilerInput compilerInput2 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile1);
        com.google.javascript.jscomp.JsAst jsAst3 = new com.google.javascript.jscomp.JsAst((com.google.javascript.jscomp.SourceFile) jSSourceFile1);
        jsAst3.clearAst();
        org.junit.Assert.assertNotNull(jSSourceFile1);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.brokenClosureRequiresLevel;
        com.google.javascript.jscomp.CheckLevel checkLevel2 = com.google.javascript.jscomp.CheckLevel.WARNING;
        compilerOptions0.checkGlobalNamesLevel = checkLevel2;
        compilerOptions0.computeFunctionSideEffects = true;
        compilerOptions0.setShadowVariables(true);
        compilerOptions0.debugFunctionSideEffectsPath = "goog.global";
        compilerOptions0.collapseAnonymousFunctions = true;
        compilerOptions0.printInputDelimiter = true;
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + checkLevel2 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel2.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        int int0 = com.google.javascript.rhino.Node.LOCAL_BLOCK_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + (-3) + "'", int0 == (-3));
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile1 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.CompilerInput compilerInput2 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile1);
        com.google.javascript.jscomp.CompilerInput compilerInput5 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput2, "hi!", false);
        com.google.javascript.jscomp.CompilerInput compilerInput7 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput2, true);
        java.io.PrintStream printStream8 = null;
        com.google.javascript.jscomp.Compiler compiler9 = new com.google.javascript.jscomp.Compiler(printStream8);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile11 = com.google.javascript.jscomp.JSSourceFile.fromFile("Not declared as a constructor");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile13 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.CompilerInput compilerInput14 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile13);
        com.google.javascript.jscomp.CompilerInput compilerInput17 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput14, "hi!", false);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile19 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        compilerInput14.setSourceFile((com.google.javascript.jscomp.SourceFile) jSSourceFile19);
        java.lang.String str21 = jSSourceFile19.toString();
        com.google.javascript.jscomp.CompilerOptions compilerOptions22 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean23 = compilerOptions22.aliasAllStrings;
        compilerOptions22.setGenerateExports(true);
        com.google.javascript.jscomp.Result result26 = compiler9.compile(jSSourceFile11, jSSourceFile19, compilerOptions22);
        com.google.javascript.jscomp.CompilerInput compilerInput27 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile19);
        com.google.javascript.jscomp.CompilerInput compilerInput28 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput27);
        com.google.javascript.jscomp.JSModule jSModule29 = null;
        compilerInput27.setModule(jSModule29);
        com.google.javascript.jscomp.SourceAst sourceAst31 = compilerInput27.getSourceAst();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile33 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.CompilerInput compilerInput34 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile33);
        com.google.javascript.jscomp.CompilerInput compilerInput37 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput34, "hi!", false);
        com.google.javascript.jscomp.Compiler compiler38 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile40 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.CompilerInput compilerInput41 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile40);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile43 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.CompilerInput compilerInput44 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile43);
        com.google.javascript.jscomp.CompilerInput compilerInput47 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput44, "hi!", false);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile49 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        compilerInput44.setSourceFile((com.google.javascript.jscomp.SourceFile) jSSourceFile49);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile52 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray53 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile40, jSSourceFile49, jSSourceFile52 };
        java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList54 = new java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile>();
        boolean boolean55 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList54, jSSourceFileArray53);
        com.google.javascript.jscomp.JSModule[] jSModuleArray56 = new com.google.javascript.jscomp.JSModule[] {};
        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList57 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
        boolean boolean58 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList57, jSModuleArray56);
        com.google.javascript.jscomp.CompilerOptions compilerOptions59 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions59.checkDuplicateMessages = false;
        boolean boolean62 = compilerOptions59.inlineAnonymousFunctionExpressions;
        compilerOptions59.crossModuleMethodMotion = true;
        com.google.javascript.jscomp.Result result65 = compiler38.compileModules((java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList54, (java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList57, compilerOptions59);
        compilerInput34.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler38);
        com.google.javascript.jscomp.Scope scope67 = compiler38.getTopScope();
        com.google.javascript.rhino.Node node68 = compilerInput27.getAstRoot((com.google.javascript.jscomp.AbstractCompiler) compiler38);
        com.google.javascript.jscomp.JSError[] jSErrorArray69 = compiler38.getMessages();
        compilerInput2.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler38);
        org.junit.Assert.assertNotNull(jSSourceFile1);
        org.junit.Assert.assertNotNull(jSSourceFile11);
        org.junit.Assert.assertNotNull(jSSourceFile13);
        org.junit.Assert.assertNotNull(jSSourceFile19);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "" + "'", str21.equals(""));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(result26);
        org.junit.Assert.assertNotNull(sourceAst31);
        org.junit.Assert.assertNotNull(jSSourceFile33);
        org.junit.Assert.assertNotNull(jSSourceFile40);
        org.junit.Assert.assertNotNull(jSSourceFile43);
        org.junit.Assert.assertNotNull(jSSourceFile49);
        org.junit.Assert.assertNotNull(jSSourceFile52);
        org.junit.Assert.assertNotNull(jSSourceFileArray53);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + true + "'", boolean55 == true);
        org.junit.Assert.assertNotNull(jSModuleArray56);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertNotNull(result65);
        org.junit.Assert.assertNull(scope67);
        org.junit.Assert.assertNull(node68);
        org.junit.Assert.assertNotNull(jSErrorArray69);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        com.google.javascript.rhino.Context context0 = com.google.javascript.rhino.Context.enter();
        boolean boolean1 = context0.isGeneratingSource();
        com.google.javascript.rhino.ErrorReporter errorReporter2 = context0.getErrorReporter();
        try {
            context0.setLanguageVersion((int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Bad language version: 10");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(context0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNull(errorReporter2);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.Compiler compiler2 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile4 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.CompilerInput compilerInput5 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile4);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile7 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.CompilerInput compilerInput8 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile7);
        com.google.javascript.jscomp.CompilerInput compilerInput11 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput8, "hi!", false);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile13 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        compilerInput8.setSourceFile((com.google.javascript.jscomp.SourceFile) jSSourceFile13);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile16 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray17 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile4, jSSourceFile13, jSSourceFile16 };
        java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList18 = new java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile>();
        boolean boolean19 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList18, jSSourceFileArray17);
        com.google.javascript.jscomp.JSModule[] jSModuleArray20 = new com.google.javascript.jscomp.JSModule[] {};
        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList21 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
        boolean boolean22 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList21, jSModuleArray20);
        com.google.javascript.jscomp.CompilerOptions compilerOptions23 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions23.checkDuplicateMessages = false;
        boolean boolean26 = compilerOptions23.inlineAnonymousFunctionExpressions;
        compilerOptions23.crossModuleMethodMotion = true;
        com.google.javascript.jscomp.Result result29 = compiler2.compileModules((java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList18, (java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList21, compilerOptions23);
        com.google.javascript.jscomp.Compiler compiler30 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile32 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.CompilerInput compilerInput33 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile32);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile35 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.CompilerInput compilerInput36 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile35);
        com.google.javascript.jscomp.CompilerInput compilerInput39 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput36, "hi!", false);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile41 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        compilerInput36.setSourceFile((com.google.javascript.jscomp.SourceFile) jSSourceFile41);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile44 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray45 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile32, jSSourceFile41, jSSourceFile44 };
        java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList46 = new java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile>();
        boolean boolean47 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList46, jSSourceFileArray45);
        com.google.javascript.jscomp.JSModule[] jSModuleArray48 = new com.google.javascript.jscomp.JSModule[] {};
        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList49 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
        boolean boolean50 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList49, jSModuleArray48);
        com.google.javascript.jscomp.CompilerOptions compilerOptions51 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions51.checkDuplicateMessages = false;
        boolean boolean54 = compilerOptions51.inlineAnonymousFunctionExpressions;
        compilerOptions51.crossModuleMethodMotion = true;
        com.google.javascript.jscomp.Result result57 = compiler30.compileModules((java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList46, (java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList49, compilerOptions51);
        com.google.javascript.jscomp.CompilerOptions compilerOptions58 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel59 = compilerOptions58.brokenClosureRequiresLevel;
        java.util.Set<java.lang.String> strSet60 = compilerOptions58.aliasableStrings;
        boolean boolean61 = compilerOptions58.decomposeExpressions;
        java.util.Set<java.lang.String> strSet62 = compilerOptions58.stripNamePrefixes;
        com.google.javascript.jscomp.Result result63 = compiler1.compile((java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList18, (java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList46, compilerOptions58);
        com.google.javascript.jscomp.JSError[] jSErrorArray64 = compiler1.getWarnings();
        try {
            compiler1.processDefines();
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: INTERNAL COMPILER ERROR.\nPlease report this problem.\nnull");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile4);
        org.junit.Assert.assertNotNull(jSSourceFile7);
        org.junit.Assert.assertNotNull(jSSourceFile13);
        org.junit.Assert.assertNotNull(jSSourceFile16);
        org.junit.Assert.assertNotNull(jSSourceFileArray17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(jSModuleArray20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(result29);
        org.junit.Assert.assertNotNull(jSSourceFile32);
        org.junit.Assert.assertNotNull(jSSourceFile35);
        org.junit.Assert.assertNotNull(jSSourceFile41);
        org.junit.Assert.assertNotNull(jSSourceFile44);
        org.junit.Assert.assertNotNull(jSSourceFileArray45);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
        org.junit.Assert.assertNotNull(jSModuleArray48);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNotNull(result57);
        org.junit.Assert.assertTrue("'" + checkLevel59 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel59.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(strSet60);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertNotNull(strSet62);
        org.junit.Assert.assertNotNull(result63);
        org.junit.Assert.assertNotNull(jSErrorArray64);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        com.google.javascript.rhino.Node.SideEffectFlags sideEffectFlags1 = new com.google.javascript.rhino.Node.SideEffectFlags(17);
        sideEffectFlags1.setAllFlags();
        int int3 = sideEffectFlags1.valueOf();
        sideEffectFlags1.setReturnsTainted();
        sideEffectFlags1.clearAllFlags();
        sideEffectFlags1.setMutatesArguments();
        sideEffectFlags1.setMutatesGlobalState();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray12 = new com.google.javascript.rhino.Node[] { node3, node5, node7, node9, node11 };
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray12);
        int int14 = node13.getSideEffectFlags();
        com.google.javascript.rhino.Node node15 = node13.getNext();
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention16 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node22 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node24 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node26 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node28 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray29 = new com.google.javascript.rhino.Node[] { node20, node22, node24, node26, node28 };
        com.google.javascript.rhino.Node node30 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray29);
        com.google.javascript.rhino.Node node33 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node35 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node37 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node39 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node41 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray42 = new com.google.javascript.rhino.Node[] { node33, node35, node37, node39, node41 };
        com.google.javascript.rhino.Node node43 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray42);
        com.google.javascript.rhino.Node node44 = new com.google.javascript.rhino.Node(100, node30, node43);
        java.lang.String str45 = closureCodingConvention16.getSingletonGetterClassName(node44);
        node44.setWasEmptyNode(true);
        com.google.javascript.rhino.Node node51 = com.google.javascript.rhino.Node.newNumber(100.0d, 4095, 9);
        java.util.Set<java.lang.String> strSet52 = node51.getDirectives();
        com.google.javascript.rhino.Node node55 = new com.google.javascript.rhino.Node((int) (short) 0, node13, node44, node51, (int) (short) 10, (int) ' ');
        int int56 = node51.getType();
        try {
            node51.setQuotedString();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: FAILED ASSERTION");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertNotNull(nodeArray12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNull(node15);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertNotNull(nodeArray29);
        org.junit.Assert.assertNotNull(node33);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertNotNull(node37);
        org.junit.Assert.assertNotNull(node39);
        org.junit.Assert.assertNotNull(node41);
        org.junit.Assert.assertNotNull(nodeArray42);
        org.junit.Assert.assertNull(str45);
        org.junit.Assert.assertNotNull(node51);
        org.junit.Assert.assertNull(strSet52);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 39 + "'", int56 == 39);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        com.google.javascript.jscomp.DiagnosticType diagnosticType0 = com.google.javascript.jscomp.Compiler.MOTION_ITERATIONS_ERROR;
        com.google.javascript.jscomp.CheckLevel checkLevel1 = diagnosticType0.defaultLevel;
        org.junit.Assert.assertNotNull(diagnosticType0);
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray0 = new com.google.javascript.jscomp.WarningsGuard[] {};
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard1 = new com.google.javascript.jscomp.ComposeWarningsGuard(warningsGuardArray0);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup2 = com.google.javascript.jscomp.DiagnosticGroups.STRICT_MODULE_DEP_CHECK;
        boolean boolean3 = composeWarningsGuard1.disables(diagnosticGroup2);
        com.google.javascript.jscomp.DiagnosticType[] diagnosticTypeArray4 = new com.google.javascript.jscomp.DiagnosticType[] {};
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup5 = new com.google.javascript.jscomp.DiagnosticGroup(diagnosticTypeArray4);
        com.google.javascript.jscomp.DiagnosticGroups.AMBIGUOUS_FUNCTION_DECL = diagnosticGroup5;
        java.lang.RuntimeException runtimeException7 = com.google.javascript.rhino.ScriptRuntime.notFunctionError((java.lang.Object) diagnosticGroup5);
        boolean boolean8 = composeWarningsGuard1.enables(diagnosticGroup5);
        org.junit.Assert.assertNotNull(warningsGuardArray0);
        org.junit.Assert.assertNotNull(diagnosticGroup2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(diagnosticTypeArray4);
        org.junit.Assert.assertNotNull(runtimeException7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.brokenClosureRequiresLevel;
        com.google.javascript.jscomp.CheckLevel checkLevel2 = com.google.javascript.jscomp.CheckLevel.WARNING;
        compilerOptions0.checkGlobalNamesLevel = checkLevel2;
        compilerOptions0.computeFunctionSideEffects = true;
        compilerOptions0.closurePass = false;
        boolean boolean8 = compilerOptions0.crossModuleMethodMotion;
        compilerOptions0.ignoreCajaProperties = true;
        compilerOptions0.syntheticBlockEndMarker = "";
        boolean boolean13 = compilerOptions0.reserveRawExports;
        compilerOptions0.enableExternExports(false);
        compilerOptions0.aliasStringsBlacklist = "false";
        compilerOptions0.devirtualizePrototypeMethods = false;
        boolean boolean20 = compilerOptions0.aliasKeywords;
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + checkLevel2 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel2.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.checkDuplicateMessages = false;
        boolean boolean3 = compilerOptions0.inlineAnonymousFunctionExpressions;
        java.lang.String str4 = compilerOptions0.checkMissingGetCssNameBlacklist;
        compilerOptions0.removeUnusedLocalVars = true;
        com.google.common.collect.Multimap<com.google.javascript.jscomp.CustomPassExecutionTime, com.google.javascript.jscomp.CompilerPass> customPassExecutionTimeMultimap7 = null;
        compilerOptions0.customPasses = customPassExecutionTimeMultimap7;
        boolean boolean9 = compilerOptions0.markNoSideEffectCalls;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray11 = new com.google.javascript.rhino.Node[] { node2, node4, node6, node8, node10 };
        com.google.javascript.rhino.Node node12 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray11);
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node15 = node12.copyInformationFrom(node14);
        node14.setIsSyntheticBlock(true);
        boolean boolean18 = node14.wasEmptyNode();
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(nodeArray11);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention1 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray14 = new com.google.javascript.rhino.Node[] { node5, node7, node9, node11, node13 };
        com.google.javascript.rhino.Node node15 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray14);
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node22 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node24 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node26 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray27 = new com.google.javascript.rhino.Node[] { node18, node20, node22, node24, node26 };
        com.google.javascript.rhino.Node node28 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray27);
        com.google.javascript.rhino.Node node29 = new com.google.javascript.rhino.Node(100, node15, node28);
        boolean boolean30 = closureCodingConvention1.isVarArgsParameter(node29);
        java.lang.String str31 = closureCodingConvention1.getExportPropertyFunction();
        boolean boolean34 = closureCodingConvention1.isExported("goog.exportProperty", false);
        com.google.javascript.rhino.Node node38 = com.google.javascript.rhino.Node.newNumber(100.0d, 4095, 9);
        java.util.Set<java.lang.String> strSet39 = node38.getDirectives();
        boolean boolean40 = closureCodingConvention1.isVarArgsParameter(node38);
        com.google.javascript.rhino.Node node43 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node45 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node47 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node49 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node51 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray52 = new com.google.javascript.rhino.Node[] { node43, node45, node47, node49, node51 };
        com.google.javascript.rhino.Node node53 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray52);
        int int54 = node53.getSideEffectFlags();
        node38.addChildrenToFront(node53);
        try {
            com.google.javascript.rhino.Node node56 = new com.google.javascript.rhino.Node(120, node53);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: new child has existing parent");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(nodeArray14);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertNotNull(nodeArray27);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "goog.exportProperty" + "'", str31.equals("goog.exportProperty"));
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(node38);
        org.junit.Assert.assertNull(strSet39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(node43);
        org.junit.Assert.assertNotNull(node45);
        org.junit.Assert.assertNotNull(node47);
        org.junit.Assert.assertNotNull(node49);
        org.junit.Assert.assertNotNull(node51);
        org.junit.Assert.assertNotNull(nodeArray52);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 0 + "'", int54 == 0);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        java.nio.charset.Charset charset1 = null;
        com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromFile("leavewith", charset1);
        org.junit.Assert.assertNotNull(sourceFile2);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.brokenClosureRequiresLevel;
        com.google.javascript.jscomp.CheckLevel checkLevel2 = com.google.javascript.jscomp.CheckLevel.WARNING;
        compilerOptions0.checkGlobalNamesLevel = checkLevel2;
        com.google.javascript.jscomp.ErrorFormat errorFormat4 = null;
        compilerOptions0.errorFormat = errorFormat4;
        boolean boolean6 = compilerOptions0.ambiguateProperties;
        com.google.javascript.jscomp.CompilerOptions compilerOptions7 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel8 = compilerOptions7.brokenClosureRequiresLevel;
        com.google.javascript.jscomp.CheckLevel checkLevel9 = com.google.javascript.jscomp.CheckLevel.WARNING;
        compilerOptions7.checkGlobalNamesLevel = checkLevel9;
        compilerOptions7.computeFunctionSideEffects = true;
        boolean boolean13 = compilerOptions7.removeDeadCode;
        compilerOptions7.inlineVariables = true;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy16 = com.google.javascript.jscomp.VariableRenamingPolicy.OFF;
        compilerOptions7.variableRenaming = variableRenamingPolicy16;
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy18 = com.google.javascript.jscomp.PropertyRenamingPolicy.HEURISTIC;
        compilerOptions0.setRenamingPolicy(variableRenamingPolicy16, propertyRenamingPolicy18);
        compilerOptions0.markNoSideEffectCalls = false;
        boolean boolean22 = compilerOptions0.moveFunctionDeclarations;
        compilerOptions0.strictMessageReplacement = false;
        boolean boolean25 = compilerOptions0.checkSuspiciousCode;
        boolean boolean26 = compilerOptions0.inferTypesInGlobalScope;
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + checkLevel2 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel2.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + checkLevel8 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel8.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + checkLevel9 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel9.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy16 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.OFF + "'", variableRenamingPolicy16.equals(com.google.javascript.jscomp.VariableRenamingPolicy.OFF));
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy18 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.HEURISTIC + "'", propertyRenamingPolicy18.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.HEURISTIC));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.checkDuplicateMessages = false;
        boolean boolean3 = compilerOptions0.inlineAnonymousFunctionExpressions;
        java.lang.String str4 = compilerOptions0.checkMissingGetCssNameBlacklist;
        compilerOptions0.inlineAnonymousFunctionExpressions = false;
        boolean boolean7 = compilerOptions0.aliasExternals;
        compilerOptions0.removeTryCatchFinally = true;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        com.google.javascript.rhino.Node.SideEffectFlags sideEffectFlags1 = new com.google.javascript.rhino.Node.SideEffectFlags(17);
        sideEffectFlags1.setAllFlags();
        int int3 = sideEffectFlags1.valueOf();
        sideEffectFlags1.setAllFlags();
        sideEffectFlags1.clearAllFlags();
        sideEffectFlags1.setReturnsTainted();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile5 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.CompilerInput compilerInput6 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile5);
        com.google.javascript.jscomp.CompilerInput compilerInput9 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput6, "hi!", false);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile11 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        compilerInput6.setSourceFile((com.google.javascript.jscomp.SourceFile) jSSourceFile11);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile14 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray15 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile2, jSSourceFile11, jSSourceFile14 };
        java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList16 = new java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile>();
        boolean boolean17 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList16, jSSourceFileArray15);
        com.google.javascript.jscomp.JSModule[] jSModuleArray18 = new com.google.javascript.jscomp.JSModule[] {};
        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList19 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
        boolean boolean20 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList19, jSModuleArray18);
        com.google.javascript.jscomp.CompilerOptions compilerOptions21 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions21.checkDuplicateMessages = false;
        boolean boolean24 = compilerOptions21.inlineAnonymousFunctionExpressions;
        compilerOptions21.crossModuleMethodMotion = true;
        com.google.javascript.jscomp.Result result27 = compiler0.compileModules((java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList16, (java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList19, compilerOptions21);
        boolean boolean28 = compiler0.acceptConstKeyword();
        com.google.javascript.jscomp.JSModule jSModule29 = null;
        try {
            java.lang.String[] strArray30 = compiler0.toSourceArray(jSModule29);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: java.lang.NullPointerException");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile2);
        org.junit.Assert.assertNotNull(jSSourceFile5);
        org.junit.Assert.assertNotNull(jSSourceFile11);
        org.junit.Assert.assertNotNull(jSSourceFile14);
        org.junit.Assert.assertNotNull(jSSourceFileArray15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(jSModuleArray18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(result27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.GLOBAL_THIS;
        com.google.javascript.jscomp.DiagnosticGroups.UNKNOWN_DEFINES = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticGroups.GLOBAL_THIS = diagnosticGroup0;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        com.google.javascript.rhino.Context context0 = com.google.javascript.rhino.Context.enter();
        boolean boolean1 = context0.isGeneratingSource();
        com.google.javascript.rhino.ErrorReporter errorReporter2 = context0.getErrorReporter();
        com.google.javascript.rhino.ErrorReporter errorReporter3 = context0.getErrorReporter();
        boolean boolean4 = context0.isSealed();
        boolean boolean6 = context0.isActivationNeeded("goog.exportProperty");
        com.google.javascript.rhino.ScriptRuntime.storeUint32Result(context0, (long) 100);
        org.junit.Assert.assertNotNull(context0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNull(errorReporter2);
        org.junit.Assert.assertNull(errorReporter3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray11 = new com.google.javascript.rhino.Node[] { node2, node4, node6, node8, node10 };
        com.google.javascript.rhino.Node node12 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray11);
        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node22 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node24 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray25 = new com.google.javascript.rhino.Node[] { node16, node18, node20, node22, node24 };
        com.google.javascript.rhino.Node node26 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray25);
        com.google.javascript.rhino.Node node28 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node29 = node26.copyInformationFrom(node28);
        com.google.javascript.rhino.Node node30 = node26.getParent();
        com.google.javascript.rhino.Node node31 = new com.google.javascript.rhino.Node((int) (short) -1, node26);
        com.google.javascript.rhino.Node node36 = com.google.javascript.rhino.Node.newString((int) (short) 0, "hi!", 100, (-2));
        boolean boolean37 = node26.isEquivalentTo(node36);
        com.google.javascript.rhino.Node node38 = node12.clonePropsFrom(node36);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder39 = node36.getJsDocBuilderForNode();
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(nodeArray11);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertNotNull(nodeArray25);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNull(node30);
        org.junit.Assert.assertNotNull(node36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(node38);
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder39);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.brokenClosureRequiresLevel;
        com.google.javascript.jscomp.CheckLevel checkLevel2 = com.google.javascript.jscomp.CheckLevel.WARNING;
        compilerOptions0.checkGlobalNamesLevel = checkLevel2;
        compilerOptions0.checkMissingGetCssNameBlacklist = "JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of optimization iterations: {0}";
        com.google.javascript.jscomp.CompilerOptions compilerOptions6 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel7 = compilerOptions6.brokenClosureRequiresLevel;
        java.util.Set<java.lang.String> strSet8 = compilerOptions6.aliasableStrings;
        boolean boolean9 = compilerOptions6.decomposeExpressions;
        java.util.Set<java.lang.String> strSet10 = compilerOptions6.stripNamePrefixes;
        boolean boolean11 = compilerOptions6.instrumentForCoverageOnly;
        com.google.javascript.jscomp.CheckLevel checkLevel12 = compilerOptions6.checkMissingReturn;
        compilerOptions6.labelRenaming = false;
        java.lang.RuntimeException runtimeException15 = com.google.javascript.rhino.ScriptRuntime.undefReadError((java.lang.Object) compilerOptions0, (java.lang.Object) false);
        java.lang.String str16 = runtimeException15.toString();
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + checkLevel2 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel2.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
        org.junit.Assert.assertTrue("'" + checkLevel7 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel7.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(strSet8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(strSet10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + checkLevel12 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel12.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(runtimeException15);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        com.google.javascript.jscomp.DiagnosticType diagnosticType5 = com.google.javascript.jscomp.DiagnosticType.warning("1", "");
        java.lang.String[] strArray6 = null;
        com.google.javascript.jscomp.JSError jSError7 = com.google.javascript.jscomp.JSError.make("goog.global", (int) (byte) 10, 15, diagnosticType5, strArray6);
        com.google.javascript.jscomp.CheckLevel checkLevel8 = jSError7.level;
        org.junit.Assert.assertNotNull(diagnosticType5);
        org.junit.Assert.assertNotNull(jSError7);
        org.junit.Assert.assertTrue("'" + checkLevel8 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel8.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        com.google.javascript.rhino.Context context0 = com.google.javascript.rhino.Context.enter();
        boolean boolean1 = context0.isGeneratingSource();
        java.lang.Object obj2 = context0.getDebuggerContextData();
        boolean boolean3 = context0.isGeneratingSource();
        com.google.javascript.rhino.ScriptRuntime.storeUint32Result(context0, (long) 48);
        org.junit.Assert.assertNotNull(context0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNull(obj2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.brokenClosureRequiresLevel;
        com.google.javascript.jscomp.CheckLevel checkLevel2 = com.google.javascript.jscomp.CheckLevel.WARNING;
        compilerOptions0.checkGlobalNamesLevel = checkLevel2;
        compilerOptions0.computeFunctionSideEffects = true;
        boolean boolean6 = compilerOptions0.removeDeadCode;
        compilerOptions0.inlineVariables = true;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy9 = com.google.javascript.jscomp.VariableRenamingPolicy.OFF;
        compilerOptions0.variableRenaming = variableRenamingPolicy9;
        com.google.javascript.jscomp.CheckLevel checkLevel11 = compilerOptions0.checkShadowVars;
        compilerOptions0.instrumentForCoverage = true;
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + checkLevel2 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel2.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy9 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.OFF + "'", variableRenamingPolicy9.equals(com.google.javascript.jscomp.VariableRenamingPolicy.OFF));
        org.junit.Assert.assertTrue("'" + checkLevel11 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel11.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        com.google.javascript.jscomp.MessageFormatter messageFormatter0 = null;
        java.util.logging.Logger logger1 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager2 = new com.google.javascript.jscomp.LoggerErrorManager(messageFormatter0, logger1);
        com.google.javascript.jscomp.Compiler compiler3 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager2);
        loggerErrorManager2.generateReport();
        int int5 = loggerErrorManager2.getWarningCount();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.brokenClosureRequiresLevel;
        com.google.javascript.jscomp.CheckLevel checkLevel2 = com.google.javascript.jscomp.CheckLevel.WARNING;
        compilerOptions0.checkGlobalNamesLevel = checkLevel2;
        compilerOptions0.computeFunctionSideEffects = true;
        compilerOptions0.setShadowVariables(true);
        compilerOptions0.debugFunctionSideEffectsPath = "goog.global";
        java.lang.String str10 = compilerOptions0.inputDelimiter;
        compilerOptions0.removeTryCatchFinally = false;
        compilerOptions0.setShadowVariables(false);
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + checkLevel2 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel2.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "// Input %num%" + "'", str10.equals("// Input %num%"));
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.Compiler compiler2 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile4 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.CompilerInput compilerInput5 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile4);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile7 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.CompilerInput compilerInput8 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile7);
        com.google.javascript.jscomp.CompilerInput compilerInput11 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput8, "hi!", false);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile13 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        compilerInput8.setSourceFile((com.google.javascript.jscomp.SourceFile) jSSourceFile13);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile16 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray17 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile4, jSSourceFile13, jSSourceFile16 };
        java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList18 = new java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile>();
        boolean boolean19 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList18, jSSourceFileArray17);
        com.google.javascript.jscomp.JSModule[] jSModuleArray20 = new com.google.javascript.jscomp.JSModule[] {};
        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList21 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
        boolean boolean22 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList21, jSModuleArray20);
        com.google.javascript.jscomp.CompilerOptions compilerOptions23 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions23.checkDuplicateMessages = false;
        boolean boolean26 = compilerOptions23.inlineAnonymousFunctionExpressions;
        compilerOptions23.crossModuleMethodMotion = true;
        com.google.javascript.jscomp.Result result29 = compiler2.compileModules((java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList18, (java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList21, compilerOptions23);
        com.google.javascript.jscomp.Compiler compiler30 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile32 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.CompilerInput compilerInput33 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile32);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile35 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.CompilerInput compilerInput36 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile35);
        com.google.javascript.jscomp.CompilerInput compilerInput39 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput36, "hi!", false);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile41 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        compilerInput36.setSourceFile((com.google.javascript.jscomp.SourceFile) jSSourceFile41);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile44 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray45 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile32, jSSourceFile41, jSSourceFile44 };
        java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList46 = new java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile>();
        boolean boolean47 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList46, jSSourceFileArray45);
        com.google.javascript.jscomp.JSModule[] jSModuleArray48 = new com.google.javascript.jscomp.JSModule[] {};
        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList49 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
        boolean boolean50 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList49, jSModuleArray48);
        com.google.javascript.jscomp.CompilerOptions compilerOptions51 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions51.checkDuplicateMessages = false;
        boolean boolean54 = compilerOptions51.inlineAnonymousFunctionExpressions;
        compilerOptions51.crossModuleMethodMotion = true;
        com.google.javascript.jscomp.Result result57 = compiler30.compileModules((java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList46, (java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList49, compilerOptions51);
        com.google.javascript.jscomp.CompilerOptions compilerOptions58 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel59 = compilerOptions58.brokenClosureRequiresLevel;
        java.util.Set<java.lang.String> strSet60 = compilerOptions58.aliasableStrings;
        boolean boolean61 = compilerOptions58.decomposeExpressions;
        java.util.Set<java.lang.String> strSet62 = compilerOptions58.stripNamePrefixes;
        com.google.javascript.jscomp.Result result63 = compiler1.compile((java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList18, (java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList46, compilerOptions58);
        com.google.javascript.jscomp.CompilerOptions compilerOptions64 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions64.checkDuplicateMessages = false;
        boolean boolean67 = compilerOptions64.inlineAnonymousFunctionExpressions;
        compilerOptions64.recordFunctionInformation = true;
        boolean boolean70 = compilerOptions64.checkCaja;
        compilerOptions64.aliasableGlobals = "EOF 0";
        boolean boolean73 = compilerOptions64.removeEmptyFunctions;
        boolean boolean74 = compilerOptions64.deadAssignmentElimination;
        com.google.javascript.jscomp.CheckLevel checkLevel75 = com.google.javascript.jscomp.CheckLevel.ERROR;
        compilerOptions64.checkUndefinedProperties = checkLevel75;
        com.google.javascript.jscomp.CheckLevel checkLevel77 = com.google.javascript.jscomp.CheckLevel.OFF;
        compilerOptions64.checkFunctions = checkLevel77;
        compilerOptions58.checkGlobalThisLevel = checkLevel77;
        org.junit.Assert.assertNotNull(jSSourceFile4);
        org.junit.Assert.assertNotNull(jSSourceFile7);
        org.junit.Assert.assertNotNull(jSSourceFile13);
        org.junit.Assert.assertNotNull(jSSourceFile16);
        org.junit.Assert.assertNotNull(jSSourceFileArray17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(jSModuleArray20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(result29);
        org.junit.Assert.assertNotNull(jSSourceFile32);
        org.junit.Assert.assertNotNull(jSSourceFile35);
        org.junit.Assert.assertNotNull(jSSourceFile41);
        org.junit.Assert.assertNotNull(jSSourceFile44);
        org.junit.Assert.assertNotNull(jSSourceFileArray45);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
        org.junit.Assert.assertNotNull(jSModuleArray48);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNotNull(result57);
        org.junit.Assert.assertTrue("'" + checkLevel59 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel59.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(strSet60);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertNotNull(strSet62);
        org.junit.Assert.assertNotNull(result63);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
        org.junit.Assert.assertTrue("'" + checkLevel75 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel75.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + checkLevel77 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel77.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.STRICT_MODULE_DEP_CHECK;
        com.google.javascript.jscomp.DiagnosticGroups.VISIBILITY = diagnosticGroup0;
        com.google.javascript.jscomp.CheckLevel checkLevel2 = com.google.javascript.jscomp.CheckLevel.WARNING;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard3 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup0, checkLevel2);
        com.google.javascript.jscomp.DiagnosticType[] diagnosticTypeArray4 = new com.google.javascript.jscomp.DiagnosticType[] {};
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup5 = new com.google.javascript.jscomp.DiagnosticGroup(diagnosticTypeArray4);
        com.google.javascript.jscomp.DiagnosticGroups.AMBIGUOUS_FUNCTION_DECL = diagnosticGroup5;
        boolean boolean7 = diagnosticGroupWarningsGuard3.enables(diagnosticGroup5);
        org.junit.Assert.assertNotNull(diagnosticGroup0);
        org.junit.Assert.assertTrue("'" + checkLevel2 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel2.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
        org.junit.Assert.assertNotNull(diagnosticTypeArray4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.brokenClosureRequiresLevel;
        com.google.javascript.jscomp.CheckLevel checkLevel2 = com.google.javascript.jscomp.CheckLevel.WARNING;
        compilerOptions0.checkGlobalNamesLevel = checkLevel2;
        com.google.javascript.jscomp.ErrorFormat errorFormat4 = null;
        compilerOptions0.errorFormat = errorFormat4;
        boolean boolean6 = compilerOptions0.ambiguateProperties;
        com.google.javascript.jscomp.CompilerOptions compilerOptions7 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel8 = compilerOptions7.brokenClosureRequiresLevel;
        com.google.javascript.jscomp.CheckLevel checkLevel9 = com.google.javascript.jscomp.CheckLevel.WARNING;
        compilerOptions7.checkGlobalNamesLevel = checkLevel9;
        compilerOptions7.computeFunctionSideEffects = true;
        boolean boolean13 = compilerOptions7.removeDeadCode;
        compilerOptions7.inlineVariables = true;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy16 = com.google.javascript.jscomp.VariableRenamingPolicy.OFF;
        compilerOptions7.variableRenaming = variableRenamingPolicy16;
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy18 = com.google.javascript.jscomp.PropertyRenamingPolicy.HEURISTIC;
        compilerOptions0.setRenamingPolicy(variableRenamingPolicy16, propertyRenamingPolicy18);
        com.google.javascript.jscomp.CheckLevel checkLevel20 = compilerOptions0.brokenClosureRequiresLevel;
        boolean boolean21 = compilerOptions0.isExternExportsEnabled();
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + checkLevel2 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel2.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + checkLevel8 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel8.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + checkLevel9 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel9.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy16 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.OFF + "'", variableRenamingPolicy16.equals(com.google.javascript.jscomp.VariableRenamingPolicy.OFF));
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy18 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.HEURISTIC + "'", propertyRenamingPolicy18.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.HEURISTIC));
        org.junit.Assert.assertTrue("'" + checkLevel20 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel20.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.skipAllCompilerPasses();
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.checkDuplicateMessages = false;
        compilerOptions0.tightenTypes = true;
        compilerOptions0.sourceMapOutputPath = "JSC_OPTIMIZE_LOOP_ERROR";
        compilerOptions0.aliasAllStrings = false;
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.checkDuplicateMessages = false;
        boolean boolean3 = compilerOptions0.inlineAnonymousFunctionExpressions;
        compilerOptions0.recordFunctionInformation = true;
        boolean boolean6 = compilerOptions0.checkCaja;
        compilerOptions0.aliasableGlobals = "EOF 0";
        com.google.javascript.jscomp.CheckLevel checkLevel9 = com.google.javascript.jscomp.CheckLevel.OFF;
        compilerOptions0.reportUnknownTypes = checkLevel9;
        com.google.javascript.jscomp.CompilerOptions compilerOptions11 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions11.checkDuplicateMessages = false;
        boolean boolean14 = compilerOptions11.inlineAnonymousFunctionExpressions;
        compilerOptions11.recordFunctionInformation = true;
        boolean boolean17 = compilerOptions11.checkCaja;
        java.util.Set<java.lang.String> strSet18 = compilerOptions11.stripNamePrefixes;
        compilerOptions0.setIdGenerators(strSet18);
        boolean boolean20 = compilerOptions0.removeUnusedLocalVars;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + checkLevel9 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel9.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(strSet18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray13 = new com.google.javascript.rhino.Node[] { node4, node6, node8, node10, node12 };
        com.google.javascript.rhino.Node node14 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray13);
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node21 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray26 = new com.google.javascript.rhino.Node[] { node17, node19, node21, node23, node25 };
        com.google.javascript.rhino.Node node27 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray26);
        com.google.javascript.rhino.Node node28 = new com.google.javascript.rhino.Node(100, node14, node27);
        java.lang.String str29 = closureCodingConvention0.getSingletonGetterClassName(node28);
        com.google.javascript.rhino.jstype.FunctionType functionType30 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType31 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType32 = null;
        closureCodingConvention0.applySubclassRelationship(functionType30, functionType31, subclassType32);
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention34 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node38 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node40 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node42 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node44 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node46 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray47 = new com.google.javascript.rhino.Node[] { node38, node40, node42, node44, node46 };
        com.google.javascript.rhino.Node node48 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray47);
        com.google.javascript.rhino.Node node51 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node53 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node55 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node57 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node59 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray60 = new com.google.javascript.rhino.Node[] { node51, node53, node55, node57, node59 };
        com.google.javascript.rhino.Node node61 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray60);
        com.google.javascript.rhino.Node node62 = new com.google.javascript.rhino.Node(100, node48, node61);
        java.lang.String str63 = closureCodingConvention34.getSingletonGetterClassName(node62);
        com.google.javascript.rhino.Node node64 = node62.getFirstChild();
        java.lang.String str65 = closureCodingConvention0.identifyTypeDefAssign(node64);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(nodeArray13);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNotNull(nodeArray26);
        org.junit.Assert.assertNull(str29);
        org.junit.Assert.assertNotNull(node38);
        org.junit.Assert.assertNotNull(node40);
        org.junit.Assert.assertNotNull(node42);
        org.junit.Assert.assertNotNull(node44);
        org.junit.Assert.assertNotNull(node46);
        org.junit.Assert.assertNotNull(nodeArray47);
        org.junit.Assert.assertNotNull(node51);
        org.junit.Assert.assertNotNull(node53);
        org.junit.Assert.assertNotNull(node55);
        org.junit.Assert.assertNotNull(node57);
        org.junit.Assert.assertNotNull(node59);
        org.junit.Assert.assertNotNull(nodeArray60);
        org.junit.Assert.assertNull(str63);
        org.junit.Assert.assertNotNull(node64);
        org.junit.Assert.assertNull(str65);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.TWEAKS;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.brokenClosureRequiresLevel;
        com.google.javascript.jscomp.CheckLevel checkLevel2 = com.google.javascript.jscomp.CheckLevel.WARNING;
        compilerOptions0.checkGlobalNamesLevel = checkLevel2;
        compilerOptions0.computeFunctionSideEffects = true;
        compilerOptions0.closurePass = false;
        com.google.javascript.jscomp.ErrorFormat errorFormat8 = compilerOptions0.errorFormat;
        com.google.common.collect.Multimap<com.google.javascript.jscomp.CustomPassExecutionTime, com.google.javascript.jscomp.CompilerPass> customPassExecutionTimeMultimap9 = null;
        compilerOptions0.customPasses = customPassExecutionTimeMultimap9;
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + checkLevel2 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel2.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
        org.junit.Assert.assertNotNull(errorFormat8);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.brokenClosureRequiresLevel;
        com.google.javascript.jscomp.CheckLevel checkLevel2 = com.google.javascript.jscomp.CheckLevel.WARNING;
        compilerOptions0.checkGlobalNamesLevel = checkLevel2;
        compilerOptions0.computeFunctionSideEffects = true;
        boolean boolean6 = compilerOptions0.removeDeadCode;
        compilerOptions0.removeUnusedLocalVars = true;
        com.google.javascript.jscomp.AnonymousFunctionNamingPolicy anonymousFunctionNamingPolicy9 = com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.MAPPED;
        char[] charArray10 = anonymousFunctionNamingPolicy9.getReservedCharacters();
        compilerOptions0.anonymousFunctionNaming = anonymousFunctionNamingPolicy9;
        char[] charArray12 = anonymousFunctionNamingPolicy9.getReservedCharacters();
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + checkLevel2 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel2.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + anonymousFunctionNamingPolicy9 + "' != '" + com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.MAPPED + "'", anonymousFunctionNamingPolicy9.equals(com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.MAPPED));
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertNotNull(charArray12);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.checkDuplicateMessages = false;
        boolean boolean3 = compilerOptions0.inlineAnonymousFunctionExpressions;
        compilerOptions0.recordFunctionInformation = true;
        boolean boolean6 = compilerOptions0.checkCaja;
        java.util.Set<java.lang.String> strSet7 = compilerOptions0.stripNamePrefixes;
        boolean boolean8 = compilerOptions0.inlineFunctions;
        boolean boolean9 = compilerOptions0.generatePseudoNames;
        java.util.Set<java.lang.String> strSet10 = null;
        compilerOptions0.stripTypes = strSet10;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(strSet7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray13 = new com.google.javascript.rhino.Node[] { node4, node6, node8, node10, node12 };
        com.google.javascript.rhino.Node node14 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray13);
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node21 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray26 = new com.google.javascript.rhino.Node[] { node17, node19, node21, node23, node25 };
        com.google.javascript.rhino.Node node27 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray26);
        com.google.javascript.rhino.Node node28 = new com.google.javascript.rhino.Node(100, node14, node27);
        java.lang.String str29 = closureCodingConvention0.getSingletonGetterClassName(node28);
        com.google.javascript.rhino.Node node30 = node28.cloneTree();
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder31 = node30.new FileLevelJsDocBuilder();
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(nodeArray13);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNotNull(nodeArray26);
        org.junit.Assert.assertNull(str29);
        org.junit.Assert.assertNotNull(node30);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        com.google.javascript.jscomp.ErrorFormat errorFormat0 = com.google.javascript.jscomp.ErrorFormat.SINGLELINE;
        java.io.PrintStream printStream1 = null;
        com.google.javascript.jscomp.Compiler compiler2 = new com.google.javascript.jscomp.Compiler(printStream1);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile4 = com.google.javascript.jscomp.JSSourceFile.fromFile("Not declared as a constructor");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile6 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.CompilerInput compilerInput7 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile6);
        com.google.javascript.jscomp.CompilerInput compilerInput10 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput7, "hi!", false);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile12 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        compilerInput7.setSourceFile((com.google.javascript.jscomp.SourceFile) jSSourceFile12);
        java.lang.String str14 = jSSourceFile12.toString();
        com.google.javascript.jscomp.CompilerOptions compilerOptions15 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean16 = compilerOptions15.aliasAllStrings;
        compilerOptions15.setGenerateExports(true);
        com.google.javascript.jscomp.Result result19 = compiler2.compile(jSSourceFile4, jSSourceFile12, compilerOptions15);
        com.google.javascript.jscomp.MessageFormatter messageFormatter21 = errorFormat0.toFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler2, false);
        compiler2.optimize();
        boolean boolean23 = compiler2.acceptConstKeyword();
        org.junit.Assert.assertNotNull(errorFormat0);
        org.junit.Assert.assertNotNull(jSSourceFile4);
        org.junit.Assert.assertNotNull(jSSourceFile6);
        org.junit.Assert.assertNotNull(jSSourceFile12);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(result19);
        org.junit.Assert.assertNotNull(messageFormatter21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        com.google.javascript.jscomp.MessageFormatter messageFormatter0 = null;
        java.util.logging.Logger logger1 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager2 = new com.google.javascript.jscomp.LoggerErrorManager(messageFormatter0, logger1);
        com.google.javascript.jscomp.Compiler compiler3 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager2);
        loggerErrorManager2.generateReport();
        loggerErrorManager2.generateReport();
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.brokenClosureRequiresLevel;
        com.google.javascript.jscomp.CheckLevel checkLevel2 = com.google.javascript.jscomp.CheckLevel.WARNING;
        compilerOptions0.checkGlobalNamesLevel = checkLevel2;
        compilerOptions0.computeFunctionSideEffects = true;
        compilerOptions0.closurePass = false;
        com.google.javascript.jscomp.CompilerOptions compilerOptions8 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel9 = compilerOptions8.brokenClosureRequiresLevel;
        compilerOptions0.checkGlobalThisLevel = checkLevel9;
        compilerOptions0.collapseVariableDeclarations = false;
        compilerOptions0.removeEmptyFunctions = false;
        com.google.javascript.jscomp.CheckLevel checkLevel15 = null;
        compilerOptions0.checkUnreachableCode = checkLevel15;
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + checkLevel2 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel2.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
        org.junit.Assert.assertTrue("'" + checkLevel9 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel9.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray13 = new com.google.javascript.rhino.Node[] { node4, node6, node8, node10, node12 };
        com.google.javascript.rhino.Node node14 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray13);
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node21 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray26 = new com.google.javascript.rhino.Node[] { node17, node19, node21, node23, node25 };
        com.google.javascript.rhino.Node node27 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray26);
        com.google.javascript.rhino.Node node28 = new com.google.javascript.rhino.Node(100, node14, node27);
        boolean boolean29 = closureCodingConvention0.isVarArgsParameter(node28);
        java.lang.String str30 = closureCodingConvention0.getExportPropertyFunction();
        boolean boolean33 = closureCodingConvention0.isExported("goog.exportProperty", false);
        com.google.javascript.rhino.Node node37 = com.google.javascript.rhino.Node.newNumber(100.0d, 4095, 9);
        java.util.Set<java.lang.String> strSet38 = node37.getDirectives();
        boolean boolean39 = closureCodingConvention0.isVarArgsParameter(node37);
        com.google.javascript.rhino.Node node42 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node44 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node46 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node48 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node50 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray51 = new com.google.javascript.rhino.Node[] { node42, node44, node46, node48, node50 };
        com.google.javascript.rhino.Node node52 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray51);
        int int53 = node52.getSideEffectFlags();
        node37.addChildrenToFront(node52);
        com.google.javascript.rhino.Node node55 = node52.cloneNode();
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder56 = node55.getJsDocBuilderForNode();
        fileLevelJsDocBuilder56.append("DiagnosticGroup<undefinedVars>");
        fileLevelJsDocBuilder56.append("DiagnosticGroup<goog.exportSymbol>");
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(nodeArray13);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNotNull(nodeArray26);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "goog.exportProperty" + "'", str30.equals("goog.exportProperty"));
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(node37);
        org.junit.Assert.assertNull(strSet38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(node42);
        org.junit.Assert.assertNotNull(node44);
        org.junit.Assert.assertNotNull(node46);
        org.junit.Assert.assertNotNull(node48);
        org.junit.Assert.assertNotNull(node50);
        org.junit.Assert.assertNotNull(nodeArray51);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 0 + "'", int53 == 0);
        org.junit.Assert.assertNotNull(node55);
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder56);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        com.google.javascript.rhino.Node node3 = new com.google.javascript.rhino.Node((int) (short) 0, 16, 37);
        boolean boolean4 = node3.hasOneChild();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        com.google.javascript.rhino.Context context0 = com.google.javascript.rhino.Context.enter();
        boolean boolean1 = context0.isGeneratingSource();
        java.lang.Object obj2 = null;
        context0.removeThreadLocal(obj2);
        boolean boolean4 = context0.isGeneratingDebug();
        boolean boolean5 = context0.isGeneratingDebug();
        org.junit.Assert.assertNotNull(context0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile1 = com.google.javascript.jscomp.JSSourceFile.fromFile("Not declared as a constructor");
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile1, false);
        com.google.javascript.jscomp.CompilerInput compilerInput4 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile1);
        org.junit.Assert.assertNotNull(jSSourceFile1);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.checkDuplicateMessages = false;
        boolean boolean3 = compilerOptions0.inlineAnonymousFunctionExpressions;
        compilerOptions0.recordFunctionInformation = true;
        boolean boolean6 = compilerOptions0.checkCaja;
        java.util.Set<java.lang.String> strSet7 = compilerOptions0.stripNamePrefixes;
        boolean boolean8 = compilerOptions0.inlineFunctions;
        boolean boolean9 = compilerOptions0.aliasKeywords;
        boolean boolean10 = compilerOptions0.convertToDottedProperties;
        boolean boolean11 = compilerOptions0.exportTestFunctions;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(strSet7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        com.google.javascript.jscomp.SourceFile sourceFile3 = com.google.javascript.jscomp.SourceFile.fromCode("goog.exportProperty", "language version", "goog.exportProperty");
        sourceFile3.setOriginalPath("com.google.javascript.rhino.EcmaError: TypeError: -1 is not a function, it is java.lang.Byte.");
        org.junit.Assert.assertNotNull(sourceFile3);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.brokenClosureRequiresLevel;
        com.google.javascript.jscomp.CheckLevel checkLevel2 = com.google.javascript.jscomp.CheckLevel.WARNING;
        compilerOptions0.checkGlobalNamesLevel = checkLevel2;
        compilerOptions0.computeFunctionSideEffects = true;
        boolean boolean6 = compilerOptions0.removeDeadCode;
        compilerOptions0.inlineVariables = true;
        boolean boolean9 = compilerOptions0.removeDeadCode;
        compilerOptions0.closurePass = true;
        com.google.javascript.jscomp.CompilerOptions compilerOptions12 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions12.checkDuplicateMessages = false;
        boolean boolean15 = compilerOptions12.inlineAnonymousFunctionExpressions;
        compilerOptions12.recordFunctionInformation = true;
        boolean boolean18 = compilerOptions12.checkCaja;
        compilerOptions12.aliasableGlobals = "EOF 0";
        com.google.javascript.jscomp.CheckLevel checkLevel21 = com.google.javascript.jscomp.CheckLevel.OFF;
        compilerOptions12.reportUnknownTypes = checkLevel21;
        com.google.javascript.jscomp.CompilerOptions compilerOptions23 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions23.checkDuplicateMessages = false;
        boolean boolean26 = compilerOptions23.inlineAnonymousFunctionExpressions;
        compilerOptions23.recordFunctionInformation = true;
        boolean boolean29 = compilerOptions23.checkCaja;
        java.util.Set<java.lang.String> strSet30 = compilerOptions23.stripNamePrefixes;
        compilerOptions12.setIdGenerators(strSet30);
        compilerOptions0.stripTypes = strSet30;
        java.lang.String str33 = compilerOptions0.debugFunctionSideEffectsPath;
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + checkLevel2 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel2.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + checkLevel21 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel21.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(strSet30);
        org.junit.Assert.assertNull(str33);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        com.google.javascript.rhino.EcmaError ecmaError1 = com.google.javascript.rhino.ScriptRuntime.typeError("");
        int int2 = ecmaError1.getColumnNumber();
        org.junit.Assert.assertNotNull(ecmaError1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.brokenClosureRequiresLevel;
        com.google.javascript.jscomp.CheckLevel checkLevel2 = com.google.javascript.jscomp.CheckLevel.WARNING;
        compilerOptions0.checkGlobalNamesLevel = checkLevel2;
        com.google.javascript.jscomp.ErrorFormat errorFormat4 = null;
        compilerOptions0.errorFormat = errorFormat4;
        boolean boolean6 = compilerOptions0.ambiguateProperties;
        com.google.javascript.jscomp.CompilerOptions compilerOptions7 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel8 = compilerOptions7.brokenClosureRequiresLevel;
        com.google.javascript.jscomp.CheckLevel checkLevel9 = com.google.javascript.jscomp.CheckLevel.WARNING;
        compilerOptions7.checkGlobalNamesLevel = checkLevel9;
        compilerOptions7.computeFunctionSideEffects = true;
        boolean boolean13 = compilerOptions7.removeDeadCode;
        compilerOptions7.inlineVariables = true;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy16 = com.google.javascript.jscomp.VariableRenamingPolicy.OFF;
        compilerOptions7.variableRenaming = variableRenamingPolicy16;
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy18 = com.google.javascript.jscomp.PropertyRenamingPolicy.HEURISTIC;
        compilerOptions0.setRenamingPolicy(variableRenamingPolicy16, propertyRenamingPolicy18);
        compilerOptions0.markNoSideEffectCalls = false;
        java.lang.String str22 = compilerOptions0.nameReferenceGraphPath;
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + checkLevel2 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel2.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + checkLevel8 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel8.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + checkLevel9 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel9.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy16 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.OFF + "'", variableRenamingPolicy16.equals(com.google.javascript.jscomp.VariableRenamingPolicy.OFF));
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy18 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.HEURISTIC + "'", propertyRenamingPolicy18.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.HEURISTIC));
        org.junit.Assert.assertNull(str22);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.Node.newString(36, "// Input %num%");
        com.google.javascript.rhino.Node node3 = node2.getParent();
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertNull(node3);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.aliasAllStrings;
        compilerOptions0.setGenerateExports(true);
        compilerOptions0.setDefineToStringLiteral("JSC_OPTIMIZE_LOOP_ERROR", "1");
        compilerOptions0.allowLegacyJsMessages = false;
        compilerOptions0.allowLegacyJsMessages = true;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.brokenClosureRequiresLevel;
        com.google.javascript.jscomp.CheckLevel checkLevel2 = com.google.javascript.jscomp.CheckLevel.WARNING;
        compilerOptions0.checkGlobalNamesLevel = checkLevel2;
        compilerOptions0.computeFunctionSideEffects = true;
        boolean boolean6 = compilerOptions0.removeDeadCode;
        com.google.javascript.jscomp.CompilerOptions.TweakProcessing tweakProcessing7 = compilerOptions0.getTweakProcessing();
        compilerOptions0.setRemoveClosureAsserts(true);
        boolean boolean10 = compilerOptions0.recordFunctionInformation;
        compilerOptions0.computeFunctionSideEffects = true;
        com.google.javascript.jscomp.CompilerOptions.AliasTransformationHandler aliasTransformationHandler13 = compilerOptions0.getAliasTransformationHandler();
        com.google.javascript.rhino.SourcePosition<com.google.javascript.jscomp.CompilerOptions.AliasTransformation> aliasTransformationSourcePosition15 = null;
        try {
            com.google.javascript.jscomp.CompilerOptions.AliasTransformation aliasTransformation16 = aliasTransformationHandler13.logAliasTransformation("DiagnosticGroup<strictModuleDepCheck>", aliasTransformationSourcePosition15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + checkLevel2 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel2.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + tweakProcessing7 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TweakProcessing.OFF + "'", tweakProcessing7.equals(com.google.javascript.jscomp.CompilerOptions.TweakProcessing.OFF));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(aliasTransformationHandler13);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile3 = com.google.javascript.jscomp.JSSourceFile.fromFile("Not declared as a constructor");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile5 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.CompilerInput compilerInput6 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile5);
        com.google.javascript.jscomp.CompilerInput compilerInput9 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput6, "hi!", false);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile11 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        compilerInput6.setSourceFile((com.google.javascript.jscomp.SourceFile) jSSourceFile11);
        java.lang.String str13 = jSSourceFile11.toString();
        com.google.javascript.jscomp.CompilerOptions compilerOptions14 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean15 = compilerOptions14.aliasAllStrings;
        compilerOptions14.setGenerateExports(true);
        com.google.javascript.jscomp.Result result18 = compiler1.compile(jSSourceFile3, jSSourceFile11, compilerOptions14);
        com.google.javascript.jscomp.Compiler.IntermediateState intermediateState19 = compiler1.getState();
        boolean boolean20 = compiler1.acceptEcmaScript5();
        compiler1.optimize();
        org.junit.Assert.assertNotNull(jSSourceFile3);
        org.junit.Assert.assertNotNull(jSSourceFile5);
        org.junit.Assert.assertNotNull(jSSourceFile11);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(result18);
        org.junit.Assert.assertNotNull(intermediateState19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.brokenClosureRequiresLevel;
        com.google.javascript.jscomp.CheckLevel checkLevel2 = com.google.javascript.jscomp.CheckLevel.WARNING;
        compilerOptions0.checkGlobalNamesLevel = checkLevel2;
        compilerOptions0.computeFunctionSideEffects = true;
        compilerOptions0.closurePass = false;
        com.google.javascript.jscomp.CompilerOptions compilerOptions8 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel9 = compilerOptions8.brokenClosureRequiresLevel;
        compilerOptions0.checkGlobalThisLevel = checkLevel9;
        compilerOptions0.collapseVariableDeclarations = false;
        compilerOptions0.checkTypes = true;
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + checkLevel2 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel2.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
        org.junit.Assert.assertTrue("'" + checkLevel9 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel9.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.brokenClosureRequiresLevel;
        com.google.javascript.jscomp.CheckLevel checkLevel2 = com.google.javascript.jscomp.CheckLevel.WARNING;
        compilerOptions0.checkGlobalNamesLevel = checkLevel2;
        compilerOptions0.computeFunctionSideEffects = true;
        boolean boolean6 = compilerOptions0.removeDeadCode;
        compilerOptions0.inlineVariables = true;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap9 = compilerOptions0.cssRenamingMap;
        com.google.javascript.jscomp.CheckLevel checkLevel10 = compilerOptions0.checkGlobalThisLevel;
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + checkLevel2 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel2.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(cssRenamingMap9);
        org.junit.Assert.assertTrue("'" + checkLevel10 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel10.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray13 = new com.google.javascript.rhino.Node[] { node4, node6, node8, node10, node12 };
        com.google.javascript.rhino.Node node14 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray13);
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node21 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray26 = new com.google.javascript.rhino.Node[] { node17, node19, node21, node23, node25 };
        com.google.javascript.rhino.Node node27 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray26);
        com.google.javascript.rhino.Node node28 = new com.google.javascript.rhino.Node(100, node14, node27);
        java.lang.String str29 = closureCodingConvention0.getSingletonGetterClassName(node28);
        com.google.javascript.rhino.JSDocInfo jSDocInfo30 = null;
        node28.setJSDocInfo(jSDocInfo30);
        boolean boolean32 = node28.isVarArgs();
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(nodeArray13);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNotNull(nodeArray26);
        org.junit.Assert.assertNull(str29);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.brokenClosureRequiresLevel;
        com.google.javascript.jscomp.CheckLevel checkLevel2 = com.google.javascript.jscomp.CheckLevel.WARNING;
        compilerOptions0.checkGlobalNamesLevel = checkLevel2;
        compilerOptions0.computeFunctionSideEffects = true;
        boolean boolean6 = compilerOptions0.removeDeadCode;
        compilerOptions0.setManageClosureDependencies(false);
        compilerOptions0.nameReferenceGraphPath = "";
        java.lang.String str11 = compilerOptions0.syntheticBlockStartMarker;
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup12 = com.google.javascript.jscomp.DiagnosticGroups.STRICT_MODULE_DEP_CHECK;
        java.lang.String str13 = diagnosticGroup12.toString();
        com.google.javascript.jscomp.CheckLevel checkLevel14 = com.google.javascript.jscomp.CheckLevel.WARNING;
        compilerOptions0.setWarningLevel(diagnosticGroup12, checkLevel14);
        boolean boolean16 = compilerOptions0.recordFunctionInformation;
        compilerOptions0.unaliasableGlobals = "TypeError";
        boolean boolean19 = compilerOptions0.computeFunctionSideEffects;
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + checkLevel2 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel2.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(str11);
        org.junit.Assert.assertNotNull(diagnosticGroup12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "DiagnosticGroup<strictModuleDepCheck>" + "'", str13.equals("DiagnosticGroup<strictModuleDepCheck>"));
        org.junit.Assert.assertTrue("'" + checkLevel14 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel14.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newNumber(100.0d, 4095, 9);
        java.util.Set<java.lang.String> strSet5 = node4.getDirectives();
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray17 = new com.google.javascript.rhino.Node[] { node8, node10, node12, node14, node16 };
        com.google.javascript.rhino.Node node18 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray17);
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node21 = node18.copyInformationFrom(node20);
        com.google.javascript.rhino.Node node24 = new com.google.javascript.rhino.Node(28, node4, node18, (-2), (int) (byte) -1);
        boolean boolean25 = node24.isNoSideEffectsCall();
        int int27 = node24.getIntProp(1);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNull(strSet5);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertNotNull(nodeArray17);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        com.google.javascript.jscomp.CompilerOptions.TweakProcessing tweakProcessing0 = com.google.javascript.jscomp.CompilerOptions.TweakProcessing.OFF;
        boolean boolean1 = tweakProcessing0.isOn();
        boolean boolean2 = tweakProcessing0.isOn();
        org.junit.Assert.assertTrue("'" + tweakProcessing0 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TweakProcessing.OFF + "'", tweakProcessing0.equals(com.google.javascript.jscomp.CompilerOptions.TweakProcessing.OFF));
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.brokenClosureRequiresLevel;
        com.google.javascript.jscomp.CheckLevel checkLevel2 = com.google.javascript.jscomp.CheckLevel.WARNING;
        compilerOptions0.checkGlobalNamesLevel = checkLevel2;
        compilerOptions0.renamePrefix = "hi!";
        compilerOptions0.instrumentForCoverageOnly = true;
        compilerOptions0.setDefineToDoubleLiteral("goog.global", (double) 10L);
        com.google.javascript.jscomp.CheckLevel checkLevel11 = compilerOptions0.checkMissingGetCssNameLevel;
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + checkLevel2 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel2.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
        org.junit.Assert.assertTrue("'" + checkLevel11 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel11.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.brokenClosureRequiresLevel;
        com.google.javascript.jscomp.CheckLevel checkLevel2 = com.google.javascript.jscomp.CheckLevel.WARNING;
        compilerOptions0.checkGlobalNamesLevel = checkLevel2;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy4 = com.google.javascript.jscomp.VariableRenamingPolicy.OFF;
        compilerOptions0.variableRenaming = variableRenamingPolicy4;
        com.google.javascript.jscomp.CheckLevel checkLevel6 = compilerOptions0.checkMissingGetCssNameLevel;
        compilerOptions0.reportPath = "Not declared as a type name";
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + checkLevel2 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel2.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy4 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.OFF + "'", variableRenamingPolicy4.equals(com.google.javascript.jscomp.VariableRenamingPolicy.OFF));
        org.junit.Assert.assertTrue("'" + checkLevel6 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel6.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        com.google.javascript.rhino.Context context0 = com.google.javascript.rhino.Context.enter();
        boolean boolean1 = context0.isGeneratingSource();
        boolean boolean2 = context0.isGeneratingSource();
        com.google.javascript.jscomp.CompilerOptions compilerOptions3 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel4 = compilerOptions3.brokenClosureRequiresLevel;
        com.google.javascript.jscomp.CheckLevel checkLevel5 = com.google.javascript.jscomp.CheckLevel.WARNING;
        compilerOptions3.checkGlobalNamesLevel = checkLevel5;
        compilerOptions3.computeFunctionSideEffects = true;
        compilerOptions3.closurePass = false;
        com.google.javascript.jscomp.CompilerOptions compilerOptions11 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel12 = compilerOptions11.brokenClosureRequiresLevel;
        com.google.javascript.jscomp.CheckLevel checkLevel13 = com.google.javascript.jscomp.CheckLevel.WARNING;
        compilerOptions11.checkGlobalNamesLevel = checkLevel13;
        compilerOptions11.computeFunctionSideEffects = true;
        boolean boolean17 = compilerOptions11.removeDeadCode;
        compilerOptions11.inlineVariables = true;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy20 = com.google.javascript.jscomp.VariableRenamingPolicy.OFF;
        compilerOptions11.variableRenaming = variableRenamingPolicy20;
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy22 = com.google.javascript.jscomp.PropertyRenamingPolicy.HEURISTIC;
        compilerOptions3.setRenamingPolicy(variableRenamingPolicy20, propertyRenamingPolicy22);
        context0.seal((java.lang.Object) propertyRenamingPolicy22);
        org.junit.Assert.assertNotNull(context0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + checkLevel4 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel4.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + checkLevel5 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel5.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
        org.junit.Assert.assertTrue("'" + checkLevel12 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel12.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + checkLevel13 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel13.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy20 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.OFF + "'", variableRenamingPolicy20.equals(com.google.javascript.jscomp.VariableRenamingPolicy.OFF));
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy22 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.HEURISTIC + "'", propertyRenamingPolicy22.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.HEURISTIC));
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.brokenClosureRequiresLevel;
        com.google.javascript.jscomp.CheckLevel checkLevel2 = com.google.javascript.jscomp.CheckLevel.WARNING;
        compilerOptions0.checkGlobalNamesLevel = checkLevel2;
        compilerOptions0.computeFunctionSideEffects = true;
        compilerOptions0.setDefineToStringLiteral("", "Unknown class name");
        java.lang.String str9 = compilerOptions0.aliasableGlobals;
        byte[] byteArray10 = compilerOptions0.inputVariableMapSerialized;
        com.google.javascript.jscomp.MessageFormatter messageFormatter11 = null;
        java.util.logging.Logger logger12 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager13 = new com.google.javascript.jscomp.LoggerErrorManager(messageFormatter11, logger12);
        int int14 = loggerErrorManager13.getWarningCount();
        com.google.javascript.jscomp.CompilerOptions compilerOptions15 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel16 = compilerOptions15.brokenClosureRequiresLevel;
        com.google.javascript.jscomp.DiagnosticType diagnosticType17 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        java.lang.String[] strArray18 = com.google.javascript.rhino.ScriptRuntime.emptyStrings;
        com.google.javascript.jscomp.JSError jSError19 = com.google.javascript.jscomp.JSError.make(diagnosticType17, strArray18);
        com.google.javascript.jscomp.DiagnosticType diagnosticType20 = jSError19.getType();
        loggerErrorManager13.report(checkLevel16, jSError19);
        compilerOptions0.checkUndefinedProperties = checkLevel16;
        compilerOptions0.disableRuntimeTypeCheck();
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + checkLevel2 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel2.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertNull(byteArray10);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + checkLevel16 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel16.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticType17);
        org.junit.Assert.assertNotNull(strArray18);
        org.junit.Assert.assertNotNull(jSError19);
        org.junit.Assert.assertNotNull(diagnosticType20);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.brokenClosureRequiresLevel;
        com.google.javascript.jscomp.CheckLevel checkLevel2 = com.google.javascript.jscomp.CheckLevel.WARNING;
        compilerOptions0.checkGlobalNamesLevel = checkLevel2;
        compilerOptions0.computeFunctionSideEffects = true;
        boolean boolean6 = compilerOptions0.removeDeadCode;
        compilerOptions0.inlineVariables = true;
        compilerOptions0.crossModuleMethodMotion = true;
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + checkLevel2 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel2.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.brokenClosureRequiresLevel;
        com.google.javascript.jscomp.CheckLevel checkLevel2 = com.google.javascript.jscomp.CheckLevel.WARNING;
        compilerOptions0.checkGlobalNamesLevel = checkLevel2;
        compilerOptions0.computeFunctionSideEffects = true;
        compilerOptions0.closurePass = false;
        boolean boolean8 = compilerOptions0.crossModuleMethodMotion;
        compilerOptions0.ignoreCajaProperties = true;
        compilerOptions0.syntheticBlockEndMarker = "";
        compilerOptions0.unaliasableGlobals = "TypeError";
        java.lang.String str15 = compilerOptions0.nameReferenceGraphPath;
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + checkLevel2 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel2.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNull(str15);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test214");
        com.google.javascript.rhino.Node.SideEffectFlags sideEffectFlags0 = new com.google.javascript.rhino.Node.SideEffectFlags();
        sideEffectFlags0.clearSideEffectFlags();
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test215");
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newString((int) (short) 0, "hi!", 100, (-2));
        com.google.javascript.rhino.Node node6 = new com.google.javascript.rhino.Node(10, node5);
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString("DiagnosticGroup<strictModuleDepCheck>");
        boolean boolean9 = node5.isEquivalentToTyped(node8);
        node5.putIntProp((int) (short) -1, 13);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.brokenClosureRequiresLevel;
        compilerOptions0.setManageClosureDependencies(true);
        java.lang.String[] strArray11 = new java.lang.String[] { "goog.exportProperty", "Not declared as a type name", "error reporter", "DiagnosticGroup<undefinedVars>", "goog.exportProperty", "Not declared as a constructor" };
        java.util.ArrayList<java.lang.String> strList12 = new java.util.ArrayList<java.lang.String>();
        boolean boolean13 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strList12, strArray11);
        compilerOptions0.setReplaceStringsConfiguration("goog.exportProperty", (java.util.List<java.lang.String>) strList12);
        compilerOptions0.ideMode = false;
        byte[] byteArray22 = new byte[] { (byte) 100, (byte) 1, (byte) 10, (byte) 10, (byte) 1 };
        compilerOptions0.inputVariableMapSerialized = byteArray22;
        byte[] byteArray24 = compilerOptions0.inputVariableMapSerialized;
        boolean boolean25 = compilerOptions0.aliasExternals;
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(strArray11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(byteArray22);
        org.junit.Assert.assertNotNull(byteArray24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test217");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.brokenClosureRequiresLevel;
        com.google.javascript.jscomp.CheckLevel checkLevel2 = com.google.javascript.jscomp.CheckLevel.WARNING;
        compilerOptions0.checkGlobalNamesLevel = checkLevel2;
        compilerOptions0.computeFunctionSideEffects = true;
        compilerOptions0.setDefineToStringLiteral("", "Unknown class name");
        java.lang.String str9 = compilerOptions0.aliasableGlobals;
        byte[] byteArray10 = compilerOptions0.inputVariableMapSerialized;
        boolean boolean11 = compilerOptions0.inlineGetters;
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + checkLevel2 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel2.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertNull(byteArray10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test218");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.checkDuplicateMessages = false;
        boolean boolean3 = compilerOptions0.inlineAnonymousFunctionExpressions;
        java.lang.String str4 = compilerOptions0.checkMissingGetCssNameBlacklist;
        compilerOptions0.inlineAnonymousFunctionExpressions = false;
        boolean boolean7 = compilerOptions0.checkSymbols;
        boolean boolean8 = compilerOptions0.checkTypes;
        boolean boolean9 = compilerOptions0.removeTryCatchFinally;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test219");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.brokenClosureRequiresLevel;
        com.google.javascript.jscomp.CheckLevel checkLevel2 = com.google.javascript.jscomp.CheckLevel.WARNING;
        compilerOptions0.checkGlobalNamesLevel = checkLevel2;
        compilerOptions0.computeFunctionSideEffects = true;
        boolean boolean6 = compilerOptions0.removeDeadCode;
        compilerOptions0.removeDeadCode = false;
        compilerOptions0.checkCaja = false;
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + checkLevel2 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel2.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test220");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.brokenClosureRequiresLevel;
        com.google.javascript.jscomp.CheckLevel checkLevel2 = com.google.javascript.jscomp.CheckLevel.WARNING;
        compilerOptions0.checkGlobalNamesLevel = checkLevel2;
        compilerOptions0.computeFunctionSideEffects = true;
        compilerOptions0.setShadowVariables(true);
        compilerOptions0.debugFunctionSideEffectsPath = "goog.global";
        java.lang.String str10 = compilerOptions0.inputDelimiter;
        compilerOptions0.removeTryCatchFinally = false;
        boolean boolean13 = compilerOptions0.ambiguateProperties;
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + checkLevel2 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel2.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "// Input %num%" + "'", str10.equals("// Input %num%"));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray11 = new com.google.javascript.rhino.Node[] { node2, node4, node6, node8, node10 };
        com.google.javascript.rhino.Node node12 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray11);
        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node22 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node24 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray25 = new com.google.javascript.rhino.Node[] { node16, node18, node20, node22, node24 };
        com.google.javascript.rhino.Node node26 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray25);
        com.google.javascript.rhino.Node node28 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node29 = node26.copyInformationFrom(node28);
        com.google.javascript.rhino.Node node30 = node26.getParent();
        com.google.javascript.rhino.Node node31 = new com.google.javascript.rhino.Node((int) (short) -1, node26);
        com.google.javascript.rhino.Node node36 = com.google.javascript.rhino.Node.newString((int) (short) 0, "hi!", 100, (-2));
        boolean boolean37 = node26.isEquivalentTo(node36);
        com.google.javascript.rhino.Node node38 = node12.clonePropsFrom(node36);
        com.google.javascript.rhino.JSDocInfo jSDocInfo39 = node38.getJSDocInfo();
        int int41 = node38.getIntProp(26);
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable42 = node38.children();
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(nodeArray11);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertNotNull(nodeArray25);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNull(node30);
        org.junit.Assert.assertNotNull(node36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(node38);
        org.junit.Assert.assertNull(jSDocInfo39);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
        org.junit.Assert.assertNotNull(nodeIterable42);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray0 = new com.google.javascript.jscomp.WarningsGuard[] {};
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard1 = new com.google.javascript.jscomp.ComposeWarningsGuard(warningsGuardArray0);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup2 = com.google.javascript.jscomp.DiagnosticGroups.STRICT_MODULE_DEP_CHECK;
        boolean boolean3 = composeWarningsGuard1.disables(diagnosticGroup2);
        java.lang.String str4 = composeWarningsGuard1.toString();
        org.junit.Assert.assertNotNull(warningsGuardArray0);
        org.junit.Assert.assertNotNull(diagnosticGroup2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test223");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray13 = new com.google.javascript.rhino.Node[] { node4, node6, node8, node10, node12 };
        com.google.javascript.rhino.Node node14 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray13);
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node21 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray26 = new com.google.javascript.rhino.Node[] { node17, node19, node21, node23, node25 };
        com.google.javascript.rhino.Node node27 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray26);
        com.google.javascript.rhino.Node node28 = new com.google.javascript.rhino.Node(100, node14, node27);
        com.google.javascript.jscomp.DiagnosticType diagnosticType29 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        java.lang.String str30 = diagnosticType29.key;
        java.lang.Class<?> wildcardClass31 = diagnosticType29.getClass();
        java.lang.String[] strArray32 = com.google.javascript.rhino.ScriptRuntime.emptyStrings;
        com.google.javascript.jscomp.JSError jSError33 = com.google.javascript.jscomp.JSError.make("com.google.javascript.rhino.EcmaError: TypeError: ", node14, diagnosticType29, strArray32);
        node14.setVarArgs(false);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(nodeArray13);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNotNull(nodeArray26);
        org.junit.Assert.assertNotNull(diagnosticType29);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "JSC_OPTIMIZE_LOOP_ERROR" + "'", str30.equals("JSC_OPTIMIZE_LOOP_ERROR"));
        org.junit.Assert.assertNotNull(wildcardClass31);
        org.junit.Assert.assertNotNull(strArray32);
        org.junit.Assert.assertNotNull(jSError33);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test224");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile5 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.CompilerInput compilerInput6 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile5);
        com.google.javascript.jscomp.CompilerInput compilerInput9 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput6, "hi!", false);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile11 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        compilerInput6.setSourceFile((com.google.javascript.jscomp.SourceFile) jSSourceFile11);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile14 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray15 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile2, jSSourceFile11, jSSourceFile14 };
        java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList16 = new java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile>();
        boolean boolean17 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList16, jSSourceFileArray15);
        com.google.javascript.jscomp.JSModule[] jSModuleArray18 = new com.google.javascript.jscomp.JSModule[] {};
        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList19 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
        boolean boolean20 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList19, jSModuleArray18);
        com.google.javascript.jscomp.CompilerOptions compilerOptions21 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions21.checkDuplicateMessages = false;
        boolean boolean24 = compilerOptions21.inlineAnonymousFunctionExpressions;
        compilerOptions21.crossModuleMethodMotion = true;
        com.google.javascript.jscomp.Result result27 = compiler0.compileModules((java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList16, (java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList19, compilerOptions21);
        boolean boolean28 = compiler0.acceptEcmaScript5();
        com.google.javascript.jscomp.SourceExcerptProvider.SourceExcerpt sourceExcerpt29 = null;
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter30 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler0, sourceExcerpt29);
        org.junit.Assert.assertNotNull(jSSourceFile2);
        org.junit.Assert.assertNotNull(jSSourceFile5);
        org.junit.Assert.assertNotNull(jSSourceFile11);
        org.junit.Assert.assertNotNull(jSSourceFile14);
        org.junit.Assert.assertNotNull(jSSourceFileArray15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(jSModuleArray18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(result27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test225");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.brokenClosureRequiresLevel;
        com.google.javascript.jscomp.CheckLevel checkLevel2 = com.google.javascript.jscomp.CheckLevel.WARNING;
        compilerOptions0.checkGlobalNamesLevel = checkLevel2;
        compilerOptions0.computeFunctionSideEffects = true;
        compilerOptions0.closurePass = false;
        boolean boolean8 = compilerOptions0.crossModuleMethodMotion;
        compilerOptions0.ignoreCajaProperties = true;
        compilerOptions0.syntheticBlockEndMarker = "";
        com.google.javascript.jscomp.CheckLevel checkLevel13 = compilerOptions0.brokenClosureRequiresLevel;
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + checkLevel2 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel2.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + checkLevel13 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel13.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test226");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray13 = new com.google.javascript.rhino.Node[] { node4, node6, node8, node10, node12 };
        com.google.javascript.rhino.Node node14 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray13);
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node21 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray26 = new com.google.javascript.rhino.Node[] { node17, node19, node21, node23, node25 };
        com.google.javascript.rhino.Node node27 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray26);
        com.google.javascript.rhino.Node node28 = new com.google.javascript.rhino.Node(100, node14, node27);
        boolean boolean29 = closureCodingConvention0.isVarArgsParameter(node28);
        java.lang.String str30 = closureCodingConvention0.getExportPropertyFunction();
        boolean boolean32 = closureCodingConvention0.isConstant("hi!");
        boolean boolean34 = closureCodingConvention0.isConstant("Unknown class name");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention35 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node39 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node41 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node43 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node45 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node47 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray48 = new com.google.javascript.rhino.Node[] { node39, node41, node43, node45, node47 };
        com.google.javascript.rhino.Node node49 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray48);
        com.google.javascript.rhino.Node node52 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node54 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node56 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node58 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node60 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray61 = new com.google.javascript.rhino.Node[] { node52, node54, node56, node58, node60 };
        com.google.javascript.rhino.Node node62 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray61);
        com.google.javascript.rhino.Node node63 = new com.google.javascript.rhino.Node(100, node49, node62);
        java.lang.String str64 = closureCodingConvention35.getSingletonGetterClassName(node63);
        com.google.javascript.rhino.Node node70 = com.google.javascript.rhino.Node.newString((int) (short) 0, "hi!", 100, (-2));
        com.google.javascript.rhino.Node node71 = new com.google.javascript.rhino.Node(10, node70);
        java.lang.String str72 = closureCodingConvention35.identifyTypeDefAssign(node71);
        com.google.javascript.rhino.Node node73 = node71.cloneNode();
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship74 = closureCodingConvention0.getDelegateRelationship(node73);
        com.google.javascript.rhino.Node node77 = com.google.javascript.rhino.Node.newString(36, "// Input %num%");
        com.google.javascript.rhino.Node node79 = com.google.javascript.rhino.Node.newString("DiagnosticGroup<strictModuleDepCheck>");
        node73.addChildAfter(node77, node79);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(nodeArray13);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNotNull(nodeArray26);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "goog.exportProperty" + "'", str30.equals("goog.exportProperty"));
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(node39);
        org.junit.Assert.assertNotNull(node41);
        org.junit.Assert.assertNotNull(node43);
        org.junit.Assert.assertNotNull(node45);
        org.junit.Assert.assertNotNull(node47);
        org.junit.Assert.assertNotNull(nodeArray48);
        org.junit.Assert.assertNotNull(node52);
        org.junit.Assert.assertNotNull(node54);
        org.junit.Assert.assertNotNull(node56);
        org.junit.Assert.assertNotNull(node58);
        org.junit.Assert.assertNotNull(node60);
        org.junit.Assert.assertNotNull(nodeArray61);
        org.junit.Assert.assertNull(str64);
        org.junit.Assert.assertNotNull(node70);
        org.junit.Assert.assertNull(str72);
        org.junit.Assert.assertNotNull(node73);
        org.junit.Assert.assertNull(delegateRelationship74);
        org.junit.Assert.assertNotNull(node77);
        org.junit.Assert.assertNotNull(node79);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test227");
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newString((int) (short) 0, "hi!", 100, (-2));
        com.google.javascript.jscomp.DiagnosticType diagnosticType6 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray7 = com.google.javascript.rhino.ScriptRuntime.emptyStrings;
        com.google.javascript.jscomp.JSError jSError8 = com.google.javascript.jscomp.JSError.make("", node5, diagnosticType6, strArray7);
        java.lang.String str9 = jSError8.sourceName;
        com.google.javascript.jscomp.CompilerOptions compilerOptions10 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel11 = compilerOptions10.brokenClosureRequiresLevel;
        compilerOptions10.setManageClosureDependencies(true);
        java.lang.String[] strArray21 = new java.lang.String[] { "goog.exportProperty", "Not declared as a type name", "error reporter", "DiagnosticGroup<undefinedVars>", "goog.exportProperty", "Not declared as a constructor" };
        java.util.ArrayList<java.lang.String> strList22 = new java.util.ArrayList<java.lang.String>();
        boolean boolean23 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strList22, strArray21);
        compilerOptions10.setReplaceStringsConfiguration("goog.exportProperty", (java.util.List<java.lang.String>) strList22);
        compilerOptions10.decomposeExpressions = false;
        com.google.javascript.jscomp.CheckLevel checkLevel27 = compilerOptions10.checkMissingGetCssNameLevel;
        compilerOptions10.groupVariableDeclarations = true;
        boolean boolean30 = compilerOptions10.removeUnusedLocalVars;
        boolean boolean31 = jSError8.equals((java.lang.Object) compilerOptions10);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNotNull(diagnosticType6);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertNotNull(jSError8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + checkLevel11 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel11.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(strArray21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + checkLevel27 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel27.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test228");
        try {
            com.google.javascript.rhino.Context.reportWarning("goog.exportSymbol", "", (int) (short) 100, "DiagnosticGroup<undefinedVars>", 31);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: No Context associated with current Thread");
        } catch (java.lang.RuntimeException e) {
        }
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test229");
        try {
            com.google.javascript.rhino.Context.reportWarning("com.google.javascript.rhino.EcmaError: TypeError: -1 is not a function, it is java.lang.Byte.");
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: No Context associated with current Thread");
        } catch (java.lang.RuntimeException e) {
        }
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test230");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile3 = com.google.javascript.jscomp.JSSourceFile.fromFile("Not declared as a constructor");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile5 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.CompilerInput compilerInput6 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile5);
        com.google.javascript.jscomp.CompilerInput compilerInput9 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput6, "hi!", false);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile11 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        compilerInput6.setSourceFile((com.google.javascript.jscomp.SourceFile) jSSourceFile11);
        java.lang.String str13 = jSSourceFile11.toString();
        com.google.javascript.jscomp.CompilerOptions compilerOptions14 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean15 = compilerOptions14.aliasAllStrings;
        compilerOptions14.setGenerateExports(true);
        com.google.javascript.jscomp.Result result18 = compiler1.compile(jSSourceFile3, jSSourceFile11, compilerOptions14);
        compilerOptions14.syntheticBlockEndMarker = "Not declared as a type name";
        compilerOptions14.generatePseudoNames = true;
        boolean boolean23 = compilerOptions14.isExternExportsEnabled();
        boolean boolean24 = compilerOptions14.printInputDelimiter;
        org.junit.Assert.assertNotNull(jSSourceFile3);
        org.junit.Assert.assertNotNull(jSSourceFile5);
        org.junit.Assert.assertNotNull(jSSourceFile11);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(result18);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test231");
        com.google.javascript.rhino.EcmaError ecmaError1 = com.google.javascript.rhino.ScriptRuntime.typeError("");
        java.lang.String str2 = ecmaError1.details();
        java.lang.String str3 = ecmaError1.getName();
        java.lang.String str4 = ecmaError1.sourceName();
        int int5 = ecmaError1.columnNumber();
        org.junit.Assert.assertNotNull(ecmaError1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "TypeError: " + "'", str2.equals("TypeError: "));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "TypeError" + "'", str3.equals("TypeError"));
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test232");
        com.google.javascript.jscomp.AbstractCompiler abstractCompiler0 = null;
        com.google.javascript.jscomp.NodeTraversal.Callback callback1 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal2 = new com.google.javascript.jscomp.NodeTraversal(abstractCompiler0, callback1);
        boolean boolean3 = nodeTraversal2.hasScope();
        com.google.javascript.jscomp.Scope scope4 = nodeTraversal2.getScope();
        com.google.javascript.jscomp.Compiler compiler5 = nodeTraversal2.getCompiler();
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention6 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray19 = new com.google.javascript.rhino.Node[] { node10, node12, node14, node16, node18 };
        com.google.javascript.rhino.Node node20 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray19);
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node27 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node29 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node31 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray32 = new com.google.javascript.rhino.Node[] { node23, node25, node27, node29, node31 };
        com.google.javascript.rhino.Node node33 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray32);
        com.google.javascript.rhino.Node node34 = new com.google.javascript.rhino.Node(100, node20, node33);
        boolean boolean35 = closureCodingConvention6.isVarArgsParameter(node34);
        java.lang.String str36 = closureCodingConvention6.getExportPropertyFunction();
        boolean boolean39 = closureCodingConvention6.isExported("goog.exportProperty", false);
        com.google.javascript.rhino.Node node43 = com.google.javascript.rhino.Node.newNumber(100.0d, 4095, 9);
        java.util.Set<java.lang.String> strSet44 = node43.getDirectives();
        boolean boolean45 = closureCodingConvention6.isVarArgsParameter(node43);
        com.google.javascript.rhino.Node node48 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node50 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node52 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node54 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node56 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray57 = new com.google.javascript.rhino.Node[] { node48, node50, node52, node54, node56 };
        com.google.javascript.rhino.Node node58 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray57);
        com.google.javascript.rhino.Node node59 = node58.getNext();
        com.google.javascript.rhino.Node node63 = com.google.javascript.rhino.Node.newNumber(100.0d, 4095, 9);
        java.lang.String str64 = closureCodingConvention6.extractClassNameIfRequire(node58, node63);
        try {
            nodeTraversal2.traverse(node63);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(scope4);
        org.junit.Assert.assertNull(compiler5);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNotNull(nodeArray19);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNotNull(node27);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertNotNull(nodeArray32);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "goog.exportProperty" + "'", str36.equals("goog.exportProperty"));
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(node43);
        org.junit.Assert.assertNull(strSet44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(node48);
        org.junit.Assert.assertNotNull(node50);
        org.junit.Assert.assertNotNull(node52);
        org.junit.Assert.assertNotNull(node54);
        org.junit.Assert.assertNotNull(node56);
        org.junit.Assert.assertNotNull(nodeArray57);
        org.junit.Assert.assertNull(node59);
        org.junit.Assert.assertNotNull(node63);
        org.junit.Assert.assertNull(str64);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test233");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.checkDuplicateMessages = false;
        boolean boolean3 = compilerOptions0.inlineAnonymousFunctionExpressions;
        compilerOptions0.recordFunctionInformation = true;
        boolean boolean6 = compilerOptions0.checkCaja;
        compilerOptions0.aliasableGlobals = "EOF 0";
        boolean boolean9 = compilerOptions0.removeEmptyFunctions;
        compilerOptions0.exportTestFunctions = true;
        boolean boolean12 = compilerOptions0.optimizeReturns;
        com.google.javascript.jscomp.CompilerOptions compilerOptions13 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions13.checkDuplicateMessages = false;
        boolean boolean16 = compilerOptions13.inlineAnonymousFunctionExpressions;
        compilerOptions13.recordFunctionInformation = true;
        boolean boolean19 = compilerOptions13.checkCaja;
        java.util.Set<java.lang.String> strSet20 = compilerOptions13.stripNamePrefixes;
        compilerOptions0.stripNameSuffixes = strSet20;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(strSet20);
    }

//    @Test
//    public void test234() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test234");
//        com.google.javascript.rhino.Context context0 = com.google.javascript.rhino.Context.enter();
//        boolean boolean1 = context0.isGeneratingSource();
//        java.lang.Object obj2 = null;
//        context0.removeThreadLocal(obj2);
//        com.google.javascript.jscomp.CompilerOptions compilerOptions4 = new com.google.javascript.jscomp.CompilerOptions();
//        compilerOptions4.checkDuplicateMessages = false;
//        boolean boolean7 = compilerOptions4.inlineAnonymousFunctionExpressions;
//        context0.seal((java.lang.Object) boolean7);
//        try {
//            context0.removeActivationName("");
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
//        } catch (java.lang.IllegalStateException e) {
//        }
//        org.junit.Assert.assertNotNull(context0);
//        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test235");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.brokenClosureRequiresLevel;
        com.google.javascript.jscomp.CheckLevel checkLevel2 = com.google.javascript.jscomp.CheckLevel.WARNING;
        compilerOptions0.checkGlobalNamesLevel = checkLevel2;
        compilerOptions0.computeFunctionSideEffects = true;
        compilerOptions0.setShadowVariables(true);
        compilerOptions0.debugFunctionSideEffectsPath = "goog.global";
        compilerOptions0.checkTypes = false;
        compilerOptions0.gatherCssNames = false;
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + checkLevel2 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel2.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test236");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.checkDuplicateMessages = false;
        boolean boolean3 = compilerOptions0.inlineAnonymousFunctionExpressions;
        boolean boolean4 = compilerOptions0.crossModuleMethodMotion;
        boolean boolean5 = compilerOptions0.removeUnusedPrototypePropertiesInExterns;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test237");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.TYPE_INVALIDATION;
        java.lang.String str1 = diagnosticGroup0.toString();
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test238");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.brokenClosureRequiresLevel;
        compilerOptions0.inlineConstantVars = false;
        com.google.javascript.jscomp.CompilerOptions compilerOptions4 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel5 = compilerOptions4.brokenClosureRequiresLevel;
        java.util.Set<java.lang.String> strSet6 = compilerOptions4.aliasableStrings;
        boolean boolean7 = compilerOptions4.decomposeExpressions;
        java.util.Set<java.lang.String> strSet8 = compilerOptions4.stripNamePrefixes;
        compilerOptions0.stripTypePrefixes = strSet8;
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + checkLevel5 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel5.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(strSet6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(strSet8);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test239");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.brokenClosureRequiresLevel;
        com.google.javascript.jscomp.CheckLevel checkLevel2 = com.google.javascript.jscomp.CheckLevel.WARNING;
        compilerOptions0.checkGlobalNamesLevel = checkLevel2;
        compilerOptions0.computeFunctionSideEffects = true;
        compilerOptions0.closurePass = false;
        com.google.javascript.jscomp.CompilerOptions compilerOptions8 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel9 = compilerOptions8.brokenClosureRequiresLevel;
        compilerOptions0.checkGlobalThisLevel = checkLevel9;
        compilerOptions0.collapseVariableDeclarations = false;
        com.google.javascript.jscomp.CheckLevel checkLevel13 = compilerOptions0.checkGlobalNamesLevel;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy14 = com.google.javascript.jscomp.VariableRenamingPolicy.OFF;
        compilerOptions0.variableRenaming = variableRenamingPolicy14;
        boolean boolean16 = compilerOptions0.checkControlStructures;
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + checkLevel2 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel2.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
        org.junit.Assert.assertTrue("'" + checkLevel9 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel9.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + checkLevel13 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel13.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy14 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.OFF + "'", variableRenamingPolicy14.equals(com.google.javascript.jscomp.VariableRenamingPolicy.OFF));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test240");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.brokenClosureRequiresLevel;
        com.google.javascript.jscomp.CheckLevel checkLevel2 = com.google.javascript.jscomp.CheckLevel.WARNING;
        compilerOptions0.checkGlobalNamesLevel = checkLevel2;
        compilerOptions0.computeFunctionSideEffects = true;
        compilerOptions0.closurePass = false;
        com.google.javascript.jscomp.ErrorFormat errorFormat8 = compilerOptions0.errorFormat;
        compilerOptions0.prettyPrint = false;
        com.google.javascript.jscomp.CheckLevel checkLevel11 = com.google.javascript.jscomp.CheckLevel.ERROR;
        compilerOptions0.reportMissingOverride = checkLevel11;
        java.lang.String str13 = compilerOptions0.sourceMapOutputPath;
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + checkLevel2 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel2.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
        org.junit.Assert.assertNotNull(errorFormat8);
        org.junit.Assert.assertTrue("'" + checkLevel11 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel11.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNull(str13);
    }

//    @Test
//    public void test241() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test241");
//        com.google.javascript.jscomp.ErrorFormat errorFormat0 = com.google.javascript.jscomp.ErrorFormat.SINGLELINE;
//        java.io.PrintStream printStream1 = null;
//        com.google.javascript.jscomp.Compiler compiler2 = new com.google.javascript.jscomp.Compiler(printStream1);
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile4 = com.google.javascript.jscomp.JSSourceFile.fromFile("Not declared as a constructor");
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile6 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
//        com.google.javascript.jscomp.CompilerInput compilerInput7 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile6);
//        com.google.javascript.jscomp.CompilerInput compilerInput10 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput7, "hi!", false);
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile12 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
//        compilerInput7.setSourceFile((com.google.javascript.jscomp.SourceFile) jSSourceFile12);
//        java.lang.String str14 = jSSourceFile12.toString();
//        com.google.javascript.jscomp.CompilerOptions compilerOptions15 = new com.google.javascript.jscomp.CompilerOptions();
//        boolean boolean16 = compilerOptions15.aliasAllStrings;
//        compilerOptions15.setGenerateExports(true);
//        com.google.javascript.jscomp.Result result19 = compiler2.compile(jSSourceFile4, jSSourceFile12, compilerOptions15);
//        com.google.javascript.jscomp.MessageFormatter messageFormatter21 = errorFormat0.toFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler2, false);
//        compiler2.optimize();
//        com.google.javascript.rhino.Node node28 = com.google.javascript.rhino.Node.newString((int) (short) 0, "hi!", 100, (-2));
//        com.google.javascript.jscomp.DiagnosticType diagnosticType29 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
//        java.lang.String[] strArray30 = com.google.javascript.rhino.ScriptRuntime.emptyStrings;
//        com.google.javascript.jscomp.JSError jSError31 = com.google.javascript.jscomp.JSError.make("", node28, diagnosticType29, strArray30);
//        try {
//            compiler2.report(jSError31);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(errorFormat0);
//        org.junit.Assert.assertNotNull(jSSourceFile4);
//        org.junit.Assert.assertNotNull(jSSourceFile6);
//        org.junit.Assert.assertNotNull(jSSourceFile12);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertNotNull(result19);
//        org.junit.Assert.assertNotNull(messageFormatter21);
//        org.junit.Assert.assertNotNull(node28);
//        org.junit.Assert.assertNotNull(diagnosticType29);
//        org.junit.Assert.assertNotNull(strArray30);
//        org.junit.Assert.assertNotNull(jSError31);
//    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test242");
        int int0 = com.google.javascript.rhino.Node.POST_FLAG;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test243");
        com.google.javascript.jscomp.AbstractCompiler abstractCompiler0 = null;
        com.google.javascript.jscomp.NodeTraversal.Callback callback1 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal2 = new com.google.javascript.jscomp.NodeTraversal(abstractCompiler0, callback1);
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray14 = new com.google.javascript.rhino.Node[] { node5, node7, node9, node11, node13 };
        com.google.javascript.rhino.Node node15 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray14);
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node18 = node15.copyInformationFrom(node17);
        com.google.javascript.rhino.Node node19 = node17.getLastSibling();
        com.google.javascript.jscomp.CompilerOptions compilerOptions20 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel21 = compilerOptions20.brokenClosureRequiresLevel;
        com.google.javascript.jscomp.CheckLevel checkLevel22 = com.google.javascript.jscomp.CheckLevel.WARNING;
        compilerOptions20.checkGlobalNamesLevel = checkLevel22;
        compilerOptions20.computeFunctionSideEffects = true;
        com.google.javascript.jscomp.CheckLevel checkLevel26 = compilerOptions20.checkGlobalThisLevel;
        com.google.javascript.jscomp.DiagnosticType diagnosticType27 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        com.google.javascript.rhino.Node node33 = com.google.javascript.rhino.Node.newString((int) (short) 0, "hi!", 100, (-2));
        com.google.javascript.jscomp.DiagnosticType diagnosticType34 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray35 = com.google.javascript.rhino.ScriptRuntime.emptyStrings;
        com.google.javascript.jscomp.JSError jSError36 = com.google.javascript.jscomp.JSError.make("", node33, diagnosticType34, strArray35);
        com.google.javascript.jscomp.JSError jSError37 = nodeTraversal2.makeError(node19, checkLevel26, diagnosticType27, strArray35);
        try {
            com.google.javascript.rhino.Node node39 = node19.getChildAtIndex(10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(nodeArray14);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertTrue("'" + checkLevel21 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel21.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + checkLevel22 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel22.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
        org.junit.Assert.assertTrue("'" + checkLevel26 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel26.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(diagnosticType27);
        org.junit.Assert.assertNotNull(node33);
        org.junit.Assert.assertNotNull(diagnosticType34);
        org.junit.Assert.assertNotNull(strArray35);
        org.junit.Assert.assertNotNull(jSError36);
        org.junit.Assert.assertNotNull(jSError37);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test244");
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray11 = new com.google.javascript.rhino.Node[] { node2, node4, node6, node8, node10 };
        com.google.javascript.rhino.Node node12 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray11);
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node15 = node12.copyInformationFrom(node14);
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.Node.newNumber(100.0d, 4095, 9);
        node15.addChildToBack(node19);
        boolean boolean21 = node19.isVarArgs();
        java.lang.String str22 = node19.getQualifiedName();
        node19.setCharno(2);
        int int25 = node19.getSideEffectFlags();
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(nodeArray11);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNull(str22);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test245");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.checkDuplicateMessages = false;
        boolean boolean3 = compilerOptions0.inlineAnonymousFunctionExpressions;
        compilerOptions0.recordFunctionInformation = true;
        boolean boolean6 = compilerOptions0.checkCaja;
        java.util.Set<java.lang.String> strSet7 = compilerOptions0.stripNamePrefixes;
        boolean boolean8 = compilerOptions0.inlineFunctions;
        compilerOptions0.checkDuplicateMessages = false;
        com.google.javascript.jscomp.CodingConvention codingConvention11 = compilerOptions0.getCodingConvention();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(strSet7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNull(codingConvention11);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test246");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile1 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.CompilerInput compilerInput2 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile1);
        com.google.javascript.jscomp.CompilerInput compilerInput5 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput2, "hi!", false);
        com.google.javascript.jscomp.CompilerInput compilerInput7 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput2, true);
        java.lang.String str9 = compilerInput7.getLine(7);
        com.google.javascript.jscomp.Compiler compiler10 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile12 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.CompilerInput compilerInput13 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile12);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile15 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.CompilerInput compilerInput16 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile15);
        com.google.javascript.jscomp.CompilerInput compilerInput19 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput16, "hi!", false);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile21 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        compilerInput16.setSourceFile((com.google.javascript.jscomp.SourceFile) jSSourceFile21);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile24 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray25 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile12, jSSourceFile21, jSSourceFile24 };
        java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList26 = new java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile>();
        boolean boolean27 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList26, jSSourceFileArray25);
        com.google.javascript.jscomp.JSModule[] jSModuleArray28 = new com.google.javascript.jscomp.JSModule[] {};
        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList29 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
        boolean boolean30 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList29, jSModuleArray28);
        com.google.javascript.jscomp.CompilerOptions compilerOptions31 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions31.checkDuplicateMessages = false;
        boolean boolean34 = compilerOptions31.inlineAnonymousFunctionExpressions;
        compilerOptions31.crossModuleMethodMotion = true;
        com.google.javascript.jscomp.Result result37 = compiler10.compileModules((java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList26, (java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList29, compilerOptions31);
        com.google.javascript.jscomp.ErrorManager errorManager38 = compiler10.getErrorManager();
        com.google.javascript.jscomp.Compiler compiler39 = new com.google.javascript.jscomp.Compiler(errorManager38);
        compilerInput7.setErrorManager(errorManager38);
        org.junit.Assert.assertNotNull(jSSourceFile1);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertNotNull(jSSourceFile12);
        org.junit.Assert.assertNotNull(jSSourceFile15);
        org.junit.Assert.assertNotNull(jSSourceFile21);
        org.junit.Assert.assertNotNull(jSSourceFile24);
        org.junit.Assert.assertNotNull(jSSourceFileArray25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertNotNull(jSModuleArray28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(result37);
        org.junit.Assert.assertNotNull(errorManager38);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test247");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray13 = new com.google.javascript.rhino.Node[] { node4, node6, node8, node10, node12 };
        com.google.javascript.rhino.Node node14 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray13);
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node21 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray26 = new com.google.javascript.rhino.Node[] { node17, node19, node21, node23, node25 };
        com.google.javascript.rhino.Node node27 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray26);
        com.google.javascript.rhino.Node node28 = new com.google.javascript.rhino.Node(100, node14, node27);
        boolean boolean29 = closureCodingConvention0.isVarArgsParameter(node28);
        java.lang.String str30 = closureCodingConvention0.getExportPropertyFunction();
        boolean boolean33 = closureCodingConvention0.isExported("goog.exportProperty", false);
        com.google.javascript.rhino.Node node37 = com.google.javascript.rhino.Node.newNumber(100.0d, 4095, 9);
        java.util.Set<java.lang.String> strSet38 = node37.getDirectives();
        boolean boolean39 = closureCodingConvention0.isVarArgsParameter(node37);
        com.google.javascript.rhino.Node node42 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node44 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node46 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node48 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node50 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray51 = new com.google.javascript.rhino.Node[] { node42, node44, node46, node48, node50 };
        com.google.javascript.rhino.Node node52 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray51);
        com.google.javascript.rhino.Node node53 = node52.getNext();
        com.google.javascript.rhino.Node node57 = com.google.javascript.rhino.Node.newNumber(100.0d, 4095, 9);
        java.lang.String str58 = closureCodingConvention0.extractClassNameIfRequire(node52, node57);
        boolean boolean60 = closureCodingConvention0.isValidEnumKey("error reporter");
        com.google.javascript.rhino.jstype.FunctionType functionType61 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType62 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType63 = null;
        closureCodingConvention0.applySubclassRelationship(functionType61, functionType62, subclassType63);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(nodeArray13);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNotNull(nodeArray26);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "goog.exportProperty" + "'", str30.equals("goog.exportProperty"));
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(node37);
        org.junit.Assert.assertNull(strSet38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(node42);
        org.junit.Assert.assertNotNull(node44);
        org.junit.Assert.assertNotNull(node46);
        org.junit.Assert.assertNotNull(node48);
        org.junit.Assert.assertNotNull(node50);
        org.junit.Assert.assertNotNull(nodeArray51);
        org.junit.Assert.assertNull(node53);
        org.junit.Assert.assertNotNull(node57);
        org.junit.Assert.assertNull(str58);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + true + "'", boolean60 == true);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test248");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.checkDuplicateMessages = false;
        boolean boolean3 = compilerOptions0.inlineAnonymousFunctionExpressions;
        compilerOptions0.recordFunctionInformation = true;
        boolean boolean6 = compilerOptions0.checkCaja;
        compilerOptions0.aliasableGlobals = "EOF 0";
        com.google.javascript.jscomp.CheckLevel checkLevel9 = com.google.javascript.jscomp.CheckLevel.OFF;
        compilerOptions0.reportUnknownTypes = checkLevel9;
        com.google.javascript.jscomp.CompilerOptions compilerOptions11 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions11.checkDuplicateMessages = false;
        boolean boolean14 = compilerOptions11.inlineAnonymousFunctionExpressions;
        compilerOptions11.recordFunctionInformation = true;
        boolean boolean17 = compilerOptions11.checkCaja;
        java.util.Set<java.lang.String> strSet18 = compilerOptions11.stripNamePrefixes;
        compilerOptions0.setIdGenerators(strSet18);
        com.google.javascript.jscomp.CheckLevel checkLevel20 = compilerOptions0.checkUnreachableCode;
        compilerOptions0.groupVariableDeclarations = false;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + checkLevel9 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel9.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(strSet18);
        org.junit.Assert.assertTrue("'" + checkLevel20 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel20.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test249");
        com.google.javascript.rhino.EcmaError ecmaError1 = com.google.javascript.rhino.ScriptRuntime.typeError("");
        java.lang.String str2 = ecmaError1.getSourceName();
        java.lang.String str3 = ecmaError1.getErrorMessage();
        com.google.javascript.jscomp.DiagnosticType[] diagnosticTypeArray4 = new com.google.javascript.jscomp.DiagnosticType[] {};
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup5 = new com.google.javascript.jscomp.DiagnosticGroup(diagnosticTypeArray4);
        com.google.javascript.jscomp.DiagnosticGroups.AMBIGUOUS_FUNCTION_DECL = diagnosticGroup5;
        com.google.javascript.jscomp.CompilerOptions compilerOptions7 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions7.checkDuplicateMessages = false;
        boolean boolean10 = compilerOptions7.inlineAnonymousFunctionExpressions;
        compilerOptions7.recordFunctionInformation = true;
        boolean boolean13 = compilerOptions7.checkCaja;
        compilerOptions7.aliasableGlobals = "EOF 0";
        com.google.javascript.jscomp.CheckLevel checkLevel16 = com.google.javascript.jscomp.CheckLevel.OFF;
        compilerOptions7.reportUnknownTypes = checkLevel16;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard18 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup5, checkLevel16);
        java.lang.RuntimeException runtimeException19 = com.google.javascript.rhino.ScriptRuntime.notFunctionError((java.lang.Object) ecmaError1, (java.lang.Object) diagnosticGroup5);
        java.lang.String str20 = ecmaError1.getScriptStackTrace();
        org.junit.Assert.assertNotNull(ecmaError1);
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
        org.junit.Assert.assertNotNull(diagnosticTypeArray4);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + checkLevel16 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel16.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(runtimeException19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "<No stack trace available>" + "'", str20.equals("<No stack trace available>"));
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test250");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray12 = new com.google.javascript.rhino.Node[] { node3, node5, node7, node9, node11 };
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray12);
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node16 = node13.copyInformationFrom(node15);
        com.google.javascript.rhino.Node node17 = node13.getParent();
        com.google.javascript.rhino.Node node18 = new com.google.javascript.rhino.Node((int) (short) -1, node13);
        com.google.javascript.rhino.jstype.JSType jSType19 = null;
        node18.setJSType(jSType19);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertNotNull(nodeArray12);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertNull(node17);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test251");
        com.google.javascript.jscomp.Compiler.CodeBuilder codeBuilder0 = new com.google.javascript.jscomp.Compiler.CodeBuilder();
        java.lang.String str1 = codeBuilder0.toString();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test252");
        int int0 = com.google.javascript.rhino.Node.BOTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test253");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.brokenClosureRequiresLevel;
        com.google.javascript.jscomp.CheckLevel checkLevel2 = com.google.javascript.jscomp.CheckLevel.WARNING;
        compilerOptions0.checkGlobalNamesLevel = checkLevel2;
        compilerOptions0.computeFunctionSideEffects = true;
        boolean boolean6 = compilerOptions0.removeDeadCode;
        com.google.javascript.jscomp.SourceMap.DetailLevel detailLevel7 = null;
        compilerOptions0.sourceMapDetailLevel = detailLevel7;
        boolean boolean9 = compilerOptions0.prettyPrint;
        boolean boolean10 = compilerOptions0.exportTestFunctions;
        compilerOptions0.removeTryCatchFinally = true;
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + checkLevel2 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel2.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test254");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.NodeTraversal.Callback callback1 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal2 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler0, callback1);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile4 = com.google.javascript.jscomp.JSSourceFile.fromFile("Not declared as a constructor");
        java.io.PrintStream printStream5 = null;
        com.google.javascript.jscomp.Compiler compiler6 = new com.google.javascript.jscomp.Compiler(printStream5);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile8 = com.google.javascript.jscomp.JSSourceFile.fromFile("Not declared as a constructor");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile10 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.CompilerInput compilerInput11 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile10);
        com.google.javascript.jscomp.CompilerInput compilerInput14 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput11, "hi!", false);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile16 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        compilerInput11.setSourceFile((com.google.javascript.jscomp.SourceFile) jSSourceFile16);
        java.lang.String str18 = jSSourceFile16.toString();
        com.google.javascript.jscomp.CompilerOptions compilerOptions19 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean20 = compilerOptions19.aliasAllStrings;
        compilerOptions19.setGenerateExports(true);
        com.google.javascript.jscomp.Result result23 = compiler6.compile(jSSourceFile8, jSSourceFile16, compilerOptions19);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile25 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.CompilerInput compilerInput26 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile25);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile28 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.CompilerInput compilerInput29 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile28);
        com.google.javascript.jscomp.CompilerInput compilerInput32 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput29, "hi!", false);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile34 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        compilerInput29.setSourceFile((com.google.javascript.jscomp.SourceFile) jSSourceFile34);
        java.lang.String str36 = jSSourceFile34.toString();
        java.io.PrintStream printStream37 = null;
        com.google.javascript.jscomp.Compiler compiler38 = new com.google.javascript.jscomp.Compiler(printStream37);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile40 = com.google.javascript.jscomp.JSSourceFile.fromFile("Not declared as a constructor");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile42 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.CompilerInput compilerInput43 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile42);
        com.google.javascript.jscomp.CompilerInput compilerInput46 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput43, "hi!", false);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile48 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        compilerInput43.setSourceFile((com.google.javascript.jscomp.SourceFile) jSSourceFile48);
        java.lang.String str50 = jSSourceFile48.toString();
        com.google.javascript.jscomp.CompilerOptions compilerOptions51 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean52 = compilerOptions51.aliasAllStrings;
        compilerOptions51.setGenerateExports(true);
        com.google.javascript.jscomp.Result result55 = compiler38.compile(jSSourceFile40, jSSourceFile48, compilerOptions51);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile57 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.CompilerInput compilerInput58 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile57);
        com.google.javascript.jscomp.Region region60 = jSSourceFile57.getRegion(24);
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray61 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile4, jSSourceFile16, jSSourceFile25, jSSourceFile34, jSSourceFile48, jSSourceFile57 };
        java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList62 = new java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile>();
        boolean boolean63 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList62, jSSourceFileArray61);
        com.google.javascript.jscomp.JSModule[] jSModuleArray64 = new com.google.javascript.jscomp.JSModule[] {};
        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList65 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
        boolean boolean66 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList65, jSModuleArray64);
        com.google.javascript.jscomp.CompilerOptions compilerOptions67 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel68 = compilerOptions67.brokenClosureRequiresLevel;
        com.google.javascript.jscomp.CheckLevel checkLevel69 = com.google.javascript.jscomp.CheckLevel.WARNING;
        compilerOptions67.checkGlobalNamesLevel = checkLevel69;
        compilerOptions67.computeFunctionSideEffects = true;
        boolean boolean73 = compilerOptions67.removeDeadCode;
        com.google.javascript.jscomp.CompilerOptions.TweakProcessing tweakProcessing74 = compilerOptions67.getTweakProcessing();
        com.google.javascript.jscomp.Result result75 = compiler0.compileModules((java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList62, (java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList65, compilerOptions67);
        com.google.javascript.jscomp.CodingConvention codingConvention76 = compiler0.getCodingConvention();
        com.google.javascript.rhino.Node node80 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode(codingConvention76, "com.google.javascript.rhino.EcmaError: TypeError: ", 41, (-1));
        com.google.javascript.rhino.Node node86 = com.google.javascript.rhino.Node.newString((int) (short) 0, "hi!", 100, (-2));
        com.google.javascript.rhino.Node node87 = new com.google.javascript.rhino.Node(10, node86);
        com.google.javascript.rhino.Node node89 = com.google.javascript.rhino.Node.newString("DiagnosticGroup<strictModuleDepCheck>");
        boolean boolean90 = node86.isEquivalentToTyped(node89);
        node80.addChildToBack(node89);
        org.junit.Assert.assertNotNull(jSSourceFile4);
        org.junit.Assert.assertNotNull(jSSourceFile8);
        org.junit.Assert.assertNotNull(jSSourceFile10);
        org.junit.Assert.assertNotNull(jSSourceFile16);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "" + "'", str18.equals(""));
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(result23);
        org.junit.Assert.assertNotNull(jSSourceFile25);
        org.junit.Assert.assertNotNull(jSSourceFile28);
        org.junit.Assert.assertNotNull(jSSourceFile34);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "" + "'", str36.equals(""));
        org.junit.Assert.assertNotNull(jSSourceFile40);
        org.junit.Assert.assertNotNull(jSSourceFile42);
        org.junit.Assert.assertNotNull(jSSourceFile48);
        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "" + "'", str50.equals(""));
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertNotNull(result55);
        org.junit.Assert.assertNotNull(jSSourceFile57);
        org.junit.Assert.assertNull(region60);
        org.junit.Assert.assertNotNull(jSSourceFileArray61);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + true + "'", boolean63 == true);
        org.junit.Assert.assertNotNull(jSModuleArray64);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertTrue("'" + checkLevel68 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel68.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + checkLevel69 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel69.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
        org.junit.Assert.assertTrue("'" + tweakProcessing74 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TweakProcessing.OFF + "'", tweakProcessing74.equals(com.google.javascript.jscomp.CompilerOptions.TweakProcessing.OFF));
        org.junit.Assert.assertNotNull(result75);
        org.junit.Assert.assertNotNull(codingConvention76);
        org.junit.Assert.assertNotNull(node80);
        org.junit.Assert.assertNotNull(node86);
        org.junit.Assert.assertNotNull(node89);
        org.junit.Assert.assertTrue("'" + boolean90 + "' != '" + false + "'", boolean90 == false);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test255");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.brokenClosureRequiresLevel;
        java.util.Set<java.lang.String> strSet2 = compilerOptions0.aliasableStrings;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy3 = com.google.javascript.jscomp.VariableRenamingPolicy.OFF;
        compilerOptions0.variableRenaming = variableRenamingPolicy3;
        boolean boolean5 = compilerOptions0.optimizeArgumentsArray;
        com.google.javascript.jscomp.ErrorFormat errorFormat6 = compilerOptions0.errorFormat;
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(strSet2);
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy3 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.OFF + "'", variableRenamingPolicy3.equals(com.google.javascript.jscomp.VariableRenamingPolicy.OFF));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(errorFormat6);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test256");
        int int0 = com.google.javascript.rhino.Node.NON_SPECIALCALL;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test257");
        try {
            com.google.javascript.rhino.EcmaError ecmaError2 = com.google.javascript.rhino.ScriptRuntime.typeError1("", ": WARNING - {0}\n");
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property ");
        } catch (java.lang.RuntimeException e) {
        }
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test258");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.checkDuplicateMessages = false;
        boolean boolean3 = compilerOptions0.inlineAnonymousFunctionExpressions;
        compilerOptions0.recordFunctionInformation = true;
        boolean boolean6 = compilerOptions0.checkCaja;
        compilerOptions0.aliasableGlobals = "EOF 0";
        boolean boolean9 = compilerOptions0.removeEmptyFunctions;
        boolean boolean10 = compilerOptions0.deadAssignmentElimination;
        java.lang.String str11 = compilerOptions0.inputDelimiter;
        compilerOptions0.foldConstants = true;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "// Input %num%" + "'", str11.equals("// Input %num%"));
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test259");
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray11 = new com.google.javascript.rhino.Node[] { node2, node4, node6, node8, node10 };
        com.google.javascript.rhino.Node node12 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray11);
        boolean boolean13 = node12.isVarArgs();
        try {
            com.google.javascript.rhino.Node node14 = node12.detachFromParent();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(nodeArray11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test260");
        com.google.javascript.rhino.EcmaError ecmaError1 = com.google.javascript.rhino.ScriptRuntime.typeError("");
        java.lang.String str2 = ecmaError1.details();
        java.lang.String str3 = ecmaError1.getName();
        java.lang.String str4 = ecmaError1.sourceName();
        com.google.javascript.rhino.EcmaError ecmaError7 = com.google.javascript.rhino.ScriptRuntime.constructError("", "language version");
        ecmaError7.initColumnNumber((int) (byte) 10);
        ecmaError1.addSuppressed((java.lang.Throwable) ecmaError7);
        java.lang.String str11 = ecmaError7.details();
        org.junit.Assert.assertNotNull(ecmaError1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "TypeError: " + "'", str2.equals("TypeError: "));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "TypeError" + "'", str3.equals("TypeError"));
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNotNull(ecmaError7);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + ": language version" + "'", str11.equals(": language version"));
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test261");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.brokenClosureRequiresLevel;
        com.google.javascript.jscomp.CheckLevel checkLevel2 = com.google.javascript.jscomp.CheckLevel.WARNING;
        compilerOptions0.checkGlobalNamesLevel = checkLevel2;
        compilerOptions0.computeFunctionSideEffects = true;
        boolean boolean6 = compilerOptions0.removeDeadCode;
        compilerOptions0.setManageClosureDependencies(false);
        compilerOptions0.nameReferenceGraphPath = "";
        java.lang.String str11 = compilerOptions0.syntheticBlockStartMarker;
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup12 = com.google.javascript.jscomp.DiagnosticGroups.STRICT_MODULE_DEP_CHECK;
        java.lang.String str13 = diagnosticGroup12.toString();
        com.google.javascript.jscomp.CheckLevel checkLevel14 = com.google.javascript.jscomp.CheckLevel.WARNING;
        compilerOptions0.setWarningLevel(diagnosticGroup12, checkLevel14);
        compilerOptions0.lineBreak = false;
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + checkLevel2 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel2.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(str11);
        org.junit.Assert.assertNotNull(diagnosticGroup12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "DiagnosticGroup<strictModuleDepCheck>" + "'", str13.equals("DiagnosticGroup<strictModuleDepCheck>"));
        org.junit.Assert.assertTrue("'" + checkLevel14 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel14.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test262");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.Compiler compiler2 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile4 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.CompilerInput compilerInput5 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile4);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile7 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.CompilerInput compilerInput8 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile7);
        com.google.javascript.jscomp.CompilerInput compilerInput11 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput8, "hi!", false);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile13 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        compilerInput8.setSourceFile((com.google.javascript.jscomp.SourceFile) jSSourceFile13);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile16 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray17 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile4, jSSourceFile13, jSSourceFile16 };
        java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList18 = new java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile>();
        boolean boolean19 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList18, jSSourceFileArray17);
        com.google.javascript.jscomp.JSModule[] jSModuleArray20 = new com.google.javascript.jscomp.JSModule[] {};
        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList21 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
        boolean boolean22 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList21, jSModuleArray20);
        com.google.javascript.jscomp.CompilerOptions compilerOptions23 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions23.checkDuplicateMessages = false;
        boolean boolean26 = compilerOptions23.inlineAnonymousFunctionExpressions;
        compilerOptions23.crossModuleMethodMotion = true;
        com.google.javascript.jscomp.Result result29 = compiler2.compileModules((java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList18, (java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList21, compilerOptions23);
        com.google.javascript.jscomp.Compiler compiler30 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile32 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.CompilerInput compilerInput33 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile32);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile35 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.CompilerInput compilerInput36 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile35);
        com.google.javascript.jscomp.CompilerInput compilerInput39 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput36, "hi!", false);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile41 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        compilerInput36.setSourceFile((com.google.javascript.jscomp.SourceFile) jSSourceFile41);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile44 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray45 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile32, jSSourceFile41, jSSourceFile44 };
        java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList46 = new java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile>();
        boolean boolean47 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList46, jSSourceFileArray45);
        com.google.javascript.jscomp.JSModule[] jSModuleArray48 = new com.google.javascript.jscomp.JSModule[] {};
        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList49 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
        boolean boolean50 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList49, jSModuleArray48);
        com.google.javascript.jscomp.CompilerOptions compilerOptions51 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions51.checkDuplicateMessages = false;
        boolean boolean54 = compilerOptions51.inlineAnonymousFunctionExpressions;
        compilerOptions51.crossModuleMethodMotion = true;
        com.google.javascript.jscomp.Result result57 = compiler30.compileModules((java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList46, (java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList49, compilerOptions51);
        com.google.javascript.jscomp.CompilerOptions compilerOptions58 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel59 = compilerOptions58.brokenClosureRequiresLevel;
        java.util.Set<java.lang.String> strSet60 = compilerOptions58.aliasableStrings;
        boolean boolean61 = compilerOptions58.decomposeExpressions;
        java.util.Set<java.lang.String> strSet62 = compilerOptions58.stripNamePrefixes;
        com.google.javascript.jscomp.Result result63 = compiler1.compile((java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList18, (java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList46, compilerOptions58);
        com.google.javascript.jscomp.JSError[] jSErrorArray64 = compiler1.getWarnings();
        compiler1.rebuildInputsFromModules();
        org.junit.Assert.assertNotNull(jSSourceFile4);
        org.junit.Assert.assertNotNull(jSSourceFile7);
        org.junit.Assert.assertNotNull(jSSourceFile13);
        org.junit.Assert.assertNotNull(jSSourceFile16);
        org.junit.Assert.assertNotNull(jSSourceFileArray17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(jSModuleArray20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(result29);
        org.junit.Assert.assertNotNull(jSSourceFile32);
        org.junit.Assert.assertNotNull(jSSourceFile35);
        org.junit.Assert.assertNotNull(jSSourceFile41);
        org.junit.Assert.assertNotNull(jSSourceFile44);
        org.junit.Assert.assertNotNull(jSSourceFileArray45);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
        org.junit.Assert.assertNotNull(jSModuleArray48);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNotNull(result57);
        org.junit.Assert.assertTrue("'" + checkLevel59 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel59.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(strSet60);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertNotNull(strSet62);
        org.junit.Assert.assertNotNull(result63);
        org.junit.Assert.assertNotNull(jSErrorArray64);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test263");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString((int) (short) 0, "hi!", 100, (-2));
        java.lang.Appendable appendable5 = null;
        try {
            node4.appendStringTree(appendable5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node4);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test264");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile5 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.CompilerInput compilerInput6 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile5);
        com.google.javascript.jscomp.CompilerInput compilerInput9 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput6, "hi!", false);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile11 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        compilerInput6.setSourceFile((com.google.javascript.jscomp.SourceFile) jSSourceFile11);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile14 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray15 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile2, jSSourceFile11, jSSourceFile14 };
        java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList16 = new java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile>();
        boolean boolean17 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList16, jSSourceFileArray15);
        com.google.javascript.jscomp.JSModule[] jSModuleArray18 = new com.google.javascript.jscomp.JSModule[] {};
        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList19 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
        boolean boolean20 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList19, jSModuleArray18);
        com.google.javascript.jscomp.CompilerOptions compilerOptions21 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions21.checkDuplicateMessages = false;
        boolean boolean24 = compilerOptions21.inlineAnonymousFunctionExpressions;
        compilerOptions21.crossModuleMethodMotion = true;
        com.google.javascript.jscomp.Result result27 = compiler0.compileModules((java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList16, (java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList19, compilerOptions21);
        boolean boolean28 = compiler0.acceptEcmaScript5();
        com.google.javascript.jscomp.Region region31 = compiler0.getSourceRegion("error reporter", 34);
        com.google.javascript.jscomp.JSModule jSModule32 = null;
        try {
            java.lang.String str33 = compiler0.toSource(jSModule32);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: java.lang.NullPointerException");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile2);
        org.junit.Assert.assertNotNull(jSSourceFile5);
        org.junit.Assert.assertNotNull(jSSourceFile11);
        org.junit.Assert.assertNotNull(jSSourceFile14);
        org.junit.Assert.assertNotNull(jSSourceFileArray15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(jSModuleArray18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(result27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNull(region31);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test265");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile3 = com.google.javascript.jscomp.JSSourceFile.fromFile("Not declared as a constructor");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile5 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.CompilerInput compilerInput6 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile5);
        com.google.javascript.jscomp.CompilerInput compilerInput9 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput6, "hi!", false);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile11 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        compilerInput6.setSourceFile((com.google.javascript.jscomp.SourceFile) jSSourceFile11);
        java.lang.String str13 = jSSourceFile11.toString();
        com.google.javascript.jscomp.CompilerOptions compilerOptions14 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean15 = compilerOptions14.aliasAllStrings;
        compilerOptions14.setGenerateExports(true);
        com.google.javascript.jscomp.Result result18 = compiler1.compile(jSSourceFile3, jSSourceFile11, compilerOptions14);
        compilerOptions14.inlineLocalFunctions = true;
        compilerOptions14.devirtualizePrototypeMethods = true;
        com.google.javascript.jscomp.CheckLevel checkLevel23 = compilerOptions14.checkMethods;
        org.junit.Assert.assertNotNull(jSSourceFile3);
        org.junit.Assert.assertNotNull(jSSourceFile5);
        org.junit.Assert.assertNotNull(jSSourceFile11);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(result18);
        org.junit.Assert.assertTrue("'" + checkLevel23 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel23.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test266");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile3 = com.google.javascript.jscomp.JSSourceFile.fromFile("Not declared as a constructor");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile5 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.CompilerInput compilerInput6 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile5);
        com.google.javascript.jscomp.CompilerInput compilerInput9 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput6, "hi!", false);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile11 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        compilerInput6.setSourceFile((com.google.javascript.jscomp.SourceFile) jSSourceFile11);
        java.lang.String str13 = jSSourceFile11.toString();
        com.google.javascript.jscomp.CompilerOptions compilerOptions14 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean15 = compilerOptions14.aliasAllStrings;
        compilerOptions14.setGenerateExports(true);
        com.google.javascript.jscomp.Result result18 = compiler1.compile(jSSourceFile3, jSSourceFile11, compilerOptions14);
        compilerOptions14.syntheticBlockEndMarker = "Not declared as a type name";
        compilerOptions14.generatePseudoNames = true;
        byte[] byteArray23 = compilerOptions14.inputVariableMapSerialized;
        compilerOptions14.coalesceVariableNames = true;
        org.junit.Assert.assertNotNull(jSSourceFile3);
        org.junit.Assert.assertNotNull(jSSourceFile5);
        org.junit.Assert.assertNotNull(jSSourceFile11);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(result18);
        org.junit.Assert.assertNull(byteArray23);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test267");
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newString((int) (short) 0, "hi!", 100, (-2));
        com.google.javascript.jscomp.DiagnosticType diagnosticType6 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray7 = com.google.javascript.rhino.ScriptRuntime.emptyStrings;
        com.google.javascript.jscomp.JSError jSError8 = com.google.javascript.jscomp.JSError.make("", node5, diagnosticType6, strArray7);
        java.lang.String str9 = jSError8.description;
        int int10 = jSError8.getCharno();
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNotNull(diagnosticType6);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertNotNull(jSError8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "{0}" + "'", str9.equals("{0}"));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test268");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.brokenClosureRequiresLevel;
        boolean boolean2 = compilerOptions0.collapseAnonymousFunctions;
        compilerOptions0.reserveRawExports = true;
        boolean boolean5 = compilerOptions0.checkTypedPropertyCalls;
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test269");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.brokenClosureRequiresLevel;
        com.google.javascript.jscomp.CheckLevel checkLevel2 = com.google.javascript.jscomp.CheckLevel.WARNING;
        compilerOptions0.checkGlobalNamesLevel = checkLevel2;
        compilerOptions0.computeFunctionSideEffects = true;
        compilerOptions0.setDefineToStringLiteral("", "Unknown class name");
        compilerOptions0.checkTypedPropertyCalls = true;
        com.google.javascript.jscomp.ErrorFormat errorFormat11 = compilerOptions0.errorFormat;
        boolean boolean12 = compilerOptions0.gatherCssNames;
        compilerOptions0.tightenTypes = false;
        com.google.javascript.jscomp.CheckLevel checkLevel15 = compilerOptions0.brokenClosureRequiresLevel;
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + checkLevel2 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel2.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
        org.junit.Assert.assertNotNull(errorFormat11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + checkLevel15 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel15.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test270");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray13 = new com.google.javascript.rhino.Node[] { node4, node6, node8, node10, node12 };
        com.google.javascript.rhino.Node node14 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray13);
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node21 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray26 = new com.google.javascript.rhino.Node[] { node17, node19, node21, node23, node25 };
        com.google.javascript.rhino.Node node27 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray26);
        com.google.javascript.rhino.Node node28 = new com.google.javascript.rhino.Node(100, node14, node27);
        boolean boolean29 = closureCodingConvention0.isVarArgsParameter(node28);
        java.lang.String str30 = closureCodingConvention0.getExportPropertyFunction();
        boolean boolean33 = closureCodingConvention0.isExported("goog.exportProperty", false);
        com.google.javascript.rhino.Node node37 = com.google.javascript.rhino.Node.newNumber(100.0d, 4095, 9);
        java.util.Set<java.lang.String> strSet38 = node37.getDirectives();
        boolean boolean39 = closureCodingConvention0.isVarArgsParameter(node37);
        com.google.javascript.rhino.Node node42 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node44 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node46 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node48 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node50 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray51 = new com.google.javascript.rhino.Node[] { node42, node44, node46, node48, node50 };
        com.google.javascript.rhino.Node node52 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray51);
        int int53 = node52.getSideEffectFlags();
        node37.addChildrenToFront(node52);
        com.google.javascript.rhino.Node node55 = node52.cloneNode();
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder56 = node55.getJsDocBuilderForNode();
        int int57 = node55.getType();
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(nodeArray13);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNotNull(nodeArray26);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "goog.exportProperty" + "'", str30.equals("goog.exportProperty"));
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(node37);
        org.junit.Assert.assertNull(strSet38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(node42);
        org.junit.Assert.assertNotNull(node44);
        org.junit.Assert.assertNotNull(node46);
        org.junit.Assert.assertNotNull(node48);
        org.junit.Assert.assertNotNull(node50);
        org.junit.Assert.assertNotNull(nodeArray51);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 0 + "'", int53 == 0);
        org.junit.Assert.assertNotNull(node55);
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder56);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 0 + "'", int57 == 0);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test271");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.brokenClosureRequiresLevel;
        com.google.javascript.jscomp.CheckLevel checkLevel2 = com.google.javascript.jscomp.CheckLevel.WARNING;
        compilerOptions0.checkGlobalNamesLevel = checkLevel2;
        compilerOptions0.computeFunctionSideEffects = true;
        boolean boolean6 = compilerOptions0.removeDeadCode;
        compilerOptions0.removeUnusedLocalVars = true;
        com.google.javascript.jscomp.CheckLevel checkLevel9 = compilerOptions0.checkGlobalNamesLevel;
        compilerOptions0.checkEs5Strict = false;
        compilerOptions0.convertToDottedProperties = true;
        boolean boolean14 = compilerOptions0.coalesceVariableNames;
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + checkLevel2 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel2.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + checkLevel9 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel9.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test272");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.brokenClosureRequiresLevel;
        java.util.Set<java.lang.String> strSet2 = compilerOptions0.aliasableStrings;
        boolean boolean3 = compilerOptions0.decomposeExpressions;
        java.util.Set<java.lang.String> strSet4 = compilerOptions0.stripNamePrefixes;
        boolean boolean5 = compilerOptions0.instrumentForCoverageOnly;
        com.google.javascript.jscomp.CheckLevel checkLevel6 = compilerOptions0.checkMissingReturn;
        compilerOptions0.labelRenaming = false;
        compilerOptions0.inlineLocalFunctions = true;
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy11 = compilerOptions0.propertyRenaming;
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(strSet2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(strSet4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + checkLevel6 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel6.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy11 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.OFF + "'", propertyRenamingPolicy11.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.OFF));
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test273");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.brokenClosureRequiresLevel;
        com.google.javascript.jscomp.CheckLevel checkLevel2 = com.google.javascript.jscomp.CheckLevel.WARNING;
        compilerOptions0.checkGlobalNamesLevel = checkLevel2;
        compilerOptions0.computeFunctionSideEffects = true;
        compilerOptions0.closurePass = false;
        com.google.javascript.jscomp.ErrorFormat errorFormat8 = compilerOptions0.errorFormat;
        compilerOptions0.prettyPrint = false;
        boolean boolean11 = compilerOptions0.rewriteFunctionExpressions;
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + checkLevel2 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel2.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
        org.junit.Assert.assertNotNull(errorFormat8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test274");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray13 = new com.google.javascript.rhino.Node[] { node4, node6, node8, node10, node12 };
        com.google.javascript.rhino.Node node14 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray13);
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node21 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray26 = new com.google.javascript.rhino.Node[] { node17, node19, node21, node23, node25 };
        com.google.javascript.rhino.Node node27 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray26);
        com.google.javascript.rhino.Node node28 = new com.google.javascript.rhino.Node(100, node14, node27);
        boolean boolean29 = closureCodingConvention0.isVarArgsParameter(node28);
        java.lang.String str30 = closureCodingConvention0.getExportPropertyFunction();
        boolean boolean33 = closureCodingConvention0.isExported("goog.exportProperty", false);
        com.google.javascript.rhino.Node node37 = com.google.javascript.rhino.Node.newNumber(100.0d, 4095, 9);
        java.util.Set<java.lang.String> strSet38 = node37.getDirectives();
        boolean boolean39 = closureCodingConvention0.isVarArgsParameter(node37);
        com.google.javascript.rhino.Node node42 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node44 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node46 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node48 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node50 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray51 = new com.google.javascript.rhino.Node[] { node42, node44, node46, node48, node50 };
        com.google.javascript.rhino.Node node52 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray51);
        com.google.javascript.rhino.Node node53 = node52.getNext();
        com.google.javascript.rhino.Node node57 = com.google.javascript.rhino.Node.newNumber(100.0d, 4095, 9);
        java.lang.String str58 = closureCodingConvention0.extractClassNameIfRequire(node52, node57);
        com.google.javascript.rhino.jstype.FunctionType functionType59 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType60 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType61 = null;
        closureCodingConvention0.applySubclassRelationship(functionType59, functionType60, subclassType61);
        java.lang.String str63 = closureCodingConvention0.getDelegateSuperclassName();
        boolean boolean65 = closureCodingConvention0.isSuperClassReference("Not declared as a type name");
        boolean boolean68 = closureCodingConvention0.isExported("JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of optimization iterations: {0}", false);
        boolean boolean70 = closureCodingConvention0.isConstantKey("DiagnosticGroup<goog.exportSymbol>");
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(nodeArray13);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNotNull(nodeArray26);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "goog.exportProperty" + "'", str30.equals("goog.exportProperty"));
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(node37);
        org.junit.Assert.assertNull(strSet38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(node42);
        org.junit.Assert.assertNotNull(node44);
        org.junit.Assert.assertNotNull(node46);
        org.junit.Assert.assertNotNull(node48);
        org.junit.Assert.assertNotNull(node50);
        org.junit.Assert.assertNotNull(nodeArray51);
        org.junit.Assert.assertNull(node53);
        org.junit.Assert.assertNotNull(node57);
        org.junit.Assert.assertNull(str58);
        org.junit.Assert.assertNull(str63);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test275");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.brokenClosureRequiresLevel;
        com.google.javascript.jscomp.CheckLevel checkLevel2 = com.google.javascript.jscomp.CheckLevel.WARNING;
        compilerOptions0.checkGlobalNamesLevel = checkLevel2;
        compilerOptions0.computeFunctionSideEffects = true;
        boolean boolean6 = compilerOptions0.removeDeadCode;
        com.google.javascript.jscomp.CompilerOptions.TweakProcessing tweakProcessing7 = compilerOptions0.getTweakProcessing();
        compilerOptions0.setRemoveClosureAsserts(true);
        com.google.javascript.jscomp.CompilerOptions compilerOptions10 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel11 = compilerOptions10.brokenClosureRequiresLevel;
        com.google.javascript.jscomp.CheckLevel checkLevel12 = com.google.javascript.jscomp.CheckLevel.WARNING;
        compilerOptions10.checkGlobalNamesLevel = checkLevel12;
        compilerOptions10.computeFunctionSideEffects = true;
        com.google.javascript.jscomp.CheckLevel checkLevel16 = compilerOptions10.checkGlobalThisLevel;
        compilerOptions0.checkUnreachableCode = checkLevel16;
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + checkLevel2 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel2.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + tweakProcessing7 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TweakProcessing.OFF + "'", tweakProcessing7.equals(com.google.javascript.jscomp.CompilerOptions.TweakProcessing.OFF));
        org.junit.Assert.assertTrue("'" + checkLevel11 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel11.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + checkLevel12 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel12.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
        org.junit.Assert.assertTrue("'" + checkLevel16 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel16.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

//    @Test
//    public void test276() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test276");
//        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.UNDEFINED_VARIABLES;
//        com.google.javascript.jscomp.DiagnosticGroups.VISIBILITY = diagnosticGroup0;
//        com.google.javascript.jscomp.DiagnosticGroups.CHECK_VARIABLES = diagnosticGroup0;
//        org.junit.Assert.assertNull(diagnosticGroup0);
//    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test277");
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray11 = new com.google.javascript.rhino.Node[] { node2, node4, node6, node8, node10 };
        com.google.javascript.rhino.Node node12 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray11);
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node15 = node12.copyInformationFrom(node14);
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.Node.newNumber(100.0d, 4095, 9);
        node15.addChildToBack(node19);
        boolean boolean21 = node19.isVarArgs();
        com.google.javascript.rhino.Node node22 = node19.getParent();
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(nodeArray11);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(node22);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test278");
        com.google.javascript.rhino.EcmaError ecmaError1 = com.google.javascript.rhino.ScriptRuntime.typeError("goog.exportProperty");
        int int2 = ecmaError1.getColumnNumber();
        java.io.FilenameFilter filenameFilter3 = null;
        java.lang.String str4 = ecmaError1.getScriptStackTrace(filenameFilter3);
        org.junit.Assert.assertNotNull(ecmaError1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "<No stack trace available>" + "'", str4.equals("<No stack trace available>"));
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test279");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newNumber(100.0d, 4095, 9);
        java.util.Set<java.lang.String> strSet5 = node4.getDirectives();
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray17 = new com.google.javascript.rhino.Node[] { node8, node10, node12, node14, node16 };
        com.google.javascript.rhino.Node node18 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray17);
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node21 = node18.copyInformationFrom(node20);
        com.google.javascript.rhino.Node node24 = new com.google.javascript.rhino.Node(28, node4, node18, (-2), (int) (byte) -1);
        com.google.javascript.rhino.Node node25 = node18.removeChildren();
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNull(strSet5);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertNotNull(nodeArray17);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertNotNull(node25);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test280");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.checkDuplicateMessages = false;
        boolean boolean3 = compilerOptions0.inlineAnonymousFunctionExpressions;
        compilerOptions0.recordFunctionInformation = true;
        boolean boolean6 = compilerOptions0.checkCaja;
        java.util.Set<java.lang.String> strSet7 = compilerOptions0.stripNamePrefixes;
        boolean boolean8 = compilerOptions0.inlineFunctions;
        boolean boolean9 = compilerOptions0.generatePseudoNames;
        compilerOptions0.recordFunctionInformation = true;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(strSet7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }
}

