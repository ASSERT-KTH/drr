import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        java.io.File file0 = null;
        try {
            com.google.javascript.jscomp.SourceFile sourceFile1 = com.google.javascript.jscomp.SourceFile.fromFile(file0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node2 = null;
        com.google.javascript.rhino.Node node3 = null;
        try {
            node1.addChildBefore(node2, node3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The existing child node of the parent should not be null.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node1);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        int int0 = com.google.javascript.rhino.Node.TYPE_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 17 + "'", int0 == 17);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        int int0 = com.google.javascript.rhino.Node.SIDE_EFFECT_FLAGS;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 41 + "'", int0 == 41);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        int int0 = com.google.javascript.rhino.Node.JSDOC_INFO_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 29 + "'", int0 == 29);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        try {
            com.google.javascript.rhino.EcmaError ecmaError4 = com.google.javascript.rhino.ScriptRuntime.typeError3("hi!", "hi!", "", "hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property hi!");
        } catch (java.lang.RuntimeException e) {
        }
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        int int0 = com.google.javascript.rhino.Node.TEMP_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 6 + "'", int0 == 6);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        int int0 = com.google.javascript.rhino.Context.VERSION_1_1;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 110 + "'", int0 == 110);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        com.google.javascript.jscomp.SourceMap.Format format0 = com.google.javascript.jscomp.SourceMap.Format.EXPERIMENTIAL;
        org.junit.Assert.assertNotNull(format0);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        int int0 = com.google.javascript.rhino.Context.FEATURE_STRICT_EVAL;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 9 + "'", int0 == 9);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.STRICT_MODULE_DEP_CHECK;
        com.google.javascript.jscomp.DiagnosticGroups.STRICT_MODULE_DEP_CHECK = diagnosticGroup0;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention2 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray15 = new com.google.javascript.rhino.Node[] { node6, node8, node10, node12, node14 };
        com.google.javascript.rhino.Node node16 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray15);
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node21 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node27 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray28 = new com.google.javascript.rhino.Node[] { node19, node21, node23, node25, node27 };
        com.google.javascript.rhino.Node node29 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray28);
        com.google.javascript.rhino.Node node30 = new com.google.javascript.rhino.Node(100, node16, node29);
        java.lang.String str31 = closureCodingConvention2.getSingletonGetterClassName(node30);
        com.google.javascript.rhino.Node node35 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node37 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node39 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node41 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node43 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray44 = new com.google.javascript.rhino.Node[] { node35, node37, node39, node41, node43 };
        com.google.javascript.rhino.Node node45 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray44);
        com.google.javascript.rhino.Node node48 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node50 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node52 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node54 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node56 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray57 = new com.google.javascript.rhino.Node[] { node48, node50, node52, node54, node56 };
        com.google.javascript.rhino.Node node58 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray57);
        com.google.javascript.rhino.Node node59 = new com.google.javascript.rhino.Node(100, node45, node58);
        try {
            node1.replaceChildAfter(node30, node45);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: prev is not a child of this node.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNotNull(nodeArray15);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNotNull(node27);
        org.junit.Assert.assertNotNull(nodeArray28);
        org.junit.Assert.assertNull(str31);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertNotNull(node37);
        org.junit.Assert.assertNotNull(node39);
        org.junit.Assert.assertNotNull(node41);
        org.junit.Assert.assertNotNull(node43);
        org.junit.Assert.assertNotNull(nodeArray44);
        org.junit.Assert.assertNotNull(node48);
        org.junit.Assert.assertNotNull(node50);
        org.junit.Assert.assertNotNull(node52);
        org.junit.Assert.assertNotNull(node54);
        org.junit.Assert.assertNotNull(node56);
        org.junit.Assert.assertNotNull(nodeArray57);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        int int0 = com.google.javascript.rhino.Node.REGEXP_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 12 + "'", int0 == 12);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        java.io.File file0 = null;
        java.nio.charset.Charset charset1 = null;
        try {
            com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromFile(file0, charset1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        com.google.javascript.rhino.Node node0 = null;
        try {
            java.util.Collection<com.google.javascript.rhino.Node> nodeCollection1 = com.google.javascript.jscomp.NodeUtil.getVarsDeclaredInBranch(node0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        java.io.File file0 = null;
        java.nio.charset.Charset charset1 = null;
        try {
            com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromFile(file0, charset1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        int int0 = com.google.javascript.rhino.Node.USES_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 11 + "'", int0 == 11);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        int int0 = com.google.javascript.rhino.Node.PROPERTY_FLAG;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        java.lang.Object[] objArray0 = com.google.javascript.rhino.Context.emptyArgs;
        org.junit.Assert.assertNotNull(objArray0);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray13 = new com.google.javascript.rhino.Node[] { node4, node6, node8, node10, node12 };
        com.google.javascript.rhino.Node node14 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray13);
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node21 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray26 = new com.google.javascript.rhino.Node[] { node17, node19, node21, node23, node25 };
        com.google.javascript.rhino.Node node27 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray26);
        com.google.javascript.rhino.Node node28 = new com.google.javascript.rhino.Node(100, node14, node27);
        com.google.javascript.jscomp.CheckLevel checkLevel29 = com.google.javascript.jscomp.CheckLevel.WARNING;
        com.google.javascript.jscomp.DiagnosticType diagnosticType30 = null;
        java.lang.String[] strArray36 = new java.lang.String[] { "hi!", "hi!", "hi!", "", "" };
        try {
            com.google.javascript.jscomp.JSError jSError37 = com.google.javascript.jscomp.JSError.make("", node14, checkLevel29, diagnosticType30, strArray36);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(nodeArray13);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNotNull(nodeArray26);
        org.junit.Assert.assertTrue("'" + checkLevel29 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel29.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
        org.junit.Assert.assertNotNull(strArray36);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        int int0 = com.google.javascript.rhino.Context.FEATURE_STRICT_VARS;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 8 + "'", int0 == 8);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        com.google.javascript.jscomp.AbstractCompiler abstractCompiler0 = null;
        com.google.javascript.jscomp.NodeTraversal.Callback callback1 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal2 = new com.google.javascript.jscomp.NodeTraversal(abstractCompiler0, callback1);
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray15 = new com.google.javascript.rhino.Node[] { node6, node8, node10, node12, node14 };
        com.google.javascript.rhino.Node node16 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray15);
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node21 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node27 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray28 = new com.google.javascript.rhino.Node[] { node19, node21, node23, node25, node27 };
        com.google.javascript.rhino.Node node29 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray28);
        com.google.javascript.rhino.Node node30 = new com.google.javascript.rhino.Node(100, node16, node29);
        com.google.javascript.jscomp.DiagnosticType diagnosticType31 = null;
        java.lang.String[] strArray35 = new java.lang.String[] { "hi!", "", "hi!" };
        try {
            com.google.javascript.jscomp.JSError jSError36 = nodeTraversal2.makeError(node29, diagnosticType31, strArray35);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNotNull(nodeArray15);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNotNull(node27);
        org.junit.Assert.assertNotNull(nodeArray28);
        org.junit.Assert.assertNotNull(strArray35);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        com.google.javascript.jscomp.AbstractCompiler abstractCompiler0 = null;
        java.util.List<com.google.javascript.rhino.Node> nodeList1 = null;
        com.google.javascript.jscomp.NodeTraversal.Callback callback2 = null;
        try {
            com.google.javascript.jscomp.NodeTraversal.traverseRoots(abstractCompiler0, nodeList1, callback2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        java.lang.Object obj1 = null;
        try {
            java.lang.String str2 = com.google.javascript.rhino.ScriptRuntime.getMessage1("hi!", obj1);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property hi!");
        } catch (java.lang.RuntimeException e) {
        }
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        int int0 = com.google.javascript.rhino.Node.IS_VAR_ARGS_PARAM;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 44 + "'", int0 == 44);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        int int0 = com.google.javascript.rhino.Node.IS_NAMESPACE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 45 + "'", int0 == 45);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray11 = new com.google.javascript.rhino.Node[] { node2, node4, node6, node8, node10 };
        com.google.javascript.rhino.Node node12 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray11);
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node15 = node12.copyInformationFrom(node14);
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node21 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node27 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray28 = new com.google.javascript.rhino.Node[] { node19, node21, node23, node25, node27 };
        com.google.javascript.rhino.Node node29 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray28);
        com.google.javascript.rhino.Node node32 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node34 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node36 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node38 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node40 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray41 = new com.google.javascript.rhino.Node[] { node32, node34, node36, node38, node40 };
        com.google.javascript.rhino.Node node42 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray41);
        com.google.javascript.rhino.Node node43 = new com.google.javascript.rhino.Node(100, node29, node42);
        try {
            node12.addChildToFront(node29);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(nodeArray11);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNotNull(node27);
        org.junit.Assert.assertNotNull(nodeArray28);
        org.junit.Assert.assertNotNull(node32);
        org.junit.Assert.assertNotNull(node34);
        org.junit.Assert.assertNotNull(node36);
        org.junit.Assert.assertNotNull(node38);
        org.junit.Assert.assertNotNull(node40);
        org.junit.Assert.assertNotNull(nodeArray41);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        com.google.javascript.rhino.Context context0 = com.google.javascript.rhino.Context.enter();
        boolean boolean1 = context0.isGeneratingSource();
        boolean boolean2 = context0.isGeneratingSource();
        com.google.javascript.rhino.ErrorReporter errorReporter3 = context0.getErrorReporter();
        org.junit.Assert.assertNotNull(context0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNull(errorReporter3);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        try {
            java.lang.String str2 = com.google.javascript.rhino.ScriptRuntime.escapeString("", '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: FAILED ASSERTION");
        } catch (java.lang.IllegalStateException e) {
        }
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        try {
            com.google.javascript.rhino.EcmaError ecmaError1 = com.google.javascript.rhino.ScriptRuntime.typeError0("");
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property ");
        } catch (java.lang.RuntimeException e) {
        }
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        com.google.javascript.rhino.Node node0 = null;
        try {
            com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder1 = node0.new FileLevelJsDocBuilder();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: reflection call to com.google.javascript.rhino.Node$FileLevelJsDocBuilder with null for superclass argument");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray13 = new com.google.javascript.rhino.Node[] { node4, node6, node8, node10, node12 };
        com.google.javascript.rhino.Node node14 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray13);
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node21 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray26 = new com.google.javascript.rhino.Node[] { node17, node19, node21, node23, node25 };
        com.google.javascript.rhino.Node node27 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray26);
        com.google.javascript.rhino.Node node28 = new com.google.javascript.rhino.Node(100, node14, node27);
        java.lang.String str29 = closureCodingConvention0.getSingletonGetterClassName(node28);
        com.google.javascript.rhino.Node node32 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node34 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node36 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node38 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node40 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray41 = new com.google.javascript.rhino.Node[] { node32, node34, node36, node38, node40 };
        com.google.javascript.rhino.Node node42 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray41);
        com.google.javascript.rhino.Node node44 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node45 = node42.copyInformationFrom(node44);
        try {
            node28.removeChild(node42);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: node is not a child");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(nodeArray13);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNotNull(nodeArray26);
        org.junit.Assert.assertNull(str29);
        org.junit.Assert.assertNotNull(node32);
        org.junit.Assert.assertNotNull(node34);
        org.junit.Assert.assertNotNull(node36);
        org.junit.Assert.assertNotNull(node38);
        org.junit.Assert.assertNotNull(node40);
        org.junit.Assert.assertNotNull(nodeArray41);
        org.junit.Assert.assertNotNull(node44);
        org.junit.Assert.assertNotNull(node45);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        com.google.javascript.jscomp.CompilerOptions.TracerMode tracerMode0 = com.google.javascript.jscomp.CompilerOptions.TracerMode.FAST;
        org.junit.Assert.assertTrue("'" + tracerMode0 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TracerMode.FAST + "'", tracerMode0.equals(com.google.javascript.jscomp.CompilerOptions.TracerMode.FAST));
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray13 = new com.google.javascript.rhino.Node[] { node4, node6, node8, node10, node12 };
        com.google.javascript.rhino.Node node14 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray13);
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node21 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray26 = new com.google.javascript.rhino.Node[] { node17, node19, node21, node23, node25 };
        com.google.javascript.rhino.Node node27 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray26);
        com.google.javascript.rhino.Node node28 = new com.google.javascript.rhino.Node(100, node14, node27);
        java.lang.String str29 = closureCodingConvention0.getSingletonGetterClassName(node28);
        java.lang.String str30 = closureCodingConvention0.getGlobalObject();
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(nodeArray13);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNotNull(nodeArray26);
        org.junit.Assert.assertNull(str29);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "goog.global" + "'", str30.equals("goog.global"));
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray11 = new com.google.javascript.rhino.Node[] { node2, node4, node6, node8, node10 };
        com.google.javascript.rhino.Node node12 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray11);
        java.lang.String str13 = node12.getQualifiedName();
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node21 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray26 = new com.google.javascript.rhino.Node[] { node17, node19, node21, node23, node25 };
        com.google.javascript.rhino.Node node27 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray26);
        com.google.javascript.rhino.Node node30 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node32 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node34 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node36 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node38 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray39 = new com.google.javascript.rhino.Node[] { node30, node32, node34, node36, node38 };
        com.google.javascript.rhino.Node node40 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray39);
        com.google.javascript.rhino.Node node41 = new com.google.javascript.rhino.Node(100, node27, node40);
        com.google.javascript.rhino.Node node43 = node27.getAncestor(9);
        try {
            com.google.javascript.rhino.Node node44 = node12.copyInformationFromForTree(node43);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(nodeArray11);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNotNull(nodeArray26);
        org.junit.Assert.assertNotNull(node30);
        org.junit.Assert.assertNotNull(node32);
        org.junit.Assert.assertNotNull(node34);
        org.junit.Assert.assertNotNull(node36);
        org.junit.Assert.assertNotNull(node38);
        org.junit.Assert.assertNotNull(nodeArray39);
        org.junit.Assert.assertNull(node43);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        try {
            com.google.javascript.rhino.EcmaError ecmaError3 = com.google.javascript.rhino.ScriptRuntime.typeError2("hi!", "hi!", "");
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property hi!");
        } catch (java.lang.RuntimeException e) {
        }
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        int int0 = com.google.javascript.rhino.Node.MAX_COLUMN_NUMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4095 + "'", int0 == 4095);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        int int0 = com.google.javascript.rhino.Node.CODEOFFSET_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 8 + "'", int0 == 8);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        int int0 = com.google.javascript.rhino.Node.SYNTHETIC_BLOCK_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 37 + "'", int0 == 37);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        try {
            com.google.javascript.rhino.Context.checkOptimizationLevel((int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Optimization level outside [-1..9]: 97");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        com.google.javascript.jscomp.parsing.Config.LanguageMode languageMode0 = com.google.javascript.jscomp.parsing.Config.LanguageMode.ECMASCRIPT5_STRICT;
        org.junit.Assert.assertTrue("'" + languageMode0 + "' != '" + com.google.javascript.jscomp.parsing.Config.LanguageMode.ECMASCRIPT5_STRICT + "'", languageMode0.equals(com.google.javascript.jscomp.parsing.Config.LanguageMode.ECMASCRIPT5_STRICT));
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        int int0 = com.google.javascript.rhino.Node.FIXUPS_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 9 + "'", int0 == 9);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        int int0 = com.google.javascript.rhino.Node.DECR_FLAG;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        com.google.javascript.jscomp.SourceMap.Format format0 = com.google.javascript.jscomp.SourceMap.Format.LEGACY;
        org.junit.Assert.assertNotNull(format0);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        int int0 = com.google.javascript.rhino.Node.ISNUMBER_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 25 + "'", int0 == 25);
    }

//    @Test
//    public void test046() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test046");
//        try {
//            java.lang.String str2 = com.google.javascript.rhino.ScriptRuntime.numberToString((double) 37, (int) (byte) 0);
//            org.junit.Assert.fail("Expected exception of type com.google.javascript.rhino.EvaluatorException; message: illegal radix 0.");
//        } catch (com.google.javascript.rhino.EvaluatorException e) {
//        }
//    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        int int0 = com.google.javascript.rhino.Node.DIRECTIVES;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 47 + "'", int0 == 47);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        int int0 = com.google.javascript.rhino.Node.OBJECT_IDS_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + (-2) + "'", int0 == (-2));
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        int int0 = com.google.javascript.rhino.Context.FEATURE_RESERVED_KEYWORD_AS_IDENTIFIER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        com.google.javascript.jscomp.DiagnosticType diagnosticType0 = null;
        java.lang.String[] strArray3 = new java.lang.String[] { "", "goog.global" };
        try {
            com.google.javascript.jscomp.JSError jSError4 = com.google.javascript.jscomp.JSError.make(diagnosticType0, strArray3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray12 = new com.google.javascript.rhino.Node[] { node3, node5, node7, node9, node11 };
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray12);
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node16 = node13.copyInformationFrom(node15);
        java.lang.String str17 = node15.getString();
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node22 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node24 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node26 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node28 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray29 = new com.google.javascript.rhino.Node[] { node20, node22, node24, node26, node28 };
        com.google.javascript.rhino.Node node30 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray29);
        int int31 = node30.getSideEffectFlags();
        com.google.javascript.rhino.Node[] nodeArray32 = new com.google.javascript.rhino.Node[] { node15, node30 };
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList33 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean34 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList33, nodeArray32);
        com.google.javascript.rhino.Node node38 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node40 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node42 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node44 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node46 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray47 = new com.google.javascript.rhino.Node[] { node38, node40, node42, node44, node46 };
        com.google.javascript.rhino.Node node48 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray47);
        com.google.javascript.rhino.Node node51 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node53 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node55 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node57 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node59 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray60 = new com.google.javascript.rhino.Node[] { node51, node53, node55, node57, node59 };
        com.google.javascript.rhino.Node node61 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray60);
        com.google.javascript.rhino.Node node62 = new com.google.javascript.rhino.Node(100, node48, node61);
        com.google.javascript.rhino.Node node64 = node48.getAncestor(9);
        try {
            com.google.javascript.rhino.Node node67 = com.google.javascript.jscomp.NodeUtil.newFunctionNode("goog.exportSymbol", (java.util.List<com.google.javascript.rhino.Node>) nodeList33, node64, (-2), (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertNotNull(nodeArray12);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertNotNull(nodeArray29);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertNotNull(nodeArray32);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertNotNull(node38);
        org.junit.Assert.assertNotNull(node40);
        org.junit.Assert.assertNotNull(node42);
        org.junit.Assert.assertNotNull(node44);
        org.junit.Assert.assertNotNull(node46);
        org.junit.Assert.assertNotNull(nodeArray47);
        org.junit.Assert.assertNotNull(node51);
        org.junit.Assert.assertNotNull(node53);
        org.junit.Assert.assertNotNull(node55);
        org.junit.Assert.assertNotNull(node57);
        org.junit.Assert.assertNotNull(node59);
        org.junit.Assert.assertNotNull(nodeArray60);
        org.junit.Assert.assertNull(node64);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        int int0 = com.google.javascript.rhino.Node.FLAG_LOCAL_RESULTS;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 16 + "'", int0 == 16);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        int int0 = com.google.javascript.rhino.Context.FEATURE_LOCATION_INFORMATION_IN_ERROR;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        java.lang.String str0 = com.google.javascript.rhino.jstype.JSType.NOT_A_CLASS;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "Not declared as a constructor" + "'", str0.equals("Not declared as a constructor"));
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        java.lang.String str1 = com.google.javascript.rhino.ScriptRuntime.toString((java.lang.Object) (byte) 1);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1" + "'", str1.equals("1"));
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        int int0 = com.google.javascript.rhino.Node.CATCH_SCOPE_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + (-1) + "'", int0 == (-1));
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        java.lang.String str0 = com.google.javascript.rhino.Context.languageVersionProperty;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "language version" + "'", str0.equals("language version"));
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy0 = com.google.javascript.jscomp.VariableRenamingPolicy.ALL;
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy0 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.ALL + "'", variableRenamingPolicy0.equals(com.google.javascript.jscomp.VariableRenamingPolicy.ALL));
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.aliasAllStrings;
        com.google.common.collect.Multimap<com.google.javascript.jscomp.CustomPassExecutionTime, com.google.javascript.jscomp.CompilerPass> customPassExecutionTimeMultimap2 = null;
        compilerOptions0.customPasses = customPassExecutionTimeMultimap2;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        boolean boolean2 = closureCodingConvention0.isConstant("");
        boolean boolean4 = closureCodingConvention0.isValidEnumKey("hi!");
        java.lang.String str5 = closureCodingConvention0.getExportSymbolFunction();
        com.google.javascript.jscomp.AbstractCompiler abstractCompiler6 = null;
        com.google.javascript.jscomp.NodeTraversal.Callback callback7 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal8 = new com.google.javascript.jscomp.NodeTraversal(abstractCompiler6, callback7);
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newNumber((double) 'a', (int) (short) 0, 37);
        try {
            com.google.javascript.jscomp.CodingConvention.ObjectLiteralCast objectLiteralCast13 = closureCodingConvention0.getObjectLiteralCast(nodeTraversal8, node12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "goog.exportSymbol" + "'", str5.equals("goog.exportSymbol"));
        org.junit.Assert.assertNotNull(node12);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        java.lang.String str0 = com.google.javascript.rhino.jstype.JSType.UNKNOWN_NAME;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "Unknown class name" + "'", str0.equals("Unknown class name"));
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        com.google.javascript.jscomp.SourceFile sourceFile3 = com.google.javascript.jscomp.SourceFile.fromCode("language version", "goog.exportProperty", "");
        org.junit.Assert.assertNotNull(sourceFile3);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray11 = new com.google.javascript.rhino.Node[] { node2, node4, node6, node8, node10 };
        com.google.javascript.rhino.Node node12 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray11);
        try {
            double double13 = node12.getDouble();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: EOF 0 is not a number node");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(nodeArray11);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        int int0 = com.google.javascript.rhino.Node.RIGHT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        boolean boolean1 = com.google.javascript.rhino.ScriptRuntime.isJSLineTerminator((-2));
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.GLOBAL_THIS;
        com.google.javascript.jscomp.DiagnosticGroups.UNDEFINED_VARIABLES = diagnosticGroup0;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

//    @Test
//    public void test067() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test067");
//        try {
//            java.lang.String str2 = com.google.javascript.rhino.ScriptRuntime.numberToString((double) (byte) 10, (int) (byte) 0);
//            org.junit.Assert.fail("Expected exception of type com.google.javascript.rhino.EvaluatorException; message: illegal radix 0.");
//        } catch (com.google.javascript.rhino.EvaluatorException e) {
//        }
//    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        java.util.logging.Level level0 = null;
        com.google.javascript.jscomp.Compiler.setLoggingLevel(level0);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray12 = new com.google.javascript.rhino.Node[] { node3, node5, node7, node9, node11 };
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray12);
        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node22 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node24 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray25 = new com.google.javascript.rhino.Node[] { node16, node18, node20, node22, node24 };
        com.google.javascript.rhino.Node node26 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray25);
        com.google.javascript.rhino.Node node27 = new com.google.javascript.rhino.Node(100, node13, node26);
        com.google.javascript.rhino.Node node29 = node13.getAncestor(9);
        try {
            java.lang.Object obj31 = node29.getProp((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertNotNull(nodeArray12);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertNotNull(nodeArray25);
        org.junit.Assert.assertNull(node29);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray12 = new com.google.javascript.rhino.Node[] { node3, node5, node7, node9, node11 };
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray12);
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node16 = node13.copyInformationFrom(node15);
        com.google.javascript.rhino.Node node17 = node13.getParent();
        com.google.javascript.rhino.Node node18 = new com.google.javascript.rhino.Node((int) (short) -1, node13);
        com.google.javascript.rhino.Node node22 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node24 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node26 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node28 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node30 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray31 = new com.google.javascript.rhino.Node[] { node22, node24, node26, node28, node30 };
        com.google.javascript.rhino.Node node32 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray31);
        com.google.javascript.rhino.Node node35 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node37 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node39 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node41 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node43 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray44 = new com.google.javascript.rhino.Node[] { node35, node37, node39, node41, node43 };
        com.google.javascript.rhino.Node node45 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray44);
        com.google.javascript.rhino.Node node46 = new com.google.javascript.rhino.Node(100, node32, node45);
        com.google.javascript.rhino.Node node48 = com.google.javascript.rhino.Node.newString("");
        try {
            node13.replaceChildAfter(node45, node48);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: prev is not a child of this node.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertNotNull(nodeArray12);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertNull(node17);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertNotNull(node30);
        org.junit.Assert.assertNotNull(nodeArray31);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertNotNull(node37);
        org.junit.Assert.assertNotNull(node39);
        org.junit.Assert.assertNotNull(node41);
        org.junit.Assert.assertNotNull(node43);
        org.junit.Assert.assertNotNull(nodeArray44);
        org.junit.Assert.assertNotNull(node48);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        int int0 = com.google.javascript.rhino.Node.LASTUSE_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 24 + "'", int0 == 24);
    }

//    @Test
//    public void test072() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test072");
//        try {
//            com.google.javascript.rhino.Context.exit();
//            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Calling Context.exit without previous Context.enter");
//        } catch (java.lang.RuntimeException e) {
//        }
//    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        int int0 = com.google.javascript.rhino.Node.DEBUGSOURCE_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 28 + "'", int0 == 28);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        java.lang.Double double0 = com.google.javascript.rhino.ScriptRuntime.NaNobj;
        org.junit.Assert.assertEquals((double) double0, Double.NaN, 0);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        com.google.javascript.rhino.Node.SideEffectFlags sideEffectFlags1 = new com.google.javascript.rhino.Node.SideEffectFlags(17);
        sideEffectFlags1.setAllFlags();
        int int3 = sideEffectFlags1.valueOf();
        sideEffectFlags1.setReturnsTainted();
        boolean boolean5 = sideEffectFlags1.areAllFlagsSet();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        int int0 = com.google.javascript.rhino.Node.LABEL_ID_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        int int0 = com.google.javascript.rhino.Node.LOCAL_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 7 + "'", int0 == 7);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        int int0 = com.google.javascript.rhino.Node.FLAG_THIS_UNMODIFIED;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray11 = new com.google.javascript.rhino.Node[] { node2, node4, node6, node8, node10 };
        com.google.javascript.rhino.Node node12 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray11);
        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node22 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node24 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray25 = new com.google.javascript.rhino.Node[] { node16, node18, node20, node22, node24 };
        com.google.javascript.rhino.Node node26 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray25);
        com.google.javascript.rhino.Node node29 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node31 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node33 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node35 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node37 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray38 = new com.google.javascript.rhino.Node[] { node29, node31, node33, node35, node37 };
        com.google.javascript.rhino.Node node39 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray38);
        com.google.javascript.rhino.Node node40 = new com.google.javascript.rhino.Node(100, node26, node39);
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention41 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node45 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node47 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node49 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node51 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node53 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray54 = new com.google.javascript.rhino.Node[] { node45, node47, node49, node51, node53 };
        com.google.javascript.rhino.Node node55 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray54);
        com.google.javascript.rhino.Node node58 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node60 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node62 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node64 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node66 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray67 = new com.google.javascript.rhino.Node[] { node58, node60, node62, node64, node66 };
        com.google.javascript.rhino.Node node68 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray67);
        com.google.javascript.rhino.Node node69 = new com.google.javascript.rhino.Node(100, node55, node68);
        java.lang.String str70 = closureCodingConvention41.getSingletonGetterClassName(node69);
        try {
            node12.replaceChildAfter(node39, node69);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: prev is not a child of this node.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(nodeArray11);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertNotNull(nodeArray25);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertNotNull(node33);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertNotNull(node37);
        org.junit.Assert.assertNotNull(nodeArray38);
        org.junit.Assert.assertNotNull(node45);
        org.junit.Assert.assertNotNull(node47);
        org.junit.Assert.assertNotNull(node49);
        org.junit.Assert.assertNotNull(node51);
        org.junit.Assert.assertNotNull(node53);
        org.junit.Assert.assertNotNull(nodeArray54);
        org.junit.Assert.assertNotNull(node58);
        org.junit.Assert.assertNotNull(node60);
        org.junit.Assert.assertNotNull(node62);
        org.junit.Assert.assertNotNull(node64);
        org.junit.Assert.assertNotNull(node66);
        org.junit.Assert.assertNotNull(nodeArray67);
        org.junit.Assert.assertNull(str70);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        com.google.javascript.rhino.Node.SideEffectFlags sideEffectFlags1 = new com.google.javascript.rhino.Node.SideEffectFlags(17);
        sideEffectFlags1.setAllFlags();
        boolean boolean3 = sideEffectFlags1.areAllFlagsSet();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        try {
            com.google.javascript.rhino.Context.reportWarning("", "", (-2), "Not declared as a constructor", (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: No Context associated with current Thread");
        } catch (java.lang.RuntimeException e) {
        }
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        int int0 = com.google.javascript.rhino.Context.FEATURE_WARNING_AS_ERROR;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 12 + "'", int0 == 12);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        int int0 = com.google.javascript.rhino.Node.COLUMN_MASK;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4095 + "'", int0 == 4095);
    }

//    @Test
//    public void test084() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test084");
//        com.google.javascript.rhino.Context context0 = com.google.javascript.rhino.Context.getCurrentContext();
//        org.junit.Assert.assertNull(context0);
//    }

//    @Test
//    public void test085() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test085");
//        com.google.javascript.rhino.Context context0 = com.google.javascript.rhino.Context.enter();
//        boolean boolean1 = context0.isGeneratingSource();
//        com.google.javascript.rhino.ErrorReporter errorReporter2 = context0.getErrorReporter();
//        com.google.javascript.rhino.ErrorReporter errorReporter3 = context0.getErrorReporter();
//        try {
//            context0.setLanguageVersion((int) (short) 1);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Bad language version: 1");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(context0);
//        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
//        org.junit.Assert.assertNull(errorReporter2);
//        org.junit.Assert.assertNull(errorReporter3);
//    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        try {
            java.lang.String str1 = com.google.javascript.rhino.ScriptRuntime.getMessage0("DiagnosticGroup<undefinedVars>");
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property DiagnosticGroup<undefinedVars>");
        } catch (java.lang.RuntimeException e) {
        }
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        com.google.javascript.jscomp.SourceAst sourceAst0 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(sourceAst0, "Not declared as a constructor", true);
        try {
            compilerInput3.clearAst();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        boolean boolean1 = com.google.javascript.rhino.Context.isValidLanguageVersion(25);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        int int0 = com.google.javascript.rhino.Node.TARGETBLOCK_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 22 + "'", int0 == 22);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        boolean boolean2 = closureCodingConvention0.isConstant("");
        boolean boolean4 = closureCodingConvention0.isValidEnumKey("hi!");
        com.google.javascript.jscomp.AbstractCompiler abstractCompiler5 = null;
        com.google.javascript.jscomp.NodeTraversal.Callback callback6 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal7 = new com.google.javascript.jscomp.NodeTraversal(abstractCompiler5, callback6);
        boolean boolean8 = nodeTraversal7.hasScope();
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention9 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node21 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray22 = new com.google.javascript.rhino.Node[] { node13, node15, node17, node19, node21 };
        com.google.javascript.rhino.Node node23 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray22);
        com.google.javascript.rhino.Node node26 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node28 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node30 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node32 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node34 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray35 = new com.google.javascript.rhino.Node[] { node26, node28, node30, node32, node34 };
        com.google.javascript.rhino.Node node36 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray35);
        com.google.javascript.rhino.Node node37 = new com.google.javascript.rhino.Node(100, node23, node36);
        boolean boolean38 = closureCodingConvention9.isVarArgsParameter(node37);
        try {
            com.google.javascript.jscomp.CodingConvention.ObjectLiteralCast objectLiteralCast39 = closureCodingConvention0.getObjectLiteralCast(nodeTraversal7, node37);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertNotNull(nodeArray22);
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertNotNull(node30);
        org.junit.Assert.assertNotNull(node32);
        org.junit.Assert.assertNotNull(node34);
        org.junit.Assert.assertNotNull(nodeArray35);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        boolean boolean1 = com.google.javascript.rhino.Context.isValidOptimizationLevel(22);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        java.lang.RuntimeException runtimeException1 = com.google.javascript.rhino.ScriptRuntime.notFunctionError((java.lang.Object) (byte) -1);
        java.lang.String str2 = runtimeException1.toString();
        org.junit.Assert.assertNotNull(runtimeException1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "com.google.javascript.rhino.EcmaError: TypeError: -1 is not a function, it is java.lang.Byte." + "'", str2.equals("com.google.javascript.rhino.EcmaError: TypeError: -1 is not a function, it is java.lang.Byte."));
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        int int0 = com.google.javascript.rhino.Context.VERSION_1_4;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 140 + "'", int0 == 140);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        java.lang.String str0 = com.google.javascript.rhino.jstype.JSType.NOT_A_TYPE;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "Not declared as a type name" + "'", str0.equals("Not declared as a type name"));
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        int int0 = com.google.javascript.rhino.Context.VERSION_1_3;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 130 + "'", int0 == 130);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        int int0 = com.google.javascript.rhino.Context.FEATURE_MEMBER_EXPR_AS_FUNCTION_NAME;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray13 = new com.google.javascript.rhino.Node[] { node4, node6, node8, node10, node12 };
        com.google.javascript.rhino.Node node14 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray13);
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node21 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray26 = new com.google.javascript.rhino.Node[] { node17, node19, node21, node23, node25 };
        com.google.javascript.rhino.Node node27 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray26);
        com.google.javascript.rhino.Node node28 = new com.google.javascript.rhino.Node(100, node14, node27);
        boolean boolean29 = closureCodingConvention0.isVarArgsParameter(node28);
        java.lang.String str30 = closureCodingConvention0.getExportPropertyFunction();
        com.google.javascript.rhino.Node node33 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node35 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node37 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node39 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node41 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray42 = new com.google.javascript.rhino.Node[] { node33, node35, node37, node39, node41 };
        com.google.javascript.rhino.Node node43 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray42);
        com.google.javascript.rhino.Node node45 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node46 = node43.copyInformationFrom(node45);
        com.google.javascript.jscomp.parsing.Config.LanguageMode languageMode48 = com.google.javascript.jscomp.parsing.Config.LanguageMode.ECMASCRIPT5;
        node46.putProp(24, (java.lang.Object) languageMode48);
        try {
            boolean boolean50 = closureCodingConvention0.isPropertyTestFunction(node46);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(nodeArray13);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNotNull(nodeArray26);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "goog.exportProperty" + "'", str30.equals("goog.exportProperty"));
        org.junit.Assert.assertNotNull(node33);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertNotNull(node37);
        org.junit.Assert.assertNotNull(node39);
        org.junit.Assert.assertNotNull(node41);
        org.junit.Assert.assertNotNull(nodeArray42);
        org.junit.Assert.assertNotNull(node45);
        org.junit.Assert.assertNotNull(node46);
        org.junit.Assert.assertTrue("'" + languageMode48 + "' != '" + com.google.javascript.jscomp.parsing.Config.LanguageMode.ECMASCRIPT5 + "'", languageMode48.equals(com.google.javascript.jscomp.parsing.Config.LanguageMode.ECMASCRIPT5));
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        int int0 = com.google.javascript.rhino.Node.EMPTY_BLOCK;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 38 + "'", int0 == 38);
    }

//    @Test
//    public void test099() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test099");
//        com.google.javascript.rhino.Context context0 = com.google.javascript.rhino.Context.enter();
//        boolean boolean1 = context0.isGeneratingSource();
//        com.google.javascript.rhino.ErrorReporter errorReporter2 = context0.getErrorReporter();
//        com.google.javascript.rhino.ErrorReporter errorReporter3 = context0.getErrorReporter();
//        boolean boolean4 = context0.isSealed();
//        java.beans.PropertyChangeListener propertyChangeListener5 = null;
//        try {
//            context0.removePropertyChangeListener(propertyChangeListener5);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(context0);
//        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
//        org.junit.Assert.assertNull(errorReporter2);
//        org.junit.Assert.assertNull(errorReporter3);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        int int0 = com.google.javascript.rhino.Context.FEATURE_DYNAMIC_SCOPE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 7 + "'", int0 == 7);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        com.google.javascript.jscomp.ErrorManager errorManager0 = null;
        try {
            com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(errorManager0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: the error manager cannot be null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test102() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test102");
//        try {
//            com.google.javascript.rhino.Context.reportError("Not declared as a constructor");
//            org.junit.Assert.fail("Expected exception of type com.google.javascript.rhino.EvaluatorException; message: Not declared as a constructor");
//        } catch (com.google.javascript.rhino.EvaluatorException e) {
//        }
//    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2);
        com.google.javascript.jscomp.CompilerOptions compilerOptions4 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel5 = compilerOptions4.brokenClosureRequiresLevel;
        java.util.Set<java.lang.String> strSet6 = compilerOptions4.aliasableStrings;
        com.google.javascript.jscomp.CompilerOptions compilerOptions7 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel8 = compilerOptions7.brokenClosureRequiresLevel;
        com.google.javascript.jscomp.CheckLevel checkLevel9 = com.google.javascript.jscomp.CheckLevel.WARNING;
        compilerOptions7.checkGlobalNamesLevel = checkLevel9;
        compilerOptions7.computeFunctionSideEffects = true;
        compilerOptions7.closurePass = false;
        com.google.javascript.jscomp.ErrorFormat errorFormat15 = compilerOptions7.errorFormat;
        try {
            java.lang.String str17 = com.google.javascript.rhino.ScriptRuntime.getMessage4("1", (java.lang.Object) compilerInput3, (java.lang.Object) compilerOptions4, (java.lang.Object) compilerOptions7, (java.lang.Object) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property 1");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile2);
        org.junit.Assert.assertTrue("'" + checkLevel5 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel5.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(strSet6);
        org.junit.Assert.assertTrue("'" + checkLevel8 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel8.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + checkLevel9 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel9.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
        org.junit.Assert.assertNotNull(errorFormat15);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        com.google.javascript.jscomp.SourceAst sourceAst0 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(sourceAst0, "Not declared as a constructor", true);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile5 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.CompilerInput compilerInput6 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile5);
        try {
            compilerInput3.setSourceFile((com.google.javascript.jscomp.SourceFile) jSSourceFile5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile5);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        int int0 = com.google.javascript.rhino.Context.VERSION_DEFAULT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        double double0 = com.google.javascript.rhino.ScriptRuntime.NaN;
        org.junit.Assert.assertEquals((double) double0, Double.NaN, 0);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy0 = com.google.javascript.jscomp.VariableRenamingPolicy.LOCAL;
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy0 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.LOCAL + "'", variableRenamingPolicy0.equals(com.google.javascript.jscomp.VariableRenamingPolicy.LOCAL));
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        int int0 = com.google.javascript.rhino.Context.VERSION_1_2;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 120 + "'", int0 == 120);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        java.lang.String str0 = com.google.javascript.rhino.Context.errorReporterProperty;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "error reporter" + "'", str0.equals("error reporter"));
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        int int0 = com.google.javascript.rhino.Node.ORIGINALNAME_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 39 + "'", int0 == 39);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        com.google.javascript.rhino.jstype.JSType jSType0 = null;
        com.google.javascript.rhino.jstype.JSType jSType1 = null;
        boolean boolean2 = com.google.javascript.rhino.jstype.JSType.isEquivalent(jSType0, jSType1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        int int0 = com.google.javascript.rhino.Node.VARS_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        boolean boolean2 = closureCodingConvention0.isConstant("");
        boolean boolean4 = closureCodingConvention0.isValidEnumKey("hi!");
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray16 = new com.google.javascript.rhino.Node[] { node7, node9, node11, node13, node15 };
        com.google.javascript.rhino.Node node17 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray16);
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node20 = node17.copyInformationFrom(node19);
        java.lang.String str21 = node19.getString();
        java.lang.String str22 = closureCodingConvention0.identifyTypeDefAssign(node19);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertNotNull(nodeArray16);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "" + "'", str21.equals(""));
        org.junit.Assert.assertNull(str22);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.NodeTraversal.Callback callback1 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal2 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler0, callback1);
        compiler0.disableThreads();
        try {
            int int4 = compiler0.getErrorCount();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray11 = new com.google.javascript.rhino.Node[] { node2, node4, node6, node8, node10 };
        com.google.javascript.rhino.Node node12 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray11);
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node15 = node12.copyInformationFrom(node14);
        com.google.javascript.rhino.Node node16 = node12.getParent();
        try {
            boolean boolean17 = node16.isUnscopedQualifiedName();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(nodeArray11);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertNull(node16);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray13 = new com.google.javascript.rhino.Node[] { node4, node6, node8, node10, node12 };
        com.google.javascript.rhino.Node node14 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray13);
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node21 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray26 = new com.google.javascript.rhino.Node[] { node17, node19, node21, node23, node25 };
        com.google.javascript.rhino.Node node27 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray26);
        com.google.javascript.rhino.Node node28 = new com.google.javascript.rhino.Node(100, node14, node27);
        java.lang.String str29 = closureCodingConvention0.getSingletonGetterClassName(node28);
        com.google.javascript.rhino.Node node35 = com.google.javascript.rhino.Node.newString((int) (short) 0, "hi!", 100, (-2));
        com.google.javascript.rhino.Node node36 = new com.google.javascript.rhino.Node(10, node35);
        java.lang.String str37 = closureCodingConvention0.identifyTypeDefAssign(node36);
        com.google.javascript.rhino.Node node39 = com.google.javascript.rhino.Node.newString("goog.exportSymbol");
        try {
            boolean boolean40 = closureCodingConvention0.isPropertyTestFunction(node39);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(nodeArray13);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNotNull(nodeArray26);
        org.junit.Assert.assertNull(str29);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertNull(str37);
        org.junit.Assert.assertNotNull(node39);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        try {
            com.google.javascript.rhino.EcmaError ecmaError6 = com.google.javascript.rhino.ScriptRuntime.constructError("com.google.javascript.rhino.EcmaError: TypeError: -1 is not a function, it is java.lang.Byte.", "", "", (-2), "com.google.javascript.rhino.EcmaError: TypeError: -1 is not a function, it is java.lang.Byte.", 22);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: -2");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        com.google.javascript.jscomp.ErrorFormat errorFormat0 = com.google.javascript.jscomp.ErrorFormat.MULTILINE;
        org.junit.Assert.assertNotNull(errorFormat0);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.NodeTraversal.Callback callback1 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal2 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler0, callback1);
        compiler0.disableThreads();
        try {
            boolean boolean4 = compiler0.isIdeMode();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        try {
            compiler1.parse();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        int int0 = com.google.javascript.rhino.Node.FLAG_NO_THROWS;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 8 + "'", int0 == 8);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.brokenClosureRequiresLevel;
        com.google.javascript.jscomp.CheckLevel checkLevel2 = com.google.javascript.jscomp.CheckLevel.WARNING;
        compilerOptions0.checkGlobalNamesLevel = checkLevel2;
        compilerOptions0.renamePrefix = "hi!";
        boolean boolean6 = compilerOptions0.inlineFunctions;
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + checkLevel2 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel2.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        java.io.InputStream inputStream1 = null;
        try {
            com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromInputStream("language version", inputStream1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.brokenClosureRequiresLevel;
        com.google.javascript.jscomp.CheckLevel checkLevel2 = com.google.javascript.jscomp.CheckLevel.WARNING;
        compilerOptions0.checkGlobalNamesLevel = checkLevel2;
        com.google.javascript.jscomp.ErrorFormat errorFormat4 = null;
        compilerOptions0.errorFormat = errorFormat4;
        com.google.javascript.jscomp.CheckLevel checkLevel6 = null;
        compilerOptions0.checkMissingGetCssNameLevel = checkLevel6;
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + checkLevel2 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel2.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        boolean boolean2 = closureCodingConvention0.isConstant("");
        boolean boolean4 = closureCodingConvention0.isValidEnumKey("hi!");
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray17 = new com.google.javascript.rhino.Node[] { node8, node10, node12, node14, node16 };
        com.google.javascript.rhino.Node node18 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray17);
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node21 = node18.copyInformationFrom(node20);
        com.google.javascript.rhino.Node node22 = node18.getParent();
        com.google.javascript.rhino.Node node23 = new com.google.javascript.rhino.Node((int) (short) -1, node18);
        com.google.javascript.rhino.Node node28 = com.google.javascript.rhino.Node.newString((int) (short) 0, "hi!", 100, (-2));
        boolean boolean29 = node18.isEquivalentTo(node28);
        com.google.javascript.rhino.Node node32 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node34 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node36 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node38 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node40 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray41 = new com.google.javascript.rhino.Node[] { node32, node34, node36, node38, node40 };
        com.google.javascript.rhino.Node node42 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray41);
        com.google.javascript.rhino.Node node44 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node45 = node42.copyInformationFrom(node44);
        com.google.javascript.jscomp.parsing.Config.LanguageMode languageMode47 = com.google.javascript.jscomp.parsing.Config.LanguageMode.ECMASCRIPT5;
        node45.putProp(24, (java.lang.Object) languageMode47);
        java.lang.String str49 = closureCodingConvention0.extractClassNameIfRequire(node18, node45);
        node18.setIsSyntheticBlock(true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertNotNull(nodeArray17);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertNull(node22);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(node32);
        org.junit.Assert.assertNotNull(node34);
        org.junit.Assert.assertNotNull(node36);
        org.junit.Assert.assertNotNull(node38);
        org.junit.Assert.assertNotNull(node40);
        org.junit.Assert.assertNotNull(nodeArray41);
        org.junit.Assert.assertNotNull(node44);
        org.junit.Assert.assertNotNull(node45);
        org.junit.Assert.assertTrue("'" + languageMode47 + "' != '" + com.google.javascript.jscomp.parsing.Config.LanguageMode.ECMASCRIPT5 + "'", languageMode47.equals(com.google.javascript.jscomp.parsing.Config.LanguageMode.ECMASCRIPT5));
        org.junit.Assert.assertNull(str49);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.brokenClosureRequiresLevel;
        com.google.javascript.jscomp.CheckLevel checkLevel2 = com.google.javascript.jscomp.CheckLevel.WARNING;
        compilerOptions0.checkGlobalNamesLevel = checkLevel2;
        compilerOptions0.computeFunctionSideEffects = true;
        boolean boolean6 = compilerOptions0.removeDeadCode;
        compilerOptions0.debugFunctionSideEffectsPath = "goog.exportProperty";
        compilerOptions0.extractPrototypeMemberDeclarations = true;
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + checkLevel2 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel2.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        int int0 = com.google.javascript.rhino.Node.DIRECTCALL_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 26 + "'", int0 == 26);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile5 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.CompilerInput compilerInput6 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile5);
        com.google.javascript.jscomp.CompilerInput compilerInput9 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput6, "hi!", false);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile11 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        compilerInput6.setSourceFile((com.google.javascript.jscomp.SourceFile) jSSourceFile11);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile14 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray15 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile2, jSSourceFile11, jSSourceFile14 };
        java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList16 = new java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile>();
        boolean boolean17 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList16, jSSourceFileArray15);
        com.google.javascript.jscomp.JSModule[] jSModuleArray18 = new com.google.javascript.jscomp.JSModule[] {};
        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList19 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
        boolean boolean20 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList19, jSModuleArray18);
        com.google.javascript.jscomp.CompilerOptions compilerOptions21 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions21.checkDuplicateMessages = false;
        boolean boolean24 = compilerOptions21.inlineAnonymousFunctionExpressions;
        compilerOptions21.crossModuleMethodMotion = true;
        com.google.javascript.jscomp.Result result27 = compiler0.compileModules((java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList16, (java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList19, compilerOptions21);
        com.google.javascript.jscomp.ErrorManager errorManager28 = compiler0.getErrorManager();
        compiler0.parse();
        org.junit.Assert.assertNotNull(jSSourceFile2);
        org.junit.Assert.assertNotNull(jSSourceFile5);
        org.junit.Assert.assertNotNull(jSSourceFile11);
        org.junit.Assert.assertNotNull(jSSourceFile14);
        org.junit.Assert.assertNotNull(jSSourceFileArray15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(jSModuleArray18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(result27);
        org.junit.Assert.assertNotNull(errorManager28);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.brokenClosureRequiresLevel;
        com.google.javascript.jscomp.CheckLevel checkLevel2 = com.google.javascript.jscomp.CheckLevel.WARNING;
        compilerOptions0.checkGlobalNamesLevel = checkLevel2;
        compilerOptions0.computeFunctionSideEffects = true;
        compilerOptions0.closurePass = false;
        com.google.javascript.jscomp.CompilerOptions compilerOptions8 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel9 = compilerOptions8.brokenClosureRequiresLevel;
        compilerOptions0.checkGlobalThisLevel = checkLevel9;
        compilerOptions0.collapseVariableDeclarations = false;
        com.google.javascript.jscomp.CheckLevel checkLevel13 = compilerOptions0.checkGlobalNamesLevel;
        compilerOptions0.syntheticBlockEndMarker = "EOF 0";
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + checkLevel2 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel2.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
        org.junit.Assert.assertTrue("'" + checkLevel9 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel9.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + checkLevel13 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel13.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy0 = com.google.javascript.jscomp.PropertyRenamingPolicy.ALL_UNQUOTED;
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy0 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.ALL_UNQUOTED + "'", propertyRenamingPolicy0.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.ALL_UNQUOTED));
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        try {
            com.google.javascript.rhino.EcmaError ecmaError3 = com.google.javascript.rhino.ScriptRuntime.typeError2("error reporter", "Unknown class name", "Not declared as a constructor");
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property error reporter");
        } catch (java.lang.RuntimeException e) {
        }
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.brokenClosureRequiresLevel;
        com.google.javascript.jscomp.CheckLevel checkLevel2 = com.google.javascript.jscomp.CheckLevel.WARNING;
        compilerOptions0.checkGlobalNamesLevel = checkLevel2;
        compilerOptions0.computeFunctionSideEffects = true;
        boolean boolean6 = compilerOptions0.removeDeadCode;
        compilerOptions0.setManageClosureDependencies(false);
        compilerOptions0.nameReferenceGraphPath = "";
        boolean boolean11 = compilerOptions0.checkTypes;
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + checkLevel2 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel2.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.FILEOVERVIEW_JSDOC;
        com.google.javascript.jscomp.DiagnosticGroups.INTERNET_EXPLORER_CHECKS = diagnosticGroup0;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray11 = new com.google.javascript.rhino.Node[] { node2, node4, node6, node8, node10 };
        com.google.javascript.rhino.Node node12 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray11);
        java.lang.String str13 = node12.toString();
        try {
            int int15 = node12.getExistingIntProp((int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: FAILED ASSERTION");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(nodeArray11);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "EOF 0" + "'", str13.equals("EOF 0"));
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.NodeTraversal.Callback callback1 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal2 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler0, callback1);
        com.google.javascript.jscomp.JSModule jSModule3 = null;
        try {
            java.lang.String str4 = compiler0.toSource(jSModule3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        int int0 = com.google.javascript.rhino.Node.ATTRIBUTE_FLAG;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray12 = new com.google.javascript.rhino.Node[] { node3, node5, node7, node9, node11 };
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray12);
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node16 = node13.copyInformationFrom(node15);
        com.google.javascript.rhino.Node node17 = node13.getParent();
        com.google.javascript.rhino.Node node18 = new com.google.javascript.rhino.Node((int) (short) -1, node13);
        boolean boolean19 = node13.wasEmptyNode();
        com.google.javascript.rhino.Node node21 = node13.getAncestor(0);
        try {
            node21.setQuotedString();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: FAILED ASSERTION");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertNotNull(nodeArray12);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertNull(node17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(node21);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray13 = new com.google.javascript.rhino.Node[] { node4, node6, node8, node10, node12 };
        com.google.javascript.rhino.Node node14 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray13);
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node21 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray26 = new com.google.javascript.rhino.Node[] { node17, node19, node21, node23, node25 };
        com.google.javascript.rhino.Node node27 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray26);
        com.google.javascript.rhino.Node node28 = new com.google.javascript.rhino.Node(100, node14, node27);
        java.lang.String str29 = closureCodingConvention0.getSingletonGetterClassName(node28);
        com.google.javascript.rhino.Node node35 = com.google.javascript.rhino.Node.newString((int) (short) 0, "hi!", 100, (-2));
        com.google.javascript.rhino.Node node36 = new com.google.javascript.rhino.Node(10, node35);
        java.lang.String str37 = closureCodingConvention0.identifyTypeDefAssign(node36);
        java.lang.Object obj39 = node36.getProp(41);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(nodeArray13);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNotNull(nodeArray26);
        org.junit.Assert.assertNull(str29);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertNull(str37);
        org.junit.Assert.assertNull(obj39);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        int int0 = com.google.javascript.rhino.Node.LEFT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.brokenClosureRequiresLevel;
        com.google.javascript.jscomp.CheckLevel checkLevel2 = com.google.javascript.jscomp.CheckLevel.WARNING;
        compilerOptions0.checkGlobalNamesLevel = checkLevel2;
        compilerOptions0.computeFunctionSideEffects = true;
        compilerOptions0.closurePass = false;
        com.google.javascript.jscomp.CheckLevel checkLevel8 = com.google.javascript.jscomp.CheckLevel.WARNING;
        compilerOptions0.checkFunctions = checkLevel8;
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + checkLevel2 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel2.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
        org.junit.Assert.assertTrue("'" + checkLevel8 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel8.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.brokenClosureRequiresLevel;
        compilerOptions0.setManageClosureDependencies(true);
        java.lang.String[] strArray11 = new java.lang.String[] { "goog.exportProperty", "Not declared as a type name", "error reporter", "DiagnosticGroup<undefinedVars>", "goog.exportProperty", "Not declared as a constructor" };
        java.util.ArrayList<java.lang.String> strList12 = new java.util.ArrayList<java.lang.String>();
        boolean boolean13 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strList12, strArray11);
        compilerOptions0.setReplaceStringsConfiguration("goog.exportProperty", (java.util.List<java.lang.String>) strList12);
        com.google.javascript.jscomp.CheckLevel checkLevel15 = compilerOptions0.aggressiveVarCheck;
        boolean boolean16 = compilerOptions0.allowLegacyJsMessages;
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(strArray11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + checkLevel15 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel15.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray13 = new com.google.javascript.rhino.Node[] { node4, node6, node8, node10, node12 };
        com.google.javascript.rhino.Node node14 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray13);
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node21 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray26 = new com.google.javascript.rhino.Node[] { node17, node19, node21, node23, node25 };
        com.google.javascript.rhino.Node node27 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray26);
        com.google.javascript.rhino.Node node28 = new com.google.javascript.rhino.Node(100, node14, node27);
        boolean boolean29 = closureCodingConvention0.isVarArgsParameter(node28);
        java.lang.String str30 = closureCodingConvention0.getExportPropertyFunction();
        boolean boolean33 = closureCodingConvention0.isExported("goog.exportProperty", false);
        com.google.javascript.rhino.Node node37 = com.google.javascript.rhino.Node.newNumber(100.0d, 4095, 9);
        java.util.Set<java.lang.String> strSet38 = node37.getDirectives();
        boolean boolean39 = closureCodingConvention0.isVarArgsParameter(node37);
        int int40 = node37.getType();
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(nodeArray13);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNotNull(nodeArray26);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "goog.exportProperty" + "'", str30.equals("goog.exportProperty"));
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(node37);
        org.junit.Assert.assertNull(strSet38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 39 + "'", int40 == 39);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        com.google.javascript.jscomp.SourceFile sourceFile5 = com.google.javascript.jscomp.SourceFile.fromCode("goog.exportProperty", "language version", "goog.exportProperty");
        java.io.Reader reader6 = sourceFile5.getCodeReader();
        com.google.javascript.jscomp.CompilerOptions.TweakProcessing tweakProcessing7 = com.google.javascript.jscomp.CompilerOptions.TweakProcessing.OFF;
        com.google.javascript.jscomp.CompilerOptions compilerOptions8 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel9 = compilerOptions8.brokenClosureRequiresLevel;
        java.util.Set<java.lang.String> strSet10 = compilerOptions8.aliasableStrings;
        boolean boolean11 = compilerOptions8.decomposeExpressions;
        boolean boolean12 = compilerOptions8.removeUnusedLocalVars;
        try {
            java.lang.String str13 = com.google.javascript.rhino.ScriptRuntime.getMessage4("", (java.lang.Object) 7, (java.lang.Object) reader6, (java.lang.Object) tweakProcessing7, (java.lang.Object) boolean12);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property ");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(sourceFile5);
        org.junit.Assert.assertNotNull(reader6);
        org.junit.Assert.assertTrue("'" + tweakProcessing7 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TweakProcessing.OFF + "'", tweakProcessing7.equals(com.google.javascript.jscomp.CompilerOptions.TweakProcessing.OFF));
        org.junit.Assert.assertTrue("'" + checkLevel9 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel9.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(strSet10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray0 = new com.google.javascript.jscomp.WarningsGuard[] {};
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard1 = new com.google.javascript.jscomp.ComposeWarningsGuard(warningsGuardArray0);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup2 = com.google.javascript.jscomp.DiagnosticGroups.STRICT_MODULE_DEP_CHECK;
        boolean boolean3 = composeWarningsGuard1.disables(diagnosticGroup2);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup4 = null;
        try {
            boolean boolean5 = composeWarningsGuard1.disables(diagnosticGroup4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(warningsGuardArray0);
        org.junit.Assert.assertNotNull(diagnosticGroup2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        int int0 = com.google.javascript.rhino.Node.SPECIAL_PROP_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 18 + "'", int0 == 18);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray11 = new com.google.javascript.rhino.Node[] { node2, node4, node6, node8, node10 };
        com.google.javascript.rhino.Node node12 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray11);
        com.google.javascript.rhino.Node node13 = node12.getNext();
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention14 = new com.google.javascript.jscomp.ClosureCodingConvention();
        boolean boolean16 = closureCodingConvention14.isConstant("");
        boolean boolean18 = closureCodingConvention14.isValidEnumKey("hi!");
        com.google.javascript.rhino.Node node22 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node24 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node26 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node28 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node30 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray31 = new com.google.javascript.rhino.Node[] { node22, node24, node26, node28, node30 };
        com.google.javascript.rhino.Node node32 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray31);
        com.google.javascript.rhino.Node node34 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node35 = node32.copyInformationFrom(node34);
        com.google.javascript.rhino.Node node36 = node32.getParent();
        com.google.javascript.rhino.Node node37 = new com.google.javascript.rhino.Node((int) (short) -1, node32);
        com.google.javascript.rhino.Node node42 = com.google.javascript.rhino.Node.newString((int) (short) 0, "hi!", 100, (-2));
        boolean boolean43 = node32.isEquivalentTo(node42);
        com.google.javascript.rhino.Node node46 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node48 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node50 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node52 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node54 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray55 = new com.google.javascript.rhino.Node[] { node46, node48, node50, node52, node54 };
        com.google.javascript.rhino.Node node56 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray55);
        com.google.javascript.rhino.Node node58 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node59 = node56.copyInformationFrom(node58);
        com.google.javascript.jscomp.parsing.Config.LanguageMode languageMode61 = com.google.javascript.jscomp.parsing.Config.LanguageMode.ECMASCRIPT5;
        node59.putProp(24, (java.lang.Object) languageMode61);
        java.lang.String str63 = closureCodingConvention14.extractClassNameIfRequire(node32, node59);
        com.google.javascript.rhino.Node node69 = com.google.javascript.rhino.Node.newString((int) (short) 0, "hi!", 100, (-2));
        com.google.javascript.rhino.Node node70 = new com.google.javascript.rhino.Node(10, node69);
        node69.setLineno((-1));
        try {
            node12.replaceChildAfter(node59, node69);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: prev is not a child of this node.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(nodeArray11);
        org.junit.Assert.assertNull(node13);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertNotNull(node30);
        org.junit.Assert.assertNotNull(nodeArray31);
        org.junit.Assert.assertNotNull(node34);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertNull(node36);
        org.junit.Assert.assertNotNull(node42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(node46);
        org.junit.Assert.assertNotNull(node48);
        org.junit.Assert.assertNotNull(node50);
        org.junit.Assert.assertNotNull(node52);
        org.junit.Assert.assertNotNull(node54);
        org.junit.Assert.assertNotNull(nodeArray55);
        org.junit.Assert.assertNotNull(node58);
        org.junit.Assert.assertNotNull(node59);
        org.junit.Assert.assertTrue("'" + languageMode61 + "' != '" + com.google.javascript.jscomp.parsing.Config.LanguageMode.ECMASCRIPT5 + "'", languageMode61.equals(com.google.javascript.jscomp.parsing.Config.LanguageMode.ECMASCRIPT5));
        org.junit.Assert.assertNull(str63);
        org.junit.Assert.assertNotNull(node69);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray12 = new com.google.javascript.rhino.Node[] { node3, node5, node7, node9, node11 };
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray12);
        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node22 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node24 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray25 = new com.google.javascript.rhino.Node[] { node16, node18, node20, node22, node24 };
        com.google.javascript.rhino.Node node26 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray25);
        com.google.javascript.rhino.Node node27 = new com.google.javascript.rhino.Node(100, node13, node26);
        com.google.javascript.rhino.Node node29 = node13.getAncestor(9);
        com.google.javascript.rhino.Node node33 = com.google.javascript.rhino.Node.newNumber(0.0d, (int) (short) 1, (int) ' ');
        int int35 = node33.getIntProp(10);
        com.google.javascript.rhino.Node node41 = com.google.javascript.rhino.Node.newString((int) (short) 0, "hi!", 100, (-2));
        com.google.javascript.rhino.Node node42 = new com.google.javascript.rhino.Node(10, node41);
        try {
            node29.addChildAfter(node33, node41);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertNotNull(nodeArray12);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertNotNull(nodeArray25);
        org.junit.Assert.assertNull(node29);
        org.junit.Assert.assertNotNull(node33);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
        org.junit.Assert.assertNotNull(node41);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray11 = new com.google.javascript.rhino.Node[] { node2, node4, node6, node8, node10 };
        com.google.javascript.rhino.Node node12 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray11);
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node15 = node12.copyInformationFrom(node14);
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.Node.newNumber(100.0d, 4095, 9);
        node15.addChildToBack(node19);
        try {
            node19.setSideEffectFlags((int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: setIsNoSideEffectsCall only supports CALL and NEW nodes, got NUMBER");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(nodeArray11);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertNotNull(node19);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        int int0 = com.google.javascript.rhino.Node.INCRDECR_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 31 + "'", int0 == 31);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = null;
        com.google.javascript.jscomp.DiagnosticGroups.UNKNOWN_DEFINES = diagnosticGroup0;
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray13 = new com.google.javascript.rhino.Node[] { node4, node6, node8, node10, node12 };
        com.google.javascript.rhino.Node node14 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray13);
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node21 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray26 = new com.google.javascript.rhino.Node[] { node17, node19, node21, node23, node25 };
        com.google.javascript.rhino.Node node27 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray26);
        com.google.javascript.rhino.Node node28 = new com.google.javascript.rhino.Node(100, node14, node27);
        java.lang.String str29 = closureCodingConvention0.getSingletonGetterClassName(node28);
        boolean boolean31 = closureCodingConvention0.isValidEnumKey("");
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(nodeArray13);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNotNull(nodeArray26);
        org.junit.Assert.assertNull(str29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        com.google.javascript.jscomp.AnonymousFunctionNamingPolicy anonymousFunctionNamingPolicy0 = com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.UNMAPPED;
        org.junit.Assert.assertTrue("'" + anonymousFunctionNamingPolicy0 + "' != '" + com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.UNMAPPED + "'", anonymousFunctionNamingPolicy0.equals(com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.UNMAPPED));
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        boolean boolean2 = closureCodingConvention0.isConstant("");
        boolean boolean4 = closureCodingConvention0.isValidEnumKey("hi!");
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray17 = new com.google.javascript.rhino.Node[] { node8, node10, node12, node14, node16 };
        com.google.javascript.rhino.Node node18 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray17);
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node21 = node18.copyInformationFrom(node20);
        com.google.javascript.rhino.Node node22 = node18.getParent();
        com.google.javascript.rhino.Node node23 = new com.google.javascript.rhino.Node((int) (short) -1, node18);
        com.google.javascript.rhino.Node node28 = com.google.javascript.rhino.Node.newString((int) (short) 0, "hi!", 100, (-2));
        boolean boolean29 = node18.isEquivalentTo(node28);
        com.google.javascript.rhino.Node node32 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node34 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node36 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node38 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node40 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray41 = new com.google.javascript.rhino.Node[] { node32, node34, node36, node38, node40 };
        com.google.javascript.rhino.Node node42 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray41);
        com.google.javascript.rhino.Node node44 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node45 = node42.copyInformationFrom(node44);
        com.google.javascript.jscomp.parsing.Config.LanguageMode languageMode47 = com.google.javascript.jscomp.parsing.Config.LanguageMode.ECMASCRIPT5;
        node45.putProp(24, (java.lang.Object) languageMode47);
        java.lang.String str49 = closureCodingConvention0.extractClassNameIfRequire(node18, node45);
        try {
            com.google.javascript.rhino.Node node50 = com.google.javascript.jscomp.NodeUtil.newExpr(node18);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: new child has existing parent");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertNotNull(nodeArray17);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertNull(node22);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(node32);
        org.junit.Assert.assertNotNull(node34);
        org.junit.Assert.assertNotNull(node36);
        org.junit.Assert.assertNotNull(node38);
        org.junit.Assert.assertNotNull(node40);
        org.junit.Assert.assertNotNull(nodeArray41);
        org.junit.Assert.assertNotNull(node44);
        org.junit.Assert.assertNotNull(node45);
        org.junit.Assert.assertTrue("'" + languageMode47 + "' != '" + com.google.javascript.jscomp.parsing.Config.LanguageMode.ECMASCRIPT5 + "'", languageMode47.equals(com.google.javascript.jscomp.parsing.Config.LanguageMode.ECMASCRIPT5));
        org.junit.Assert.assertNull(str49);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newNumber(0.0d, (int) (short) 1, (int) ' ');
        node3.setOptionalArg(true);
        try {
            node3.setSideEffectFlags(11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: setIsNoSideEffectsCall only supports CALL and NEW nodes, got NUMBER");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node3);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        com.google.javascript.jscomp.SourceFile sourceFile3 = com.google.javascript.jscomp.SourceFile.fromCode("Not declared as a type name", "Not declared as a constructor", "language version");
        org.junit.Assert.assertNotNull(sourceFile3);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.NodeTraversal.Callback callback1 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal2 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler0, callback1);
        try {
            com.google.javascript.jscomp.JSModule jSModule3 = nodeTraversal2.getModule();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile1 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.CompilerInput compilerInput2 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile1);
        com.google.javascript.jscomp.CompilerInput compilerInput5 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput2, "hi!", false);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile7 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        compilerInput2.setSourceFile((com.google.javascript.jscomp.SourceFile) jSSourceFile7);
        jSSourceFile7.clearCachedSource();
        org.junit.Assert.assertNotNull(jSSourceFile1);
        org.junit.Assert.assertNotNull(jSSourceFile7);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        java.nio.charset.Charset charset1 = null;
        com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromFile("", charset1);
        java.lang.String str3 = sourceFile2.toString();
        org.junit.Assert.assertNotNull(sourceFile2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile3 = com.google.javascript.jscomp.JSSourceFile.fromFile("Not declared as a constructor");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile5 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.CompilerInput compilerInput6 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile5);
        com.google.javascript.jscomp.CompilerInput compilerInput9 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput6, "hi!", false);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile11 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        compilerInput6.setSourceFile((com.google.javascript.jscomp.SourceFile) jSSourceFile11);
        java.lang.String str13 = jSSourceFile11.toString();
        com.google.javascript.jscomp.CompilerOptions compilerOptions14 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean15 = compilerOptions14.aliasAllStrings;
        compilerOptions14.setGenerateExports(true);
        com.google.javascript.jscomp.Result result18 = compiler1.compile(jSSourceFile3, jSSourceFile11, compilerOptions14);
        boolean boolean19 = compilerOptions14.checkUnusedPropertiesEarly;
        org.junit.Assert.assertNotNull(jSSourceFile3);
        org.junit.Assert.assertNotNull(jSSourceFile5);
        org.junit.Assert.assertNotNull(jSSourceFile11);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(result18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile5 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.CompilerInput compilerInput6 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile5);
        com.google.javascript.jscomp.CompilerInput compilerInput9 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput6, "hi!", false);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile11 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        compilerInput6.setSourceFile((com.google.javascript.jscomp.SourceFile) jSSourceFile11);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile14 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray15 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile2, jSSourceFile11, jSSourceFile14 };
        java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList16 = new java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile>();
        boolean boolean17 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList16, jSSourceFileArray15);
        com.google.javascript.jscomp.JSModule[] jSModuleArray18 = new com.google.javascript.jscomp.JSModule[] {};
        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList19 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
        boolean boolean20 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList19, jSModuleArray18);
        com.google.javascript.jscomp.CompilerOptions compilerOptions21 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions21.checkDuplicateMessages = false;
        boolean boolean24 = compilerOptions21.inlineAnonymousFunctionExpressions;
        compilerOptions21.crossModuleMethodMotion = true;
        com.google.javascript.jscomp.Result result27 = compiler0.compileModules((java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList16, (java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList19, compilerOptions21);
        try {
            compiler0.normalize();
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: INTERNAL COMPILER ERROR.\nPlease report this problem.\nnull");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile2);
        org.junit.Assert.assertNotNull(jSSourceFile5);
        org.junit.Assert.assertNotNull(jSSourceFile11);
        org.junit.Assert.assertNotNull(jSSourceFile14);
        org.junit.Assert.assertNotNull(jSSourceFileArray15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(jSModuleArray18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(result27);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.brokenClosureRequiresLevel;
        com.google.javascript.jscomp.CheckLevel checkLevel2 = com.google.javascript.jscomp.CheckLevel.WARNING;
        compilerOptions0.checkGlobalNamesLevel = checkLevel2;
        compilerOptions0.computeFunctionSideEffects = true;
        boolean boolean6 = compilerOptions0.removeDeadCode;
        compilerOptions0.inlineVariables = true;
        com.google.javascript.jscomp.CompilerOptions compilerOptions9 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel10 = compilerOptions9.brokenClosureRequiresLevel;
        com.google.javascript.jscomp.CheckLevel checkLevel11 = com.google.javascript.jscomp.CheckLevel.WARNING;
        compilerOptions9.checkGlobalNamesLevel = checkLevel11;
        compilerOptions9.computeFunctionSideEffects = true;
        boolean boolean15 = compilerOptions9.removeDeadCode;
        compilerOptions9.removeDeadCode = false;
        com.google.javascript.jscomp.CheckLevel checkLevel18 = com.google.javascript.jscomp.CheckLevel.OFF;
        compilerOptions9.checkRequires = checkLevel18;
        compilerOptions9.setShadowVariables(true);
        java.lang.RuntimeException runtimeException22 = com.google.javascript.rhino.ScriptRuntime.undefCallError((java.lang.Object) true, (java.lang.Object) true);
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + checkLevel2 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel2.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + checkLevel10 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel10.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + checkLevel11 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel11.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + checkLevel18 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel18.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(runtimeException22);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.brokenClosureRequiresLevel;
        com.google.javascript.jscomp.CheckLevel checkLevel2 = com.google.javascript.jscomp.CheckLevel.WARNING;
        compilerOptions0.checkGlobalNamesLevel = checkLevel2;
        compilerOptions0.computeFunctionSideEffects = true;
        compilerOptions0.setShadowVariables(true);
        compilerOptions0.debugFunctionSideEffectsPath = "goog.global";
        compilerOptions0.setNameAnonymousFunctionsOnly(false);
        compilerOptions0.setShadowVariables(false);
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + checkLevel2 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel2.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile5 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.CompilerInput compilerInput6 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile5);
        com.google.javascript.jscomp.CompilerInput compilerInput9 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput6, "hi!", false);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile11 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        compilerInput6.setSourceFile((com.google.javascript.jscomp.SourceFile) jSSourceFile11);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile14 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray15 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile2, jSSourceFile11, jSSourceFile14 };
        java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList16 = new java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile>();
        boolean boolean17 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList16, jSSourceFileArray15);
        com.google.javascript.jscomp.JSModule[] jSModuleArray18 = new com.google.javascript.jscomp.JSModule[] {};
        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList19 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
        boolean boolean20 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList19, jSModuleArray18);
        com.google.javascript.jscomp.CompilerOptions compilerOptions21 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions21.checkDuplicateMessages = false;
        boolean boolean24 = compilerOptions21.inlineAnonymousFunctionExpressions;
        compilerOptions21.crossModuleMethodMotion = true;
        com.google.javascript.jscomp.Result result27 = compiler0.compileModules((java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList16, (java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList19, compilerOptions21);
        com.google.javascript.jscomp.ErrorManager errorManager28 = compiler0.getErrorManager();
        com.google.javascript.jscomp.Compiler compiler29 = new com.google.javascript.jscomp.Compiler(errorManager28);
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray30 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile32 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.CompilerInput compilerInput33 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile32);
        com.google.javascript.jscomp.CompilerInput compilerInput36 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput33, "hi!", false);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile38 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        compilerInput33.setSourceFile((com.google.javascript.jscomp.SourceFile) jSSourceFile38);
        jSSourceFile38.clearCachedSource();
        java.io.PrintStream printStream41 = null;
        com.google.javascript.jscomp.Compiler compiler42 = new com.google.javascript.jscomp.Compiler(printStream41);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile44 = com.google.javascript.jscomp.JSSourceFile.fromFile("Not declared as a constructor");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile46 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.CompilerInput compilerInput47 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile46);
        com.google.javascript.jscomp.CompilerInput compilerInput50 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput47, "hi!", false);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile52 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        compilerInput47.setSourceFile((com.google.javascript.jscomp.SourceFile) jSSourceFile52);
        java.lang.String str54 = jSSourceFile52.toString();
        com.google.javascript.jscomp.CompilerOptions compilerOptions55 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean56 = compilerOptions55.aliasAllStrings;
        compilerOptions55.setGenerateExports(true);
        com.google.javascript.jscomp.Result result59 = compiler42.compile(jSSourceFile44, jSSourceFile52, compilerOptions55);
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray60 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile38, jSSourceFile52 };
        com.google.javascript.jscomp.CompilerOptions compilerOptions61 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel62 = compilerOptions61.brokenClosureRequiresLevel;
        java.util.Map<java.lang.String, com.google.javascript.rhino.Node> strMap63 = compilerOptions61.getDefineReplacements();
        try {
            com.google.javascript.jscomp.Result result64 = compiler29.compile(jSSourceFileArray30, jSSourceFileArray60, compilerOptions61);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile2);
        org.junit.Assert.assertNotNull(jSSourceFile5);
        org.junit.Assert.assertNotNull(jSSourceFile11);
        org.junit.Assert.assertNotNull(jSSourceFile14);
        org.junit.Assert.assertNotNull(jSSourceFileArray15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(jSModuleArray18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(result27);
        org.junit.Assert.assertNotNull(errorManager28);
        org.junit.Assert.assertNotNull(jSSourceFile32);
        org.junit.Assert.assertNotNull(jSSourceFile38);
        org.junit.Assert.assertNotNull(jSSourceFile44);
        org.junit.Assert.assertNotNull(jSSourceFile46);
        org.junit.Assert.assertNotNull(jSSourceFile52);
        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "" + "'", str54.equals(""));
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertNotNull(result59);
        org.junit.Assert.assertNotNull(jSSourceFileArray60);
        org.junit.Assert.assertTrue("'" + checkLevel62 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel62.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(strMap63);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray13 = new com.google.javascript.rhino.Node[] { node4, node6, node8, node10, node12 };
        com.google.javascript.rhino.Node node14 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray13);
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node21 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray26 = new com.google.javascript.rhino.Node[] { node17, node19, node21, node23, node25 };
        com.google.javascript.rhino.Node node27 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray26);
        com.google.javascript.rhino.Node node28 = new com.google.javascript.rhino.Node(100, node14, node27);
        boolean boolean29 = closureCodingConvention0.isVarArgsParameter(node28);
        java.lang.String str30 = closureCodingConvention0.getExportPropertyFunction();
        com.google.javascript.rhino.Node node31 = null;
        try {
            java.util.List<java.lang.String> strList32 = closureCodingConvention0.identifyTypeDeclarationCall(node31);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(nodeArray13);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNotNull(nodeArray26);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "goog.exportProperty" + "'", str30.equals("goog.exportProperty"));
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray13 = new com.google.javascript.rhino.Node[] { node4, node6, node8, node10, node12 };
        com.google.javascript.rhino.Node node14 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray13);
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node21 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray26 = new com.google.javascript.rhino.Node[] { node17, node19, node21, node23, node25 };
        com.google.javascript.rhino.Node node27 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray26);
        com.google.javascript.rhino.Node node28 = new com.google.javascript.rhino.Node(100, node14, node27);
        boolean boolean29 = closureCodingConvention0.isVarArgsParameter(node28);
        java.lang.String str30 = closureCodingConvention0.getExportPropertyFunction();
        boolean boolean33 = closureCodingConvention0.isExported("goog.exportProperty", false);
        com.google.javascript.rhino.Node node37 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node39 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node41 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node43 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node45 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray46 = new com.google.javascript.rhino.Node[] { node37, node39, node41, node43, node45 };
        com.google.javascript.rhino.Node node47 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray46);
        com.google.javascript.rhino.Node node49 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node50 = node47.copyInformationFrom(node49);
        com.google.javascript.rhino.Node node51 = node47.getParent();
        com.google.javascript.rhino.Node node52 = new com.google.javascript.rhino.Node((int) (short) -1, node47);
        com.google.javascript.rhino.Node node57 = com.google.javascript.rhino.Node.newString((int) (short) 0, "hi!", 100, (-2));
        boolean boolean58 = node47.isEquivalentTo(node57);
        int int60 = node57.getIntProp(28);
        try {
            boolean boolean61 = closureCodingConvention0.isPropertyTestFunction(node57);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(nodeArray13);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNotNull(nodeArray26);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "goog.exportProperty" + "'", str30.equals("goog.exportProperty"));
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(node37);
        org.junit.Assert.assertNotNull(node39);
        org.junit.Assert.assertNotNull(node41);
        org.junit.Assert.assertNotNull(node43);
        org.junit.Assert.assertNotNull(node45);
        org.junit.Assert.assertNotNull(nodeArray46);
        org.junit.Assert.assertNotNull(node49);
        org.junit.Assert.assertNotNull(node50);
        org.junit.Assert.assertNull(node51);
        org.junit.Assert.assertNotNull(node57);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 0 + "'", int60 == 0);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        com.google.javascript.rhino.Node.SideEffectFlags sideEffectFlags1 = new com.google.javascript.rhino.Node.SideEffectFlags(17);
        sideEffectFlags1.setAllFlags();
        int int3 = sideEffectFlags1.valueOf();
        sideEffectFlags1.setReturnsTainted();
        sideEffectFlags1.setAllFlags();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        int int0 = com.google.javascript.rhino.Node.OPT_ARG_NAME;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 36 + "'", int0 == 36);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.brokenClosureRequiresLevel;
        compilerOptions0.setManageClosureDependencies(true);
        compilerOptions0.inlineLocalVariables = true;
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.brokenClosureRequiresLevel;
        com.google.javascript.jscomp.CheckLevel checkLevel2 = com.google.javascript.jscomp.CheckLevel.WARNING;
        compilerOptions0.checkGlobalNamesLevel = checkLevel2;
        compilerOptions0.computeFunctionSideEffects = true;
        compilerOptions0.setDefineToStringLiteral("", "Unknown class name");
        compilerOptions0.checkTypedPropertyCalls = true;
        compilerOptions0.tightenTypes = false;
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + checkLevel2 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel2.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        int int0 = com.google.javascript.rhino.Node.FUNCTION_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 5 + "'", int0 == 5);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.brokenClosureRequiresLevel;
        compilerOptions0.setManageClosureDependencies(true);
        java.lang.String[] strArray11 = new java.lang.String[] { "goog.exportProperty", "Not declared as a type name", "error reporter", "DiagnosticGroup<undefinedVars>", "goog.exportProperty", "Not declared as a constructor" };
        java.util.ArrayList<java.lang.String> strList12 = new java.util.ArrayList<java.lang.String>();
        boolean boolean13 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strList12, strArray11);
        compilerOptions0.setReplaceStringsConfiguration("goog.exportProperty", (java.util.List<java.lang.String>) strList12);
        compilerOptions0.reportPath = "1";
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(strArray11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray11 = new com.google.javascript.rhino.Node[] { node2, node4, node6, node8, node10 };
        com.google.javascript.rhino.Node node12 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray11);
        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node22 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node24 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray25 = new com.google.javascript.rhino.Node[] { node16, node18, node20, node22, node24 };
        com.google.javascript.rhino.Node node26 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray25);
        com.google.javascript.rhino.Node node28 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node29 = node26.copyInformationFrom(node28);
        com.google.javascript.rhino.Node node30 = node26.getParent();
        com.google.javascript.rhino.Node node31 = new com.google.javascript.rhino.Node((int) (short) -1, node26);
        com.google.javascript.rhino.Node node36 = com.google.javascript.rhino.Node.newString((int) (short) 0, "hi!", 100, (-2));
        boolean boolean37 = node26.isEquivalentTo(node36);
        com.google.javascript.rhino.Node node38 = node12.clonePropsFrom(node36);
        boolean boolean39 = node36.isLocalResultCall();
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(nodeArray11);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertNotNull(nodeArray25);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNull(node30);
        org.junit.Assert.assertNotNull(node36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(node38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.NodeTraversal.Callback callback1 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal2 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler0, callback1);
        try {
            com.google.javascript.jscomp.Result result3 = compiler0.getResult();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.aliasAllStrings;
        compilerOptions0.setGenerateExports(true);
        compilerOptions0.setDefineToStringLiteral("JSC_OPTIMIZE_LOOP_ERROR", "1");
        compilerOptions0.foldConstants = true;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        int int0 = com.google.javascript.rhino.Node.CASEARRAY_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 15 + "'", int0 == 15);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        int int0 = com.google.javascript.rhino.Node.FINALLY_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 20 + "'", int0 == 20);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2);
        com.google.javascript.jscomp.CompilerInput compilerInput6 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput3, "hi!", false);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile8 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        compilerInput3.setSourceFile((com.google.javascript.jscomp.SourceFile) jSSourceFile8);
        com.google.javascript.jscomp.CompilerInput compilerInput10 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput3);
        java.lang.Object obj11 = null;
        try {
            java.lang.String str12 = com.google.javascript.rhino.ScriptRuntime.getMessage2("", (java.lang.Object) compilerInput10, obj11);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property ");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile2);
        org.junit.Assert.assertNotNull(jSSourceFile8);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        int int0 = com.google.javascript.rhino.Node.SOURCENAME_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 16 + "'", int0 == 16);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.brokenClosureRequiresLevel;
        com.google.javascript.jscomp.CheckLevel checkLevel2 = com.google.javascript.jscomp.CheckLevel.WARNING;
        compilerOptions0.checkGlobalNamesLevel = checkLevel2;
        compilerOptions0.computeFunctionSideEffects = true;
        boolean boolean6 = compilerOptions0.removeDeadCode;
        com.google.javascript.jscomp.CompilerOptions.TweakProcessing tweakProcessing7 = compilerOptions0.getTweakProcessing();
        compilerOptions0.checkDuplicateMessages = false;
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + checkLevel2 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel2.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + tweakProcessing7 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TweakProcessing.OFF + "'", tweakProcessing7.equals(com.google.javascript.jscomp.CompilerOptions.TweakProcessing.OFF));
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        long long1 = com.google.javascript.rhino.ScriptRuntime.testUint32String("{0}");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1L) + "'", long1 == (-1L));
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.brokenClosureRequiresLevel;
        com.google.javascript.jscomp.CheckLevel checkLevel2 = com.google.javascript.jscomp.CheckLevel.WARNING;
        compilerOptions0.checkGlobalNamesLevel = checkLevel2;
        compilerOptions0.computeFunctionSideEffects = true;
        boolean boolean6 = compilerOptions0.removeDeadCode;
        com.google.javascript.jscomp.SourceMap.DetailLevel detailLevel7 = null;
        compilerOptions0.sourceMapDetailLevel = detailLevel7;
        boolean boolean9 = compilerOptions0.prettyPrint;
        compilerOptions0.aliasKeywords = false;
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + checkLevel2 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel2.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray12 = new com.google.javascript.rhino.Node[] { node3, node5, node7, node9, node11 };
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray12);
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node16 = node13.copyInformationFrom(node15);
        com.google.javascript.rhino.Node node17 = node13.getParent();
        com.google.javascript.rhino.Node node18 = new com.google.javascript.rhino.Node((int) (short) -1, node13);
        com.google.javascript.rhino.Node.SideEffectFlags sideEffectFlags20 = new com.google.javascript.rhino.Node.SideEffectFlags(17);
        sideEffectFlags20.setAllFlags();
        int int22 = sideEffectFlags20.valueOf();
        sideEffectFlags20.setReturnsTainted();
        sideEffectFlags20.clearAllFlags();
        try {
            node18.setSideEffectFlags(sideEffectFlags20);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: setIsNoSideEffectsCall only supports CALL and NEW nodes, got ERROR");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertNotNull(nodeArray12);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertNull(node17);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        try {
            com.google.javascript.rhino.EcmaError ecmaError4 = com.google.javascript.rhino.ScriptRuntime.typeError3("", "Not declared as a constructor", "", "TypeError: ");
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property ");
        } catch (java.lang.RuntimeException e) {
        }
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.NodeTraversal.Callback callback1 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal2 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler0, callback1);
        compiler0.disableThreads();
        com.google.javascript.jscomp.PassConfig passConfig4 = null;
        try {
            compiler0.setPassConfig(passConfig4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.brokenClosureRequiresLevel;
        compilerOptions0.setManageClosureDependencies(true);
        java.lang.String[] strArray11 = new java.lang.String[] { "goog.exportProperty", "Not declared as a type name", "error reporter", "DiagnosticGroup<undefinedVars>", "goog.exportProperty", "Not declared as a constructor" };
        java.util.ArrayList<java.lang.String> strList12 = new java.util.ArrayList<java.lang.String>();
        boolean boolean13 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strList12, strArray11);
        compilerOptions0.setReplaceStringsConfiguration("goog.exportProperty", (java.util.List<java.lang.String>) strList12);
        compilerOptions0.ideMode = false;
        compilerOptions0.lineLengthThreshold((int) (short) 100);
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(strArray11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newNumber(100.0d, 4095, 9);
        java.util.Set<java.lang.String> strSet5 = node4.getDirectives();
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray17 = new com.google.javascript.rhino.Node[] { node8, node10, node12, node14, node16 };
        com.google.javascript.rhino.Node node18 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray17);
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node21 = node18.copyInformationFrom(node20);
        com.google.javascript.rhino.Node node24 = new com.google.javascript.rhino.Node(28, node4, node18, (-2), (int) (byte) -1);
        com.google.javascript.rhino.Node node28 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node30 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node32 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node34 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node36 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray37 = new com.google.javascript.rhino.Node[] { node28, node30, node32, node34, node36 };
        com.google.javascript.rhino.Node node38 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray37);
        com.google.javascript.rhino.Node node40 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node41 = node38.copyInformationFrom(node40);
        com.google.javascript.rhino.Node node42 = node38.getParent();
        com.google.javascript.rhino.Node node43 = new com.google.javascript.rhino.Node((int) (short) -1, node38);
        com.google.javascript.rhino.Node node48 = com.google.javascript.rhino.Node.newString((int) (short) 0, "hi!", 100, (-2));
        boolean boolean49 = node38.isEquivalentTo(node48);
        int int51 = node48.getIntProp(28);
        com.google.javascript.rhino.Node node52 = null;
        try {
            node4.addChildBefore(node48, node52);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The existing child node of the parent should not be null.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNull(strSet5);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertNotNull(nodeArray17);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertNotNull(node30);
        org.junit.Assert.assertNotNull(node32);
        org.junit.Assert.assertNotNull(node34);
        org.junit.Assert.assertNotNull(node36);
        org.junit.Assert.assertNotNull(nodeArray37);
        org.junit.Assert.assertNotNull(node40);
        org.junit.Assert.assertNotNull(node41);
        org.junit.Assert.assertNull(node42);
        org.junit.Assert.assertNotNull(node48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 0 + "'", int51 == 0);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.NodeTraversal.Callback callback1 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal2 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler0, callback1);
        try {
            com.google.javascript.rhino.Node node3 = nodeTraversal2.getScopeRoot();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        java.io.InputStream inputStream1 = null;
        try {
            com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromInputStream("Unknown class name", inputStream1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        int int0 = com.google.javascript.rhino.Context.VERSION_UNKNOWN;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + (-1) + "'", int0 == (-1));
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.NodeTraversal.Callback callback1 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal2 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler0, callback1);
        try {
            com.google.javascript.jscomp.CodingConvention codingConvention3 = compiler0.getCodingConvention();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        com.google.javascript.jscomp.AbstractCompiler abstractCompiler0 = null;
        com.google.javascript.jscomp.NodeTraversal.Callback callback1 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal2 = new com.google.javascript.jscomp.NodeTraversal(abstractCompiler0, callback1);
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray14 = new com.google.javascript.rhino.Node[] { node5, node7, node9, node11, node13 };
        com.google.javascript.rhino.Node node15 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray14);
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node18 = node15.copyInformationFrom(node17);
        com.google.javascript.jscomp.parsing.Config.LanguageMode languageMode20 = com.google.javascript.jscomp.parsing.Config.LanguageMode.ECMASCRIPT5;
        node18.putProp(24, (java.lang.Object) languageMode20);
        com.google.javascript.jscomp.AbstractCompiler abstractCompiler22 = null;
        com.google.javascript.jscomp.NodeTraversal.Callback callback23 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal24 = new com.google.javascript.jscomp.NodeTraversal(abstractCompiler22, callback23);
        com.google.javascript.rhino.Node node27 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node29 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node31 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node33 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node35 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray36 = new com.google.javascript.rhino.Node[] { node27, node29, node31, node33, node35 };
        com.google.javascript.rhino.Node node37 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray36);
        com.google.javascript.rhino.Node node39 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node40 = node37.copyInformationFrom(node39);
        com.google.javascript.rhino.Node node41 = node39.getLastSibling();
        com.google.javascript.jscomp.CompilerOptions compilerOptions42 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel43 = compilerOptions42.brokenClosureRequiresLevel;
        com.google.javascript.jscomp.CheckLevel checkLevel44 = com.google.javascript.jscomp.CheckLevel.WARNING;
        compilerOptions42.checkGlobalNamesLevel = checkLevel44;
        compilerOptions42.computeFunctionSideEffects = true;
        com.google.javascript.jscomp.CheckLevel checkLevel48 = compilerOptions42.checkGlobalThisLevel;
        com.google.javascript.jscomp.DiagnosticType diagnosticType49 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        com.google.javascript.rhino.Node node55 = com.google.javascript.rhino.Node.newString((int) (short) 0, "hi!", 100, (-2));
        com.google.javascript.jscomp.DiagnosticType diagnosticType56 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray57 = com.google.javascript.rhino.ScriptRuntime.emptyStrings;
        com.google.javascript.jscomp.JSError jSError58 = com.google.javascript.jscomp.JSError.make("", node55, diagnosticType56, strArray57);
        com.google.javascript.jscomp.JSError jSError59 = nodeTraversal24.makeError(node41, checkLevel48, diagnosticType49, strArray57);
        com.google.javascript.jscomp.CheckLevel checkLevel60 = null;
        diagnosticType49.level = checkLevel60;
        java.lang.String[] strArray63 = new java.lang.String[] { "{0}" };
        try {
            nodeTraversal2.report(node18, diagnosticType49, strArray63);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(nodeArray14);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertTrue("'" + languageMode20 + "' != '" + com.google.javascript.jscomp.parsing.Config.LanguageMode.ECMASCRIPT5 + "'", languageMode20.equals(com.google.javascript.jscomp.parsing.Config.LanguageMode.ECMASCRIPT5));
        org.junit.Assert.assertNotNull(node27);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertNotNull(node33);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertNotNull(nodeArray36);
        org.junit.Assert.assertNotNull(node39);
        org.junit.Assert.assertNotNull(node40);
        org.junit.Assert.assertNotNull(node41);
        org.junit.Assert.assertTrue("'" + checkLevel43 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel43.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + checkLevel44 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel44.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
        org.junit.Assert.assertTrue("'" + checkLevel48 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel48.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(diagnosticType49);
        org.junit.Assert.assertNotNull(node55);
        org.junit.Assert.assertNotNull(diagnosticType56);
        org.junit.Assert.assertNotNull(strArray57);
        org.junit.Assert.assertNotNull(jSError58);
        org.junit.Assert.assertNotNull(jSError59);
        org.junit.Assert.assertNotNull(strArray63);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.brokenClosureRequiresLevel;
        com.google.javascript.jscomp.CheckLevel checkLevel2 = com.google.javascript.jscomp.CheckLevel.WARNING;
        compilerOptions0.checkGlobalNamesLevel = checkLevel2;
        compilerOptions0.computeFunctionSideEffects = true;
        compilerOptions0.closurePass = false;
        boolean boolean8 = compilerOptions0.crossModuleMethodMotion;
        compilerOptions0.ignoreCajaProperties = true;
        compilerOptions0.syntheticBlockEndMarker = "";
        boolean boolean13 = compilerOptions0.reserveRawExports;
        boolean boolean14 = compilerOptions0.ignoreCajaProperties;
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + checkLevel2 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel2.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        int int0 = com.google.javascript.rhino.Node.LABEL_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 19 + "'", int0 == 19);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile1 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.CompilerInput compilerInput2 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile1);
        com.google.javascript.jscomp.CompilerInput compilerInput5 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput2, "hi!", false);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile7 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        compilerInput2.setSourceFile((com.google.javascript.jscomp.SourceFile) jSSourceFile7);
        java.lang.String str9 = jSSourceFile7.toString();
        try {
            java.lang.String str10 = jSSourceFile7.getCode();
            org.junit.Assert.fail("Expected exception of type java.io.FileNotFoundException; message:  (No such file or directory)");
        } catch (java.io.FileNotFoundException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile1);
        org.junit.Assert.assertNotNull(jSSourceFile7);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        int int0 = com.google.javascript.rhino.Node.IS_OPTIONAL_PARAM;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 43 + "'", int0 == 43);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.UNKNOWN_DEFINES;
        com.google.javascript.jscomp.DiagnosticGroups.UNDEFINED_VARIABLES = diagnosticGroup0;
        org.junit.Assert.assertNull(diagnosticGroup0);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray13 = new com.google.javascript.rhino.Node[] { node4, node6, node8, node10, node12 };
        com.google.javascript.rhino.Node node14 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray13);
        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node17 = node14.copyInformationFrom(node16);
        com.google.javascript.rhino.Node node18 = node14.getParent();
        com.google.javascript.rhino.Node node19 = new com.google.javascript.rhino.Node((int) (short) -1, node14);
        node14.detachChildren();
        try {
            com.google.javascript.rhino.Node node23 = new com.google.javascript.rhino.Node(29, node14, 2, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: new child has existing parent");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(nodeArray13);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNull(node18);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newString((int) (short) 0, "hi!", 100, (-2));
        com.google.javascript.rhino.Node node6 = new com.google.javascript.rhino.Node(10, node5);
        node5.setLineno((-1));
        com.google.javascript.rhino.JSDocInfo jSDocInfo9 = null;
        node5.setJSDocInfo(jSDocInfo9);
        org.junit.Assert.assertNotNull(node5);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.checkDuplicateMessages = false;
        boolean boolean3 = compilerOptions0.inlineAnonymousFunctionExpressions;
        compilerOptions0.recordFunctionInformation = true;
        boolean boolean6 = compilerOptions0.checkCaja;
        compilerOptions0.aliasableGlobals = "EOF 0";
        boolean boolean9 = compilerOptions0.removeEmptyFunctions;
        compilerOptions0.exportTestFunctions = true;
        boolean boolean12 = compilerOptions0.moveFunctionDeclarations;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray13 = new com.google.javascript.rhino.Node[] { node4, node6, node8, node10, node12 };
        com.google.javascript.rhino.Node node14 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray13);
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node21 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray26 = new com.google.javascript.rhino.Node[] { node17, node19, node21, node23, node25 };
        com.google.javascript.rhino.Node node27 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray26);
        com.google.javascript.rhino.Node node28 = new com.google.javascript.rhino.Node(100, node14, node27);
        boolean boolean29 = closureCodingConvention0.isVarArgsParameter(node28);
        java.util.Collection<com.google.javascript.jscomp.CodingConvention.AssertionFunctionSpec> assertionFunctionSpecCollection30 = closureCodingConvention0.getAssertionFunctions();
        com.google.javascript.jscomp.NodeTraversal nodeTraversal31 = null;
        com.google.javascript.rhino.Node node32 = null;
        try {
            com.google.javascript.jscomp.CodingConvention.ObjectLiteralCast objectLiteralCast33 = closureCodingConvention0.getObjectLiteralCast(nodeTraversal31, node32);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(nodeArray13);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNotNull(nodeArray26);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(assertionFunctionSpecCollection30);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.UNKNOWN_DEFINES;
        com.google.javascript.jscomp.DiagnosticGroups.TYPE_INVALIDATION = diagnosticGroup0;
        org.junit.Assert.assertNull(diagnosticGroup0);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile3 = com.google.javascript.jscomp.JSSourceFile.fromFile("Not declared as a constructor");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile5 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.CompilerInput compilerInput6 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile5);
        com.google.javascript.jscomp.CompilerInput compilerInput9 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput6, "hi!", false);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile11 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        compilerInput6.setSourceFile((com.google.javascript.jscomp.SourceFile) jSSourceFile11);
        java.lang.String str13 = jSSourceFile11.toString();
        com.google.javascript.jscomp.CompilerOptions compilerOptions14 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean15 = compilerOptions14.aliasAllStrings;
        compilerOptions14.setGenerateExports(true);
        com.google.javascript.jscomp.Result result18 = compiler1.compile(jSSourceFile3, jSSourceFile11, compilerOptions14);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile20 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.CompilerInput compilerInput21 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile20);
        com.google.javascript.jscomp.Region region23 = jSSourceFile20.getRegion(24);
        com.google.javascript.jscomp.JSModule jSModule24 = null;
        com.google.javascript.jscomp.JSModule[] jSModuleArray25 = new com.google.javascript.jscomp.JSModule[] { jSModule24 };
        com.google.javascript.jscomp.CompilerOptions compilerOptions26 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions26.checkDuplicateMessages = false;
        boolean boolean29 = compilerOptions26.inlineAnonymousFunctionExpressions;
        compilerOptions26.recordFunctionInformation = true;
        boolean boolean32 = compilerOptions26.checkCaja;
        com.google.javascript.jscomp.CheckLevel checkLevel33 = compilerOptions26.checkUndefinedProperties;
        compilerOptions26.ideMode = false;
        boolean boolean36 = compilerOptions26.deadAssignmentElimination;
        try {
            com.google.javascript.jscomp.Result result37 = compiler1.compile(jSSourceFile20, jSModuleArray25, compilerOptions26);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile3);
        org.junit.Assert.assertNotNull(jSSourceFile5);
        org.junit.Assert.assertNotNull(jSSourceFile11);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(result18);
        org.junit.Assert.assertNotNull(jSSourceFile20);
        org.junit.Assert.assertNull(region23);
        org.junit.Assert.assertNotNull(jSModuleArray25);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + checkLevel33 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel33.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        try {
            java.lang.String str1 = com.google.javascript.rhino.ScriptRuntime.getMessage0("com.google.javascript.rhino.EcmaError: TypeError: -1 is not a function, it is java.lang.Byte.");
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property com.google.javascript.rhino.EcmaError: TypeError: -1 is not a function, it is java.lang.Byte.");
        } catch (java.lang.RuntimeException e) {
        }
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        com.google.javascript.jscomp.SourceFile sourceFile3 = com.google.javascript.jscomp.SourceFile.fromCode("goog.exportProperty", "language version", "goog.exportProperty");
        java.io.Reader reader4 = sourceFile3.getCodeReader();
        java.lang.String str5 = sourceFile3.getOriginalPath();
        org.junit.Assert.assertNotNull(sourceFile3);
        org.junit.Assert.assertNotNull(reader4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "language version" + "'", str5.equals("language version"));
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        int int0 = com.google.javascript.rhino.Node.PARENTHESIZED_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 34 + "'", int0 == 34);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile5 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.CompilerInput compilerInput6 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile5);
        com.google.javascript.jscomp.CompilerInput compilerInput9 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput6, "hi!", false);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile11 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        compilerInput6.setSourceFile((com.google.javascript.jscomp.SourceFile) jSSourceFile11);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile14 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray15 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile2, jSSourceFile11, jSSourceFile14 };
        java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList16 = new java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile>();
        boolean boolean17 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList16, jSSourceFileArray15);
        com.google.javascript.jscomp.JSModule[] jSModuleArray18 = new com.google.javascript.jscomp.JSModule[] {};
        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList19 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
        boolean boolean20 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList19, jSModuleArray18);
        com.google.javascript.jscomp.CompilerOptions compilerOptions21 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions21.checkDuplicateMessages = false;
        boolean boolean24 = compilerOptions21.inlineAnonymousFunctionExpressions;
        compilerOptions21.crossModuleMethodMotion = true;
        com.google.javascript.jscomp.Result result27 = compiler0.compileModules((java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList16, (java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList19, compilerOptions21);
        boolean boolean28 = compiler0.acceptEcmaScript5();
        try {
            compiler0.optimize();
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: INTERNAL COMPILER ERROR.\nPlease report this problem.\nnull");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile2);
        org.junit.Assert.assertNotNull(jSSourceFile5);
        org.junit.Assert.assertNotNull(jSSourceFile11);
        org.junit.Assert.assertNotNull(jSSourceFile14);
        org.junit.Assert.assertNotNull(jSSourceFileArray15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(jSModuleArray18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(result27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile3 = com.google.javascript.jscomp.JSSourceFile.fromFile("Not declared as a constructor");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile5 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.CompilerInput compilerInput6 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile5);
        com.google.javascript.jscomp.CompilerInput compilerInput9 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput6, "hi!", false);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile11 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        compilerInput6.setSourceFile((com.google.javascript.jscomp.SourceFile) jSSourceFile11);
        java.lang.String str13 = jSSourceFile11.toString();
        com.google.javascript.jscomp.CompilerOptions compilerOptions14 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean15 = compilerOptions14.aliasAllStrings;
        compilerOptions14.setGenerateExports(true);
        com.google.javascript.jscomp.Result result18 = compiler1.compile(jSSourceFile3, jSSourceFile11, compilerOptions14);
        com.google.javascript.jscomp.CompilerInput compilerInput19 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile11);
        com.google.javascript.jscomp.CompilerInput compilerInput20 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput19);
        java.lang.String str21 = compilerInput20.getName();
        org.junit.Assert.assertNotNull(jSSourceFile3);
        org.junit.Assert.assertNotNull(jSSourceFile5);
        org.junit.Assert.assertNotNull(jSSourceFile11);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(result18);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "" + "'", str21.equals(""));
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.brokenClosureRequiresLevel;
        com.google.javascript.jscomp.CheckLevel checkLevel2 = com.google.javascript.jscomp.CheckLevel.WARNING;
        compilerOptions0.checkGlobalNamesLevel = checkLevel2;
        boolean boolean4 = compilerOptions0.smartNameRemoval;
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + checkLevel2 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel2.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray12 = new com.google.javascript.rhino.Node[] { node3, node5, node7, node9, node11 };
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray12);
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node16 = node13.copyInformationFrom(node15);
        com.google.javascript.rhino.Node node17 = node13.getParent();
        com.google.javascript.rhino.Node node18 = new com.google.javascript.rhino.Node((int) (short) -1, node13);
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newString((int) (short) 0, "hi!", 100, (-2));
        boolean boolean24 = node13.isEquivalentTo(node23);
        java.util.Collection<com.google.javascript.rhino.Node> nodeCollection25 = com.google.javascript.jscomp.NodeUtil.getVarsDeclaredInBranch(node23);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertNotNull(nodeArray12);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertNull(node17);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(nodeCollection25);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.brokenClosureRequiresLevel;
        compilerOptions0.setManageClosureDependencies(true);
        java.lang.String[] strArray11 = new java.lang.String[] { "goog.exportProperty", "Not declared as a type name", "error reporter", "DiagnosticGroup<undefinedVars>", "goog.exportProperty", "Not declared as a constructor" };
        java.util.ArrayList<java.lang.String> strList12 = new java.util.ArrayList<java.lang.String>();
        boolean boolean13 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strList12, strArray11);
        compilerOptions0.setReplaceStringsConfiguration("goog.exportProperty", (java.util.List<java.lang.String>) strList12);
        com.google.javascript.jscomp.CheckLevel checkLevel15 = compilerOptions0.aggressiveVarCheck;
        boolean boolean16 = compilerOptions0.optimizeParameters;
        compilerOptions0.closurePass = false;
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(strArray11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + checkLevel15 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel15.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        com.google.javascript.jscomp.DiagnosticType diagnosticType2 = com.google.javascript.jscomp.DiagnosticType.warning("goog.exportSymbol", "DiagnosticGroup<strictModuleDepCheck>");
        org.junit.Assert.assertNotNull(diagnosticType2);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile5 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.CompilerInput compilerInput6 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile5);
        com.google.javascript.jscomp.CompilerInput compilerInput9 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput6, "hi!", false);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile11 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        compilerInput6.setSourceFile((com.google.javascript.jscomp.SourceFile) jSSourceFile11);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile14 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray15 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile2, jSSourceFile11, jSSourceFile14 };
        java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList16 = new java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile>();
        boolean boolean17 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList16, jSSourceFileArray15);
        com.google.javascript.jscomp.JSModule[] jSModuleArray18 = new com.google.javascript.jscomp.JSModule[] {};
        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList19 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
        boolean boolean20 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList19, jSModuleArray18);
        com.google.javascript.jscomp.CompilerOptions compilerOptions21 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions21.checkDuplicateMessages = false;
        boolean boolean24 = compilerOptions21.inlineAnonymousFunctionExpressions;
        compilerOptions21.crossModuleMethodMotion = true;
        com.google.javascript.jscomp.Result result27 = compiler0.compileModules((java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList16, (java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList19, compilerOptions21);
        com.google.javascript.jscomp.JSModule jSModule28 = null;
        try {
            java.lang.String[] strArray29 = compiler0.toSourceArray(jSModule28);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: java.lang.NullPointerException");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile2);
        org.junit.Assert.assertNotNull(jSSourceFile5);
        org.junit.Assert.assertNotNull(jSSourceFile11);
        org.junit.Assert.assertNotNull(jSSourceFile14);
        org.junit.Assert.assertNotNull(jSSourceFileArray15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(jSModuleArray18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(result27);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        int int0 = com.google.javascript.rhino.Node.IS_CONSTANT_NAME;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 42 + "'", int0 == 42);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        int int0 = com.google.javascript.rhino.Context.FEATURE_E4X;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 6 + "'", int0 == 6);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray11 = new com.google.javascript.rhino.Node[] { node2, node4, node6, node8, node10 };
        com.google.javascript.rhino.Node node12 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray11);
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node15 = node12.copyInformationFrom(node14);
        com.google.javascript.rhino.Node node16 = node14.getLastSibling();
        int int17 = node14.getCharno();
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(nodeArray11);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray13 = new com.google.javascript.rhino.Node[] { node4, node6, node8, node10, node12 };
        com.google.javascript.rhino.Node node14 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray13);
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node21 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray26 = new com.google.javascript.rhino.Node[] { node17, node19, node21, node23, node25 };
        com.google.javascript.rhino.Node node27 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray26);
        com.google.javascript.rhino.Node node28 = new com.google.javascript.rhino.Node(100, node14, node27);
        boolean boolean29 = closureCodingConvention0.isVarArgsParameter(node28);
        com.google.javascript.rhino.jstype.FunctionType functionType30 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType31 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType32 = null;
        try {
            closureCodingConvention0.applySingletonGetter(functionType30, functionType31, objectType32);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(nodeArray13);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNotNull(nodeArray26);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        com.google.javascript.jscomp.DiagnosticType diagnosticType0 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        java.lang.String str1 = diagnosticType0.key;
        java.lang.Class<?> wildcardClass2 = diagnosticType0.getClass();
        com.google.javascript.jscomp.CheckLevel checkLevel3 = diagnosticType0.defaultLevel;
        org.junit.Assert.assertNotNull(diagnosticType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "JSC_OPTIMIZE_LOOP_ERROR" + "'", str1.equals("JSC_OPTIMIZE_LOOP_ERROR"));
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertTrue("'" + checkLevel3 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel3.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile3 = com.google.javascript.jscomp.JSSourceFile.fromFile("Not declared as a constructor");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile5 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.CompilerInput compilerInput6 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile5);
        com.google.javascript.jscomp.CompilerInput compilerInput9 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput6, "hi!", false);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile11 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        compilerInput6.setSourceFile((com.google.javascript.jscomp.SourceFile) jSSourceFile11);
        java.lang.String str13 = jSSourceFile11.toString();
        com.google.javascript.jscomp.CompilerOptions compilerOptions14 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean15 = compilerOptions14.aliasAllStrings;
        compilerOptions14.setGenerateExports(true);
        com.google.javascript.jscomp.Result result18 = compiler1.compile(jSSourceFile3, jSSourceFile11, compilerOptions14);
        compilerOptions14.inlineLocalFunctions = true;
        compilerOptions14.devirtualizePrototypeMethods = true;
        com.google.common.collect.Multimap<com.google.javascript.jscomp.CustomPassExecutionTime, com.google.javascript.jscomp.CompilerPass> customPassExecutionTimeMultimap23 = null;
        compilerOptions14.customPasses = customPassExecutionTimeMultimap23;
        compilerOptions14.reportPath = "TypeError: ";
        compilerOptions14.instrumentForCoverageOnly = true;
        org.junit.Assert.assertNotNull(jSSourceFile3);
        org.junit.Assert.assertNotNull(jSSourceFile5);
        org.junit.Assert.assertNotNull(jSSourceFile11);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(result18);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray13 = new com.google.javascript.rhino.Node[] { node4, node6, node8, node10, node12 };
        com.google.javascript.rhino.Node node14 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray13);
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node21 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray26 = new com.google.javascript.rhino.Node[] { node17, node19, node21, node23, node25 };
        com.google.javascript.rhino.Node node27 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray26);
        com.google.javascript.rhino.Node node28 = new com.google.javascript.rhino.Node(100, node14, node27);
        boolean boolean29 = closureCodingConvention0.isVarArgsParameter(node28);
        java.lang.String str30 = closureCodingConvention0.getExportPropertyFunction();
        boolean boolean33 = closureCodingConvention0.isExported("goog.exportProperty", false);
        com.google.javascript.rhino.Node node37 = com.google.javascript.rhino.Node.newNumber(100.0d, 4095, 9);
        java.util.Set<java.lang.String> strSet38 = node37.getDirectives();
        boolean boolean39 = closureCodingConvention0.isVarArgsParameter(node37);
        com.google.javascript.rhino.Node node42 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node44 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node46 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node48 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node50 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray51 = new com.google.javascript.rhino.Node[] { node42, node44, node46, node48, node50 };
        com.google.javascript.rhino.Node node52 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray51);
        com.google.javascript.rhino.Node node53 = node52.getNext();
        com.google.javascript.rhino.Node node57 = com.google.javascript.rhino.Node.newNumber(100.0d, 4095, 9);
        java.lang.String str58 = closureCodingConvention0.extractClassNameIfRequire(node52, node57);
        boolean boolean60 = closureCodingConvention0.isValidEnumKey("error reporter");
        boolean boolean62 = closureCodingConvention0.isExported("");
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(nodeArray13);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNotNull(nodeArray26);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "goog.exportProperty" + "'", str30.equals("goog.exportProperty"));
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(node37);
        org.junit.Assert.assertNull(strSet38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(node42);
        org.junit.Assert.assertNotNull(node44);
        org.junit.Assert.assertNotNull(node46);
        org.junit.Assert.assertNotNull(node48);
        org.junit.Assert.assertNotNull(node50);
        org.junit.Assert.assertNotNull(nodeArray51);
        org.junit.Assert.assertNull(node53);
        org.junit.Assert.assertNotNull(node57);
        org.junit.Assert.assertNull(str58);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + true + "'", boolean60 == true);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        int int0 = com.google.javascript.rhino.Node.CASES_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 13 + "'", int0 == 13);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        com.google.javascript.rhino.Context.checkOptimizationLevel(3);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        com.google.javascript.rhino.EcmaError ecmaError1 = com.google.javascript.rhino.ScriptRuntime.typeError("");
        java.lang.String str2 = ecmaError1.getSourceName();
        java.lang.String str3 = ecmaError1.getErrorMessage();
        ecmaError1.initColumnNumber((int) '4');
        org.junit.Assert.assertNotNull(ecmaError1);
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.brokenClosureRequiresLevel;
        compilerOptions0.setManageClosureDependencies(true);
        java.lang.String[] strArray11 = new java.lang.String[] { "goog.exportProperty", "Not declared as a type name", "error reporter", "DiagnosticGroup<undefinedVars>", "goog.exportProperty", "Not declared as a constructor" };
        java.util.ArrayList<java.lang.String> strList12 = new java.util.ArrayList<java.lang.String>();
        boolean boolean13 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strList12, strArray11);
        compilerOptions0.setReplaceStringsConfiguration("goog.exportProperty", (java.util.List<java.lang.String>) strList12);
        compilerOptions0.decomposeExpressions = false;
        com.google.javascript.jscomp.CheckLevel checkLevel17 = compilerOptions0.checkMissingGetCssNameLevel;
        compilerOptions0.recordFunctionInformation = false;
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(strArray11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + checkLevel17 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel17.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray0 = new com.google.javascript.jscomp.WarningsGuard[] {};
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard1 = new com.google.javascript.jscomp.ComposeWarningsGuard(warningsGuardArray0);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup2 = com.google.javascript.jscomp.DiagnosticGroups.STRICT_MODULE_DEP_CHECK;
        boolean boolean3 = composeWarningsGuard1.disables(diagnosticGroup2);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup5 = com.google.javascript.jscomp.DiagnosticGroups.STRICT_MODULE_DEP_CHECK;
        com.google.javascript.jscomp.DiagnosticGroups.STRICT_MODULE_DEP_CHECK = diagnosticGroup5;
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup7 = com.google.javascript.jscomp.DiagnosticGroups.ACCESS_CONTROLS;
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup8 = com.google.javascript.jscomp.DiagnosticGroups.ACCESS_CONTROLS;
        com.google.javascript.jscomp.DiagnosticGroup[] diagnosticGroupArray9 = new com.google.javascript.jscomp.DiagnosticGroup[] { diagnosticGroup5, diagnosticGroup7, diagnosticGroup8 };
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup10 = new com.google.javascript.jscomp.DiagnosticGroup("goog.exportSymbol", diagnosticGroupArray9);
        com.google.javascript.jscomp.DiagnosticGroups.CONSTANT_PROPERTY = diagnosticGroup10;
        boolean boolean12 = composeWarningsGuard1.disables(diagnosticGroup10);
        org.junit.Assert.assertNotNull(warningsGuardArray0);
        org.junit.Assert.assertNotNull(diagnosticGroup2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(diagnosticGroup5);
        org.junit.Assert.assertNotNull(diagnosticGroup7);
        org.junit.Assert.assertNotNull(diagnosticGroup8);
        org.junit.Assert.assertNotNull(diagnosticGroupArray9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = null;
        com.google.javascript.jscomp.DiagnosticGroups.MISSING_PROPERTIES = diagnosticGroup0;
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy0 = com.google.javascript.jscomp.PropertyRenamingPolicy.UNSPECIFIED;
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy0 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.UNSPECIFIED + "'", propertyRenamingPolicy0.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.UNSPECIFIED));
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray11 = new com.google.javascript.rhino.Node[] { node2, node4, node6, node8, node10 };
        com.google.javascript.rhino.Node node12 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray11);
        int int13 = node12.getSideEffectFlags();
        com.google.javascript.rhino.Node node14 = node12.getNext();
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention15 = new com.google.javascript.jscomp.ClosureCodingConvention();
        boolean boolean17 = closureCodingConvention15.isConstant("");
        boolean boolean19 = closureCodingConvention15.isValidEnumKey("hi!");
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node27 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node29 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node31 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray32 = new com.google.javascript.rhino.Node[] { node23, node25, node27, node29, node31 };
        com.google.javascript.rhino.Node node33 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray32);
        com.google.javascript.rhino.Node node35 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node36 = node33.copyInformationFrom(node35);
        com.google.javascript.rhino.Node node37 = node33.getParent();
        com.google.javascript.rhino.Node node38 = new com.google.javascript.rhino.Node((int) (short) -1, node33);
        com.google.javascript.rhino.Node node43 = com.google.javascript.rhino.Node.newString((int) (short) 0, "hi!", 100, (-2));
        boolean boolean44 = node33.isEquivalentTo(node43);
        com.google.javascript.rhino.Node node47 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node49 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node51 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node53 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node55 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray56 = new com.google.javascript.rhino.Node[] { node47, node49, node51, node53, node55 };
        com.google.javascript.rhino.Node node57 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray56);
        com.google.javascript.rhino.Node node59 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node60 = node57.copyInformationFrom(node59);
        com.google.javascript.jscomp.parsing.Config.LanguageMode languageMode62 = com.google.javascript.jscomp.parsing.Config.LanguageMode.ECMASCRIPT5;
        node60.putProp(24, (java.lang.Object) languageMode62);
        java.lang.String str64 = closureCodingConvention15.extractClassNameIfRequire(node33, node60);
        boolean boolean65 = node12.hasChild(node60);
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(nodeArray11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNull(node14);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNotNull(node27);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertNotNull(nodeArray32);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertNotNull(node36);
        org.junit.Assert.assertNull(node37);
        org.junit.Assert.assertNotNull(node43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(node47);
        org.junit.Assert.assertNotNull(node49);
        org.junit.Assert.assertNotNull(node51);
        org.junit.Assert.assertNotNull(node53);
        org.junit.Assert.assertNotNull(node55);
        org.junit.Assert.assertNotNull(nodeArray56);
        org.junit.Assert.assertNotNull(node59);
        org.junit.Assert.assertNotNull(node60);
        org.junit.Assert.assertTrue("'" + languageMode62 + "' != '" + com.google.javascript.jscomp.parsing.Config.LanguageMode.ECMASCRIPT5 + "'", languageMode62.equals(com.google.javascript.jscomp.parsing.Config.LanguageMode.ECMASCRIPT5));
        org.junit.Assert.assertNull(str64);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        int int0 = com.google.javascript.rhino.Node.DEFAULT_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 14 + "'", int0 == 14);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray13 = new com.google.javascript.rhino.Node[] { node4, node6, node8, node10, node12 };
        com.google.javascript.rhino.Node node14 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray13);
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node21 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray26 = new com.google.javascript.rhino.Node[] { node17, node19, node21, node23, node25 };
        com.google.javascript.rhino.Node node27 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray26);
        com.google.javascript.rhino.Node node28 = new com.google.javascript.rhino.Node(100, node14, node27);
        java.lang.String str29 = closureCodingConvention0.getSingletonGetterClassName(node28);
        com.google.javascript.rhino.Node node35 = com.google.javascript.rhino.Node.newString((int) (short) 0, "hi!", 100, (-2));
        com.google.javascript.rhino.Node node36 = new com.google.javascript.rhino.Node(10, node35);
        java.lang.String str37 = closureCodingConvention0.identifyTypeDefAssign(node36);
        com.google.javascript.rhino.Node node38 = node36.cloneNode();
        boolean boolean39 = node38.hasOneChild();
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(nodeArray13);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNotNull(nodeArray26);
        org.junit.Assert.assertNull(str29);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertNull(str37);
        org.junit.Assert.assertNotNull(node38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray11 = new com.google.javascript.rhino.Node[] { node2, node4, node6, node8, node10 };
        com.google.javascript.rhino.Node node12 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray11);
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node15 = node12.copyInformationFrom(node14);
        int int16 = node14.getType();
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(nodeArray11);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 40 + "'", int16 == 40);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        com.google.javascript.jscomp.SourceFile sourceFile4 = com.google.javascript.jscomp.SourceFile.fromCode("goog.exportProperty", "language version", "goog.exportProperty");
        java.io.Reader reader5 = sourceFile4.getCodeReader();
        com.google.javascript.jscomp.SourceFile sourceFile6 = com.google.javascript.jscomp.SourceFile.fromReader("goog.exportSymbol", reader5);
        java.lang.String str7 = sourceFile6.getName();
        org.junit.Assert.assertNotNull(sourceFile4);
        org.junit.Assert.assertNotNull(reader5);
        org.junit.Assert.assertNotNull(sourceFile6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "goog.exportSymbol" + "'", str7.equals("goog.exportSymbol"));
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray13 = new com.google.javascript.rhino.Node[] { node4, node6, node8, node10, node12 };
        com.google.javascript.rhino.Node node14 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray13);
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node21 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray26 = new com.google.javascript.rhino.Node[] { node17, node19, node21, node23, node25 };
        com.google.javascript.rhino.Node node27 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray26);
        com.google.javascript.rhino.Node node28 = new com.google.javascript.rhino.Node(100, node14, node27);
        boolean boolean29 = closureCodingConvention0.isVarArgsParameter(node28);
        java.lang.String str30 = closureCodingConvention0.getExportPropertyFunction();
        boolean boolean33 = closureCodingConvention0.isExported("goog.exportProperty", false);
        com.google.javascript.rhino.Node node37 = com.google.javascript.rhino.Node.newNumber(100.0d, 4095, 9);
        java.util.Set<java.lang.String> strSet38 = node37.getDirectives();
        boolean boolean39 = closureCodingConvention0.isVarArgsParameter(node37);
        com.google.javascript.rhino.Node node42 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node44 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node46 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node48 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node50 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray51 = new com.google.javascript.rhino.Node[] { node42, node44, node46, node48, node50 };
        com.google.javascript.rhino.Node node52 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray51);
        com.google.javascript.rhino.Node node53 = node52.getNext();
        com.google.javascript.rhino.Node node57 = com.google.javascript.rhino.Node.newNumber(100.0d, 4095, 9);
        java.lang.String str58 = closureCodingConvention0.extractClassNameIfRequire(node52, node57);
        com.google.javascript.rhino.jstype.FunctionType functionType59 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType60 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType61 = null;
        closureCodingConvention0.applySubclassRelationship(functionType59, functionType60, subclassType61);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(nodeArray13);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNotNull(nodeArray26);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "goog.exportProperty" + "'", str30.equals("goog.exportProperty"));
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(node37);
        org.junit.Assert.assertNull(strSet38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(node42);
        org.junit.Assert.assertNotNull(node44);
        org.junit.Assert.assertNotNull(node46);
        org.junit.Assert.assertNotNull(node48);
        org.junit.Assert.assertNotNull(node50);
        org.junit.Assert.assertNotNull(nodeArray51);
        org.junit.Assert.assertNull(node53);
        org.junit.Assert.assertNotNull(node57);
        org.junit.Assert.assertNull(str58);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray11 = new com.google.javascript.rhino.Node[] { node2, node4, node6, node8, node10 };
        com.google.javascript.rhino.Node node12 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray11);
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node15 = node12.copyInformationFrom(node14);
        com.google.javascript.rhino.Node node16 = node12.getParent();
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node22 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node24 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node26 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node28 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray29 = new com.google.javascript.rhino.Node[] { node20, node22, node24, node26, node28 };
        com.google.javascript.rhino.Node node30 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray29);
        int int31 = node30.getSideEffectFlags();
        com.google.javascript.rhino.Node node32 = node30.getNext();
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention33 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node37 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node39 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node41 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node43 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node45 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray46 = new com.google.javascript.rhino.Node[] { node37, node39, node41, node43, node45 };
        com.google.javascript.rhino.Node node47 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray46);
        com.google.javascript.rhino.Node node50 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node52 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node54 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node56 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node58 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray59 = new com.google.javascript.rhino.Node[] { node50, node52, node54, node56, node58 };
        com.google.javascript.rhino.Node node60 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray59);
        com.google.javascript.rhino.Node node61 = new com.google.javascript.rhino.Node(100, node47, node60);
        java.lang.String str62 = closureCodingConvention33.getSingletonGetterClassName(node61);
        node61.setWasEmptyNode(true);
        com.google.javascript.rhino.Node node68 = com.google.javascript.rhino.Node.newNumber(100.0d, 4095, 9);
        java.util.Set<java.lang.String> strSet69 = node68.getDirectives();
        com.google.javascript.rhino.Node node72 = new com.google.javascript.rhino.Node((int) (short) 0, node30, node61, node68, (int) (short) 10, (int) ' ');
        com.google.javascript.rhino.Node node77 = com.google.javascript.rhino.Node.newNumber(100.0d, 4095, 9);
        java.util.Set<java.lang.String> strSet78 = node77.getDirectives();
        com.google.javascript.rhino.Node node81 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node83 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node85 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node87 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node89 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray90 = new com.google.javascript.rhino.Node[] { node81, node83, node85, node87, node89 };
        com.google.javascript.rhino.Node node91 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray90);
        com.google.javascript.rhino.Node node93 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node94 = node91.copyInformationFrom(node93);
        com.google.javascript.rhino.Node node97 = new com.google.javascript.rhino.Node(28, node77, node91, (-2), (int) (byte) -1);
        boolean boolean98 = node97.isNoSideEffectsCall();
        try {
            node16.addChildBefore(node72, node97);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(nodeArray11);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertNull(node16);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertNotNull(nodeArray29);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertNull(node32);
        org.junit.Assert.assertNotNull(node37);
        org.junit.Assert.assertNotNull(node39);
        org.junit.Assert.assertNotNull(node41);
        org.junit.Assert.assertNotNull(node43);
        org.junit.Assert.assertNotNull(node45);
        org.junit.Assert.assertNotNull(nodeArray46);
        org.junit.Assert.assertNotNull(node50);
        org.junit.Assert.assertNotNull(node52);
        org.junit.Assert.assertNotNull(node54);
        org.junit.Assert.assertNotNull(node56);
        org.junit.Assert.assertNotNull(node58);
        org.junit.Assert.assertNotNull(nodeArray59);
        org.junit.Assert.assertNull(str62);
        org.junit.Assert.assertNotNull(node68);
        org.junit.Assert.assertNull(strSet69);
        org.junit.Assert.assertNotNull(node77);
        org.junit.Assert.assertNull(strSet78);
        org.junit.Assert.assertNotNull(node81);
        org.junit.Assert.assertNotNull(node83);
        org.junit.Assert.assertNotNull(node85);
        org.junit.Assert.assertNotNull(node87);
        org.junit.Assert.assertNotNull(node89);
        org.junit.Assert.assertNotNull(nodeArray90);
        org.junit.Assert.assertNotNull(node93);
        org.junit.Assert.assertNotNull(node94);
        org.junit.Assert.assertTrue("'" + boolean98 + "' != '" + false + "'", boolean98 == false);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray13 = new com.google.javascript.rhino.Node[] { node4, node6, node8, node10, node12 };
        com.google.javascript.rhino.Node node14 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray13);
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node21 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray26 = new com.google.javascript.rhino.Node[] { node17, node19, node21, node23, node25 };
        com.google.javascript.rhino.Node node27 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray26);
        com.google.javascript.rhino.Node node28 = new com.google.javascript.rhino.Node(100, node14, node27);
        boolean boolean29 = closureCodingConvention0.isVarArgsParameter(node28);
        java.lang.String str30 = closureCodingConvention0.getExportPropertyFunction();
        boolean boolean33 = closureCodingConvention0.isExported("goog.exportProperty", false);
        com.google.javascript.rhino.Node node37 = com.google.javascript.rhino.Node.newNumber(100.0d, 4095, 9);
        java.util.Set<java.lang.String> strSet38 = node37.getDirectives();
        boolean boolean39 = closureCodingConvention0.isVarArgsParameter(node37);
        com.google.javascript.rhino.Node node42 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node44 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node46 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node48 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node50 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray51 = new com.google.javascript.rhino.Node[] { node42, node44, node46, node48, node50 };
        com.google.javascript.rhino.Node node52 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray51);
        int int53 = node52.getSideEffectFlags();
        node37.addChildrenToFront(node52);
        int int56 = node52.getIntProp((int) (short) 10);
        try {
            node52.setString("TypeError");
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: EOF 0 is not a string node");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(nodeArray13);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNotNull(nodeArray26);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "goog.exportProperty" + "'", str30.equals("goog.exportProperty"));
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(node37);
        org.junit.Assert.assertNull(strSet38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(node42);
        org.junit.Assert.assertNotNull(node44);
        org.junit.Assert.assertNotNull(node46);
        org.junit.Assert.assertNotNull(node48);
        org.junit.Assert.assertNotNull(node50);
        org.junit.Assert.assertNotNull(nodeArray51);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 0 + "'", int53 == 0);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 0 + "'", int56 == 0);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        com.google.javascript.rhino.EvaluatorException evaluatorException3 = new com.google.javascript.rhino.EvaluatorException("DiagnosticGroup<strictModuleDepCheck>", "Not declared as a type name", 41);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        try {
            com.google.javascript.rhino.EcmaError ecmaError1 = com.google.javascript.rhino.ScriptRuntime.typeError0("JSC_OPTIMIZE_LOOP_ERROR");
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property JSC_OPTIMIZE_LOOP_ERROR");
        } catch (java.lang.RuntimeException e) {
        }
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        java.io.InputStream inputStream1 = null;
        try {
            com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromInputStream("1", inputStream1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile5 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.CompilerInput compilerInput6 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile5);
        com.google.javascript.jscomp.CompilerInput compilerInput9 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput6, "hi!", false);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile11 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        compilerInput6.setSourceFile((com.google.javascript.jscomp.SourceFile) jSSourceFile11);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile14 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray15 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile2, jSSourceFile11, jSSourceFile14 };
        java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList16 = new java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile>();
        boolean boolean17 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList16, jSSourceFileArray15);
        com.google.javascript.jscomp.JSModule[] jSModuleArray18 = new com.google.javascript.jscomp.JSModule[] {};
        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList19 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
        boolean boolean20 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList19, jSModuleArray18);
        com.google.javascript.jscomp.CompilerOptions compilerOptions21 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions21.checkDuplicateMessages = false;
        boolean boolean24 = compilerOptions21.inlineAnonymousFunctionExpressions;
        compilerOptions21.crossModuleMethodMotion = true;
        com.google.javascript.jscomp.Result result27 = compiler0.compileModules((java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList16, (java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList19, compilerOptions21);
        com.google.javascript.jscomp.ErrorManager errorManager28 = compiler0.getErrorManager();
        com.google.javascript.jscomp.Compiler compiler29 = new com.google.javascript.jscomp.Compiler(errorManager28);
        com.google.javascript.jscomp.JSModule jSModule30 = null;
        try {
            java.lang.String str31 = compiler29.toSource(jSModule30);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile2);
        org.junit.Assert.assertNotNull(jSSourceFile5);
        org.junit.Assert.assertNotNull(jSSourceFile11);
        org.junit.Assert.assertNotNull(jSSourceFile14);
        org.junit.Assert.assertNotNull(jSSourceFileArray15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(jSModuleArray18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(result27);
        org.junit.Assert.assertNotNull(errorManager28);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        com.google.javascript.rhino.Context context0 = com.google.javascript.rhino.Context.enter();
        boolean boolean1 = context0.isGeneratingSource();
        boolean boolean2 = context0.isGeneratingSource();
        boolean boolean3 = context0.isGeneratingSource();
        org.junit.Assert.assertNotNull(context0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile3 = com.google.javascript.jscomp.JSSourceFile.fromFile("Not declared as a constructor");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile5 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.CompilerInput compilerInput6 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile5);
        com.google.javascript.jscomp.CompilerInput compilerInput9 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput6, "hi!", false);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile11 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        compilerInput6.setSourceFile((com.google.javascript.jscomp.SourceFile) jSSourceFile11);
        java.lang.String str13 = jSSourceFile11.toString();
        com.google.javascript.jscomp.CompilerOptions compilerOptions14 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean15 = compilerOptions14.aliasAllStrings;
        compilerOptions14.setGenerateExports(true);
        com.google.javascript.jscomp.Result result18 = compiler1.compile(jSSourceFile3, jSSourceFile11, compilerOptions14);
        com.google.javascript.jscomp.JsAst jsAst19 = new com.google.javascript.jscomp.JsAst((com.google.javascript.jscomp.SourceFile) jSSourceFile11);
        jsAst19.clearAst();
        org.junit.Assert.assertNotNull(jSSourceFile3);
        org.junit.Assert.assertNotNull(jSSourceFile5);
        org.junit.Assert.assertNotNull(jSSourceFile11);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(result18);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.NodeTraversal.Callback callback1 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal2 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler0, callback1);
        try {
            boolean boolean3 = compiler0.acceptConstKeyword();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        com.google.javascript.jscomp.parsing.Config.LanguageMode languageMode3 = com.google.javascript.jscomp.parsing.Config.LanguageMode.ECMASCRIPT5;
        com.google.javascript.jscomp.parsing.Config config5 = com.google.javascript.jscomp.parsing.ParserRunner.createConfig(true, languageMode3, true);
        com.google.javascript.jscomp.mozilla.rhino.ErrorReporter errorReporter6 = null;
        java.util.logging.Logger logger7 = null;
        try {
            com.google.javascript.rhino.Node node8 = com.google.javascript.jscomp.parsing.ParserRunner.parse("goog.global", "DiagnosticGroup<undefinedVars>", config5, errorReporter6, logger7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + languageMode3 + "' != '" + com.google.javascript.jscomp.parsing.Config.LanguageMode.ECMASCRIPT5 + "'", languageMode3.equals(com.google.javascript.jscomp.parsing.Config.LanguageMode.ECMASCRIPT5));
        org.junit.Assert.assertNotNull(config5);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.brokenClosureRequiresLevel;
        com.google.javascript.jscomp.CheckLevel checkLevel2 = com.google.javascript.jscomp.CheckLevel.WARNING;
        compilerOptions0.checkGlobalNamesLevel = checkLevel2;
        compilerOptions0.computeFunctionSideEffects = true;
        boolean boolean6 = compilerOptions0.removeDeadCode;
        compilerOptions0.removeUnusedLocalVars = true;
        compilerOptions0.setDefineToBooleanLiteral("language version", true);
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + checkLevel2 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel2.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.brokenClosureRequiresLevel;
        com.google.javascript.jscomp.CheckLevel checkLevel2 = com.google.javascript.jscomp.CheckLevel.WARNING;
        compilerOptions0.checkGlobalNamesLevel = checkLevel2;
        compilerOptions0.computeFunctionSideEffects = true;
        boolean boolean6 = compilerOptions0.removeDeadCode;
        com.google.javascript.jscomp.CompilerOptions.TweakProcessing tweakProcessing7 = compilerOptions0.getTweakProcessing();
        boolean boolean8 = compilerOptions0.checkControlStructures;
        boolean boolean9 = compilerOptions0.decomposeExpressions;
        boolean boolean10 = compilerOptions0.printInputDelimiter;
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + checkLevel2 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel2.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + tweakProcessing7 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TweakProcessing.OFF + "'", tweakProcessing7.equals(com.google.javascript.jscomp.CompilerOptions.TweakProcessing.OFF));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        int int0 = com.google.javascript.rhino.Node.MEMBER_TYPE_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 32 + "'", int0 == 32);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.brokenClosureRequiresLevel;
        com.google.javascript.jscomp.CheckLevel checkLevel2 = com.google.javascript.jscomp.CheckLevel.WARNING;
        compilerOptions0.checkGlobalNamesLevel = checkLevel2;
        compilerOptions0.computeFunctionSideEffects = true;
        boolean boolean6 = compilerOptions0.removeDeadCode;
        com.google.common.collect.Multimap<com.google.javascript.jscomp.CustomPassExecutionTime, com.google.javascript.jscomp.CompilerPass> customPassExecutionTimeMultimap7 = compilerOptions0.customPasses;
        boolean boolean8 = compilerOptions0.removeUnusedVars;
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + checkLevel2 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel2.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(customPassExecutionTimeMultimap7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        com.google.javascript.jscomp.AbstractCompiler abstractCompiler0 = null;
        com.google.javascript.jscomp.NodeTraversal.Callback callback1 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal2 = new com.google.javascript.jscomp.NodeTraversal(abstractCompiler0, callback1);
        boolean boolean3 = nodeTraversal2.hasScope();
        try {
            com.google.javascript.jscomp.CompilerInput compilerInput4 = nodeTraversal2.getInput();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray11 = new com.google.javascript.rhino.Node[] { node2, node4, node6, node8, node10 };
        com.google.javascript.rhino.Node node12 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray11);
        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node22 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node24 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray25 = new com.google.javascript.rhino.Node[] { node16, node18, node20, node22, node24 };
        com.google.javascript.rhino.Node node26 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray25);
        com.google.javascript.rhino.Node node28 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node29 = node26.copyInformationFrom(node28);
        com.google.javascript.rhino.Node node30 = node26.getParent();
        com.google.javascript.rhino.Node node31 = new com.google.javascript.rhino.Node((int) (short) -1, node26);
        com.google.javascript.rhino.Node node36 = com.google.javascript.rhino.Node.newString((int) (short) 0, "hi!", 100, (-2));
        boolean boolean37 = node26.isEquivalentTo(node36);
        com.google.javascript.rhino.Node node38 = node12.clonePropsFrom(node36);
        java.lang.String str39 = node12.toString();
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(nodeArray11);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertNotNull(nodeArray25);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNull(node30);
        org.junit.Assert.assertNotNull(node36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(node38);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "EOF 0" + "'", str39.equals("EOF 0"));
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        java.lang.String str1 = com.google.javascript.rhino.Node.tokenToName(43);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "false" + "'", str1.equals("false"));
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray13 = new com.google.javascript.rhino.Node[] { node4, node6, node8, node10, node12 };
        com.google.javascript.rhino.Node node14 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray13);
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node21 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray26 = new com.google.javascript.rhino.Node[] { node17, node19, node21, node23, node25 };
        com.google.javascript.rhino.Node node27 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray26);
        com.google.javascript.rhino.Node node28 = new com.google.javascript.rhino.Node(100, node14, node27);
        boolean boolean29 = closureCodingConvention0.isVarArgsParameter(node28);
        java.lang.String str30 = closureCodingConvention0.getExportPropertyFunction();
        boolean boolean33 = closureCodingConvention0.isExported("goog.exportProperty", false);
        com.google.javascript.rhino.Node node37 = com.google.javascript.rhino.Node.newNumber(100.0d, 4095, 9);
        java.util.Set<java.lang.String> strSet38 = node37.getDirectives();
        boolean boolean39 = closureCodingConvention0.isVarArgsParameter(node37);
        com.google.javascript.rhino.Node node42 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node44 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node46 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node48 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node50 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray51 = new com.google.javascript.rhino.Node[] { node42, node44, node46, node48, node50 };
        com.google.javascript.rhino.Node node52 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray51);
        int int53 = node52.getSideEffectFlags();
        node37.addChildrenToFront(node52);
        com.google.javascript.rhino.Node node55 = node52.cloneNode();
        node52.setType(24);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(nodeArray13);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNotNull(nodeArray26);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "goog.exportProperty" + "'", str30.equals("goog.exportProperty"));
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(node37);
        org.junit.Assert.assertNull(strSet38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(node42);
        org.junit.Assert.assertNotNull(node44);
        org.junit.Assert.assertNotNull(node46);
        org.junit.Assert.assertNotNull(node48);
        org.junit.Assert.assertNotNull(node50);
        org.junit.Assert.assertNotNull(nodeArray51);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 0 + "'", int53 == 0);
        org.junit.Assert.assertNotNull(node55);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.FILEOVERVIEW_JSDOC;
        com.google.javascript.jscomp.DiagnosticType diagnosticType1 = com.google.javascript.jscomp.Compiler.MOTION_ITERATIONS_ERROR;
        boolean boolean2 = diagnosticGroup0.matches(diagnosticType1);
        org.junit.Assert.assertNotNull(diagnosticGroup0);
        org.junit.Assert.assertNotNull(diagnosticType1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray13 = new com.google.javascript.rhino.Node[] { node4, node6, node8, node10, node12 };
        com.google.javascript.rhino.Node node14 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray13);
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node21 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray26 = new com.google.javascript.rhino.Node[] { node17, node19, node21, node23, node25 };
        com.google.javascript.rhino.Node node27 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray26);
        com.google.javascript.rhino.Node node28 = new com.google.javascript.rhino.Node(100, node14, node27);
        boolean boolean29 = closureCodingConvention0.isVarArgsParameter(node28);
        java.lang.String str30 = closureCodingConvention0.getGlobalObject();
        boolean boolean32 = closureCodingConvention0.isValidEnumKey("goog.global");
        boolean boolean34 = closureCodingConvention0.isSuperClassReference("JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of optimization iterations: {0}");
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(nodeArray13);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNotNull(nodeArray26);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "goog.global" + "'", str30.equals("goog.global"));
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.brokenClosureRequiresLevel;
        com.google.javascript.jscomp.CheckLevel checkLevel2 = com.google.javascript.jscomp.CheckLevel.WARNING;
        compilerOptions0.checkGlobalNamesLevel = checkLevel2;
        com.google.javascript.jscomp.ErrorFormat errorFormat4 = null;
        compilerOptions0.errorFormat = errorFormat4;
        java.lang.String str6 = compilerOptions0.checkMissingGetCssNameBlacklist;
        com.google.javascript.jscomp.CompilerOptions.AliasTransformationHandler aliasTransformationHandler7 = null;
        compilerOptions0.setAliasTransformationHandler(aliasTransformationHandler7);
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + checkLevel2 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel2.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
        org.junit.Assert.assertNull(str6);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        com.google.javascript.jscomp.ErrorFormat errorFormat0 = com.google.javascript.jscomp.ErrorFormat.SOURCELESS;
        org.junit.Assert.assertNotNull(errorFormat0);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newNumber(100.0d, 4095, 9);
        java.util.Set<java.lang.String> strSet5 = node4.getDirectives();
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray17 = new com.google.javascript.rhino.Node[] { node8, node10, node12, node14, node16 };
        com.google.javascript.rhino.Node node18 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray17);
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node21 = node18.copyInformationFrom(node20);
        com.google.javascript.rhino.Node node24 = new com.google.javascript.rhino.Node(28, node4, node18, (-2), (int) (byte) -1);
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention25 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node29 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node31 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node33 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node35 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node37 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray38 = new com.google.javascript.rhino.Node[] { node29, node31, node33, node35, node37 };
        com.google.javascript.rhino.Node node39 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray38);
        com.google.javascript.rhino.Node node42 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node44 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node46 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node48 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node50 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray51 = new com.google.javascript.rhino.Node[] { node42, node44, node46, node48, node50 };
        com.google.javascript.rhino.Node node52 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray51);
        com.google.javascript.rhino.Node node53 = new com.google.javascript.rhino.Node(100, node39, node52);
        boolean boolean54 = closureCodingConvention25.isVarArgsParameter(node53);
        java.lang.String str55 = closureCodingConvention25.getExportPropertyFunction();
        boolean boolean58 = closureCodingConvention25.isExported("goog.exportProperty", false);
        com.google.javascript.rhino.Node node62 = com.google.javascript.rhino.Node.newNumber(100.0d, 4095, 9);
        java.util.Set<java.lang.String> strSet63 = node62.getDirectives();
        boolean boolean64 = closureCodingConvention25.isVarArgsParameter(node62);
        com.google.javascript.rhino.Node node67 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node69 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node71 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node73 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node75 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray76 = new com.google.javascript.rhino.Node[] { node67, node69, node71, node73, node75 };
        com.google.javascript.rhino.Node node77 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray76);
        int int78 = node77.getSideEffectFlags();
        node62.addChildrenToFront(node77);
        int int81 = node77.getIntProp((int) (short) 10);
        try {
            node24.addChildrenToFront(node77);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNull(strSet5);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertNotNull(nodeArray17);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertNotNull(node33);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertNotNull(node37);
        org.junit.Assert.assertNotNull(nodeArray38);
        org.junit.Assert.assertNotNull(node42);
        org.junit.Assert.assertNotNull(node44);
        org.junit.Assert.assertNotNull(node46);
        org.junit.Assert.assertNotNull(node48);
        org.junit.Assert.assertNotNull(node50);
        org.junit.Assert.assertNotNull(nodeArray51);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertTrue("'" + str55 + "' != '" + "goog.exportProperty" + "'", str55.equals("goog.exportProperty"));
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(node62);
        org.junit.Assert.assertNull(strSet63);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertNotNull(node67);
        org.junit.Assert.assertNotNull(node69);
        org.junit.Assert.assertNotNull(node71);
        org.junit.Assert.assertNotNull(node73);
        org.junit.Assert.assertNotNull(node75);
        org.junit.Assert.assertNotNull(nodeArray76);
        org.junit.Assert.assertTrue("'" + int78 + "' != '" + 0 + "'", int78 == 0);
        org.junit.Assert.assertTrue("'" + int81 + "' != '" + 0 + "'", int81 == 0);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.brokenClosureRequiresLevel;
        com.google.javascript.jscomp.CheckLevel checkLevel2 = com.google.javascript.jscomp.CheckLevel.WARNING;
        compilerOptions0.checkGlobalNamesLevel = checkLevel2;
        compilerOptions0.computeFunctionSideEffects = true;
        boolean boolean6 = compilerOptions0.removeDeadCode;
        compilerOptions0.removeDeadCode = false;
        compilerOptions0.setCollapsePropertiesOnExternTypes(true);
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + checkLevel2 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel2.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        com.google.javascript.rhino.Node node0 = null;
        try {
            com.google.javascript.rhino.Node node1 = com.google.javascript.jscomp.NodeUtil.newExpr(node0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        boolean boolean2 = closureCodingConvention0.isConstant("");
        boolean boolean4 = closureCodingConvention0.isValidEnumKey("hi!");
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray17 = new com.google.javascript.rhino.Node[] { node8, node10, node12, node14, node16 };
        com.google.javascript.rhino.Node node18 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray17);
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node21 = node18.copyInformationFrom(node20);
        com.google.javascript.rhino.Node node22 = node18.getParent();
        com.google.javascript.rhino.Node node23 = new com.google.javascript.rhino.Node((int) (short) -1, node18);
        com.google.javascript.rhino.Node node28 = com.google.javascript.rhino.Node.newString((int) (short) 0, "hi!", 100, (-2));
        boolean boolean29 = node18.isEquivalentTo(node28);
        com.google.javascript.rhino.Node node32 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node34 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node36 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node38 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node40 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray41 = new com.google.javascript.rhino.Node[] { node32, node34, node36, node38, node40 };
        com.google.javascript.rhino.Node node42 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray41);
        com.google.javascript.rhino.Node node44 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node45 = node42.copyInformationFrom(node44);
        com.google.javascript.jscomp.parsing.Config.LanguageMode languageMode47 = com.google.javascript.jscomp.parsing.Config.LanguageMode.ECMASCRIPT5;
        node45.putProp(24, (java.lang.Object) languageMode47);
        java.lang.String str49 = closureCodingConvention0.extractClassNameIfRequire(node18, node45);
        boolean boolean51 = node18.getBooleanProp(130);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertNotNull(nodeArray17);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertNull(node22);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(node32);
        org.junit.Assert.assertNotNull(node34);
        org.junit.Assert.assertNotNull(node36);
        org.junit.Assert.assertNotNull(node38);
        org.junit.Assert.assertNotNull(node40);
        org.junit.Assert.assertNotNull(nodeArray41);
        org.junit.Assert.assertNotNull(node44);
        org.junit.Assert.assertNotNull(node45);
        org.junit.Assert.assertTrue("'" + languageMode47 + "' != '" + com.google.javascript.jscomp.parsing.Config.LanguageMode.ECMASCRIPT5 + "'", languageMode47.equals(com.google.javascript.jscomp.parsing.Config.LanguageMode.ECMASCRIPT5));
        org.junit.Assert.assertNull(str49);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.CHECK_REGEXP;
        com.google.javascript.jscomp.DiagnosticGroups.MISSING_PROPERTIES = diagnosticGroup0;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.Compiler compiler2 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile4 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.CompilerInput compilerInput5 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile4);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile7 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.CompilerInput compilerInput8 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile7);
        com.google.javascript.jscomp.CompilerInput compilerInput11 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput8, "hi!", false);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile13 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        compilerInput8.setSourceFile((com.google.javascript.jscomp.SourceFile) jSSourceFile13);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile16 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray17 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile4, jSSourceFile13, jSSourceFile16 };
        java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList18 = new java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile>();
        boolean boolean19 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList18, jSSourceFileArray17);
        com.google.javascript.jscomp.JSModule[] jSModuleArray20 = new com.google.javascript.jscomp.JSModule[] {};
        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList21 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
        boolean boolean22 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList21, jSModuleArray20);
        com.google.javascript.jscomp.CompilerOptions compilerOptions23 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions23.checkDuplicateMessages = false;
        boolean boolean26 = compilerOptions23.inlineAnonymousFunctionExpressions;
        compilerOptions23.crossModuleMethodMotion = true;
        com.google.javascript.jscomp.Result result29 = compiler2.compileModules((java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList18, (java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList21, compilerOptions23);
        com.google.javascript.jscomp.Compiler compiler30 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile32 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.CompilerInput compilerInput33 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile32);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile35 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.CompilerInput compilerInput36 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile35);
        com.google.javascript.jscomp.CompilerInput compilerInput39 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput36, "hi!", false);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile41 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        compilerInput36.setSourceFile((com.google.javascript.jscomp.SourceFile) jSSourceFile41);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile44 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray45 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile32, jSSourceFile41, jSSourceFile44 };
        java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList46 = new java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile>();
        boolean boolean47 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList46, jSSourceFileArray45);
        com.google.javascript.jscomp.JSModule[] jSModuleArray48 = new com.google.javascript.jscomp.JSModule[] {};
        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList49 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
        boolean boolean50 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList49, jSModuleArray48);
        com.google.javascript.jscomp.CompilerOptions compilerOptions51 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions51.checkDuplicateMessages = false;
        boolean boolean54 = compilerOptions51.inlineAnonymousFunctionExpressions;
        compilerOptions51.crossModuleMethodMotion = true;
        com.google.javascript.jscomp.Result result57 = compiler30.compileModules((java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList46, (java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList49, compilerOptions51);
        com.google.javascript.jscomp.CompilerOptions compilerOptions58 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel59 = compilerOptions58.brokenClosureRequiresLevel;
        java.util.Set<java.lang.String> strSet60 = compilerOptions58.aliasableStrings;
        boolean boolean61 = compilerOptions58.decomposeExpressions;
        java.util.Set<java.lang.String> strSet62 = compilerOptions58.stripNamePrefixes;
        com.google.javascript.jscomp.Result result63 = compiler1.compile((java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList18, (java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList46, compilerOptions58);
        com.google.javascript.jscomp.PerformanceTracker performanceTracker64 = compiler1.tracker;
        try {
            compiler1.check();
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: INTERNAL COMPILER ERROR.\nPlease report this problem.\nnull");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile4);
        org.junit.Assert.assertNotNull(jSSourceFile7);
        org.junit.Assert.assertNotNull(jSSourceFile13);
        org.junit.Assert.assertNotNull(jSSourceFile16);
        org.junit.Assert.assertNotNull(jSSourceFileArray17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(jSModuleArray20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(result29);
        org.junit.Assert.assertNotNull(jSSourceFile32);
        org.junit.Assert.assertNotNull(jSSourceFile35);
        org.junit.Assert.assertNotNull(jSSourceFile41);
        org.junit.Assert.assertNotNull(jSSourceFile44);
        org.junit.Assert.assertNotNull(jSSourceFileArray45);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
        org.junit.Assert.assertNotNull(jSModuleArray48);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNotNull(result57);
        org.junit.Assert.assertTrue("'" + checkLevel59 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel59.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(strSet60);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertNotNull(strSet62);
        org.junit.Assert.assertNotNull(result63);
        org.junit.Assert.assertNull(performanceTracker64);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newNumber(100.0d, 4095, 9);
        java.util.Set<java.lang.String> strSet5 = node4.getDirectives();
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray17 = new com.google.javascript.rhino.Node[] { node8, node10, node12, node14, node16 };
        com.google.javascript.rhino.Node node18 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray17);
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node21 = node18.copyInformationFrom(node20);
        com.google.javascript.rhino.Node node24 = new com.google.javascript.rhino.Node(28, node4, node18, (-2), (int) (byte) -1);
        com.google.javascript.rhino.Node node28 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node30 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node32 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node34 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node36 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray37 = new com.google.javascript.rhino.Node[] { node28, node30, node32, node34, node36 };
        com.google.javascript.rhino.Node node38 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray37);
        com.google.javascript.rhino.Node node41 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node43 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node45 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node47 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node49 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray50 = new com.google.javascript.rhino.Node[] { node41, node43, node45, node47, node49 };
        com.google.javascript.rhino.Node node51 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray50);
        com.google.javascript.rhino.Node node52 = new com.google.javascript.rhino.Node(100, node38, node51);
        com.google.javascript.rhino.Node node54 = node38.getAncestor(9);
        try {
            boolean boolean55 = node24.isEquivalentTo(node54);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNull(strSet5);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertNotNull(nodeArray17);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertNotNull(node30);
        org.junit.Assert.assertNotNull(node32);
        org.junit.Assert.assertNotNull(node34);
        org.junit.Assert.assertNotNull(node36);
        org.junit.Assert.assertNotNull(nodeArray37);
        org.junit.Assert.assertNotNull(node41);
        org.junit.Assert.assertNotNull(node43);
        org.junit.Assert.assertNotNull(node45);
        org.junit.Assert.assertNotNull(node47);
        org.junit.Assert.assertNotNull(node49);
        org.junit.Assert.assertNotNull(nodeArray50);
        org.junit.Assert.assertNull(node54);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray12 = new com.google.javascript.rhino.Node[] { node3, node5, node7, node9, node11 };
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray12);
        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node22 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node24 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray25 = new com.google.javascript.rhino.Node[] { node16, node18, node20, node22, node24 };
        com.google.javascript.rhino.Node node26 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray25);
        com.google.javascript.rhino.Node node27 = new com.google.javascript.rhino.Node(100, node13, node26);
        try {
            int int29 = node13.getExistingIntProp(42);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: FAILED ASSERTION");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertNotNull(nodeArray12);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertNotNull(nodeArray25);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        com.google.javascript.jscomp.CompilerOptions.TweakProcessing tweakProcessing0 = com.google.javascript.jscomp.CompilerOptions.TweakProcessing.STRIP;
        boolean boolean1 = tweakProcessing0.isOn();
        org.junit.Assert.assertTrue("'" + tweakProcessing0 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TweakProcessing.STRIP + "'", tweakProcessing0.equals(com.google.javascript.jscomp.CompilerOptions.TweakProcessing.STRIP));
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        boolean boolean2 = closureCodingConvention0.isConstant("");
        boolean boolean4 = closureCodingConvention0.isValidEnumKey("hi!");
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray17 = new com.google.javascript.rhino.Node[] { node8, node10, node12, node14, node16 };
        com.google.javascript.rhino.Node node18 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray17);
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node21 = node18.copyInformationFrom(node20);
        com.google.javascript.rhino.Node node22 = node18.getParent();
        com.google.javascript.rhino.Node node23 = new com.google.javascript.rhino.Node((int) (short) -1, node18);
        com.google.javascript.rhino.Node node28 = com.google.javascript.rhino.Node.newString((int) (short) 0, "hi!", 100, (-2));
        boolean boolean29 = node18.isEquivalentTo(node28);
        com.google.javascript.rhino.Node node32 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node34 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node36 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node38 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node40 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray41 = new com.google.javascript.rhino.Node[] { node32, node34, node36, node38, node40 };
        com.google.javascript.rhino.Node node42 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray41);
        com.google.javascript.rhino.Node node44 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node45 = node42.copyInformationFrom(node44);
        com.google.javascript.jscomp.parsing.Config.LanguageMode languageMode47 = com.google.javascript.jscomp.parsing.Config.LanguageMode.ECMASCRIPT5;
        node45.putProp(24, (java.lang.Object) languageMode47);
        java.lang.String str49 = closureCodingConvention0.extractClassNameIfRequire(node18, node45);
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention50 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node54 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node56 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node58 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node60 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node62 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray63 = new com.google.javascript.rhino.Node[] { node54, node56, node58, node60, node62 };
        com.google.javascript.rhino.Node node64 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray63);
        com.google.javascript.rhino.Node node67 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node69 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node71 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node73 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node75 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray76 = new com.google.javascript.rhino.Node[] { node67, node69, node71, node73, node75 };
        com.google.javascript.rhino.Node node77 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray76);
        com.google.javascript.rhino.Node node78 = new com.google.javascript.rhino.Node(100, node64, node77);
        java.lang.String str79 = closureCodingConvention50.getSingletonGetterClassName(node78);
        com.google.javascript.rhino.Node node82 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node84 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node86 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node88 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node90 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray91 = new com.google.javascript.rhino.Node[] { node82, node84, node86, node88, node90 };
        com.google.javascript.rhino.Node node92 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray91);
        com.google.javascript.rhino.Node node94 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node95 = node92.copyInformationFrom(node94);
        java.lang.String str96 = node94.getString();
        node45.addChildAfter(node78, node94);
        node78.setVarArgs(false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertNotNull(nodeArray17);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertNull(node22);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(node32);
        org.junit.Assert.assertNotNull(node34);
        org.junit.Assert.assertNotNull(node36);
        org.junit.Assert.assertNotNull(node38);
        org.junit.Assert.assertNotNull(node40);
        org.junit.Assert.assertNotNull(nodeArray41);
        org.junit.Assert.assertNotNull(node44);
        org.junit.Assert.assertNotNull(node45);
        org.junit.Assert.assertTrue("'" + languageMode47 + "' != '" + com.google.javascript.jscomp.parsing.Config.LanguageMode.ECMASCRIPT5 + "'", languageMode47.equals(com.google.javascript.jscomp.parsing.Config.LanguageMode.ECMASCRIPT5));
        org.junit.Assert.assertNull(str49);
        org.junit.Assert.assertNotNull(node54);
        org.junit.Assert.assertNotNull(node56);
        org.junit.Assert.assertNotNull(node58);
        org.junit.Assert.assertNotNull(node60);
        org.junit.Assert.assertNotNull(node62);
        org.junit.Assert.assertNotNull(nodeArray63);
        org.junit.Assert.assertNotNull(node67);
        org.junit.Assert.assertNotNull(node69);
        org.junit.Assert.assertNotNull(node71);
        org.junit.Assert.assertNotNull(node73);
        org.junit.Assert.assertNotNull(node75);
        org.junit.Assert.assertNotNull(nodeArray76);
        org.junit.Assert.assertNull(str79);
        org.junit.Assert.assertNotNull(node82);
        org.junit.Assert.assertNotNull(node84);
        org.junit.Assert.assertNotNull(node86);
        org.junit.Assert.assertNotNull(node88);
        org.junit.Assert.assertNotNull(node90);
        org.junit.Assert.assertNotNull(nodeArray91);
        org.junit.Assert.assertNotNull(node94);
        org.junit.Assert.assertNotNull(node95);
        org.junit.Assert.assertTrue("'" + str96 + "' != '" + "" + "'", str96.equals(""));
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray13 = new com.google.javascript.rhino.Node[] { node4, node6, node8, node10, node12 };
        com.google.javascript.rhino.Node node14 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray13);
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node21 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray26 = new com.google.javascript.rhino.Node[] { node17, node19, node21, node23, node25 };
        com.google.javascript.rhino.Node node27 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray26);
        com.google.javascript.rhino.Node node28 = new com.google.javascript.rhino.Node(100, node14, node27);
        boolean boolean29 = closureCodingConvention0.isVarArgsParameter(node28);
        java.lang.String str30 = closureCodingConvention0.getExportPropertyFunction();
        boolean boolean32 = closureCodingConvention0.isConstant("hi!");
        com.google.javascript.rhino.jstype.FunctionType functionType33 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType34 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType35 = null;
        closureCodingConvention0.applySubclassRelationship(functionType33, functionType34, subclassType35);
        com.google.javascript.rhino.Node node37 = null;
        try {
            java.lang.String str38 = closureCodingConvention0.identifyTypeDefAssign(node37);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(nodeArray13);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNotNull(nodeArray26);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "goog.exportProperty" + "'", str30.equals("goog.exportProperty"));
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray13 = new com.google.javascript.rhino.Node[] { node4, node6, node8, node10, node12 };
        com.google.javascript.rhino.Node node14 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray13);
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node21 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray26 = new com.google.javascript.rhino.Node[] { node17, node19, node21, node23, node25 };
        com.google.javascript.rhino.Node node27 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray26);
        com.google.javascript.rhino.Node node28 = new com.google.javascript.rhino.Node(100, node14, node27);
        boolean boolean29 = closureCodingConvention0.isVarArgsParameter(node28);
        java.util.Collection<com.google.javascript.jscomp.CodingConvention.AssertionFunctionSpec> assertionFunctionSpecCollection30 = closureCodingConvention0.getAssertionFunctions();
        com.google.javascript.rhino.jstype.FunctionType functionType31 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType32 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType33 = null;
        try {
            closureCodingConvention0.applySingletonGetter(functionType31, functionType32, objectType33);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(nodeArray13);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNotNull(nodeArray26);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(assertionFunctionSpecCollection30);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.brokenClosureRequiresLevel;
        com.google.javascript.jscomp.CheckLevel checkLevel2 = com.google.javascript.jscomp.CheckLevel.WARNING;
        compilerOptions0.checkGlobalNamesLevel = checkLevel2;
        compilerOptions0.computeFunctionSideEffects = true;
        compilerOptions0.setShadowVariables(true);
        compilerOptions0.debugFunctionSideEffectsPath = "goog.global";
        java.lang.String str10 = compilerOptions0.inputDelimiter;
        compilerOptions0.inputDelimiter = "";
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + checkLevel2 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel2.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "// Input %num%" + "'", str10.equals("// Input %num%"));
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        java.io.InputStream inputStream1 = null;
        try {
            com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromInputStream("", inputStream1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile3 = com.google.javascript.jscomp.JSSourceFile.fromFile("Not declared as a constructor");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile5 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.CompilerInput compilerInput6 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile5);
        com.google.javascript.jscomp.CompilerInput compilerInput9 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput6, "hi!", false);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile11 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        compilerInput6.setSourceFile((com.google.javascript.jscomp.SourceFile) jSSourceFile11);
        java.lang.String str13 = jSSourceFile11.toString();
        com.google.javascript.jscomp.CompilerOptions compilerOptions14 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean15 = compilerOptions14.aliasAllStrings;
        compilerOptions14.setGenerateExports(true);
        com.google.javascript.jscomp.Result result18 = compiler1.compile(jSSourceFile3, jSSourceFile11, compilerOptions14);
        compilerOptions14.setChainCalls(true);
        org.junit.Assert.assertNotNull(jSSourceFile3);
        org.junit.Assert.assertNotNull(jSSourceFile5);
        org.junit.Assert.assertNotNull(jSSourceFile11);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(result18);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newString("");
        node1.setCharno(42);
        org.junit.Assert.assertNotNull(node1);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        try {
            com.google.javascript.rhino.EcmaError ecmaError2 = com.google.javascript.rhino.ScriptRuntime.typeError1("", "TypeError");
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property ");
        } catch (java.lang.RuntimeException e) {
        }
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.ErrorManager errorManager1 = compiler0.getErrorManager();
        org.junit.Assert.assertNotNull(errorManager1);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile1 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        java.lang.String str3 = jSSourceFile1.getLine(2);
        org.junit.Assert.assertNotNull(jSSourceFile1);
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        com.google.javascript.jscomp.AbstractCompiler abstractCompiler0 = null;
        com.google.javascript.jscomp.NodeTraversal.Callback callback1 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal2 = new com.google.javascript.jscomp.NodeTraversal(abstractCompiler0, callback1);
        boolean boolean3 = nodeTraversal2.hasScope();
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray15 = new com.google.javascript.rhino.Node[] { node6, node8, node10, node12, node14 };
        com.google.javascript.rhino.Node node16 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray15);
        com.google.javascript.jscomp.DiagnosticType diagnosticType17 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        java.lang.String[] strArray18 = com.google.javascript.rhino.ScriptRuntime.emptyStrings;
        com.google.javascript.jscomp.JSError jSError19 = com.google.javascript.jscomp.JSError.make(diagnosticType17, strArray18);
        com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.Node.newString((int) (short) 0, "hi!", 100, (-2));
        com.google.javascript.jscomp.DiagnosticType diagnosticType26 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray27 = com.google.javascript.rhino.ScriptRuntime.emptyStrings;
        com.google.javascript.jscomp.JSError jSError28 = com.google.javascript.jscomp.JSError.make("", node25, diagnosticType26, strArray27);
        try {
            nodeTraversal2.report(node16, diagnosticType17, strArray27);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNotNull(nodeArray15);
        org.junit.Assert.assertNotNull(diagnosticType17);
        org.junit.Assert.assertNotNull(strArray18);
        org.junit.Assert.assertNotNull(jSError19);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNotNull(diagnosticType26);
        org.junit.Assert.assertNotNull(strArray27);
        org.junit.Assert.assertNotNull(jSError28);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray13 = new com.google.javascript.rhino.Node[] { node4, node6, node8, node10, node12 };
        com.google.javascript.rhino.Node node14 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray13);
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node21 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray26 = new com.google.javascript.rhino.Node[] { node17, node19, node21, node23, node25 };
        com.google.javascript.rhino.Node node27 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray26);
        com.google.javascript.rhino.Node node28 = new com.google.javascript.rhino.Node(100, node14, node27);
        com.google.javascript.rhino.Node node30 = com.google.javascript.rhino.Node.newString("");
        try {
            com.google.javascript.rhino.Node node33 = new com.google.javascript.rhino.Node(4095, node27, node30, 43, 5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: first new child has existing parent");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(nodeArray13);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNotNull(nodeArray26);
        org.junit.Assert.assertNotNull(node30);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        com.google.javascript.jscomp.CheckLevel checkLevel1 = null;
        com.google.javascript.jscomp.DiagnosticType diagnosticType3 = com.google.javascript.jscomp.DiagnosticType.make("error reporter", checkLevel1, "goog.global");
        org.junit.Assert.assertNotNull(diagnosticType3);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.NodeTraversal.Callback callback1 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal2 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler0, callback1);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile4 = com.google.javascript.jscomp.JSSourceFile.fromFile("Not declared as a constructor");
        java.io.PrintStream printStream5 = null;
        com.google.javascript.jscomp.Compiler compiler6 = new com.google.javascript.jscomp.Compiler(printStream5);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile8 = com.google.javascript.jscomp.JSSourceFile.fromFile("Not declared as a constructor");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile10 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.CompilerInput compilerInput11 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile10);
        com.google.javascript.jscomp.CompilerInput compilerInput14 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput11, "hi!", false);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile16 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        compilerInput11.setSourceFile((com.google.javascript.jscomp.SourceFile) jSSourceFile16);
        java.lang.String str18 = jSSourceFile16.toString();
        com.google.javascript.jscomp.CompilerOptions compilerOptions19 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean20 = compilerOptions19.aliasAllStrings;
        compilerOptions19.setGenerateExports(true);
        com.google.javascript.jscomp.Result result23 = compiler6.compile(jSSourceFile8, jSSourceFile16, compilerOptions19);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile25 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.CompilerInput compilerInput26 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile25);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile28 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.CompilerInput compilerInput29 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile28);
        com.google.javascript.jscomp.CompilerInput compilerInput32 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput29, "hi!", false);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile34 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        compilerInput29.setSourceFile((com.google.javascript.jscomp.SourceFile) jSSourceFile34);
        java.lang.String str36 = jSSourceFile34.toString();
        java.io.PrintStream printStream37 = null;
        com.google.javascript.jscomp.Compiler compiler38 = new com.google.javascript.jscomp.Compiler(printStream37);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile40 = com.google.javascript.jscomp.JSSourceFile.fromFile("Not declared as a constructor");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile42 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.CompilerInput compilerInput43 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile42);
        com.google.javascript.jscomp.CompilerInput compilerInput46 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput43, "hi!", false);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile48 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        compilerInput43.setSourceFile((com.google.javascript.jscomp.SourceFile) jSSourceFile48);
        java.lang.String str50 = jSSourceFile48.toString();
        com.google.javascript.jscomp.CompilerOptions compilerOptions51 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean52 = compilerOptions51.aliasAllStrings;
        compilerOptions51.setGenerateExports(true);
        com.google.javascript.jscomp.Result result55 = compiler38.compile(jSSourceFile40, jSSourceFile48, compilerOptions51);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile57 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.CompilerInput compilerInput58 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile57);
        com.google.javascript.jscomp.Region region60 = jSSourceFile57.getRegion(24);
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray61 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile4, jSSourceFile16, jSSourceFile25, jSSourceFile34, jSSourceFile48, jSSourceFile57 };
        java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList62 = new java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile>();
        boolean boolean63 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList62, jSSourceFileArray61);
        com.google.javascript.jscomp.JSModule[] jSModuleArray64 = new com.google.javascript.jscomp.JSModule[] {};
        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList65 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
        boolean boolean66 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList65, jSModuleArray64);
        com.google.javascript.jscomp.CompilerOptions compilerOptions67 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel68 = compilerOptions67.brokenClosureRequiresLevel;
        com.google.javascript.jscomp.CheckLevel checkLevel69 = com.google.javascript.jscomp.CheckLevel.WARNING;
        compilerOptions67.checkGlobalNamesLevel = checkLevel69;
        compilerOptions67.computeFunctionSideEffects = true;
        boolean boolean73 = compilerOptions67.removeDeadCode;
        com.google.javascript.jscomp.CompilerOptions.TweakProcessing tweakProcessing74 = compilerOptions67.getTweakProcessing();
        com.google.javascript.jscomp.Result result75 = compiler0.compileModules((java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList62, (java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList65, compilerOptions67);
        java.lang.String str78 = compiler0.getSourceLine("com.google.javascript.rhino.EcmaError: TypeError: -1 is not a function, it is java.lang.Byte.", 7);
        boolean boolean79 = compiler0.acceptConstKeyword();
        com.google.javascript.jscomp.SourceMap sourceMap80 = compiler0.getSourceMap();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile82 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.CompilerInput compilerInput83 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile82);
        com.google.javascript.jscomp.CompilerInput compilerInput86 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput83, "hi!", false);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile88 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        compilerInput83.setSourceFile((com.google.javascript.jscomp.SourceFile) jSSourceFile88);
        java.lang.String str90 = jSSourceFile88.toString();
        com.google.javascript.jscomp.CompilerInput compilerInput91 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile88);
        jSSourceFile88.clearCachedSource();
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray93 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile88 };
        com.google.javascript.jscomp.JSModule[] jSModuleArray94 = null;
        com.google.javascript.jscomp.CompilerOptions compilerOptions95 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel96 = compilerOptions95.brokenClosureRequiresLevel;
        compilerOptions95.inlineConstantVars = false;
        try {
            compiler0.init(jSSourceFileArray93, jSModuleArray94, compilerOptions95);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile4);
        org.junit.Assert.assertNotNull(jSSourceFile8);
        org.junit.Assert.assertNotNull(jSSourceFile10);
        org.junit.Assert.assertNotNull(jSSourceFile16);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "" + "'", str18.equals(""));
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(result23);
        org.junit.Assert.assertNotNull(jSSourceFile25);
        org.junit.Assert.assertNotNull(jSSourceFile28);
        org.junit.Assert.assertNotNull(jSSourceFile34);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "" + "'", str36.equals(""));
        org.junit.Assert.assertNotNull(jSSourceFile40);
        org.junit.Assert.assertNotNull(jSSourceFile42);
        org.junit.Assert.assertNotNull(jSSourceFile48);
        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "" + "'", str50.equals(""));
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertNotNull(result55);
        org.junit.Assert.assertNotNull(jSSourceFile57);
        org.junit.Assert.assertNull(region60);
        org.junit.Assert.assertNotNull(jSSourceFileArray61);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + true + "'", boolean63 == true);
        org.junit.Assert.assertNotNull(jSModuleArray64);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertTrue("'" + checkLevel68 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel68.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + checkLevel69 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel69.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
        org.junit.Assert.assertTrue("'" + tweakProcessing74 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TweakProcessing.OFF + "'", tweakProcessing74.equals(com.google.javascript.jscomp.CompilerOptions.TweakProcessing.OFF));
        org.junit.Assert.assertNotNull(result75);
        org.junit.Assert.assertNull(str78);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
        org.junit.Assert.assertNull(sourceMap80);
        org.junit.Assert.assertNotNull(jSSourceFile82);
        org.junit.Assert.assertNotNull(jSSourceFile88);
        org.junit.Assert.assertTrue("'" + str90 + "' != '" + "" + "'", str90.equals(""));
        org.junit.Assert.assertNotNull(jSSourceFileArray93);
        org.junit.Assert.assertTrue("'" + checkLevel96 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel96.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        long long1 = com.google.javascript.rhino.ScriptRuntime.testUint32String("language version");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1L) + "'", long1 == (-1L));
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.brokenClosureRequiresLevel;
        com.google.javascript.jscomp.CheckLevel checkLevel2 = com.google.javascript.jscomp.CheckLevel.WARNING;
        compilerOptions0.checkGlobalNamesLevel = checkLevel2;
        com.google.javascript.jscomp.ErrorFormat errorFormat4 = null;
        compilerOptions0.errorFormat = errorFormat4;
        boolean boolean6 = compilerOptions0.ambiguateProperties;
        com.google.javascript.jscomp.CompilerOptions compilerOptions7 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel8 = compilerOptions7.brokenClosureRequiresLevel;
        compilerOptions7.setManageClosureDependencies(true);
        java.lang.String[] strArray18 = new java.lang.String[] { "goog.exportProperty", "Not declared as a type name", "error reporter", "DiagnosticGroup<undefinedVars>", "goog.exportProperty", "Not declared as a constructor" };
        java.util.ArrayList<java.lang.String> strList19 = new java.util.ArrayList<java.lang.String>();
        boolean boolean20 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strList19, strArray18);
        compilerOptions7.setReplaceStringsConfiguration("goog.exportProperty", (java.util.List<java.lang.String>) strList19);
        compilerOptions7.decomposeExpressions = false;
        com.google.javascript.jscomp.CheckLevel checkLevel24 = compilerOptions7.checkMissingGetCssNameLevel;
        compilerOptions0.checkGlobalThisLevel = checkLevel24;
        compilerOptions0.unaliasableGlobals = "JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of optimization iterations: {0}";
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + checkLevel2 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel2.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + checkLevel8 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel8.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(strArray18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + checkLevel24 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel24.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        int int0 = com.google.javascript.rhino.Node.VAR_ARGS_NAME;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 29 + "'", int0 == 29);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile5 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.CompilerInput compilerInput6 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile5);
        com.google.javascript.jscomp.CompilerInput compilerInput9 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput6, "hi!", false);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile11 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        compilerInput6.setSourceFile((com.google.javascript.jscomp.SourceFile) jSSourceFile11);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile14 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray15 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile2, jSSourceFile11, jSSourceFile14 };
        java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList16 = new java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile>();
        boolean boolean17 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList16, jSSourceFileArray15);
        com.google.javascript.jscomp.JSModule[] jSModuleArray18 = new com.google.javascript.jscomp.JSModule[] {};
        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList19 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
        boolean boolean20 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList19, jSModuleArray18);
        com.google.javascript.jscomp.CompilerOptions compilerOptions21 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions21.checkDuplicateMessages = false;
        boolean boolean24 = compilerOptions21.inlineAnonymousFunctionExpressions;
        compilerOptions21.crossModuleMethodMotion = true;
        com.google.javascript.jscomp.Result result27 = compiler0.compileModules((java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList16, (java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList19, compilerOptions21);
        com.google.javascript.jscomp.ErrorManager errorManager28 = compiler0.getErrorManager();
        com.google.javascript.jscomp.Compiler.IntermediateState intermediateState29 = null;
        try {
            compiler0.setState(intermediateState29);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile2);
        org.junit.Assert.assertNotNull(jSSourceFile5);
        org.junit.Assert.assertNotNull(jSSourceFile11);
        org.junit.Assert.assertNotNull(jSSourceFile14);
        org.junit.Assert.assertNotNull(jSSourceFileArray15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(jSModuleArray18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(result27);
        org.junit.Assert.assertNotNull(errorManager28);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.NodeTraversal.Callback callback1 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal2 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler0, callback1);
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention3 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray16 = new com.google.javascript.rhino.Node[] { node7, node9, node11, node13, node15 };
        com.google.javascript.rhino.Node node17 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray16);
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node22 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node24 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node26 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node28 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray29 = new com.google.javascript.rhino.Node[] { node20, node22, node24, node26, node28 };
        com.google.javascript.rhino.Node node30 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray29);
        com.google.javascript.rhino.Node node31 = new com.google.javascript.rhino.Node(100, node17, node30);
        boolean boolean32 = closureCodingConvention3.isVarArgsParameter(node31);
        java.lang.String str33 = closureCodingConvention3.getExportPropertyFunction();
        boolean boolean36 = closureCodingConvention3.isExported("goog.exportProperty", false);
        com.google.javascript.rhino.Node node40 = com.google.javascript.rhino.Node.newNumber(100.0d, 4095, 9);
        java.util.Set<java.lang.String> strSet41 = node40.getDirectives();
        boolean boolean42 = closureCodingConvention3.isVarArgsParameter(node40);
        com.google.javascript.rhino.Node node45 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node47 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node49 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node51 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node53 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray54 = new com.google.javascript.rhino.Node[] { node45, node47, node49, node51, node53 };
        com.google.javascript.rhino.Node node55 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray54);
        int int56 = node55.getSideEffectFlags();
        node40.addChildrenToFront(node55);
        com.google.javascript.rhino.Node node58 = node55.cloneNode();
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder59 = node58.getJsDocBuilderForNode();
        try {
            nodeTraversal2.traverse(node58);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: INTERNAL COMPILER ERROR.\nPlease report this problem.\nnull");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertNotNull(nodeArray16);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertNotNull(nodeArray29);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "goog.exportProperty" + "'", str33.equals("goog.exportProperty"));
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(node40);
        org.junit.Assert.assertNull(strSet41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(node45);
        org.junit.Assert.assertNotNull(node47);
        org.junit.Assert.assertNotNull(node49);
        org.junit.Assert.assertNotNull(node51);
        org.junit.Assert.assertNotNull(node53);
        org.junit.Assert.assertNotNull(nodeArray54);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 0 + "'", int56 == 0);
        org.junit.Assert.assertNotNull(node58);
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder59);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        com.google.javascript.jscomp.SourceAst sourceAst0 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(sourceAst0, "Not declared as a constructor", true);
        try {
            java.lang.String str4 = compilerInput3.getCode();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy0 = com.google.javascript.jscomp.VariableRenamingPolicy.UNSPECIFIED;
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy0 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.UNSPECIFIED + "'", variableRenamingPolicy0.equals(com.google.javascript.jscomp.VariableRenamingPolicy.UNSPECIFIED));
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        com.google.javascript.rhino.Node.SideEffectFlags sideEffectFlags1 = new com.google.javascript.rhino.Node.SideEffectFlags(130);
        sideEffectFlags1.setMutatesGlobalState();
        sideEffectFlags1.clearAllFlags();
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        int int0 = com.google.javascript.rhino.Context.FEATURE_STRICT_MODE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 11 + "'", int0 == 11);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        java.lang.String str1 = com.google.javascript.rhino.jstype.ObjectType.createDelegateSuffix("DiagnosticGroup<strictModuleDepCheck>");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "(DiagnosticGroup<strictModuleDepCheck>)" + "'", str1.equals("(DiagnosticGroup<strictModuleDepCheck>)"));
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        com.google.javascript.jscomp.DiagnosticType diagnosticType0 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        java.lang.String str1 = diagnosticType0.key;
        java.lang.Class<?> wildcardClass2 = diagnosticType0.getClass();
        com.google.javascript.jscomp.CompilerOptions compilerOptions3 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel4 = compilerOptions3.brokenClosureRequiresLevel;
        com.google.javascript.jscomp.CheckLevel checkLevel5 = com.google.javascript.jscomp.CheckLevel.WARNING;
        compilerOptions3.checkGlobalNamesLevel = checkLevel5;
        compilerOptions3.computeFunctionSideEffects = true;
        compilerOptions3.closurePass = false;
        com.google.javascript.jscomp.ErrorFormat errorFormat11 = compilerOptions3.errorFormat;
        compilerOptions3.prettyPrint = false;
        com.google.javascript.jscomp.CheckLevel checkLevel14 = com.google.javascript.jscomp.CheckLevel.ERROR;
        compilerOptions3.reportMissingOverride = checkLevel14;
        diagnosticType0.level = checkLevel14;
        org.junit.Assert.assertNotNull(diagnosticType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "JSC_OPTIMIZE_LOOP_ERROR" + "'", str1.equals("JSC_OPTIMIZE_LOOP_ERROR"));
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertTrue("'" + checkLevel4 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel4.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + checkLevel5 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel5.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
        org.junit.Assert.assertNotNull(errorFormat11);
        org.junit.Assert.assertTrue("'" + checkLevel14 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel14.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        int int0 = com.google.javascript.rhino.Node.CONTINUE_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray12 = new com.google.javascript.rhino.Node[] { node3, node5, node7, node9, node11 };
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray12);
        int int14 = node13.getSideEffectFlags();
        com.google.javascript.rhino.Node node15 = node13.getNext();
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention16 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node22 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node24 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node26 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node28 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray29 = new com.google.javascript.rhino.Node[] { node20, node22, node24, node26, node28 };
        com.google.javascript.rhino.Node node30 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray29);
        com.google.javascript.rhino.Node node33 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node35 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node37 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node39 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node41 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray42 = new com.google.javascript.rhino.Node[] { node33, node35, node37, node39, node41 };
        com.google.javascript.rhino.Node node43 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray42);
        com.google.javascript.rhino.Node node44 = new com.google.javascript.rhino.Node(100, node30, node43);
        java.lang.String str45 = closureCodingConvention16.getSingletonGetterClassName(node44);
        node44.setWasEmptyNode(true);
        com.google.javascript.rhino.Node node51 = com.google.javascript.rhino.Node.newNumber(100.0d, 4095, 9);
        java.util.Set<java.lang.String> strSet52 = node51.getDirectives();
        com.google.javascript.rhino.Node node55 = new com.google.javascript.rhino.Node((int) (short) 0, node13, node44, node51, (int) (short) 10, (int) ' ');
        com.google.javascript.rhino.Node node57 = node44.getAncestor(130);
        try {
            boolean boolean58 = node57.isNoSideEffectsCall();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertNotNull(nodeArray12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNull(node15);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertNotNull(nodeArray29);
        org.junit.Assert.assertNotNull(node33);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertNotNull(node37);
        org.junit.Assert.assertNotNull(node39);
        org.junit.Assert.assertNotNull(node41);
        org.junit.Assert.assertNotNull(nodeArray42);
        org.junit.Assert.assertNull(str45);
        org.junit.Assert.assertNotNull(node51);
        org.junit.Assert.assertNull(strSet52);
        org.junit.Assert.assertNull(node57);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.brokenClosureRequiresLevel;
        com.google.javascript.jscomp.CheckLevel checkLevel2 = com.google.javascript.jscomp.CheckLevel.WARNING;
        compilerOptions0.checkGlobalNamesLevel = checkLevel2;
        compilerOptions0.computeFunctionSideEffects = true;
        boolean boolean6 = compilerOptions0.removeDeadCode;
        compilerOptions0.inlineLocalVariables = false;
        compilerOptions0.setPropertyAffinity(true);
        com.google.javascript.jscomp.CompilerOptions compilerOptions11 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel12 = compilerOptions11.brokenClosureRequiresLevel;
        com.google.javascript.jscomp.CheckLevel checkLevel13 = com.google.javascript.jscomp.CheckLevel.WARNING;
        compilerOptions11.checkGlobalNamesLevel = checkLevel13;
        compilerOptions11.computeFunctionSideEffects = true;
        compilerOptions11.setDefineToStringLiteral("", "Unknown class name");
        compilerOptions11.checkTypedPropertyCalls = true;
        com.google.javascript.jscomp.ErrorFormat errorFormat22 = compilerOptions11.errorFormat;
        compilerOptions0.errorFormat = errorFormat22;
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + checkLevel2 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel2.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + checkLevel12 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel12.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + checkLevel13 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel13.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
        org.junit.Assert.assertNotNull(errorFormat22);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile3 = com.google.javascript.jscomp.JSSourceFile.fromFile("Not declared as a constructor");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile5 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.CompilerInput compilerInput6 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile5);
        com.google.javascript.jscomp.CompilerInput compilerInput9 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput6, "hi!", false);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile11 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        compilerInput6.setSourceFile((com.google.javascript.jscomp.SourceFile) jSSourceFile11);
        java.lang.String str13 = jSSourceFile11.toString();
        com.google.javascript.jscomp.CompilerOptions compilerOptions14 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean15 = compilerOptions14.aliasAllStrings;
        compilerOptions14.setGenerateExports(true);
        com.google.javascript.jscomp.Result result18 = compiler1.compile(jSSourceFile3, jSSourceFile11, compilerOptions14);
        com.google.javascript.jscomp.CompilerInput compilerInput19 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile11);
        boolean boolean20 = compilerInput19.isExtern();
        org.junit.Assert.assertNotNull(jSSourceFile3);
        org.junit.Assert.assertNotNull(jSSourceFile5);
        org.junit.Assert.assertNotNull(jSSourceFile11);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(result18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.checkDuplicateMessages = false;
        boolean boolean3 = compilerOptions0.inlineAnonymousFunctionExpressions;
        compilerOptions0.recordFunctionInformation = true;
        boolean boolean6 = compilerOptions0.checkCaja;
        java.util.Set<java.lang.String> strSet7 = compilerOptions0.stripNamePrefixes;
        boolean boolean8 = compilerOptions0.inlineFunctions;
        boolean boolean9 = compilerOptions0.aliasKeywords;
        boolean boolean10 = compilerOptions0.checkUnusedPropertiesEarly;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(strSet7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.NodeTraversal.Callback callback1 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal2 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler0, callback1);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile4 = com.google.javascript.jscomp.JSSourceFile.fromFile("Not declared as a constructor");
        java.io.PrintStream printStream5 = null;
        com.google.javascript.jscomp.Compiler compiler6 = new com.google.javascript.jscomp.Compiler(printStream5);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile8 = com.google.javascript.jscomp.JSSourceFile.fromFile("Not declared as a constructor");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile10 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.CompilerInput compilerInput11 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile10);
        com.google.javascript.jscomp.CompilerInput compilerInput14 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput11, "hi!", false);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile16 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        compilerInput11.setSourceFile((com.google.javascript.jscomp.SourceFile) jSSourceFile16);
        java.lang.String str18 = jSSourceFile16.toString();
        com.google.javascript.jscomp.CompilerOptions compilerOptions19 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean20 = compilerOptions19.aliasAllStrings;
        compilerOptions19.setGenerateExports(true);
        com.google.javascript.jscomp.Result result23 = compiler6.compile(jSSourceFile8, jSSourceFile16, compilerOptions19);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile25 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.CompilerInput compilerInput26 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile25);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile28 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.CompilerInput compilerInput29 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile28);
        com.google.javascript.jscomp.CompilerInput compilerInput32 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput29, "hi!", false);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile34 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        compilerInput29.setSourceFile((com.google.javascript.jscomp.SourceFile) jSSourceFile34);
        java.lang.String str36 = jSSourceFile34.toString();
        java.io.PrintStream printStream37 = null;
        com.google.javascript.jscomp.Compiler compiler38 = new com.google.javascript.jscomp.Compiler(printStream37);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile40 = com.google.javascript.jscomp.JSSourceFile.fromFile("Not declared as a constructor");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile42 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.CompilerInput compilerInput43 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile42);
        com.google.javascript.jscomp.CompilerInput compilerInput46 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput43, "hi!", false);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile48 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        compilerInput43.setSourceFile((com.google.javascript.jscomp.SourceFile) jSSourceFile48);
        java.lang.String str50 = jSSourceFile48.toString();
        com.google.javascript.jscomp.CompilerOptions compilerOptions51 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean52 = compilerOptions51.aliasAllStrings;
        compilerOptions51.setGenerateExports(true);
        com.google.javascript.jscomp.Result result55 = compiler38.compile(jSSourceFile40, jSSourceFile48, compilerOptions51);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile57 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.CompilerInput compilerInput58 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile57);
        com.google.javascript.jscomp.Region region60 = jSSourceFile57.getRegion(24);
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray61 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile4, jSSourceFile16, jSSourceFile25, jSSourceFile34, jSSourceFile48, jSSourceFile57 };
        java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList62 = new java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile>();
        boolean boolean63 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList62, jSSourceFileArray61);
        com.google.javascript.jscomp.JSModule[] jSModuleArray64 = new com.google.javascript.jscomp.JSModule[] {};
        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList65 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
        boolean boolean66 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList65, jSModuleArray64);
        com.google.javascript.jscomp.CompilerOptions compilerOptions67 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel68 = compilerOptions67.brokenClosureRequiresLevel;
        com.google.javascript.jscomp.CheckLevel checkLevel69 = com.google.javascript.jscomp.CheckLevel.WARNING;
        compilerOptions67.checkGlobalNamesLevel = checkLevel69;
        compilerOptions67.computeFunctionSideEffects = true;
        boolean boolean73 = compilerOptions67.removeDeadCode;
        com.google.javascript.jscomp.CompilerOptions.TweakProcessing tweakProcessing74 = compilerOptions67.getTweakProcessing();
        com.google.javascript.jscomp.Result result75 = compiler0.compileModules((java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList62, (java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList65, compilerOptions67);
        compiler0.reportCodeChange();
        org.junit.Assert.assertNotNull(jSSourceFile4);
        org.junit.Assert.assertNotNull(jSSourceFile8);
        org.junit.Assert.assertNotNull(jSSourceFile10);
        org.junit.Assert.assertNotNull(jSSourceFile16);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "" + "'", str18.equals(""));
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(result23);
        org.junit.Assert.assertNotNull(jSSourceFile25);
        org.junit.Assert.assertNotNull(jSSourceFile28);
        org.junit.Assert.assertNotNull(jSSourceFile34);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "" + "'", str36.equals(""));
        org.junit.Assert.assertNotNull(jSSourceFile40);
        org.junit.Assert.assertNotNull(jSSourceFile42);
        org.junit.Assert.assertNotNull(jSSourceFile48);
        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "" + "'", str50.equals(""));
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertNotNull(result55);
        org.junit.Assert.assertNotNull(jSSourceFile57);
        org.junit.Assert.assertNull(region60);
        org.junit.Assert.assertNotNull(jSSourceFileArray61);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + true + "'", boolean63 == true);
        org.junit.Assert.assertNotNull(jSModuleArray64);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertTrue("'" + checkLevel68 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel68.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + checkLevel69 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel69.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
        org.junit.Assert.assertTrue("'" + tweakProcessing74 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TweakProcessing.OFF + "'", tweakProcessing74.equals(com.google.javascript.jscomp.CompilerOptions.TweakProcessing.OFF));
        org.junit.Assert.assertNotNull(result75);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray12 = new com.google.javascript.rhino.Node[] { node3, node5, node7, node9, node11 };
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray12);
        int int14 = node13.getSideEffectFlags();
        com.google.javascript.rhino.Node node15 = node13.getNext();
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention16 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node22 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node24 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node26 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node28 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray29 = new com.google.javascript.rhino.Node[] { node20, node22, node24, node26, node28 };
        com.google.javascript.rhino.Node node30 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray29);
        com.google.javascript.rhino.Node node33 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node35 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node37 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node39 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node41 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray42 = new com.google.javascript.rhino.Node[] { node33, node35, node37, node39, node41 };
        com.google.javascript.rhino.Node node43 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray42);
        com.google.javascript.rhino.Node node44 = new com.google.javascript.rhino.Node(100, node30, node43);
        java.lang.String str45 = closureCodingConvention16.getSingletonGetterClassName(node44);
        node44.setWasEmptyNode(true);
        com.google.javascript.rhino.Node node51 = com.google.javascript.rhino.Node.newNumber(100.0d, 4095, 9);
        java.util.Set<java.lang.String> strSet52 = node51.getDirectives();
        com.google.javascript.rhino.Node node55 = new com.google.javascript.rhino.Node((int) (short) 0, node13, node44, node51, (int) (short) 10, (int) ' ');
        try {
            node55.setString("hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: EOF 10 is not a string node");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertNotNull(nodeArray12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNull(node15);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertNotNull(nodeArray29);
        org.junit.Assert.assertNotNull(node33);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertNotNull(node37);
        org.junit.Assert.assertNotNull(node39);
        org.junit.Assert.assertNotNull(node41);
        org.junit.Assert.assertNotNull(nodeArray42);
        org.junit.Assert.assertNull(str45);
        org.junit.Assert.assertNotNull(node51);
        org.junit.Assert.assertNull(strSet52);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray11 = new com.google.javascript.rhino.Node[] { node2, node4, node6, node8, node10 };
        com.google.javascript.rhino.Node node12 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray11);
        int int13 = node12.getSideEffectFlags();
        com.google.javascript.jscomp.SourceFile sourceFile17 = com.google.javascript.jscomp.SourceFile.fromCode("goog.exportProperty", "language version", "goog.exportProperty");
        java.io.Reader reader18 = sourceFile17.getCodeReader();
        com.google.javascript.rhino.Node.SideEffectFlags sideEffectFlags20 = new com.google.javascript.rhino.Node.SideEffectFlags(17);
        sideEffectFlags20.setAllFlags();
        sideEffectFlags20.setMutatesGlobalState();
        java.lang.RuntimeException runtimeException23 = com.google.javascript.rhino.ScriptRuntime.undefWriteError((java.lang.Object) int13, (java.lang.Object) sourceFile17, (java.lang.Object) sideEffectFlags20);
        com.google.javascript.rhino.EcmaError ecmaError25 = com.google.javascript.rhino.ScriptRuntime.typeError("");
        java.lang.String str26 = ecmaError25.getSourceName();
        int int27 = ecmaError25.columnNumber();
        int int28 = ecmaError25.getColumnNumber();
        runtimeException23.addSuppressed((java.lang.Throwable) ecmaError25);
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(nodeArray11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(sourceFile17);
        org.junit.Assert.assertNotNull(reader18);
        org.junit.Assert.assertNotNull(runtimeException23);
        org.junit.Assert.assertNotNull(ecmaError25);
        org.junit.Assert.assertNull(str26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.CHECK_REGEXP;
        com.google.javascript.jscomp.DiagnosticType diagnosticType6 = com.google.javascript.jscomp.DiagnosticType.warning("1", "");
        java.lang.String[] strArray7 = null;
        com.google.javascript.jscomp.JSError jSError8 = com.google.javascript.jscomp.JSError.make("goog.global", (int) (byte) 10, 15, diagnosticType6, strArray7);
        boolean boolean9 = diagnosticGroup0.matches(jSError8);
        org.junit.Assert.assertNotNull(diagnosticGroup0);
        org.junit.Assert.assertNotNull(diagnosticType6);
        org.junit.Assert.assertNotNull(jSError8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        com.google.javascript.rhino.Node.SideEffectFlags sideEffectFlags1 = new com.google.javascript.rhino.Node.SideEffectFlags(10);
        boolean boolean2 = sideEffectFlags1.areAllFlagsSet();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        com.google.javascript.jscomp.DiagnosticType diagnosticType2 = com.google.javascript.jscomp.DiagnosticType.warning("1", "");
        java.text.MessageFormat messageFormat3 = diagnosticType2.format;
        org.junit.Assert.assertNotNull(diagnosticType2);
        org.junit.Assert.assertNotNull(messageFormat3);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        com.google.javascript.rhino.Node node1 = null;
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention2 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray15 = new com.google.javascript.rhino.Node[] { node6, node8, node10, node12, node14 };
        com.google.javascript.rhino.Node node16 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray15);
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node21 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node27 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray28 = new com.google.javascript.rhino.Node[] { node19, node21, node23, node25, node27 };
        com.google.javascript.rhino.Node node29 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray28);
        com.google.javascript.rhino.Node node30 = new com.google.javascript.rhino.Node(100, node16, node29);
        java.lang.String str31 = closureCodingConvention2.getSingletonGetterClassName(node30);
        com.google.javascript.rhino.Node node32 = node30.getFirstChild();
        try {
            com.google.javascript.rhino.Node node33 = new com.google.javascript.rhino.Node(38, node1, node30);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNotNull(nodeArray15);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNotNull(node27);
        org.junit.Assert.assertNotNull(nodeArray28);
        org.junit.Assert.assertNull(str31);
        org.junit.Assert.assertNotNull(node32);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.brokenClosureRequiresLevel;
        compilerOptions0.setManageClosureDependencies(true);
        java.lang.String[] strArray11 = new java.lang.String[] { "goog.exportProperty", "Not declared as a type name", "error reporter", "DiagnosticGroup<undefinedVars>", "goog.exportProperty", "Not declared as a constructor" };
        java.util.ArrayList<java.lang.String> strList12 = new java.util.ArrayList<java.lang.String>();
        boolean boolean13 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strList12, strArray11);
        compilerOptions0.setReplaceStringsConfiguration("goog.exportProperty", (java.util.List<java.lang.String>) strList12);
        compilerOptions0.ideMode = false;
        byte[] byteArray22 = new byte[] { (byte) 100, (byte) 1, (byte) 10, (byte) 10, (byte) 1 };
        compilerOptions0.inputVariableMapSerialized = byteArray22;
        compilerOptions0.inlineFunctions = false;
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(strArray11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(byteArray22);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.Node.newString(36, "// Input %num%");
        java.lang.String str3 = node2.getString();
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "// Input %num%" + "'", str3.equals("// Input %num%"));
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        com.google.javascript.rhino.Context context0 = com.google.javascript.rhino.Context.enter();
        try {
            context0.unseal((java.lang.Object) 110);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(context0);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        boolean boolean2 = closureCodingConvention0.isConstant("");
        boolean boolean4 = closureCodingConvention0.isValidEnumKey("hi!");
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray17 = new com.google.javascript.rhino.Node[] { node8, node10, node12, node14, node16 };
        com.google.javascript.rhino.Node node18 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray17);
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node21 = node18.copyInformationFrom(node20);
        com.google.javascript.rhino.Node node22 = node18.getParent();
        com.google.javascript.rhino.Node node23 = new com.google.javascript.rhino.Node((int) (short) -1, node18);
        com.google.javascript.rhino.Node node28 = com.google.javascript.rhino.Node.newString((int) (short) 0, "hi!", 100, (-2));
        boolean boolean29 = node18.isEquivalentTo(node28);
        com.google.javascript.rhino.Node node32 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node34 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node36 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node38 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node40 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray41 = new com.google.javascript.rhino.Node[] { node32, node34, node36, node38, node40 };
        com.google.javascript.rhino.Node node42 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray41);
        com.google.javascript.rhino.Node node44 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node45 = node42.copyInformationFrom(node44);
        com.google.javascript.jscomp.parsing.Config.LanguageMode languageMode47 = com.google.javascript.jscomp.parsing.Config.LanguageMode.ECMASCRIPT5;
        node45.putProp(24, (java.lang.Object) languageMode47);
        java.lang.String str49 = closureCodingConvention0.extractClassNameIfRequire(node18, node45);
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention50 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node54 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node56 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node58 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node60 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node62 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray63 = new com.google.javascript.rhino.Node[] { node54, node56, node58, node60, node62 };
        com.google.javascript.rhino.Node node64 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray63);
        com.google.javascript.rhino.Node node67 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node69 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node71 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node73 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node75 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray76 = new com.google.javascript.rhino.Node[] { node67, node69, node71, node73, node75 };
        com.google.javascript.rhino.Node node77 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray76);
        com.google.javascript.rhino.Node node78 = new com.google.javascript.rhino.Node(100, node64, node77);
        java.lang.String str79 = closureCodingConvention50.getSingletonGetterClassName(node78);
        com.google.javascript.rhino.Node node82 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node84 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node86 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node88 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node90 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray91 = new com.google.javascript.rhino.Node[] { node82, node84, node86, node88, node90 };
        com.google.javascript.rhino.Node node92 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray91);
        com.google.javascript.rhino.Node node94 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node95 = node92.copyInformationFrom(node94);
        java.lang.String str96 = node94.getString();
        node45.addChildAfter(node78, node94);
        node78.setType((int) (short) 0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertNotNull(nodeArray17);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertNull(node22);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(node32);
        org.junit.Assert.assertNotNull(node34);
        org.junit.Assert.assertNotNull(node36);
        org.junit.Assert.assertNotNull(node38);
        org.junit.Assert.assertNotNull(node40);
        org.junit.Assert.assertNotNull(nodeArray41);
        org.junit.Assert.assertNotNull(node44);
        org.junit.Assert.assertNotNull(node45);
        org.junit.Assert.assertTrue("'" + languageMode47 + "' != '" + com.google.javascript.jscomp.parsing.Config.LanguageMode.ECMASCRIPT5 + "'", languageMode47.equals(com.google.javascript.jscomp.parsing.Config.LanguageMode.ECMASCRIPT5));
        org.junit.Assert.assertNull(str49);
        org.junit.Assert.assertNotNull(node54);
        org.junit.Assert.assertNotNull(node56);
        org.junit.Assert.assertNotNull(node58);
        org.junit.Assert.assertNotNull(node60);
        org.junit.Assert.assertNotNull(node62);
        org.junit.Assert.assertNotNull(nodeArray63);
        org.junit.Assert.assertNotNull(node67);
        org.junit.Assert.assertNotNull(node69);
        org.junit.Assert.assertNotNull(node71);
        org.junit.Assert.assertNotNull(node73);
        org.junit.Assert.assertNotNull(node75);
        org.junit.Assert.assertNotNull(nodeArray76);
        org.junit.Assert.assertNull(str79);
        org.junit.Assert.assertNotNull(node82);
        org.junit.Assert.assertNotNull(node84);
        org.junit.Assert.assertNotNull(node86);
        org.junit.Assert.assertNotNull(node88);
        org.junit.Assert.assertNotNull(node90);
        org.junit.Assert.assertNotNull(nodeArray91);
        org.junit.Assert.assertNotNull(node94);
        org.junit.Assert.assertNotNull(node95);
        org.junit.Assert.assertTrue("'" + str96 + "' != '" + "" + "'", str96.equals(""));
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.NodeTraversal.Callback callback1 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal2 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler0, callback1);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile4 = com.google.javascript.jscomp.JSSourceFile.fromFile("Not declared as a constructor");
        java.io.PrintStream printStream5 = null;
        com.google.javascript.jscomp.Compiler compiler6 = new com.google.javascript.jscomp.Compiler(printStream5);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile8 = com.google.javascript.jscomp.JSSourceFile.fromFile("Not declared as a constructor");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile10 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.CompilerInput compilerInput11 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile10);
        com.google.javascript.jscomp.CompilerInput compilerInput14 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput11, "hi!", false);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile16 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        compilerInput11.setSourceFile((com.google.javascript.jscomp.SourceFile) jSSourceFile16);
        java.lang.String str18 = jSSourceFile16.toString();
        com.google.javascript.jscomp.CompilerOptions compilerOptions19 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean20 = compilerOptions19.aliasAllStrings;
        compilerOptions19.setGenerateExports(true);
        com.google.javascript.jscomp.Result result23 = compiler6.compile(jSSourceFile8, jSSourceFile16, compilerOptions19);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile25 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.CompilerInput compilerInput26 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile25);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile28 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.CompilerInput compilerInput29 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile28);
        com.google.javascript.jscomp.CompilerInput compilerInput32 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput29, "hi!", false);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile34 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        compilerInput29.setSourceFile((com.google.javascript.jscomp.SourceFile) jSSourceFile34);
        java.lang.String str36 = jSSourceFile34.toString();
        java.io.PrintStream printStream37 = null;
        com.google.javascript.jscomp.Compiler compiler38 = new com.google.javascript.jscomp.Compiler(printStream37);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile40 = com.google.javascript.jscomp.JSSourceFile.fromFile("Not declared as a constructor");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile42 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.CompilerInput compilerInput43 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile42);
        com.google.javascript.jscomp.CompilerInput compilerInput46 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput43, "hi!", false);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile48 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        compilerInput43.setSourceFile((com.google.javascript.jscomp.SourceFile) jSSourceFile48);
        java.lang.String str50 = jSSourceFile48.toString();
        com.google.javascript.jscomp.CompilerOptions compilerOptions51 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean52 = compilerOptions51.aliasAllStrings;
        compilerOptions51.setGenerateExports(true);
        com.google.javascript.jscomp.Result result55 = compiler38.compile(jSSourceFile40, jSSourceFile48, compilerOptions51);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile57 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.CompilerInput compilerInput58 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile57);
        com.google.javascript.jscomp.Region region60 = jSSourceFile57.getRegion(24);
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray61 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile4, jSSourceFile16, jSSourceFile25, jSSourceFile34, jSSourceFile48, jSSourceFile57 };
        java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList62 = new java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile>();
        boolean boolean63 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList62, jSSourceFileArray61);
        com.google.javascript.jscomp.JSModule[] jSModuleArray64 = new com.google.javascript.jscomp.JSModule[] {};
        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList65 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
        boolean boolean66 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList65, jSModuleArray64);
        com.google.javascript.jscomp.CompilerOptions compilerOptions67 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel68 = compilerOptions67.brokenClosureRequiresLevel;
        com.google.javascript.jscomp.CheckLevel checkLevel69 = com.google.javascript.jscomp.CheckLevel.WARNING;
        compilerOptions67.checkGlobalNamesLevel = checkLevel69;
        compilerOptions67.computeFunctionSideEffects = true;
        boolean boolean73 = compilerOptions67.removeDeadCode;
        com.google.javascript.jscomp.CompilerOptions.TweakProcessing tweakProcessing74 = compilerOptions67.getTweakProcessing();
        com.google.javascript.jscomp.Result result75 = compiler0.compileModules((java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList62, (java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList65, compilerOptions67);
        java.lang.String str78 = compiler0.getSourceLine("com.google.javascript.rhino.EcmaError: TypeError: -1 is not a function, it is java.lang.Byte.", 7);
        com.google.javascript.jscomp.NodeTraversal.Callback callback79 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal80 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler0, callback79);
        org.junit.Assert.assertNotNull(jSSourceFile4);
        org.junit.Assert.assertNotNull(jSSourceFile8);
        org.junit.Assert.assertNotNull(jSSourceFile10);
        org.junit.Assert.assertNotNull(jSSourceFile16);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "" + "'", str18.equals(""));
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(result23);
        org.junit.Assert.assertNotNull(jSSourceFile25);
        org.junit.Assert.assertNotNull(jSSourceFile28);
        org.junit.Assert.assertNotNull(jSSourceFile34);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "" + "'", str36.equals(""));
        org.junit.Assert.assertNotNull(jSSourceFile40);
        org.junit.Assert.assertNotNull(jSSourceFile42);
        org.junit.Assert.assertNotNull(jSSourceFile48);
        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "" + "'", str50.equals(""));
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertNotNull(result55);
        org.junit.Assert.assertNotNull(jSSourceFile57);
        org.junit.Assert.assertNull(region60);
        org.junit.Assert.assertNotNull(jSSourceFileArray61);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + true + "'", boolean63 == true);
        org.junit.Assert.assertNotNull(jSModuleArray64);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertTrue("'" + checkLevel68 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel68.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + checkLevel69 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel69.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
        org.junit.Assert.assertTrue("'" + tweakProcessing74 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TweakProcessing.OFF + "'", tweakProcessing74.equals(com.google.javascript.jscomp.CompilerOptions.TweakProcessing.OFF));
        org.junit.Assert.assertNotNull(result75);
        org.junit.Assert.assertNull(str78);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        com.google.javascript.jscomp.ErrorFormat errorFormat0 = com.google.javascript.jscomp.ErrorFormat.SINGLELINE;
        java.io.PrintStream printStream1 = null;
        com.google.javascript.jscomp.Compiler compiler2 = new com.google.javascript.jscomp.Compiler(printStream1);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile4 = com.google.javascript.jscomp.JSSourceFile.fromFile("Not declared as a constructor");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile6 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.CompilerInput compilerInput7 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile6);
        com.google.javascript.jscomp.CompilerInput compilerInput10 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput7, "hi!", false);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile12 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        compilerInput7.setSourceFile((com.google.javascript.jscomp.SourceFile) jSSourceFile12);
        java.lang.String str14 = jSSourceFile12.toString();
        com.google.javascript.jscomp.CompilerOptions compilerOptions15 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean16 = compilerOptions15.aliasAllStrings;
        compilerOptions15.setGenerateExports(true);
        com.google.javascript.jscomp.Result result19 = compiler2.compile(jSSourceFile4, jSSourceFile12, compilerOptions15);
        com.google.javascript.jscomp.MessageFormatter messageFormatter21 = errorFormat0.toFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler2, false);
        com.google.javascript.jscomp.JSModule jSModule22 = null;
        try {
            java.lang.String[] strArray23 = compiler2.toSourceArray(jSModule22);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: java.lang.NullPointerException");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(errorFormat0);
        org.junit.Assert.assertNotNull(jSSourceFile4);
        org.junit.Assert.assertNotNull(jSSourceFile6);
        org.junit.Assert.assertNotNull(jSSourceFile12);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(result19);
        org.junit.Assert.assertNotNull(messageFormatter21);
    }

//    @Test
//    public void test307() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test307");
//        com.google.javascript.rhino.Context context0 = com.google.javascript.rhino.Context.enter();
//        boolean boolean1 = context0.isGeneratingSource();
//        java.lang.Object obj2 = null;
//        context0.removeThreadLocal(obj2);
//        com.google.javascript.rhino.ScriptRuntime.storeUint32Result(context0, (long) 2);
//        java.beans.PropertyChangeListener propertyChangeListener6 = null;
//        try {
//            context0.removePropertyChangeListener(propertyChangeListener6);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(context0);
//        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
//    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.checkDuplicateMessages = false;
        boolean boolean3 = compilerOptions0.inlineAnonymousFunctionExpressions;
        compilerOptions0.recordFunctionInformation = true;
        boolean boolean6 = compilerOptions0.checkCaja;
        java.util.Set<java.lang.String> strSet7 = compilerOptions0.stripNamePrefixes;
        compilerOptions0.skipAllCompilerPasses();
        boolean boolean9 = compilerOptions0.inlineConstantVars;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(strSet7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.NodeTraversal.Callback callback1 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal2 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler0, callback1);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile4 = com.google.javascript.jscomp.JSSourceFile.fromFile("Not declared as a constructor");
        java.io.PrintStream printStream5 = null;
        com.google.javascript.jscomp.Compiler compiler6 = new com.google.javascript.jscomp.Compiler(printStream5);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile8 = com.google.javascript.jscomp.JSSourceFile.fromFile("Not declared as a constructor");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile10 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.CompilerInput compilerInput11 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile10);
        com.google.javascript.jscomp.CompilerInput compilerInput14 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput11, "hi!", false);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile16 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        compilerInput11.setSourceFile((com.google.javascript.jscomp.SourceFile) jSSourceFile16);
        java.lang.String str18 = jSSourceFile16.toString();
        com.google.javascript.jscomp.CompilerOptions compilerOptions19 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean20 = compilerOptions19.aliasAllStrings;
        compilerOptions19.setGenerateExports(true);
        com.google.javascript.jscomp.Result result23 = compiler6.compile(jSSourceFile8, jSSourceFile16, compilerOptions19);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile25 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.CompilerInput compilerInput26 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile25);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile28 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.CompilerInput compilerInput29 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile28);
        com.google.javascript.jscomp.CompilerInput compilerInput32 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput29, "hi!", false);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile34 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        compilerInput29.setSourceFile((com.google.javascript.jscomp.SourceFile) jSSourceFile34);
        java.lang.String str36 = jSSourceFile34.toString();
        java.io.PrintStream printStream37 = null;
        com.google.javascript.jscomp.Compiler compiler38 = new com.google.javascript.jscomp.Compiler(printStream37);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile40 = com.google.javascript.jscomp.JSSourceFile.fromFile("Not declared as a constructor");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile42 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.CompilerInput compilerInput43 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile42);
        com.google.javascript.jscomp.CompilerInput compilerInput46 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput43, "hi!", false);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile48 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        compilerInput43.setSourceFile((com.google.javascript.jscomp.SourceFile) jSSourceFile48);
        java.lang.String str50 = jSSourceFile48.toString();
        com.google.javascript.jscomp.CompilerOptions compilerOptions51 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean52 = compilerOptions51.aliasAllStrings;
        compilerOptions51.setGenerateExports(true);
        com.google.javascript.jscomp.Result result55 = compiler38.compile(jSSourceFile40, jSSourceFile48, compilerOptions51);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile57 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.CompilerInput compilerInput58 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile57);
        com.google.javascript.jscomp.Region region60 = jSSourceFile57.getRegion(24);
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray61 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile4, jSSourceFile16, jSSourceFile25, jSSourceFile34, jSSourceFile48, jSSourceFile57 };
        java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList62 = new java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile>();
        boolean boolean63 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList62, jSSourceFileArray61);
        com.google.javascript.jscomp.JSModule[] jSModuleArray64 = new com.google.javascript.jscomp.JSModule[] {};
        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList65 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
        boolean boolean66 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList65, jSModuleArray64);
        com.google.javascript.jscomp.CompilerOptions compilerOptions67 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel68 = compilerOptions67.brokenClosureRequiresLevel;
        com.google.javascript.jscomp.CheckLevel checkLevel69 = com.google.javascript.jscomp.CheckLevel.WARNING;
        compilerOptions67.checkGlobalNamesLevel = checkLevel69;
        compilerOptions67.computeFunctionSideEffects = true;
        boolean boolean73 = compilerOptions67.removeDeadCode;
        com.google.javascript.jscomp.CompilerOptions.TweakProcessing tweakProcessing74 = compilerOptions67.getTweakProcessing();
        com.google.javascript.jscomp.Result result75 = compiler0.compileModules((java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList62, (java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList65, compilerOptions67);
        com.google.javascript.jscomp.CodingConvention codingConvention76 = compiler0.getCodingConvention();
        try {
            compiler0.processDefines();
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: INTERNAL COMPILER ERROR.\nPlease report this problem.\nnull");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile4);
        org.junit.Assert.assertNotNull(jSSourceFile8);
        org.junit.Assert.assertNotNull(jSSourceFile10);
        org.junit.Assert.assertNotNull(jSSourceFile16);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "" + "'", str18.equals(""));
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(result23);
        org.junit.Assert.assertNotNull(jSSourceFile25);
        org.junit.Assert.assertNotNull(jSSourceFile28);
        org.junit.Assert.assertNotNull(jSSourceFile34);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "" + "'", str36.equals(""));
        org.junit.Assert.assertNotNull(jSSourceFile40);
        org.junit.Assert.assertNotNull(jSSourceFile42);
        org.junit.Assert.assertNotNull(jSSourceFile48);
        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "" + "'", str50.equals(""));
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertNotNull(result55);
        org.junit.Assert.assertNotNull(jSSourceFile57);
        org.junit.Assert.assertNull(region60);
        org.junit.Assert.assertNotNull(jSSourceFileArray61);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + true + "'", boolean63 == true);
        org.junit.Assert.assertNotNull(jSModuleArray64);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertTrue("'" + checkLevel68 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel68.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + checkLevel69 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel69.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
        org.junit.Assert.assertTrue("'" + tweakProcessing74 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TweakProcessing.OFF + "'", tweakProcessing74.equals(com.google.javascript.jscomp.CompilerOptions.TweakProcessing.OFF));
        org.junit.Assert.assertNotNull(result75);
        org.junit.Assert.assertNotNull(codingConvention76);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.UNDEFINED_VARIABLES;
        com.google.javascript.jscomp.DiagnosticGroups.CHECK_TYPES = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticGroups.ACCESS_CONTROLS = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticGroups.UNDEFINED_VARIABLES = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticGroups.INTERNET_EXPLORER_CHECKS = diagnosticGroup0;
        org.junit.Assert.assertNull(diagnosticGroup0);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        java.io.InputStream inputStream1 = null;
        try {
            com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromInputStream("Unknown class name", inputStream1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray12 = new com.google.javascript.rhino.Node[] { node3, node5, node7, node9, node11 };
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray12);
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node16 = node13.copyInformationFrom(node15);
        com.google.javascript.rhino.Node node17 = node13.getParent();
        com.google.javascript.rhino.Node node18 = new com.google.javascript.rhino.Node((int) (short) -1, node13);
        com.google.javascript.rhino.Node node19 = null;
        boolean boolean20 = node18.hasChild(node19);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertNotNull(nodeArray12);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertNull(node17);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        com.google.javascript.jscomp.AnonymousFunctionNamingPolicy anonymousFunctionNamingPolicy0 = com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF;
        char[] charArray1 = anonymousFunctionNamingPolicy0.getReservedCharacters();
        org.junit.Assert.assertTrue("'" + anonymousFunctionNamingPolicy0 + "' != '" + com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF + "'", anonymousFunctionNamingPolicy0.equals(com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF));
        org.junit.Assert.assertNull(charArray1);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile3 = com.google.javascript.jscomp.JSSourceFile.fromFile("Not declared as a constructor");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile5 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.CompilerInput compilerInput6 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile5);
        com.google.javascript.jscomp.CompilerInput compilerInput9 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput6, "hi!", false);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile11 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        compilerInput6.setSourceFile((com.google.javascript.jscomp.SourceFile) jSSourceFile11);
        java.lang.String str13 = jSSourceFile11.toString();
        com.google.javascript.jscomp.CompilerOptions compilerOptions14 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean15 = compilerOptions14.aliasAllStrings;
        compilerOptions14.setGenerateExports(true);
        com.google.javascript.jscomp.Result result18 = compiler1.compile(jSSourceFile3, jSSourceFile11, compilerOptions14);
        com.google.javascript.jscomp.CompilerInput compilerInput19 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile11);
        com.google.javascript.jscomp.CompilerInput compilerInput20 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput19);
        com.google.javascript.jscomp.JSModule jSModule21 = null;
        compilerInput19.setModule(jSModule21);
        com.google.javascript.jscomp.SourceAst sourceAst23 = compilerInput19.getSourceAst();
        com.google.javascript.jscomp.Region region25 = compilerInput19.getRegion((int) '4');
        org.junit.Assert.assertNotNull(jSSourceFile3);
        org.junit.Assert.assertNotNull(jSSourceFile5);
        org.junit.Assert.assertNotNull(jSSourceFile11);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(result18);
        org.junit.Assert.assertNotNull(sourceAst23);
        org.junit.Assert.assertNull(region25);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile3 = com.google.javascript.jscomp.JSSourceFile.fromFile("Not declared as a constructor");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile5 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.CompilerInput compilerInput6 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile5);
        com.google.javascript.jscomp.CompilerInput compilerInput9 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput6, "hi!", false);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile11 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        compilerInput6.setSourceFile((com.google.javascript.jscomp.SourceFile) jSSourceFile11);
        java.lang.String str13 = jSSourceFile11.toString();
        com.google.javascript.jscomp.CompilerOptions compilerOptions14 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean15 = compilerOptions14.aliasAllStrings;
        compilerOptions14.setGenerateExports(true);
        com.google.javascript.jscomp.Result result18 = compiler1.compile(jSSourceFile3, jSSourceFile11, compilerOptions14);
        com.google.javascript.jscomp.CompilerInput compilerInput19 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile11);
        com.google.javascript.jscomp.CompilerInput compilerInput20 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput19);
        com.google.javascript.jscomp.JSModule jSModule21 = null;
        compilerInput19.setModule(jSModule21);
        com.google.javascript.jscomp.SourceAst sourceAst23 = compilerInput19.getSourceAst();
        try {
            java.util.Collection<java.lang.String> strCollection24 = compilerInput19.getProvides();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Expected setErrorManager to be called first");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile3);
        org.junit.Assert.assertNotNull(jSSourceFile5);
        org.junit.Assert.assertNotNull(jSSourceFile11);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(result18);
        org.junit.Assert.assertNotNull(sourceAst23);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        com.google.javascript.rhino.EcmaError ecmaError2 = com.google.javascript.rhino.ScriptRuntime.constructError("error reporter", "com.google.javascript.rhino.EcmaError: TypeError: -1 is not a function, it is java.lang.Byte.");
        org.junit.Assert.assertNotNull(ecmaError2);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        com.google.javascript.jscomp.CompilerOptions compilerOptions1 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel2 = compilerOptions1.brokenClosureRequiresLevel;
        boolean boolean3 = compilerOptions1.collapseAnonymousFunctions;
        compilerOptions1.reserveRawExports = true;
        try {
            java.lang.String str6 = com.google.javascript.rhino.ScriptRuntime.getMessage1("1", (java.lang.Object) compilerOptions1);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property 1");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertTrue("'" + checkLevel2 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel2.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        int int0 = com.google.javascript.rhino.jstype.JSType.ENUMDECL;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray13 = new com.google.javascript.rhino.Node[] { node4, node6, node8, node10, node12 };
        com.google.javascript.rhino.Node node14 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray13);
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node21 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray26 = new com.google.javascript.rhino.Node[] { node17, node19, node21, node23, node25 };
        com.google.javascript.rhino.Node node27 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray26);
        com.google.javascript.rhino.Node node28 = new com.google.javascript.rhino.Node(100, node14, node27);
        boolean boolean29 = closureCodingConvention0.isVarArgsParameter(node28);
        java.lang.String str30 = closureCodingConvention0.getGlobalObject();
        com.google.javascript.rhino.Node node35 = com.google.javascript.rhino.Node.newNumber(100.0d, 4095, 9);
        java.util.Set<java.lang.String> strSet36 = node35.getDirectives();
        com.google.javascript.rhino.Node node39 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node41 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node43 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node45 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node47 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray48 = new com.google.javascript.rhino.Node[] { node39, node41, node43, node45, node47 };
        com.google.javascript.rhino.Node node49 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray48);
        com.google.javascript.rhino.Node node51 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node52 = node49.copyInformationFrom(node51);
        com.google.javascript.rhino.Node node55 = new com.google.javascript.rhino.Node(28, node35, node49, (-2), (int) (byte) -1);
        boolean boolean56 = node55.isNoSideEffectsCall();
        com.google.javascript.rhino.Node node60 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node62 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node64 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node66 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node68 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray69 = new com.google.javascript.rhino.Node[] { node60, node62, node64, node66, node68 };
        com.google.javascript.rhino.Node node70 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray69);
        com.google.javascript.rhino.Node node72 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node73 = node70.copyInformationFrom(node72);
        com.google.javascript.rhino.Node node74 = node70.getParent();
        com.google.javascript.rhino.Node node75 = new com.google.javascript.rhino.Node((int) (short) -1, node70);
        boolean boolean76 = node70.wasEmptyNode();
        com.google.javascript.rhino.Node node78 = node70.getAncestor(0);
        java.lang.String str79 = closureCodingConvention0.extractClassNameIfProvide(node55, node70);
        com.google.javascript.rhino.jstype.JSType jSType80 = node55.getJSType();
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(nodeArray13);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNotNull(nodeArray26);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "goog.global" + "'", str30.equals("goog.global"));
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertNull(strSet36);
        org.junit.Assert.assertNotNull(node39);
        org.junit.Assert.assertNotNull(node41);
        org.junit.Assert.assertNotNull(node43);
        org.junit.Assert.assertNotNull(node45);
        org.junit.Assert.assertNotNull(node47);
        org.junit.Assert.assertNotNull(nodeArray48);
        org.junit.Assert.assertNotNull(node51);
        org.junit.Assert.assertNotNull(node52);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertNotNull(node60);
        org.junit.Assert.assertNotNull(node62);
        org.junit.Assert.assertNotNull(node64);
        org.junit.Assert.assertNotNull(node66);
        org.junit.Assert.assertNotNull(node68);
        org.junit.Assert.assertNotNull(nodeArray69);
        org.junit.Assert.assertNotNull(node72);
        org.junit.Assert.assertNotNull(node73);
        org.junit.Assert.assertNull(node74);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
        org.junit.Assert.assertNotNull(node78);
        org.junit.Assert.assertNull(str79);
        org.junit.Assert.assertNull(jSType80);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile1 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.CompilerInput compilerInput2 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile1);
        com.google.javascript.jscomp.CompilerInput compilerInput5 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput2, "hi!", false);
        com.google.javascript.jscomp.Compiler compiler6 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile8 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.CompilerInput compilerInput9 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile8);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile11 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.CompilerInput compilerInput12 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile11);
        com.google.javascript.jscomp.CompilerInput compilerInput15 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput12, "hi!", false);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile17 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        compilerInput12.setSourceFile((com.google.javascript.jscomp.SourceFile) jSSourceFile17);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile20 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray21 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile8, jSSourceFile17, jSSourceFile20 };
        java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList22 = new java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile>();
        boolean boolean23 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList22, jSSourceFileArray21);
        com.google.javascript.jscomp.JSModule[] jSModuleArray24 = new com.google.javascript.jscomp.JSModule[] {};
        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList25 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
        boolean boolean26 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList25, jSModuleArray24);
        com.google.javascript.jscomp.CompilerOptions compilerOptions27 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions27.checkDuplicateMessages = false;
        boolean boolean30 = compilerOptions27.inlineAnonymousFunctionExpressions;
        compilerOptions27.crossModuleMethodMotion = true;
        com.google.javascript.jscomp.Result result33 = compiler6.compileModules((java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList22, (java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList25, compilerOptions27);
        compilerInput2.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler6);
        try {
            com.google.javascript.jscomp.CompilerInput compilerInput36 = compiler6.newExternInput("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Conflicting externs name: ");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile1);
        org.junit.Assert.assertNotNull(jSSourceFile8);
        org.junit.Assert.assertNotNull(jSSourceFile11);
        org.junit.Assert.assertNotNull(jSSourceFile17);
        org.junit.Assert.assertNotNull(jSSourceFile20);
        org.junit.Assert.assertNotNull(jSSourceFileArray21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(jSModuleArray24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(result33);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.brokenClosureRequiresLevel;
        com.google.javascript.jscomp.CheckLevel checkLevel2 = com.google.javascript.jscomp.CheckLevel.WARNING;
        compilerOptions0.checkGlobalNamesLevel = checkLevel2;
        compilerOptions0.computeFunctionSideEffects = true;
        boolean boolean6 = compilerOptions0.removeDeadCode;
        compilerOptions0.inlineVariables = true;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy9 = com.google.javascript.jscomp.VariableRenamingPolicy.OFF;
        compilerOptions0.variableRenaming = variableRenamingPolicy9;
        com.google.javascript.jscomp.CheckLevel checkLevel11 = compilerOptions0.checkShadowVars;
        java.lang.String str12 = compilerOptions0.inputDelimiter;
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + checkLevel2 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel2.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy9 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.OFF + "'", variableRenamingPolicy9.equals(com.google.javascript.jscomp.VariableRenamingPolicy.OFF));
        org.junit.Assert.assertTrue("'" + checkLevel11 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel11.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "// Input %num%" + "'", str12.equals("// Input %num%"));
    }

//    @Test
//    public void test322() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test322");
//        com.google.javascript.rhino.Context context0 = com.google.javascript.rhino.Context.enter();
//        boolean boolean1 = context0.isGeneratingSource();
//        java.lang.Object obj2 = null;
//        context0.removeThreadLocal(obj2);
//        boolean boolean4 = context0.isGeneratingDebug();
//        boolean boolean5 = context0.hasCompileFunctionsWithDynamicScope();
//        com.google.javascript.rhino.ErrorReporter errorReporter6 = null;
//        try {
//            com.google.javascript.rhino.ErrorReporter errorReporter7 = context0.setErrorReporter(errorReporter6);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(context0);
//        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile3 = com.google.javascript.jscomp.JSSourceFile.fromFile("Not declared as a constructor");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile5 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.CompilerInput compilerInput6 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile5);
        com.google.javascript.jscomp.CompilerInput compilerInput9 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput6, "hi!", false);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile11 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        compilerInput6.setSourceFile((com.google.javascript.jscomp.SourceFile) jSSourceFile11);
        java.lang.String str13 = jSSourceFile11.toString();
        com.google.javascript.jscomp.CompilerOptions compilerOptions14 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean15 = compilerOptions14.aliasAllStrings;
        compilerOptions14.setGenerateExports(true);
        com.google.javascript.jscomp.Result result18 = compiler1.compile(jSSourceFile3, jSSourceFile11, compilerOptions14);
        com.google.javascript.jscomp.CompilerInput compilerInput19 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile11);
        com.google.javascript.jscomp.CompilerInput compilerInput20 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput19);
        com.google.javascript.jscomp.JSModule jSModule21 = null;
        compilerInput19.setModule(jSModule21);
        com.google.javascript.jscomp.SourceAst sourceAst23 = compilerInput19.getSourceAst();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile25 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.CompilerInput compilerInput26 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile25);
        com.google.javascript.jscomp.CompilerInput compilerInput29 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput26, "hi!", false);
        com.google.javascript.jscomp.Compiler compiler30 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile32 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.CompilerInput compilerInput33 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile32);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile35 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.CompilerInput compilerInput36 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile35);
        com.google.javascript.jscomp.CompilerInput compilerInput39 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput36, "hi!", false);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile41 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        compilerInput36.setSourceFile((com.google.javascript.jscomp.SourceFile) jSSourceFile41);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile44 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray45 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile32, jSSourceFile41, jSSourceFile44 };
        java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList46 = new java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile>();
        boolean boolean47 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList46, jSSourceFileArray45);
        com.google.javascript.jscomp.JSModule[] jSModuleArray48 = new com.google.javascript.jscomp.JSModule[] {};
        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList49 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
        boolean boolean50 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList49, jSModuleArray48);
        com.google.javascript.jscomp.CompilerOptions compilerOptions51 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions51.checkDuplicateMessages = false;
        boolean boolean54 = compilerOptions51.inlineAnonymousFunctionExpressions;
        compilerOptions51.crossModuleMethodMotion = true;
        com.google.javascript.jscomp.Result result57 = compiler30.compileModules((java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList46, (java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList49, compilerOptions51);
        compilerInput26.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler30);
        com.google.javascript.jscomp.Scope scope59 = compiler30.getTopScope();
        com.google.javascript.rhino.Node node60 = compilerInput19.getAstRoot((com.google.javascript.jscomp.AbstractCompiler) compiler30);
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray61 = new com.google.javascript.jscomp.JSSourceFile[] {};
        com.google.javascript.jscomp.JSModule jSModule62 = null;
        com.google.javascript.jscomp.JSModule[] jSModuleArray63 = new com.google.javascript.jscomp.JSModule[] { jSModule62 };
        java.io.PrintStream printStream64 = null;
        com.google.javascript.jscomp.Compiler compiler65 = new com.google.javascript.jscomp.Compiler(printStream64);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile67 = com.google.javascript.jscomp.JSSourceFile.fromFile("Not declared as a constructor");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile69 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.CompilerInput compilerInput70 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile69);
        com.google.javascript.jscomp.CompilerInput compilerInput73 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput70, "hi!", false);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile75 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        compilerInput70.setSourceFile((com.google.javascript.jscomp.SourceFile) jSSourceFile75);
        java.lang.String str77 = jSSourceFile75.toString();
        com.google.javascript.jscomp.CompilerOptions compilerOptions78 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean79 = compilerOptions78.aliasAllStrings;
        compilerOptions78.setGenerateExports(true);
        com.google.javascript.jscomp.Result result82 = compiler65.compile(jSSourceFile67, jSSourceFile75, compilerOptions78);
        compilerOptions78.syntheticBlockEndMarker = "Not declared as a type name";
        compilerOptions78.generatePseudoNames = true;
        try {
            compiler30.init(jSSourceFileArray61, jSModuleArray63, compilerOptions78);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile3);
        org.junit.Assert.assertNotNull(jSSourceFile5);
        org.junit.Assert.assertNotNull(jSSourceFile11);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(result18);
        org.junit.Assert.assertNotNull(sourceAst23);
        org.junit.Assert.assertNotNull(jSSourceFile25);
        org.junit.Assert.assertNotNull(jSSourceFile32);
        org.junit.Assert.assertNotNull(jSSourceFile35);
        org.junit.Assert.assertNotNull(jSSourceFile41);
        org.junit.Assert.assertNotNull(jSSourceFile44);
        org.junit.Assert.assertNotNull(jSSourceFileArray45);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
        org.junit.Assert.assertNotNull(jSModuleArray48);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNotNull(result57);
        org.junit.Assert.assertNull(scope59);
        org.junit.Assert.assertNull(node60);
        org.junit.Assert.assertNotNull(jSSourceFileArray61);
        org.junit.Assert.assertNotNull(jSModuleArray63);
        org.junit.Assert.assertNotNull(jSSourceFile67);
        org.junit.Assert.assertNotNull(jSSourceFile69);
        org.junit.Assert.assertNotNull(jSSourceFile75);
        org.junit.Assert.assertTrue("'" + str77 + "' != '" + "" + "'", str77.equals(""));
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
        org.junit.Assert.assertNotNull(result82);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.checkDuplicateMessages = false;
        boolean boolean3 = compilerOptions0.inlineAnonymousFunctionExpressions;
        java.lang.String str4 = compilerOptions0.checkMissingGetCssNameBlacklist;
        compilerOptions0.inlineAnonymousFunctionExpressions = false;
        com.google.javascript.jscomp.CheckLevel checkLevel7 = null;
        compilerOptions0.checkGlobalThisLevel = checkLevel7;
        compilerOptions0.aliasExternals = false;
        compilerOptions0.generatePseudoNames = true;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.brokenClosureRequiresLevel;
        com.google.javascript.jscomp.CheckLevel checkLevel2 = com.google.javascript.jscomp.CheckLevel.WARNING;
        compilerOptions0.checkGlobalNamesLevel = checkLevel2;
        compilerOptions0.computeFunctionSideEffects = true;
        boolean boolean6 = compilerOptions0.removeDeadCode;
        com.google.javascript.jscomp.CompilerOptions.TweakProcessing tweakProcessing7 = compilerOptions0.getTweakProcessing();
        boolean boolean8 = compilerOptions0.checkControlStructures;
        java.lang.String str9 = compilerOptions0.sourceMapOutputPath;
        boolean boolean10 = compilerOptions0.convertToDottedProperties;
        compilerOptions0.debugFunctionSideEffectsPath = "// Input %num%";
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + checkLevel2 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel2.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + tweakProcessing7 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TweakProcessing.OFF + "'", tweakProcessing7.equals(com.google.javascript.jscomp.CompilerOptions.TweakProcessing.OFF));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        com.google.javascript.jscomp.AbstractCompiler abstractCompiler0 = null;
        com.google.javascript.jscomp.NodeTraversal.Callback callback1 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal2 = new com.google.javascript.jscomp.NodeTraversal(abstractCompiler0, callback1);
        com.google.javascript.rhino.Node node3 = nodeTraversal2.getEnclosingFunction();
        org.junit.Assert.assertNull(node3);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray0 = new com.google.javascript.jscomp.WarningsGuard[] {};
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard1 = new com.google.javascript.jscomp.ComposeWarningsGuard(warningsGuardArray0);
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.Node.newString((int) (short) 0, "hi!", 100, (-2));
        com.google.javascript.jscomp.DiagnosticType diagnosticType8 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray9 = com.google.javascript.rhino.ScriptRuntime.emptyStrings;
        com.google.javascript.jscomp.JSError jSError10 = com.google.javascript.jscomp.JSError.make("", node7, diagnosticType8, strArray9);
        java.lang.String str11 = jSError10.sourceName;
        com.google.javascript.jscomp.CheckLevel checkLevel12 = composeWarningsGuard1.level(jSError10);
        org.junit.Assert.assertNotNull(warningsGuardArray0);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertNotNull(diagnosticType8);
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertNotNull(jSError10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertNull(checkLevel12);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        try {
            com.google.javascript.rhino.Context.reportWarning("JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of optimization iterations: {0}", "TypeError", 13, "1", 39);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: No Context associated with current Thread");
        } catch (java.lang.RuntimeException e) {
        }
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.brokenClosureRequiresLevel;
        com.google.javascript.jscomp.CheckLevel checkLevel2 = com.google.javascript.jscomp.CheckLevel.WARNING;
        compilerOptions0.checkGlobalNamesLevel = checkLevel2;
        compilerOptions0.renamePrefix = "hi!";
        compilerOptions0.instrumentForCoverageOnly = true;
        compilerOptions0.setDefineToDoubleLiteral("goog.global", (double) 10L);
        compilerOptions0.recordFunctionInformation = true;
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + checkLevel2 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel2.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.brokenClosureRequiresLevel;
        compilerOptions0.setManageClosureDependencies(true);
        java.lang.String[] strArray11 = new java.lang.String[] { "goog.exportProperty", "Not declared as a type name", "error reporter", "DiagnosticGroup<undefinedVars>", "goog.exportProperty", "Not declared as a constructor" };
        java.util.ArrayList<java.lang.String> strList12 = new java.util.ArrayList<java.lang.String>();
        boolean boolean13 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strList12, strArray11);
        compilerOptions0.setReplaceStringsConfiguration("goog.exportProperty", (java.util.List<java.lang.String>) strList12);
        compilerOptions0.decomposeExpressions = false;
        com.google.javascript.jscomp.CheckLevel checkLevel17 = compilerOptions0.checkMissingGetCssNameLevel;
        compilerOptions0.groupVariableDeclarations = true;
        boolean boolean20 = compilerOptions0.removeUnusedLocalVars;
        compilerOptions0.extractPrototypeMemberDeclarations = false;
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(strArray11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + checkLevel17 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel17.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.CHECK_TYPES;
        com.google.javascript.jscomp.DiagnosticGroups.ACCESS_CONTROLS = diagnosticGroup0;
        org.junit.Assert.assertNull(diagnosticGroup0);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile1 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.CompilerInput compilerInput2 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile1);
        com.google.javascript.jscomp.CompilerInput compilerInput5 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput2, "hi!", false);
        com.google.javascript.jscomp.Compiler compiler6 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile8 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.CompilerInput compilerInput9 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile8);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile11 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.CompilerInput compilerInput12 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile11);
        com.google.javascript.jscomp.CompilerInput compilerInput15 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput12, "hi!", false);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile17 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        compilerInput12.setSourceFile((com.google.javascript.jscomp.SourceFile) jSSourceFile17);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile20 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray21 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile8, jSSourceFile17, jSSourceFile20 };
        java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList22 = new java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile>();
        boolean boolean23 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList22, jSSourceFileArray21);
        com.google.javascript.jscomp.JSModule[] jSModuleArray24 = new com.google.javascript.jscomp.JSModule[] {};
        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList25 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
        boolean boolean26 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList25, jSModuleArray24);
        com.google.javascript.jscomp.CompilerOptions compilerOptions27 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions27.checkDuplicateMessages = false;
        boolean boolean30 = compilerOptions27.inlineAnonymousFunctionExpressions;
        compilerOptions27.crossModuleMethodMotion = true;
        com.google.javascript.jscomp.Result result33 = compiler6.compileModules((java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList22, (java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList25, compilerOptions27);
        compilerInput2.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler6);
        com.google.javascript.jscomp.JSError[] jSErrorArray35 = compiler6.getMessages();
        org.junit.Assert.assertNotNull(jSSourceFile1);
        org.junit.Assert.assertNotNull(jSSourceFile8);
        org.junit.Assert.assertNotNull(jSSourceFile11);
        org.junit.Assert.assertNotNull(jSSourceFile17);
        org.junit.Assert.assertNotNull(jSSourceFile20);
        org.junit.Assert.assertNotNull(jSSourceFileArray21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(jSModuleArray24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(result33);
        org.junit.Assert.assertNotNull(jSErrorArray35);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        java.nio.charset.Charset charset1 = null;
        com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromFile("hi!", charset1);
        org.junit.Assert.assertNotNull(sourceFile2);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        com.google.javascript.jscomp.SourceFile sourceFile4 = com.google.javascript.jscomp.SourceFile.fromCode("goog.exportProperty", "language version", "goog.exportProperty");
        java.io.Reader reader5 = sourceFile4.getCodeReader();
        com.google.javascript.jscomp.SourceFile sourceFile6 = com.google.javascript.jscomp.SourceFile.fromReader("", reader5);
        org.junit.Assert.assertNotNull(sourceFile4);
        org.junit.Assert.assertNotNull(reader5);
        org.junit.Assert.assertNotNull(sourceFile6);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray12 = new com.google.javascript.rhino.Node[] { node3, node5, node7, node9, node11 };
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray12);
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node16 = node13.copyInformationFrom(node15);
        com.google.javascript.rhino.Node node17 = node13.getParent();
        com.google.javascript.rhino.Node node18 = new com.google.javascript.rhino.Node((int) (short) -1, node13);
        boolean boolean19 = node13.wasEmptyNode();
        com.google.javascript.rhino.Node node21 = node13.getAncestor(0);
        com.google.javascript.rhino.Node node22 = node21.detachFromParent();
        com.google.javascript.rhino.Node node23 = node22.getFirstChild();
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertNotNull(nodeArray12);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertNull(node17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertNotNull(node23);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        java.lang.String str1 = com.google.javascript.rhino.ScriptRuntime.escapeString("error reporter");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "error reporter" + "'", str1.equals("error reporter"));
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray12 = new com.google.javascript.rhino.Node[] { node3, node5, node7, node9, node11 };
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray12);
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node16 = node13.copyInformationFrom(node15);
        com.google.javascript.rhino.Node node17 = node13.getParent();
        com.google.javascript.rhino.Node node18 = new com.google.javascript.rhino.Node((int) (short) -1, node13);
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newString((int) (short) 0, "hi!", 100, (-2));
        boolean boolean24 = node13.isEquivalentTo(node23);
        int int26 = node23.getIntProp(28);
        node23.addSuppression("");
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertNotNull(nodeArray12);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertNull(node17);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile1 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.CompilerInput compilerInput2 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile1);
        com.google.javascript.jscomp.CompilerInput compilerInput5 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput2, "hi!", false);
        com.google.javascript.jscomp.Compiler compiler6 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile8 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.CompilerInput compilerInput9 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile8);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile11 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.CompilerInput compilerInput12 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile11);
        com.google.javascript.jscomp.CompilerInput compilerInput15 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput12, "hi!", false);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile17 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        compilerInput12.setSourceFile((com.google.javascript.jscomp.SourceFile) jSSourceFile17);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile20 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray21 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile8, jSSourceFile17, jSSourceFile20 };
        java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList22 = new java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile>();
        boolean boolean23 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList22, jSSourceFileArray21);
        com.google.javascript.jscomp.JSModule[] jSModuleArray24 = new com.google.javascript.jscomp.JSModule[] {};
        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList25 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
        boolean boolean26 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList25, jSModuleArray24);
        com.google.javascript.jscomp.CompilerOptions compilerOptions27 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions27.checkDuplicateMessages = false;
        boolean boolean30 = compilerOptions27.inlineAnonymousFunctionExpressions;
        compilerOptions27.crossModuleMethodMotion = true;
        com.google.javascript.jscomp.Result result33 = compiler6.compileModules((java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList22, (java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList25, compilerOptions27);
        compilerInput2.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler6);
        com.google.javascript.jscomp.Scope scope35 = compiler6.getTopScope();
        try {
            compiler6.normalize();
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: INTERNAL COMPILER ERROR.\nPlease report this problem.\nnull");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile1);
        org.junit.Assert.assertNotNull(jSSourceFile8);
        org.junit.Assert.assertNotNull(jSSourceFile11);
        org.junit.Assert.assertNotNull(jSSourceFile17);
        org.junit.Assert.assertNotNull(jSSourceFile20);
        org.junit.Assert.assertNotNull(jSSourceFileArray21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(jSModuleArray24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(result33);
        org.junit.Assert.assertNull(scope35);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile1 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.CompilerInput compilerInput2 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile1);
        com.google.javascript.jscomp.CompilerInput compilerInput5 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput2, "hi!", false);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile7 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        compilerInput2.setSourceFile((com.google.javascript.jscomp.SourceFile) jSSourceFile7);
        com.google.javascript.jscomp.CompilerInput compilerInput11 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput2, "JSC_OPTIMIZE_LOOP_ERROR", true);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile13 = com.google.javascript.jscomp.JSSourceFile.fromFile("Not declared as a constructor");
        jSSourceFile13.clearCachedSource();
        try {
            compilerInput2.setSourceFile((com.google.javascript.jscomp.SourceFile) jSSourceFile13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile1);
        org.junit.Assert.assertNotNull(jSSourceFile7);
        org.junit.Assert.assertNotNull(jSSourceFile13);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray12 = new com.google.javascript.rhino.Node[] { node3, node5, node7, node9, node11 };
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray12);
        try {
            com.google.javascript.rhino.Node node14 = new com.google.javascript.rhino.Node(15, nodeArray12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: duplicate child");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertNotNull(nodeArray12);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.brokenClosureRequiresLevel;
        com.google.javascript.jscomp.CheckLevel checkLevel2 = com.google.javascript.jscomp.CheckLevel.WARNING;
        compilerOptions0.checkGlobalNamesLevel = checkLevel2;
        compilerOptions0.computeFunctionSideEffects = true;
        boolean boolean6 = compilerOptions0.removeDeadCode;
        com.google.javascript.jscomp.SourceMap.DetailLevel detailLevel7 = null;
        compilerOptions0.sourceMapDetailLevel = detailLevel7;
        boolean boolean9 = compilerOptions0.closurePass;
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + checkLevel2 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel2.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray13 = new com.google.javascript.rhino.Node[] { node4, node6, node8, node10, node12 };
        com.google.javascript.rhino.Node node14 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray13);
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node21 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray26 = new com.google.javascript.rhino.Node[] { node17, node19, node21, node23, node25 };
        com.google.javascript.rhino.Node node27 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray26);
        com.google.javascript.rhino.Node node28 = new com.google.javascript.rhino.Node(100, node14, node27);
        boolean boolean29 = closureCodingConvention0.isVarArgsParameter(node28);
        java.lang.String str30 = closureCodingConvention0.getExportPropertyFunction();
        boolean boolean33 = closureCodingConvention0.isExported("goog.exportProperty", false);
        com.google.javascript.rhino.Node node37 = com.google.javascript.rhino.Node.newNumber(100.0d, 4095, 9);
        java.util.Set<java.lang.String> strSet38 = node37.getDirectives();
        boolean boolean39 = closureCodingConvention0.isVarArgsParameter(node37);
        com.google.javascript.rhino.Node node42 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node44 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node46 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node48 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node50 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray51 = new com.google.javascript.rhino.Node[] { node42, node44, node46, node48, node50 };
        com.google.javascript.rhino.Node node52 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray51);
        com.google.javascript.rhino.Node node53 = node52.getNext();
        com.google.javascript.rhino.Node node57 = com.google.javascript.rhino.Node.newNumber(100.0d, 4095, 9);
        java.lang.String str58 = closureCodingConvention0.extractClassNameIfRequire(node52, node57);
        try {
            node57.setSideEffectFlags(120);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: setIsNoSideEffectsCall only supports CALL and NEW nodes, got NUMBER");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(nodeArray13);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNotNull(nodeArray26);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "goog.exportProperty" + "'", str30.equals("goog.exportProperty"));
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(node37);
        org.junit.Assert.assertNull(strSet38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(node42);
        org.junit.Assert.assertNotNull(node44);
        org.junit.Assert.assertNotNull(node46);
        org.junit.Assert.assertNotNull(node48);
        org.junit.Assert.assertNotNull(node50);
        org.junit.Assert.assertNotNull(nodeArray51);
        org.junit.Assert.assertNull(node53);
        org.junit.Assert.assertNotNull(node57);
        org.junit.Assert.assertNull(str58);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray13 = new com.google.javascript.rhino.Node[] { node4, node6, node8, node10, node12 };
        com.google.javascript.rhino.Node node14 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray13);
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node21 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray26 = new com.google.javascript.rhino.Node[] { node17, node19, node21, node23, node25 };
        com.google.javascript.rhino.Node node27 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray26);
        com.google.javascript.rhino.Node node28 = new com.google.javascript.rhino.Node(100, node14, node27);
        java.lang.String str29 = closureCodingConvention0.getSingletonGetterClassName(node28);
        com.google.javascript.rhino.JSDocInfo jSDocInfo30 = null;
        node28.setJSDocInfo(jSDocInfo30);
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention32 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node36 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node38 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node40 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node42 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node44 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray45 = new com.google.javascript.rhino.Node[] { node36, node38, node40, node42, node44 };
        com.google.javascript.rhino.Node node46 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray45);
        com.google.javascript.rhino.Node node49 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node51 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node53 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node55 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node57 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray58 = new com.google.javascript.rhino.Node[] { node49, node51, node53, node55, node57 };
        com.google.javascript.rhino.Node node59 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray58);
        com.google.javascript.rhino.Node node60 = new com.google.javascript.rhino.Node(100, node46, node59);
        java.lang.String str61 = closureCodingConvention32.getSingletonGetterClassName(node60);
        com.google.javascript.rhino.Node node67 = com.google.javascript.rhino.Node.newString((int) (short) 0, "hi!", 100, (-2));
        com.google.javascript.rhino.Node node68 = new com.google.javascript.rhino.Node(10, node67);
        java.lang.String str69 = closureCodingConvention32.identifyTypeDefAssign(node68);
        com.google.javascript.rhino.Node node70 = node68.getNext();
        try {
            node28.removeChild(node68);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: node is not a child");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(nodeArray13);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNotNull(nodeArray26);
        org.junit.Assert.assertNull(str29);
        org.junit.Assert.assertNotNull(node36);
        org.junit.Assert.assertNotNull(node38);
        org.junit.Assert.assertNotNull(node40);
        org.junit.Assert.assertNotNull(node42);
        org.junit.Assert.assertNotNull(node44);
        org.junit.Assert.assertNotNull(nodeArray45);
        org.junit.Assert.assertNotNull(node49);
        org.junit.Assert.assertNotNull(node51);
        org.junit.Assert.assertNotNull(node53);
        org.junit.Assert.assertNotNull(node55);
        org.junit.Assert.assertNotNull(node57);
        org.junit.Assert.assertNotNull(nodeArray58);
        org.junit.Assert.assertNull(str61);
        org.junit.Assert.assertNotNull(node67);
        org.junit.Assert.assertNull(str69);
        org.junit.Assert.assertNull(node70);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        int int0 = com.google.javascript.rhino.Node.SKIP_INDEXES_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 30 + "'", int0 == 30);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        try {
            com.google.javascript.rhino.Context.checkOptimizationLevel(4095);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Optimization level outside [-1..9]: 4095");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        com.google.javascript.rhino.EvaluatorException evaluatorException3 = new com.google.javascript.rhino.EvaluatorException("goog.global", "// Input %num%", (int) ' ');
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.checkDuplicateMessages = false;
        boolean boolean3 = compilerOptions0.inlineAnonymousFunctionExpressions;
        compilerOptions0.recordFunctionInformation = true;
        boolean boolean6 = compilerOptions0.checkCaja;
        java.util.Set<java.lang.String> strSet7 = compilerOptions0.stripNamePrefixes;
        boolean boolean8 = compilerOptions0.inlineFunctions;
        compilerOptions0.prettyPrint = true;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(strSet7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.brokenClosureRequiresLevel;
        java.util.Set<java.lang.String> strSet2 = compilerOptions0.aliasableStrings;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy3 = com.google.javascript.jscomp.VariableRenamingPolicy.OFF;
        compilerOptions0.variableRenaming = variableRenamingPolicy3;
        boolean boolean5 = compilerOptions0.optimizeArgumentsArray;
        boolean boolean6 = compilerOptions0.flowSensitiveInlineVariables;
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(strSet2);
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy3 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.OFF + "'", variableRenamingPolicy3.equals(com.google.javascript.jscomp.VariableRenamingPolicy.OFF));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.DEPRECATED;
        java.lang.String str1 = diagnosticGroup0.toString();
        org.junit.Assert.assertNotNull(diagnosticGroup0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "DiagnosticGroup<deprecated>" + "'", str1.equals("DiagnosticGroup<deprecated>"));
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        com.google.javascript.rhino.EvaluatorException evaluatorException1 = new com.google.javascript.rhino.EvaluatorException("Unknown class name");
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.brokenClosureRequiresLevel;
        com.google.javascript.jscomp.CheckLevel checkLevel2 = com.google.javascript.jscomp.CheckLevel.WARNING;
        compilerOptions0.checkGlobalNamesLevel = checkLevel2;
        compilerOptions0.computeFunctionSideEffects = true;
        com.google.javascript.jscomp.CheckLevel checkLevel6 = compilerOptions0.checkGlobalThisLevel;
        compilerOptions0.setTweakToNumberLiteral("language version", 0);
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + checkLevel2 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel2.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
        org.junit.Assert.assertTrue("'" + checkLevel6 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel6.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray11 = new com.google.javascript.rhino.Node[] { node2, node4, node6, node8, node10 };
        com.google.javascript.rhino.Node node12 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray11);
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node15 = node12.copyInformationFrom(node14);
        java.lang.String str16 = node14.getString();
        boolean boolean17 = node14.isLocalResultCall();
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(nodeArray11);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString((int) (short) 0, "hi!", 100, (-2));
        com.google.javascript.jscomp.DiagnosticType diagnosticType7 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray8 = com.google.javascript.rhino.ScriptRuntime.emptyStrings;
        com.google.javascript.jscomp.JSError jSError9 = com.google.javascript.jscomp.JSError.make("", node6, diagnosticType7, strArray8);
        java.lang.String str10 = jSError9.sourceName;
        java.lang.Object obj11 = null;
        try {
            java.lang.String str12 = com.google.javascript.rhino.ScriptRuntime.getMessage2("DiagnosticGroup<deprecated>", (java.lang.Object) jSError9, obj11);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property DiagnosticGroup<deprecated>");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(diagnosticType7);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertNotNull(jSError9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
    }

//    @Test
//    public void test354() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test354");
//        com.google.javascript.rhino.Context context0 = com.google.javascript.rhino.Context.enter();
//        com.google.javascript.rhino.ScriptRuntime.storeUint32Result(context0, (long) (short) 10);
//        context0.addActivationName("hi!");
//        context0.setGeneratingSource(true);
//        try {
//            context0.setLanguageVersion((int) '#');
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Bad language version: 35");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(context0);
//    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile1 = com.google.javascript.jscomp.JSSourceFile.fromFile("false");
        org.junit.Assert.assertNotNull(jSSourceFile1);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.brokenClosureRequiresLevel;
        java.util.Set<java.lang.String> strSet2 = compilerOptions0.aliasableStrings;
        boolean boolean3 = compilerOptions0.decomposeExpressions;
        java.util.Set<java.lang.String> strSet4 = compilerOptions0.stripNamePrefixes;
        boolean boolean5 = compilerOptions0.instrumentForCoverageOnly;
        com.google.common.collect.Multimap<com.google.javascript.jscomp.CustomPassExecutionTime, com.google.javascript.jscomp.CompilerPass> customPassExecutionTimeMultimap6 = compilerOptions0.customPasses;
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(strSet2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(strSet4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(customPassExecutionTimeMultimap6);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.NodeTraversal.Callback callback1 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal2 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler0, callback1);
        compiler0.disableThreads();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile5 = com.google.javascript.jscomp.JSSourceFile.fromFile("Not declared as a constructor");
        com.google.javascript.jscomp.CompilerInput compilerInput7 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile5, false);
        java.io.PrintStream printStream8 = null;
        com.google.javascript.jscomp.Compiler compiler9 = new com.google.javascript.jscomp.Compiler(printStream8);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile11 = com.google.javascript.jscomp.JSSourceFile.fromFile("Not declared as a constructor");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile13 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.CompilerInput compilerInput14 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile13);
        com.google.javascript.jscomp.CompilerInput compilerInput17 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput14, "hi!", false);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile19 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        compilerInput14.setSourceFile((com.google.javascript.jscomp.SourceFile) jSSourceFile19);
        java.lang.String str21 = jSSourceFile19.toString();
        com.google.javascript.jscomp.CompilerOptions compilerOptions22 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean23 = compilerOptions22.aliasAllStrings;
        compilerOptions22.setGenerateExports(true);
        com.google.javascript.jscomp.Result result26 = compiler9.compile(jSSourceFile11, jSSourceFile19, compilerOptions22);
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray27 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile19 };
        com.google.javascript.jscomp.CompilerOptions compilerOptions28 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel29 = compilerOptions28.brokenClosureRequiresLevel;
        com.google.javascript.jscomp.CheckLevel checkLevel30 = com.google.javascript.jscomp.CheckLevel.WARNING;
        compilerOptions28.checkGlobalNamesLevel = checkLevel30;
        compilerOptions28.computeFunctionSideEffects = true;
        boolean boolean34 = compilerOptions28.removeDeadCode;
        compilerOptions28.inlineVariables = true;
        compilerOptions28.reserveRawExports = false;
        com.google.javascript.jscomp.Result result39 = compiler0.compile(jSSourceFile5, jSSourceFileArray27, compilerOptions28);
        org.junit.Assert.assertNotNull(jSSourceFile5);
        org.junit.Assert.assertNotNull(jSSourceFile11);
        org.junit.Assert.assertNotNull(jSSourceFile13);
        org.junit.Assert.assertNotNull(jSSourceFile19);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "" + "'", str21.equals(""));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(result26);
        org.junit.Assert.assertNotNull(jSSourceFileArray27);
        org.junit.Assert.assertTrue("'" + checkLevel29 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel29.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + checkLevel30 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel30.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(result39);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.CHECK_VARIABLES;
        com.google.javascript.jscomp.DiagnosticGroups.FILEOVERVIEW_JSDOC = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticGroups.CHECK_REGEXP = diagnosticGroup0;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.NodeTraversal.Callback callback1 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal2 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler0, callback1);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile4 = com.google.javascript.jscomp.JSSourceFile.fromFile("Not declared as a constructor");
        java.io.PrintStream printStream5 = null;
        com.google.javascript.jscomp.Compiler compiler6 = new com.google.javascript.jscomp.Compiler(printStream5);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile8 = com.google.javascript.jscomp.JSSourceFile.fromFile("Not declared as a constructor");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile10 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.CompilerInput compilerInput11 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile10);
        com.google.javascript.jscomp.CompilerInput compilerInput14 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput11, "hi!", false);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile16 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        compilerInput11.setSourceFile((com.google.javascript.jscomp.SourceFile) jSSourceFile16);
        java.lang.String str18 = jSSourceFile16.toString();
        com.google.javascript.jscomp.CompilerOptions compilerOptions19 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean20 = compilerOptions19.aliasAllStrings;
        compilerOptions19.setGenerateExports(true);
        com.google.javascript.jscomp.Result result23 = compiler6.compile(jSSourceFile8, jSSourceFile16, compilerOptions19);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile25 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.CompilerInput compilerInput26 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile25);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile28 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.CompilerInput compilerInput29 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile28);
        com.google.javascript.jscomp.CompilerInput compilerInput32 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput29, "hi!", false);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile34 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        compilerInput29.setSourceFile((com.google.javascript.jscomp.SourceFile) jSSourceFile34);
        java.lang.String str36 = jSSourceFile34.toString();
        java.io.PrintStream printStream37 = null;
        com.google.javascript.jscomp.Compiler compiler38 = new com.google.javascript.jscomp.Compiler(printStream37);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile40 = com.google.javascript.jscomp.JSSourceFile.fromFile("Not declared as a constructor");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile42 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.CompilerInput compilerInput43 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile42);
        com.google.javascript.jscomp.CompilerInput compilerInput46 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput43, "hi!", false);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile48 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        compilerInput43.setSourceFile((com.google.javascript.jscomp.SourceFile) jSSourceFile48);
        java.lang.String str50 = jSSourceFile48.toString();
        com.google.javascript.jscomp.CompilerOptions compilerOptions51 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean52 = compilerOptions51.aliasAllStrings;
        compilerOptions51.setGenerateExports(true);
        com.google.javascript.jscomp.Result result55 = compiler38.compile(jSSourceFile40, jSSourceFile48, compilerOptions51);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile57 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.CompilerInput compilerInput58 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile57);
        com.google.javascript.jscomp.Region region60 = jSSourceFile57.getRegion(24);
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray61 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile4, jSSourceFile16, jSSourceFile25, jSSourceFile34, jSSourceFile48, jSSourceFile57 };
        java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList62 = new java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile>();
        boolean boolean63 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList62, jSSourceFileArray61);
        com.google.javascript.jscomp.JSModule[] jSModuleArray64 = new com.google.javascript.jscomp.JSModule[] {};
        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList65 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
        boolean boolean66 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList65, jSModuleArray64);
        com.google.javascript.jscomp.CompilerOptions compilerOptions67 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel68 = compilerOptions67.brokenClosureRequiresLevel;
        com.google.javascript.jscomp.CheckLevel checkLevel69 = com.google.javascript.jscomp.CheckLevel.WARNING;
        compilerOptions67.checkGlobalNamesLevel = checkLevel69;
        compilerOptions67.computeFunctionSideEffects = true;
        boolean boolean73 = compilerOptions67.removeDeadCode;
        com.google.javascript.jscomp.CompilerOptions.TweakProcessing tweakProcessing74 = compilerOptions67.getTweakProcessing();
        com.google.javascript.jscomp.Result result75 = compiler0.compileModules((java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList62, (java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList65, compilerOptions67);
        java.lang.String str78 = compiler0.getSourceLine("com.google.javascript.rhino.EcmaError: TypeError: -1 is not a function, it is java.lang.Byte.", 7);
        boolean boolean79 = compiler0.acceptConstKeyword();
        com.google.javascript.jscomp.JSModule jSModule80 = null;
        try {
            java.lang.String[] strArray81 = compiler0.toSourceArray(jSModule80);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: java.lang.NullPointerException");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile4);
        org.junit.Assert.assertNotNull(jSSourceFile8);
        org.junit.Assert.assertNotNull(jSSourceFile10);
        org.junit.Assert.assertNotNull(jSSourceFile16);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "" + "'", str18.equals(""));
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(result23);
        org.junit.Assert.assertNotNull(jSSourceFile25);
        org.junit.Assert.assertNotNull(jSSourceFile28);
        org.junit.Assert.assertNotNull(jSSourceFile34);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "" + "'", str36.equals(""));
        org.junit.Assert.assertNotNull(jSSourceFile40);
        org.junit.Assert.assertNotNull(jSSourceFile42);
        org.junit.Assert.assertNotNull(jSSourceFile48);
        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "" + "'", str50.equals(""));
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertNotNull(result55);
        org.junit.Assert.assertNotNull(jSSourceFile57);
        org.junit.Assert.assertNull(region60);
        org.junit.Assert.assertNotNull(jSSourceFileArray61);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + true + "'", boolean63 == true);
        org.junit.Assert.assertNotNull(jSModuleArray64);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertTrue("'" + checkLevel68 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel68.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + checkLevel69 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel69.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
        org.junit.Assert.assertTrue("'" + tweakProcessing74 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TweakProcessing.OFF + "'", tweakProcessing74.equals(com.google.javascript.jscomp.CompilerOptions.TweakProcessing.OFF));
        org.junit.Assert.assertNotNull(result75);
        org.junit.Assert.assertNull(str78);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.checkDuplicateMessages = false;
        boolean boolean3 = compilerOptions0.inlineAnonymousFunctionExpressions;
        compilerOptions0.recordFunctionInformation = true;
        boolean boolean6 = compilerOptions0.checkCaja;
        compilerOptions0.aliasableGlobals = "EOF 0";
        com.google.javascript.jscomp.CheckLevel checkLevel9 = com.google.javascript.jscomp.CheckLevel.OFF;
        compilerOptions0.reportUnknownTypes = checkLevel9;
        boolean boolean11 = compilerOptions0.devirtualizePrototypeMethods;
        compilerOptions0.locale = "EOF 0";
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + checkLevel9 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel9.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

//    @Test
//    public void test361() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test361");
//        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.VISIBILITY;
//        com.google.javascript.jscomp.DiagnosticGroups.INVALID_CASTS = diagnosticGroup0;
//        org.junit.Assert.assertNull(diagnosticGroup0);
//    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        com.google.javascript.rhino.EvaluatorException evaluatorException5 = new com.google.javascript.rhino.EvaluatorException("Unknown class name", "{0}", 22, "", 18);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray13 = new com.google.javascript.rhino.Node[] { node4, node6, node8, node10, node12 };
        com.google.javascript.rhino.Node node14 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray13);
        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node17 = node14.copyInformationFrom(node16);
        com.google.javascript.rhino.Node node18 = node14.getParent();
        com.google.javascript.rhino.Node node19 = new com.google.javascript.rhino.Node((int) (short) -1, node14);
        boolean boolean20 = node14.wasEmptyNode();
        try {
            com.google.javascript.rhino.Node node21 = new com.google.javascript.rhino.Node(130, node14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: new child has existing parent");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(nodeArray13);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNull(node18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile1 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.CompilerInput compilerInput2 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile1);
        com.google.javascript.jscomp.CompilerInput compilerInput5 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput2, "hi!", false);
        java.lang.String str7 = compilerInput5.getLine(42);
        org.junit.Assert.assertNotNull(jSSourceFile1);
        org.junit.Assert.assertNull(str7);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        int int0 = com.google.javascript.rhino.Node.FLAG_GLOBAL_STATE_UNMODIFIED;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.brokenClosureRequiresLevel;
        com.google.javascript.jscomp.CheckLevel checkLevel2 = com.google.javascript.jscomp.CheckLevel.WARNING;
        compilerOptions0.checkGlobalNamesLevel = checkLevel2;
        compilerOptions0.computeFunctionSideEffects = true;
        boolean boolean6 = compilerOptions0.removeDeadCode;
        com.google.javascript.jscomp.SourceMap.DetailLevel detailLevel7 = null;
        compilerOptions0.sourceMapDetailLevel = detailLevel7;
        compilerOptions0.collapseAnonymousFunctions = false;
        compilerOptions0.removeTryCatchFinally = true;
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + checkLevel2 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel2.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        com.google.javascript.rhino.Node.SideEffectFlags sideEffectFlags1 = new com.google.javascript.rhino.Node.SideEffectFlags(10);
        int int2 = sideEffectFlags1.valueOf();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray11 = new com.google.javascript.rhino.Node[] { node2, node4, node6, node8, node10 };
        com.google.javascript.rhino.Node node12 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray11);
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node15 = node12.copyInformationFrom(node14);
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.Node.newNumber(100.0d, 4095, 9);
        node15.addChildToBack(node19);
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention21 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node25 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode((com.google.javascript.jscomp.CodingConvention) closureCodingConvention21, "", (int) (short) 100, (int) (short) 10);
        node15.addChildrenToFront(node25);
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(nodeArray11);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNotNull(node25);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        try {
            java.lang.String str1 = com.google.javascript.rhino.ScriptRuntime.getMessage0("1: ");
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property 1: ");
        } catch (java.lang.RuntimeException e) {
        }
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        com.google.javascript.jscomp.SourceFile sourceFile1 = com.google.javascript.jscomp.SourceFile.fromFile("// Input %num%");
        org.junit.Assert.assertNotNull(sourceFile1);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile1 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.CompilerInput compilerInput2 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile1);
        com.google.javascript.jscomp.CompilerInput compilerInput5 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput2, "hi!", false);
        com.google.javascript.jscomp.Compiler compiler6 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile8 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.CompilerInput compilerInput9 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile8);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile11 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.CompilerInput compilerInput12 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile11);
        com.google.javascript.jscomp.CompilerInput compilerInput15 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput12, "hi!", false);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile17 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        compilerInput12.setSourceFile((com.google.javascript.jscomp.SourceFile) jSSourceFile17);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile20 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray21 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile8, jSSourceFile17, jSSourceFile20 };
        java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList22 = new java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile>();
        boolean boolean23 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList22, jSSourceFileArray21);
        com.google.javascript.jscomp.JSModule[] jSModuleArray24 = new com.google.javascript.jscomp.JSModule[] {};
        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList25 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
        boolean boolean26 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList25, jSModuleArray24);
        com.google.javascript.jscomp.CompilerOptions compilerOptions27 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions27.checkDuplicateMessages = false;
        boolean boolean30 = compilerOptions27.inlineAnonymousFunctionExpressions;
        compilerOptions27.crossModuleMethodMotion = true;
        com.google.javascript.jscomp.Result result33 = compiler6.compileModules((java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList22, (java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList25, compilerOptions27);
        compilerInput2.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler6);
        int int35 = compiler6.getErrorCount();
        org.junit.Assert.assertNotNull(jSSourceFile1);
        org.junit.Assert.assertNotNull(jSSourceFile8);
        org.junit.Assert.assertNotNull(jSSourceFile11);
        org.junit.Assert.assertNotNull(jSSourceFile17);
        org.junit.Assert.assertNotNull(jSSourceFile20);
        org.junit.Assert.assertNotNull(jSSourceFileArray21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(jSModuleArray24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(result33);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 2 + "'", int35 == 2);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.Compiler compiler2 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile4 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.CompilerInput compilerInput5 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile4);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile7 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.CompilerInput compilerInput8 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile7);
        com.google.javascript.jscomp.CompilerInput compilerInput11 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput8, "hi!", false);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile13 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        compilerInput8.setSourceFile((com.google.javascript.jscomp.SourceFile) jSSourceFile13);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile16 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray17 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile4, jSSourceFile13, jSSourceFile16 };
        java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList18 = new java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile>();
        boolean boolean19 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList18, jSSourceFileArray17);
        com.google.javascript.jscomp.JSModule[] jSModuleArray20 = new com.google.javascript.jscomp.JSModule[] {};
        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList21 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
        boolean boolean22 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList21, jSModuleArray20);
        com.google.javascript.jscomp.CompilerOptions compilerOptions23 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions23.checkDuplicateMessages = false;
        boolean boolean26 = compilerOptions23.inlineAnonymousFunctionExpressions;
        compilerOptions23.crossModuleMethodMotion = true;
        com.google.javascript.jscomp.Result result29 = compiler2.compileModules((java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList18, (java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList21, compilerOptions23);
        com.google.javascript.jscomp.Compiler compiler30 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile32 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.CompilerInput compilerInput33 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile32);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile35 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.CompilerInput compilerInput36 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile35);
        com.google.javascript.jscomp.CompilerInput compilerInput39 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput36, "hi!", false);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile41 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        compilerInput36.setSourceFile((com.google.javascript.jscomp.SourceFile) jSSourceFile41);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile44 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray45 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile32, jSSourceFile41, jSSourceFile44 };
        java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList46 = new java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile>();
        boolean boolean47 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList46, jSSourceFileArray45);
        com.google.javascript.jscomp.JSModule[] jSModuleArray48 = new com.google.javascript.jscomp.JSModule[] {};
        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList49 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
        boolean boolean50 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList49, jSModuleArray48);
        com.google.javascript.jscomp.CompilerOptions compilerOptions51 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions51.checkDuplicateMessages = false;
        boolean boolean54 = compilerOptions51.inlineAnonymousFunctionExpressions;
        compilerOptions51.crossModuleMethodMotion = true;
        com.google.javascript.jscomp.Result result57 = compiler30.compileModules((java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList46, (java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList49, compilerOptions51);
        com.google.javascript.jscomp.CompilerOptions compilerOptions58 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel59 = compilerOptions58.brokenClosureRequiresLevel;
        java.util.Set<java.lang.String> strSet60 = compilerOptions58.aliasableStrings;
        boolean boolean61 = compilerOptions58.decomposeExpressions;
        java.util.Set<java.lang.String> strSet62 = compilerOptions58.stripNamePrefixes;
        com.google.javascript.jscomp.Result result63 = compiler1.compile((java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList18, (java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList46, compilerOptions58);
        boolean boolean64 = compilerOptions58.removeTryCatchFinally;
        org.junit.Assert.assertNotNull(jSSourceFile4);
        org.junit.Assert.assertNotNull(jSSourceFile7);
        org.junit.Assert.assertNotNull(jSSourceFile13);
        org.junit.Assert.assertNotNull(jSSourceFile16);
        org.junit.Assert.assertNotNull(jSSourceFileArray17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(jSModuleArray20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(result29);
        org.junit.Assert.assertNotNull(jSSourceFile32);
        org.junit.Assert.assertNotNull(jSSourceFile35);
        org.junit.Assert.assertNotNull(jSSourceFile41);
        org.junit.Assert.assertNotNull(jSSourceFile44);
        org.junit.Assert.assertNotNull(jSSourceFileArray45);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
        org.junit.Assert.assertNotNull(jSModuleArray48);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNotNull(result57);
        org.junit.Assert.assertTrue("'" + checkLevel59 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel59.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(strSet60);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertNotNull(strSet62);
        org.junit.Assert.assertNotNull(result63);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        int int0 = com.google.javascript.rhino.Node.SPECIALCALL_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 27 + "'", int0 == 27);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        java.lang.Object obj2 = null;
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy3 = com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC;
        java.lang.Object obj4 = null;
        try {
            java.lang.String str5 = com.google.javascript.rhino.ScriptRuntime.getMessage4("Not declared as a constructor", (java.lang.Object) "1: ", obj2, (java.lang.Object) propertyRenamingPolicy3, obj4);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property Not declared as a constructor");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy3 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC + "'", propertyRenamingPolicy3.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC));
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.checkDuplicateMessages = false;
        boolean boolean3 = compilerOptions0.inlineAnonymousFunctionExpressions;
        compilerOptions0.recordFunctionInformation = true;
        boolean boolean6 = compilerOptions0.checkCaja;
        compilerOptions0.aliasableGlobals = "EOF 0";
        boolean boolean9 = compilerOptions0.removeEmptyFunctions;
        boolean boolean10 = compilerOptions0.deadAssignmentElimination;
        compilerOptions0.allowLegacyJsMessages = true;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node4 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode((com.google.javascript.jscomp.CodingConvention) closureCodingConvention0, "", (int) (short) 100, (int) (short) 10);
        com.google.javascript.jscomp.Compiler compiler5 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.NodeTraversal.Callback callback6 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal7 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler5, callback6);
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString(36, "// Input %num%");
        try {
            com.google.javascript.jscomp.CodingConvention.ObjectLiteralCast objectLiteralCast11 = closureCodingConvention0.getObjectLiteralCast(nodeTraversal7, node10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(node10);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile1 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.CompilerInput compilerInput2 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile1);
        com.google.javascript.jscomp.CompilerInput compilerInput5 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput2, "hi!", false);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile7 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        compilerInput2.setSourceFile((com.google.javascript.jscomp.SourceFile) jSSourceFile7);
        java.io.PrintStream printStream9 = null;
        com.google.javascript.jscomp.Compiler compiler10 = new com.google.javascript.jscomp.Compiler(printStream9);
        com.google.javascript.jscomp.Compiler compiler11 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile13 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.CompilerInput compilerInput14 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile13);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile16 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.CompilerInput compilerInput17 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile16);
        com.google.javascript.jscomp.CompilerInput compilerInput20 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput17, "hi!", false);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile22 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        compilerInput17.setSourceFile((com.google.javascript.jscomp.SourceFile) jSSourceFile22);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile25 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray26 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile13, jSSourceFile22, jSSourceFile25 };
        java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList27 = new java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile>();
        boolean boolean28 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList27, jSSourceFileArray26);
        com.google.javascript.jscomp.JSModule[] jSModuleArray29 = new com.google.javascript.jscomp.JSModule[] {};
        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList30 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
        boolean boolean31 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList30, jSModuleArray29);
        com.google.javascript.jscomp.CompilerOptions compilerOptions32 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions32.checkDuplicateMessages = false;
        boolean boolean35 = compilerOptions32.inlineAnonymousFunctionExpressions;
        compilerOptions32.crossModuleMethodMotion = true;
        com.google.javascript.jscomp.Result result38 = compiler11.compileModules((java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList27, (java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList30, compilerOptions32);
        com.google.javascript.jscomp.Compiler compiler39 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile41 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.CompilerInput compilerInput42 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile41);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile44 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.CompilerInput compilerInput45 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile44);
        com.google.javascript.jscomp.CompilerInput compilerInput48 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput45, "hi!", false);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile50 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        compilerInput45.setSourceFile((com.google.javascript.jscomp.SourceFile) jSSourceFile50);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile53 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray54 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile41, jSSourceFile50, jSSourceFile53 };
        java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList55 = new java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile>();
        boolean boolean56 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList55, jSSourceFileArray54);
        com.google.javascript.jscomp.JSModule[] jSModuleArray57 = new com.google.javascript.jscomp.JSModule[] {};
        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList58 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
        boolean boolean59 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList58, jSModuleArray57);
        com.google.javascript.jscomp.CompilerOptions compilerOptions60 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions60.checkDuplicateMessages = false;
        boolean boolean63 = compilerOptions60.inlineAnonymousFunctionExpressions;
        compilerOptions60.crossModuleMethodMotion = true;
        com.google.javascript.jscomp.Result result66 = compiler39.compileModules((java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList55, (java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList58, compilerOptions60);
        com.google.javascript.jscomp.CompilerOptions compilerOptions67 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel68 = compilerOptions67.brokenClosureRequiresLevel;
        java.util.Set<java.lang.String> strSet69 = compilerOptions67.aliasableStrings;
        boolean boolean70 = compilerOptions67.decomposeExpressions;
        java.util.Set<java.lang.String> strSet71 = compilerOptions67.stripNamePrefixes;
        com.google.javascript.jscomp.Result result72 = compiler10.compile((java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList27, (java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList55, compilerOptions67);
        com.google.javascript.jscomp.PerformanceTracker performanceTracker73 = compiler10.tracker;
        com.google.javascript.rhino.Node node74 = compilerInput2.getAstRoot((com.google.javascript.jscomp.AbstractCompiler) compiler10);
        com.google.javascript.jscomp.Compiler.CodeBuilder codeBuilder75 = null;
        com.google.javascript.rhino.Node node80 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node82 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node84 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node86 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node88 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray89 = new com.google.javascript.rhino.Node[] { node80, node82, node84, node86, node88 };
        com.google.javascript.rhino.Node node90 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray89);
        com.google.javascript.rhino.Node node92 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node93 = node90.copyInformationFrom(node92);
        com.google.javascript.rhino.Node node94 = node90.getParent();
        com.google.javascript.rhino.Node node95 = new com.google.javascript.rhino.Node((int) (short) -1, node90);
        try {
            compiler10.toSource(codeBuilder75, (int) (byte) 0, node90);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: java.lang.Error: Unknown type 0\nEOF\n    STRING \n    STRING \n    STRING \n    STRING \n    STRING \n");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile1);
        org.junit.Assert.assertNotNull(jSSourceFile7);
        org.junit.Assert.assertNotNull(jSSourceFile13);
        org.junit.Assert.assertNotNull(jSSourceFile16);
        org.junit.Assert.assertNotNull(jSSourceFile22);
        org.junit.Assert.assertNotNull(jSSourceFile25);
        org.junit.Assert.assertNotNull(jSSourceFileArray26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(jSModuleArray29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(result38);
        org.junit.Assert.assertNotNull(jSSourceFile41);
        org.junit.Assert.assertNotNull(jSSourceFile44);
        org.junit.Assert.assertNotNull(jSSourceFile50);
        org.junit.Assert.assertNotNull(jSSourceFile53);
        org.junit.Assert.assertNotNull(jSSourceFileArray54);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + true + "'", boolean56 == true);
        org.junit.Assert.assertNotNull(jSModuleArray57);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertNotNull(result66);
        org.junit.Assert.assertTrue("'" + checkLevel68 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel68.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(strSet69);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertNotNull(strSet71);
        org.junit.Assert.assertNotNull(result72);
        org.junit.Assert.assertNull(performanceTracker73);
        org.junit.Assert.assertNull(node74);
        org.junit.Assert.assertNotNull(node80);
        org.junit.Assert.assertNotNull(node82);
        org.junit.Assert.assertNotNull(node84);
        org.junit.Assert.assertNotNull(node86);
        org.junit.Assert.assertNotNull(node88);
        org.junit.Assert.assertNotNull(nodeArray89);
        org.junit.Assert.assertNotNull(node92);
        org.junit.Assert.assertNotNull(node93);
        org.junit.Assert.assertNull(node94);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        com.google.javascript.rhino.EcmaError ecmaError1 = com.google.javascript.rhino.ScriptRuntime.typeError("");
        java.lang.String str2 = ecmaError1.getSourceName();
        java.lang.Throwable throwable3 = null;
        try {
            ecmaError1.addSuppressed(throwable3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Cannot suppress a null exception.");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(ecmaError1);
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.checkDuplicateMessages = false;
        java.util.Set<java.lang.String> strSet3 = compilerOptions0.stripTypes;
        com.google.javascript.jscomp.CheckLevel checkLevel4 = compilerOptions0.checkMissingGetCssNameLevel;
        org.junit.Assert.assertNotNull(strSet3);
        org.junit.Assert.assertTrue("'" + checkLevel4 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel4.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.checkDuplicateMessages = false;
        boolean boolean3 = compilerOptions0.inlineAnonymousFunctionExpressions;
        java.lang.String str4 = compilerOptions0.checkMissingGetCssNameBlacklist;
        compilerOptions0.removeUnusedLocalVars = true;
        com.google.common.collect.Multimap<com.google.javascript.jscomp.CustomPassExecutionTime, com.google.javascript.jscomp.CompilerPass> customPassExecutionTimeMultimap7 = null;
        compilerOptions0.customPasses = customPassExecutionTimeMultimap7;
        compilerOptions0.lineLengthThreshold(12);
        boolean boolean11 = compilerOptions0.devirtualizePrototypeMethods;
        compilerOptions0.setRewriteNewDateGoogNow(true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.checkDuplicateMessages = false;
        java.util.Set<java.lang.String> strSet3 = compilerOptions0.stripTypes;
        com.google.javascript.jscomp.CompilerOptions compilerOptions4 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions4.checkDuplicateMessages = false;
        boolean boolean7 = compilerOptions4.inlineAnonymousFunctionExpressions;
        compilerOptions4.recordFunctionInformation = true;
        boolean boolean10 = compilerOptions4.checkCaja;
        compilerOptions4.aliasableGlobals = "EOF 0";
        boolean boolean13 = compilerOptions4.removeEmptyFunctions;
        com.google.javascript.jscomp.CompilerOptions.TweakProcessing tweakProcessing14 = com.google.javascript.jscomp.CompilerOptions.TweakProcessing.STRIP;
        compilerOptions4.setTweakProcessing(tweakProcessing14);
        compilerOptions0.setTweakProcessing(tweakProcessing14);
        org.junit.Assert.assertNotNull(strSet3);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + tweakProcessing14 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TweakProcessing.STRIP + "'", tweakProcessing14.equals(com.google.javascript.jscomp.CompilerOptions.TweakProcessing.STRIP));
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.checkDuplicateMessages = false;
        boolean boolean3 = compilerOptions0.inlineAnonymousFunctionExpressions;
        compilerOptions0.recordFunctionInformation = true;
        boolean boolean6 = compilerOptions0.checkCaja;
        java.util.Set<java.lang.String> strSet7 = compilerOptions0.stripNamePrefixes;
        boolean boolean8 = compilerOptions0.inlineFunctions;
        boolean boolean9 = compilerOptions0.generatePseudoNames;
        compilerOptions0.smartNameRemoval = false;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(strSet7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

//    @Test
//    public void test383() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test383");
//        com.google.javascript.rhino.Context context0 = com.google.javascript.rhino.Context.enter();
//        boolean boolean1 = context0.isGeneratingSource();
//        boolean boolean2 = context0.isGeneratingSource();
//        java.beans.PropertyChangeListener propertyChangeListener3 = null;
//        try {
//            context0.removePropertyChangeListener(propertyChangeListener3);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(context0);
//        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
//    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        com.google.javascript.rhino.Context context0 = com.google.javascript.rhino.Context.enter();
        boolean boolean1 = context0.isGeneratingSource();
        java.lang.Object obj2 = context0.getDebuggerContextData();
        boolean boolean3 = context0.isGeneratingSource();
        java.lang.Object obj4 = context0.getDebuggerContextData();
        org.junit.Assert.assertNotNull(context0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNull(obj2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNull(obj4);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        int int0 = com.google.javascript.rhino.Node.DESCENDANTS_FLAG;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        com.google.javascript.rhino.Context context0 = com.google.javascript.rhino.Context.enter();
        boolean boolean1 = context0.isGeneratingDebug();
        org.junit.Assert.assertNotNull(context0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.brokenClosureRequiresLevel;
        java.lang.String str2 = compilerOptions0.renamePrefix;
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.brokenClosureRequiresLevel;
        com.google.javascript.jscomp.CheckLevel checkLevel2 = com.google.javascript.jscomp.CheckLevel.WARNING;
        compilerOptions0.checkGlobalNamesLevel = checkLevel2;
        compilerOptions0.computeFunctionSideEffects = true;
        boolean boolean6 = compilerOptions0.removeDeadCode;
        compilerOptions0.setManageClosureDependencies(false);
        compilerOptions0.nameReferenceGraphPath = "";
        java.lang.String str11 = compilerOptions0.syntheticBlockStartMarker;
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup12 = com.google.javascript.jscomp.DiagnosticGroups.STRICT_MODULE_DEP_CHECK;
        java.lang.String str13 = diagnosticGroup12.toString();
        com.google.javascript.jscomp.CheckLevel checkLevel14 = com.google.javascript.jscomp.CheckLevel.WARNING;
        compilerOptions0.setWarningLevel(diagnosticGroup12, checkLevel14);
        compilerOptions0.unaliasableGlobals = "goog.exportProperty";
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + checkLevel2 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel2.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(str11);
        org.junit.Assert.assertNotNull(diagnosticGroup12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "DiagnosticGroup<strictModuleDepCheck>" + "'", str13.equals("DiagnosticGroup<strictModuleDepCheck>"));
        org.junit.Assert.assertTrue("'" + checkLevel14 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel14.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.brokenClosureRequiresLevel;
        java.util.Set<java.lang.String> strSet2 = compilerOptions0.aliasableStrings;
        boolean boolean3 = compilerOptions0.decomposeExpressions;
        boolean boolean4 = compilerOptions0.removeUnusedLocalVars;
        java.lang.String str5 = compilerOptions0.sourceMapOutputPath;
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(strSet2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(str5);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile1 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.CompilerInput compilerInput2 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile1);
        com.google.javascript.jscomp.CompilerInput compilerInput5 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput2, "hi!", false);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile7 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        compilerInput2.setSourceFile((com.google.javascript.jscomp.SourceFile) jSSourceFile7);
        java.lang.String str9 = jSSourceFile7.toString();
        com.google.javascript.jscomp.CompilerInput compilerInput10 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile7);
        jSSourceFile7.clearCachedSource();
        java.lang.String str12 = jSSourceFile7.toString();
        org.junit.Assert.assertNotNull(jSSourceFile1);
        org.junit.Assert.assertNotNull(jSSourceFile7);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        com.google.javascript.rhino.EcmaError ecmaError1 = com.google.javascript.rhino.ScriptRuntime.typeError("");
        java.lang.String str2 = ecmaError1.getSourceName();
        int int3 = ecmaError1.columnNumber();
        int int4 = ecmaError1.getColumnNumber();
        java.lang.String str5 = ecmaError1.sourceName();
        org.junit.Assert.assertNotNull(ecmaError1);
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNull(str5);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.NodeTraversal.Callback callback1 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal2 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler0, callback1);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile4 = com.google.javascript.jscomp.JSSourceFile.fromFile("Not declared as a constructor");
        java.io.PrintStream printStream5 = null;
        com.google.javascript.jscomp.Compiler compiler6 = new com.google.javascript.jscomp.Compiler(printStream5);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile8 = com.google.javascript.jscomp.JSSourceFile.fromFile("Not declared as a constructor");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile10 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.CompilerInput compilerInput11 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile10);
        com.google.javascript.jscomp.CompilerInput compilerInput14 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput11, "hi!", false);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile16 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        compilerInput11.setSourceFile((com.google.javascript.jscomp.SourceFile) jSSourceFile16);
        java.lang.String str18 = jSSourceFile16.toString();
        com.google.javascript.jscomp.CompilerOptions compilerOptions19 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean20 = compilerOptions19.aliasAllStrings;
        compilerOptions19.setGenerateExports(true);
        com.google.javascript.jscomp.Result result23 = compiler6.compile(jSSourceFile8, jSSourceFile16, compilerOptions19);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile25 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.CompilerInput compilerInput26 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile25);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile28 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.CompilerInput compilerInput29 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile28);
        com.google.javascript.jscomp.CompilerInput compilerInput32 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput29, "hi!", false);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile34 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        compilerInput29.setSourceFile((com.google.javascript.jscomp.SourceFile) jSSourceFile34);
        java.lang.String str36 = jSSourceFile34.toString();
        java.io.PrintStream printStream37 = null;
        com.google.javascript.jscomp.Compiler compiler38 = new com.google.javascript.jscomp.Compiler(printStream37);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile40 = com.google.javascript.jscomp.JSSourceFile.fromFile("Not declared as a constructor");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile42 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.CompilerInput compilerInput43 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile42);
        com.google.javascript.jscomp.CompilerInput compilerInput46 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput43, "hi!", false);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile48 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        compilerInput43.setSourceFile((com.google.javascript.jscomp.SourceFile) jSSourceFile48);
        java.lang.String str50 = jSSourceFile48.toString();
        com.google.javascript.jscomp.CompilerOptions compilerOptions51 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean52 = compilerOptions51.aliasAllStrings;
        compilerOptions51.setGenerateExports(true);
        com.google.javascript.jscomp.Result result55 = compiler38.compile(jSSourceFile40, jSSourceFile48, compilerOptions51);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile57 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.CompilerInput compilerInput58 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile57);
        com.google.javascript.jscomp.Region region60 = jSSourceFile57.getRegion(24);
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray61 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile4, jSSourceFile16, jSSourceFile25, jSSourceFile34, jSSourceFile48, jSSourceFile57 };
        java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList62 = new java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile>();
        boolean boolean63 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList62, jSSourceFileArray61);
        com.google.javascript.jscomp.JSModule[] jSModuleArray64 = new com.google.javascript.jscomp.JSModule[] {};
        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList65 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
        boolean boolean66 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList65, jSModuleArray64);
        com.google.javascript.jscomp.CompilerOptions compilerOptions67 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel68 = compilerOptions67.brokenClosureRequiresLevel;
        com.google.javascript.jscomp.CheckLevel checkLevel69 = com.google.javascript.jscomp.CheckLevel.WARNING;
        compilerOptions67.checkGlobalNamesLevel = checkLevel69;
        compilerOptions67.computeFunctionSideEffects = true;
        boolean boolean73 = compilerOptions67.removeDeadCode;
        com.google.javascript.jscomp.CompilerOptions.TweakProcessing tweakProcessing74 = compilerOptions67.getTweakProcessing();
        com.google.javascript.jscomp.Result result75 = compiler0.compileModules((java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList62, (java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList65, compilerOptions67);
        java.lang.String str78 = compiler0.getSourceLine("com.google.javascript.rhino.EcmaError: TypeError: -1 is not a function, it is java.lang.Byte.", 7);
        boolean boolean79 = compiler0.acceptConstKeyword();
        com.google.javascript.jscomp.PassConfig passConfig80 = null;
        try {
            compiler0.setPassConfig(passConfig80);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile4);
        org.junit.Assert.assertNotNull(jSSourceFile8);
        org.junit.Assert.assertNotNull(jSSourceFile10);
        org.junit.Assert.assertNotNull(jSSourceFile16);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "" + "'", str18.equals(""));
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(result23);
        org.junit.Assert.assertNotNull(jSSourceFile25);
        org.junit.Assert.assertNotNull(jSSourceFile28);
        org.junit.Assert.assertNotNull(jSSourceFile34);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "" + "'", str36.equals(""));
        org.junit.Assert.assertNotNull(jSSourceFile40);
        org.junit.Assert.assertNotNull(jSSourceFile42);
        org.junit.Assert.assertNotNull(jSSourceFile48);
        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "" + "'", str50.equals(""));
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertNotNull(result55);
        org.junit.Assert.assertNotNull(jSSourceFile57);
        org.junit.Assert.assertNull(region60);
        org.junit.Assert.assertNotNull(jSSourceFileArray61);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + true + "'", boolean63 == true);
        org.junit.Assert.assertNotNull(jSModuleArray64);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertTrue("'" + checkLevel68 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel68.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + checkLevel69 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel69.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
        org.junit.Assert.assertTrue("'" + tweakProcessing74 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TweakProcessing.OFF + "'", tweakProcessing74.equals(com.google.javascript.jscomp.CompilerOptions.TweakProcessing.OFF));
        org.junit.Assert.assertNotNull(result75);
        org.junit.Assert.assertNull(str78);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray13 = new com.google.javascript.rhino.Node[] { node4, node6, node8, node10, node12 };
        com.google.javascript.rhino.Node node14 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray13);
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node21 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray26 = new com.google.javascript.rhino.Node[] { node17, node19, node21, node23, node25 };
        com.google.javascript.rhino.Node node27 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray26);
        com.google.javascript.rhino.Node node28 = new com.google.javascript.rhino.Node(100, node14, node27);
        boolean boolean29 = closureCodingConvention0.isVarArgsParameter(node28);
        java.lang.String str30 = closureCodingConvention0.getGlobalObject();
        boolean boolean32 = closureCodingConvention0.isPrivate("TypeError: ");
        com.google.javascript.jscomp.AbstractCompiler abstractCompiler33 = null;
        com.google.javascript.jscomp.NodeTraversal.Callback callback34 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal35 = new com.google.javascript.jscomp.NodeTraversal(abstractCompiler33, callback34);
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention36 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node40 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node42 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node44 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node46 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node48 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray49 = new com.google.javascript.rhino.Node[] { node40, node42, node44, node46, node48 };
        com.google.javascript.rhino.Node node50 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray49);
        com.google.javascript.rhino.Node node53 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node55 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node57 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node59 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node61 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray62 = new com.google.javascript.rhino.Node[] { node53, node55, node57, node59, node61 };
        com.google.javascript.rhino.Node node63 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray62);
        com.google.javascript.rhino.Node node64 = new com.google.javascript.rhino.Node(100, node50, node63);
        boolean boolean65 = closureCodingConvention36.isVarArgsParameter(node64);
        java.lang.String str66 = closureCodingConvention36.getGlobalObject();
        boolean boolean68 = closureCodingConvention36.isValidEnumKey("goog.global");
        com.google.javascript.rhino.Node node72 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node74 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node76 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node78 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node80 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray81 = new com.google.javascript.rhino.Node[] { node72, node74, node76, node78, node80 };
        com.google.javascript.rhino.Node node82 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray81);
        com.google.javascript.rhino.Node node84 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node85 = node82.copyInformationFrom(node84);
        com.google.javascript.rhino.Node node86 = node82.getParent();
        com.google.javascript.rhino.Node node87 = new com.google.javascript.rhino.Node((int) (short) -1, node82);
        boolean boolean88 = node82.wasEmptyNode();
        java.lang.String str89 = closureCodingConvention36.getSingletonGetterClassName(node82);
        try {
            com.google.javascript.jscomp.CodingConvention.ObjectLiteralCast objectLiteralCast90 = closureCodingConvention0.getObjectLiteralCast(nodeTraversal35, node82);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(nodeArray13);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNotNull(nodeArray26);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "goog.global" + "'", str30.equals("goog.global"));
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(node40);
        org.junit.Assert.assertNotNull(node42);
        org.junit.Assert.assertNotNull(node44);
        org.junit.Assert.assertNotNull(node46);
        org.junit.Assert.assertNotNull(node48);
        org.junit.Assert.assertNotNull(nodeArray49);
        org.junit.Assert.assertNotNull(node53);
        org.junit.Assert.assertNotNull(node55);
        org.junit.Assert.assertNotNull(node57);
        org.junit.Assert.assertNotNull(node59);
        org.junit.Assert.assertNotNull(node61);
        org.junit.Assert.assertNotNull(nodeArray62);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertTrue("'" + str66 + "' != '" + "goog.global" + "'", str66.equals("goog.global"));
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + true + "'", boolean68 == true);
        org.junit.Assert.assertNotNull(node72);
        org.junit.Assert.assertNotNull(node74);
        org.junit.Assert.assertNotNull(node76);
        org.junit.Assert.assertNotNull(node78);
        org.junit.Assert.assertNotNull(node80);
        org.junit.Assert.assertNotNull(nodeArray81);
        org.junit.Assert.assertNotNull(node84);
        org.junit.Assert.assertNotNull(node85);
        org.junit.Assert.assertNull(node86);
        org.junit.Assert.assertTrue("'" + boolean88 + "' != '" + false + "'", boolean88 == false);
        org.junit.Assert.assertNull(str89);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newString((int) (short) 0, "hi!", 100, (-2));
        com.google.javascript.rhino.Node node6 = new com.google.javascript.rhino.Node(10, node5);
        node5.setLineno((-1));
        node5.setIsSyntheticBlock(true);
        org.junit.Assert.assertNotNull(node5);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.checkDuplicateMessages = false;
        boolean boolean3 = compilerOptions0.inlineAnonymousFunctionExpressions;
        compilerOptions0.recordFunctionInformation = true;
        boolean boolean6 = compilerOptions0.checkCaja;
        compilerOptions0.aliasableGlobals = "EOF 0";
        boolean boolean9 = compilerOptions0.removeEmptyFunctions;
        boolean boolean10 = compilerOptions0.deadAssignmentElimination;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap11 = null;
        compilerOptions0.cssRenamingMap = cssRenamingMap11;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.NodeTraversal.Callback callback1 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal2 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler0, callback1);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile4 = com.google.javascript.jscomp.JSSourceFile.fromFile("Not declared as a constructor");
        java.io.PrintStream printStream5 = null;
        com.google.javascript.jscomp.Compiler compiler6 = new com.google.javascript.jscomp.Compiler(printStream5);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile8 = com.google.javascript.jscomp.JSSourceFile.fromFile("Not declared as a constructor");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile10 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.CompilerInput compilerInput11 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile10);
        com.google.javascript.jscomp.CompilerInput compilerInput14 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput11, "hi!", false);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile16 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        compilerInput11.setSourceFile((com.google.javascript.jscomp.SourceFile) jSSourceFile16);
        java.lang.String str18 = jSSourceFile16.toString();
        com.google.javascript.jscomp.CompilerOptions compilerOptions19 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean20 = compilerOptions19.aliasAllStrings;
        compilerOptions19.setGenerateExports(true);
        com.google.javascript.jscomp.Result result23 = compiler6.compile(jSSourceFile8, jSSourceFile16, compilerOptions19);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile25 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.CompilerInput compilerInput26 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile25);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile28 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.CompilerInput compilerInput29 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile28);
        com.google.javascript.jscomp.CompilerInput compilerInput32 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput29, "hi!", false);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile34 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        compilerInput29.setSourceFile((com.google.javascript.jscomp.SourceFile) jSSourceFile34);
        java.lang.String str36 = jSSourceFile34.toString();
        java.io.PrintStream printStream37 = null;
        com.google.javascript.jscomp.Compiler compiler38 = new com.google.javascript.jscomp.Compiler(printStream37);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile40 = com.google.javascript.jscomp.JSSourceFile.fromFile("Not declared as a constructor");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile42 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.CompilerInput compilerInput43 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile42);
        com.google.javascript.jscomp.CompilerInput compilerInput46 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput43, "hi!", false);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile48 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        compilerInput43.setSourceFile((com.google.javascript.jscomp.SourceFile) jSSourceFile48);
        java.lang.String str50 = jSSourceFile48.toString();
        com.google.javascript.jscomp.CompilerOptions compilerOptions51 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean52 = compilerOptions51.aliasAllStrings;
        compilerOptions51.setGenerateExports(true);
        com.google.javascript.jscomp.Result result55 = compiler38.compile(jSSourceFile40, jSSourceFile48, compilerOptions51);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile57 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.CompilerInput compilerInput58 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile57);
        com.google.javascript.jscomp.Region region60 = jSSourceFile57.getRegion(24);
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray61 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile4, jSSourceFile16, jSSourceFile25, jSSourceFile34, jSSourceFile48, jSSourceFile57 };
        java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList62 = new java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile>();
        boolean boolean63 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList62, jSSourceFileArray61);
        com.google.javascript.jscomp.JSModule[] jSModuleArray64 = new com.google.javascript.jscomp.JSModule[] {};
        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList65 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
        boolean boolean66 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList65, jSModuleArray64);
        com.google.javascript.jscomp.CompilerOptions compilerOptions67 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel68 = compilerOptions67.brokenClosureRequiresLevel;
        com.google.javascript.jscomp.CheckLevel checkLevel69 = com.google.javascript.jscomp.CheckLevel.WARNING;
        compilerOptions67.checkGlobalNamesLevel = checkLevel69;
        compilerOptions67.computeFunctionSideEffects = true;
        boolean boolean73 = compilerOptions67.removeDeadCode;
        com.google.javascript.jscomp.CompilerOptions.TweakProcessing tweakProcessing74 = compilerOptions67.getTweakProcessing();
        com.google.javascript.jscomp.Result result75 = compiler0.compileModules((java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList62, (java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList65, compilerOptions67);
        java.lang.String str78 = compiler0.getSourceLine("com.google.javascript.rhino.EcmaError: TypeError: -1 is not a function, it is java.lang.Byte.", 7);
        try {
            com.google.javascript.jscomp.CompilerInput compilerInput80 = compiler0.newExternInput("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Conflicting externs name: ");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile4);
        org.junit.Assert.assertNotNull(jSSourceFile8);
        org.junit.Assert.assertNotNull(jSSourceFile10);
        org.junit.Assert.assertNotNull(jSSourceFile16);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "" + "'", str18.equals(""));
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(result23);
        org.junit.Assert.assertNotNull(jSSourceFile25);
        org.junit.Assert.assertNotNull(jSSourceFile28);
        org.junit.Assert.assertNotNull(jSSourceFile34);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "" + "'", str36.equals(""));
        org.junit.Assert.assertNotNull(jSSourceFile40);
        org.junit.Assert.assertNotNull(jSSourceFile42);
        org.junit.Assert.assertNotNull(jSSourceFile48);
        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "" + "'", str50.equals(""));
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertNotNull(result55);
        org.junit.Assert.assertNotNull(jSSourceFile57);
        org.junit.Assert.assertNull(region60);
        org.junit.Assert.assertNotNull(jSSourceFileArray61);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + true + "'", boolean63 == true);
        org.junit.Assert.assertNotNull(jSModuleArray64);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertTrue("'" + checkLevel68 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel68.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + checkLevel69 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel69.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
        org.junit.Assert.assertTrue("'" + tweakProcessing74 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TweakProcessing.OFF + "'", tweakProcessing74.equals(com.google.javascript.jscomp.CompilerOptions.TweakProcessing.OFF));
        org.junit.Assert.assertNotNull(result75);
        org.junit.Assert.assertNull(str78);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        com.google.javascript.jscomp.AbstractCompiler abstractCompiler0 = null;
        com.google.javascript.jscomp.NodeTraversal.Callback callback1 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal2 = new com.google.javascript.jscomp.NodeTraversal(abstractCompiler0, callback1);
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray14 = new com.google.javascript.rhino.Node[] { node5, node7, node9, node11, node13 };
        com.google.javascript.rhino.Node node15 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray14);
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node18 = node15.copyInformationFrom(node17);
        com.google.javascript.rhino.Node node19 = node17.getLastSibling();
        com.google.javascript.jscomp.CompilerOptions compilerOptions20 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel21 = compilerOptions20.brokenClosureRequiresLevel;
        com.google.javascript.jscomp.CheckLevel checkLevel22 = com.google.javascript.jscomp.CheckLevel.WARNING;
        compilerOptions20.checkGlobalNamesLevel = checkLevel22;
        compilerOptions20.computeFunctionSideEffects = true;
        com.google.javascript.jscomp.CheckLevel checkLevel26 = compilerOptions20.checkGlobalThisLevel;
        com.google.javascript.jscomp.DiagnosticType diagnosticType27 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        com.google.javascript.rhino.Node node33 = com.google.javascript.rhino.Node.newString((int) (short) 0, "hi!", 100, (-2));
        com.google.javascript.jscomp.DiagnosticType diagnosticType34 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray35 = com.google.javascript.rhino.ScriptRuntime.emptyStrings;
        com.google.javascript.jscomp.JSError jSError36 = com.google.javascript.jscomp.JSError.make("", node33, diagnosticType34, strArray35);
        com.google.javascript.jscomp.JSError jSError37 = nodeTraversal2.makeError(node19, checkLevel26, diagnosticType27, strArray35);
        try {
            int int39 = node19.getExistingIntProp(11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: FAILED ASSERTION");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(nodeArray14);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertTrue("'" + checkLevel21 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel21.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + checkLevel22 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel22.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
        org.junit.Assert.assertTrue("'" + checkLevel26 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel26.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(diagnosticType27);
        org.junit.Assert.assertNotNull(node33);
        org.junit.Assert.assertNotNull(diagnosticType34);
        org.junit.Assert.assertNotNull(strArray35);
        org.junit.Assert.assertNotNull(jSError36);
        org.junit.Assert.assertNotNull(jSError37);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        com.google.javascript.rhino.EcmaError ecmaError1 = com.google.javascript.rhino.ScriptRuntime.typeError("");
        java.lang.String str2 = ecmaError1.details();
        java.lang.String str3 = ecmaError1.toString();
        org.junit.Assert.assertNotNull(ecmaError1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "TypeError: " + "'", str2.equals("TypeError: "));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "com.google.javascript.rhino.EcmaError: TypeError: " + "'", str3.equals("com.google.javascript.rhino.EcmaError: TypeError: "));
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        com.google.javascript.rhino.Node node3 = new com.google.javascript.rhino.Node(41, 44, 34);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.brokenClosureRequiresLevel;
        com.google.javascript.jscomp.CheckLevel checkLevel2 = com.google.javascript.jscomp.CheckLevel.WARNING;
        compilerOptions0.checkGlobalNamesLevel = checkLevel2;
        com.google.javascript.jscomp.ErrorFormat errorFormat4 = null;
        compilerOptions0.errorFormat = errorFormat4;
        boolean boolean6 = compilerOptions0.ambiguateProperties;
        com.google.javascript.jscomp.CompilerOptions compilerOptions7 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel8 = compilerOptions7.brokenClosureRequiresLevel;
        com.google.javascript.jscomp.CheckLevel checkLevel9 = com.google.javascript.jscomp.CheckLevel.WARNING;
        compilerOptions7.checkGlobalNamesLevel = checkLevel9;
        compilerOptions7.computeFunctionSideEffects = true;
        boolean boolean13 = compilerOptions7.removeDeadCode;
        compilerOptions7.inlineVariables = true;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy16 = com.google.javascript.jscomp.VariableRenamingPolicy.OFF;
        compilerOptions7.variableRenaming = variableRenamingPolicy16;
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy18 = com.google.javascript.jscomp.PropertyRenamingPolicy.HEURISTIC;
        compilerOptions0.setRenamingPolicy(variableRenamingPolicy16, propertyRenamingPolicy18);
        compilerOptions0.markNoSideEffectCalls = false;
        boolean boolean22 = compilerOptions0.moveFunctionDeclarations;
        compilerOptions0.aliasAllStrings = true;
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + checkLevel2 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel2.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + checkLevel8 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel8.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + checkLevel9 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel9.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy16 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.OFF + "'", variableRenamingPolicy16.equals(com.google.javascript.jscomp.VariableRenamingPolicy.OFF));
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy18 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.HEURISTIC + "'", propertyRenamingPolicy18.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.HEURISTIC));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray13 = new com.google.javascript.rhino.Node[] { node4, node6, node8, node10, node12 };
        com.google.javascript.rhino.Node node14 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray13);
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node21 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray26 = new com.google.javascript.rhino.Node[] { node17, node19, node21, node23, node25 };
        com.google.javascript.rhino.Node node27 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray26);
        com.google.javascript.rhino.Node node28 = new com.google.javascript.rhino.Node(100, node14, node27);
        boolean boolean29 = closureCodingConvention0.isVarArgsParameter(node28);
        java.lang.String str30 = closureCodingConvention0.getExportPropertyFunction();
        boolean boolean33 = closureCodingConvention0.isExported("goog.exportProperty", false);
        com.google.javascript.rhino.Node node37 = com.google.javascript.rhino.Node.newNumber(100.0d, 4095, 9);
        java.util.Set<java.lang.String> strSet38 = node37.getDirectives();
        boolean boolean39 = closureCodingConvention0.isVarArgsParameter(node37);
        com.google.javascript.rhino.jstype.FunctionType functionType40 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType41 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType42 = null;
        closureCodingConvention0.applySubclassRelationship(functionType40, functionType41, subclassType42);
        boolean boolean46 = closureCodingConvention0.isExported("", false);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(nodeArray13);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNotNull(nodeArray26);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "goog.exportProperty" + "'", str30.equals("goog.exportProperty"));
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(node37);
        org.junit.Assert.assertNull(strSet38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile1 = com.google.javascript.jscomp.JSSourceFile.fromFile("language version");
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile1, true);
        org.junit.Assert.assertNotNull(jSSourceFile1);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.checkDuplicateMessages = false;
        boolean boolean3 = compilerOptions0.inlineAnonymousFunctionExpressions;
        compilerOptions0.recordFunctionInformation = true;
        boolean boolean6 = compilerOptions0.checkCaja;
        java.util.Set<java.lang.String> strSet7 = compilerOptions0.stripNamePrefixes;
        boolean boolean8 = compilerOptions0.collapseVariableDeclarations;
        boolean boolean9 = compilerOptions0.optimizeCalls;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(strSet7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray11 = new com.google.javascript.rhino.Node[] { node2, node4, node6, node8, node10 };
        com.google.javascript.rhino.Node node12 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray11);
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node15 = node12.copyInformationFrom(node14);
        com.google.javascript.rhino.Node node16 = node14.getLastSibling();
        node14.setIsSyntheticBlock(true);
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(nodeArray11);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertNotNull(node16);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile3 = com.google.javascript.jscomp.JSSourceFile.fromFile("Not declared as a constructor");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile5 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.CompilerInput compilerInput6 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile5);
        com.google.javascript.jscomp.CompilerInput compilerInput9 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput6, "hi!", false);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile11 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        compilerInput6.setSourceFile((com.google.javascript.jscomp.SourceFile) jSSourceFile11);
        java.lang.String str13 = jSSourceFile11.toString();
        com.google.javascript.jscomp.CompilerOptions compilerOptions14 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean15 = compilerOptions14.aliasAllStrings;
        compilerOptions14.setGenerateExports(true);
        com.google.javascript.jscomp.Result result18 = compiler1.compile(jSSourceFile3, jSSourceFile11, compilerOptions14);
        compilerOptions14.inlineLocalFunctions = true;
        compilerOptions14.devirtualizePrototypeMethods = true;
        byte[] byteArray23 = compilerOptions14.inputVariableMapSerialized;
        org.junit.Assert.assertNotNull(jSSourceFile3);
        org.junit.Assert.assertNotNull(jSSourceFile5);
        org.junit.Assert.assertNotNull(jSSourceFile11);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(result18);
        org.junit.Assert.assertNull(byteArray23);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile5 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.CompilerInput compilerInput6 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile5);
        com.google.javascript.jscomp.CompilerInput compilerInput9 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput6, "hi!", false);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile11 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        compilerInput6.setSourceFile((com.google.javascript.jscomp.SourceFile) jSSourceFile11);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile14 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray15 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile2, jSSourceFile11, jSSourceFile14 };
        java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList16 = new java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile>();
        boolean boolean17 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList16, jSSourceFileArray15);
        com.google.javascript.jscomp.JSModule[] jSModuleArray18 = new com.google.javascript.jscomp.JSModule[] {};
        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList19 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
        boolean boolean20 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList19, jSModuleArray18);
        com.google.javascript.jscomp.CompilerOptions compilerOptions21 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions21.checkDuplicateMessages = false;
        boolean boolean24 = compilerOptions21.inlineAnonymousFunctionExpressions;
        compilerOptions21.crossModuleMethodMotion = true;
        com.google.javascript.jscomp.Result result27 = compiler0.compileModules((java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList16, (java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList19, compilerOptions21);
        boolean boolean28 = compiler0.acceptEcmaScript5();
        com.google.javascript.jscomp.JSError[] jSErrorArray29 = compiler0.getMessages();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry30 = compiler0.getTypeRegistry();
        org.junit.Assert.assertNotNull(jSSourceFile2);
        org.junit.Assert.assertNotNull(jSSourceFile5);
        org.junit.Assert.assertNotNull(jSSourceFile11);
        org.junit.Assert.assertNotNull(jSSourceFile14);
        org.junit.Assert.assertNotNull(jSSourceFileArray15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(jSModuleArray18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(result27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(jSErrorArray29);
        org.junit.Assert.assertNotNull(jSTypeRegistry30);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        int int0 = com.google.javascript.rhino.Node.DIRECT_EVAL;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 48 + "'", int0 == 48);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.checkDuplicateMessages = false;
        boolean boolean3 = compilerOptions0.inlineAnonymousFunctionExpressions;
        java.lang.String str4 = compilerOptions0.checkMissingGetCssNameBlacklist;
        compilerOptions0.removeUnusedLocalVars = true;
        com.google.common.collect.Multimap<com.google.javascript.jscomp.CustomPassExecutionTime, com.google.javascript.jscomp.CompilerPass> customPassExecutionTimeMultimap7 = null;
        compilerOptions0.customPasses = customPassExecutionTimeMultimap7;
        compilerOptions0.lineLengthThreshold(12);
        boolean boolean11 = compilerOptions0.devirtualizePrototypeMethods;
        com.google.javascript.jscomp.CompilerOptions compilerOptions12 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel13 = compilerOptions12.brokenClosureRequiresLevel;
        com.google.javascript.jscomp.CheckLevel checkLevel14 = com.google.javascript.jscomp.CheckLevel.WARNING;
        compilerOptions12.checkGlobalNamesLevel = checkLevel14;
        com.google.javascript.jscomp.ErrorFormat errorFormat16 = null;
        compilerOptions12.errorFormat = errorFormat16;
        boolean boolean18 = compilerOptions12.ambiguateProperties;
        com.google.javascript.jscomp.CompilerOptions compilerOptions19 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel20 = compilerOptions19.brokenClosureRequiresLevel;
        com.google.javascript.jscomp.CheckLevel checkLevel21 = com.google.javascript.jscomp.CheckLevel.WARNING;
        compilerOptions19.checkGlobalNamesLevel = checkLevel21;
        compilerOptions19.computeFunctionSideEffects = true;
        boolean boolean25 = compilerOptions19.removeDeadCode;
        compilerOptions19.inlineVariables = true;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy28 = com.google.javascript.jscomp.VariableRenamingPolicy.OFF;
        compilerOptions19.variableRenaming = variableRenamingPolicy28;
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy30 = com.google.javascript.jscomp.PropertyRenamingPolicy.HEURISTIC;
        compilerOptions12.setRenamingPolicy(variableRenamingPolicy28, propertyRenamingPolicy30);
        compilerOptions0.variableRenaming = variableRenamingPolicy28;
        java.lang.String str33 = compilerOptions0.sourceMapOutputPath;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + checkLevel13 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel13.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + checkLevel14 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel14.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + checkLevel20 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel20.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + checkLevel21 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel21.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy28 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.OFF + "'", variableRenamingPolicy28.equals(com.google.javascript.jscomp.VariableRenamingPolicy.OFF));
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy30 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.HEURISTIC + "'", propertyRenamingPolicy30.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.HEURISTIC));
        org.junit.Assert.assertNull(str33);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.CHECK_USELESS_CODE;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray13 = new com.google.javascript.rhino.Node[] { node4, node6, node8, node10, node12 };
        com.google.javascript.rhino.Node node14 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray13);
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node21 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray26 = new com.google.javascript.rhino.Node[] { node17, node19, node21, node23, node25 };
        com.google.javascript.rhino.Node node27 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray26);
        com.google.javascript.rhino.Node node28 = new com.google.javascript.rhino.Node(100, node14, node27);
        boolean boolean29 = closureCodingConvention0.isVarArgsParameter(node28);
        java.lang.String str30 = closureCodingConvention0.getExportPropertyFunction();
        boolean boolean32 = closureCodingConvention0.isConstant("hi!");
        com.google.javascript.rhino.jstype.FunctionType functionType33 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType34 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType35 = null;
        closureCodingConvention0.applySubclassRelationship(functionType33, functionType34, subclassType35);
        com.google.javascript.rhino.Node node40 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node42 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node44 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node46 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node48 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray49 = new com.google.javascript.rhino.Node[] { node40, node42, node44, node46, node48 };
        com.google.javascript.rhino.Node node50 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray49);
        com.google.javascript.rhino.Node node52 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node53 = node50.copyInformationFrom(node52);
        com.google.javascript.rhino.Node node54 = node50.getParent();
        com.google.javascript.rhino.Node node55 = new com.google.javascript.rhino.Node((int) (short) -1, node50);
        boolean boolean56 = node50.wasEmptyNode();
        java.lang.String str57 = closureCodingConvention0.identifyTypeDefAssign(node50);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(nodeArray13);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNotNull(nodeArray26);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "goog.exportProperty" + "'", str30.equals("goog.exportProperty"));
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(node40);
        org.junit.Assert.assertNotNull(node42);
        org.junit.Assert.assertNotNull(node44);
        org.junit.Assert.assertNotNull(node46);
        org.junit.Assert.assertNotNull(node48);
        org.junit.Assert.assertNotNull(nodeArray49);
        org.junit.Assert.assertNotNull(node52);
        org.junit.Assert.assertNotNull(node53);
        org.junit.Assert.assertNull(node54);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertNull(str57);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray13 = new com.google.javascript.rhino.Node[] { node4, node6, node8, node10, node12 };
        com.google.javascript.rhino.Node node14 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray13);
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node21 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray26 = new com.google.javascript.rhino.Node[] { node17, node19, node21, node23, node25 };
        com.google.javascript.rhino.Node node27 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray26);
        com.google.javascript.rhino.Node node28 = new com.google.javascript.rhino.Node(100, node14, node27);
        boolean boolean29 = closureCodingConvention0.isVarArgsParameter(node28);
        java.lang.String str30 = closureCodingConvention0.getGlobalObject();
        com.google.javascript.rhino.Node node35 = com.google.javascript.rhino.Node.newNumber(100.0d, 4095, 9);
        java.util.Set<java.lang.String> strSet36 = node35.getDirectives();
        com.google.javascript.rhino.Node node39 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node41 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node43 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node45 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node47 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray48 = new com.google.javascript.rhino.Node[] { node39, node41, node43, node45, node47 };
        com.google.javascript.rhino.Node node49 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray48);
        com.google.javascript.rhino.Node node51 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node52 = node49.copyInformationFrom(node51);
        com.google.javascript.rhino.Node node55 = new com.google.javascript.rhino.Node(28, node35, node49, (-2), (int) (byte) -1);
        boolean boolean56 = node55.isNoSideEffectsCall();
        com.google.javascript.rhino.Node node60 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node62 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node64 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node66 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node68 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray69 = new com.google.javascript.rhino.Node[] { node60, node62, node64, node66, node68 };
        com.google.javascript.rhino.Node node70 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray69);
        com.google.javascript.rhino.Node node72 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node73 = node70.copyInformationFrom(node72);
        com.google.javascript.rhino.Node node74 = node70.getParent();
        com.google.javascript.rhino.Node node75 = new com.google.javascript.rhino.Node((int) (short) -1, node70);
        boolean boolean76 = node70.wasEmptyNode();
        com.google.javascript.rhino.Node node78 = node70.getAncestor(0);
        java.lang.String str79 = closureCodingConvention0.extractClassNameIfProvide(node55, node70);
        node70.setVarArgs(false);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(nodeArray13);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNotNull(nodeArray26);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "goog.global" + "'", str30.equals("goog.global"));
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertNull(strSet36);
        org.junit.Assert.assertNotNull(node39);
        org.junit.Assert.assertNotNull(node41);
        org.junit.Assert.assertNotNull(node43);
        org.junit.Assert.assertNotNull(node45);
        org.junit.Assert.assertNotNull(node47);
        org.junit.Assert.assertNotNull(nodeArray48);
        org.junit.Assert.assertNotNull(node51);
        org.junit.Assert.assertNotNull(node52);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertNotNull(node60);
        org.junit.Assert.assertNotNull(node62);
        org.junit.Assert.assertNotNull(node64);
        org.junit.Assert.assertNotNull(node66);
        org.junit.Assert.assertNotNull(node68);
        org.junit.Assert.assertNotNull(nodeArray69);
        org.junit.Assert.assertNotNull(node72);
        org.junit.Assert.assertNotNull(node73);
        org.junit.Assert.assertNull(node74);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
        org.junit.Assert.assertNotNull(node78);
        org.junit.Assert.assertNull(str79);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.checkDuplicateMessages = false;
        boolean boolean3 = compilerOptions0.inlineAnonymousFunctionExpressions;
        compilerOptions0.recordFunctionInformation = true;
        boolean boolean6 = compilerOptions0.checkCaja;
        com.google.javascript.jscomp.CheckLevel checkLevel7 = compilerOptions0.checkUndefinedProperties;
        compilerOptions0.ideMode = false;
        com.google.javascript.jscomp.CompilerOptions.TweakProcessing tweakProcessing10 = compilerOptions0.getTweakProcessing();
        compilerOptions0.inlineLocalFunctions = false;
        compilerOptions0.removeTryCatchFinally = true;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + checkLevel7 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel7.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + tweakProcessing10 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TweakProcessing.OFF + "'", tweakProcessing10.equals(com.google.javascript.jscomp.CompilerOptions.TweakProcessing.OFF));
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray12 = new com.google.javascript.rhino.Node[] { node3, node5, node7, node9, node11 };
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray12);
        int int14 = node13.getSideEffectFlags();
        com.google.javascript.rhino.Node node15 = node13.getNext();
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention16 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node22 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node24 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node26 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node28 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray29 = new com.google.javascript.rhino.Node[] { node20, node22, node24, node26, node28 };
        com.google.javascript.rhino.Node node30 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray29);
        com.google.javascript.rhino.Node node33 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node35 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node37 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node39 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node41 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray42 = new com.google.javascript.rhino.Node[] { node33, node35, node37, node39, node41 };
        com.google.javascript.rhino.Node node43 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray42);
        com.google.javascript.rhino.Node node44 = new com.google.javascript.rhino.Node(100, node30, node43);
        java.lang.String str45 = closureCodingConvention16.getSingletonGetterClassName(node44);
        node44.setWasEmptyNode(true);
        com.google.javascript.rhino.Node node51 = com.google.javascript.rhino.Node.newNumber(100.0d, 4095, 9);
        java.util.Set<java.lang.String> strSet52 = node51.getDirectives();
        com.google.javascript.rhino.Node node55 = new com.google.javascript.rhino.Node((int) (short) 0, node13, node44, node51, (int) (short) 10, (int) ' ');
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder56 = node51.getJsDocBuilderForNode();
        com.google.javascript.rhino.jstype.JSType jSType57 = null;
        node51.setJSType(jSType57);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertNotNull(nodeArray12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNull(node15);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertNotNull(nodeArray29);
        org.junit.Assert.assertNotNull(node33);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertNotNull(node37);
        org.junit.Assert.assertNotNull(node39);
        org.junit.Assert.assertNotNull(node41);
        org.junit.Assert.assertNotNull(nodeArray42);
        org.junit.Assert.assertNull(str45);
        org.junit.Assert.assertNotNull(node51);
        org.junit.Assert.assertNull(strSet52);
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder56);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        com.google.javascript.rhino.EcmaError ecmaError1 = com.google.javascript.rhino.ScriptRuntime.typeError("");
        java.lang.String str2 = ecmaError1.details();
        java.lang.String str3 = ecmaError1.getName();
        java.lang.String str4 = ecmaError1.sourceName();
        ecmaError1.initLineSource("");
        org.junit.Assert.assertNotNull(ecmaError1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "TypeError: " + "'", str2.equals("TypeError: "));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "TypeError" + "'", str3.equals("TypeError"));
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        int int0 = com.google.javascript.rhino.Context.FEATURE_PARENT_PROTO_PROPRTIES;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 5 + "'", int0 == 5);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        java.lang.Object[] objArray0 = com.google.javascript.rhino.ScriptRuntime.emptyArgs;
        org.junit.Assert.assertNotNull(objArray0);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.brokenClosureRequiresLevel;
        java.util.Set<java.lang.String> strSet2 = compilerOptions0.aliasableStrings;
        boolean boolean3 = compilerOptions0.decomposeExpressions;
        java.util.Set<java.lang.String> strSet4 = compilerOptions0.stripNamePrefixes;
        boolean boolean5 = compilerOptions0.instrumentForCoverageOnly;
        com.google.javascript.jscomp.CheckLevel checkLevel6 = compilerOptions0.checkMissingReturn;
        compilerOptions0.labelRenaming = false;
        compilerOptions0.instrumentationTemplate = "goog.exportSymbol";
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(strSet2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(strSet4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + checkLevel6 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel6.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.checkDuplicateMessages = false;
        compilerOptions0.tightenTypes = true;
        compilerOptions0.setNameAnonymousFunctionsOnly(false);
        boolean boolean7 = compilerOptions0.ideMode;
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.brokenClosureRequiresLevel;
        com.google.javascript.jscomp.CheckLevel checkLevel2 = com.google.javascript.jscomp.CheckLevel.WARNING;
        compilerOptions0.checkGlobalNamesLevel = checkLevel2;
        com.google.javascript.jscomp.ErrorFormat errorFormat4 = null;
        compilerOptions0.errorFormat = errorFormat4;
        boolean boolean6 = compilerOptions0.ambiguateProperties;
        com.google.javascript.jscomp.CompilerOptions compilerOptions7 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel8 = compilerOptions7.brokenClosureRequiresLevel;
        com.google.javascript.jscomp.CheckLevel checkLevel9 = com.google.javascript.jscomp.CheckLevel.WARNING;
        compilerOptions7.checkGlobalNamesLevel = checkLevel9;
        compilerOptions7.computeFunctionSideEffects = true;
        boolean boolean13 = compilerOptions7.removeDeadCode;
        compilerOptions7.inlineVariables = true;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy16 = com.google.javascript.jscomp.VariableRenamingPolicy.OFF;
        compilerOptions7.variableRenaming = variableRenamingPolicy16;
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy18 = com.google.javascript.jscomp.PropertyRenamingPolicy.HEURISTIC;
        compilerOptions0.setRenamingPolicy(variableRenamingPolicy16, propertyRenamingPolicy18);
        compilerOptions0.markNoSideEffectCalls = false;
        com.google.javascript.jscomp.CompilerOptions.TweakProcessing tweakProcessing22 = compilerOptions0.getTweakProcessing();
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + checkLevel2 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel2.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + checkLevel8 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel8.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + checkLevel9 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel9.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy16 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.OFF + "'", variableRenamingPolicy16.equals(com.google.javascript.jscomp.VariableRenamingPolicy.OFF));
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy18 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.HEURISTIC + "'", propertyRenamingPolicy18.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.HEURISTIC));
        org.junit.Assert.assertTrue("'" + tweakProcessing22 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TweakProcessing.OFF + "'", tweakProcessing22.equals(com.google.javascript.jscomp.CompilerOptions.TweakProcessing.OFF));
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.Compiler compiler2 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile4 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.CompilerInput compilerInput5 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile4);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile7 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.CompilerInput compilerInput8 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile7);
        com.google.javascript.jscomp.CompilerInput compilerInput11 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput8, "hi!", false);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile13 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        compilerInput8.setSourceFile((com.google.javascript.jscomp.SourceFile) jSSourceFile13);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile16 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray17 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile4, jSSourceFile13, jSSourceFile16 };
        java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList18 = new java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile>();
        boolean boolean19 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList18, jSSourceFileArray17);
        com.google.javascript.jscomp.JSModule[] jSModuleArray20 = new com.google.javascript.jscomp.JSModule[] {};
        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList21 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
        boolean boolean22 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList21, jSModuleArray20);
        com.google.javascript.jscomp.CompilerOptions compilerOptions23 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions23.checkDuplicateMessages = false;
        boolean boolean26 = compilerOptions23.inlineAnonymousFunctionExpressions;
        compilerOptions23.crossModuleMethodMotion = true;
        com.google.javascript.jscomp.Result result29 = compiler2.compileModules((java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList18, (java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList21, compilerOptions23);
        com.google.javascript.jscomp.Compiler compiler30 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile32 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.CompilerInput compilerInput33 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile32);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile35 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.CompilerInput compilerInput36 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile35);
        com.google.javascript.jscomp.CompilerInput compilerInput39 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput36, "hi!", false);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile41 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        compilerInput36.setSourceFile((com.google.javascript.jscomp.SourceFile) jSSourceFile41);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile44 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray45 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile32, jSSourceFile41, jSSourceFile44 };
        java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList46 = new java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile>();
        boolean boolean47 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList46, jSSourceFileArray45);
        com.google.javascript.jscomp.JSModule[] jSModuleArray48 = new com.google.javascript.jscomp.JSModule[] {};
        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList49 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
        boolean boolean50 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList49, jSModuleArray48);
        com.google.javascript.jscomp.CompilerOptions compilerOptions51 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions51.checkDuplicateMessages = false;
        boolean boolean54 = compilerOptions51.inlineAnonymousFunctionExpressions;
        compilerOptions51.crossModuleMethodMotion = true;
        com.google.javascript.jscomp.Result result57 = compiler30.compileModules((java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList46, (java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList49, compilerOptions51);
        com.google.javascript.jscomp.CompilerOptions compilerOptions58 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel59 = compilerOptions58.brokenClosureRequiresLevel;
        java.util.Set<java.lang.String> strSet60 = compilerOptions58.aliasableStrings;
        boolean boolean61 = compilerOptions58.decomposeExpressions;
        java.util.Set<java.lang.String> strSet62 = compilerOptions58.stripNamePrefixes;
        com.google.javascript.jscomp.Result result63 = compiler1.compile((java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList18, (java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList46, compilerOptions58);
        com.google.javascript.jscomp.PerformanceTracker performanceTracker64 = compiler1.tracker;
        com.google.javascript.rhino.Node node65 = compiler1.getRoot();
        org.junit.Assert.assertNotNull(jSSourceFile4);
        org.junit.Assert.assertNotNull(jSSourceFile7);
        org.junit.Assert.assertNotNull(jSSourceFile13);
        org.junit.Assert.assertNotNull(jSSourceFile16);
        org.junit.Assert.assertNotNull(jSSourceFileArray17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(jSModuleArray20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(result29);
        org.junit.Assert.assertNotNull(jSSourceFile32);
        org.junit.Assert.assertNotNull(jSSourceFile35);
        org.junit.Assert.assertNotNull(jSSourceFile41);
        org.junit.Assert.assertNotNull(jSSourceFile44);
        org.junit.Assert.assertNotNull(jSSourceFileArray45);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
        org.junit.Assert.assertNotNull(jSModuleArray48);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNotNull(result57);
        org.junit.Assert.assertTrue("'" + checkLevel59 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel59.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(strSet60);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertNotNull(strSet62);
        org.junit.Assert.assertNotNull(result63);
        org.junit.Assert.assertNull(performanceTracker64);
        org.junit.Assert.assertNull(node65);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        java.lang.String str1 = com.google.javascript.rhino.Node.tokenToName(3);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "leavewith" + "'", str1.equals("leavewith"));
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        com.google.javascript.jscomp.parsing.Config.LanguageMode languageMode0 = com.google.javascript.jscomp.parsing.Config.LanguageMode.ECMASCRIPT3;
        org.junit.Assert.assertTrue("'" + languageMode0 + "' != '" + com.google.javascript.jscomp.parsing.Config.LanguageMode.ECMASCRIPT3 + "'", languageMode0.equals(com.google.javascript.jscomp.parsing.Config.LanguageMode.ECMASCRIPT3));
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.brokenClosureRequiresLevel;
        java.util.Set<java.lang.String> strSet2 = compilerOptions0.aliasableStrings;
        boolean boolean3 = compilerOptions0.decomposeExpressions;
        java.util.Set<java.lang.String> strSet4 = compilerOptions0.stripNamePrefixes;
        boolean boolean5 = compilerOptions0.instrumentForCoverageOnly;
        com.google.javascript.jscomp.CheckLevel checkLevel6 = compilerOptions0.checkMissingReturn;
        compilerOptions0.inlineConstantVars = true;
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(strSet2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(strSet4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + checkLevel6 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel6.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray13 = new com.google.javascript.rhino.Node[] { node4, node6, node8, node10, node12 };
        com.google.javascript.rhino.Node node14 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray13);
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node21 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray26 = new com.google.javascript.rhino.Node[] { node17, node19, node21, node23, node25 };
        com.google.javascript.rhino.Node node27 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray26);
        com.google.javascript.rhino.Node node28 = new com.google.javascript.rhino.Node(100, node14, node27);
        com.google.javascript.rhino.Node node32 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node34 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node36 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node38 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node40 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray41 = new com.google.javascript.rhino.Node[] { node32, node34, node36, node38, node40 };
        com.google.javascript.rhino.Node node42 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray41);
        com.google.javascript.rhino.Node node45 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node47 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node49 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node51 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node53 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray54 = new com.google.javascript.rhino.Node[] { node45, node47, node49, node51, node53 };
        com.google.javascript.rhino.Node node55 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray54);
        com.google.javascript.rhino.Node node56 = new com.google.javascript.rhino.Node(100, node42, node55);
        com.google.javascript.rhino.Node node57 = null;
        try {
            com.google.javascript.rhino.Node node60 = new com.google.javascript.rhino.Node(18, node14, node56, node57, 2, 17);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(nodeArray13);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNotNull(nodeArray26);
        org.junit.Assert.assertNotNull(node32);
        org.junit.Assert.assertNotNull(node34);
        org.junit.Assert.assertNotNull(node36);
        org.junit.Assert.assertNotNull(node38);
        org.junit.Assert.assertNotNull(node40);
        org.junit.Assert.assertNotNull(nodeArray41);
        org.junit.Assert.assertNotNull(node45);
        org.junit.Assert.assertNotNull(node47);
        org.junit.Assert.assertNotNull(node49);
        org.junit.Assert.assertNotNull(node51);
        org.junit.Assert.assertNotNull(node53);
        org.junit.Assert.assertNotNull(nodeArray54);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray13 = new com.google.javascript.rhino.Node[] { node4, node6, node8, node10, node12 };
        com.google.javascript.rhino.Node node14 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray13);
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node21 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray26 = new com.google.javascript.rhino.Node[] { node17, node19, node21, node23, node25 };
        com.google.javascript.rhino.Node node27 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray26);
        com.google.javascript.rhino.Node node28 = new com.google.javascript.rhino.Node(100, node14, node27);
        java.lang.String str29 = closureCodingConvention0.getSingletonGetterClassName(node28);
        boolean boolean30 = node28.isNoSideEffectsCall();
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(nodeArray13);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNotNull(nodeArray26);
        org.junit.Assert.assertNull(str29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.brokenClosureRequiresLevel;
        com.google.javascript.jscomp.CheckLevel checkLevel2 = com.google.javascript.jscomp.CheckLevel.WARNING;
        compilerOptions0.checkGlobalNamesLevel = checkLevel2;
        compilerOptions0.computeFunctionSideEffects = true;
        boolean boolean6 = compilerOptions0.removeDeadCode;
        com.google.javascript.jscomp.CompilerOptions.TweakProcessing tweakProcessing7 = compilerOptions0.getTweakProcessing();
        com.google.javascript.jscomp.CompilerOptions compilerOptions8 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel9 = compilerOptions8.brokenClosureRequiresLevel;
        com.google.javascript.jscomp.CheckLevel checkLevel10 = com.google.javascript.jscomp.CheckLevel.WARNING;
        compilerOptions8.checkGlobalNamesLevel = checkLevel10;
        compilerOptions8.computeFunctionSideEffects = true;
        compilerOptions8.closurePass = false;
        com.google.javascript.jscomp.ErrorFormat errorFormat16 = compilerOptions8.errorFormat;
        compilerOptions8.prettyPrint = false;
        com.google.javascript.jscomp.CheckLevel checkLevel19 = com.google.javascript.jscomp.CheckLevel.ERROR;
        compilerOptions8.reportMissingOverride = checkLevel19;
        compilerOptions0.checkFunctions = checkLevel19;
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + checkLevel2 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel2.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + tweakProcessing7 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TweakProcessing.OFF + "'", tweakProcessing7.equals(com.google.javascript.jscomp.CompilerOptions.TweakProcessing.OFF));
        org.junit.Assert.assertTrue("'" + checkLevel9 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel9.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + checkLevel10 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel10.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
        org.junit.Assert.assertNotNull(errorFormat16);
        org.junit.Assert.assertTrue("'" + checkLevel19 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel19.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.NodeTraversal.Callback callback1 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal2 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler0, callback1);
        compiler0.disableThreads();
        try {
            com.google.javascript.jscomp.JSError[] jSErrorArray4 = compiler0.getWarnings();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.checkDuplicateMessages = false;
        boolean boolean3 = compilerOptions0.inlineAnonymousFunctionExpressions;
        java.lang.String str4 = compilerOptions0.checkMissingGetCssNameBlacklist;
        compilerOptions0.removeUnusedLocalVars = true;
        com.google.common.collect.Multimap<com.google.javascript.jscomp.CustomPassExecutionTime, com.google.javascript.jscomp.CompilerPass> customPassExecutionTimeMultimap7 = null;
        compilerOptions0.customPasses = customPassExecutionTimeMultimap7;
        compilerOptions0.lineLengthThreshold(12);
        compilerOptions0.renamePrefix = "Not declared as a constructor";
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.brokenClosureRequiresLevel;
        com.google.javascript.jscomp.CheckLevel checkLevel2 = com.google.javascript.jscomp.CheckLevel.WARNING;
        compilerOptions0.checkGlobalNamesLevel = checkLevel2;
        compilerOptions0.computeFunctionSideEffects = true;
        compilerOptions0.setDefineToStringLiteral("", "Unknown class name");
        java.lang.String str9 = compilerOptions0.aliasableGlobals;
        compilerOptions0.instrumentForCoverage = true;
        compilerOptions0.checkDuplicateMessages = false;
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + checkLevel2 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel2.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
        org.junit.Assert.assertNull(str9);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile5 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.CompilerInput compilerInput6 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile5);
        com.google.javascript.jscomp.CompilerInput compilerInput9 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput6, "hi!", false);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile11 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        compilerInput6.setSourceFile((com.google.javascript.jscomp.SourceFile) jSSourceFile11);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile14 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray15 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile2, jSSourceFile11, jSSourceFile14 };
        java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList16 = new java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile>();
        boolean boolean17 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList16, jSSourceFileArray15);
        com.google.javascript.jscomp.JSModule[] jSModuleArray18 = new com.google.javascript.jscomp.JSModule[] {};
        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList19 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
        boolean boolean20 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList19, jSModuleArray18);
        com.google.javascript.jscomp.CompilerOptions compilerOptions21 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions21.checkDuplicateMessages = false;
        boolean boolean24 = compilerOptions21.inlineAnonymousFunctionExpressions;
        compilerOptions21.crossModuleMethodMotion = true;
        com.google.javascript.jscomp.Result result27 = compiler0.compileModules((java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList16, (java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList19, compilerOptions21);
        boolean boolean28 = compiler0.acceptEcmaScript5();
        try {
            compiler0.check();
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: INTERNAL COMPILER ERROR.\nPlease report this problem.\nnull");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile2);
        org.junit.Assert.assertNotNull(jSSourceFile5);
        org.junit.Assert.assertNotNull(jSSourceFile11);
        org.junit.Assert.assertNotNull(jSSourceFile14);
        org.junit.Assert.assertNotNull(jSSourceFileArray15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(jSModuleArray18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(result27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        com.google.javascript.jscomp.AbstractCompiler abstractCompiler0 = null;
        com.google.javascript.jscomp.NodeTraversal.Callback callback1 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal2 = new com.google.javascript.jscomp.NodeTraversal(abstractCompiler0, callback1);
        boolean boolean3 = nodeTraversal2.hasScope();
        java.lang.String str4 = nodeTraversal2.getSourceName();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.brokenClosureRequiresLevel;
        com.google.javascript.jscomp.CheckLevel checkLevel2 = com.google.javascript.jscomp.CheckLevel.WARNING;
        compilerOptions0.checkGlobalNamesLevel = checkLevel2;
        compilerOptions0.computeFunctionSideEffects = true;
        boolean boolean6 = compilerOptions0.removeDeadCode;
        compilerOptions0.setManageClosureDependencies(false);
        compilerOptions0.nameReferenceGraphPath = "";
        java.lang.String str11 = compilerOptions0.syntheticBlockStartMarker;
        compilerOptions0.instrumentationTemplate = "TypeError: ";
        compilerOptions0.allowLegacyJsMessages = false;
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + checkLevel2 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel2.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(str11);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        boolean boolean1 = com.google.javascript.rhino.Context.isValidLanguageVersion(0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.brokenClosureRequiresLevel;
        boolean boolean2 = compilerOptions0.groupVariableDeclarations;
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray13 = new com.google.javascript.rhino.Node[] { node4, node6, node8, node10, node12 };
        com.google.javascript.rhino.Node node14 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray13);
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node21 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray26 = new com.google.javascript.rhino.Node[] { node17, node19, node21, node23, node25 };
        com.google.javascript.rhino.Node node27 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray26);
        com.google.javascript.rhino.Node node28 = new com.google.javascript.rhino.Node(100, node14, node27);
        boolean boolean29 = closureCodingConvention0.isVarArgsParameter(node28);
        java.lang.String str30 = closureCodingConvention0.getGlobalObject();
        com.google.javascript.rhino.Node node35 = com.google.javascript.rhino.Node.newNumber(100.0d, 4095, 9);
        java.util.Set<java.lang.String> strSet36 = node35.getDirectives();
        com.google.javascript.rhino.Node node39 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node41 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node43 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node45 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node47 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray48 = new com.google.javascript.rhino.Node[] { node39, node41, node43, node45, node47 };
        com.google.javascript.rhino.Node node49 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray48);
        com.google.javascript.rhino.Node node51 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node52 = node49.copyInformationFrom(node51);
        com.google.javascript.rhino.Node node55 = new com.google.javascript.rhino.Node(28, node35, node49, (-2), (int) (byte) -1);
        boolean boolean56 = node55.isNoSideEffectsCall();
        com.google.javascript.rhino.Node node60 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node62 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node64 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node66 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node68 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray69 = new com.google.javascript.rhino.Node[] { node60, node62, node64, node66, node68 };
        com.google.javascript.rhino.Node node70 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray69);
        com.google.javascript.rhino.Node node72 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node73 = node70.copyInformationFrom(node72);
        com.google.javascript.rhino.Node node74 = node70.getParent();
        com.google.javascript.rhino.Node node75 = new com.google.javascript.rhino.Node((int) (short) -1, node70);
        boolean boolean76 = node70.wasEmptyNode();
        com.google.javascript.rhino.Node node78 = node70.getAncestor(0);
        java.lang.String str79 = closureCodingConvention0.extractClassNameIfProvide(node55, node70);
        com.google.javascript.rhino.Node node82 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node84 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node86 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node88 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node90 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray91 = new com.google.javascript.rhino.Node[] { node82, node84, node86, node88, node90 };
        com.google.javascript.rhino.Node node92 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray91);
        com.google.javascript.rhino.Node node94 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node95 = node92.copyInformationFrom(node94);
        com.google.javascript.rhino.Node node96 = node55.copyInformationFromForTree(node92);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(nodeArray13);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNotNull(nodeArray26);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "goog.global" + "'", str30.equals("goog.global"));
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertNull(strSet36);
        org.junit.Assert.assertNotNull(node39);
        org.junit.Assert.assertNotNull(node41);
        org.junit.Assert.assertNotNull(node43);
        org.junit.Assert.assertNotNull(node45);
        org.junit.Assert.assertNotNull(node47);
        org.junit.Assert.assertNotNull(nodeArray48);
        org.junit.Assert.assertNotNull(node51);
        org.junit.Assert.assertNotNull(node52);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertNotNull(node60);
        org.junit.Assert.assertNotNull(node62);
        org.junit.Assert.assertNotNull(node64);
        org.junit.Assert.assertNotNull(node66);
        org.junit.Assert.assertNotNull(node68);
        org.junit.Assert.assertNotNull(nodeArray69);
        org.junit.Assert.assertNotNull(node72);
        org.junit.Assert.assertNotNull(node73);
        org.junit.Assert.assertNull(node74);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
        org.junit.Assert.assertNotNull(node78);
        org.junit.Assert.assertNull(str79);
        org.junit.Assert.assertNotNull(node82);
        org.junit.Assert.assertNotNull(node84);
        org.junit.Assert.assertNotNull(node86);
        org.junit.Assert.assertNotNull(node88);
        org.junit.Assert.assertNotNull(node90);
        org.junit.Assert.assertNotNull(nodeArray91);
        org.junit.Assert.assertNotNull(node94);
        org.junit.Assert.assertNotNull(node95);
        org.junit.Assert.assertNotNull(node96);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.checkDuplicateMessages = false;
        boolean boolean3 = compilerOptions0.inlineAnonymousFunctionExpressions;
        compilerOptions0.recordFunctionInformation = true;
        boolean boolean6 = compilerOptions0.checkCaja;
        compilerOptions0.aliasableGlobals = "EOF 0";
        boolean boolean9 = compilerOptions0.removeEmptyFunctions;
        boolean boolean10 = compilerOptions0.deadAssignmentElimination;
        java.lang.String str11 = compilerOptions0.inputDelimiter;
        boolean boolean12 = compilerOptions0.crossModuleCodeMotion;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "// Input %num%" + "'", str11.equals("// Input %num%"));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        com.google.javascript.jscomp.JSModule jSModule0 = null;
        com.google.javascript.jscomp.JSModule[] jSModuleArray1 = new com.google.javascript.jscomp.JSModule[] { jSModule0 };
        try {
            com.google.javascript.jscomp.JSModuleGraph jSModuleGraph2 = new com.google.javascript.jscomp.JSModuleGraph(jSModuleArray1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jSModuleArray1);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.brokenClosureRequiresLevel;
        com.google.javascript.jscomp.CheckLevel checkLevel2 = com.google.javascript.jscomp.CheckLevel.WARNING;
        compilerOptions0.checkGlobalNamesLevel = checkLevel2;
        compilerOptions0.computeFunctionSideEffects = true;
        boolean boolean6 = compilerOptions0.removeDeadCode;
        compilerOptions0.setManageClosureDependencies(false);
        boolean boolean9 = compilerOptions0.optimizeParameters;
        compilerOptions0.setShadowVariables(true);
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + checkLevel2 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel2.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        com.google.javascript.rhino.Node.SideEffectFlags sideEffectFlags1 = new com.google.javascript.rhino.Node.SideEffectFlags(130);
        sideEffectFlags1.setMutatesGlobalState();
        sideEffectFlags1.clearSideEffectFlags();
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        int int0 = com.google.javascript.rhino.Node.SPECIALCALL_EVAL;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

//    @Test
//    public void test441() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test441");
//        com.google.javascript.rhino.Context context0 = com.google.javascript.rhino.Context.enter();
//        boolean boolean1 = context0.isGeneratingSource();
//        com.google.javascript.rhino.ErrorReporter errorReporter2 = context0.getErrorReporter();
//        com.google.javascript.rhino.ErrorReporter errorReporter3 = context0.getErrorReporter();
//        boolean boolean5 = context0.isActivationNeeded("com.google.javascript.rhino.EcmaError: TypeError: -1 is not a function, it is java.lang.Byte.");
//        try {
//            context0.setInstructionObserverThreshold((-2));
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(context0);
//        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
//        org.junit.Assert.assertNull(errorReporter2);
//        org.junit.Assert.assertNull(errorReporter3);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile1 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.CompilerInput compilerInput2 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile1);
        com.google.javascript.jscomp.CompilerInput compilerInput5 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput2, "hi!", false);
        com.google.javascript.jscomp.SourceFile sourceFile6 = compilerInput2.getSourceFile();
        org.junit.Assert.assertNotNull(jSSourceFile1);
        org.junit.Assert.assertNotNull(sourceFile6);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray13 = new com.google.javascript.rhino.Node[] { node4, node6, node8, node10, node12 };
        com.google.javascript.rhino.Node node14 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray13);
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node21 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray26 = new com.google.javascript.rhino.Node[] { node17, node19, node21, node23, node25 };
        com.google.javascript.rhino.Node node27 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray26);
        com.google.javascript.rhino.Node node28 = new com.google.javascript.rhino.Node(100, node14, node27);
        boolean boolean29 = closureCodingConvention0.isVarArgsParameter(node28);
        java.lang.String str30 = closureCodingConvention0.getExportPropertyFunction();
        boolean boolean33 = closureCodingConvention0.isExported("goog.exportProperty", false);
        com.google.javascript.rhino.Node node37 = com.google.javascript.rhino.Node.newNumber(100.0d, 4095, 9);
        java.util.Set<java.lang.String> strSet38 = node37.getDirectives();
        boolean boolean39 = closureCodingConvention0.isVarArgsParameter(node37);
        com.google.javascript.rhino.Node node42 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node44 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node46 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node48 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node50 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray51 = new com.google.javascript.rhino.Node[] { node42, node44, node46, node48, node50 };
        com.google.javascript.rhino.Node node52 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray51);
        com.google.javascript.rhino.Node node53 = node52.getNext();
        com.google.javascript.rhino.Node node57 = com.google.javascript.rhino.Node.newNumber(100.0d, 4095, 9);
        java.lang.String str58 = closureCodingConvention0.extractClassNameIfRequire(node52, node57);
        com.google.javascript.rhino.jstype.FunctionType functionType59 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType60 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType61 = null;
        closureCodingConvention0.applySubclassRelationship(functionType59, functionType60, subclassType61);
        com.google.javascript.rhino.Node node63 = null;
        try {
            java.util.List<java.lang.String> strList64 = closureCodingConvention0.identifyTypeDeclarationCall(node63);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(nodeArray13);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNotNull(nodeArray26);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "goog.exportProperty" + "'", str30.equals("goog.exportProperty"));
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(node37);
        org.junit.Assert.assertNull(strSet38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(node42);
        org.junit.Assert.assertNotNull(node44);
        org.junit.Assert.assertNotNull(node46);
        org.junit.Assert.assertNotNull(node48);
        org.junit.Assert.assertNotNull(node50);
        org.junit.Assert.assertNotNull(nodeArray51);
        org.junit.Assert.assertNull(node53);
        org.junit.Assert.assertNotNull(node57);
        org.junit.Assert.assertNull(str58);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.checkDuplicateMessages = false;
        boolean boolean3 = compilerOptions0.inlineAnonymousFunctionExpressions;
        compilerOptions0.recordFunctionInformation = true;
        boolean boolean6 = compilerOptions0.checkCaja;
        compilerOptions0.aliasableGlobals = "EOF 0";
        com.google.javascript.jscomp.CheckLevel checkLevel9 = com.google.javascript.jscomp.CheckLevel.OFF;
        compilerOptions0.reportUnknownTypes = checkLevel9;
        boolean boolean11 = compilerOptions0.devirtualizePrototypeMethods;
        compilerOptions0.rewriteFunctionExpressions = true;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + checkLevel9 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel9.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.brokenClosureRequiresLevel;
        com.google.javascript.jscomp.CheckLevel checkLevel2 = com.google.javascript.jscomp.CheckLevel.WARNING;
        compilerOptions0.checkGlobalNamesLevel = checkLevel2;
        java.lang.String str4 = compilerOptions0.instrumentationTemplate;
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + checkLevel2 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel2.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.brokenClosureRequiresLevel;
        java.util.Set<java.lang.String> strSet2 = compilerOptions0.aliasableStrings;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy3 = com.google.javascript.jscomp.VariableRenamingPolicy.OFF;
        compilerOptions0.variableRenaming = variableRenamingPolicy3;
        compilerOptions0.crossModuleCodeMotion = false;
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(strSet2);
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy3 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.OFF + "'", variableRenamingPolicy3.equals(com.google.javascript.jscomp.VariableRenamingPolicy.OFF));
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.brokenClosureRequiresLevel;
        com.google.javascript.jscomp.CheckLevel checkLevel2 = com.google.javascript.jscomp.CheckLevel.WARNING;
        compilerOptions0.checkGlobalNamesLevel = checkLevel2;
        compilerOptions0.computeFunctionSideEffects = true;
        boolean boolean6 = compilerOptions0.removeDeadCode;
        compilerOptions0.inlineVariables = true;
        boolean boolean9 = compilerOptions0.removeDeadCode;
        compilerOptions0.closurePass = true;
        com.google.javascript.jscomp.CompilerOptions compilerOptions12 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions12.checkDuplicateMessages = false;
        boolean boolean15 = compilerOptions12.inlineAnonymousFunctionExpressions;
        compilerOptions12.recordFunctionInformation = true;
        boolean boolean18 = compilerOptions12.checkCaja;
        compilerOptions12.aliasableGlobals = "EOF 0";
        com.google.javascript.jscomp.CheckLevel checkLevel21 = com.google.javascript.jscomp.CheckLevel.OFF;
        compilerOptions12.reportUnknownTypes = checkLevel21;
        com.google.javascript.jscomp.CompilerOptions compilerOptions23 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions23.checkDuplicateMessages = false;
        boolean boolean26 = compilerOptions23.inlineAnonymousFunctionExpressions;
        compilerOptions23.recordFunctionInformation = true;
        boolean boolean29 = compilerOptions23.checkCaja;
        java.util.Set<java.lang.String> strSet30 = compilerOptions23.stripNamePrefixes;
        compilerOptions12.setIdGenerators(strSet30);
        compilerOptions0.stripTypes = strSet30;
        com.google.javascript.jscomp.CompilerOptions compilerOptions33 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions33.checkDuplicateMessages = false;
        boolean boolean36 = compilerOptions33.inlineAnonymousFunctionExpressions;
        compilerOptions33.recordFunctionInformation = true;
        boolean boolean39 = compilerOptions33.checkCaja;
        compilerOptions33.aliasableGlobals = "EOF 0";
        com.google.javascript.jscomp.CheckLevel checkLevel42 = com.google.javascript.jscomp.CheckLevel.OFF;
        compilerOptions33.reportUnknownTypes = checkLevel42;
        com.google.javascript.jscomp.CompilerOptions compilerOptions44 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions44.checkDuplicateMessages = false;
        boolean boolean47 = compilerOptions44.inlineAnonymousFunctionExpressions;
        compilerOptions44.recordFunctionInformation = true;
        boolean boolean50 = compilerOptions44.checkCaja;
        java.util.Set<java.lang.String> strSet51 = compilerOptions44.stripNamePrefixes;
        compilerOptions33.setIdGenerators(strSet51);
        compilerOptions0.stripTypePrefixes = strSet51;
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + checkLevel2 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel2.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + checkLevel21 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel21.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(strSet30);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + checkLevel42 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel42.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(strSet51);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        int int0 = com.google.javascript.rhino.Node.LOCALCOUNT_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 21 + "'", int0 == 21);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        com.google.javascript.jscomp.MessageFormatter messageFormatter0 = null;
        java.util.logging.Logger logger1 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager2 = new com.google.javascript.jscomp.LoggerErrorManager(messageFormatter0, logger1);
        com.google.javascript.jscomp.Compiler compiler3 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager2);
        com.google.javascript.jscomp.PassConfig passConfig4 = null;
        try {
            compiler3.setPassConfig(passConfig4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.brokenClosureRequiresLevel;
        com.google.javascript.jscomp.CheckLevel checkLevel2 = com.google.javascript.jscomp.CheckLevel.WARNING;
        compilerOptions0.checkGlobalNamesLevel = checkLevel2;
        compilerOptions0.computeFunctionSideEffects = true;
        compilerOptions0.setShadowVariables(true);
        compilerOptions0.debugFunctionSideEffectsPath = "goog.global";
        java.lang.String str10 = compilerOptions0.inputDelimiter;
        boolean boolean11 = compilerOptions0.inlineConstantVars;
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + checkLevel2 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel2.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "// Input %num%" + "'", str10.equals("// Input %num%"));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.brokenClosureRequiresLevel;
        com.google.javascript.jscomp.CheckLevel checkLevel2 = com.google.javascript.jscomp.CheckLevel.WARNING;
        compilerOptions0.checkGlobalNamesLevel = checkLevel2;
        compilerOptions0.renamePrefix = "hi!";
        compilerOptions0.instrumentForCoverageOnly = true;
        boolean boolean8 = compilerOptions0.recordFunctionInformation;
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + checkLevel2 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel2.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        int int0 = com.google.javascript.rhino.Node.COLUMN_BITS;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 12 + "'", int0 == 12);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray13 = new com.google.javascript.rhino.Node[] { node4, node6, node8, node10, node12 };
        com.google.javascript.rhino.Node node14 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray13);
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node21 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray26 = new com.google.javascript.rhino.Node[] { node17, node19, node21, node23, node25 };
        com.google.javascript.rhino.Node node27 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray26);
        com.google.javascript.rhino.Node node28 = new com.google.javascript.rhino.Node(100, node14, node27);
        java.lang.String str29 = closureCodingConvention0.getSingletonGetterClassName(node28);
        com.google.javascript.rhino.Node node35 = com.google.javascript.rhino.Node.newString((int) (short) 0, "hi!", 100, (-2));
        com.google.javascript.rhino.Node node36 = new com.google.javascript.rhino.Node(10, node35);
        java.lang.String str37 = closureCodingConvention0.identifyTypeDefAssign(node36);
        com.google.javascript.rhino.Node node38 = node36.cloneNode();
        node36.removeProp(44);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(nodeArray13);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNotNull(nodeArray26);
        org.junit.Assert.assertNull(str29);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertNull(str37);
        org.junit.Assert.assertNotNull(node38);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        int int0 = com.google.javascript.rhino.Context.VERSION_1_5;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 150 + "'", int0 == 150);
    }

//    @Test
//    public void test455() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test455");
//        com.google.javascript.rhino.Context context0 = com.google.javascript.rhino.Context.enter();
//        com.google.javascript.rhino.ScriptRuntime.storeUint32Result(context0, (long) (short) 10);
//        java.beans.PropertyChangeListener propertyChangeListener3 = null;
//        try {
//            context0.addPropertyChangeListener(propertyChangeListener3);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(context0);
//    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray12 = new com.google.javascript.rhino.Node[] { node3, node5, node7, node9, node11 };
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray12);
        int int14 = node13.getSideEffectFlags();
        com.google.javascript.rhino.Node node15 = node13.getNext();
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention16 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node22 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node24 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node26 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node28 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray29 = new com.google.javascript.rhino.Node[] { node20, node22, node24, node26, node28 };
        com.google.javascript.rhino.Node node30 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray29);
        com.google.javascript.rhino.Node node33 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node35 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node37 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node39 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node41 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray42 = new com.google.javascript.rhino.Node[] { node33, node35, node37, node39, node41 };
        com.google.javascript.rhino.Node node43 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray42);
        com.google.javascript.rhino.Node node44 = new com.google.javascript.rhino.Node(100, node30, node43);
        java.lang.String str45 = closureCodingConvention16.getSingletonGetterClassName(node44);
        node44.setWasEmptyNode(true);
        com.google.javascript.rhino.Node node51 = com.google.javascript.rhino.Node.newNumber(100.0d, 4095, 9);
        java.util.Set<java.lang.String> strSet52 = node51.getDirectives();
        com.google.javascript.rhino.Node node55 = new com.google.javascript.rhino.Node((int) (short) 0, node13, node44, node51, (int) (short) 10, (int) ' ');
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder56 = node51.getJsDocBuilderForNode();
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention57 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node61 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node63 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node65 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node67 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node69 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray70 = new com.google.javascript.rhino.Node[] { node61, node63, node65, node67, node69 };
        com.google.javascript.rhino.Node node71 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray70);
        com.google.javascript.rhino.Node node74 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node76 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node78 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node80 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node82 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray83 = new com.google.javascript.rhino.Node[] { node74, node76, node78, node80, node82 };
        com.google.javascript.rhino.Node node84 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray83);
        com.google.javascript.rhino.Node node85 = new com.google.javascript.rhino.Node(100, node71, node84);
        boolean boolean86 = closureCodingConvention57.isVarArgsParameter(node85);
        java.lang.String str87 = closureCodingConvention57.getExportPropertyFunction();
        boolean boolean90 = closureCodingConvention57.isExported("goog.exportProperty", false);
        com.google.javascript.rhino.Node node94 = com.google.javascript.rhino.Node.newNumber(100.0d, 4095, 9);
        java.util.Set<java.lang.String> strSet95 = node94.getDirectives();
        boolean boolean96 = closureCodingConvention57.isVarArgsParameter(node94);
        com.google.javascript.rhino.Node node97 = node51.copyInformationFromForTree(node94);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertNotNull(nodeArray12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNull(node15);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertNotNull(nodeArray29);
        org.junit.Assert.assertNotNull(node33);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertNotNull(node37);
        org.junit.Assert.assertNotNull(node39);
        org.junit.Assert.assertNotNull(node41);
        org.junit.Assert.assertNotNull(nodeArray42);
        org.junit.Assert.assertNull(str45);
        org.junit.Assert.assertNotNull(node51);
        org.junit.Assert.assertNull(strSet52);
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder56);
        org.junit.Assert.assertNotNull(node61);
        org.junit.Assert.assertNotNull(node63);
        org.junit.Assert.assertNotNull(node65);
        org.junit.Assert.assertNotNull(node67);
        org.junit.Assert.assertNotNull(node69);
        org.junit.Assert.assertNotNull(nodeArray70);
        org.junit.Assert.assertNotNull(node74);
        org.junit.Assert.assertNotNull(node76);
        org.junit.Assert.assertNotNull(node78);
        org.junit.Assert.assertNotNull(node80);
        org.junit.Assert.assertNotNull(node82);
        org.junit.Assert.assertNotNull(nodeArray83);
        org.junit.Assert.assertTrue("'" + boolean86 + "' != '" + false + "'", boolean86 == false);
        org.junit.Assert.assertTrue("'" + str87 + "' != '" + "goog.exportProperty" + "'", str87.equals("goog.exportProperty"));
        org.junit.Assert.assertTrue("'" + boolean90 + "' != '" + false + "'", boolean90 == false);
        org.junit.Assert.assertNotNull(node94);
        org.junit.Assert.assertNull(strSet95);
        org.junit.Assert.assertTrue("'" + boolean96 + "' != '" + false + "'", boolean96 == false);
        org.junit.Assert.assertNotNull(node97);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        com.google.javascript.jscomp.AbstractCompiler abstractCompiler0 = null;
        com.google.javascript.jscomp.NodeTraversal.Callback callback1 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal2 = new com.google.javascript.jscomp.NodeTraversal(abstractCompiler0, callback1);
        com.google.javascript.rhino.Node node3 = nodeTraversal2.getCurrentNode();
        com.google.javascript.jscomp.Scope scope4 = nodeTraversal2.getScope();
        org.junit.Assert.assertNull(node3);
        org.junit.Assert.assertNull(scope4);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        com.google.javascript.jscomp.DiagnosticType diagnosticType0 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        java.lang.String str1 = diagnosticType0.key;
        com.google.javascript.jscomp.DiagnosticType diagnosticType2 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        java.lang.String[] strArray3 = com.google.javascript.rhino.ScriptRuntime.emptyStrings;
        com.google.javascript.jscomp.JSError jSError4 = com.google.javascript.jscomp.JSError.make(diagnosticType2, strArray3);
        com.google.javascript.jscomp.JSError jSError5 = com.google.javascript.jscomp.JSError.make(diagnosticType0, strArray3);
        com.google.javascript.jscomp.CheckLevel checkLevel6 = diagnosticType0.level;
        org.junit.Assert.assertNotNull(diagnosticType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "JSC_OPTIMIZE_LOOP_ERROR" + "'", str1.equals("JSC_OPTIMIZE_LOOP_ERROR"));
        org.junit.Assert.assertNotNull(diagnosticType2);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(jSError4);
        org.junit.Assert.assertNotNull(jSError5);
        org.junit.Assert.assertTrue("'" + checkLevel6 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel6.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile1 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.CompilerInput compilerInput2 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile1);
        com.google.javascript.jscomp.CompilerInput compilerInput5 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput2, "hi!", false);
        compilerInput5.clearAst();
        org.junit.Assert.assertNotNull(jSSourceFile1);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.checkDuplicateMessages = false;
        boolean boolean3 = compilerOptions0.inlineAnonymousFunctionExpressions;
        java.lang.String str4 = compilerOptions0.checkMissingGetCssNameBlacklist;
        compilerOptions0.inlineAnonymousFunctionExpressions = false;
        com.google.javascript.jscomp.CheckLevel checkLevel7 = null;
        compilerOptions0.checkGlobalThisLevel = checkLevel7;
        com.google.javascript.jscomp.CheckLevel checkLevel9 = compilerOptions0.checkMethods;
        compilerOptions0.sourceMapOutputPath = "DiagnosticGroup<undefinedVars>";
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + checkLevel9 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel9.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.brokenClosureRequiresLevel;
        com.google.javascript.jscomp.CheckLevel checkLevel2 = com.google.javascript.jscomp.CheckLevel.WARNING;
        compilerOptions0.checkGlobalNamesLevel = checkLevel2;
        compilerOptions0.computeFunctionSideEffects = true;
        boolean boolean6 = compilerOptions0.removeDeadCode;
        com.google.javascript.jscomp.CompilerOptions.TweakProcessing tweakProcessing7 = compilerOptions0.getTweakProcessing();
        boolean boolean8 = compilerOptions0.checkControlStructures;
        boolean boolean9 = compilerOptions0.extractPrototypeMemberDeclarations;
        compilerOptions0.recordFunctionInformation = false;
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + checkLevel2 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel2.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + tweakProcessing7 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TweakProcessing.OFF + "'", tweakProcessing7.equals(com.google.javascript.jscomp.CompilerOptions.TweakProcessing.OFF));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray12 = new com.google.javascript.rhino.Node[] { node3, node5, node7, node9, node11 };
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray12);
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node16 = node13.copyInformationFrom(node15);
        com.google.javascript.rhino.Node node17 = node13.getParent();
        com.google.javascript.rhino.Node node18 = new com.google.javascript.rhino.Node((int) (short) -1, node13);
        boolean boolean19 = node13.wasEmptyNode();
        com.google.javascript.rhino.Node node21 = node13.getAncestor(0);
        com.google.javascript.rhino.Node node22 = node21.detachFromParent();
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention23 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node27 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node29 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node31 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node33 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node35 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray36 = new com.google.javascript.rhino.Node[] { node27, node29, node31, node33, node35 };
        com.google.javascript.rhino.Node node37 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray36);
        com.google.javascript.rhino.Node node40 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node42 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node44 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node46 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node48 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray49 = new com.google.javascript.rhino.Node[] { node40, node42, node44, node46, node48 };
        com.google.javascript.rhino.Node node50 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray49);
        com.google.javascript.rhino.Node node51 = new com.google.javascript.rhino.Node(100, node37, node50);
        java.lang.String str52 = closureCodingConvention23.getSingletonGetterClassName(node51);
        node51.setWasEmptyNode(true);
        com.google.javascript.rhino.Node node57 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node59 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node61 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node63 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node65 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray66 = new com.google.javascript.rhino.Node[] { node57, node59, node61, node63, node65 };
        com.google.javascript.rhino.Node node67 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray66);
        com.google.javascript.rhino.Node node70 = com.google.javascript.rhino.Node.newString(36, "// Input %num%");
        node51.addChildAfter(node67, node70);
        try {
            node22.addChildrenToFront(node67);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertNotNull(nodeArray12);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertNull(node17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertNotNull(node27);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertNotNull(node33);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertNotNull(nodeArray36);
        org.junit.Assert.assertNotNull(node40);
        org.junit.Assert.assertNotNull(node42);
        org.junit.Assert.assertNotNull(node44);
        org.junit.Assert.assertNotNull(node46);
        org.junit.Assert.assertNotNull(node48);
        org.junit.Assert.assertNotNull(nodeArray49);
        org.junit.Assert.assertNull(str52);
        org.junit.Assert.assertNotNull(node57);
        org.junit.Assert.assertNotNull(node59);
        org.junit.Assert.assertNotNull(node61);
        org.junit.Assert.assertNotNull(node63);
        org.junit.Assert.assertNotNull(node65);
        org.junit.Assert.assertNotNull(nodeArray66);
        org.junit.Assert.assertNotNull(node70);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray0 = new com.google.javascript.jscomp.WarningsGuard[] {};
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard1 = new com.google.javascript.jscomp.ComposeWarningsGuard(warningsGuardArray0);
        java.lang.String str2 = composeWarningsGuard1.toString();
        org.junit.Assert.assertNotNull(warningsGuardArray0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        com.google.javascript.jscomp.DiagnosticType diagnosticType0 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        java.lang.String[] strArray1 = com.google.javascript.rhino.ScriptRuntime.emptyStrings;
        com.google.javascript.jscomp.JSError jSError2 = com.google.javascript.jscomp.JSError.make(diagnosticType0, strArray1);
        int int3 = jSError2.lineNumber;
        org.junit.Assert.assertNotNull(diagnosticType0);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(jSError2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        java.io.InputStream inputStream1 = null;
        try {
            com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromInputStream("", inputStream1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.brokenClosureRequiresLevel;
        boolean boolean2 = compilerOptions0.collapseAnonymousFunctions;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy3 = com.google.javascript.jscomp.VariableRenamingPolicy.OFF;
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy4 = com.google.javascript.jscomp.PropertyRenamingPolicy.OFF;
        compilerOptions0.setRenamingPolicy(variableRenamingPolicy3, propertyRenamingPolicy4);
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy3 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.OFF + "'", variableRenamingPolicy3.equals(com.google.javascript.jscomp.VariableRenamingPolicy.OFF));
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy4 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.OFF + "'", propertyRenamingPolicy4.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.OFF));
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile5 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.CompilerInput compilerInput6 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile5);
        com.google.javascript.jscomp.CompilerInput compilerInput9 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput6, "hi!", false);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile11 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        compilerInput6.setSourceFile((com.google.javascript.jscomp.SourceFile) jSSourceFile11);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile14 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray15 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile2, jSSourceFile11, jSSourceFile14 };
        java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList16 = new java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile>();
        boolean boolean17 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList16, jSSourceFileArray15);
        com.google.javascript.jscomp.JSModule[] jSModuleArray18 = new com.google.javascript.jscomp.JSModule[] {};
        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList19 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
        boolean boolean20 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList19, jSModuleArray18);
        com.google.javascript.jscomp.CompilerOptions compilerOptions21 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions21.checkDuplicateMessages = false;
        boolean boolean24 = compilerOptions21.inlineAnonymousFunctionExpressions;
        compilerOptions21.crossModuleMethodMotion = true;
        com.google.javascript.jscomp.Result result27 = compiler0.compileModules((java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList16, (java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList19, compilerOptions21);
        boolean boolean28 = compilerOptions21.tightenTypes;
        org.junit.Assert.assertNotNull(jSSourceFile2);
        org.junit.Assert.assertNotNull(jSSourceFile5);
        org.junit.Assert.assertNotNull(jSSourceFile11);
        org.junit.Assert.assertNotNull(jSSourceFile14);
        org.junit.Assert.assertNotNull(jSSourceFileArray15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(jSModuleArray18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(result27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray13 = new com.google.javascript.rhino.Node[] { node4, node6, node8, node10, node12 };
        com.google.javascript.rhino.Node node14 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray13);
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node21 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray26 = new com.google.javascript.rhino.Node[] { node17, node19, node21, node23, node25 };
        com.google.javascript.rhino.Node node27 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray26);
        com.google.javascript.rhino.Node node28 = new com.google.javascript.rhino.Node(100, node14, node27);
        boolean boolean29 = closureCodingConvention0.isVarArgsParameter(node28);
        java.lang.String str30 = closureCodingConvention0.getExportPropertyFunction();
        boolean boolean32 = closureCodingConvention0.isConstant("hi!");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention33 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node37 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node39 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node41 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node43 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node45 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray46 = new com.google.javascript.rhino.Node[] { node37, node39, node41, node43, node45 };
        com.google.javascript.rhino.Node node47 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray46);
        com.google.javascript.rhino.Node node50 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node52 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node54 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node56 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node58 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray59 = new com.google.javascript.rhino.Node[] { node50, node52, node54, node56, node58 };
        com.google.javascript.rhino.Node node60 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray59);
        com.google.javascript.rhino.Node node61 = new com.google.javascript.rhino.Node(100, node47, node60);
        boolean boolean62 = closureCodingConvention33.isVarArgsParameter(node61);
        java.lang.String str63 = closureCodingConvention33.getExportPropertyFunction();
        boolean boolean66 = closureCodingConvention33.isExported("goog.exportProperty", false);
        com.google.javascript.rhino.Node node70 = com.google.javascript.rhino.Node.newNumber(100.0d, 4095, 9);
        java.util.Set<java.lang.String> strSet71 = node70.getDirectives();
        boolean boolean72 = closureCodingConvention33.isVarArgsParameter(node70);
        com.google.javascript.rhino.Node node75 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node77 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node79 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node81 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node83 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray84 = new com.google.javascript.rhino.Node[] { node75, node77, node79, node81, node83 };
        com.google.javascript.rhino.Node node85 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray84);
        int int86 = node85.getSideEffectFlags();
        node70.addChildrenToFront(node85);
        java.lang.String str88 = closureCodingConvention0.getSingletonGetterClassName(node85);
        com.google.javascript.rhino.Node node89 = node85.removeFirstChild();
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(nodeArray13);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNotNull(nodeArray26);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "goog.exportProperty" + "'", str30.equals("goog.exportProperty"));
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(node37);
        org.junit.Assert.assertNotNull(node39);
        org.junit.Assert.assertNotNull(node41);
        org.junit.Assert.assertNotNull(node43);
        org.junit.Assert.assertNotNull(node45);
        org.junit.Assert.assertNotNull(nodeArray46);
        org.junit.Assert.assertNotNull(node50);
        org.junit.Assert.assertNotNull(node52);
        org.junit.Assert.assertNotNull(node54);
        org.junit.Assert.assertNotNull(node56);
        org.junit.Assert.assertNotNull(node58);
        org.junit.Assert.assertNotNull(nodeArray59);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertTrue("'" + str63 + "' != '" + "goog.exportProperty" + "'", str63.equals("goog.exportProperty"));
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertNotNull(node70);
        org.junit.Assert.assertNull(strSet71);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
        org.junit.Assert.assertNotNull(node75);
        org.junit.Assert.assertNotNull(node77);
        org.junit.Assert.assertNotNull(node79);
        org.junit.Assert.assertNotNull(node81);
        org.junit.Assert.assertNotNull(node83);
        org.junit.Assert.assertNotNull(nodeArray84);
        org.junit.Assert.assertTrue("'" + int86 + "' != '" + 0 + "'", int86 == 0);
        org.junit.Assert.assertNull(str88);
        org.junit.Assert.assertNotNull(node89);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray13 = new com.google.javascript.rhino.Node[] { node4, node6, node8, node10, node12 };
        com.google.javascript.rhino.Node node14 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray13);
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node21 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray26 = new com.google.javascript.rhino.Node[] { node17, node19, node21, node23, node25 };
        com.google.javascript.rhino.Node node27 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray26);
        com.google.javascript.rhino.Node node28 = new com.google.javascript.rhino.Node(100, node14, node27);
        boolean boolean29 = closureCodingConvention0.isVarArgsParameter(node28);
        java.lang.String str30 = closureCodingConvention0.getGlobalObject();
        com.google.javascript.rhino.Node node35 = com.google.javascript.rhino.Node.newNumber(100.0d, 4095, 9);
        java.util.Set<java.lang.String> strSet36 = node35.getDirectives();
        com.google.javascript.rhino.Node node39 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node41 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node43 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node45 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node47 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray48 = new com.google.javascript.rhino.Node[] { node39, node41, node43, node45, node47 };
        com.google.javascript.rhino.Node node49 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray48);
        com.google.javascript.rhino.Node node51 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node52 = node49.copyInformationFrom(node51);
        com.google.javascript.rhino.Node node55 = new com.google.javascript.rhino.Node(28, node35, node49, (-2), (int) (byte) -1);
        boolean boolean56 = node55.isNoSideEffectsCall();
        com.google.javascript.rhino.Node node60 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node62 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node64 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node66 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node68 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray69 = new com.google.javascript.rhino.Node[] { node60, node62, node64, node66, node68 };
        com.google.javascript.rhino.Node node70 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray69);
        com.google.javascript.rhino.Node node72 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node73 = node70.copyInformationFrom(node72);
        com.google.javascript.rhino.Node node74 = node70.getParent();
        com.google.javascript.rhino.Node node75 = new com.google.javascript.rhino.Node((int) (short) -1, node70);
        boolean boolean76 = node70.wasEmptyNode();
        com.google.javascript.rhino.Node node78 = node70.getAncestor(0);
        java.lang.String str79 = closureCodingConvention0.extractClassNameIfProvide(node55, node70);
        java.lang.String str80 = node55.getQualifiedName();
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(nodeArray13);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNotNull(nodeArray26);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "goog.global" + "'", str30.equals("goog.global"));
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertNull(strSet36);
        org.junit.Assert.assertNotNull(node39);
        org.junit.Assert.assertNotNull(node41);
        org.junit.Assert.assertNotNull(node43);
        org.junit.Assert.assertNotNull(node45);
        org.junit.Assert.assertNotNull(node47);
        org.junit.Assert.assertNotNull(nodeArray48);
        org.junit.Assert.assertNotNull(node51);
        org.junit.Assert.assertNotNull(node52);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertNotNull(node60);
        org.junit.Assert.assertNotNull(node62);
        org.junit.Assert.assertNotNull(node64);
        org.junit.Assert.assertNotNull(node66);
        org.junit.Assert.assertNotNull(node68);
        org.junit.Assert.assertNotNull(nodeArray69);
        org.junit.Assert.assertNotNull(node72);
        org.junit.Assert.assertNotNull(node73);
        org.junit.Assert.assertNull(node74);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
        org.junit.Assert.assertNotNull(node78);
        org.junit.Assert.assertNull(str79);
        org.junit.Assert.assertNull(str80);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.brokenClosureRequiresLevel;
        com.google.javascript.jscomp.CheckLevel checkLevel2 = com.google.javascript.jscomp.CheckLevel.WARNING;
        compilerOptions0.checkGlobalNamesLevel = checkLevel2;
        compilerOptions0.computeFunctionSideEffects = true;
        boolean boolean6 = compilerOptions0.removeDeadCode;
        com.google.javascript.jscomp.SourceMap.DetailLevel detailLevel7 = null;
        compilerOptions0.sourceMapDetailLevel = detailLevel7;
        compilerOptions0.collapseAnonymousFunctions = false;
        boolean boolean11 = compilerOptions0.crossModuleMethodMotion;
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + checkLevel2 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel2.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

//    @Test
//    public void test471() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test471");
//        try {
//            com.google.javascript.rhino.EvaluatorException evaluatorException5 = com.google.javascript.rhino.Context.reportRuntimeError("JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of optimization iterations: {0}", "hi!", 3, ": WARNING - {0}\n", 27);
//            org.junit.Assert.fail("Expected exception of type com.google.javascript.rhino.EvaluatorException; message: JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of optimization iterations: {0} (hi!#3)");
//        } catch (com.google.javascript.rhino.EvaluatorException e) {
//        }
//    }

//    @Test
//    public void test472() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test472");
//        com.google.javascript.rhino.Context context0 = com.google.javascript.rhino.Context.enter();
//        boolean boolean1 = context0.isGeneratingSource();
//        com.google.javascript.rhino.ErrorReporter errorReporter2 = context0.getErrorReporter();
//        com.google.javascript.rhino.ErrorReporter errorReporter3 = context0.getErrorReporter();
//        boolean boolean4 = context0.isSealed();
//        boolean boolean6 = context0.isActivationNeeded("goog.exportProperty");
//        boolean boolean7 = context0.isSealed();
//        org.junit.Assert.assertNotNull(context0);
//        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
//        org.junit.Assert.assertNull(errorReporter2);
//        org.junit.Assert.assertNull(errorReporter3);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray12 = new com.google.javascript.rhino.Node[] { node3, node5, node7, node9, node11 };
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray12);
        int int14 = node13.getSideEffectFlags();
        com.google.javascript.rhino.Node node15 = node13.getNext();
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention16 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node22 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node24 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node26 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node28 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray29 = new com.google.javascript.rhino.Node[] { node20, node22, node24, node26, node28 };
        com.google.javascript.rhino.Node node30 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray29);
        com.google.javascript.rhino.Node node33 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node35 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node37 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node39 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node41 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node[] nodeArray42 = new com.google.javascript.rhino.Node[] { node33, node35, node37, node39, node41 };
        com.google.javascript.rhino.Node node43 = new com.google.javascript.rhino.Node((int) (short) 0, nodeArray42);
        com.google.javascript.rhino.Node node44 = new com.google.javascript.rhino.Node(100, node30, node43);
        java.lang.String str45 = closureCodingConvention16.getSingletonGetterClassName(node44);
        node44.setWasEmptyNode(true);
        com.google.javascript.rhino.Node node51 = com.google.javascript.rhino.Node.newNumber(100.0d, 4095, 9);
        java.util.Set<java.lang.String> strSet52 = node51.getDirectives();
        com.google.javascript.rhino.Node node55 = new com.google.javascript.rhino.Node((int) (short) 0, node13, node44, node51, (int) (short) 10, (int) ' ');
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable56 = node44.children();
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertNotNull(nodeArray12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNull(node15);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertNotNull(nodeArray29);
        org.junit.Assert.assertNotNull(node33);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertNotNull(node37);
        org.junit.Assert.assertNotNull(node39);
        org.junit.Assert.assertNotNull(node41);
        org.junit.Assert.assertNotNull(nodeArray42);
        org.junit.Assert.assertNull(str45);
        org.junit.Assert.assertNotNull(node51);
        org.junit.Assert.assertNull(strSet52);
        org.junit.Assert.assertNotNull(nodeIterable56);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.brokenClosureRequiresLevel;
        compilerOptions0.setManageClosureDependencies(true);
        java.lang.String[] strArray11 = new java.lang.String[] { "goog.exportProperty", "Not declared as a type name", "error reporter", "DiagnosticGroup<undefinedVars>", "goog.exportProperty", "Not declared as a constructor" };
        java.util.ArrayList<java.lang.String> strList12 = new java.util.ArrayList<java.lang.String>();
        boolean boolean13 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strList12, strArray11);
        compilerOptions0.setReplaceStringsConfiguration("goog.exportProperty", (java.util.List<java.lang.String>) strList12);
        com.google.javascript.jscomp.CheckLevel checkLevel15 = compilerOptions0.aggressiveVarCheck;
        compilerOptions0.setRewriteNewDateGoogNow(false);
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(strArray11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + checkLevel15 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel15.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.checkDuplicateMessages = false;
        boolean boolean3 = compilerOptions0.inlineAnonymousFunctionExpressions;
        java.lang.String str4 = compilerOptions0.checkMissingGetCssNameBlacklist;
        compilerOptions0.removeUnusedLocalVars = true;
        compilerOptions0.setTweakToNumberLiteral("EOF 0", 40);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        com.google.javascript.rhino.Node node1 = new com.google.javascript.rhino.Node((int) 'a');
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.brokenClosureRequiresLevel;
        com.google.javascript.jscomp.CheckLevel checkLevel2 = com.google.javascript.jscomp.CheckLevel.WARNING;
        compilerOptions0.checkGlobalNamesLevel = checkLevel2;
        compilerOptions0.computeFunctionSideEffects = true;
        boolean boolean6 = compilerOptions0.removeDeadCode;
        compilerOptions0.inlineLocalVariables = false;
        com.google.javascript.jscomp.CompilerOptions compilerOptions9 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel10 = compilerOptions9.brokenClosureRequiresLevel;
        compilerOptions9.setManageClosureDependencies(true);
        java.lang.String[] strArray20 = new java.lang.String[] { "goog.exportProperty", "Not declared as a type name", "error reporter", "DiagnosticGroup<undefinedVars>", "goog.exportProperty", "Not declared as a constructor" };
        java.util.ArrayList<java.lang.String> strList21 = new java.util.ArrayList<java.lang.String>();
        boolean boolean22 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strList21, strArray20);
        compilerOptions9.setReplaceStringsConfiguration("goog.exportProperty", (java.util.List<java.lang.String>) strList21);
        compilerOptions9.decomposeExpressions = false;
        com.google.javascript.jscomp.CheckLevel checkLevel26 = compilerOptions9.checkMissingGetCssNameLevel;
        compilerOptions0.checkMissingGetCssNameLevel = checkLevel26;
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + checkLevel2 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel2.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + checkLevel10 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel10.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(strArray20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + checkLevel26 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel26.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        int int0 = com.google.javascript.rhino.Node.BRACELESS_TYPE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 40 + "'", int0 == 40);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newNumber(0.0d, (int) (short) 1, (int) ' ');
        int int5 = node3.getIntProp(10);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder6 = node3.getJsDocBuilderForNode();
        fileLevelJsDocBuilder6.append("EOF 0");
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder6);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.checkDuplicateMessages = false;
        compilerOptions0.collapseProperties = false;
        boolean boolean5 = compilerOptions0.aliasAllStrings;
        compilerOptions0.tightenTypes = true;
        compilerOptions0.checkSymbols = true;
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile3 = com.google.javascript.jscomp.JSSourceFile.fromFile("Not declared as a constructor");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile5 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.CompilerInput compilerInput6 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile5);
        com.google.javascript.jscomp.CompilerInput compilerInput9 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput6, "hi!", false);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile11 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        compilerInput6.setSourceFile((com.google.javascript.jscomp.SourceFile) jSSourceFile11);
        java.lang.String str13 = jSSourceFile11.toString();
        com.google.javascript.jscomp.CompilerOptions compilerOptions14 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean15 = compilerOptions14.aliasAllStrings;
        compilerOptions14.setGenerateExports(true);
        com.google.javascript.jscomp.Result result18 = compiler1.compile(jSSourceFile3, jSSourceFile11, compilerOptions14);
        compilerOptions14.inlineLocalFunctions = true;
        compilerOptions14.setGenerateExports(true);
        org.junit.Assert.assertNotNull(jSSourceFile3);
        org.junit.Assert.assertNotNull(jSSourceFile5);
        org.junit.Assert.assertNotNull(jSSourceFile11);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(result18);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        java.lang.String str1 = com.google.javascript.rhino.ScriptRuntime.escapeString("");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile3 = com.google.javascript.jscomp.JSSourceFile.fromFile("Not declared as a constructor");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile5 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.CompilerInput compilerInput6 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile5);
        com.google.javascript.jscomp.CompilerInput compilerInput9 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput6, "hi!", false);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile11 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        compilerInput6.setSourceFile((com.google.javascript.jscomp.SourceFile) jSSourceFile11);
        java.lang.String str13 = jSSourceFile11.toString();
        com.google.javascript.jscomp.CompilerOptions compilerOptions14 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean15 = compilerOptions14.aliasAllStrings;
        compilerOptions14.setGenerateExports(true);
        com.google.javascript.jscomp.Result result18 = compiler1.compile(jSSourceFile3, jSSourceFile11, compilerOptions14);
        compilerOptions14.syntheticBlockEndMarker = "Not declared as a type name";
        compilerOptions14.generatePseudoNames = true;
        byte[] byteArray23 = compilerOptions14.inputVariableMapSerialized;
        com.google.javascript.jscomp.CompilerOptions compilerOptions24 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions24.checkDuplicateMessages = false;
        boolean boolean27 = compilerOptions24.inlineAnonymousFunctionExpressions;
        compilerOptions24.recordFunctionInformation = true;
        boolean boolean30 = compilerOptions24.checkCaja;
        compilerOptions24.aliasableGlobals = "EOF 0";
        com.google.javascript.jscomp.CheckLevel checkLevel33 = com.google.javascript.jscomp.CheckLevel.OFF;
        compilerOptions24.reportUnknownTypes = checkLevel33;
        com.google.javascript.jscomp.CheckLevel checkLevel35 = compilerOptions24.brokenClosureRequiresLevel;
        compilerOptions14.checkMissingReturn = checkLevel35;
        org.junit.Assert.assertNotNull(jSSourceFile3);
        org.junit.Assert.assertNotNull(jSSourceFile5);
        org.junit.Assert.assertNotNull(jSSourceFile11);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(result18);
        org.junit.Assert.assertNull(byteArray23);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + checkLevel33 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel33.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + checkLevel35 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel35.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.brokenClosureRequiresLevel;
        com.google.javascript.jscomp.CheckLevel checkLevel2 = com.google.javascript.jscomp.CheckLevel.WARNING;
        compilerOptions0.checkGlobalNamesLevel = checkLevel2;
        compilerOptions0.computeFunctionSideEffects = true;
        compilerOptions0.setDefineToStringLiteral("", "Unknown class name");
        java.lang.String str9 = compilerOptions0.aliasableGlobals;
        byte[] byteArray10 = compilerOptions0.inputVariableMapSerialized;
        compilerOptions0.setRewriteNewDateGoogNow(false);
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + checkLevel2 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel2.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertNull(byteArray10);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromCode("", "{0}");
        org.junit.Assert.assertNotNull(sourceFile2);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile1 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.CompilerInput compilerInput2 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile1);
        compilerInput2.clearAst();
        org.junit.Assert.assertNotNull(jSSourceFile1);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.checkDuplicateMessages = false;
        boolean boolean3 = compilerOptions0.inlineAnonymousFunctionExpressions;
        compilerOptions0.recordFunctionInformation = true;
        boolean boolean6 = compilerOptions0.checkCaja;
        compilerOptions0.allowLegacyJsMessages = true;
        compilerOptions0.aliasKeywords = false;
        boolean boolean11 = compilerOptions0.checkTypes;
        compilerOptions0.renamePrefix = "// Input %num%";
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile1 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.CompilerInput compilerInput2 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile1);
        com.google.javascript.jscomp.CompilerInput compilerInput5 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput2, "hi!", false);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile7 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        compilerInput2.setSourceFile((com.google.javascript.jscomp.SourceFile) jSSourceFile7);
        java.lang.String str9 = jSSourceFile7.toString();
        try {
            java.io.Reader reader10 = jSSourceFile7.getCodeReader();
            org.junit.Assert.fail("Expected exception of type java.io.FileNotFoundException; message:  (No such file or directory)");
        } catch (java.io.FileNotFoundException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile1);
        org.junit.Assert.assertNotNull(jSSourceFile7);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.Node.newString(36, "// Input %num%");
        com.google.javascript.jscomp.CompilerOptions compilerOptions3 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel4 = compilerOptions3.brokenClosureRequiresLevel;
        com.google.javascript.jscomp.CheckLevel checkLevel5 = com.google.javascript.jscomp.CheckLevel.WARNING;
        compilerOptions3.checkGlobalNamesLevel = checkLevel5;
        compilerOptions3.computeFunctionSideEffects = true;
        boolean boolean9 = compilerOptions3.removeDeadCode;
        compilerOptions3.inlineVariables = true;
        java.lang.RuntimeException runtimeException13 = com.google.javascript.rhino.ScriptRuntime.undefWriteError((java.lang.Object) "// Input %num%", (java.lang.Object) true, (java.lang.Object) 150);
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertTrue("'" + checkLevel4 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel4.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + checkLevel5 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel5.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(runtimeException13);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.Compiler compiler2 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile4 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.CompilerInput compilerInput5 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile4);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile7 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.CompilerInput compilerInput8 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile7);
        com.google.javascript.jscomp.CompilerInput compilerInput11 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput8, "hi!", false);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile13 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        compilerInput8.setSourceFile((com.google.javascript.jscomp.SourceFile) jSSourceFile13);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile16 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray17 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile4, jSSourceFile13, jSSourceFile16 };
        java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList18 = new java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile>();
        boolean boolean19 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList18, jSSourceFileArray17);
        com.google.javascript.jscomp.JSModule[] jSModuleArray20 = new com.google.javascript.jscomp.JSModule[] {};
        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList21 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
        boolean boolean22 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList21, jSModuleArray20);
        com.google.javascript.jscomp.CompilerOptions compilerOptions23 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions23.checkDuplicateMessages = false;
        boolean boolean26 = compilerOptions23.inlineAnonymousFunctionExpressions;
        compilerOptions23.crossModuleMethodMotion = true;
        com.google.javascript.jscomp.Result result29 = compiler2.compileModules((java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList18, (java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList21, compilerOptions23);
        com.google.javascript.jscomp.Compiler compiler30 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile32 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.CompilerInput compilerInput33 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile32);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile35 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.CompilerInput compilerInput36 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile35);
        com.google.javascript.jscomp.CompilerInput compilerInput39 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput36, "hi!", false);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile41 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        compilerInput36.setSourceFile((com.google.javascript.jscomp.SourceFile) jSSourceFile41);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile44 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray45 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile32, jSSourceFile41, jSSourceFile44 };
        java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList46 = new java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile>();
        boolean boolean47 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList46, jSSourceFileArray45);
        com.google.javascript.jscomp.JSModule[] jSModuleArray48 = new com.google.javascript.jscomp.JSModule[] {};
        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList49 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
        boolean boolean50 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList49, jSModuleArray48);
        com.google.javascript.jscomp.CompilerOptions compilerOptions51 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions51.checkDuplicateMessages = false;
        boolean boolean54 = compilerOptions51.inlineAnonymousFunctionExpressions;
        compilerOptions51.crossModuleMethodMotion = true;
        com.google.javascript.jscomp.Result result57 = compiler30.compileModules((java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList46, (java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList49, compilerOptions51);
        com.google.javascript.jscomp.CompilerOptions compilerOptions58 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel59 = compilerOptions58.brokenClosureRequiresLevel;
        java.util.Set<java.lang.String> strSet60 = compilerOptions58.aliasableStrings;
        boolean boolean61 = compilerOptions58.decomposeExpressions;
        java.util.Set<java.lang.String> strSet62 = compilerOptions58.stripNamePrefixes;
        com.google.javascript.jscomp.Result result63 = compiler1.compile((java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList18, (java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList46, compilerOptions58);
        compiler1.rebuildInputsFromModules();
        compiler1.rebuildInputsFromModules();
        org.junit.Assert.assertNotNull(jSSourceFile4);
        org.junit.Assert.assertNotNull(jSSourceFile7);
        org.junit.Assert.assertNotNull(jSSourceFile13);
        org.junit.Assert.assertNotNull(jSSourceFile16);
        org.junit.Assert.assertNotNull(jSSourceFileArray17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(jSModuleArray20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(result29);
        org.junit.Assert.assertNotNull(jSSourceFile32);
        org.junit.Assert.assertNotNull(jSSourceFile35);
        org.junit.Assert.assertNotNull(jSSourceFile41);
        org.junit.Assert.assertNotNull(jSSourceFile44);
        org.junit.Assert.assertNotNull(jSSourceFileArray45);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
        org.junit.Assert.assertNotNull(jSModuleArray48);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNotNull(result57);
        org.junit.Assert.assertTrue("'" + checkLevel59 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel59.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(strSet60);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertNotNull(strSet62);
        org.junit.Assert.assertNotNull(result63);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.brokenClosureRequiresLevel;
        com.google.javascript.jscomp.CheckLevel checkLevel2 = com.google.javascript.jscomp.CheckLevel.WARNING;
        compilerOptions0.checkGlobalNamesLevel = checkLevel2;
        com.google.javascript.jscomp.ErrorFormat errorFormat4 = null;
        compilerOptions0.errorFormat = errorFormat4;
        boolean boolean6 = compilerOptions0.ambiguateProperties;
        com.google.javascript.jscomp.CompilerOptions compilerOptions7 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel8 = compilerOptions7.brokenClosureRequiresLevel;
        com.google.javascript.jscomp.CheckLevel checkLevel9 = com.google.javascript.jscomp.CheckLevel.WARNING;
        compilerOptions7.checkGlobalNamesLevel = checkLevel9;
        compilerOptions7.computeFunctionSideEffects = true;
        boolean boolean13 = compilerOptions7.removeDeadCode;
        compilerOptions7.inlineVariables = true;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy16 = com.google.javascript.jscomp.VariableRenamingPolicy.OFF;
        compilerOptions7.variableRenaming = variableRenamingPolicy16;
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy18 = com.google.javascript.jscomp.PropertyRenamingPolicy.HEURISTIC;
        compilerOptions0.setRenamingPolicy(variableRenamingPolicy16, propertyRenamingPolicy18);
        compilerOptions0.markNoSideEffectCalls = false;
        boolean boolean22 = compilerOptions0.moveFunctionDeclarations;
        compilerOptions0.strictMessageReplacement = false;
        compilerOptions0.setDefineToStringLiteral("TypeError: ", "goog.global");
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + checkLevel2 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel2.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + checkLevel8 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel8.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + checkLevel9 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel9.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy16 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.OFF + "'", variableRenamingPolicy16.equals(com.google.javascript.jscomp.VariableRenamingPolicy.OFF));
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy18 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.HEURISTIC + "'", propertyRenamingPolicy18.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.HEURISTIC));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.NodeTraversal.Callback callback1 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal2 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler0, callback1);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile4 = com.google.javascript.jscomp.JSSourceFile.fromFile("Not declared as a constructor");
        java.io.PrintStream printStream5 = null;
        com.google.javascript.jscomp.Compiler compiler6 = new com.google.javascript.jscomp.Compiler(printStream5);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile8 = com.google.javascript.jscomp.JSSourceFile.fromFile("Not declared as a constructor");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile10 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.CompilerInput compilerInput11 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile10);
        com.google.javascript.jscomp.CompilerInput compilerInput14 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput11, "hi!", false);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile16 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        compilerInput11.setSourceFile((com.google.javascript.jscomp.SourceFile) jSSourceFile16);
        java.lang.String str18 = jSSourceFile16.toString();
        com.google.javascript.jscomp.CompilerOptions compilerOptions19 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean20 = compilerOptions19.aliasAllStrings;
        compilerOptions19.setGenerateExports(true);
        com.google.javascript.jscomp.Result result23 = compiler6.compile(jSSourceFile8, jSSourceFile16, compilerOptions19);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile25 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.CompilerInput compilerInput26 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile25);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile28 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.CompilerInput compilerInput29 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile28);
        com.google.javascript.jscomp.CompilerInput compilerInput32 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput29, "hi!", false);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile34 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        compilerInput29.setSourceFile((com.google.javascript.jscomp.SourceFile) jSSourceFile34);
        java.lang.String str36 = jSSourceFile34.toString();
        java.io.PrintStream printStream37 = null;
        com.google.javascript.jscomp.Compiler compiler38 = new com.google.javascript.jscomp.Compiler(printStream37);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile40 = com.google.javascript.jscomp.JSSourceFile.fromFile("Not declared as a constructor");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile42 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.CompilerInput compilerInput43 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile42);
        com.google.javascript.jscomp.CompilerInput compilerInput46 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput43, "hi!", false);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile48 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        compilerInput43.setSourceFile((com.google.javascript.jscomp.SourceFile) jSSourceFile48);
        java.lang.String str50 = jSSourceFile48.toString();
        com.google.javascript.jscomp.CompilerOptions compilerOptions51 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean52 = compilerOptions51.aliasAllStrings;
        compilerOptions51.setGenerateExports(true);
        com.google.javascript.jscomp.Result result55 = compiler38.compile(jSSourceFile40, jSSourceFile48, compilerOptions51);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile57 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.CompilerInput compilerInput58 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile57);
        com.google.javascript.jscomp.Region region60 = jSSourceFile57.getRegion(24);
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray61 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile4, jSSourceFile16, jSSourceFile25, jSSourceFile34, jSSourceFile48, jSSourceFile57 };
        java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList62 = new java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile>();
        boolean boolean63 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList62, jSSourceFileArray61);
        com.google.javascript.jscomp.JSModule[] jSModuleArray64 = new com.google.javascript.jscomp.JSModule[] {};
        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList65 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
        boolean boolean66 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList65, jSModuleArray64);
        com.google.javascript.jscomp.CompilerOptions compilerOptions67 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel68 = compilerOptions67.brokenClosureRequiresLevel;
        com.google.javascript.jscomp.CheckLevel checkLevel69 = com.google.javascript.jscomp.CheckLevel.WARNING;
        compilerOptions67.checkGlobalNamesLevel = checkLevel69;
        compilerOptions67.computeFunctionSideEffects = true;
        boolean boolean73 = compilerOptions67.removeDeadCode;
        com.google.javascript.jscomp.CompilerOptions.TweakProcessing tweakProcessing74 = compilerOptions67.getTweakProcessing();
        com.google.javascript.jscomp.Result result75 = compiler0.compileModules((java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList62, (java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList65, compilerOptions67);
        java.lang.String str78 = compiler0.getSourceLine("com.google.javascript.rhino.EcmaError: TypeError: -1 is not a function, it is java.lang.Byte.", 7);
        boolean boolean79 = compiler0.acceptConstKeyword();
        com.google.javascript.jscomp.SourceMap sourceMap80 = compiler0.getSourceMap();
        java.util.List<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList81 = null;
        java.util.List<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList82 = null;
        com.google.javascript.jscomp.CompilerOptions compilerOptions83 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel84 = compilerOptions83.brokenClosureRequiresLevel;
        com.google.javascript.jscomp.CheckLevel checkLevel85 = com.google.javascript.jscomp.CheckLevel.WARNING;
        compilerOptions83.checkGlobalNamesLevel = checkLevel85;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy87 = com.google.javascript.jscomp.VariableRenamingPolicy.OFF;
        compilerOptions83.variableRenaming = variableRenamingPolicy87;
        com.google.javascript.jscomp.CheckLevel checkLevel89 = compilerOptions83.checkMissingGetCssNameLevel;
        try {
            com.google.javascript.jscomp.Result result90 = compiler0.compile(jSSourceFileList81, jSSourceFileList82, compilerOptions83);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile4);
        org.junit.Assert.assertNotNull(jSSourceFile8);
        org.junit.Assert.assertNotNull(jSSourceFile10);
        org.junit.Assert.assertNotNull(jSSourceFile16);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "" + "'", str18.equals(""));
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(result23);
        org.junit.Assert.assertNotNull(jSSourceFile25);
        org.junit.Assert.assertNotNull(jSSourceFile28);
        org.junit.Assert.assertNotNull(jSSourceFile34);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "" + "'", str36.equals(""));
        org.junit.Assert.assertNotNull(jSSourceFile40);
        org.junit.Assert.assertNotNull(jSSourceFile42);
        org.junit.Assert.assertNotNull(jSSourceFile48);
        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "" + "'", str50.equals(""));
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertNotNull(result55);
        org.junit.Assert.assertNotNull(jSSourceFile57);
        org.junit.Assert.assertNull(region60);
        org.junit.Assert.assertNotNull(jSSourceFileArray61);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + true + "'", boolean63 == true);
        org.junit.Assert.assertNotNull(jSModuleArray64);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertTrue("'" + checkLevel68 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel68.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + checkLevel69 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel69.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
        org.junit.Assert.assertTrue("'" + tweakProcessing74 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TweakProcessing.OFF + "'", tweakProcessing74.equals(com.google.javascript.jscomp.CompilerOptions.TweakProcessing.OFF));
        org.junit.Assert.assertNotNull(result75);
        org.junit.Assert.assertNull(str78);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
        org.junit.Assert.assertNull(sourceMap80);
        org.junit.Assert.assertTrue("'" + checkLevel84 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel84.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + checkLevel85 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel85.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy87 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.OFF + "'", variableRenamingPolicy87.equals(com.google.javascript.jscomp.VariableRenamingPolicy.OFF));
        org.junit.Assert.assertTrue("'" + checkLevel89 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel89.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

//    @Test
//    public void test493() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test493");
//        com.google.javascript.rhino.Context context0 = com.google.javascript.rhino.Context.enter();
//        boolean boolean1 = context0.isGeneratingSource();
//        java.lang.Object obj2 = null;
//        context0.removeThreadLocal(obj2);
//        boolean boolean4 = context0.isGeneratingDebug();
//        try {
//            context0.setLanguageVersion(11);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Bad language version: 11");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(context0);
//        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile1 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.CompilerInput compilerInput2 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile1);
        com.google.javascript.jscomp.CompilerInput compilerInput5 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput2, "hi!", false);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile7 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        compilerInput2.setSourceFile((com.google.javascript.jscomp.SourceFile) jSSourceFile7);
        java.io.PrintStream printStream9 = null;
        com.google.javascript.jscomp.Compiler compiler10 = new com.google.javascript.jscomp.Compiler(printStream9);
        com.google.javascript.jscomp.Compiler compiler11 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile13 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.CompilerInput compilerInput14 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile13);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile16 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.CompilerInput compilerInput17 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile16);
        com.google.javascript.jscomp.CompilerInput compilerInput20 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput17, "hi!", false);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile22 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        compilerInput17.setSourceFile((com.google.javascript.jscomp.SourceFile) jSSourceFile22);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile25 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray26 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile13, jSSourceFile22, jSSourceFile25 };
        java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList27 = new java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile>();
        boolean boolean28 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList27, jSSourceFileArray26);
        com.google.javascript.jscomp.JSModule[] jSModuleArray29 = new com.google.javascript.jscomp.JSModule[] {};
        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList30 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
        boolean boolean31 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList30, jSModuleArray29);
        com.google.javascript.jscomp.CompilerOptions compilerOptions32 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions32.checkDuplicateMessages = false;
        boolean boolean35 = compilerOptions32.inlineAnonymousFunctionExpressions;
        compilerOptions32.crossModuleMethodMotion = true;
        com.google.javascript.jscomp.Result result38 = compiler11.compileModules((java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList27, (java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList30, compilerOptions32);
        com.google.javascript.jscomp.Compiler compiler39 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile41 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.CompilerInput compilerInput42 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile41);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile44 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.CompilerInput compilerInput45 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile44);
        com.google.javascript.jscomp.CompilerInput compilerInput48 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput45, "hi!", false);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile50 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        compilerInput45.setSourceFile((com.google.javascript.jscomp.SourceFile) jSSourceFile50);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile53 = com.google.javascript.jscomp.JSSourceFile.fromFile("");
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray54 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile41, jSSourceFile50, jSSourceFile53 };
        java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList55 = new java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile>();
        boolean boolean56 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList55, jSSourceFileArray54);
        com.google.javascript.jscomp.JSModule[] jSModuleArray57 = new com.google.javascript.jscomp.JSModule[] {};
        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList58 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
        boolean boolean59 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList58, jSModuleArray57);
        com.google.javascript.jscomp.CompilerOptions compilerOptions60 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions60.checkDuplicateMessages = false;
        boolean boolean63 = compilerOptions60.inlineAnonymousFunctionExpressions;
        compilerOptions60.crossModuleMethodMotion = true;
        com.google.javascript.jscomp.Result result66 = compiler39.compileModules((java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList55, (java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList58, compilerOptions60);
        com.google.javascript.jscomp.CompilerOptions compilerOptions67 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel68 = compilerOptions67.brokenClosureRequiresLevel;
        java.util.Set<java.lang.String> strSet69 = compilerOptions67.aliasableStrings;
        boolean boolean70 = compilerOptions67.decomposeExpressions;
        java.util.Set<java.lang.String> strSet71 = compilerOptions67.stripNamePrefixes;
        com.google.javascript.jscomp.Result result72 = compiler10.compile((java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList27, (java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList55, compilerOptions67);
        com.google.javascript.jscomp.PerformanceTracker performanceTracker73 = compiler10.tracker;
        com.google.javascript.rhino.Node node74 = compilerInput2.getAstRoot((com.google.javascript.jscomp.AbstractCompiler) compiler10);
        try {
            java.lang.String str75 = compilerInput2.getCode();
            org.junit.Assert.fail("Expected exception of type java.io.FileNotFoundException; message:  (No such file or directory)");
        } catch (java.io.FileNotFoundException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile1);
        org.junit.Assert.assertNotNull(jSSourceFile7);
        org.junit.Assert.assertNotNull(jSSourceFile13);
        org.junit.Assert.assertNotNull(jSSourceFile16);
        org.junit.Assert.assertNotNull(jSSourceFile22);
        org.junit.Assert.assertNotNull(jSSourceFile25);
        org.junit.Assert.assertNotNull(jSSourceFileArray26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(jSModuleArray29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(result38);
        org.junit.Assert.assertNotNull(jSSourceFile41);
        org.junit.Assert.assertNotNull(jSSourceFile44);
        org.junit.Assert.assertNotNull(jSSourceFile50);
        org.junit.Assert.assertNotNull(jSSourceFile53);
        org.junit.Assert.assertNotNull(jSSourceFileArray54);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + true + "'", boolean56 == true);
        org.junit.Assert.assertNotNull(jSModuleArray57);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertNotNull(result66);
        org.junit.Assert.assertTrue("'" + checkLevel68 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel68.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(strSet69);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertNotNull(strSet71);
        org.junit.Assert.assertNotNull(result72);
        org.junit.Assert.assertNull(performanceTracker73);
        org.junit.Assert.assertNull(node74);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.brokenClosureRequiresLevel;
        com.google.javascript.jscomp.CheckLevel checkLevel2 = com.google.javascript.jscomp.CheckLevel.WARNING;
        compilerOptions0.checkGlobalNamesLevel = checkLevel2;
        compilerOptions0.computeFunctionSideEffects = true;
        boolean boolean6 = compilerOptions0.removeDeadCode;
        compilerOptions0.removeUnusedLocalVars = true;
        com.google.javascript.jscomp.CheckLevel checkLevel9 = compilerOptions0.checkGlobalNamesLevel;
        boolean boolean10 = compilerOptions0.inlineLocalFunctions;
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + checkLevel2 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel2.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + checkLevel9 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel9.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray0 = new com.google.javascript.jscomp.WarningsGuard[] {};
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard1 = new com.google.javascript.jscomp.ComposeWarningsGuard(warningsGuardArray0);
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard2 = new com.google.javascript.jscomp.ComposeWarningsGuard(warningsGuardArray0);
        org.junit.Assert.assertNotNull(warningsGuardArray0);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.brokenClosureRequiresLevel;
        com.google.javascript.jscomp.CheckLevel checkLevel2 = com.google.javascript.jscomp.CheckLevel.WARNING;
        compilerOptions0.checkGlobalNamesLevel = checkLevel2;
        compilerOptions0.computeFunctionSideEffects = true;
        compilerOptions0.setShadowVariables(true);
        compilerOptions0.debugFunctionSideEffectsPath = "goog.global";
        com.google.common.collect.Multimap<com.google.javascript.jscomp.CustomPassExecutionTime, com.google.javascript.jscomp.CompilerPass> customPassExecutionTimeMultimap10 = null;
        compilerOptions0.customPasses = customPassExecutionTimeMultimap10;
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + checkLevel2 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel2.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile1 = com.google.javascript.jscomp.JSSourceFile.fromFile("language version");
        try {
            java.lang.String str2 = jSSourceFile1.getCode();
            org.junit.Assert.fail("Expected exception of type java.io.FileNotFoundException; message: language version (No such file or directory)");
        } catch (java.io.FileNotFoundException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile1);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.brokenClosureRequiresLevel;
        java.util.Set<java.lang.String> strSet2 = compilerOptions0.aliasableStrings;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy3 = com.google.javascript.jscomp.VariableRenamingPolicy.OFF;
        compilerOptions0.variableRenaming = variableRenamingPolicy3;
        boolean boolean5 = compilerOptions0.inlineConstantVars;
        com.google.javascript.jscomp.CompilerOptions compilerOptions6 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel7 = compilerOptions6.brokenClosureRequiresLevel;
        com.google.javascript.jscomp.CheckLevel checkLevel8 = com.google.javascript.jscomp.CheckLevel.WARNING;
        compilerOptions6.checkGlobalNamesLevel = checkLevel8;
        compilerOptions6.computeFunctionSideEffects = true;
        boolean boolean12 = compilerOptions6.removeDeadCode;
        compilerOptions6.inlineVariables = true;
        compilerOptions6.reserveRawExports = false;
        com.google.javascript.jscomp.SourceMap.DetailLevel detailLevel17 = compilerOptions6.sourceMapDetailLevel;
        compilerOptions0.sourceMapDetailLevel = detailLevel17;
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(strSet2);
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy3 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.OFF + "'", variableRenamingPolicy3.equals(com.google.javascript.jscomp.VariableRenamingPolicy.OFF));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + checkLevel7 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel7.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + checkLevel8 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel8.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(detailLevel17);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.ACCESS_CONTROLS;
        com.google.javascript.jscomp.DiagnosticGroups.CHECK_REGEXP = diagnosticGroup0;
        org.junit.Assert.assertNull(diagnosticGroup0);
    }
}

