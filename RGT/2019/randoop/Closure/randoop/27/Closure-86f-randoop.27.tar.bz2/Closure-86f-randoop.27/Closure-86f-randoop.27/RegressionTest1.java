import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test01() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test01");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.ErrorReporter errorReporter3 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter3, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative6 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray7 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative6 };
        com.google.javascript.rhino.jstype.JSType jSType8 = jSTypeRegistry5.createUnionType(jSTypeNativeArray7);
        com.google.javascript.rhino.ErrorReporter errorReporter9 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry11 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter9, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative12 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray13 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative12 };
        com.google.javascript.rhino.jstype.JSType jSType14 = jSTypeRegistry11.createUnionType(jSTypeNativeArray13);
        com.google.javascript.rhino.Node node16 = new com.google.javascript.rhino.Node((-1));
        com.google.javascript.rhino.jstype.FunctionType functionType17 = jSTypeRegistry5.createFunctionType(jSType14, node16);
        com.google.javascript.rhino.Node node18 = new com.google.javascript.rhino.Node((int) ' ', node16);
        com.google.javascript.rhino.Node node19 = new com.google.javascript.rhino.Node((int) ' ', node18);
        java.lang.String str20 = closureCodingConvention0.getSingletonGetterClassName(node18);
        boolean boolean22 = closureCodingConvention0.isConstant("goog.exportProperty");
        org.junit.Assert.assertTrue("'" + jSTypeNative6 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative6.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray7);
        org.junit.Assert.assertNotNull(jSType8);
        org.junit.Assert.assertTrue("'" + jSTypeNative12 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative12.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray13);
        org.junit.Assert.assertNotNull(jSType14);
        org.junit.Assert.assertNotNull(functionType17);
        org.junit.Assert.assertNull(str20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test02() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test02");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative3 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray4 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative3 };
        com.google.javascript.rhino.jstype.JSType jSType5 = jSTypeRegistry2.createUnionType(jSTypeNativeArray4);
        com.google.javascript.rhino.jstype.JSType jSType10 = jSTypeRegistry2.createNamedType("EOF", "STRING hi!", 73, 100);
        com.google.javascript.rhino.jstype.ObjectType objectType11 = com.google.javascript.rhino.jstype.ObjectType.cast(jSType10);
        org.junit.Assert.assertTrue("'" + jSTypeNative3 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative3.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray4);
        org.junit.Assert.assertNotNull(jSType5);
        org.junit.Assert.assertNotNull(jSType10);
        org.junit.Assert.assertNotNull(objectType11);
    }

    @Test
    public void test03() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test03");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative3 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray4 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative3 };
        com.google.javascript.rhino.jstype.JSType jSType5 = jSTypeRegistry2.createUnionType(jSTypeNativeArray4);
        com.google.javascript.rhino.ErrorReporter errorReporter6 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry8 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter6, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative9 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray10 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative9 };
        com.google.javascript.rhino.jstype.JSType jSType11 = jSTypeRegistry8.createUnionType(jSTypeNativeArray10);
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node((-1));
        com.google.javascript.rhino.jstype.FunctionType functionType14 = jSTypeRegistry2.createFunctionType(jSType11, node13);
        boolean boolean16 = functionType14.hasOwnProperty("hi!");
        com.google.javascript.rhino.jstype.FunctionPrototypeType functionPrototypeType17 = null;
        boolean boolean18 = functionType14.setPrototype(functionPrototypeType17);
        com.google.javascript.rhino.ErrorReporter errorReporter19 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry21 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter19, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative22 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray23 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative22 };
        com.google.javascript.rhino.jstype.JSType jSType24 = jSTypeRegistry21.createUnionType(jSTypeNativeArray23);
        com.google.javascript.rhino.ErrorReporter errorReporter25 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry27 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter25, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative28 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray29 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative28 };
        com.google.javascript.rhino.jstype.JSType jSType30 = jSTypeRegistry27.createUnionType(jSTypeNativeArray29);
        com.google.javascript.rhino.Node node32 = new com.google.javascript.rhino.Node((-1));
        com.google.javascript.rhino.jstype.FunctionType functionType33 = jSTypeRegistry21.createFunctionType(jSType30, node32);
        boolean boolean35 = functionType33.hasOwnProperty("hi!");
        com.google.javascript.rhino.ErrorReporter errorReporter36 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry38 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter36, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative39 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray40 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative39 };
        com.google.javascript.rhino.jstype.JSType jSType41 = jSTypeRegistry38.createUnionType(jSTypeNativeArray40);
        com.google.javascript.rhino.ErrorReporter errorReporter42 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry44 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter42, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative45 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray46 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative45 };
        com.google.javascript.rhino.jstype.JSType jSType47 = jSTypeRegistry44.createUnionType(jSTypeNativeArray46);
        com.google.javascript.rhino.Node node49 = new com.google.javascript.rhino.Node((-1));
        com.google.javascript.rhino.jstype.FunctionType functionType50 = jSTypeRegistry38.createFunctionType(jSType47, node49);
        boolean boolean52 = functionType50.hasOwnProperty("hi!");
        functionType33.setPrototypeBasedOn((com.google.javascript.rhino.jstype.ObjectType) functionType50);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable54 = functionType33.getCtorImplementedInterfaces();
        com.google.javascript.rhino.ErrorReporter errorReporter55 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry57 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter55, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative58 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray59 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative58 };
        com.google.javascript.rhino.jstype.JSType jSType60 = jSTypeRegistry57.createUnionType(jSTypeNativeArray59);
        com.google.javascript.rhino.ErrorReporter errorReporter61 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry63 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter61, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative64 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray65 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative64 };
        com.google.javascript.rhino.jstype.JSType jSType66 = jSTypeRegistry63.createUnionType(jSTypeNativeArray65);
        com.google.javascript.rhino.Node node68 = new com.google.javascript.rhino.Node((-1));
        com.google.javascript.rhino.jstype.FunctionType functionType69 = jSTypeRegistry57.createFunctionType(jSType66, node68);
        boolean boolean71 = functionType69.hasOwnProperty("hi!");
        com.google.javascript.rhino.ErrorReporter errorReporter72 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry74 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter72, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative75 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray76 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative75 };
        com.google.javascript.rhino.jstype.JSType jSType77 = jSTypeRegistry74.createUnionType(jSTypeNativeArray76);
        com.google.javascript.rhino.ErrorReporter errorReporter78 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry80 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter78, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative81 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray82 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative81 };
        com.google.javascript.rhino.jstype.JSType jSType83 = jSTypeRegistry80.createUnionType(jSTypeNativeArray82);
        com.google.javascript.rhino.Node node85 = new com.google.javascript.rhino.Node((-1));
        com.google.javascript.rhino.jstype.FunctionType functionType86 = jSTypeRegistry74.createFunctionType(jSType83, node85);
        boolean boolean88 = functionType86.hasOwnProperty("hi!");
        functionType69.setPrototypeBasedOn((com.google.javascript.rhino.jstype.ObjectType) functionType86);
        com.google.javascript.rhino.jstype.JSType jSType90 = functionType33.getLeastSupertype((com.google.javascript.rhino.jstype.JSType) functionType69);
        com.google.javascript.rhino.jstype.JSType.TypePair typePair91 = functionType14.getTypesUnderShallowInequality((com.google.javascript.rhino.jstype.JSType) functionType33);
        java.lang.String str92 = functionType33.toString();
        boolean boolean93 = functionType33.matchesUint32Context();
        org.junit.Assert.assertTrue("'" + jSTypeNative3 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative3.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray4);
        org.junit.Assert.assertNotNull(jSType5);
        org.junit.Assert.assertTrue("'" + jSTypeNative9 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative9.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray10);
        org.junit.Assert.assertNotNull(jSType11);
        org.junit.Assert.assertNotNull(functionType14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + jSTypeNative22 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative22.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray23);
        org.junit.Assert.assertNotNull(jSType24);
        org.junit.Assert.assertTrue("'" + jSTypeNative28 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative28.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray29);
        org.junit.Assert.assertNotNull(jSType30);
        org.junit.Assert.assertNotNull(functionType33);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + jSTypeNative39 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative39.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray40);
        org.junit.Assert.assertNotNull(jSType41);
        org.junit.Assert.assertTrue("'" + jSTypeNative45 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative45.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray46);
        org.junit.Assert.assertNotNull(jSType47);
        org.junit.Assert.assertNotNull(functionType50);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertNotNull(objectTypeIterable54);
        org.junit.Assert.assertTrue("'" + jSTypeNative58 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative58.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray59);
        org.junit.Assert.assertNotNull(jSType60);
        org.junit.Assert.assertTrue("'" + jSTypeNative64 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative64.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray65);
        org.junit.Assert.assertNotNull(jSType66);
        org.junit.Assert.assertNotNull(functionType69);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
        org.junit.Assert.assertTrue("'" + jSTypeNative75 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative75.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray76);
        org.junit.Assert.assertNotNull(jSType77);
        org.junit.Assert.assertTrue("'" + jSTypeNative81 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative81.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray82);
        org.junit.Assert.assertNotNull(jSType83);
        org.junit.Assert.assertNotNull(functionType86);
        org.junit.Assert.assertTrue("'" + boolean88 + "' != '" + false + "'", boolean88 == false);
        org.junit.Assert.assertNotNull(jSType90);
        org.junit.Assert.assertNotNull(typePair91);
        org.junit.Assert.assertTrue("'" + str92 + "' != '" + "function (): function (new:TypeError, *, *, *): TypeError" + "'", str92.equals("function (): function (new:TypeError, *, *, *): TypeError"));
        org.junit.Assert.assertTrue("'" + boolean93 + "' != '" + false + "'", boolean93 == false);
    }

    @Test
    public void test04() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test04");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.disambiguateProperties;
        com.google.javascript.jscomp.AnonymousFunctionNamingPolicy anonymousFunctionNamingPolicy2 = compilerOptions0.anonymousFunctionNaming;
        boolean boolean3 = compilerOptions0.removeUnusedPrototypeProperties;
        compilerOptions0.inlineFunctions = false;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + anonymousFunctionNamingPolicy2 + "' != '" + com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF + "'", anonymousFunctionNamingPolicy2.equals(com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test05() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test05");
        com.google.javascript.rhino.Node node1 = new com.google.javascript.rhino.Node(83);
        boolean boolean2 = node1.hasMoreThanOneChild();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test06() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test06");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative3 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray4 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative3 };
        com.google.javascript.rhino.jstype.JSType jSType5 = jSTypeRegistry2.createUnionType(jSTypeNativeArray4);
        com.google.javascript.rhino.ErrorReporter errorReporter6 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry8 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter6, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative9 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray10 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative9 };
        com.google.javascript.rhino.jstype.JSType jSType11 = jSTypeRegistry8.createUnionType(jSTypeNativeArray10);
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node((-1));
        com.google.javascript.rhino.jstype.FunctionType functionType14 = jSTypeRegistry2.createFunctionType(jSType11, node13);
        com.google.javascript.rhino.jstype.ObjectType objectType15 = jSTypeRegistry2.createAnonymousObjectType();
        com.google.javascript.rhino.ErrorReporter errorReporter17 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry19 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter17, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative20 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray21 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative20 };
        com.google.javascript.rhino.jstype.JSType jSType22 = jSTypeRegistry19.createUnionType(jSTypeNativeArray21);
        com.google.javascript.rhino.ErrorReporter errorReporter23 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry25 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter23, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative26 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray27 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative26 };
        com.google.javascript.rhino.jstype.JSType jSType28 = jSTypeRegistry25.createUnionType(jSTypeNativeArray27);
        com.google.javascript.rhino.Node node30 = new com.google.javascript.rhino.Node((-1));
        com.google.javascript.rhino.jstype.FunctionType functionType31 = jSTypeRegistry19.createFunctionType(jSType28, node30);
        com.google.javascript.rhino.ErrorReporter errorReporter32 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry34 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter32, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative35 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray36 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative35 };
        com.google.javascript.rhino.jstype.JSType jSType37 = jSTypeRegistry34.createUnionType(jSTypeNativeArray36);
        com.google.javascript.rhino.ErrorReporter errorReporter38 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry40 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter38, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative41 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray42 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative41 };
        com.google.javascript.rhino.jstype.JSType jSType43 = jSTypeRegistry40.createUnionType(jSTypeNativeArray42);
        com.google.javascript.rhino.Node node45 = new com.google.javascript.rhino.Node((-1));
        com.google.javascript.rhino.jstype.FunctionType functionType46 = jSTypeRegistry34.createFunctionType(jSType43, node45);
        com.google.javascript.rhino.ErrorReporter errorReporter47 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry49 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter47, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative50 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray51 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative50 };
        com.google.javascript.rhino.jstype.JSType jSType52 = jSTypeRegistry49.createUnionType(jSTypeNativeArray51);
        com.google.javascript.rhino.ErrorReporter errorReporter53 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry55 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter53, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative56 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray57 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative56 };
        com.google.javascript.rhino.jstype.JSType jSType58 = jSTypeRegistry55.createUnionType(jSTypeNativeArray57);
        com.google.javascript.rhino.Node node60 = new com.google.javascript.rhino.Node((-1));
        com.google.javascript.rhino.jstype.FunctionType functionType61 = jSTypeRegistry49.createFunctionType(jSType58, node60);
        boolean boolean63 = functionType61.hasOwnProperty("hi!");
        com.google.javascript.rhino.jstype.ObjectType objectType64 = jSTypeRegistry34.createObjectType((com.google.javascript.rhino.jstype.ObjectType) functionType61);
        com.google.javascript.rhino.jstype.JSType.TypePair typePair65 = jSType28.getTypesUnderShallowInequality((com.google.javascript.rhino.jstype.JSType) objectType64);
        jSTypeRegistry2.registerPropertyOnType("goog.exportSymbol", jSType28);
        com.google.javascript.rhino.jstype.JSTypeRegistry.ResolveMode resolveMode67 = com.google.javascript.rhino.jstype.JSTypeRegistry.ResolveMode.LAZY_EXPRESSIONS;
        jSTypeRegistry2.setResolveMode(resolveMode67);
        boolean boolean70 = jSTypeRegistry2.hasNamespace("");
        org.junit.Assert.assertTrue("'" + jSTypeNative3 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative3.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray4);
        org.junit.Assert.assertNotNull(jSType5);
        org.junit.Assert.assertTrue("'" + jSTypeNative9 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative9.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray10);
        org.junit.Assert.assertNotNull(jSType11);
        org.junit.Assert.assertNotNull(functionType14);
        org.junit.Assert.assertNotNull(objectType15);
        org.junit.Assert.assertTrue("'" + jSTypeNative20 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative20.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray21);
        org.junit.Assert.assertNotNull(jSType22);
        org.junit.Assert.assertTrue("'" + jSTypeNative26 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative26.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray27);
        org.junit.Assert.assertNotNull(jSType28);
        org.junit.Assert.assertNotNull(functionType31);
        org.junit.Assert.assertTrue("'" + jSTypeNative35 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative35.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray36);
        org.junit.Assert.assertNotNull(jSType37);
        org.junit.Assert.assertTrue("'" + jSTypeNative41 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative41.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray42);
        org.junit.Assert.assertNotNull(jSType43);
        org.junit.Assert.assertNotNull(functionType46);
        org.junit.Assert.assertTrue("'" + jSTypeNative50 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative50.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray51);
        org.junit.Assert.assertNotNull(jSType52);
        org.junit.Assert.assertTrue("'" + jSTypeNative56 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative56.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray57);
        org.junit.Assert.assertNotNull(jSType58);
        org.junit.Assert.assertNotNull(functionType61);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertNotNull(objectType64);
        org.junit.Assert.assertNotNull(typePair65);
        org.junit.Assert.assertTrue("'" + resolveMode67 + "' != '" + com.google.javascript.rhino.jstype.JSTypeRegistry.ResolveMode.LAZY_EXPRESSIONS + "'", resolveMode67.equals(com.google.javascript.rhino.jstype.JSTypeRegistry.ResolveMode.LAZY_EXPRESSIONS));
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
    }

    @Test
    public void test07() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test07");
        com.google.javascript.rhino.EvaluatorException evaluatorException5 = new com.google.javascript.rhino.EvaluatorException("", "", 100, "hi!", (int) (short) 1);
        java.lang.String str6 = evaluatorException5.sourceName();
        com.google.javascript.rhino.EvaluatorException evaluatorException12 = new com.google.javascript.rhino.EvaluatorException("", "", 100, "hi!", (int) (short) 1);
        evaluatorException5.addSuppressed((java.lang.Throwable) evaluatorException12);
        java.lang.String str14 = evaluatorException5.sourceName();
        java.lang.Throwable[] throwableArray15 = evaluatorException5.getSuppressed();
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertNotNull(throwableArray15);
    }

    @Test
    public void test08() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test08");
        java.io.InputStream inputStream1 = null;
        try {
            com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromInputStream("error reporter", inputStream1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test09() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test09");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.removeUnusedPrototypeProperties;
        compilerOptions0.removeEmptyFunctions = true;
        compilerOptions0.removeUnusedVars = false;
        compilerOptions0.setDefineToNumberLiteral("", 21);
        compilerOptions0.setLooseTypes(false);
        com.google.javascript.jscomp.CompilerOptions compilerOptions11 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean12 = compilerOptions11.disambiguateProperties;
        boolean boolean13 = compilerOptions11.isExternExportsEnabled();
        boolean boolean14 = compilerOptions11.removeTryCatchFinally;
        com.google.javascript.jscomp.SourceMap.DetailLevel detailLevel15 = null;
        compilerOptions11.sourceMapDetailLevel = detailLevel15;
        com.google.javascript.jscomp.CheckLevel checkLevel17 = compilerOptions11.checkShadowVars;
        compilerOptions0.checkUnreachableCode = checkLevel17;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + checkLevel17 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel17.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test10() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test10");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode3 = new com.google.javascript.rhino.ScriptOrFnNode(11, 130, (int) (short) 100);
        int int6 = scriptOrFnNode3.addRegexp("language version", "hi!");
        int int7 = scriptOrFnNode3.getEndLineno();
        java.lang.String str9 = scriptOrFnNode3.getRegexpString(0);
        int int12 = scriptOrFnNode3.addRegexp("", "{1350500668}");
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "language version" + "'", str9.equals("language version"));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
    }

    @Test
    public void test11() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test11");
        int int0 = com.google.javascript.rhino.Node.VARIABLE_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 23 + "'", int0 == 23);
    }

    @Test
    public void test12() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test12");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.markNoSideEffectCalls = true;
        compilerOptions0.setDefineToNumberLiteral("STRING hi!", (int) (byte) 100);
        boolean boolean6 = compilerOptions0.decomposeExpressions;
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test13() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test13");
        int int0 = com.google.javascript.rhino.Node.LABEL_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 19 + "'", int0 == 19);
    }

    @Test
    public void test14() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test14");
        com.google.javascript.rhino.Node.SideEffectFlags sideEffectFlags1 = new com.google.javascript.rhino.Node.SideEffectFlags((int) (short) 100);
        sideEffectFlags1.setMutatesGlobalState();
        sideEffectFlags1.clearAllFlags();
        sideEffectFlags1.setAllFlags();
    }

    @Test
    public void test15() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test15");
        com.google.javascript.rhino.JSDocInfoBuilder jSDocInfoBuilder1 = new com.google.javascript.rhino.JSDocInfoBuilder(false);
        com.google.javascript.jscomp.CompilerOptions compilerOptions2 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.common.collect.Multimap<com.google.javascript.jscomp.CustomPassExecutionTime, com.google.javascript.jscomp.CompilerPass> customPassExecutionTimeMultimap3 = null;
        compilerOptions2.customPasses = customPassExecutionTimeMultimap3;
        boolean boolean5 = compilerOptions2.inlineConstantVars;
        java.lang.String str6 = compilerOptions2.syntheticBlockStartMarker;
        compilerOptions2.decomposeExpressions = false;
        boolean boolean9 = compilerOptions2.checkTypes;
        java.lang.String str10 = compilerOptions2.sourceMapOutputPath;
        boolean boolean11 = compilerOptions2.deadAssignmentElimination;
        java.lang.String[] strArray15 = new java.lang.String[] { "language version", "language version", "" };
        java.util.LinkedHashSet<java.lang.String> strSet16 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean17 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet16, strArray15);
        compilerOptions2.aliasableStrings = strSet16;
        boolean boolean19 = jSDocInfoBuilder1.recordModifies((java.util.Set<java.lang.String>) strSet16);
        boolean boolean20 = jSDocInfoBuilder1.recordImplicitCast();
        com.google.javascript.rhino.JSDocInfo jSDocInfo22 = jSDocInfoBuilder1.build("Named type with empty name component");
        com.google.javascript.rhino.JSTypeExpression jSTypeExpression23 = jSDocInfo22.getType();
        java.lang.String str24 = jSDocInfo22.getDescription();
        java.lang.String str25 = jSDocInfo22.getLendsName();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(strArray15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(jSDocInfo22);
        org.junit.Assert.assertNull(jSTypeExpression23);
        org.junit.Assert.assertNull(str24);
        org.junit.Assert.assertNull(str25);
    }

    @Test
    public void test16() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test16");
        com.google.javascript.rhino.JSDocInfoBuilder jSDocInfoBuilder1 = new com.google.javascript.rhino.JSDocInfoBuilder(true);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode6 = new com.google.javascript.rhino.ScriptOrFnNode(11, 130, (int) (short) 100);
        int int7 = scriptOrFnNode6.getEncodedSourceStart();
        com.google.javascript.rhino.JSTypeExpression jSTypeExpression9 = new com.google.javascript.rhino.JSTypeExpression((com.google.javascript.rhino.Node) scriptOrFnNode6, "Named type with empty name component");
        boolean boolean10 = jSDocInfoBuilder1.recordParameter("language version", jSTypeExpression9);
        com.google.javascript.rhino.JSDocInfoBuilder jSDocInfoBuilder12 = new com.google.javascript.rhino.JSDocInfoBuilder(false);
        com.google.javascript.jscomp.CompilerOptions compilerOptions13 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.common.collect.Multimap<com.google.javascript.jscomp.CustomPassExecutionTime, com.google.javascript.jscomp.CompilerPass> customPassExecutionTimeMultimap14 = null;
        compilerOptions13.customPasses = customPassExecutionTimeMultimap14;
        boolean boolean16 = compilerOptions13.inlineConstantVars;
        java.lang.String str17 = compilerOptions13.syntheticBlockStartMarker;
        compilerOptions13.decomposeExpressions = false;
        boolean boolean20 = compilerOptions13.checkTypes;
        java.lang.String str21 = compilerOptions13.sourceMapOutputPath;
        boolean boolean22 = compilerOptions13.deadAssignmentElimination;
        java.lang.String[] strArray26 = new java.lang.String[] { "language version", "language version", "" };
        java.util.LinkedHashSet<java.lang.String> strSet27 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean28 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet27, strArray26);
        compilerOptions13.aliasableStrings = strSet27;
        boolean boolean30 = jSDocInfoBuilder12.recordModifies((java.util.Set<java.lang.String>) strSet27);
        boolean boolean31 = jSDocInfoBuilder1.recordSuppressions((java.util.Set<java.lang.String>) strSet27);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(strArray26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
    }

    @Test
    public void test17() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test17");
        com.google.javascript.rhino.Node.SideEffectFlags sideEffectFlags1 = new com.google.javascript.rhino.Node.SideEffectFlags((int) (short) 100);
        sideEffectFlags1.setMutatesArguments();
        sideEffectFlags1.setMutatesThis();
    }

    @Test
    public void test18() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test18");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.common.collect.Multimap<com.google.javascript.jscomp.CustomPassExecutionTime, com.google.javascript.jscomp.CompilerPass> customPassExecutionTimeMultimap1 = null;
        compilerOptions0.customPasses = customPassExecutionTimeMultimap1;
        boolean boolean3 = compilerOptions0.inlineConstantVars;
        java.lang.String str4 = compilerOptions0.syntheticBlockStartMarker;
        compilerOptions0.decomposeExpressions = false;
        boolean boolean7 = compilerOptions0.checkTypes;
        java.lang.String str8 = compilerOptions0.sourceMapOutputPath;
        boolean boolean9 = compilerOptions0.deadAssignmentElimination;
        java.lang.String[] strArray13 = new java.lang.String[] { "language version", "language version", "" };
        java.util.LinkedHashSet<java.lang.String> strSet14 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean15 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet14, strArray13);
        compilerOptions0.aliasableStrings = strSet14;
        com.google.javascript.jscomp.CompilerOptions compilerOptions17 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean18 = compilerOptions17.disambiguateProperties;
        boolean boolean19 = compilerOptions17.isExternExportsEnabled();
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup20 = com.google.javascript.jscomp.DiagnosticGroups.CHECK_TYPES;
        com.google.javascript.jscomp.CompilerOptions compilerOptions21 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel22 = compilerOptions21.checkMissingGetCssNameLevel;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard23 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup20, checkLevel22);
        compilerOptions17.checkProvides = checkLevel22;
        boolean boolean25 = compilerOptions17.aliasAllStrings;
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup26 = com.google.javascript.jscomp.DiagnosticGroups.CHECK_TYPES;
        com.google.javascript.jscomp.CompilerOptions compilerOptions27 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean28 = compilerOptions27.disambiguateProperties;
        boolean boolean29 = compilerOptions27.isExternExportsEnabled();
        com.google.javascript.jscomp.CheckLevel checkLevel30 = compilerOptions27.checkMethods;
        compilerOptions17.setWarningLevel(diagnosticGroup26, checkLevel30);
        compilerOptions0.brokenClosureRequiresLevel = checkLevel30;
        java.lang.String str33 = compilerOptions0.renamePrefix;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(strArray13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(diagnosticGroup20);
        org.junit.Assert.assertTrue("'" + checkLevel22 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel22.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(diagnosticGroup26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + checkLevel30 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel30.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNull(str33);
    }

    @Test
    public void test19() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test19");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.removeUnusedPrototypeProperties;
        compilerOptions0.removeEmptyFunctions = true;
        boolean boolean4 = compilerOptions0.instrumentForCoverageOnly;
        com.google.javascript.jscomp.CheckLevel checkLevel5 = compilerOptions0.checkRequires;
        compilerOptions0.nameReferenceReportPath = "error reporter";
        boolean boolean8 = compilerOptions0.specializeInitialModule;
        boolean boolean9 = compilerOptions0.removeEmptyFunctions;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + checkLevel5 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel5.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test20() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test20");
        com.google.javascript.rhino.ErrorReporter errorReporter1 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry3 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter1, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative4 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray5 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative4 };
        com.google.javascript.rhino.jstype.JSType jSType6 = jSTypeRegistry3.createUnionType(jSTypeNativeArray5);
        com.google.javascript.rhino.ErrorReporter errorReporter7 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry9 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter7, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative10 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray11 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative10 };
        com.google.javascript.rhino.jstype.JSType jSType12 = jSTypeRegistry9.createUnionType(jSTypeNativeArray11);
        com.google.javascript.rhino.Node node14 = new com.google.javascript.rhino.Node((-1));
        com.google.javascript.rhino.jstype.FunctionType functionType15 = jSTypeRegistry3.createFunctionType(jSType12, node14);
        com.google.javascript.rhino.Node node16 = new com.google.javascript.rhino.Node((int) ' ', node14);
        java.util.Set<java.lang.String> strSet17 = node14.getDirectives();
        org.junit.Assert.assertTrue("'" + jSTypeNative4 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative4.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray5);
        org.junit.Assert.assertNotNull(jSType6);
        org.junit.Assert.assertTrue("'" + jSTypeNative10 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative10.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray11);
        org.junit.Assert.assertNotNull(jSType12);
        org.junit.Assert.assertNotNull(functionType15);
        org.junit.Assert.assertNull(strSet17);
    }

    @Test
    public void test21() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test21");
        com.google.javascript.rhino.Node node1 = new com.google.javascript.rhino.Node((-1));
        node1.putIntProp(33, 130);
        com.google.javascript.rhino.jstype.JSType jSType5 = node1.getJSType();
        java.lang.String str6 = node1.toStringTree();
        org.junit.Assert.assertNull(jSType5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "ERROR [name: 130]\n" + "'", str6.equals("ERROR [name: 130]\n"));
    }

    @Test
    public void test22() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test22");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative3 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray4 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative3 };
        com.google.javascript.rhino.jstype.JSType jSType5 = jSTypeRegistry2.createUnionType(jSTypeNativeArray4);
        com.google.javascript.rhino.ErrorReporter errorReporter6 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry8 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter6, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative9 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray10 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative9 };
        com.google.javascript.rhino.jstype.JSType jSType11 = jSTypeRegistry8.createUnionType(jSTypeNativeArray10);
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node((-1));
        com.google.javascript.rhino.jstype.FunctionType functionType14 = jSTypeRegistry2.createFunctionType(jSType11, node13);
        com.google.javascript.rhino.ErrorReporter errorReporter15 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry17 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter15, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative18 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray19 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative18 };
        com.google.javascript.rhino.jstype.JSType jSType20 = jSTypeRegistry17.createUnionType(jSTypeNativeArray19);
        com.google.javascript.rhino.ErrorReporter errorReporter21 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry23 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter21, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative24 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray25 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative24 };
        com.google.javascript.rhino.jstype.JSType jSType26 = jSTypeRegistry23.createUnionType(jSTypeNativeArray25);
        com.google.javascript.rhino.Node node28 = new com.google.javascript.rhino.Node((-1));
        com.google.javascript.rhino.jstype.FunctionType functionType29 = jSTypeRegistry17.createFunctionType(jSType26, node28);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray30 = new com.google.javascript.rhino.jstype.JSType[] { jSType26 };
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList31 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean32 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList31, jSTypeArray30);
        com.google.javascript.rhino.Node node33 = jSTypeRegistry2.createParametersWithVarArgs((java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList31);
        com.google.javascript.rhino.ErrorReporter errorReporter34 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry36 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter34, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative37 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray38 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative37 };
        com.google.javascript.rhino.jstype.JSType jSType39 = jSTypeRegistry36.createUnionType(jSTypeNativeArray38);
        com.google.javascript.rhino.ErrorReporter errorReporter40 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry42 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter40, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative43 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray44 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative43 };
        com.google.javascript.rhino.jstype.JSType jSType45 = jSTypeRegistry42.createUnionType(jSTypeNativeArray44);
        com.google.javascript.rhino.Node node47 = new com.google.javascript.rhino.Node((-1));
        com.google.javascript.rhino.jstype.FunctionType functionType48 = jSTypeRegistry36.createFunctionType(jSType45, node47);
        boolean boolean50 = functionType48.hasOwnProperty("hi!");
        com.google.javascript.rhino.ErrorReporter errorReporter51 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry53 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter51, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative54 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray55 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative54 };
        com.google.javascript.rhino.jstype.JSType jSType56 = jSTypeRegistry53.createUnionType(jSTypeNativeArray55);
        com.google.javascript.rhino.ErrorReporter errorReporter57 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry59 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter57, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative60 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray61 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative60 };
        com.google.javascript.rhino.jstype.JSType jSType62 = jSTypeRegistry59.createUnionType(jSTypeNativeArray61);
        com.google.javascript.rhino.Node node64 = new com.google.javascript.rhino.Node((-1));
        com.google.javascript.rhino.jstype.FunctionType functionType65 = jSTypeRegistry53.createFunctionType(jSType62, node64);
        boolean boolean67 = functionType65.hasOwnProperty("hi!");
        functionType48.setPrototypeBasedOn((com.google.javascript.rhino.jstype.ObjectType) functionType65);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable69 = functionType48.getCtorImplementedInterfaces();
        com.google.javascript.rhino.jstype.JSType jSType70 = jSTypeRegistry2.createOptionalType((com.google.javascript.rhino.jstype.JSType) functionType48);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray71 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.Node node72 = jSTypeRegistry2.createParameters(jSTypeArray71);
        org.junit.Assert.assertTrue("'" + jSTypeNative3 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative3.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray4);
        org.junit.Assert.assertNotNull(jSType5);
        org.junit.Assert.assertTrue("'" + jSTypeNative9 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative9.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray10);
        org.junit.Assert.assertNotNull(jSType11);
        org.junit.Assert.assertNotNull(functionType14);
        org.junit.Assert.assertTrue("'" + jSTypeNative18 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative18.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray19);
        org.junit.Assert.assertNotNull(jSType20);
        org.junit.Assert.assertTrue("'" + jSTypeNative24 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative24.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray25);
        org.junit.Assert.assertNotNull(jSType26);
        org.junit.Assert.assertNotNull(functionType29);
        org.junit.Assert.assertNotNull(jSTypeArray30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNotNull(node33);
        org.junit.Assert.assertTrue("'" + jSTypeNative37 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative37.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray38);
        org.junit.Assert.assertNotNull(jSType39);
        org.junit.Assert.assertTrue("'" + jSTypeNative43 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative43.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray44);
        org.junit.Assert.assertNotNull(jSType45);
        org.junit.Assert.assertNotNull(functionType48);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertTrue("'" + jSTypeNative54 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative54.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray55);
        org.junit.Assert.assertNotNull(jSType56);
        org.junit.Assert.assertTrue("'" + jSTypeNative60 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative60.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray61);
        org.junit.Assert.assertNotNull(jSType62);
        org.junit.Assert.assertNotNull(functionType65);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
        org.junit.Assert.assertNotNull(objectTypeIterable69);
        org.junit.Assert.assertNotNull(jSType70);
        org.junit.Assert.assertNotNull(jSTypeArray71);
        org.junit.Assert.assertNotNull(node72);
    }

    @Test
    public void test23() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test23");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.PerformanceTracker performanceTracker2 = compiler1.tracker;
        com.google.javascript.jscomp.PerformanceTracker performanceTracker3 = null;
        compiler1.tracker = performanceTracker3;
        try {
            java.lang.String str7 = compiler1.getSourceLine("goog.exportProperty", 140);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(performanceTracker2);
    }

    @Test
    public void test24() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test24");
        com.google.javascript.jscomp.CompilerOptions compilerOptions3 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.common.collect.Multimap<com.google.javascript.jscomp.CustomPassExecutionTime, com.google.javascript.jscomp.CompilerPass> customPassExecutionTimeMultimap4 = null;
        compilerOptions3.customPasses = customPassExecutionTimeMultimap4;
        compilerOptions3.devirtualizePrototypeMethods = true;
        compilerOptions3.checkDuplicateMessages = false;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy10 = null;
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy11 = null;
        compilerOptions3.setRenamingPolicy(variableRenamingPolicy10, propertyRenamingPolicy11);
        com.google.javascript.jscomp.CheckLevel checkLevel13 = compilerOptions3.checkUndefinedProperties;
        com.google.javascript.jscomp.DiagnosticType diagnosticType14 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        com.google.javascript.jscomp.DiagnosticType diagnosticType17 = com.google.javascript.jscomp.DiagnosticType.warning("", "");
        int int18 = diagnosticType14.compareTo(diagnosticType17);
        java.lang.String[] strArray19 = com.google.javascript.rhino.ScriptRuntime.emptyStrings;
        com.google.javascript.jscomp.JSError jSError20 = com.google.javascript.jscomp.JSError.make("EOF", 0, 85, checkLevel13, diagnosticType14, strArray19);
        java.lang.String str21 = diagnosticType14.key;
        org.junit.Assert.assertTrue("'" + checkLevel13 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel13.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(diagnosticType14);
        org.junit.Assert.assertNotNull(diagnosticType17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 23 + "'", int18 == 23);
        org.junit.Assert.assertNotNull(strArray19);
        org.junit.Assert.assertNotNull(jSError20);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "JSC_OPTIMIZE_LOOP_ERROR" + "'", str21.equals("JSC_OPTIMIZE_LOOP_ERROR"));
    }

    @Test
    public void test25() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test25");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.checkMissingGetCssNameLevel;
        boolean boolean2 = compilerOptions0.collapseProperties;
        boolean boolean3 = compilerOptions0.optimizeArgumentsArray;
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test26() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test26");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative3 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray4 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative3 };
        com.google.javascript.rhino.jstype.JSType jSType5 = jSTypeRegistry2.createUnionType(jSTypeNativeArray4);
        com.google.javascript.rhino.ErrorReporter errorReporter6 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry8 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter6, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative9 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray10 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative9 };
        com.google.javascript.rhino.jstype.JSType jSType11 = jSTypeRegistry8.createUnionType(jSTypeNativeArray10);
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node((-1));
        com.google.javascript.rhino.jstype.FunctionType functionType14 = jSTypeRegistry2.createFunctionType(jSType11, node13);
        com.google.javascript.rhino.ErrorReporter errorReporter15 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry17 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter15, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative18 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray19 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative18 };
        com.google.javascript.rhino.jstype.JSType jSType20 = jSTypeRegistry17.createUnionType(jSTypeNativeArray19);
        com.google.javascript.rhino.ErrorReporter errorReporter21 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry23 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter21, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative24 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray25 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative24 };
        com.google.javascript.rhino.jstype.JSType jSType26 = jSTypeRegistry23.createUnionType(jSTypeNativeArray25);
        com.google.javascript.rhino.Node node28 = new com.google.javascript.rhino.Node((-1));
        com.google.javascript.rhino.jstype.FunctionType functionType29 = jSTypeRegistry17.createFunctionType(jSType26, node28);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray30 = new com.google.javascript.rhino.jstype.JSType[] { jSType26 };
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList31 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean32 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList31, jSTypeArray30);
        com.google.javascript.rhino.Node node33 = jSTypeRegistry2.createParametersWithVarArgs((java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList31);
        jSTypeRegistry2.setLastGeneration(false);
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope36 = null;
        com.google.javascript.rhino.jstype.JSType jSType41 = jSTypeRegistry2.getType(jSTypeStaticScope36, "TYPEOF", "EOF", (int) (short) 10, 76);
        com.google.javascript.rhino.ErrorReporter errorReporter42 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry44 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter42, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative45 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray46 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative45 };
        com.google.javascript.rhino.jstype.JSType jSType47 = jSTypeRegistry44.createUnionType(jSTypeNativeArray46);
        com.google.javascript.rhino.ErrorReporter errorReporter48 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry50 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter48, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative51 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray52 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative51 };
        com.google.javascript.rhino.jstype.JSType jSType53 = jSTypeRegistry50.createUnionType(jSTypeNativeArray52);
        com.google.javascript.rhino.Node node55 = new com.google.javascript.rhino.Node((-1));
        com.google.javascript.rhino.jstype.FunctionType functionType56 = jSTypeRegistry44.createFunctionType(jSType53, node55);
        boolean boolean58 = functionType56.hasOwnProperty("hi!");
        com.google.javascript.rhino.jstype.FunctionPrototypeType functionPrototypeType59 = null;
        boolean boolean60 = functionType56.setPrototype(functionPrototypeType59);
        java.lang.String str61 = functionType56.getDisplayName();
        com.google.javascript.rhino.ErrorReporter errorReporter62 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry64 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter62, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative65 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray66 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative65 };
        com.google.javascript.rhino.jstype.JSType jSType67 = jSTypeRegistry64.createUnionType(jSTypeNativeArray66);
        com.google.javascript.rhino.ErrorReporter errorReporter68 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry70 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter68, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative71 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray72 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative71 };
        com.google.javascript.rhino.jstype.JSType jSType73 = jSTypeRegistry70.createUnionType(jSTypeNativeArray72);
        com.google.javascript.rhino.Node node75 = new com.google.javascript.rhino.Node((-1));
        com.google.javascript.rhino.jstype.FunctionType functionType76 = jSTypeRegistry64.createFunctionType(jSType73, node75);
        com.google.javascript.rhino.ErrorReporter errorReporter77 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry79 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter77, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative80 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray81 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative80 };
        com.google.javascript.rhino.jstype.JSType jSType82 = jSTypeRegistry79.createUnionType(jSTypeNativeArray81);
        com.google.javascript.rhino.ErrorReporter errorReporter83 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry85 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter83, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative86 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray87 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative86 };
        com.google.javascript.rhino.jstype.JSType jSType88 = jSTypeRegistry85.createUnionType(jSTypeNativeArray87);
        com.google.javascript.rhino.Node node90 = new com.google.javascript.rhino.Node((-1));
        com.google.javascript.rhino.jstype.FunctionType functionType91 = jSTypeRegistry79.createFunctionType(jSType88, node90);
        boolean boolean93 = functionType91.hasOwnProperty("hi!");
        com.google.javascript.rhino.jstype.ObjectType objectType94 = jSTypeRegistry64.createObjectType((com.google.javascript.rhino.jstype.ObjectType) functionType91);
        java.lang.String str95 = functionType91.getNormalizedReferenceName();
        com.google.javascript.rhino.jstype.FunctionType functionType96 = jSTypeRegistry2.createFunctionTypeWithNewThisType(functionType56, (com.google.javascript.rhino.jstype.ObjectType) functionType91);
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray97 = new com.google.javascript.rhino.jstype.JSTypeNative[] {};
        com.google.javascript.rhino.jstype.JSType jSType98 = jSTypeRegistry2.createUnionType(jSTypeNativeArray97);
        org.junit.Assert.assertTrue("'" + jSTypeNative3 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative3.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray4);
        org.junit.Assert.assertNotNull(jSType5);
        org.junit.Assert.assertTrue("'" + jSTypeNative9 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative9.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray10);
        org.junit.Assert.assertNotNull(jSType11);
        org.junit.Assert.assertNotNull(functionType14);
        org.junit.Assert.assertTrue("'" + jSTypeNative18 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative18.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray19);
        org.junit.Assert.assertNotNull(jSType20);
        org.junit.Assert.assertTrue("'" + jSTypeNative24 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative24.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray25);
        org.junit.Assert.assertNotNull(jSType26);
        org.junit.Assert.assertNotNull(functionType29);
        org.junit.Assert.assertNotNull(jSTypeArray30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNotNull(node33);
        org.junit.Assert.assertNotNull(jSType41);
        org.junit.Assert.assertTrue("'" + jSTypeNative45 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative45.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray46);
        org.junit.Assert.assertNotNull(jSType47);
        org.junit.Assert.assertTrue("'" + jSTypeNative51 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative51.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray52);
        org.junit.Assert.assertNotNull(jSType53);
        org.junit.Assert.assertNotNull(functionType56);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertNull(str61);
        org.junit.Assert.assertTrue("'" + jSTypeNative65 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative65.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray66);
        org.junit.Assert.assertNotNull(jSType67);
        org.junit.Assert.assertTrue("'" + jSTypeNative71 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative71.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray72);
        org.junit.Assert.assertNotNull(jSType73);
        org.junit.Assert.assertNotNull(functionType76);
        org.junit.Assert.assertTrue("'" + jSTypeNative80 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative80.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray81);
        org.junit.Assert.assertNotNull(jSType82);
        org.junit.Assert.assertTrue("'" + jSTypeNative86 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative86.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray87);
        org.junit.Assert.assertNotNull(jSType88);
        org.junit.Assert.assertNotNull(functionType91);
        org.junit.Assert.assertTrue("'" + boolean93 + "' != '" + false + "'", boolean93 == false);
        org.junit.Assert.assertNotNull(objectType94);
        org.junit.Assert.assertNull(str95);
        org.junit.Assert.assertNotNull(functionType96);
        org.junit.Assert.assertNotNull(jSTypeNativeArray97);
        org.junit.Assert.assertNotNull(jSType98);
    }

    @Test
    public void test27() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test27");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative3 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray4 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative3 };
        com.google.javascript.rhino.jstype.JSType jSType5 = jSTypeRegistry2.createUnionType(jSTypeNativeArray4);
        com.google.javascript.rhino.ErrorReporter errorReporter6 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry8 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter6, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative9 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray10 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative9 };
        com.google.javascript.rhino.jstype.JSType jSType11 = jSTypeRegistry8.createUnionType(jSTypeNativeArray10);
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node((-1));
        com.google.javascript.rhino.jstype.FunctionType functionType14 = jSTypeRegistry2.createFunctionType(jSType11, node13);
        boolean boolean15 = functionType14.matchesInt32Context();
        com.google.javascript.rhino.Node node16 = functionType14.getSource();
        com.google.javascript.rhino.jstype.JSType jSType18 = functionType14.getPropertyType("function (): function (new:TypeError, *, *, *): TypeError");
        org.junit.Assert.assertTrue("'" + jSTypeNative3 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative3.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray4);
        org.junit.Assert.assertNotNull(jSType5);
        org.junit.Assert.assertTrue("'" + jSTypeNative9 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative9.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray10);
        org.junit.Assert.assertNotNull(jSType11);
        org.junit.Assert.assertNotNull(functionType14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNull(node16);
        org.junit.Assert.assertNotNull(jSType18);
    }

    @Test
    public void test28() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test28");
        com.google.javascript.rhino.Context context0 = com.google.javascript.rhino.Context.enter();
        java.util.Locale locale1 = context0.getLocale();
        context0.setCompileFunctionsWithDynamicScope(false);
        java.util.Locale locale4 = context0.getLocale();
        context0.setCompileFunctionsWithDynamicScope(false);
        boolean boolean7 = context0.hasCompileFunctionsWithDynamicScope();
        org.junit.Assert.assertNotNull(context0);
        org.junit.Assert.assertNotNull(locale1);
        org.junit.Assert.assertNotNull(locale4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test29() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test29");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.disambiguateProperties;
        boolean boolean2 = compilerOptions0.isExternExportsEnabled();
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup3 = com.google.javascript.jscomp.DiagnosticGroups.CHECK_TYPES;
        com.google.javascript.jscomp.CompilerOptions compilerOptions4 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel5 = compilerOptions4.checkMissingGetCssNameLevel;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard6 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup3, checkLevel5);
        compilerOptions0.checkProvides = checkLevel5;
        boolean boolean8 = compilerOptions0.aliasExternals;
        boolean boolean9 = compilerOptions0.rewriteFunctionExpressions;
        java.lang.String str10 = compilerOptions0.unaliasableGlobals;
        boolean boolean11 = compilerOptions0.removeUnusedPrototypeProperties;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(diagnosticGroup3);
        org.junit.Assert.assertTrue("'" + checkLevel5 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel5.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test30() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test30");
        com.google.javascript.jscomp.parsing.Config config2 = com.google.javascript.jscomp.parsing.ParserRunner.createConfig(false, false);
        org.junit.Assert.assertNotNull(config2);
    }

    @Test
    public void test31() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test31");
        com.google.javascript.rhino.Node node1 = new com.google.javascript.rhino.Node(0);
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention2 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.ErrorReporter errorReporter5 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry7 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter5, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative8 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray9 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative8 };
        com.google.javascript.rhino.jstype.JSType jSType10 = jSTypeRegistry7.createUnionType(jSTypeNativeArray9);
        com.google.javascript.rhino.ErrorReporter errorReporter11 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry13 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter11, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative14 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray15 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative14 };
        com.google.javascript.rhino.jstype.JSType jSType16 = jSTypeRegistry13.createUnionType(jSTypeNativeArray15);
        com.google.javascript.rhino.Node node18 = new com.google.javascript.rhino.Node((-1));
        com.google.javascript.rhino.jstype.FunctionType functionType19 = jSTypeRegistry7.createFunctionType(jSType16, node18);
        com.google.javascript.rhino.Node node20 = new com.google.javascript.rhino.Node((int) ' ', node18);
        com.google.javascript.rhino.Node node21 = new com.google.javascript.rhino.Node((int) ' ', node20);
        java.lang.String str22 = closureCodingConvention2.getSingletonGetterClassName(node20);
        com.google.javascript.rhino.Node node26 = com.google.javascript.rhino.Node.newString("EOF", 93, 28);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode30 = new com.google.javascript.rhino.ScriptOrFnNode(11, 130, (int) (short) 100);
        int int31 = scriptOrFnNode30.getEncodedSourceStart();
        boolean boolean33 = scriptOrFnNode30.addConst("hi!");
        java.lang.String str34 = closureCodingConvention2.extractClassNameIfProvide(node26, (com.google.javascript.rhino.Node) scriptOrFnNode30);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode38 = new com.google.javascript.rhino.ScriptOrFnNode(11, 130, (int) (short) 100);
        int int41 = scriptOrFnNode38.addRegexp("language version", "hi!");
        int int42 = scriptOrFnNode38.getEndLineno();
        boolean boolean43 = closureCodingConvention2.isVarArgsParameter((com.google.javascript.rhino.Node) scriptOrFnNode38);
        node1.addChildToBack((com.google.javascript.rhino.Node) scriptOrFnNode38);
        com.google.javascript.rhino.Node node49 = com.google.javascript.rhino.Node.newString((int) ' ', "hi!", (int) (byte) 0, (int) (byte) 100);
        boolean boolean50 = scriptOrFnNode38.hasChild(node49);
        scriptOrFnNode38.setEncodedSourceBounds((int) '#', 300);
        org.junit.Assert.assertTrue("'" + jSTypeNative8 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative8.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray9);
        org.junit.Assert.assertNotNull(jSType10);
        org.junit.Assert.assertTrue("'" + jSTypeNative14 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative14.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray15);
        org.junit.Assert.assertNotNull(jSType16);
        org.junit.Assert.assertNotNull(functionType19);
        org.junit.Assert.assertNull(str22);
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertNull(str34);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + (-1) + "'", int42 == (-1));
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(node49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
    }

    @Test
    public void test32() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test32");
        java.lang.Object[] objArray0 = com.google.javascript.rhino.ScriptRuntime.emptyArgs;
        org.junit.Assert.assertNotNull(objArray0);
    }

//    @Test
//    public void test33() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test33");
//        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.UNDEFINED_VARIABLES;
//        org.junit.Assert.assertNull(diagnosticGroup0);
//    }

    @Test
    public void test34() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test34");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.GREATEST_FUNCTION_TYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.GREATEST_FUNCTION_TYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.GREATEST_FUNCTION_TYPE));
    }

    @Test
    public void test35() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test35");
        com.google.javascript.jscomp.SourceAst sourceAst0 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(sourceAst0, "", true);
        com.google.javascript.jscomp.SourceAst sourceAst4 = compilerInput3.getSourceAst();
        com.google.javascript.jscomp.SourceAst sourceAst5 = compilerInput3.getSourceAst();
        org.junit.Assert.assertNull(sourceAst4);
        org.junit.Assert.assertNull(sourceAst5);
    }

    @Test
    public void test36() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test36");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.common.collect.Multimap<com.google.javascript.jscomp.CustomPassExecutionTime, com.google.javascript.jscomp.CompilerPass> customPassExecutionTimeMultimap1 = null;
        compilerOptions0.customPasses = customPassExecutionTimeMultimap1;
        compilerOptions0.devirtualizePrototypeMethods = true;
        compilerOptions0.setOutputCharset("goog.exportSymbol");
        compilerOptions0.generatePseudoNames = false;
    }

    @Test
    public void test37() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test37");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative3 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray4 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative3 };
        com.google.javascript.rhino.jstype.JSType jSType5 = jSTypeRegistry2.createUnionType(jSTypeNativeArray4);
        com.google.javascript.rhino.ErrorReporter errorReporter6 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry8 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter6, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative9 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray10 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative9 };
        com.google.javascript.rhino.jstype.JSType jSType11 = jSTypeRegistry8.createUnionType(jSTypeNativeArray10);
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node((-1));
        com.google.javascript.rhino.jstype.FunctionType functionType14 = jSTypeRegistry2.createFunctionType(jSType11, node13);
        boolean boolean16 = functionType14.hasOwnProperty("hi!");
        com.google.javascript.rhino.jstype.FunctionPrototypeType functionPrototypeType17 = null;
        boolean boolean18 = functionType14.setPrototype(functionPrototypeType17);
        com.google.javascript.rhino.ErrorReporter errorReporter19 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry21 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter19, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative22 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray23 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative22 };
        com.google.javascript.rhino.jstype.JSType jSType24 = jSTypeRegistry21.createUnionType(jSTypeNativeArray23);
        com.google.javascript.rhino.ErrorReporter errorReporter25 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry27 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter25, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative28 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray29 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative28 };
        com.google.javascript.rhino.jstype.JSType jSType30 = jSTypeRegistry27.createUnionType(jSTypeNativeArray29);
        com.google.javascript.rhino.Node node32 = new com.google.javascript.rhino.Node((-1));
        com.google.javascript.rhino.jstype.FunctionType functionType33 = jSTypeRegistry21.createFunctionType(jSType30, node32);
        boolean boolean35 = functionType33.hasOwnProperty("hi!");
        com.google.javascript.rhino.ErrorReporter errorReporter36 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry38 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter36, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative39 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray40 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative39 };
        com.google.javascript.rhino.jstype.JSType jSType41 = jSTypeRegistry38.createUnionType(jSTypeNativeArray40);
        com.google.javascript.rhino.ErrorReporter errorReporter42 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry44 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter42, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative45 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray46 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative45 };
        com.google.javascript.rhino.jstype.JSType jSType47 = jSTypeRegistry44.createUnionType(jSTypeNativeArray46);
        com.google.javascript.rhino.Node node49 = new com.google.javascript.rhino.Node((-1));
        com.google.javascript.rhino.jstype.FunctionType functionType50 = jSTypeRegistry38.createFunctionType(jSType47, node49);
        boolean boolean52 = functionType50.hasOwnProperty("hi!");
        functionType33.setPrototypeBasedOn((com.google.javascript.rhino.jstype.ObjectType) functionType50);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable54 = functionType33.getCtorImplementedInterfaces();
        com.google.javascript.rhino.ErrorReporter errorReporter55 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry57 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter55, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative58 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray59 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative58 };
        com.google.javascript.rhino.jstype.JSType jSType60 = jSTypeRegistry57.createUnionType(jSTypeNativeArray59);
        com.google.javascript.rhino.ErrorReporter errorReporter61 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry63 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter61, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative64 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray65 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative64 };
        com.google.javascript.rhino.jstype.JSType jSType66 = jSTypeRegistry63.createUnionType(jSTypeNativeArray65);
        com.google.javascript.rhino.Node node68 = new com.google.javascript.rhino.Node((-1));
        com.google.javascript.rhino.jstype.FunctionType functionType69 = jSTypeRegistry57.createFunctionType(jSType66, node68);
        boolean boolean71 = functionType69.hasOwnProperty("hi!");
        com.google.javascript.rhino.ErrorReporter errorReporter72 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry74 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter72, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative75 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray76 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative75 };
        com.google.javascript.rhino.jstype.JSType jSType77 = jSTypeRegistry74.createUnionType(jSTypeNativeArray76);
        com.google.javascript.rhino.ErrorReporter errorReporter78 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry80 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter78, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative81 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray82 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative81 };
        com.google.javascript.rhino.jstype.JSType jSType83 = jSTypeRegistry80.createUnionType(jSTypeNativeArray82);
        com.google.javascript.rhino.Node node85 = new com.google.javascript.rhino.Node((-1));
        com.google.javascript.rhino.jstype.FunctionType functionType86 = jSTypeRegistry74.createFunctionType(jSType83, node85);
        boolean boolean88 = functionType86.hasOwnProperty("hi!");
        functionType69.setPrototypeBasedOn((com.google.javascript.rhino.jstype.ObjectType) functionType86);
        com.google.javascript.rhino.jstype.JSType jSType90 = functionType33.getLeastSupertype((com.google.javascript.rhino.jstype.JSType) functionType69);
        com.google.javascript.rhino.jstype.JSType.TypePair typePair91 = functionType14.getTypesUnderShallowInequality((com.google.javascript.rhino.jstype.JSType) functionType33);
        boolean boolean92 = functionType14.hasCachedValues();
        org.junit.Assert.assertTrue("'" + jSTypeNative3 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative3.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray4);
        org.junit.Assert.assertNotNull(jSType5);
        org.junit.Assert.assertTrue("'" + jSTypeNative9 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative9.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray10);
        org.junit.Assert.assertNotNull(jSType11);
        org.junit.Assert.assertNotNull(functionType14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + jSTypeNative22 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative22.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray23);
        org.junit.Assert.assertNotNull(jSType24);
        org.junit.Assert.assertTrue("'" + jSTypeNative28 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative28.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray29);
        org.junit.Assert.assertNotNull(jSType30);
        org.junit.Assert.assertNotNull(functionType33);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + jSTypeNative39 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative39.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray40);
        org.junit.Assert.assertNotNull(jSType41);
        org.junit.Assert.assertTrue("'" + jSTypeNative45 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative45.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray46);
        org.junit.Assert.assertNotNull(jSType47);
        org.junit.Assert.assertNotNull(functionType50);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertNotNull(objectTypeIterable54);
        org.junit.Assert.assertTrue("'" + jSTypeNative58 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative58.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray59);
        org.junit.Assert.assertNotNull(jSType60);
        org.junit.Assert.assertTrue("'" + jSTypeNative64 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative64.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray65);
        org.junit.Assert.assertNotNull(jSType66);
        org.junit.Assert.assertNotNull(functionType69);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
        org.junit.Assert.assertTrue("'" + jSTypeNative75 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative75.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray76);
        org.junit.Assert.assertNotNull(jSType77);
        org.junit.Assert.assertTrue("'" + jSTypeNative81 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative81.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray82);
        org.junit.Assert.assertNotNull(jSType83);
        org.junit.Assert.assertNotNull(functionType86);
        org.junit.Assert.assertTrue("'" + boolean88 + "' != '" + false + "'", boolean88 == false);
        org.junit.Assert.assertNotNull(jSType90);
        org.junit.Assert.assertNotNull(typePair91);
        org.junit.Assert.assertTrue("'" + boolean92 + "' != '" + false + "'", boolean92 == false);
    }
}

