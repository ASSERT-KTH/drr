import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        int int0 = com.google.javascript.rhino.Node.ATTRIBUTE_FLAG;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        java.lang.String str1 = com.google.javascript.rhino.Token.name(0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "EOF" + "'", str1.equals("EOF"));
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.jstype.JSType jSType4 = null;
        try {
            jSTypeRegistry2.overwriteDeclaredType("EOF", jSType4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.EVAL_ERROR_FUNCTION_TYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.EVAL_ERROR_FUNCTION_TYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.EVAL_ERROR_FUNCTION_TYPE));
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        com.google.javascript.jscomp.SourceFile sourceFile0 = null;
        try {
            com.google.javascript.jscomp.JsAst jsAst1 = new com.google.javascript.jscomp.JsAst(sourceFile0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        com.google.javascript.rhino.jstype.JSType jSType0 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType1 = com.google.javascript.rhino.jstype.ObjectType.cast(jSType0);
        org.junit.Assert.assertNull(objectType1);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        int int0 = com.google.javascript.rhino.Token.FINALLY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 121 + "'", int0 == 121);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention0 = new com.google.javascript.jscomp.DefaultCodingConvention();
        com.google.javascript.rhino.Node node1 = null;
        try {
            boolean boolean2 = defaultCodingConvention0.isOptionalParameter(node1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        int int0 = com.google.javascript.rhino.Context.VERSION_1_3;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 130 + "'", int0 == 130);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        int int0 = com.google.javascript.rhino.Node.LASTUSE_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 24 + "'", int0 == 24);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        int int0 = com.google.javascript.rhino.FunctionNode.FUNCTION_EXPRESSION;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.ARRAY_FUNCTION_TYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.ARRAY_FUNCTION_TYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.ARRAY_FUNCTION_TYPE));
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        int int0 = com.google.javascript.rhino.ScriptOrFnNode.DUPLICATE_CONST;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + (-2) + "'", int0 == (-2));
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        int int0 = com.google.javascript.rhino.Context.VERSION_1_0;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 100 + "'", int0 == 100);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.LEAST_FUNCTION_TYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.LEAST_FUNCTION_TYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.LEAST_FUNCTION_TYPE));
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        com.google.javascript.jscomp.DiagnosticGroups diagnosticGroups0 = new com.google.javascript.jscomp.DiagnosticGroups();
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        int int0 = com.google.javascript.rhino.Token.ASSIGN_BITAND;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 89 + "'", int0 == 89);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = null;
        com.google.javascript.jscomp.DiagnosticGroups.FILEOVERVIEW_JSDOC = diagnosticGroup0;
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative3 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray4 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative3 };
        com.google.javascript.rhino.jstype.JSType jSType5 = jSTypeRegistry2.createUnionType(jSTypeNativeArray4);
        com.google.javascript.rhino.ErrorReporter errorReporter6 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry8 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter6, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative9 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray10 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative9 };
        com.google.javascript.rhino.jstype.JSType jSType11 = jSTypeRegistry8.createUnionType(jSTypeNativeArray10);
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node((-1));
        com.google.javascript.rhino.jstype.FunctionType functionType14 = jSTypeRegistry2.createFunctionType(jSType11, node13);
        com.google.javascript.rhino.ErrorReporter errorReporter15 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry17 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter15, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative18 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray19 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative18 };
        com.google.javascript.rhino.jstype.JSType jSType20 = jSTypeRegistry17.createUnionType(jSTypeNativeArray19);
        com.google.javascript.rhino.ErrorReporter errorReporter21 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry23 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter21, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative24 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray25 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative24 };
        com.google.javascript.rhino.jstype.JSType jSType26 = jSTypeRegistry23.createUnionType(jSTypeNativeArray25);
        com.google.javascript.rhino.Node node28 = new com.google.javascript.rhino.Node((-1));
        com.google.javascript.rhino.jstype.FunctionType functionType29 = jSTypeRegistry17.createFunctionType(jSType26, node28);
        com.google.javascript.rhino.ErrorReporter errorReporter30 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry32 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter30, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative33 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray34 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative33 };
        com.google.javascript.rhino.jstype.JSType jSType35 = jSTypeRegistry32.createUnionType(jSTypeNativeArray34);
        com.google.javascript.rhino.ErrorReporter errorReporter36 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry38 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter36, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative39 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray40 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative39 };
        com.google.javascript.rhino.jstype.JSType jSType41 = jSTypeRegistry38.createUnionType(jSTypeNativeArray40);
        com.google.javascript.rhino.Node node43 = new com.google.javascript.rhino.Node((-1));
        com.google.javascript.rhino.jstype.FunctionType functionType44 = jSTypeRegistry32.createFunctionType(jSType41, node43);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray45 = new com.google.javascript.rhino.jstype.JSType[] { jSType41 };
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList46 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean47 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList46, jSTypeArray45);
        com.google.javascript.rhino.Node node48 = jSTypeRegistry17.createParametersWithVarArgs((java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList46);
        com.google.javascript.rhino.ErrorReporter errorReporter49 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry51 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter49, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative52 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray53 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative52 };
        com.google.javascript.rhino.jstype.JSType jSType54 = jSTypeRegistry51.createUnionType(jSTypeNativeArray53);
        com.google.javascript.rhino.ErrorReporter errorReporter55 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry57 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter55, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative58 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray59 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative58 };
        com.google.javascript.rhino.jstype.JSType jSType60 = jSTypeRegistry57.createUnionType(jSTypeNativeArray59);
        com.google.javascript.rhino.Node node62 = new com.google.javascript.rhino.Node((-1));
        com.google.javascript.rhino.jstype.FunctionType functionType63 = jSTypeRegistry51.createFunctionType(jSType60, node62);
        try {
            node13.replaceChild(node48, node62);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + jSTypeNative3 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative3.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray4);
        org.junit.Assert.assertNotNull(jSType5);
        org.junit.Assert.assertTrue("'" + jSTypeNative9 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative9.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray10);
        org.junit.Assert.assertNotNull(jSType11);
        org.junit.Assert.assertNotNull(functionType14);
        org.junit.Assert.assertTrue("'" + jSTypeNative18 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative18.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray19);
        org.junit.Assert.assertNotNull(jSType20);
        org.junit.Assert.assertTrue("'" + jSTypeNative24 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative24.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray25);
        org.junit.Assert.assertNotNull(jSType26);
        org.junit.Assert.assertNotNull(functionType29);
        org.junit.Assert.assertTrue("'" + jSTypeNative33 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative33.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray34);
        org.junit.Assert.assertNotNull(jSType35);
        org.junit.Assert.assertTrue("'" + jSTypeNative39 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative39.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray40);
        org.junit.Assert.assertNotNull(jSType41);
        org.junit.Assert.assertNotNull(functionType44);
        org.junit.Assert.assertNotNull(jSTypeArray45);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
        org.junit.Assert.assertNotNull(node48);
        org.junit.Assert.assertTrue("'" + jSTypeNative52 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative52.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray53);
        org.junit.Assert.assertNotNull(jSType54);
        org.junit.Assert.assertTrue("'" + jSTypeNative58 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative58.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray59);
        org.junit.Assert.assertNotNull(jSType60);
        org.junit.Assert.assertNotNull(functionType63);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.RANGE_ERROR_FUNCTION_TYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.RANGE_ERROR_FUNCTION_TYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.RANGE_ERROR_FUNCTION_TYPE));
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        int int0 = com.google.javascript.rhino.Token.FOR;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 115 + "'", int0 == 115);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        int int0 = com.google.javascript.rhino.Token.TO_DOUBLE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 146 + "'", int0 == 146);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        int int0 = com.google.javascript.rhino.Node.VAR_ARGS_NAME;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 29 + "'", int0 == 29);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative3 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray4 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative3 };
        com.google.javascript.rhino.jstype.JSType jSType5 = jSTypeRegistry2.createUnionType(jSTypeNativeArray4);
        com.google.javascript.rhino.ErrorReporter errorReporter6 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry8 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter6, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative9 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray10 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative9 };
        com.google.javascript.rhino.jstype.JSType jSType11 = jSTypeRegistry8.createUnionType(jSTypeNativeArray10);
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node((-1));
        com.google.javascript.rhino.jstype.FunctionType functionType14 = jSTypeRegistry2.createFunctionType(jSType11, node13);
        boolean boolean16 = functionType14.hasOwnProperty("hi!");
        com.google.javascript.rhino.ErrorReporter errorReporter17 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry19 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter17, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative20 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray21 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative20 };
        com.google.javascript.rhino.jstype.JSType jSType22 = jSTypeRegistry19.createUnionType(jSTypeNativeArray21);
        com.google.javascript.rhino.ErrorReporter errorReporter23 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry25 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter23, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative26 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray27 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative26 };
        com.google.javascript.rhino.jstype.JSType jSType28 = jSTypeRegistry25.createUnionType(jSTypeNativeArray27);
        com.google.javascript.rhino.Node node30 = new com.google.javascript.rhino.Node((-1));
        com.google.javascript.rhino.jstype.FunctionType functionType31 = jSTypeRegistry19.createFunctionType(jSType28, node30);
        boolean boolean33 = functionType31.hasOwnProperty("hi!");
        functionType14.setPrototypeBasedOn((com.google.javascript.rhino.jstype.ObjectType) functionType31);
        try {
            boolean boolean35 = functionType31.hasUnknownSupertype();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + jSTypeNative3 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative3.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray4);
        org.junit.Assert.assertNotNull(jSType5);
        org.junit.Assert.assertTrue("'" + jSTypeNative9 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative9.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray10);
        org.junit.Assert.assertNotNull(jSType11);
        org.junit.Assert.assertNotNull(functionType14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + jSTypeNative20 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative20.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray21);
        org.junit.Assert.assertNotNull(jSType22);
        org.junit.Assert.assertTrue("'" + jSTypeNative26 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative26.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray27);
        org.junit.Assert.assertNotNull(jSType28);
        org.junit.Assert.assertNotNull(functionType31);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.U2U_CONSTRUCTOR_TYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.U2U_CONSTRUCTOR_TYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.U2U_CONSTRUCTOR_TYPE));
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        int int0 = com.google.javascript.rhino.Token.ELLIPSIS;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 305 + "'", int0 == 305);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        int int0 = com.google.javascript.rhino.Token.XML;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 141 + "'", int0 == 141);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.DATE_FUNCTION_TYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.DATE_FUNCTION_TYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.DATE_FUNCTION_TYPE));
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        int int0 = com.google.javascript.rhino.Token.LP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 83 + "'", int0 == 83);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.ErrorReporter errorReporter4 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry6 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter4, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative7 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray8 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative7 };
        com.google.javascript.rhino.jstype.JSType jSType9 = jSTypeRegistry6.createUnionType(jSTypeNativeArray8);
        com.google.javascript.rhino.ErrorReporter errorReporter10 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry12 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter10, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative13 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray14 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative13 };
        com.google.javascript.rhino.jstype.JSType jSType15 = jSTypeRegistry12.createUnionType(jSTypeNativeArray14);
        com.google.javascript.rhino.Node node17 = new com.google.javascript.rhino.Node((-1));
        com.google.javascript.rhino.jstype.FunctionType functionType18 = jSTypeRegistry6.createFunctionType(jSType15, node17);
        try {
            jSTypeRegistry2.overwriteDeclaredType("EOF", (com.google.javascript.rhino.jstype.JSType) functionType18);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertTrue("'" + jSTypeNative7 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative7.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray8);
        org.junit.Assert.assertNotNull(jSType9);
        org.junit.Assert.assertTrue("'" + jSTypeNative13 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative13.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray14);
        org.junit.Assert.assertNotNull(jSType15);
        org.junit.Assert.assertNotNull(functionType18);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative3 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray4 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative3 };
        com.google.javascript.rhino.jstype.JSType jSType5 = jSTypeRegistry2.createUnionType(jSTypeNativeArray4);
        com.google.javascript.rhino.ErrorReporter errorReporter6 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry8 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter6, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative9 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray10 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative9 };
        com.google.javascript.rhino.jstype.JSType jSType11 = jSTypeRegistry8.createUnionType(jSTypeNativeArray10);
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node((-1));
        com.google.javascript.rhino.jstype.FunctionType functionType14 = jSTypeRegistry2.createFunctionType(jSType11, node13);
        int int15 = node13.getLineno();
        com.google.javascript.rhino.ErrorReporter errorReporter16 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry18 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter16, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative19 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray20 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative19 };
        com.google.javascript.rhino.jstype.JSType jSType21 = jSTypeRegistry18.createUnionType(jSTypeNativeArray20);
        com.google.javascript.rhino.ErrorReporter errorReporter22 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry24 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter22, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative25 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray26 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative25 };
        com.google.javascript.rhino.jstype.JSType jSType27 = jSTypeRegistry24.createUnionType(jSTypeNativeArray26);
        com.google.javascript.rhino.Node node29 = new com.google.javascript.rhino.Node((-1));
        com.google.javascript.rhino.jstype.FunctionType functionType30 = jSTypeRegistry18.createFunctionType(jSType27, node29);
        com.google.javascript.rhino.ErrorReporter errorReporter31 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry33 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter31, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative34 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray35 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative34 };
        com.google.javascript.rhino.jstype.JSType jSType36 = jSTypeRegistry33.createUnionType(jSTypeNativeArray35);
        com.google.javascript.rhino.ErrorReporter errorReporter37 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry39 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter37, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative40 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray41 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative40 };
        com.google.javascript.rhino.jstype.JSType jSType42 = jSTypeRegistry39.createUnionType(jSTypeNativeArray41);
        com.google.javascript.rhino.Node node44 = new com.google.javascript.rhino.Node((-1));
        com.google.javascript.rhino.jstype.FunctionType functionType45 = jSTypeRegistry33.createFunctionType(jSType42, node44);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray46 = new com.google.javascript.rhino.jstype.JSType[] { jSType42 };
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList47 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean48 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList47, jSTypeArray46);
        com.google.javascript.rhino.Node node49 = jSTypeRegistry18.createParametersWithVarArgs((java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList47);
        try {
            com.google.javascript.rhino.Node node50 = node13.getChildBefore(node49);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + jSTypeNative3 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative3.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray4);
        org.junit.Assert.assertNotNull(jSType5);
        org.junit.Assert.assertTrue("'" + jSTypeNative9 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative9.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray10);
        org.junit.Assert.assertNotNull(jSType11);
        org.junit.Assert.assertNotNull(functionType14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + jSTypeNative19 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative19.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray20);
        org.junit.Assert.assertNotNull(jSType21);
        org.junit.Assert.assertTrue("'" + jSTypeNative25 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative25.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray26);
        org.junit.Assert.assertNotNull(jSType27);
        org.junit.Assert.assertNotNull(functionType30);
        org.junit.Assert.assertTrue("'" + jSTypeNative34 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative34.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray35);
        org.junit.Assert.assertNotNull(jSType36);
        org.junit.Assert.assertTrue("'" + jSTypeNative40 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative40.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray41);
        org.junit.Assert.assertNotNull(jSType42);
        org.junit.Assert.assertNotNull(functionType45);
        org.junit.Assert.assertNotNull(jSTypeArray46);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + true + "'", boolean48 == true);
        org.junit.Assert.assertNotNull(node49);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative3 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray4 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative3 };
        com.google.javascript.rhino.jstype.JSType jSType5 = jSTypeRegistry2.createUnionType(jSTypeNativeArray4);
        com.google.javascript.rhino.ErrorReporter errorReporter6 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry8 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter6, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative9 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray10 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative9 };
        com.google.javascript.rhino.jstype.JSType jSType11 = jSTypeRegistry8.createUnionType(jSTypeNativeArray10);
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node((-1));
        com.google.javascript.rhino.jstype.FunctionType functionType14 = jSTypeRegistry2.createFunctionType(jSType11, node13);
        com.google.javascript.rhino.ErrorReporter errorReporter15 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry17 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter15, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative18 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray19 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative18 };
        com.google.javascript.rhino.jstype.JSType jSType20 = jSTypeRegistry17.createUnionType(jSTypeNativeArray19);
        com.google.javascript.rhino.ErrorReporter errorReporter21 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry23 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter21, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative24 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray25 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative24 };
        com.google.javascript.rhino.jstype.JSType jSType26 = jSTypeRegistry23.createUnionType(jSTypeNativeArray25);
        com.google.javascript.rhino.Node node28 = new com.google.javascript.rhino.Node((-1));
        com.google.javascript.rhino.jstype.FunctionType functionType29 = jSTypeRegistry17.createFunctionType(jSType26, node28);
        boolean boolean31 = functionType29.hasOwnProperty("hi!");
        com.google.javascript.rhino.jstype.FunctionPrototypeType functionPrototypeType32 = null;
        boolean boolean33 = functionType29.setPrototype(functionPrototypeType32);
        try {
            boolean boolean34 = jSType11.differsFrom((com.google.javascript.rhino.jstype.JSType) functionPrototypeType32);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + jSTypeNative3 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative3.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray4);
        org.junit.Assert.assertNotNull(jSType5);
        org.junit.Assert.assertTrue("'" + jSTypeNative9 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative9.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray10);
        org.junit.Assert.assertNotNull(jSType11);
        org.junit.Assert.assertNotNull(functionType14);
        org.junit.Assert.assertTrue("'" + jSTypeNative18 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative18.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray19);
        org.junit.Assert.assertNotNull(jSType20);
        org.junit.Assert.assertTrue("'" + jSTypeNative24 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative24.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray25);
        org.junit.Assert.assertNotNull(jSType26);
        org.junit.Assert.assertNotNull(functionType29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        int int0 = com.google.javascript.rhino.Token.LAST_BYTECODE_TOKEN;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 76 + "'", int0 == 76);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        int int0 = com.google.javascript.rhino.Node.NAME_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 33 + "'", int0 == 33);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        com.google.javascript.rhino.EvaluatorException evaluatorException5 = new com.google.javascript.rhino.EvaluatorException("", "", 100, "hi!", (int) (short) 1);
        try {
            evaluatorException5.initColumnNumber((int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        int int0 = com.google.javascript.rhino.Token.REF_NAME;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 75 + "'", int0 == 75);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.ErrorReporter errorReporter4 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry6 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter4, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative7 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray8 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative7 };
        com.google.javascript.rhino.jstype.JSType jSType9 = jSTypeRegistry6.createUnionType(jSTypeNativeArray8);
        com.google.javascript.rhino.ErrorReporter errorReporter10 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry12 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter10, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative13 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray14 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative13 };
        com.google.javascript.rhino.jstype.JSType jSType15 = jSTypeRegistry12.createUnionType(jSTypeNativeArray14);
        com.google.javascript.rhino.Node node17 = new com.google.javascript.rhino.Node((-1));
        com.google.javascript.rhino.jstype.FunctionType functionType18 = jSTypeRegistry6.createFunctionType(jSType15, node17);
        boolean boolean20 = functionType18.hasOwnProperty("hi!");
        com.google.javascript.rhino.ErrorReporter errorReporter21 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry23 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter21, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative24 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray25 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative24 };
        com.google.javascript.rhino.jstype.JSType jSType26 = jSTypeRegistry23.createUnionType(jSTypeNativeArray25);
        com.google.javascript.rhino.ErrorReporter errorReporter27 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry29 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter27, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative30 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray31 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative30 };
        com.google.javascript.rhino.jstype.JSType jSType32 = jSTypeRegistry29.createUnionType(jSTypeNativeArray31);
        com.google.javascript.rhino.Node node34 = new com.google.javascript.rhino.Node((-1));
        com.google.javascript.rhino.jstype.FunctionType functionType35 = jSTypeRegistry23.createFunctionType(jSType32, node34);
        boolean boolean37 = functionType35.hasOwnProperty("hi!");
        functionType18.setPrototypeBasedOn((com.google.javascript.rhino.jstype.ObjectType) functionType35);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable39 = functionType18.getCtorImplementedInterfaces();
        com.google.javascript.rhino.ErrorReporter errorReporter40 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry42 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter40, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative43 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray44 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative43 };
        com.google.javascript.rhino.jstype.JSType jSType45 = jSTypeRegistry42.createUnionType(jSTypeNativeArray44);
        com.google.javascript.rhino.ErrorReporter errorReporter46 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry48 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter46, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative49 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray50 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative49 };
        com.google.javascript.rhino.jstype.JSType jSType51 = jSTypeRegistry48.createUnionType(jSTypeNativeArray50);
        com.google.javascript.rhino.Node node53 = new com.google.javascript.rhino.Node((-1));
        com.google.javascript.rhino.jstype.FunctionType functionType54 = jSTypeRegistry42.createFunctionType(jSType51, node53);
        boolean boolean56 = functionType54.hasOwnProperty("hi!");
        com.google.javascript.rhino.ErrorReporter errorReporter57 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry59 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter57, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative60 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray61 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative60 };
        com.google.javascript.rhino.jstype.JSType jSType62 = jSTypeRegistry59.createUnionType(jSTypeNativeArray61);
        com.google.javascript.rhino.ErrorReporter errorReporter63 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry65 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter63, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative66 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray67 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative66 };
        com.google.javascript.rhino.jstype.JSType jSType68 = jSTypeRegistry65.createUnionType(jSTypeNativeArray67);
        com.google.javascript.rhino.Node node70 = new com.google.javascript.rhino.Node((-1));
        com.google.javascript.rhino.jstype.FunctionType functionType71 = jSTypeRegistry59.createFunctionType(jSType68, node70);
        boolean boolean73 = functionType71.hasOwnProperty("hi!");
        functionType54.setPrototypeBasedOn((com.google.javascript.rhino.jstype.ObjectType) functionType71);
        com.google.javascript.rhino.jstype.JSType jSType75 = functionType18.getLeastSupertype((com.google.javascript.rhino.jstype.JSType) functionType54);
        try {
            jSTypeRegistry2.overwriteDeclaredType("EOF", (com.google.javascript.rhino.jstype.JSType) functionType18);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertTrue("'" + jSTypeNative7 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative7.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray8);
        org.junit.Assert.assertNotNull(jSType9);
        org.junit.Assert.assertTrue("'" + jSTypeNative13 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative13.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray14);
        org.junit.Assert.assertNotNull(jSType15);
        org.junit.Assert.assertNotNull(functionType18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + jSTypeNative24 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative24.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray25);
        org.junit.Assert.assertNotNull(jSType26);
        org.junit.Assert.assertTrue("'" + jSTypeNative30 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative30.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray31);
        org.junit.Assert.assertNotNull(jSType32);
        org.junit.Assert.assertNotNull(functionType35);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(objectTypeIterable39);
        org.junit.Assert.assertTrue("'" + jSTypeNative43 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative43.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray44);
        org.junit.Assert.assertNotNull(jSType45);
        org.junit.Assert.assertTrue("'" + jSTypeNative49 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative49.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray50);
        org.junit.Assert.assertNotNull(jSType51);
        org.junit.Assert.assertNotNull(functionType54);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertTrue("'" + jSTypeNative60 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative60.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray61);
        org.junit.Assert.assertNotNull(jSType62);
        org.junit.Assert.assertTrue("'" + jSTypeNative66 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative66.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray67);
        org.junit.Assert.assertNotNull(jSType68);
        org.junit.Assert.assertNotNull(functionType71);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
        org.junit.Assert.assertNotNull(jSType75);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        int int0 = com.google.javascript.rhino.Node.SPECIALCALL_EVAL;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        int int0 = com.google.javascript.rhino.Context.FEATURE_STRICT_MODE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 11 + "'", int0 == 11);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        com.google.javascript.jscomp.AnonymousFunctionNamingPolicy anonymousFunctionNamingPolicy0 = com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.UNMAPPED;
        org.junit.Assert.assertTrue("'" + anonymousFunctionNamingPolicy0 + "' != '" + com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.UNMAPPED + "'", anonymousFunctionNamingPolicy0.equals(com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.UNMAPPED));
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        int int0 = com.google.javascript.rhino.Node.LOCALCOUNT_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 21 + "'", int0 == 21);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative3 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray4 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative3 };
        com.google.javascript.rhino.jstype.JSType jSType5 = jSTypeRegistry2.createUnionType(jSTypeNativeArray4);
        com.google.javascript.rhino.ErrorReporter errorReporter6 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry8 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter6, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative9 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray10 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative9 };
        com.google.javascript.rhino.jstype.JSType jSType11 = jSTypeRegistry8.createUnionType(jSTypeNativeArray10);
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node((-1));
        com.google.javascript.rhino.jstype.FunctionType functionType14 = jSTypeRegistry2.createFunctionType(jSType11, node13);
        boolean boolean16 = functionType14.hasOwnProperty("hi!");
        boolean boolean17 = functionType14.isUnknownType();
        org.junit.Assert.assertTrue("'" + jSTypeNative3 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative3.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray4);
        org.junit.Assert.assertNotNull(jSType5);
        org.junit.Assert.assertTrue("'" + jSTypeNative9 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative9.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray10);
        org.junit.Assert.assertNotNull(jSType11);
        org.junit.Assert.assertNotNull(functionType14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        boolean boolean1 = com.google.javascript.rhino.Context.isValidLanguageVersion(146);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        com.google.javascript.jscomp.DiagnosticType diagnosticType2 = com.google.javascript.jscomp.DiagnosticType.disabled("hi!", "hi!");
        org.junit.Assert.assertNotNull(diagnosticType2);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        int int0 = com.google.javascript.rhino.Node.NO_SIDE_EFFECTS;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 15 + "'", int0 == 15);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        try {
            com.google.javascript.rhino.EcmaError ecmaError2 = com.google.javascript.rhino.ScriptRuntime.typeError1("", "hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property ");
        } catch (java.lang.RuntimeException e) {
        }
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        java.io.InputStream inputStream1 = null;
        try {
            com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromInputStream("hi!", inputStream1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test049() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test049");
//        com.google.javascript.rhino.Context context0 = com.google.javascript.rhino.Context.getCurrentContext();
//        org.junit.Assert.assertNull(context0);
//    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative3 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray4 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative3 };
        com.google.javascript.rhino.jstype.JSType jSType5 = jSTypeRegistry2.createUnionType(jSTypeNativeArray4);
        com.google.javascript.rhino.ErrorReporter errorReporter6 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry8 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter6, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative9 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray10 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative9 };
        com.google.javascript.rhino.jstype.JSType jSType11 = jSTypeRegistry8.createUnionType(jSTypeNativeArray10);
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node((-1));
        com.google.javascript.rhino.jstype.FunctionType functionType14 = jSTypeRegistry2.createFunctionType(jSType11, node13);
        com.google.javascript.rhino.ErrorReporter errorReporter15 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry17 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter15, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative18 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray19 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative18 };
        com.google.javascript.rhino.jstype.JSType jSType20 = jSTypeRegistry17.createUnionType(jSTypeNativeArray19);
        com.google.javascript.rhino.ErrorReporter errorReporter21 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry23 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter21, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative24 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray25 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative24 };
        com.google.javascript.rhino.jstype.JSType jSType26 = jSTypeRegistry23.createUnionType(jSTypeNativeArray25);
        com.google.javascript.rhino.Node node28 = new com.google.javascript.rhino.Node((-1));
        com.google.javascript.rhino.jstype.FunctionType functionType29 = jSTypeRegistry17.createFunctionType(jSType26, node28);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray30 = new com.google.javascript.rhino.jstype.JSType[] { jSType26 };
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList31 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean32 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList31, jSTypeArray30);
        com.google.javascript.rhino.Node node33 = jSTypeRegistry2.createParametersWithVarArgs((java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList31);
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope34 = null;
        com.google.javascript.rhino.jstype.JSType jSType39 = jSTypeRegistry2.getType(jSTypeStaticScope34, "hi!", "EOF", (int) '#', 15);
        org.junit.Assert.assertTrue("'" + jSTypeNative3 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative3.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray4);
        org.junit.Assert.assertNotNull(jSType5);
        org.junit.Assert.assertTrue("'" + jSTypeNative9 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative9.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray10);
        org.junit.Assert.assertNotNull(jSType11);
        org.junit.Assert.assertNotNull(functionType14);
        org.junit.Assert.assertTrue("'" + jSTypeNative18 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative18.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray19);
        org.junit.Assert.assertNotNull(jSType20);
        org.junit.Assert.assertTrue("'" + jSTypeNative24 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative24.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray25);
        org.junit.Assert.assertNotNull(jSType26);
        org.junit.Assert.assertNotNull(functionType29);
        org.junit.Assert.assertNotNull(jSTypeArray30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNotNull(node33);
        org.junit.Assert.assertNotNull(jSType39);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        int int0 = com.google.javascript.rhino.Token.ARRAYLIT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 63 + "'", int0 == 63);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        int int0 = com.google.javascript.rhino.Token.SET;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 148 + "'", int0 == 148);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        com.google.javascript.rhino.ErrorReporter errorReporter2 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry4 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter2, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative5 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray6 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative5 };
        com.google.javascript.rhino.jstype.JSType jSType7 = jSTypeRegistry4.createUnionType(jSTypeNativeArray6);
        com.google.javascript.rhino.ErrorReporter errorReporter8 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry10 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter8, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative11 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray12 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative11 };
        com.google.javascript.rhino.jstype.JSType jSType13 = jSTypeRegistry10.createUnionType(jSTypeNativeArray12);
        com.google.javascript.rhino.Node node15 = new com.google.javascript.rhino.Node((-1));
        com.google.javascript.rhino.jstype.FunctionType functionType16 = jSTypeRegistry4.createFunctionType(jSType13, node15);
        com.google.javascript.rhino.Node node17 = new com.google.javascript.rhino.Node((int) ' ', node15);
        try {
            com.google.javascript.rhino.Node node20 = new com.google.javascript.rhino.Node(76, node15, 141, 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: new child has existing parent");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + jSTypeNative5 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative5.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray6);
        org.junit.Assert.assertNotNull(jSType7);
        org.junit.Assert.assertTrue("'" + jSTypeNative11 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative11.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray12);
        org.junit.Assert.assertNotNull(jSType13);
        org.junit.Assert.assertNotNull(functionType16);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        com.google.javascript.rhino.Node node1 = null;
        com.google.javascript.rhino.ErrorReporter errorReporter2 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry4 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter2, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative5 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray6 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative5 };
        com.google.javascript.rhino.jstype.JSType jSType7 = jSTypeRegistry4.createUnionType(jSTypeNativeArray6);
        com.google.javascript.rhino.ErrorReporter errorReporter8 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry10 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter8, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative11 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray12 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative11 };
        com.google.javascript.rhino.jstype.JSType jSType13 = jSTypeRegistry10.createUnionType(jSTypeNativeArray12);
        com.google.javascript.rhino.Node node15 = new com.google.javascript.rhino.Node((-1));
        com.google.javascript.rhino.jstype.FunctionType functionType16 = jSTypeRegistry4.createFunctionType(jSType13, node15);
        com.google.javascript.rhino.ErrorReporter errorReporter17 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry19 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter17, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative20 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray21 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative20 };
        com.google.javascript.rhino.jstype.JSType jSType22 = jSTypeRegistry19.createUnionType(jSTypeNativeArray21);
        com.google.javascript.rhino.ErrorReporter errorReporter23 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry25 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter23, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative26 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray27 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative26 };
        com.google.javascript.rhino.jstype.JSType jSType28 = jSTypeRegistry25.createUnionType(jSTypeNativeArray27);
        com.google.javascript.rhino.Node node30 = new com.google.javascript.rhino.Node((-1));
        com.google.javascript.rhino.jstype.FunctionType functionType31 = jSTypeRegistry19.createFunctionType(jSType28, node30);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray32 = new com.google.javascript.rhino.jstype.JSType[] { jSType28 };
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList33 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean34 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList33, jSTypeArray32);
        com.google.javascript.rhino.Node node35 = jSTypeRegistry4.createParametersWithVarArgs((java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList33);
        try {
            com.google.javascript.rhino.Node node36 = new com.google.javascript.rhino.Node((-2), node1, node35);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + jSTypeNative5 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative5.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray6);
        org.junit.Assert.assertNotNull(jSType7);
        org.junit.Assert.assertTrue("'" + jSTypeNative11 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative11.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray12);
        org.junit.Assert.assertNotNull(jSType13);
        org.junit.Assert.assertNotNull(functionType16);
        org.junit.Assert.assertTrue("'" + jSTypeNative20 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative20.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray21);
        org.junit.Assert.assertNotNull(jSType22);
        org.junit.Assert.assertTrue("'" + jSTypeNative26 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative26.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray27);
        org.junit.Assert.assertNotNull(jSType28);
        org.junit.Assert.assertNotNull(functionType31);
        org.junit.Assert.assertNotNull(jSTypeArray32);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertNotNull(node35);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        java.nio.charset.Charset charset1 = null;
        com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromFile("", charset1);
        java.lang.String str3 = sourceFile2.toString();
        org.junit.Assert.assertNotNull(sourceFile2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        int int0 = com.google.javascript.rhino.Token.REF_MEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 73 + "'", int0 == 73);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        int int0 = com.google.javascript.rhino.Context.FEATURE_E4X;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 6 + "'", int0 == 6);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        int int0 = com.google.javascript.rhino.Token.BREAK;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 116 + "'", int0 == 116);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        int int0 = com.google.javascript.rhino.Token.NEG;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 29 + "'", int0 == 29);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.removeUnusedPrototypeProperties;
        compilerOptions0.removeEmptyFunctions = true;
        compilerOptions0.removeUnusedVars = false;
        compilerOptions0.setColorizeErrorOutput(true);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        int int0 = com.google.javascript.rhino.Token.DEFAULTNAMESPACE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 70 + "'", int0 == 70);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = null;
        com.google.javascript.jscomp.JSModule[] jSModuleArray3 = new com.google.javascript.jscomp.JSModule[] {};
        com.google.javascript.jscomp.CompilerOptions compilerOptions4 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean5 = compilerOptions4.removeUnusedPrototypeProperties;
        compilerOptions4.removeEmptyFunctions = true;
        compilerOptions4.removeUnusedVars = false;
        try {
            com.google.javascript.jscomp.Result result10 = compiler1.compile(jSSourceFile2, jSModuleArray3, compilerOptions4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jSModuleArray3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        com.google.javascript.jscomp.SourceAst sourceAst0 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(sourceAst0, "", true);
        try {
            com.google.javascript.jscomp.CompilerInput compilerInput5 = new com.google.javascript.jscomp.CompilerInput(sourceAst0, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        java.io.InputStream inputStream1 = null;
        try {
            com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromInputStream("hi!", inputStream1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        int int0 = com.google.javascript.rhino.Token.CONTINUE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 117 + "'", int0 == 117);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.removeUnusedPrototypeProperties;
        compilerOptions0.removeEmptyFunctions = true;
        compilerOptions0.removeUnusedVars = false;
        com.google.javascript.jscomp.CompilerOptions compilerOptions6 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel7 = compilerOptions6.checkMissingGetCssNameLevel;
        compilerOptions0.checkUnreachableCode = checkLevel7;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + checkLevel7 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel7.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        int int0 = com.google.javascript.rhino.Token.ASSIGN_ADD;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 93 + "'", int0 == 93);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        int int0 = com.google.javascript.rhino.Token.BITXOR;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.checkMissingGetCssNameLevel;
        compilerOptions0.inputDelimiter = "STRING hi!";
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        int int0 = com.google.javascript.rhino.Token.DOTDOT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 139 + "'", int0 == 139);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        java.lang.Double double0 = com.google.javascript.rhino.ScriptRuntime.NaNobj;
        org.junit.Assert.assertEquals((double) double0, Double.NaN, 0);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        java.lang.String str0 = com.google.javascript.rhino.Context.languageVersionProperty;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "language version" + "'", str0.equals("language version"));
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.STRING_TYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.STRING_TYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.STRING_TYPE));
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.markNoSideEffectCalls = true;
        java.util.Set<java.lang.String> strSet3 = null;
        compilerOptions0.stripNamePrefixes = strSet3;
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        com.google.javascript.jscomp.MessageFormatter messageFormatter0 = null;
        java.util.logging.Logger logger1 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager2 = new com.google.javascript.jscomp.LoggerErrorManager(messageFormatter0, logger1);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup3 = com.google.javascript.jscomp.DiagnosticGroups.CHECK_TYPES;
        com.google.javascript.jscomp.CompilerOptions compilerOptions4 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel5 = compilerOptions4.checkMissingGetCssNameLevel;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard6 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup3, checkLevel5);
        com.google.javascript.jscomp.JSError jSError7 = null;
        try {
            loggerErrorManager2.report(checkLevel5, jSError7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(diagnosticGroup3);
        org.junit.Assert.assertTrue("'" + checkLevel5 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel5.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative3 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray4 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative3 };
        com.google.javascript.rhino.jstype.JSType jSType5 = jSTypeRegistry2.createUnionType(jSTypeNativeArray4);
        com.google.javascript.rhino.ErrorReporter errorReporter6 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry8 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter6, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative9 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray10 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative9 };
        com.google.javascript.rhino.jstype.JSType jSType11 = jSTypeRegistry8.createUnionType(jSTypeNativeArray10);
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node((-1));
        com.google.javascript.rhino.jstype.FunctionType functionType14 = jSTypeRegistry2.createFunctionType(jSType11, node13);
        boolean boolean15 = functionType14.matchesInt32Context();
        try {
            boolean boolean16 = functionType14.hasUnknownSupertype();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + jSTypeNative3 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative3.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray4);
        org.junit.Assert.assertNotNull(jSType5);
        org.junit.Assert.assertTrue("'" + jSTypeNative9 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative9.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray10);
        org.junit.Assert.assertNotNull(jSType11);
        org.junit.Assert.assertNotNull(functionType14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative3 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray4 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative3 };
        com.google.javascript.rhino.jstype.JSType jSType5 = jSTypeRegistry2.createUnionType(jSTypeNativeArray4);
        com.google.javascript.rhino.ErrorReporter errorReporter6 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry8 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter6, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative9 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray10 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative9 };
        com.google.javascript.rhino.jstype.JSType jSType11 = jSTypeRegistry8.createUnionType(jSTypeNativeArray10);
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node((-1));
        com.google.javascript.rhino.jstype.FunctionType functionType14 = jSTypeRegistry2.createFunctionType(jSType11, node13);
        boolean boolean16 = functionType14.hasOwnProperty("hi!");
        com.google.javascript.rhino.ErrorReporter errorReporter17 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry19 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter17, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative20 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray21 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative20 };
        com.google.javascript.rhino.jstype.JSType jSType22 = jSTypeRegistry19.createUnionType(jSTypeNativeArray21);
        com.google.javascript.rhino.ErrorReporter errorReporter23 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry25 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter23, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative26 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray27 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative26 };
        com.google.javascript.rhino.jstype.JSType jSType28 = jSTypeRegistry25.createUnionType(jSTypeNativeArray27);
        com.google.javascript.rhino.Node node30 = new com.google.javascript.rhino.Node((-1));
        com.google.javascript.rhino.jstype.FunctionType functionType31 = jSTypeRegistry19.createFunctionType(jSType28, node30);
        boolean boolean33 = functionType31.hasOwnProperty("hi!");
        functionType14.setPrototypeBasedOn((com.google.javascript.rhino.jstype.ObjectType) functionType31);
        try {
            boolean boolean35 = functionType14.hasUnknownSupertype();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + jSTypeNative3 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative3.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray4);
        org.junit.Assert.assertNotNull(jSType5);
        org.junit.Assert.assertTrue("'" + jSTypeNative9 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative9.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray10);
        org.junit.Assert.assertNotNull(jSType11);
        org.junit.Assert.assertNotNull(functionType14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + jSTypeNative20 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative20.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray21);
        org.junit.Assert.assertNotNull(jSType22);
        org.junit.Assert.assertTrue("'" + jSTypeNative26 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative26.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray27);
        org.junit.Assert.assertNotNull(jSType28);
        org.junit.Assert.assertNotNull(functionType31);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        int int0 = com.google.javascript.rhino.Token.ASSIGN_LSH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 90 + "'", int0 == 90);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        com.google.javascript.rhino.jstype.JSTypeRegistry.ResolveMode resolveMode0 = com.google.javascript.rhino.jstype.JSTypeRegistry.ResolveMode.LAZY_NAMES;
        org.junit.Assert.assertTrue("'" + resolveMode0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeRegistry.ResolveMode.LAZY_NAMES + "'", resolveMode0.equals(com.google.javascript.rhino.jstype.JSTypeRegistry.ResolveMode.LAZY_NAMES));
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        int int0 = com.google.javascript.rhino.Token.ANNOTATION;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 300 + "'", int0 == 300);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        int int0 = com.google.javascript.rhino.Token.VAR;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 118 + "'", int0 == 118);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        int int0 = com.google.javascript.rhino.Context.FEATURE_STRICT_VARS;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 8 + "'", int0 == 8);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newString("hi!");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString((int) '#', "EOF");
        boolean boolean6 = node4.getBooleanProp(100);
        node1.addChildToBack(node4);
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        int int0 = com.google.javascript.rhino.Node.BRACELESS_TYPE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 40 + "'", int0 == 40);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        com.google.javascript.rhino.ErrorReporter errorReporter2 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry4 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter2, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative5 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray6 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative5 };
        com.google.javascript.rhino.jstype.JSType jSType7 = jSTypeRegistry4.createUnionType(jSTypeNativeArray6);
        com.google.javascript.rhino.ErrorReporter errorReporter8 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry10 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter8, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative11 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray12 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative11 };
        com.google.javascript.rhino.jstype.JSType jSType13 = jSTypeRegistry10.createUnionType(jSTypeNativeArray12);
        com.google.javascript.rhino.Node node15 = new com.google.javascript.rhino.Node((-1));
        com.google.javascript.rhino.jstype.FunctionType functionType16 = jSTypeRegistry4.createFunctionType(jSType13, node15);
        com.google.javascript.rhino.Node node17 = new com.google.javascript.rhino.Node((int) ' ', node15);
        com.google.javascript.rhino.Node node18 = new com.google.javascript.rhino.Node((int) ' ', node17);
        java.lang.String str22 = node17.toString(false, true, false);
        org.junit.Assert.assertTrue("'" + jSTypeNative5 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative5.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray6);
        org.junit.Assert.assertNotNull(jSType7);
        org.junit.Assert.assertTrue("'" + jSTypeNative11 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative11.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray12);
        org.junit.Assert.assertNotNull(jSType13);
        org.junit.Assert.assertNotNull(functionType16);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "TYPEOF" + "'", str22.equals("TYPEOF"));
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.Scope scope2 = compiler1.getTopScope();
        com.google.javascript.jscomp.Compiler.CodeBuilder codeBuilder3 = null;
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.Node.newString((int) '#', "EOF");
        boolean boolean9 = node7.getBooleanProp(100);
        try {
            compiler1.toSource(codeBuilder3, 2, node7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(scope2);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = null;
        com.google.javascript.jscomp.DiagnosticGroups.UNKNOWN_DEFINES = diagnosticGroup0;
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        int int0 = com.google.javascript.rhino.Node.FLAG_THIS_UNMODIFIED;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        int int0 = com.google.javascript.rhino.Token.RC;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 82 + "'", int0 == 82);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        java.io.File file0 = null;
        try {
            com.google.javascript.jscomp.JSSourceFile jSSourceFile1 = com.google.javascript.jscomp.JSSourceFile.fromFile(file0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.markNoSideEffectCalls = true;
        compilerOptions0.moveFunctionDeclarations = false;
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        int int0 = com.google.javascript.rhino.Node.LABEL_ID_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        int int0 = com.google.javascript.rhino.Token.LB;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 79 + "'", int0 == 79);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        try {
            com.google.javascript.rhino.EcmaError ecmaError2 = com.google.javascript.rhino.ScriptRuntime.typeError1("STRING hi!", "language version");
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property STRING hi!");
        } catch (java.lang.RuntimeException e) {
        }
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        com.google.javascript.jscomp.SourceAst sourceAst0 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(sourceAst0, "", true);
        try {
            com.google.javascript.jscomp.Region region5 = compilerInput3.getRegion((int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        java.io.File file0 = null;
        try {
            com.google.javascript.jscomp.SourceFile sourceFile1 = com.google.javascript.jscomp.SourceFile.fromFile(file0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.common.collect.Multimap<com.google.javascript.jscomp.CustomPassExecutionTime, com.google.javascript.jscomp.CompilerPass> customPassExecutionTimeMultimap1 = null;
        compilerOptions0.customPasses = customPassExecutionTimeMultimap1;
        boolean boolean3 = compilerOptions0.inlineConstantVars;
        java.lang.String str4 = compilerOptions0.syntheticBlockStartMarker;
        compilerOptions0.decomposeExpressions = false;
        boolean boolean7 = compilerOptions0.checkTypes;
        java.lang.String str8 = compilerOptions0.renamePrefix;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(str8);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        int int0 = com.google.javascript.rhino.Token.RSH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 19 + "'", int0 == 19);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.NULL_TYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.NULL_TYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.NULL_TYPE));
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        com.google.javascript.rhino.ErrorReporter errorReporter1 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry3 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter1, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative4 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray5 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative4 };
        com.google.javascript.rhino.jstype.JSType jSType6 = jSTypeRegistry3.createUnionType(jSTypeNativeArray5);
        com.google.javascript.rhino.ErrorReporter errorReporter7 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry9 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter7, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative10 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray11 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative10 };
        com.google.javascript.rhino.jstype.JSType jSType12 = jSTypeRegistry9.createUnionType(jSTypeNativeArray11);
        com.google.javascript.rhino.Node node14 = new com.google.javascript.rhino.Node((-1));
        com.google.javascript.rhino.jstype.FunctionType functionType15 = jSTypeRegistry3.createFunctionType(jSType12, node14);
        com.google.javascript.rhino.Node node16 = new com.google.javascript.rhino.Node((int) ' ', node14);
        boolean boolean17 = node16.isQuotedString();
        org.junit.Assert.assertTrue("'" + jSTypeNative4 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative4.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray5);
        org.junit.Assert.assertNotNull(jSType6);
        org.junit.Assert.assertTrue("'" + jSTypeNative10 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative10.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray11);
        org.junit.Assert.assertNotNull(jSType12);
        org.junit.Assert.assertNotNull(functionType15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        java.lang.String str0 = com.google.javascript.rhino.jstype.JSType.EMPTY_TYPE_COMPONENT;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "Named type with empty name component" + "'", str0.equals("Named type with empty name component"));
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        com.google.javascript.rhino.Node.SideEffectFlags sideEffectFlags1 = new com.google.javascript.rhino.Node.SideEffectFlags((int) (short) 100);
        sideEffectFlags1.setReturnsTainted();
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        com.google.javascript.rhino.EvaluatorException evaluatorException5 = new com.google.javascript.rhino.EvaluatorException("", "", 100, "hi!", (int) (short) 1);
        java.lang.String str6 = evaluatorException5.sourceName();
        int int7 = evaluatorException5.lineNumber();
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 100 + "'", int7 == 100);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.disambiguateProperties;
        compilerOptions0.removeUnusedPrototypeProperties = true;
        compilerOptions0.removeEmptyFunctions = true;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        com.google.javascript.rhino.Node node1 = new com.google.javascript.rhino.Node((-1));
        boolean boolean2 = node1.isSyntheticBlock();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        int int0 = com.google.javascript.rhino.Node.DEBUGSOURCE_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 28 + "'", int0 == 28);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative3 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray4 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative3 };
        com.google.javascript.rhino.jstype.JSType jSType5 = jSTypeRegistry2.createUnionType(jSTypeNativeArray4);
        com.google.javascript.rhino.ErrorReporter errorReporter6 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry8 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter6, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative9 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray10 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative9 };
        com.google.javascript.rhino.jstype.JSType jSType11 = jSTypeRegistry8.createUnionType(jSTypeNativeArray10);
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node((-1));
        com.google.javascript.rhino.jstype.FunctionType functionType14 = jSTypeRegistry2.createFunctionType(jSType11, node13);
        com.google.javascript.rhino.jstype.ObjectType objectType15 = jSTypeRegistry2.createAnonymousObjectType();
        com.google.javascript.rhino.jstype.JSType jSType16 = null;
        try {
            com.google.javascript.rhino.jstype.JSType jSType17 = jSTypeRegistry2.createOptionalType(jSType16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + jSTypeNative3 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative3.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray4);
        org.junit.Assert.assertNotNull(jSType5);
        org.junit.Assert.assertTrue("'" + jSTypeNative9 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative9.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray10);
        org.junit.Assert.assertNotNull(jSType11);
        org.junit.Assert.assertNotNull(functionType14);
        org.junit.Assert.assertNotNull(objectType15);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        com.google.javascript.jscomp.CompilerOptions.TracerMode tracerMode0 = com.google.javascript.jscomp.CompilerOptions.TracerMode.ALL;
        org.junit.Assert.assertTrue("'" + tracerMode0 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TracerMode.ALL + "'", tracerMode0.equals(com.google.javascript.jscomp.CompilerOptions.TracerMode.ALL));
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention0 = new com.google.javascript.jscomp.DefaultCodingConvention();
        boolean boolean2 = defaultCodingConvention0.isSuperClassReference("Named type with empty name component");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        com.google.javascript.jscomp.MessageFormatter messageFormatter0 = null;
        java.util.logging.Logger logger1 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager2 = new com.google.javascript.jscomp.LoggerErrorManager(messageFormatter0, logger1);
        com.google.javascript.jscomp.Compiler compiler3 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager2);
        try {
            boolean boolean4 = compiler3.acceptEcmaScript5();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        int int0 = com.google.javascript.rhino.Node.CODEOFFSET_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 8 + "'", int0 == 8);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        try {
            java.lang.String str1 = com.google.javascript.rhino.ScriptRuntime.getMessage0("EOF");
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property EOF");
        } catch (java.lang.RuntimeException e) {
        }
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        int int0 = com.google.javascript.rhino.Node.PROPERTY_FLAG;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative3 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray4 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative3 };
        com.google.javascript.rhino.jstype.JSType jSType5 = jSTypeRegistry2.createUnionType(jSTypeNativeArray4);
        com.google.javascript.rhino.ErrorReporter errorReporter6 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry8 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter6, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative9 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray10 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative9 };
        com.google.javascript.rhino.jstype.JSType jSType11 = jSTypeRegistry8.createUnionType(jSTypeNativeArray10);
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node((-1));
        com.google.javascript.rhino.jstype.FunctionType functionType14 = jSTypeRegistry2.createFunctionType(jSType11, node13);
        com.google.javascript.rhino.ErrorReporter errorReporter15 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry17 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter15, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative18 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray19 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative18 };
        com.google.javascript.rhino.jstype.JSType jSType20 = jSTypeRegistry17.createUnionType(jSTypeNativeArray19);
        com.google.javascript.rhino.ErrorReporter errorReporter21 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry23 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter21, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative24 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray25 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative24 };
        com.google.javascript.rhino.jstype.JSType jSType26 = jSTypeRegistry23.createUnionType(jSTypeNativeArray25);
        com.google.javascript.rhino.Node node28 = new com.google.javascript.rhino.Node((-1));
        com.google.javascript.rhino.jstype.FunctionType functionType29 = jSTypeRegistry17.createFunctionType(jSType26, node28);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray30 = new com.google.javascript.rhino.jstype.JSType[] { jSType26 };
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList31 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean32 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList31, jSTypeArray30);
        com.google.javascript.rhino.Node node33 = jSTypeRegistry2.createParametersWithVarArgs((java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList31);
        try {
            double double34 = node33.getDouble();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: LP is not a number node");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertTrue("'" + jSTypeNative3 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative3.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray4);
        org.junit.Assert.assertNotNull(jSType5);
        org.junit.Assert.assertTrue("'" + jSTypeNative9 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative9.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray10);
        org.junit.Assert.assertNotNull(jSType11);
        org.junit.Assert.assertNotNull(functionType14);
        org.junit.Assert.assertTrue("'" + jSTypeNative18 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative18.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray19);
        org.junit.Assert.assertNotNull(jSType20);
        org.junit.Assert.assertTrue("'" + jSTypeNative24 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative24.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray25);
        org.junit.Assert.assertNotNull(jSType26);
        org.junit.Assert.assertNotNull(functionType29);
        org.junit.Assert.assertNotNull(jSTypeArray30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNotNull(node33);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        int int0 = com.google.javascript.rhino.Token.AND;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 101 + "'", int0 == 101);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode3 = new com.google.javascript.rhino.ScriptOrFnNode(11, 130, (int) (short) 100);
        java.lang.String str4 = scriptOrFnNode3.getSourceName();
        com.google.javascript.rhino.FunctionNode functionNode5 = null;
        try {
            int int6 = scriptOrFnNode3.addFunction(functionNode5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: FAILED ASSERTION");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        java.io.InputStream inputStream1 = null;
        try {
            com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromInputStream("STRING hi!", inputStream1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        try {
            java.lang.String str1 = com.google.javascript.rhino.ScriptRuntime.getMessage0("");
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property ");
        } catch (java.lang.RuntimeException e) {
        }
    }

//    @Test
//    public void test119() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test119");
//        try {
//            com.google.javascript.rhino.Context.reportError("", "STRING hi!", 8, "STRING hi!", 82);
//            org.junit.Assert.fail("Expected exception of type com.google.javascript.rhino.EvaluatorException; message:  (STRING hi!#8)");
//        } catch (com.google.javascript.rhino.EvaluatorException e) {
//        }
//    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        com.google.javascript.rhino.Node node2 = new com.google.javascript.rhino.Node(0);
        com.google.javascript.rhino.Node node3 = null;
        com.google.javascript.rhino.Node node5 = new com.google.javascript.rhino.Node((-1));
        node5.putIntProp(33, 130);
        try {
            com.google.javascript.rhino.Node node9 = new com.google.javascript.rhino.Node(0, node2, node3, node5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        com.google.javascript.rhino.ErrorReporter errorReporter2 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry4 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter2, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative5 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray6 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative5 };
        com.google.javascript.rhino.jstype.JSType jSType7 = jSTypeRegistry4.createUnionType(jSTypeNativeArray6);
        com.google.javascript.rhino.ErrorReporter errorReporter8 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry10 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter8, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative11 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray12 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative11 };
        com.google.javascript.rhino.jstype.JSType jSType13 = jSTypeRegistry10.createUnionType(jSTypeNativeArray12);
        com.google.javascript.rhino.Node node15 = new com.google.javascript.rhino.Node((-1));
        com.google.javascript.rhino.jstype.FunctionType functionType16 = jSTypeRegistry4.createFunctionType(jSType13, node15);
        com.google.javascript.rhino.Node node17 = new com.google.javascript.rhino.Node((int) ' ', node15);
        try {
            com.google.javascript.rhino.Node node18 = new com.google.javascript.rhino.Node(83, node15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: new child has existing parent");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + jSTypeNative5 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative5.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray6);
        org.junit.Assert.assertNotNull(jSType7);
        org.junit.Assert.assertTrue("'" + jSTypeNative11 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative11.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray12);
        org.junit.Assert.assertNotNull(jSType13);
        org.junit.Assert.assertNotNull(functionType16);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        int int0 = com.google.javascript.rhino.Token.STAR;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 302 + "'", int0 == 302);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        int int0 = com.google.javascript.rhino.Token.XMLATTR;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 143 + "'", int0 == 143);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        int int0 = com.google.javascript.rhino.Node.JSDOC_INFO_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 29 + "'", int0 == 29);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative3 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray4 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative3 };
        com.google.javascript.rhino.jstype.JSType jSType5 = jSTypeRegistry2.createUnionType(jSTypeNativeArray4);
        com.google.javascript.rhino.ErrorReporter errorReporter6 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry8 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter6, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative9 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray10 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative9 };
        com.google.javascript.rhino.jstype.JSType jSType11 = jSTypeRegistry8.createUnionType(jSTypeNativeArray10);
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node((-1));
        com.google.javascript.rhino.jstype.FunctionType functionType14 = jSTypeRegistry2.createFunctionType(jSType11, node13);
        com.google.javascript.rhino.ErrorReporter errorReporter15 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry17 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter15, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative18 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray19 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative18 };
        com.google.javascript.rhino.jstype.JSType jSType20 = jSTypeRegistry17.createUnionType(jSTypeNativeArray19);
        com.google.javascript.rhino.ErrorReporter errorReporter21 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry23 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter21, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative24 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray25 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative24 };
        com.google.javascript.rhino.jstype.JSType jSType26 = jSTypeRegistry23.createUnionType(jSTypeNativeArray25);
        com.google.javascript.rhino.Node node28 = new com.google.javascript.rhino.Node((-1));
        com.google.javascript.rhino.jstype.FunctionType functionType29 = jSTypeRegistry17.createFunctionType(jSType26, node28);
        boolean boolean31 = functionType29.hasOwnProperty("hi!");
        com.google.javascript.rhino.jstype.ObjectType objectType32 = jSTypeRegistry2.createObjectType((com.google.javascript.rhino.jstype.ObjectType) functionType29);
        boolean boolean33 = functionType29.isBooleanObjectType();
        org.junit.Assert.assertTrue("'" + jSTypeNative3 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative3.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray4);
        org.junit.Assert.assertNotNull(jSType5);
        org.junit.Assert.assertTrue("'" + jSTypeNative9 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative9.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray10);
        org.junit.Assert.assertNotNull(jSType11);
        org.junit.Assert.assertNotNull(functionType14);
        org.junit.Assert.assertTrue("'" + jSTypeNative18 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative18.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray19);
        org.junit.Assert.assertNotNull(jSType20);
        org.junit.Assert.assertTrue("'" + jSTypeNative24 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative24.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray25);
        org.junit.Assert.assertNotNull(jSType26);
        org.junit.Assert.assertNotNull(functionType29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(objectType32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative3 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray4 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative3 };
        com.google.javascript.rhino.jstype.JSType jSType5 = jSTypeRegistry2.createUnionType(jSTypeNativeArray4);
        com.google.javascript.rhino.ErrorReporter errorReporter6 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry8 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter6, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative9 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray10 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative9 };
        com.google.javascript.rhino.jstype.JSType jSType11 = jSTypeRegistry8.createUnionType(jSTypeNativeArray10);
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node((-1));
        com.google.javascript.rhino.jstype.FunctionType functionType14 = jSTypeRegistry2.createFunctionType(jSType11, node13);
        com.google.javascript.rhino.ErrorReporter errorReporter15 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry17 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter15, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative18 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray19 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative18 };
        com.google.javascript.rhino.jstype.JSType jSType20 = jSTypeRegistry17.createUnionType(jSTypeNativeArray19);
        com.google.javascript.rhino.ErrorReporter errorReporter21 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry23 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter21, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative24 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray25 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative24 };
        com.google.javascript.rhino.jstype.JSType jSType26 = jSTypeRegistry23.createUnionType(jSTypeNativeArray25);
        com.google.javascript.rhino.Node node28 = new com.google.javascript.rhino.Node((-1));
        com.google.javascript.rhino.jstype.FunctionType functionType29 = jSTypeRegistry17.createFunctionType(jSType26, node28);
        com.google.javascript.rhino.ErrorReporter errorReporter30 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry32 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter30, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative33 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray34 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative33 };
        com.google.javascript.rhino.jstype.JSType jSType35 = jSTypeRegistry32.createUnionType(jSTypeNativeArray34);
        com.google.javascript.rhino.ErrorReporter errorReporter36 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry38 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter36, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative39 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray40 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative39 };
        com.google.javascript.rhino.jstype.JSType jSType41 = jSTypeRegistry38.createUnionType(jSTypeNativeArray40);
        com.google.javascript.rhino.Node node43 = new com.google.javascript.rhino.Node((-1));
        com.google.javascript.rhino.jstype.FunctionType functionType44 = jSTypeRegistry32.createFunctionType(jSType41, node43);
        boolean boolean46 = functionType44.hasOwnProperty("hi!");
        com.google.javascript.rhino.jstype.ObjectType objectType47 = jSTypeRegistry17.createObjectType((com.google.javascript.rhino.jstype.ObjectType) functionType44);
        com.google.javascript.rhino.jstype.JSType.TypePair typePair48 = jSType11.getTypesUnderShallowInequality((com.google.javascript.rhino.jstype.JSType) objectType47);
        com.google.javascript.rhino.JSDocInfo jSDocInfo50 = objectType47.getOwnPropertyJSDocInfo("TYPEOF");
        org.junit.Assert.assertTrue("'" + jSTypeNative3 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative3.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray4);
        org.junit.Assert.assertNotNull(jSType5);
        org.junit.Assert.assertTrue("'" + jSTypeNative9 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative9.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray10);
        org.junit.Assert.assertNotNull(jSType11);
        org.junit.Assert.assertNotNull(functionType14);
        org.junit.Assert.assertTrue("'" + jSTypeNative18 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative18.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray19);
        org.junit.Assert.assertNotNull(jSType20);
        org.junit.Assert.assertTrue("'" + jSTypeNative24 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative24.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray25);
        org.junit.Assert.assertNotNull(jSType26);
        org.junit.Assert.assertNotNull(functionType29);
        org.junit.Assert.assertTrue("'" + jSTypeNative33 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative33.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray34);
        org.junit.Assert.assertNotNull(jSType35);
        org.junit.Assert.assertTrue("'" + jSTypeNative39 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative39.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray40);
        org.junit.Assert.assertNotNull(jSType41);
        org.junit.Assert.assertNotNull(functionType44);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(objectType47);
        org.junit.Assert.assertNotNull(typePair48);
        org.junit.Assert.assertNull(jSDocInfo50);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative3 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray4 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative3 };
        com.google.javascript.rhino.jstype.JSType jSType5 = jSTypeRegistry2.createUnionType(jSTypeNativeArray4);
        com.google.javascript.rhino.ErrorReporter errorReporter6 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry8 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter6, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative9 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray10 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative9 };
        com.google.javascript.rhino.jstype.JSType jSType11 = jSTypeRegistry8.createUnionType(jSTypeNativeArray10);
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node((-1));
        com.google.javascript.rhino.jstype.FunctionType functionType14 = jSTypeRegistry2.createFunctionType(jSType11, node13);
        boolean boolean15 = functionType14.matchesInt32Context();
        com.google.javascript.rhino.Node node16 = functionType14.getSource();
        boolean boolean17 = functionType14.isReturnTypeInferred();
        org.junit.Assert.assertTrue("'" + jSTypeNative3 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative3.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray4);
        org.junit.Assert.assertNotNull(jSType5);
        org.junit.Assert.assertTrue("'" + jSTypeNative9 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative9.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray10);
        org.junit.Assert.assertNotNull(jSType11);
        org.junit.Assert.assertNotNull(functionType14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNull(node16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative3 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray4 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative3 };
        com.google.javascript.rhino.jstype.JSType jSType5 = jSTypeRegistry2.createUnionType(jSTypeNativeArray4);
        com.google.javascript.rhino.ErrorReporter errorReporter6 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry8 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter6, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative9 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray10 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative9 };
        com.google.javascript.rhino.jstype.JSType jSType11 = jSTypeRegistry8.createUnionType(jSTypeNativeArray10);
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node((-1));
        com.google.javascript.rhino.jstype.FunctionType functionType14 = jSTypeRegistry2.createFunctionType(jSType11, node13);
        boolean boolean16 = functionType14.hasOwnProperty("hi!");
        com.google.javascript.rhino.ErrorReporter errorReporter17 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry19 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter17, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative20 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray21 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative20 };
        com.google.javascript.rhino.jstype.JSType jSType22 = jSTypeRegistry19.createUnionType(jSTypeNativeArray21);
        com.google.javascript.rhino.ErrorReporter errorReporter23 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry25 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter23, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative26 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray27 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative26 };
        com.google.javascript.rhino.jstype.JSType jSType28 = jSTypeRegistry25.createUnionType(jSTypeNativeArray27);
        com.google.javascript.rhino.Node node30 = new com.google.javascript.rhino.Node((-1));
        com.google.javascript.rhino.jstype.FunctionType functionType31 = jSTypeRegistry19.createFunctionType(jSType28, node30);
        boolean boolean33 = functionType31.hasOwnProperty("hi!");
        functionType14.setPrototypeBasedOn((com.google.javascript.rhino.jstype.ObjectType) functionType31);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable35 = functionType14.getCtorImplementedInterfaces();
        com.google.javascript.rhino.ErrorReporter errorReporter36 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry38 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter36, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative39 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray40 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative39 };
        com.google.javascript.rhino.jstype.JSType jSType41 = jSTypeRegistry38.createUnionType(jSTypeNativeArray40);
        com.google.javascript.rhino.ErrorReporter errorReporter42 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry44 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter42, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative45 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray46 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative45 };
        com.google.javascript.rhino.jstype.JSType jSType47 = jSTypeRegistry44.createUnionType(jSTypeNativeArray46);
        com.google.javascript.rhino.Node node49 = new com.google.javascript.rhino.Node((-1));
        com.google.javascript.rhino.jstype.FunctionType functionType50 = jSTypeRegistry38.createFunctionType(jSType47, node49);
        boolean boolean52 = functionType50.hasOwnProperty("hi!");
        com.google.javascript.rhino.ErrorReporter errorReporter53 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry55 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter53, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative56 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray57 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative56 };
        com.google.javascript.rhino.jstype.JSType jSType58 = jSTypeRegistry55.createUnionType(jSTypeNativeArray57);
        com.google.javascript.rhino.ErrorReporter errorReporter59 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry61 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter59, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative62 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray63 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative62 };
        com.google.javascript.rhino.jstype.JSType jSType64 = jSTypeRegistry61.createUnionType(jSTypeNativeArray63);
        com.google.javascript.rhino.Node node66 = new com.google.javascript.rhino.Node((-1));
        com.google.javascript.rhino.jstype.FunctionType functionType67 = jSTypeRegistry55.createFunctionType(jSType64, node66);
        boolean boolean69 = functionType67.hasOwnProperty("hi!");
        functionType50.setPrototypeBasedOn((com.google.javascript.rhino.jstype.ObjectType) functionType67);
        com.google.javascript.rhino.jstype.JSType jSType71 = functionType14.getLeastSupertype((com.google.javascript.rhino.jstype.JSType) functionType50);
        com.google.javascript.rhino.jstype.ObjectType objectType72 = functionType14.getImplicitPrototype();
        boolean boolean73 = functionType14.isFunctionType();
        org.junit.Assert.assertTrue("'" + jSTypeNative3 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative3.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray4);
        org.junit.Assert.assertNotNull(jSType5);
        org.junit.Assert.assertTrue("'" + jSTypeNative9 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative9.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray10);
        org.junit.Assert.assertNotNull(jSType11);
        org.junit.Assert.assertNotNull(functionType14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + jSTypeNative20 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative20.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray21);
        org.junit.Assert.assertNotNull(jSType22);
        org.junit.Assert.assertTrue("'" + jSTypeNative26 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative26.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray27);
        org.junit.Assert.assertNotNull(jSType28);
        org.junit.Assert.assertNotNull(functionType31);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(objectTypeIterable35);
        org.junit.Assert.assertTrue("'" + jSTypeNative39 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative39.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray40);
        org.junit.Assert.assertNotNull(jSType41);
        org.junit.Assert.assertTrue("'" + jSTypeNative45 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative45.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray46);
        org.junit.Assert.assertNotNull(jSType47);
        org.junit.Assert.assertNotNull(functionType50);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertTrue("'" + jSTypeNative56 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative56.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray57);
        org.junit.Assert.assertNotNull(jSType58);
        org.junit.Assert.assertTrue("'" + jSTypeNative62 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative62.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray63);
        org.junit.Assert.assertNotNull(jSType64);
        org.junit.Assert.assertNotNull(functionType67);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
        org.junit.Assert.assertNotNull(jSType71);
        org.junit.Assert.assertNotNull(objectType72);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + true + "'", boolean73 == true);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        int int0 = com.google.javascript.rhino.Token.REF_CALL;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 68 + "'", int0 == 68);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        int int0 = com.google.javascript.rhino.Token.COMMA;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 85 + "'", int0 == 85);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        int int0 = com.google.javascript.rhino.Context.FEATURE_TO_STRING_AS_SOURCE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        int int0 = com.google.javascript.rhino.Context.VERSION_1_5;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 150 + "'", int0 == 150);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.disambiguateProperties;
        boolean boolean2 = compilerOptions0.isExternExportsEnabled();
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup3 = com.google.javascript.jscomp.DiagnosticGroups.CHECK_TYPES;
        com.google.javascript.jscomp.CompilerOptions compilerOptions4 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel5 = compilerOptions4.checkMissingGetCssNameLevel;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard6 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup3, checkLevel5);
        compilerOptions0.checkProvides = checkLevel5;
        boolean boolean8 = compilerOptions0.ambiguateProperties;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(diagnosticGroup3);
        org.junit.Assert.assertTrue("'" + checkLevel5 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel5.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        int int0 = com.google.javascript.rhino.Token.GET_REF;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 65 + "'", int0 == 65);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        com.google.javascript.rhino.EvaluatorException evaluatorException5 = new com.google.javascript.rhino.EvaluatorException("", "", 100, "hi!", (int) (short) 1);
        java.lang.String str6 = evaluatorException5.sourceName();
        java.lang.String str7 = evaluatorException5.sourceName();
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.common.collect.Multimap<com.google.javascript.jscomp.CustomPassExecutionTime, com.google.javascript.jscomp.CompilerPass> customPassExecutionTimeMultimap1 = null;
        compilerOptions0.customPasses = customPassExecutionTimeMultimap1;
        boolean boolean3 = compilerOptions0.inlineConstantVars;
        java.lang.String str4 = compilerOptions0.syntheticBlockStartMarker;
        compilerOptions0.decomposeExpressions = false;
        boolean boolean7 = compilerOptions0.checkTypes;
        java.lang.String str8 = compilerOptions0.sourceMapOutputPath;
        compilerOptions0.groupVariableDeclarations = false;
        compilerOptions0.devirtualizePrototypeMethods = false;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(str8);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention0 = new com.google.javascript.jscomp.DefaultCodingConvention();
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.Node.newString("hi!");
        com.google.javascript.rhino.Node node3 = node2.getNext();
        try {
            boolean boolean4 = defaultCodingConvention0.isOptionalParameter(node3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertNull(node3);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.Node.newString((int) '#', "EOF");
        boolean boolean4 = node2.getBooleanProp(100);
        com.google.javascript.rhino.Node.SideEffectFlags sideEffectFlags6 = new com.google.javascript.rhino.Node.SideEffectFlags((int) (short) 100);
        try {
            node2.setSideEffectFlags(sideEffectFlags6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: setIsNoSideEffectsCall only supports CALL and NEW nodes, got GETELEM");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_OBJECT_TYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_OBJECT_TYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_OBJECT_TYPE));
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        com.google.javascript.jscomp.MessageFormatter messageFormatter0 = null;
        java.util.logging.Logger logger1 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager2 = new com.google.javascript.jscomp.LoggerErrorManager(messageFormatter0, logger1);
        com.google.javascript.jscomp.Compiler compiler3 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager2);
        java.lang.RuntimeException runtimeException6 = com.google.javascript.rhino.ScriptRuntime.undefWriteError((java.lang.Object) compiler3, (java.lang.Object) (byte) 100, (java.lang.Object) 143);
        org.junit.Assert.assertNotNull(runtimeException6);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        int int0 = com.google.javascript.rhino.Token.ENTERWITH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        int int0 = com.google.javascript.rhino.Node.SIDE_EFFECTS_ALL;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.removeUnusedPrototypeProperties;
        compilerOptions0.removeEmptyFunctions = true;
        com.google.javascript.jscomp.CheckLevel checkLevel4 = compilerOptions0.checkGlobalThisLevel;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + checkLevel4 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel4.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        int int0 = com.google.javascript.rhino.Context.FEATURE_RESERVED_KEYWORD_AS_IDENTIFIER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        int int0 = com.google.javascript.rhino.ScriptOrFnNode.NO_DUPLICATE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative3 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray4 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative3 };
        com.google.javascript.rhino.jstype.JSType jSType5 = jSTypeRegistry2.createUnionType(jSTypeNativeArray4);
        com.google.javascript.rhino.ErrorReporter errorReporter6 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry8 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter6, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative9 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray10 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative9 };
        com.google.javascript.rhino.jstype.JSType jSType11 = jSTypeRegistry8.createUnionType(jSTypeNativeArray10);
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node((-1));
        com.google.javascript.rhino.jstype.FunctionType functionType14 = jSTypeRegistry2.createFunctionType(jSType11, node13);
        boolean boolean16 = functionType14.hasOwnProperty("hi!");
        com.google.javascript.rhino.ErrorReporter errorReporter17 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry19 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter17, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative20 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray21 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative20 };
        com.google.javascript.rhino.jstype.JSType jSType22 = jSTypeRegistry19.createUnionType(jSTypeNativeArray21);
        com.google.javascript.rhino.ErrorReporter errorReporter23 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry25 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter23, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative26 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray27 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative26 };
        com.google.javascript.rhino.jstype.JSType jSType28 = jSTypeRegistry25.createUnionType(jSTypeNativeArray27);
        com.google.javascript.rhino.Node node30 = new com.google.javascript.rhino.Node((-1));
        com.google.javascript.rhino.jstype.FunctionType functionType31 = jSTypeRegistry19.createFunctionType(jSType28, node30);
        boolean boolean33 = functionType31.hasOwnProperty("hi!");
        functionType14.setPrototypeBasedOn((com.google.javascript.rhino.jstype.ObjectType) functionType31);
        boolean boolean35 = functionType31.isUnknownType();
        boolean boolean37 = functionType31.hasOwnProperty("hi!");
        int int38 = functionType31.getMinArguments();
        org.junit.Assert.assertTrue("'" + jSTypeNative3 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative3.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray4);
        org.junit.Assert.assertNotNull(jSType5);
        org.junit.Assert.assertTrue("'" + jSTypeNative9 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative9.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray10);
        org.junit.Assert.assertNotNull(jSType11);
        org.junit.Assert.assertNotNull(functionType14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + jSTypeNative20 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative20.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray21);
        org.junit.Assert.assertNotNull(jSType22);
        org.junit.Assert.assertTrue("'" + jSTypeNative26 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative26.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray27);
        org.junit.Assert.assertNotNull(jSType28);
        org.junit.Assert.assertNotNull(functionType31);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 0 + "'", int38 == 0);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        boolean boolean1 = com.google.javascript.rhino.ScriptRuntime.isJSLineTerminator((-1));
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative3 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray4 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative3 };
        com.google.javascript.rhino.jstype.JSType jSType5 = jSTypeRegistry2.createUnionType(jSTypeNativeArray4);
        com.google.javascript.rhino.ErrorReporter errorReporter6 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry8 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter6, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative9 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray10 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative9 };
        com.google.javascript.rhino.jstype.JSType jSType11 = jSTypeRegistry8.createUnionType(jSTypeNativeArray10);
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node((-1));
        com.google.javascript.rhino.jstype.FunctionType functionType14 = jSTypeRegistry2.createFunctionType(jSType11, node13);
        boolean boolean16 = functionType14.hasOwnProperty("hi!");
        com.google.javascript.rhino.jstype.FunctionPrototypeType functionPrototypeType17 = null;
        boolean boolean18 = functionType14.setPrototype(functionPrototypeType17);
        boolean boolean20 = functionType14.hasOwnProperty("");
        boolean boolean21 = functionType14.canBeCalled();
        org.junit.Assert.assertTrue("'" + jSTypeNative3 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative3.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray4);
        org.junit.Assert.assertNotNull(jSType5);
        org.junit.Assert.assertTrue("'" + jSTypeNative9 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative9.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray10);
        org.junit.Assert.assertNotNull(jSType11);
        org.junit.Assert.assertNotNull(functionType14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative3 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray4 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative3 };
        com.google.javascript.rhino.jstype.JSType jSType5 = jSTypeRegistry2.createUnionType(jSTypeNativeArray4);
        com.google.javascript.rhino.ErrorReporter errorReporter6 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry8 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter6, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative9 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray10 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative9 };
        com.google.javascript.rhino.jstype.JSType jSType11 = jSTypeRegistry8.createUnionType(jSTypeNativeArray10);
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node((-1));
        com.google.javascript.rhino.jstype.FunctionType functionType14 = jSTypeRegistry2.createFunctionType(jSType11, node13);
        boolean boolean16 = functionType14.hasOwnProperty("hi!");
        com.google.javascript.rhino.ErrorReporter errorReporter17 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry19 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter17, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative20 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray21 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative20 };
        com.google.javascript.rhino.jstype.JSType jSType22 = jSTypeRegistry19.createUnionType(jSTypeNativeArray21);
        com.google.javascript.rhino.ErrorReporter errorReporter23 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry25 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter23, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative26 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray27 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative26 };
        com.google.javascript.rhino.jstype.JSType jSType28 = jSTypeRegistry25.createUnionType(jSTypeNativeArray27);
        com.google.javascript.rhino.Node node30 = new com.google.javascript.rhino.Node((-1));
        com.google.javascript.rhino.jstype.FunctionType functionType31 = jSTypeRegistry19.createFunctionType(jSType28, node30);
        boolean boolean33 = functionType31.hasOwnProperty("hi!");
        functionType14.setPrototypeBasedOn((com.google.javascript.rhino.jstype.ObjectType) functionType31);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable35 = functionType14.getCtorImplementedInterfaces();
        com.google.javascript.rhino.ErrorReporter errorReporter36 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry38 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter36, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative39 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray40 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative39 };
        com.google.javascript.rhino.jstype.JSType jSType41 = jSTypeRegistry38.createUnionType(jSTypeNativeArray40);
        com.google.javascript.rhino.ErrorReporter errorReporter42 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry44 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter42, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative45 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray46 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative45 };
        com.google.javascript.rhino.jstype.JSType jSType47 = jSTypeRegistry44.createUnionType(jSTypeNativeArray46);
        com.google.javascript.rhino.Node node49 = new com.google.javascript.rhino.Node((-1));
        com.google.javascript.rhino.jstype.FunctionType functionType50 = jSTypeRegistry38.createFunctionType(jSType47, node49);
        boolean boolean52 = functionType50.hasOwnProperty("hi!");
        com.google.javascript.rhino.ErrorReporter errorReporter53 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry55 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter53, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative56 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray57 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative56 };
        com.google.javascript.rhino.jstype.JSType jSType58 = jSTypeRegistry55.createUnionType(jSTypeNativeArray57);
        com.google.javascript.rhino.ErrorReporter errorReporter59 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry61 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter59, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative62 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray63 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative62 };
        com.google.javascript.rhino.jstype.JSType jSType64 = jSTypeRegistry61.createUnionType(jSTypeNativeArray63);
        com.google.javascript.rhino.Node node66 = new com.google.javascript.rhino.Node((-1));
        com.google.javascript.rhino.jstype.FunctionType functionType67 = jSTypeRegistry55.createFunctionType(jSType64, node66);
        boolean boolean69 = functionType67.hasOwnProperty("hi!");
        functionType50.setPrototypeBasedOn((com.google.javascript.rhino.jstype.ObjectType) functionType67);
        com.google.javascript.rhino.jstype.JSType jSType71 = functionType14.getLeastSupertype((com.google.javascript.rhino.jstype.JSType) functionType50);
        com.google.javascript.rhino.jstype.ObjectType objectType72 = functionType14.getImplicitPrototype();
        com.google.javascript.rhino.jstype.JSType jSType73 = objectType72.autoboxesTo();
        org.junit.Assert.assertTrue("'" + jSTypeNative3 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative3.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray4);
        org.junit.Assert.assertNotNull(jSType5);
        org.junit.Assert.assertTrue("'" + jSTypeNative9 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative9.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray10);
        org.junit.Assert.assertNotNull(jSType11);
        org.junit.Assert.assertNotNull(functionType14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + jSTypeNative20 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative20.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray21);
        org.junit.Assert.assertNotNull(jSType22);
        org.junit.Assert.assertTrue("'" + jSTypeNative26 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative26.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray27);
        org.junit.Assert.assertNotNull(jSType28);
        org.junit.Assert.assertNotNull(functionType31);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(objectTypeIterable35);
        org.junit.Assert.assertTrue("'" + jSTypeNative39 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative39.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray40);
        org.junit.Assert.assertNotNull(jSType41);
        org.junit.Assert.assertTrue("'" + jSTypeNative45 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative45.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray46);
        org.junit.Assert.assertNotNull(jSType47);
        org.junit.Assert.assertNotNull(functionType50);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertTrue("'" + jSTypeNative56 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative56.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray57);
        org.junit.Assert.assertNotNull(jSType58);
        org.junit.Assert.assertTrue("'" + jSTypeNative62 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative62.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray63);
        org.junit.Assert.assertNotNull(jSType64);
        org.junit.Assert.assertNotNull(functionType67);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
        org.junit.Assert.assertNotNull(jSType71);
        org.junit.Assert.assertNotNull(objectType72);
        org.junit.Assert.assertNull(jSType73);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative3 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray4 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative3 };
        com.google.javascript.rhino.jstype.JSType jSType5 = jSTypeRegistry2.createUnionType(jSTypeNativeArray4);
        com.google.javascript.rhino.ErrorReporter errorReporter6 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry8 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter6, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative9 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray10 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative9 };
        com.google.javascript.rhino.jstype.JSType jSType11 = jSTypeRegistry8.createUnionType(jSTypeNativeArray10);
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node((-1));
        com.google.javascript.rhino.jstype.FunctionType functionType14 = jSTypeRegistry2.createFunctionType(jSType11, node13);
        com.google.javascript.rhino.ErrorReporter errorReporter15 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry17 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter15, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative18 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray19 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative18 };
        com.google.javascript.rhino.jstype.JSType jSType20 = jSTypeRegistry17.createUnionType(jSTypeNativeArray19);
        com.google.javascript.rhino.ErrorReporter errorReporter21 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry23 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter21, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative24 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray25 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative24 };
        com.google.javascript.rhino.jstype.JSType jSType26 = jSTypeRegistry23.createUnionType(jSTypeNativeArray25);
        com.google.javascript.rhino.Node node28 = new com.google.javascript.rhino.Node((-1));
        com.google.javascript.rhino.jstype.FunctionType functionType29 = jSTypeRegistry17.createFunctionType(jSType26, node28);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray30 = new com.google.javascript.rhino.jstype.JSType[] { jSType26 };
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList31 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean32 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList31, jSTypeArray30);
        com.google.javascript.rhino.Node node33 = jSTypeRegistry2.createParametersWithVarArgs((java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList31);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode37 = new com.google.javascript.rhino.ScriptOrFnNode(11, 130, (int) (short) 100);
        int int38 = scriptOrFnNode37.getEncodedSourceStart();
        com.google.javascript.rhino.JSTypeExpression jSTypeExpression40 = new com.google.javascript.rhino.JSTypeExpression((com.google.javascript.rhino.Node) scriptOrFnNode37, "Named type with empty name component");
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope42 = null;
        try {
            com.google.javascript.rhino.jstype.JSType jSType44 = jSTypeRegistry2.createFromTypeNodes((com.google.javascript.rhino.Node) scriptOrFnNode37, "STRING hi!", jSTypeStaticScope42, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Unexpected node in type expression: BITAND [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 130");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertTrue("'" + jSTypeNative3 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative3.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray4);
        org.junit.Assert.assertNotNull(jSType5);
        org.junit.Assert.assertTrue("'" + jSTypeNative9 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative9.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray10);
        org.junit.Assert.assertNotNull(jSType11);
        org.junit.Assert.assertNotNull(functionType14);
        org.junit.Assert.assertTrue("'" + jSTypeNative18 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative18.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray19);
        org.junit.Assert.assertNotNull(jSType20);
        org.junit.Assert.assertTrue("'" + jSTypeNative24 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative24.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray25);
        org.junit.Assert.assertNotNull(jSType26);
        org.junit.Assert.assertNotNull(functionType29);
        org.junit.Assert.assertNotNull(jSTypeArray30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNotNull(node33);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 0 + "'", int38 == 0);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.Scope scope2 = compiler1.getTopScope();
        java.util.logging.Logger logger3 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager4 = new com.google.javascript.jscomp.LoggerErrorManager(logger3);
        loggerErrorManager4.generateReport();
        compiler1.setErrorManager((com.google.javascript.jscomp.ErrorManager) loggerErrorManager4);
        org.junit.Assert.assertNull(scope2);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        java.lang.String str1 = com.google.javascript.rhino.ScriptRuntime.escapeString("TYPEOF");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "TYPEOF" + "'", str1.equals("TYPEOF"));
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        int int0 = com.google.javascript.rhino.Token.SUB;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 22 + "'", int0 == 22);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        int int0 = com.google.javascript.rhino.jstype.JSType.NOT_ENUMDECL;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        int int0 = com.google.javascript.rhino.Node.FINALLY_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 20 + "'", int0 == 20);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        try {
            com.google.javascript.jscomp.JSError[] jSErrorArray2 = compiler1.getWarnings();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        int int0 = com.google.javascript.rhino.Token.COLONCOLON;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 140 + "'", int0 == 140);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node1 = null;
        try {
            com.google.javascript.jscomp.CodingConvention.SubclassRelationship subclassRelationship2 = closureCodingConvention0.getClassesDefinedByCall(node1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        int int0 = com.google.javascript.rhino.Token.LOCAL_BLOCK;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 137 + "'", int0 == 137);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromCode("EOF", "language version");
        com.google.javascript.jscomp.Region region4 = jSSourceFile2.getRegion(0);
        org.junit.Assert.assertNotNull(jSSourceFile2);
        org.junit.Assert.assertNotNull(region4);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        com.google.javascript.jscomp.ErrorFormat errorFormat0 = com.google.javascript.jscomp.ErrorFormat.SOURCELESS;
        org.junit.Assert.assertNotNull(errorFormat0);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newString("hi!");
        com.google.javascript.rhino.Node node2 = node1.getNext();
        boolean boolean3 = node1.isVarArgs();
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertNull(node2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        int int0 = com.google.javascript.rhino.Token.JSR;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 131 + "'", int0 == 131);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        int int0 = com.google.javascript.rhino.Token.PIPE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 301 + "'", int0 == 301);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        boolean boolean0 = com.google.javascript.rhino.Token.printTrees;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode3 = new com.google.javascript.rhino.ScriptOrFnNode(11, 130, (int) (short) 100);
        int int4 = scriptOrFnNode3.getEncodedSourceStart();
        com.google.javascript.rhino.JSTypeExpression jSTypeExpression6 = new com.google.javascript.rhino.JSTypeExpression((com.google.javascript.rhino.Node) scriptOrFnNode3, "Named type with empty name component");
        int int7 = scriptOrFnNode3.getFunctionCount();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative3 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray4 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative3 };
        com.google.javascript.rhino.jstype.JSType jSType5 = jSTypeRegistry2.createUnionType(jSTypeNativeArray4);
        com.google.javascript.rhino.ErrorReporter errorReporter6 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry8 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter6, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative9 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray10 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative9 };
        com.google.javascript.rhino.jstype.JSType jSType11 = jSTypeRegistry8.createUnionType(jSTypeNativeArray10);
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node((-1));
        com.google.javascript.rhino.jstype.FunctionType functionType14 = jSTypeRegistry2.createFunctionType(jSType11, node13);
        boolean boolean16 = functionType14.hasOwnProperty("hi!");
        com.google.javascript.rhino.ErrorReporter errorReporter17 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry19 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter17, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative20 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray21 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative20 };
        com.google.javascript.rhino.jstype.JSType jSType22 = jSTypeRegistry19.createUnionType(jSTypeNativeArray21);
        com.google.javascript.rhino.ErrorReporter errorReporter23 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry25 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter23, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative26 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray27 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative26 };
        com.google.javascript.rhino.jstype.JSType jSType28 = jSTypeRegistry25.createUnionType(jSTypeNativeArray27);
        com.google.javascript.rhino.Node node30 = new com.google.javascript.rhino.Node((-1));
        com.google.javascript.rhino.jstype.FunctionType functionType31 = jSTypeRegistry19.createFunctionType(jSType28, node30);
        boolean boolean33 = functionType31.hasOwnProperty("hi!");
        functionType14.setPrototypeBasedOn((com.google.javascript.rhino.jstype.ObjectType) functionType31);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable35 = functionType14.getCtorImplementedInterfaces();
        com.google.javascript.rhino.ErrorReporter errorReporter36 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry38 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter36, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative39 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray40 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative39 };
        com.google.javascript.rhino.jstype.JSType jSType41 = jSTypeRegistry38.createUnionType(jSTypeNativeArray40);
        com.google.javascript.rhino.ErrorReporter errorReporter42 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry44 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter42, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative45 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray46 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative45 };
        com.google.javascript.rhino.jstype.JSType jSType47 = jSTypeRegistry44.createUnionType(jSTypeNativeArray46);
        com.google.javascript.rhino.Node node49 = new com.google.javascript.rhino.Node((-1));
        com.google.javascript.rhino.jstype.FunctionType functionType50 = jSTypeRegistry38.createFunctionType(jSType47, node49);
        boolean boolean52 = functionType50.hasOwnProperty("hi!");
        com.google.javascript.rhino.ErrorReporter errorReporter53 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry55 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter53, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative56 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray57 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative56 };
        com.google.javascript.rhino.jstype.JSType jSType58 = jSTypeRegistry55.createUnionType(jSTypeNativeArray57);
        com.google.javascript.rhino.ErrorReporter errorReporter59 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry61 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter59, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative62 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray63 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative62 };
        com.google.javascript.rhino.jstype.JSType jSType64 = jSTypeRegistry61.createUnionType(jSTypeNativeArray63);
        com.google.javascript.rhino.Node node66 = new com.google.javascript.rhino.Node((-1));
        com.google.javascript.rhino.jstype.FunctionType functionType67 = jSTypeRegistry55.createFunctionType(jSType64, node66);
        boolean boolean69 = functionType67.hasOwnProperty("hi!");
        functionType50.setPrototypeBasedOn((com.google.javascript.rhino.jstype.ObjectType) functionType67);
        com.google.javascript.rhino.jstype.JSType jSType71 = functionType14.getLeastSupertype((com.google.javascript.rhino.jstype.JSType) functionType50);
        boolean boolean72 = functionType50.isRecordType();
        boolean boolean73 = functionType50.hasCachedValues();
        org.junit.Assert.assertTrue("'" + jSTypeNative3 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative3.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray4);
        org.junit.Assert.assertNotNull(jSType5);
        org.junit.Assert.assertTrue("'" + jSTypeNative9 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative9.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray10);
        org.junit.Assert.assertNotNull(jSType11);
        org.junit.Assert.assertNotNull(functionType14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + jSTypeNative20 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative20.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray21);
        org.junit.Assert.assertNotNull(jSType22);
        org.junit.Assert.assertTrue("'" + jSTypeNative26 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative26.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray27);
        org.junit.Assert.assertNotNull(jSType28);
        org.junit.Assert.assertNotNull(functionType31);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(objectTypeIterable35);
        org.junit.Assert.assertTrue("'" + jSTypeNative39 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative39.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray40);
        org.junit.Assert.assertNotNull(jSType41);
        org.junit.Assert.assertTrue("'" + jSTypeNative45 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative45.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray46);
        org.junit.Assert.assertNotNull(jSType47);
        org.junit.Assert.assertNotNull(functionType50);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertTrue("'" + jSTypeNative56 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative56.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray57);
        org.junit.Assert.assertNotNull(jSType58);
        org.junit.Assert.assertTrue("'" + jSTypeNative62 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative62.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray63);
        org.junit.Assert.assertNotNull(jSType64);
        org.junit.Assert.assertNotNull(functionType67);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
        org.junit.Assert.assertNotNull(jSType71);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + true + "'", boolean73 == true);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        int int0 = com.google.javascript.rhino.Token.GT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 16 + "'", int0 == 16);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        int int0 = com.google.javascript.rhino.Token.LABEL_NAME;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 153 + "'", int0 == 153);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        java.lang.String str0 = com.google.javascript.rhino.jstype.JSType.UNKNOWN_NAME;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "Unknown class name" + "'", str0.equals("Unknown class name"));
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        int int0 = com.google.javascript.rhino.Node.ISNUMBER_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 25 + "'", int0 == 25);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.NUMBER_OBJECT_TYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.NUMBER_OBJECT_TYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.NUMBER_OBJECT_TYPE));
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        int int0 = com.google.javascript.rhino.Token.TO_OBJECT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 145 + "'", int0 == 145);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative3 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray4 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative3 };
        com.google.javascript.rhino.jstype.JSType jSType5 = jSTypeRegistry2.createUnionType(jSTypeNativeArray4);
        boolean boolean6 = jSType5.isOrdinaryFunction();
        org.junit.Assert.assertTrue("'" + jSTypeNative3 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative3.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray4);
        org.junit.Assert.assertNotNull(jSType5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative3 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray4 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative3 };
        com.google.javascript.rhino.jstype.JSType jSType5 = jSTypeRegistry2.createUnionType(jSTypeNativeArray4);
        com.google.javascript.rhino.jstype.JSType jSType10 = jSTypeRegistry2.createNamedType("EOF", "STRING hi!", 73, 100);
        com.google.javascript.rhino.JSDocInfo jSDocInfo11 = jSType10.getJSDocInfo();
        org.junit.Assert.assertTrue("'" + jSTypeNative3 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative3.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray4);
        org.junit.Assert.assertNotNull(jSType5);
        org.junit.Assert.assertNotNull(jSType10);
        org.junit.Assert.assertNull(jSDocInfo11);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode3 = new com.google.javascript.rhino.ScriptOrFnNode(11, 130, (int) (short) 100);
        int int4 = scriptOrFnNode3.getEncodedSourceStart();
        com.google.javascript.rhino.JSTypeExpression jSTypeExpression6 = new com.google.javascript.rhino.JSTypeExpression((com.google.javascript.rhino.Node) scriptOrFnNode3, "Named type with empty name component");
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope7 = null;
        com.google.javascript.rhino.ErrorReporter errorReporter8 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry10 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter8, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative11 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray12 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative11 };
        com.google.javascript.rhino.jstype.JSType jSType13 = jSTypeRegistry10.createUnionType(jSTypeNativeArray12);
        com.google.javascript.rhino.ErrorReporter errorReporter14 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry16 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter14, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative17 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray18 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative17 };
        com.google.javascript.rhino.jstype.JSType jSType19 = jSTypeRegistry16.createUnionType(jSTypeNativeArray18);
        com.google.javascript.rhino.Node node21 = new com.google.javascript.rhino.Node((-1));
        com.google.javascript.rhino.jstype.FunctionType functionType22 = jSTypeRegistry10.createFunctionType(jSType19, node21);
        com.google.javascript.rhino.ErrorReporter errorReporter23 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry25 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter23, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative26 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray27 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative26 };
        com.google.javascript.rhino.jstype.JSType jSType28 = jSTypeRegistry25.createUnionType(jSTypeNativeArray27);
        com.google.javascript.rhino.ErrorReporter errorReporter29 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry31 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter29, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative32 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray33 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative32 };
        com.google.javascript.rhino.jstype.JSType jSType34 = jSTypeRegistry31.createUnionType(jSTypeNativeArray33);
        com.google.javascript.rhino.Node node36 = new com.google.javascript.rhino.Node((-1));
        com.google.javascript.rhino.jstype.FunctionType functionType37 = jSTypeRegistry25.createFunctionType(jSType34, node36);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray38 = new com.google.javascript.rhino.jstype.JSType[] { jSType34 };
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList39 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean40 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList39, jSTypeArray38);
        com.google.javascript.rhino.Node node41 = jSTypeRegistry10.createParametersWithVarArgs((java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList39);
        jSTypeRegistry10.setLastGeneration(false);
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope44 = null;
        com.google.javascript.rhino.jstype.JSType jSType49 = jSTypeRegistry10.getType(jSTypeStaticScope44, "TYPEOF", "EOF", (int) (short) 10, 76);
        jSTypeRegistry10.setLastGeneration(false);
        try {
            com.google.javascript.rhino.jstype.JSType jSType52 = jSTypeExpression6.evaluate(jSTypeStaticScope7, jSTypeRegistry10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Unexpected node in type expression: BITAND [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 130");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + jSTypeNative11 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative11.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray12);
        org.junit.Assert.assertNotNull(jSType13);
        org.junit.Assert.assertTrue("'" + jSTypeNative17 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative17.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray18);
        org.junit.Assert.assertNotNull(jSType19);
        org.junit.Assert.assertNotNull(functionType22);
        org.junit.Assert.assertTrue("'" + jSTypeNative26 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative26.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray27);
        org.junit.Assert.assertNotNull(jSType28);
        org.junit.Assert.assertTrue("'" + jSTypeNative32 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative32.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray33);
        org.junit.Assert.assertNotNull(jSType34);
        org.junit.Assert.assertNotNull(functionType37);
        org.junit.Assert.assertNotNull(jSTypeArray38);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertNotNull(node41);
        org.junit.Assert.assertNotNull(jSType49);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative3 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray4 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative3 };
        com.google.javascript.rhino.jstype.JSType jSType5 = jSTypeRegistry2.createUnionType(jSTypeNativeArray4);
        com.google.javascript.rhino.ErrorReporter errorReporter6 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry8 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter6, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative9 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray10 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative9 };
        com.google.javascript.rhino.jstype.JSType jSType11 = jSTypeRegistry8.createUnionType(jSTypeNativeArray10);
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node((-1));
        com.google.javascript.rhino.jstype.FunctionType functionType14 = jSTypeRegistry2.createFunctionType(jSType11, node13);
        int int15 = node13.getLineno();
        int int16 = node13.getCharno();
        org.junit.Assert.assertTrue("'" + jSTypeNative3 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative3.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray4);
        org.junit.Assert.assertNotNull(jSType5);
        org.junit.Assert.assertTrue("'" + jSTypeNative9 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative9.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray10);
        org.junit.Assert.assertNotNull(jSType11);
        org.junit.Assert.assertNotNull(functionType14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        int int0 = com.google.javascript.rhino.ScriptOrFnNode.DUPLICATE_VAR;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative3 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray4 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative3 };
        com.google.javascript.rhino.jstype.JSType jSType5 = jSTypeRegistry2.createUnionType(jSTypeNativeArray4);
        com.google.javascript.rhino.ErrorReporter errorReporter6 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry8 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter6, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative9 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray10 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative9 };
        com.google.javascript.rhino.jstype.JSType jSType11 = jSTypeRegistry8.createUnionType(jSTypeNativeArray10);
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node((-1));
        com.google.javascript.rhino.jstype.FunctionType functionType14 = jSTypeRegistry2.createFunctionType(jSType11, node13);
        boolean boolean16 = functionType14.hasOwnProperty("hi!");
        com.google.javascript.rhino.jstype.FunctionPrototypeType functionPrototypeType17 = null;
        boolean boolean18 = functionType14.setPrototype(functionPrototypeType17);
        java.lang.String str19 = functionType14.getDisplayName();
        boolean boolean20 = functionType14.isRecordType();
        boolean boolean21 = functionType14.hasDisplayName();
        org.junit.Assert.assertTrue("'" + jSTypeNative3 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative3.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray4);
        org.junit.Assert.assertNotNull(jSType5);
        org.junit.Assert.assertTrue("'" + jSTypeNative9 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative9.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray10);
        org.junit.Assert.assertNotNull(jSType11);
        org.junit.Assert.assertNotNull(functionType14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNull(str19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative3 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray4 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative3 };
        com.google.javascript.rhino.jstype.JSType jSType5 = jSTypeRegistry2.createUnionType(jSTypeNativeArray4);
        com.google.javascript.rhino.ErrorReporter errorReporter6 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry8 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter6, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative9 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray10 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative9 };
        com.google.javascript.rhino.jstype.JSType jSType11 = jSTypeRegistry8.createUnionType(jSTypeNativeArray10);
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node((-1));
        com.google.javascript.rhino.jstype.FunctionType functionType14 = jSTypeRegistry2.createFunctionType(jSType11, node13);
        boolean boolean16 = functionType14.hasOwnProperty("hi!");
        com.google.javascript.rhino.jstype.FunctionPrototypeType functionPrototypeType17 = null;
        boolean boolean18 = functionType14.setPrototype(functionPrototypeType17);
        com.google.javascript.rhino.ErrorReporter errorReporter19 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry21 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter19, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative22 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray23 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative22 };
        com.google.javascript.rhino.jstype.JSType jSType24 = jSTypeRegistry21.createUnionType(jSTypeNativeArray23);
        com.google.javascript.rhino.ErrorReporter errorReporter25 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry27 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter25, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative28 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray29 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative28 };
        com.google.javascript.rhino.jstype.JSType jSType30 = jSTypeRegistry27.createUnionType(jSTypeNativeArray29);
        com.google.javascript.rhino.Node node32 = new com.google.javascript.rhino.Node((-1));
        com.google.javascript.rhino.jstype.FunctionType functionType33 = jSTypeRegistry21.createFunctionType(jSType30, node32);
        boolean boolean35 = functionType33.hasOwnProperty("hi!");
        com.google.javascript.rhino.ErrorReporter errorReporter36 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry38 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter36, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative39 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray40 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative39 };
        com.google.javascript.rhino.jstype.JSType jSType41 = jSTypeRegistry38.createUnionType(jSTypeNativeArray40);
        com.google.javascript.rhino.ErrorReporter errorReporter42 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry44 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter42, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative45 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray46 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative45 };
        com.google.javascript.rhino.jstype.JSType jSType47 = jSTypeRegistry44.createUnionType(jSTypeNativeArray46);
        com.google.javascript.rhino.Node node49 = new com.google.javascript.rhino.Node((-1));
        com.google.javascript.rhino.jstype.FunctionType functionType50 = jSTypeRegistry38.createFunctionType(jSType47, node49);
        boolean boolean52 = functionType50.hasOwnProperty("hi!");
        functionType33.setPrototypeBasedOn((com.google.javascript.rhino.jstype.ObjectType) functionType50);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable54 = functionType33.getCtorImplementedInterfaces();
        com.google.javascript.rhino.ErrorReporter errorReporter55 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry57 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter55, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative58 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray59 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative58 };
        com.google.javascript.rhino.jstype.JSType jSType60 = jSTypeRegistry57.createUnionType(jSTypeNativeArray59);
        com.google.javascript.rhino.ErrorReporter errorReporter61 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry63 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter61, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative64 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray65 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative64 };
        com.google.javascript.rhino.jstype.JSType jSType66 = jSTypeRegistry63.createUnionType(jSTypeNativeArray65);
        com.google.javascript.rhino.Node node68 = new com.google.javascript.rhino.Node((-1));
        com.google.javascript.rhino.jstype.FunctionType functionType69 = jSTypeRegistry57.createFunctionType(jSType66, node68);
        boolean boolean71 = functionType69.hasOwnProperty("hi!");
        com.google.javascript.rhino.ErrorReporter errorReporter72 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry74 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter72, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative75 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray76 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative75 };
        com.google.javascript.rhino.jstype.JSType jSType77 = jSTypeRegistry74.createUnionType(jSTypeNativeArray76);
        com.google.javascript.rhino.ErrorReporter errorReporter78 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry80 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter78, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative81 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray82 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative81 };
        com.google.javascript.rhino.jstype.JSType jSType83 = jSTypeRegistry80.createUnionType(jSTypeNativeArray82);
        com.google.javascript.rhino.Node node85 = new com.google.javascript.rhino.Node((-1));
        com.google.javascript.rhino.jstype.FunctionType functionType86 = jSTypeRegistry74.createFunctionType(jSType83, node85);
        boolean boolean88 = functionType86.hasOwnProperty("hi!");
        functionType69.setPrototypeBasedOn((com.google.javascript.rhino.jstype.ObjectType) functionType86);
        com.google.javascript.rhino.jstype.JSType jSType90 = functionType33.getLeastSupertype((com.google.javascript.rhino.jstype.JSType) functionType69);
        com.google.javascript.rhino.jstype.JSType.TypePair typePair91 = functionType14.getTypesUnderShallowInequality((com.google.javascript.rhino.jstype.JSType) functionType33);
        com.google.javascript.rhino.jstype.ObjectType objectType92 = functionType14.dereference();
        boolean boolean93 = functionType14.hasInstanceType();
        org.junit.Assert.assertTrue("'" + jSTypeNative3 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative3.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray4);
        org.junit.Assert.assertNotNull(jSType5);
        org.junit.Assert.assertTrue("'" + jSTypeNative9 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative9.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray10);
        org.junit.Assert.assertNotNull(jSType11);
        org.junit.Assert.assertNotNull(functionType14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + jSTypeNative22 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative22.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray23);
        org.junit.Assert.assertNotNull(jSType24);
        org.junit.Assert.assertTrue("'" + jSTypeNative28 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative28.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray29);
        org.junit.Assert.assertNotNull(jSType30);
        org.junit.Assert.assertNotNull(functionType33);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + jSTypeNative39 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative39.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray40);
        org.junit.Assert.assertNotNull(jSType41);
        org.junit.Assert.assertTrue("'" + jSTypeNative45 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative45.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray46);
        org.junit.Assert.assertNotNull(jSType47);
        org.junit.Assert.assertNotNull(functionType50);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertNotNull(objectTypeIterable54);
        org.junit.Assert.assertTrue("'" + jSTypeNative58 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative58.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray59);
        org.junit.Assert.assertNotNull(jSType60);
        org.junit.Assert.assertTrue("'" + jSTypeNative64 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative64.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray65);
        org.junit.Assert.assertNotNull(jSType66);
        org.junit.Assert.assertNotNull(functionType69);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
        org.junit.Assert.assertTrue("'" + jSTypeNative75 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative75.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray76);
        org.junit.Assert.assertNotNull(jSType77);
        org.junit.Assert.assertTrue("'" + jSTypeNative81 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative81.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray82);
        org.junit.Assert.assertNotNull(jSType83);
        org.junit.Assert.assertNotNull(functionType86);
        org.junit.Assert.assertTrue("'" + boolean88 + "' != '" + false + "'", boolean88 == false);
        org.junit.Assert.assertNotNull(jSType90);
        org.junit.Assert.assertNotNull(typePair91);
        org.junit.Assert.assertNotNull(objectType92);
        org.junit.Assert.assertTrue("'" + boolean93 + "' != '" + false + "'", boolean93 == false);
    }

//    @Test
//    public void test181() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test181");
//        try {
//            com.google.javascript.rhino.EvaluatorException evaluatorException1 = com.google.javascript.rhino.Context.reportRuntimeError("STRING hi!");
//            org.junit.Assert.fail("Expected exception of type com.google.javascript.rhino.EvaluatorException; message: STRING hi!");
//        } catch (com.google.javascript.rhino.EvaluatorException e) {
//        }
//    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.STRING_OBJECT_FUNCTION_TYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.STRING_OBJECT_FUNCTION_TYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.STRING_OBJECT_FUNCTION_TYPE));
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        int int0 = com.google.javascript.rhino.Token.ELSE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 109 + "'", int0 == 109);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative3 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray4 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative3 };
        com.google.javascript.rhino.jstype.JSType jSType5 = jSTypeRegistry2.createUnionType(jSTypeNativeArray4);
        com.google.javascript.rhino.ErrorReporter errorReporter6 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry8 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter6, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative9 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray10 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative9 };
        com.google.javascript.rhino.jstype.JSType jSType11 = jSTypeRegistry8.createUnionType(jSTypeNativeArray10);
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node((-1));
        com.google.javascript.rhino.jstype.FunctionType functionType14 = jSTypeRegistry2.createFunctionType(jSType11, node13);
        com.google.javascript.rhino.ErrorReporter errorReporter15 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry17 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter15, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative18 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray19 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative18 };
        com.google.javascript.rhino.jstype.JSType jSType20 = jSTypeRegistry17.createUnionType(jSTypeNativeArray19);
        com.google.javascript.rhino.ErrorReporter errorReporter21 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry23 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter21, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative24 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray25 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative24 };
        com.google.javascript.rhino.jstype.JSType jSType26 = jSTypeRegistry23.createUnionType(jSTypeNativeArray25);
        com.google.javascript.rhino.Node node28 = new com.google.javascript.rhino.Node((-1));
        com.google.javascript.rhino.jstype.FunctionType functionType29 = jSTypeRegistry17.createFunctionType(jSType26, node28);
        boolean boolean31 = functionType29.hasOwnProperty("hi!");
        com.google.javascript.rhino.jstype.ObjectType objectType32 = jSTypeRegistry2.createObjectType((com.google.javascript.rhino.jstype.ObjectType) functionType29);
        com.google.javascript.rhino.JSDocInfo jSDocInfo34 = objectType32.getOwnPropertyJSDocInfo("Named type with empty name component");
        org.junit.Assert.assertTrue("'" + jSTypeNative3 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative3.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray4);
        org.junit.Assert.assertNotNull(jSType5);
        org.junit.Assert.assertTrue("'" + jSTypeNative9 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative9.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray10);
        org.junit.Assert.assertNotNull(jSType11);
        org.junit.Assert.assertNotNull(functionType14);
        org.junit.Assert.assertTrue("'" + jSTypeNative18 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative18.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray19);
        org.junit.Assert.assertNotNull(jSType20);
        org.junit.Assert.assertTrue("'" + jSTypeNative24 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative24.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray25);
        org.junit.Assert.assertNotNull(jSType26);
        org.junit.Assert.assertNotNull(functionType29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(objectType32);
        org.junit.Assert.assertNull(jSDocInfo34);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.PerformanceTracker performanceTracker2 = compiler1.tracker;
        com.google.javascript.jscomp.JSError jSError3 = null;
        try {
            com.google.javascript.jscomp.CheckLevel checkLevel4 = compiler1.getErrorLevel(jSError3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(performanceTracker2);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        com.google.javascript.jscomp.ErrorFormat errorFormat0 = com.google.javascript.jscomp.ErrorFormat.LEGACY;
        org.junit.Assert.assertNotNull(errorFormat0);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        int int0 = com.google.javascript.rhino.Context.VERSION_1_2;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 120 + "'", int0 == 120);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        int int0 = com.google.javascript.rhino.Token.FIRST_BYTECODE_TOKEN;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.removeUnusedPrototypeProperties;
        compilerOptions0.removeEmptyFunctions = true;
        compilerOptions0.removeUnusedVars = false;
        boolean boolean6 = compilerOptions0.smartNameRemoval;
        boolean boolean7 = compilerOptions0.extractPrototypeMemberDeclarations;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        int int0 = com.google.javascript.rhino.Node.DIRECT_EVAL;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 48 + "'", int0 == 48);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.CHECKED_UNKNOWN_TYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.CHECKED_UNKNOWN_TYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.CHECKED_UNKNOWN_TYPE));
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        com.google.javascript.jscomp.MessageFormatter messageFormatter0 = null;
        java.util.logging.Logger logger1 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager2 = new com.google.javascript.jscomp.LoggerErrorManager(messageFormatter0, logger1);
        com.google.javascript.jscomp.Compiler compiler3 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager2);
        try {
            com.google.javascript.jscomp.Region region6 = compiler3.getSourceRegion("hi!", 79);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.Compiler.IntermediateState intermediateState2 = compiler1.getState();
        try {
            boolean boolean3 = compiler1.isIdeMode();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intermediateState2);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        int int0 = com.google.javascript.rhino.Token.ENUM_INIT_KEYS;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 57 + "'", int0 == 57);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        com.google.javascript.rhino.Node node1 = new com.google.javascript.rhino.Node((-1));
        boolean boolean2 = node1.isNoSideEffectsCall();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        com.google.javascript.jscomp.SourceAst sourceAst0 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(sourceAst0, "", true);
        try {
            java.lang.String str4 = compilerInput3.getCode();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.common.collect.Multimap<com.google.javascript.jscomp.CustomPassExecutionTime, com.google.javascript.jscomp.CompilerPass> customPassExecutionTimeMultimap1 = null;
        compilerOptions0.customPasses = customPassExecutionTimeMultimap1;
        boolean boolean3 = compilerOptions0.inlineConstantVars;
        java.lang.String str4 = compilerOptions0.syntheticBlockStartMarker;
        compilerOptions0.decomposeExpressions = false;
        boolean boolean7 = compilerOptions0.checkTypes;
        java.lang.String str8 = compilerOptions0.sourceMapOutputPath;
        compilerOptions0.groupVariableDeclarations = false;
        boolean boolean11 = compilerOptions0.removeUnusedPrototypePropertiesInExterns;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        try {
            com.google.javascript.rhino.Context.reportWarning("STRING hi!", "EOF", 139, "hi!", 24);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: No Context associated with current Thread");
        } catch (java.lang.RuntimeException e) {
        }
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy0 = com.google.javascript.jscomp.PropertyRenamingPolicy.OFF;
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy0 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.OFF + "'", propertyRenamingPolicy0.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.OFF));
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.common.collect.Multimap<com.google.javascript.jscomp.CustomPassExecutionTime, com.google.javascript.jscomp.CompilerPass> customPassExecutionTimeMultimap1 = null;
        compilerOptions0.customPasses = customPassExecutionTimeMultimap1;
        boolean boolean3 = compilerOptions0.inlineConstantVars;
        java.lang.String str4 = compilerOptions0.syntheticBlockStartMarker;
        compilerOptions0.decomposeExpressions = false;
        boolean boolean7 = compilerOptions0.checkTypes;
        java.lang.String str8 = compilerOptions0.sourceMapOutputPath;
        boolean boolean9 = compilerOptions0.deadAssignmentElimination;
        com.google.javascript.jscomp.DefaultPassConfig defaultPassConfig10 = new com.google.javascript.jscomp.DefaultPassConfig(compilerOptions0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy0 = com.google.javascript.jscomp.VariableRenamingPolicy.ALL;
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy0 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.ALL + "'", variableRenamingPolicy0.equals(com.google.javascript.jscomp.VariableRenamingPolicy.ALL));
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = null;
        com.google.javascript.jscomp.DiagnosticGroups.UNDEFINED_VARIABLES = diagnosticGroup0;
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.common.collect.Multimap<com.google.javascript.jscomp.CustomPassExecutionTime, com.google.javascript.jscomp.CompilerPass> customPassExecutionTimeMultimap1 = null;
        compilerOptions0.customPasses = customPassExecutionTimeMultimap1;
        compilerOptions0.devirtualizePrototypeMethods = true;
        compilerOptions0.setOutputCharset("goog.exportSymbol");
        compilerOptions0.moveFunctionDeclarations = true;
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.allowLegacyJsMessages = false;
        boolean boolean3 = compilerOptions0.checkSuspiciousCode;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        java.lang.String str0 = com.google.javascript.jscomp.graph.FixedPointGraphTraversal.NON_HALTING_ERROR_MSG;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "Fixed point computation not halting" + "'", str0.equals("Fixed point computation not halting"));
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        com.google.javascript.rhino.EvaluatorException evaluatorException5 = new com.google.javascript.rhino.EvaluatorException("", "", 100, "hi!", (int) (short) 1);
        java.lang.String str6 = evaluatorException5.sourceName();
        com.google.javascript.rhino.EvaluatorException evaluatorException12 = new com.google.javascript.rhino.EvaluatorException("", "", 100, "hi!", (int) (short) 1);
        evaluatorException5.addSuppressed((java.lang.Throwable) evaluatorException12);
        try {
            evaluatorException12.initLineNumber(6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.common.collect.Multimap<com.google.javascript.jscomp.CustomPassExecutionTime, com.google.javascript.jscomp.CompilerPass> customPassExecutionTimeMultimap1 = null;
        compilerOptions0.customPasses = customPassExecutionTimeMultimap1;
        boolean boolean3 = compilerOptions0.inlineConstantVars;
        compilerOptions0.ignoreCajaProperties = false;
        compilerOptions0.inputDelimiter = "Fixed point computation not halting";
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        int int0 = com.google.javascript.rhino.Token.GETELEM;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 35 + "'", int0 == 35);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        com.google.javascript.jscomp.parsing.Config config2 = null;
        com.google.javascript.jscomp.mozilla.rhino.ErrorReporter errorReporter3 = null;
        java.util.logging.Logger logger4 = null;
        try {
            com.google.javascript.rhino.Node node5 = com.google.javascript.jscomp.parsing.ParserRunner.parse("", "hi!", config2, errorReporter3, logger4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.PerformanceTracker performanceTracker2 = compiler1.tracker;
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray3 = new com.google.javascript.jscomp.JSSourceFile[] {};
        com.google.javascript.jscomp.JSModule jSModule4 = null;
        com.google.javascript.jscomp.JSModule[] jSModuleArray5 = new com.google.javascript.jscomp.JSModule[] { jSModule4 };
        com.google.javascript.jscomp.CompilerOptions compilerOptions6 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions6.allowLegacyJsMessages = false;
        compilerOptions6.optimizeParameters = false;
        try {
            compiler1.init(jSSourceFileArray3, jSModuleArray5, compilerOptions6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(performanceTracker2);
        org.junit.Assert.assertNotNull(jSSourceFileArray3);
        org.junit.Assert.assertNotNull(jSModuleArray5);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative3 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray4 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative3 };
        com.google.javascript.rhino.jstype.JSType jSType5 = jSTypeRegistry2.createUnionType(jSTypeNativeArray4);
        com.google.javascript.rhino.ErrorReporter errorReporter6 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry8 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter6, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative9 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray10 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative9 };
        com.google.javascript.rhino.jstype.JSType jSType11 = jSTypeRegistry8.createUnionType(jSTypeNativeArray10);
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node((-1));
        com.google.javascript.rhino.jstype.FunctionType functionType14 = jSTypeRegistry2.createFunctionType(jSType11, node13);
        com.google.javascript.rhino.ErrorReporter errorReporter15 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry17 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter15, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative18 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray19 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative18 };
        com.google.javascript.rhino.jstype.JSType jSType20 = jSTypeRegistry17.createUnionType(jSTypeNativeArray19);
        com.google.javascript.rhino.ErrorReporter errorReporter21 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry23 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter21, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative24 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray25 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative24 };
        com.google.javascript.rhino.jstype.JSType jSType26 = jSTypeRegistry23.createUnionType(jSTypeNativeArray25);
        com.google.javascript.rhino.Node node28 = new com.google.javascript.rhino.Node((-1));
        com.google.javascript.rhino.jstype.FunctionType functionType29 = jSTypeRegistry17.createFunctionType(jSType26, node28);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray30 = new com.google.javascript.rhino.jstype.JSType[] { jSType26 };
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList31 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean32 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList31, jSTypeArray30);
        com.google.javascript.rhino.Node node33 = jSTypeRegistry2.createParametersWithVarArgs((java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList31);
        jSTypeRegistry2.setLastGeneration(false);
        com.google.javascript.rhino.jstype.ObjectType objectType36 = jSTypeRegistry2.createAnonymousObjectType();
        boolean boolean37 = objectType36.isEmptyType();
        com.google.javascript.rhino.ErrorReporter errorReporter39 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry41 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter39, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative42 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray43 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative42 };
        com.google.javascript.rhino.jstype.JSType jSType44 = jSTypeRegistry41.createUnionType(jSTypeNativeArray43);
        com.google.javascript.rhino.ErrorReporter errorReporter45 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry47 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter45, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative48 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray49 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative48 };
        com.google.javascript.rhino.jstype.JSType jSType50 = jSTypeRegistry47.createUnionType(jSTypeNativeArray49);
        com.google.javascript.rhino.Node node52 = new com.google.javascript.rhino.Node((-1));
        com.google.javascript.rhino.jstype.FunctionType functionType53 = jSTypeRegistry41.createFunctionType(jSType50, node52);
        boolean boolean55 = functionType53.hasOwnProperty("hi!");
        com.google.javascript.rhino.ErrorReporter errorReporter56 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry58 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter56, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative59 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray60 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative59 };
        com.google.javascript.rhino.jstype.JSType jSType61 = jSTypeRegistry58.createUnionType(jSTypeNativeArray60);
        com.google.javascript.rhino.ErrorReporter errorReporter62 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry64 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter62, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative65 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray66 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative65 };
        com.google.javascript.rhino.jstype.JSType jSType67 = jSTypeRegistry64.createUnionType(jSTypeNativeArray66);
        com.google.javascript.rhino.Node node69 = new com.google.javascript.rhino.Node((-1));
        com.google.javascript.rhino.jstype.FunctionType functionType70 = jSTypeRegistry58.createFunctionType(jSType67, node69);
        boolean boolean72 = functionType70.hasOwnProperty("hi!");
        functionType53.setPrototypeBasedOn((com.google.javascript.rhino.jstype.ObjectType) functionType70);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable74 = functionType53.getCtorImplementedInterfaces();
        boolean boolean76 = objectType36.defineDeclaredProperty("Named type with empty name component", (com.google.javascript.rhino.jstype.JSType) functionType53, true);
        boolean boolean77 = objectType36.isRecordType();
        org.junit.Assert.assertTrue("'" + jSTypeNative3 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative3.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray4);
        org.junit.Assert.assertNotNull(jSType5);
        org.junit.Assert.assertTrue("'" + jSTypeNative9 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative9.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray10);
        org.junit.Assert.assertNotNull(jSType11);
        org.junit.Assert.assertNotNull(functionType14);
        org.junit.Assert.assertTrue("'" + jSTypeNative18 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative18.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray19);
        org.junit.Assert.assertNotNull(jSType20);
        org.junit.Assert.assertTrue("'" + jSTypeNative24 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative24.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray25);
        org.junit.Assert.assertNotNull(jSType26);
        org.junit.Assert.assertNotNull(functionType29);
        org.junit.Assert.assertNotNull(jSTypeArray30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNotNull(node33);
        org.junit.Assert.assertNotNull(objectType36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + jSTypeNative42 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative42.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray43);
        org.junit.Assert.assertNotNull(jSType44);
        org.junit.Assert.assertTrue("'" + jSTypeNative48 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative48.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray49);
        org.junit.Assert.assertNotNull(jSType50);
        org.junit.Assert.assertNotNull(functionType53);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertTrue("'" + jSTypeNative59 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative59.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray60);
        org.junit.Assert.assertNotNull(jSType61);
        org.junit.Assert.assertTrue("'" + jSTypeNative65 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative65.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray66);
        org.junit.Assert.assertNotNull(jSType67);
        org.junit.Assert.assertNotNull(functionType70);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
        org.junit.Assert.assertNotNull(objectTypeIterable74);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + true + "'", boolean76 == true);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        int int0 = com.google.javascript.rhino.Node.CASEARRAY_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 15 + "'", int0 == 15);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        int int0 = com.google.javascript.rhino.Node.IS_DISPATCHER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 46 + "'", int0 == 46);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.PerformanceTracker performanceTracker2 = compiler1.tracker;
        try {
            com.google.javascript.jscomp.JSError[] jSErrorArray3 = compiler1.getWarnings();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(performanceTracker2);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        int int0 = com.google.javascript.rhino.Token.BANG;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 306 + "'", int0 == 306);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.disambiguateProperties;
        boolean boolean2 = compilerOptions0.isExternExportsEnabled();
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup3 = com.google.javascript.jscomp.DiagnosticGroups.CHECK_TYPES;
        com.google.javascript.jscomp.CompilerOptions compilerOptions4 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel5 = compilerOptions4.checkMissingGetCssNameLevel;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard6 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup3, checkLevel5);
        compilerOptions0.checkProvides = checkLevel5;
        boolean boolean8 = compilerOptions0.aliasExternals;
        boolean boolean9 = compilerOptions0.inlineLocalFunctions;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(diagnosticGroup3);
        org.junit.Assert.assertTrue("'" + checkLevel5 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel5.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.removeUnusedPrototypeProperties;
        compilerOptions0.removeEmptyFunctions = true;
        boolean boolean4 = compilerOptions0.instrumentForCoverageOnly;
        boolean boolean5 = compilerOptions0.disambiguateProperties;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        int int0 = com.google.javascript.rhino.Node.MEMBER_TYPE_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 32 + "'", int0 == 32);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        int int0 = com.google.javascript.rhino.Token.SETELEM_OP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 136 + "'", int0 == 136);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        int int0 = com.google.javascript.rhino.Token.SEMI;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 78 + "'", int0 == 78);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        int int0 = com.google.javascript.rhino.Token.IF;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 108 + "'", int0 == 108);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        int int0 = com.google.javascript.rhino.Token.DELPROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 31 + "'", int0 == 31);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.FUNCTION_PROTOTYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.FUNCTION_PROTOTYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.FUNCTION_PROTOTYPE));
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        java.lang.String str2 = compiler1.getAstDotGraph();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        int int0 = com.google.javascript.rhino.Token.TRUE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 44 + "'", int0 == 44);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.REGEXP_TYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.REGEXP_TYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.REGEXP_TYPE));
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        int int0 = com.google.javascript.rhino.Context.FEATURE_LOCATION_INFORMATION_IN_ERROR;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        int int0 = com.google.javascript.rhino.FunctionNode.FUNCTION_EXPRESSION_STATEMENT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.allowLegacyJsMessages = false;
        compilerOptions0.optimizeParameters = false;
        compilerOptions0.rewriteFunctionExpressions = false;
        compilerOptions0.optimizeCalls = true;
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.FILEOVERVIEW_JSDOC;
        org.junit.Assert.assertNull(diagnosticGroup0);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        boolean boolean1 = com.google.javascript.rhino.Context.isValidOptimizationLevel(70);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

//    @Test
//    public void test232() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test232");
//        try {
//            com.google.javascript.rhino.EvaluatorException evaluatorException5 = com.google.javascript.rhino.Context.reportRuntimeError("Named type with empty name component", "", (int) (byte) 10, "", 120);
//            org.junit.Assert.fail("Expected exception of type com.google.javascript.rhino.EvaluatorException; message: Named type with empty name component (#10)");
//        } catch (com.google.javascript.rhino.EvaluatorException e) {
//        }
//    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.ERROR_FUNCTION_TYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.ERROR_FUNCTION_TYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.ERROR_FUNCTION_TYPE));
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        int int0 = com.google.javascript.rhino.Node.RIGHT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        int int0 = com.google.javascript.rhino.Node.DEFAULT_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 14 + "'", int0 == 14);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        com.google.javascript.rhino.EvaluatorException evaluatorException5 = new com.google.javascript.rhino.EvaluatorException("", "", 100, "hi!", (int) (short) 1);
        java.lang.String str6 = evaluatorException5.sourceName();
        com.google.javascript.rhino.EvaluatorException evaluatorException12 = new com.google.javascript.rhino.EvaluatorException("", "", 100, "hi!", (int) (short) 1);
        evaluatorException5.addSuppressed((java.lang.Throwable) evaluatorException12);
        try {
            evaluatorException5.initSourceName("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        int int0 = com.google.javascript.rhino.Token.LAST_ASSIGN;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 97 + "'", int0 == 97);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative3 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray4 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative3 };
        com.google.javascript.rhino.jstype.JSType jSType5 = jSTypeRegistry2.createUnionType(jSTypeNativeArray4);
        com.google.javascript.rhino.ErrorReporter errorReporter6 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry8 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter6, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative9 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray10 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative9 };
        com.google.javascript.rhino.jstype.JSType jSType11 = jSTypeRegistry8.createUnionType(jSTypeNativeArray10);
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node((-1));
        com.google.javascript.rhino.jstype.FunctionType functionType14 = jSTypeRegistry2.createFunctionType(jSType11, node13);
        com.google.javascript.rhino.ErrorReporter errorReporter15 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry17 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter15, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative18 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray19 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative18 };
        com.google.javascript.rhino.jstype.JSType jSType20 = jSTypeRegistry17.createUnionType(jSTypeNativeArray19);
        com.google.javascript.rhino.ErrorReporter errorReporter21 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry23 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter21, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative24 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray25 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative24 };
        com.google.javascript.rhino.jstype.JSType jSType26 = jSTypeRegistry23.createUnionType(jSTypeNativeArray25);
        com.google.javascript.rhino.Node node28 = new com.google.javascript.rhino.Node((-1));
        com.google.javascript.rhino.jstype.FunctionType functionType29 = jSTypeRegistry17.createFunctionType(jSType26, node28);
        boolean boolean31 = functionType29.hasOwnProperty("hi!");
        com.google.javascript.rhino.jstype.ObjectType objectType32 = jSTypeRegistry2.createObjectType((com.google.javascript.rhino.jstype.ObjectType) functionType29);
        com.google.javascript.rhino.ErrorReporter errorReporter33 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry35 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter33, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative36 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray37 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative36 };
        com.google.javascript.rhino.jstype.JSType jSType38 = jSTypeRegistry35.createUnionType(jSTypeNativeArray37);
        com.google.javascript.rhino.ErrorReporter errorReporter39 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry41 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter39, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative42 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray43 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative42 };
        com.google.javascript.rhino.jstype.JSType jSType44 = jSTypeRegistry41.createUnionType(jSTypeNativeArray43);
        com.google.javascript.rhino.Node node46 = new com.google.javascript.rhino.Node((-1));
        com.google.javascript.rhino.jstype.FunctionType functionType47 = jSTypeRegistry35.createFunctionType(jSType44, node46);
        boolean boolean49 = functionType47.hasOwnProperty("hi!");
        com.google.javascript.rhino.ErrorReporter errorReporter50 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry52 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter50, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative53 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray54 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative53 };
        com.google.javascript.rhino.jstype.JSType jSType55 = jSTypeRegistry52.createUnionType(jSTypeNativeArray54);
        com.google.javascript.rhino.ErrorReporter errorReporter56 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry58 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter56, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative59 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray60 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative59 };
        com.google.javascript.rhino.jstype.JSType jSType61 = jSTypeRegistry58.createUnionType(jSTypeNativeArray60);
        com.google.javascript.rhino.Node node63 = new com.google.javascript.rhino.Node((-1));
        com.google.javascript.rhino.jstype.FunctionType functionType64 = jSTypeRegistry52.createFunctionType(jSType61, node63);
        boolean boolean66 = functionType64.hasOwnProperty("hi!");
        functionType47.setPrototypeBasedOn((com.google.javascript.rhino.jstype.ObjectType) functionType64);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable68 = functionType47.getCtorImplementedInterfaces();
        boolean boolean69 = functionType47.isBooleanObjectType();
        boolean boolean70 = functionType29.hasEqualCallType(functionType47);
        boolean boolean71 = functionType47.matchesUint32Context();
        org.junit.Assert.assertTrue("'" + jSTypeNative3 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative3.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray4);
        org.junit.Assert.assertNotNull(jSType5);
        org.junit.Assert.assertTrue("'" + jSTypeNative9 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative9.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray10);
        org.junit.Assert.assertNotNull(jSType11);
        org.junit.Assert.assertNotNull(functionType14);
        org.junit.Assert.assertTrue("'" + jSTypeNative18 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative18.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray19);
        org.junit.Assert.assertNotNull(jSType20);
        org.junit.Assert.assertTrue("'" + jSTypeNative24 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative24.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray25);
        org.junit.Assert.assertNotNull(jSType26);
        org.junit.Assert.assertNotNull(functionType29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(objectType32);
        org.junit.Assert.assertTrue("'" + jSTypeNative36 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative36.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray37);
        org.junit.Assert.assertNotNull(jSType38);
        org.junit.Assert.assertTrue("'" + jSTypeNative42 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative42.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray43);
        org.junit.Assert.assertNotNull(jSType44);
        org.junit.Assert.assertNotNull(functionType47);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertTrue("'" + jSTypeNative53 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative53.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray54);
        org.junit.Assert.assertNotNull(jSType55);
        org.junit.Assert.assertTrue("'" + jSTypeNative59 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative59.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray60);
        org.junit.Assert.assertNotNull(jSType61);
        org.junit.Assert.assertNotNull(functionType64);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertNotNull(objectTypeIterable68);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        int int0 = com.google.javascript.rhino.Node.FLAG_LOCAL_RESULTS;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 16 + "'", int0 == 16);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        com.google.javascript.jscomp.SourceFile.Generator generator1 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("Named type with empty name component", generator1);
        try {
            java.io.Reader reader3 = jSSourceFile2.getCodeReader();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile2);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.disambiguateProperties;
        boolean boolean2 = compilerOptions0.isExternExportsEnabled();
        com.google.javascript.jscomp.CompilerOptions compilerOptions3 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.common.collect.Multimap<com.google.javascript.jscomp.CustomPassExecutionTime, com.google.javascript.jscomp.CompilerPass> customPassExecutionTimeMultimap4 = null;
        compilerOptions3.customPasses = customPassExecutionTimeMultimap4;
        com.google.javascript.jscomp.ErrorFormat errorFormat6 = compilerOptions3.errorFormat;
        compilerOptions0.errorFormat = errorFormat6;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(errorFormat6);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.ErrorReporter errorReporter3 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter3, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative6 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray7 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative6 };
        com.google.javascript.rhino.jstype.JSType jSType8 = jSTypeRegistry5.createUnionType(jSTypeNativeArray7);
        com.google.javascript.rhino.ErrorReporter errorReporter9 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry11 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter9, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative12 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray13 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative12 };
        com.google.javascript.rhino.jstype.JSType jSType14 = jSTypeRegistry11.createUnionType(jSTypeNativeArray13);
        com.google.javascript.rhino.Node node16 = new com.google.javascript.rhino.Node((-1));
        com.google.javascript.rhino.jstype.FunctionType functionType17 = jSTypeRegistry5.createFunctionType(jSType14, node16);
        boolean boolean19 = functionType17.hasOwnProperty("hi!");
        com.google.javascript.rhino.jstype.ObjectType objectType20 = jSTypeRegistry2.createObjectType((com.google.javascript.rhino.jstype.ObjectType) functionType17);
        boolean boolean21 = functionType17.isCheckedUnknownType();
        com.google.javascript.rhino.jstype.JSType jSType23 = functionType17.getRestrictedTypeGivenToBooleanOutcome(true);
        boolean boolean24 = functionType17.isAllType();
        org.junit.Assert.assertTrue("'" + jSTypeNative6 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative6.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray7);
        org.junit.Assert.assertNotNull(jSType8);
        org.junit.Assert.assertTrue("'" + jSTypeNative12 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative12.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray13);
        org.junit.Assert.assertNotNull(jSType14);
        org.junit.Assert.assertNotNull(functionType17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(objectType20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(jSType23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.disambiguateProperties;
        boolean boolean2 = compilerOptions0.ignoreCajaProperties;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy3 = null;
        compilerOptions0.variableRenaming = variableRenamingPolicy3;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        int int0 = com.google.javascript.rhino.Token.POS;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 28 + "'", int0 == 28);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative3 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray4 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative3 };
        com.google.javascript.rhino.jstype.JSType jSType5 = jSTypeRegistry2.createUnionType(jSTypeNativeArray4);
        com.google.javascript.rhino.ErrorReporter errorReporter6 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry8 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter6, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative9 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray10 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative9 };
        com.google.javascript.rhino.jstype.JSType jSType11 = jSTypeRegistry8.createUnionType(jSTypeNativeArray10);
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node((-1));
        com.google.javascript.rhino.jstype.FunctionType functionType14 = jSTypeRegistry2.createFunctionType(jSType11, node13);
        boolean boolean16 = functionType14.hasOwnProperty("hi!");
        com.google.javascript.rhino.ErrorReporter errorReporter17 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry19 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter17, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative20 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray21 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative20 };
        com.google.javascript.rhino.jstype.JSType jSType22 = jSTypeRegistry19.createUnionType(jSTypeNativeArray21);
        com.google.javascript.rhino.ErrorReporter errorReporter23 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry25 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter23, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative26 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray27 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative26 };
        com.google.javascript.rhino.jstype.JSType jSType28 = jSTypeRegistry25.createUnionType(jSTypeNativeArray27);
        com.google.javascript.rhino.Node node30 = new com.google.javascript.rhino.Node((-1));
        com.google.javascript.rhino.jstype.FunctionType functionType31 = jSTypeRegistry19.createFunctionType(jSType28, node30);
        boolean boolean33 = functionType31.hasOwnProperty("hi!");
        functionType14.setPrototypeBasedOn((com.google.javascript.rhino.jstype.ObjectType) functionType31);
        boolean boolean35 = functionType31.isUnknownType();
        boolean boolean37 = functionType31.hasOwnProperty("hi!");
        com.google.javascript.rhino.Node node38 = functionType31.getParametersNode();
        boolean boolean40 = functionType31.hasProperty("hi!");
        java.util.Set<java.lang.String> strSet41 = functionType31.getOwnPropertyNames();
        org.junit.Assert.assertTrue("'" + jSTypeNative3 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative3.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray4);
        org.junit.Assert.assertNotNull(jSType5);
        org.junit.Assert.assertTrue("'" + jSTypeNative9 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative9.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray10);
        org.junit.Assert.assertNotNull(jSType11);
        org.junit.Assert.assertNotNull(functionType14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + jSTypeNative20 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative20.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray21);
        org.junit.Assert.assertNotNull(jSType22);
        org.junit.Assert.assertTrue("'" + jSTypeNative26 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative26.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray27);
        org.junit.Assert.assertNotNull(jSType28);
        org.junit.Assert.assertNotNull(functionType31);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(node38);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(strSet41);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry0 = null;
        com.google.javascript.rhino.jstype.FunctionParamBuilder functionParamBuilder1 = new com.google.javascript.rhino.jstype.FunctionParamBuilder(jSTypeRegistry0);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        int int0 = com.google.javascript.rhino.Token.ENUM_ID;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 60 + "'", int0 == 60);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.Node node4 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType5 = jSTypeRegistry2.createInterfaceType("", node4);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode10 = new com.google.javascript.rhino.ScriptOrFnNode(11, 130, (int) (short) 100);
        try {
            com.google.javascript.rhino.jstype.FunctionType functionType11 = jSTypeRegistry2.createInterfaceType("", (com.google.javascript.rhino.Node) scriptOrFnNode10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(functionType5);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        jSTypeRegistry1.forwardDeclareType("hi!");
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.checkMissingGetCssNameLevel;
        java.util.Set<java.lang.String> strSet2 = compilerOptions0.stripNamePrefixes;
        com.google.javascript.jscomp.CodingConvention codingConvention3 = compilerOptions0.getCodingConvention();
        compilerOptions0.markAsCompiled = false;
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(strSet2);
        org.junit.Assert.assertNull(codingConvention3);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode3 = new com.google.javascript.rhino.ScriptOrFnNode(11, 130, (int) (short) 100);
        scriptOrFnNode3.setBaseLineno(21);
        java.util.Collection<com.google.javascript.rhino.Node> nodeCollection6 = com.google.javascript.jscomp.NodeUtil.getVarsDeclaredInBranch((com.google.javascript.rhino.Node) scriptOrFnNode3);
        org.junit.Assert.assertNotNull(nodeCollection6);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.removeUnusedPrototypeProperties;
        compilerOptions0.removeEmptyFunctions = true;
        boolean boolean4 = compilerOptions0.instrumentForCoverageOnly;
        compilerOptions0.sourceMapOutputPath = "STRING hi!";
        boolean boolean7 = compilerOptions0.groupVariableDeclarations;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.disambiguateProperties;
        com.google.javascript.jscomp.AnonymousFunctionNamingPolicy anonymousFunctionNamingPolicy2 = compilerOptions0.anonymousFunctionNaming;
        java.lang.String str3 = compilerOptions0.nameReferenceReportPath;
        compilerOptions0.prettyPrint = false;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + anonymousFunctionNamingPolicy2 + "' != '" + com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF + "'", anonymousFunctionNamingPolicy2.equals(com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF));
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.common.collect.Multimap<com.google.javascript.jscomp.CustomPassExecutionTime, com.google.javascript.jscomp.CompilerPass> customPassExecutionTimeMultimap1 = null;
        compilerOptions0.customPasses = customPassExecutionTimeMultimap1;
        boolean boolean3 = compilerOptions0.inlineConstantVars;
        com.google.javascript.jscomp.SourceMap.DetailLevel detailLevel4 = null;
        compilerOptions0.sourceMapDetailLevel = detailLevel4;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        int int0 = com.google.javascript.rhino.Token.NAME;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 38 + "'", int0 == 38);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        boolean boolean2 = closureCodingConvention0.isPrivate("EOF");
        com.google.javascript.rhino.ErrorReporter errorReporter3 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter3, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative6 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray7 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative6 };
        com.google.javascript.rhino.jstype.JSType jSType8 = jSTypeRegistry5.createUnionType(jSTypeNativeArray7);
        com.google.javascript.rhino.ErrorReporter errorReporter9 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry11 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter9, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative12 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray13 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative12 };
        com.google.javascript.rhino.jstype.JSType jSType14 = jSTypeRegistry11.createUnionType(jSTypeNativeArray13);
        com.google.javascript.rhino.Node node16 = new com.google.javascript.rhino.Node((-1));
        com.google.javascript.rhino.jstype.FunctionType functionType17 = jSTypeRegistry5.createFunctionType(jSType14, node16);
        boolean boolean18 = functionType17.matchesInt32Context();
        com.google.javascript.rhino.ErrorReporter errorReporter19 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry21 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter19, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative22 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray23 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative22 };
        com.google.javascript.rhino.jstype.JSType jSType24 = jSTypeRegistry21.createUnionType(jSTypeNativeArray23);
        com.google.javascript.rhino.ErrorReporter errorReporter25 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry27 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter25, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative28 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray29 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative28 };
        com.google.javascript.rhino.jstype.JSType jSType30 = jSTypeRegistry27.createUnionType(jSTypeNativeArray29);
        com.google.javascript.rhino.Node node32 = new com.google.javascript.rhino.Node((-1));
        com.google.javascript.rhino.jstype.FunctionType functionType33 = jSTypeRegistry21.createFunctionType(jSType30, node32);
        boolean boolean35 = functionType33.hasOwnProperty("hi!");
        com.google.javascript.rhino.jstype.FunctionPrototypeType functionPrototypeType36 = null;
        boolean boolean37 = functionType33.setPrototype(functionPrototypeType36);
        boolean boolean39 = functionType33.hasOwnProperty("");
        com.google.javascript.rhino.ErrorReporter errorReporter40 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry42 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter40, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative43 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray44 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative43 };
        com.google.javascript.rhino.jstype.JSType jSType45 = jSTypeRegistry42.createUnionType(jSTypeNativeArray44);
        com.google.javascript.rhino.ErrorReporter errorReporter46 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry48 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter46, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative49 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray50 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative49 };
        com.google.javascript.rhino.jstype.JSType jSType51 = jSTypeRegistry48.createUnionType(jSTypeNativeArray50);
        com.google.javascript.rhino.Node node53 = new com.google.javascript.rhino.Node((-1));
        com.google.javascript.rhino.jstype.FunctionType functionType54 = jSTypeRegistry42.createFunctionType(jSType51, node53);
        boolean boolean55 = functionType54.matchesInt32Context();
        boolean boolean56 = functionType54.isConstructor();
        functionType33.setPrototypeBasedOn((com.google.javascript.rhino.jstype.ObjectType) functionType54);
        com.google.javascript.rhino.jstype.FunctionType functionType58 = functionType54.getConstructor();
        com.google.javascript.rhino.ErrorReporter errorReporter59 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry61 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter59, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative62 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray63 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative62 };
        com.google.javascript.rhino.jstype.JSType jSType64 = jSTypeRegistry61.createUnionType(jSTypeNativeArray63);
        com.google.javascript.rhino.ErrorReporter errorReporter65 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry67 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter65, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative68 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray69 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative68 };
        com.google.javascript.rhino.jstype.JSType jSType70 = jSTypeRegistry67.createUnionType(jSTypeNativeArray69);
        com.google.javascript.rhino.Node node72 = new com.google.javascript.rhino.Node((-1));
        com.google.javascript.rhino.jstype.FunctionType functionType73 = jSTypeRegistry61.createFunctionType(jSType70, node72);
        com.google.javascript.rhino.ErrorReporter errorReporter74 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry76 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter74, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative77 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray78 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative77 };
        com.google.javascript.rhino.jstype.JSType jSType79 = jSTypeRegistry76.createUnionType(jSTypeNativeArray78);
        com.google.javascript.rhino.ErrorReporter errorReporter80 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry82 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter80, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative83 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray84 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative83 };
        com.google.javascript.rhino.jstype.JSType jSType85 = jSTypeRegistry82.createUnionType(jSTypeNativeArray84);
        com.google.javascript.rhino.Node node87 = new com.google.javascript.rhino.Node((-1));
        com.google.javascript.rhino.jstype.FunctionType functionType88 = jSTypeRegistry76.createFunctionType(jSType85, node87);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray89 = new com.google.javascript.rhino.jstype.JSType[] { jSType85 };
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList90 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean91 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList90, jSTypeArray89);
        com.google.javascript.rhino.Node node92 = jSTypeRegistry61.createParametersWithVarArgs((java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList90);
        jSTypeRegistry61.setLastGeneration(false);
        com.google.javascript.rhino.jstype.ObjectType objectType95 = jSTypeRegistry61.createAnonymousObjectType();
        boolean boolean96 = objectType95.hasCachedValues();
        closureCodingConvention0.applySingletonGetter(functionType17, functionType54, objectType95);
        com.google.javascript.rhino.jstype.JSType jSType98 = objectType95.unboxesTo();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + jSTypeNative6 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative6.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray7);
        org.junit.Assert.assertNotNull(jSType8);
        org.junit.Assert.assertTrue("'" + jSTypeNative12 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative12.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray13);
        org.junit.Assert.assertNotNull(jSType14);
        org.junit.Assert.assertNotNull(functionType17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + jSTypeNative22 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative22.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray23);
        org.junit.Assert.assertNotNull(jSType24);
        org.junit.Assert.assertTrue("'" + jSTypeNative28 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative28.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray29);
        org.junit.Assert.assertNotNull(jSType30);
        org.junit.Assert.assertNotNull(functionType33);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + jSTypeNative43 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative43.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray44);
        org.junit.Assert.assertNotNull(jSType45);
        org.junit.Assert.assertTrue("'" + jSTypeNative49 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative49.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray50);
        org.junit.Assert.assertNotNull(jSType51);
        org.junit.Assert.assertNotNull(functionType54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertNull(functionType58);
        org.junit.Assert.assertTrue("'" + jSTypeNative62 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative62.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray63);
        org.junit.Assert.assertNotNull(jSType64);
        org.junit.Assert.assertTrue("'" + jSTypeNative68 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative68.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray69);
        org.junit.Assert.assertNotNull(jSType70);
        org.junit.Assert.assertNotNull(functionType73);
        org.junit.Assert.assertTrue("'" + jSTypeNative77 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative77.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray78);
        org.junit.Assert.assertNotNull(jSType79);
        org.junit.Assert.assertTrue("'" + jSTypeNative83 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative83.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray84);
        org.junit.Assert.assertNotNull(jSType85);
        org.junit.Assert.assertNotNull(functionType88);
        org.junit.Assert.assertNotNull(jSTypeArray89);
        org.junit.Assert.assertTrue("'" + boolean91 + "' != '" + true + "'", boolean91 == true);
        org.junit.Assert.assertNotNull(node92);
        org.junit.Assert.assertNotNull(objectType95);
        org.junit.Assert.assertTrue("'" + boolean96 + "' != '" + false + "'", boolean96 == false);
        org.junit.Assert.assertNull(jSType98);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.disambiguateProperties;
        compilerOptions0.removeUnusedPrototypeProperties = true;
        compilerOptions0.nameReferenceReportPath = "STRING hi!";
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        int int0 = com.google.javascript.rhino.Token.LC;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 81 + "'", int0 == 81);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        int int0 = com.google.javascript.rhino.Node.IS_CONSTANT_NAME;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 42 + "'", int0 == 42);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.PerformanceTracker performanceTracker2 = compiler1.tracker;
        com.google.javascript.jscomp.PerformanceTracker performanceTracker3 = null;
        compiler1.tracker = performanceTracker3;
        com.google.javascript.jscomp.JSModule jSModule5 = null;
        try {
            java.lang.String str6 = compiler1.toSource(jSModule5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(performanceTracker2);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        com.google.javascript.rhino.Node.SideEffectFlags sideEffectFlags1 = new com.google.javascript.rhino.Node.SideEffectFlags((int) (short) 1);
        sideEffectFlags1.setReturnsTainted();
        sideEffectFlags1.setThrows();
        sideEffectFlags1.clearAllFlags();
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        com.google.javascript.rhino.ErrorReporter errorReporter2 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry4 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter2, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative5 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray6 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative5 };
        com.google.javascript.rhino.jstype.JSType jSType7 = jSTypeRegistry4.createUnionType(jSTypeNativeArray6);
        com.google.javascript.rhino.ErrorReporter errorReporter8 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry10 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter8, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative11 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray12 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative11 };
        com.google.javascript.rhino.jstype.JSType jSType13 = jSTypeRegistry10.createUnionType(jSTypeNativeArray12);
        com.google.javascript.rhino.Node node15 = new com.google.javascript.rhino.Node((-1));
        com.google.javascript.rhino.jstype.FunctionType functionType16 = jSTypeRegistry4.createFunctionType(jSType13, node15);
        com.google.javascript.rhino.ErrorReporter errorReporter17 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry19 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter17, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative20 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray21 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative20 };
        com.google.javascript.rhino.jstype.JSType jSType22 = jSTypeRegistry19.createUnionType(jSTypeNativeArray21);
        com.google.javascript.rhino.ErrorReporter errorReporter23 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry25 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter23, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative26 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray27 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative26 };
        com.google.javascript.rhino.jstype.JSType jSType28 = jSTypeRegistry25.createUnionType(jSTypeNativeArray27);
        com.google.javascript.rhino.Node node30 = new com.google.javascript.rhino.Node((-1));
        com.google.javascript.rhino.jstype.FunctionType functionType31 = jSTypeRegistry19.createFunctionType(jSType28, node30);
        boolean boolean33 = functionType31.hasOwnProperty("hi!");
        com.google.javascript.rhino.jstype.ObjectType objectType34 = jSTypeRegistry4.createObjectType((com.google.javascript.rhino.jstype.ObjectType) functionType31);
        java.lang.Object obj35 = null;
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup36 = com.google.javascript.jscomp.DiagnosticGroups.CHECK_TYPES;
        com.google.javascript.jscomp.DiagnosticGroups.UNKNOWN_DEFINES = diagnosticGroup36;
        try {
            java.lang.String str38 = com.google.javascript.rhino.ScriptRuntime.getMessage4("language version", (java.lang.Object) 0, (java.lang.Object) jSTypeRegistry4, obj35, (java.lang.Object) diagnosticGroup36);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property language version");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertTrue("'" + jSTypeNative5 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative5.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray6);
        org.junit.Assert.assertNotNull(jSType7);
        org.junit.Assert.assertTrue("'" + jSTypeNative11 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative11.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray12);
        org.junit.Assert.assertNotNull(jSType13);
        org.junit.Assert.assertNotNull(functionType16);
        org.junit.Assert.assertTrue("'" + jSTypeNative20 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative20.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray21);
        org.junit.Assert.assertNotNull(jSType22);
        org.junit.Assert.assertTrue("'" + jSTypeNative26 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative26.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray27);
        org.junit.Assert.assertNotNull(jSType28);
        org.junit.Assert.assertNotNull(functionType31);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(objectType34);
        org.junit.Assert.assertNotNull(diagnosticGroup36);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.allowLegacyJsMessages = false;
        compilerOptions0.optimizeParameters = false;
        compilerOptions0.nameReferenceGraphPath = "hi!";
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative3 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray4 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative3 };
        com.google.javascript.rhino.jstype.JSType jSType5 = jSTypeRegistry2.createUnionType(jSTypeNativeArray4);
        com.google.javascript.rhino.ErrorReporter errorReporter6 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry8 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter6, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative9 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray10 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative9 };
        com.google.javascript.rhino.jstype.JSType jSType11 = jSTypeRegistry8.createUnionType(jSTypeNativeArray10);
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node((-1));
        com.google.javascript.rhino.jstype.FunctionType functionType14 = jSTypeRegistry2.createFunctionType(jSType11, node13);
        boolean boolean16 = functionType14.hasOwnProperty("hi!");
        com.google.javascript.rhino.ErrorReporter errorReporter17 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry19 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter17, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative20 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray21 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative20 };
        com.google.javascript.rhino.jstype.JSType jSType22 = jSTypeRegistry19.createUnionType(jSTypeNativeArray21);
        com.google.javascript.rhino.ErrorReporter errorReporter23 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry25 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter23, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative26 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray27 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative26 };
        com.google.javascript.rhino.jstype.JSType jSType28 = jSTypeRegistry25.createUnionType(jSTypeNativeArray27);
        com.google.javascript.rhino.Node node30 = new com.google.javascript.rhino.Node((-1));
        com.google.javascript.rhino.jstype.FunctionType functionType31 = jSTypeRegistry19.createFunctionType(jSType28, node30);
        boolean boolean33 = functionType31.hasOwnProperty("hi!");
        functionType14.setPrototypeBasedOn((com.google.javascript.rhino.jstype.ObjectType) functionType31);
        boolean boolean35 = functionType31.isUnknownType();
        boolean boolean37 = functionType31.hasOwnProperty("hi!");
        com.google.javascript.rhino.Node node38 = functionType31.getParametersNode();
        boolean boolean40 = functionType31.hasProperty("hi!");
        com.google.javascript.rhino.ErrorReporter errorReporter41 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry43 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter41, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative44 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray45 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative44 };
        com.google.javascript.rhino.jstype.JSType jSType46 = jSTypeRegistry43.createUnionType(jSTypeNativeArray45);
        com.google.javascript.rhino.ErrorReporter errorReporter47 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry49 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter47, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative50 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray51 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative50 };
        com.google.javascript.rhino.jstype.JSType jSType52 = jSTypeRegistry49.createUnionType(jSTypeNativeArray51);
        com.google.javascript.rhino.Node node54 = new com.google.javascript.rhino.Node((-1));
        com.google.javascript.rhino.jstype.FunctionType functionType55 = jSTypeRegistry43.createFunctionType(jSType52, node54);
        boolean boolean57 = functionType55.hasOwnProperty("hi!");
        com.google.javascript.rhino.ErrorReporter errorReporter58 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry60 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter58, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative61 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray62 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative61 };
        com.google.javascript.rhino.jstype.JSType jSType63 = jSTypeRegistry60.createUnionType(jSTypeNativeArray62);
        com.google.javascript.rhino.ErrorReporter errorReporter64 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry66 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter64, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative67 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray68 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative67 };
        com.google.javascript.rhino.jstype.JSType jSType69 = jSTypeRegistry66.createUnionType(jSTypeNativeArray68);
        com.google.javascript.rhino.Node node71 = new com.google.javascript.rhino.Node((-1));
        com.google.javascript.rhino.jstype.FunctionType functionType72 = jSTypeRegistry60.createFunctionType(jSType69, node71);
        boolean boolean74 = functionType72.hasOwnProperty("hi!");
        functionType55.setPrototypeBasedOn((com.google.javascript.rhino.jstype.ObjectType) functionType72);
        boolean boolean76 = functionType72.isUnknownType();
        com.google.javascript.rhino.jstype.JSType jSType77 = functionType31.getLeastSupertype((com.google.javascript.rhino.jstype.JSType) functionType72);
        org.junit.Assert.assertTrue("'" + jSTypeNative3 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative3.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray4);
        org.junit.Assert.assertNotNull(jSType5);
        org.junit.Assert.assertTrue("'" + jSTypeNative9 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative9.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray10);
        org.junit.Assert.assertNotNull(jSType11);
        org.junit.Assert.assertNotNull(functionType14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + jSTypeNative20 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative20.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray21);
        org.junit.Assert.assertNotNull(jSType22);
        org.junit.Assert.assertTrue("'" + jSTypeNative26 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative26.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray27);
        org.junit.Assert.assertNotNull(jSType28);
        org.junit.Assert.assertNotNull(functionType31);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(node38);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + jSTypeNative44 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative44.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray45);
        org.junit.Assert.assertNotNull(jSType46);
        org.junit.Assert.assertTrue("'" + jSTypeNative50 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative50.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray51);
        org.junit.Assert.assertNotNull(jSType52);
        org.junit.Assert.assertNotNull(functionType55);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertTrue("'" + jSTypeNative61 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative61.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray62);
        org.junit.Assert.assertNotNull(jSType63);
        org.junit.Assert.assertTrue("'" + jSTypeNative67 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative67.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray68);
        org.junit.Assert.assertNotNull(jSType69);
        org.junit.Assert.assertNotNull(functionType72);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
        org.junit.Assert.assertNotNull(jSType77);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        int int0 = com.google.javascript.rhino.Token.THIS;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 42 + "'", int0 == 42);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode3 = new com.google.javascript.rhino.ScriptOrFnNode(11, 130, (int) (short) 100);
        int int6 = scriptOrFnNode3.addRegexp("language version", "hi!");
        boolean boolean7 = scriptOrFnNode3.isOptionalArg();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.common.collect.Multimap<com.google.javascript.jscomp.CustomPassExecutionTime, com.google.javascript.jscomp.CompilerPass> customPassExecutionTimeMultimap1 = null;
        compilerOptions0.customPasses = customPassExecutionTimeMultimap1;
        compilerOptions0.devirtualizePrototypeMethods = true;
        compilerOptions0.instrumentForCoverageOnly = false;
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.NUMBER_STRING_BOOLEAN;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.NUMBER_STRING_BOOLEAN + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.NUMBER_STRING_BOOLEAN));
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        int int0 = com.google.javascript.rhino.Token.EXPORT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 106 + "'", int0 == 106);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative3 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray4 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative3 };
        com.google.javascript.rhino.jstype.JSType jSType5 = jSTypeRegistry2.createUnionType(jSTypeNativeArray4);
        com.google.javascript.rhino.ErrorReporter errorReporter6 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry8 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter6, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative9 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray10 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative9 };
        com.google.javascript.rhino.jstype.JSType jSType11 = jSTypeRegistry8.createUnionType(jSTypeNativeArray10);
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node((-1));
        com.google.javascript.rhino.jstype.FunctionType functionType14 = jSTypeRegistry2.createFunctionType(jSType11, node13);
        boolean boolean16 = functionType14.hasOwnProperty("hi!");
        com.google.javascript.rhino.ErrorReporter errorReporter17 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry19 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter17, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative20 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray21 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative20 };
        com.google.javascript.rhino.jstype.JSType jSType22 = jSTypeRegistry19.createUnionType(jSTypeNativeArray21);
        com.google.javascript.rhino.ErrorReporter errorReporter23 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry25 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter23, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative26 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray27 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative26 };
        com.google.javascript.rhino.jstype.JSType jSType28 = jSTypeRegistry25.createUnionType(jSTypeNativeArray27);
        com.google.javascript.rhino.Node node30 = new com.google.javascript.rhino.Node((-1));
        com.google.javascript.rhino.jstype.FunctionType functionType31 = jSTypeRegistry19.createFunctionType(jSType28, node30);
        boolean boolean33 = functionType31.hasOwnProperty("hi!");
        functionType14.setPrototypeBasedOn((com.google.javascript.rhino.jstype.ObjectType) functionType31);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable35 = functionType14.getCtorImplementedInterfaces();
        com.google.javascript.rhino.ErrorReporter errorReporter36 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry38 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter36, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative39 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray40 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative39 };
        com.google.javascript.rhino.jstype.JSType jSType41 = jSTypeRegistry38.createUnionType(jSTypeNativeArray40);
        com.google.javascript.rhino.ErrorReporter errorReporter42 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry44 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter42, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative45 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray46 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative45 };
        com.google.javascript.rhino.jstype.JSType jSType47 = jSTypeRegistry44.createUnionType(jSTypeNativeArray46);
        com.google.javascript.rhino.Node node49 = new com.google.javascript.rhino.Node((-1));
        com.google.javascript.rhino.jstype.FunctionType functionType50 = jSTypeRegistry38.createFunctionType(jSType47, node49);
        boolean boolean52 = functionType50.hasOwnProperty("hi!");
        com.google.javascript.rhino.ErrorReporter errorReporter53 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry55 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter53, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative56 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray57 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative56 };
        com.google.javascript.rhino.jstype.JSType jSType58 = jSTypeRegistry55.createUnionType(jSTypeNativeArray57);
        com.google.javascript.rhino.ErrorReporter errorReporter59 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry61 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter59, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative62 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray63 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative62 };
        com.google.javascript.rhino.jstype.JSType jSType64 = jSTypeRegistry61.createUnionType(jSTypeNativeArray63);
        com.google.javascript.rhino.Node node66 = new com.google.javascript.rhino.Node((-1));
        com.google.javascript.rhino.jstype.FunctionType functionType67 = jSTypeRegistry55.createFunctionType(jSType64, node66);
        boolean boolean69 = functionType67.hasOwnProperty("hi!");
        functionType50.setPrototypeBasedOn((com.google.javascript.rhino.jstype.ObjectType) functionType67);
        com.google.javascript.rhino.jstype.JSType jSType71 = functionType14.getLeastSupertype((com.google.javascript.rhino.jstype.JSType) functionType50);
        com.google.javascript.rhino.jstype.ObjectType objectType72 = functionType14.getImplicitPrototype();
        boolean boolean74 = functionType14.hasOwnProperty("hi!");
        boolean boolean75 = functionType14.isReturnTypeInferred();
        boolean boolean76 = functionType14.hasCachedValues();
        org.junit.Assert.assertTrue("'" + jSTypeNative3 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative3.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray4);
        org.junit.Assert.assertNotNull(jSType5);
        org.junit.Assert.assertTrue("'" + jSTypeNative9 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative9.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray10);
        org.junit.Assert.assertNotNull(jSType11);
        org.junit.Assert.assertNotNull(functionType14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + jSTypeNative20 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative20.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray21);
        org.junit.Assert.assertNotNull(jSType22);
        org.junit.Assert.assertTrue("'" + jSTypeNative26 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative26.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray27);
        org.junit.Assert.assertNotNull(jSType28);
        org.junit.Assert.assertNotNull(functionType31);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(objectTypeIterable35);
        org.junit.Assert.assertTrue("'" + jSTypeNative39 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative39.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray40);
        org.junit.Assert.assertNotNull(jSType41);
        org.junit.Assert.assertTrue("'" + jSTypeNative45 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative45.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray46);
        org.junit.Assert.assertNotNull(jSType47);
        org.junit.Assert.assertNotNull(functionType50);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertTrue("'" + jSTypeNative56 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative56.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray57);
        org.junit.Assert.assertNotNull(jSType58);
        org.junit.Assert.assertTrue("'" + jSTypeNative62 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative62.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray63);
        org.junit.Assert.assertNotNull(jSType64);
        org.junit.Assert.assertNotNull(functionType67);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
        org.junit.Assert.assertNotNull(jSType71);
        org.junit.Assert.assertNotNull(objectType72);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + true + "'", boolean76 == true);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.GLOBAL_THIS;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.GLOBAL_THIS + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.GLOBAL_THIS));
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newString("hi!");
        node1.setOptionalArg(true);
        org.junit.Assert.assertNotNull(node1);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.PerformanceTracker performanceTracker2 = compiler1.tracker;
        com.google.javascript.jscomp.SourceMap sourceMap3 = compiler1.getSourceMap();
        org.junit.Assert.assertNull(performanceTracker2);
        org.junit.Assert.assertNull(sourceMap3);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode3 = new com.google.javascript.rhino.ScriptOrFnNode(11, 130, (int) (short) 100);
        int int6 = scriptOrFnNode3.addRegexp("language version", "hi!");
        int int7 = scriptOrFnNode3.getEndLineno();
        java.lang.String str9 = scriptOrFnNode3.getRegexpString(0);
        boolean boolean10 = scriptOrFnNode3.isUnscopedQualifiedName();
        boolean boolean11 = scriptOrFnNode3.hasMoreThanOneChild();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "language version" + "'", str9.equals("language version"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        int int0 = com.google.javascript.rhino.Token.GETVAR;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 54 + "'", int0 == 54);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative3 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray4 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative3 };
        com.google.javascript.rhino.jstype.JSType jSType5 = jSTypeRegistry2.createUnionType(jSTypeNativeArray4);
        com.google.javascript.rhino.ErrorReporter errorReporter6 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry8 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter6, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative9 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray10 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative9 };
        com.google.javascript.rhino.jstype.JSType jSType11 = jSTypeRegistry8.createUnionType(jSTypeNativeArray10);
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node((-1));
        com.google.javascript.rhino.jstype.FunctionType functionType14 = jSTypeRegistry2.createFunctionType(jSType11, node13);
        boolean boolean15 = functionType14.matchesInt32Context();
        com.google.javascript.rhino.Node node16 = functionType14.getSource();
        com.google.javascript.rhino.JSDocInfo jSDocInfo17 = functionType14.getJSDocInfo();
        org.junit.Assert.assertTrue("'" + jSTypeNative3 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative3.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray4);
        org.junit.Assert.assertNotNull(jSType5);
        org.junit.Assert.assertTrue("'" + jSTypeNative9 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative9.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray10);
        org.junit.Assert.assertNotNull(jSType11);
        org.junit.Assert.assertNotNull(functionType14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNull(node16);
        org.junit.Assert.assertNull(jSDocInfo17);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        int int0 = com.google.javascript.rhino.Node.SPECIAL_PROP_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 18 + "'", int0 == 18);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        java.util.Map<java.lang.String, com.google.javascript.rhino.jstype.JSType> strMap2 = null;
        try {
            com.google.javascript.rhino.jstype.RecordType recordType3 = jSTypeRegistry1.createRecordType(strMap2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.EVAL_ERROR_TYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.EVAL_ERROR_TYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.EVAL_ERROR_TYPE));
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        int int0 = com.google.javascript.rhino.Token.OR;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 100 + "'", int0 == 100);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        com.google.javascript.jscomp.SourceAst sourceAst0 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(sourceAst0, "", true);
        try {
            java.util.Collection<java.lang.String> strCollection4 = compilerInput3.getRequires();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Expected setErrorManager to be called first");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative3 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray4 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative3 };
        com.google.javascript.rhino.jstype.JSType jSType5 = jSTypeRegistry2.createUnionType(jSTypeNativeArray4);
        com.google.javascript.rhino.ErrorReporter errorReporter6 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry8 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter6, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative9 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray10 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative9 };
        com.google.javascript.rhino.jstype.JSType jSType11 = jSTypeRegistry8.createUnionType(jSTypeNativeArray10);
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node((-1));
        com.google.javascript.rhino.jstype.FunctionType functionType14 = jSTypeRegistry2.createFunctionType(jSType11, node13);
        com.google.javascript.rhino.ErrorReporter errorReporter15 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry17 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter15, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative18 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray19 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative18 };
        com.google.javascript.rhino.jstype.JSType jSType20 = jSTypeRegistry17.createUnionType(jSTypeNativeArray19);
        com.google.javascript.rhino.ErrorReporter errorReporter21 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry23 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter21, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative24 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray25 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative24 };
        com.google.javascript.rhino.jstype.JSType jSType26 = jSTypeRegistry23.createUnionType(jSTypeNativeArray25);
        com.google.javascript.rhino.Node node28 = new com.google.javascript.rhino.Node((-1));
        com.google.javascript.rhino.jstype.FunctionType functionType29 = jSTypeRegistry17.createFunctionType(jSType26, node28);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray30 = new com.google.javascript.rhino.jstype.JSType[] { jSType26 };
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList31 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean32 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList31, jSTypeArray30);
        com.google.javascript.rhino.Node node33 = jSTypeRegistry2.createParametersWithVarArgs((java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList31);
        jSTypeRegistry2.setLastGeneration(false);
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope36 = null;
        com.google.javascript.rhino.jstype.JSType jSType41 = jSTypeRegistry2.getType(jSTypeStaticScope36, "TYPEOF", "EOF", (int) (short) 10, 76);
        com.google.javascript.rhino.ErrorReporter errorReporter42 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry44 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter42, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative45 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray46 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative45 };
        com.google.javascript.rhino.jstype.JSType jSType47 = jSTypeRegistry44.createUnionType(jSTypeNativeArray46);
        com.google.javascript.rhino.ErrorReporter errorReporter48 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry50 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter48, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative51 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray52 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative51 };
        com.google.javascript.rhino.jstype.JSType jSType53 = jSTypeRegistry50.createUnionType(jSTypeNativeArray52);
        com.google.javascript.rhino.Node node55 = new com.google.javascript.rhino.Node((-1));
        com.google.javascript.rhino.jstype.FunctionType functionType56 = jSTypeRegistry44.createFunctionType(jSType53, node55);
        boolean boolean58 = functionType56.hasOwnProperty("hi!");
        com.google.javascript.rhino.jstype.FunctionPrototypeType functionPrototypeType59 = null;
        boolean boolean60 = functionType56.setPrototype(functionPrototypeType59);
        java.lang.String str61 = functionType56.getDisplayName();
        com.google.javascript.rhino.ErrorReporter errorReporter62 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry64 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter62, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative65 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray66 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative65 };
        com.google.javascript.rhino.jstype.JSType jSType67 = jSTypeRegistry64.createUnionType(jSTypeNativeArray66);
        com.google.javascript.rhino.ErrorReporter errorReporter68 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry70 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter68, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative71 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray72 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative71 };
        com.google.javascript.rhino.jstype.JSType jSType73 = jSTypeRegistry70.createUnionType(jSTypeNativeArray72);
        com.google.javascript.rhino.Node node75 = new com.google.javascript.rhino.Node((-1));
        com.google.javascript.rhino.jstype.FunctionType functionType76 = jSTypeRegistry64.createFunctionType(jSType73, node75);
        com.google.javascript.rhino.ErrorReporter errorReporter77 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry79 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter77, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative80 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray81 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative80 };
        com.google.javascript.rhino.jstype.JSType jSType82 = jSTypeRegistry79.createUnionType(jSTypeNativeArray81);
        com.google.javascript.rhino.ErrorReporter errorReporter83 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry85 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter83, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative86 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray87 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative86 };
        com.google.javascript.rhino.jstype.JSType jSType88 = jSTypeRegistry85.createUnionType(jSTypeNativeArray87);
        com.google.javascript.rhino.Node node90 = new com.google.javascript.rhino.Node((-1));
        com.google.javascript.rhino.jstype.FunctionType functionType91 = jSTypeRegistry79.createFunctionType(jSType88, node90);
        boolean boolean93 = functionType91.hasOwnProperty("hi!");
        com.google.javascript.rhino.jstype.ObjectType objectType94 = jSTypeRegistry64.createObjectType((com.google.javascript.rhino.jstype.ObjectType) functionType91);
        java.lang.String str95 = functionType91.getNormalizedReferenceName();
        com.google.javascript.rhino.jstype.FunctionType functionType96 = jSTypeRegistry2.createFunctionTypeWithNewThisType(functionType56, (com.google.javascript.rhino.jstype.ObjectType) functionType91);
        boolean boolean98 = functionType91.equals((java.lang.Object) 29);
        org.junit.Assert.assertTrue("'" + jSTypeNative3 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative3.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray4);
        org.junit.Assert.assertNotNull(jSType5);
        org.junit.Assert.assertTrue("'" + jSTypeNative9 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative9.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray10);
        org.junit.Assert.assertNotNull(jSType11);
        org.junit.Assert.assertNotNull(functionType14);
        org.junit.Assert.assertTrue("'" + jSTypeNative18 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative18.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray19);
        org.junit.Assert.assertNotNull(jSType20);
        org.junit.Assert.assertTrue("'" + jSTypeNative24 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative24.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray25);
        org.junit.Assert.assertNotNull(jSType26);
        org.junit.Assert.assertNotNull(functionType29);
        org.junit.Assert.assertNotNull(jSTypeArray30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNotNull(node33);
        org.junit.Assert.assertNotNull(jSType41);
        org.junit.Assert.assertTrue("'" + jSTypeNative45 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative45.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray46);
        org.junit.Assert.assertNotNull(jSType47);
        org.junit.Assert.assertTrue("'" + jSTypeNative51 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative51.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray52);
        org.junit.Assert.assertNotNull(jSType53);
        org.junit.Assert.assertNotNull(functionType56);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertNull(str61);
        org.junit.Assert.assertTrue("'" + jSTypeNative65 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative65.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray66);
        org.junit.Assert.assertNotNull(jSType67);
        org.junit.Assert.assertTrue("'" + jSTypeNative71 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative71.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray72);
        org.junit.Assert.assertNotNull(jSType73);
        org.junit.Assert.assertNotNull(functionType76);
        org.junit.Assert.assertTrue("'" + jSTypeNative80 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative80.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray81);
        org.junit.Assert.assertNotNull(jSType82);
        org.junit.Assert.assertTrue("'" + jSTypeNative86 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative86.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray87);
        org.junit.Assert.assertNotNull(jSType88);
        org.junit.Assert.assertNotNull(functionType91);
        org.junit.Assert.assertTrue("'" + boolean93 + "' != '" + false + "'", boolean93 == false);
        org.junit.Assert.assertNotNull(objectType94);
        org.junit.Assert.assertNull(str95);
        org.junit.Assert.assertNotNull(functionType96);
        org.junit.Assert.assertTrue("'" + boolean98 + "' != '" + false + "'", boolean98 == false);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.EXTERNS_VALIDATION;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.disambiguateProperties;
        boolean boolean2 = compilerOptions0.strictMessageReplacement;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative3 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray4 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative3 };
        com.google.javascript.rhino.jstype.JSType jSType5 = jSTypeRegistry2.createUnionType(jSTypeNativeArray4);
        com.google.javascript.rhino.ErrorReporter errorReporter6 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry8 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter6, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative9 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray10 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative9 };
        com.google.javascript.rhino.jstype.JSType jSType11 = jSTypeRegistry8.createUnionType(jSTypeNativeArray10);
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node((-1));
        com.google.javascript.rhino.jstype.FunctionType functionType14 = jSTypeRegistry2.createFunctionType(jSType11, node13);
        boolean boolean16 = functionType14.hasOwnProperty("hi!");
        com.google.javascript.rhino.ErrorReporter errorReporter17 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry19 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter17, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative20 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray21 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative20 };
        com.google.javascript.rhino.jstype.JSType jSType22 = jSTypeRegistry19.createUnionType(jSTypeNativeArray21);
        com.google.javascript.rhino.ErrorReporter errorReporter23 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry25 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter23, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative26 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray27 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative26 };
        com.google.javascript.rhino.jstype.JSType jSType28 = jSTypeRegistry25.createUnionType(jSTypeNativeArray27);
        com.google.javascript.rhino.Node node30 = new com.google.javascript.rhino.Node((-1));
        com.google.javascript.rhino.jstype.FunctionType functionType31 = jSTypeRegistry19.createFunctionType(jSType28, node30);
        boolean boolean33 = functionType31.hasOwnProperty("hi!");
        functionType14.setPrototypeBasedOn((com.google.javascript.rhino.jstype.ObjectType) functionType31);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable35 = functionType14.getCtorImplementedInterfaces();
        com.google.javascript.rhino.ErrorReporter errorReporter36 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry38 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter36, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative39 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray40 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative39 };
        com.google.javascript.rhino.jstype.JSType jSType41 = jSTypeRegistry38.createUnionType(jSTypeNativeArray40);
        com.google.javascript.rhino.ErrorReporter errorReporter42 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry44 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter42, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative45 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray46 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative45 };
        com.google.javascript.rhino.jstype.JSType jSType47 = jSTypeRegistry44.createUnionType(jSTypeNativeArray46);
        com.google.javascript.rhino.Node node49 = new com.google.javascript.rhino.Node((-1));
        com.google.javascript.rhino.jstype.FunctionType functionType50 = jSTypeRegistry38.createFunctionType(jSType47, node49);
        boolean boolean52 = functionType50.hasOwnProperty("hi!");
        com.google.javascript.rhino.ErrorReporter errorReporter53 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry55 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter53, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative56 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray57 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative56 };
        com.google.javascript.rhino.jstype.JSType jSType58 = jSTypeRegistry55.createUnionType(jSTypeNativeArray57);
        com.google.javascript.rhino.ErrorReporter errorReporter59 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry61 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter59, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative62 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray63 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative62 };
        com.google.javascript.rhino.jstype.JSType jSType64 = jSTypeRegistry61.createUnionType(jSTypeNativeArray63);
        com.google.javascript.rhino.Node node66 = new com.google.javascript.rhino.Node((-1));
        com.google.javascript.rhino.jstype.FunctionType functionType67 = jSTypeRegistry55.createFunctionType(jSType64, node66);
        boolean boolean69 = functionType67.hasOwnProperty("hi!");
        functionType50.setPrototypeBasedOn((com.google.javascript.rhino.jstype.ObjectType) functionType67);
        com.google.javascript.rhino.jstype.JSType jSType71 = functionType14.getLeastSupertype((com.google.javascript.rhino.jstype.JSType) functionType50);
        com.google.javascript.rhino.jstype.ObjectType objectType72 = functionType14.getImplicitPrototype();
        boolean boolean74 = functionType14.hasOwnProperty("hi!");
        int int75 = functionType14.getPropertiesCount();
        com.google.javascript.rhino.JSDocInfo jSDocInfo76 = functionType14.getJSDocInfo();
        boolean boolean77 = functionType14.isObject();
        org.junit.Assert.assertTrue("'" + jSTypeNative3 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative3.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray4);
        org.junit.Assert.assertNotNull(jSType5);
        org.junit.Assert.assertTrue("'" + jSTypeNative9 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative9.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray10);
        org.junit.Assert.assertNotNull(jSType11);
        org.junit.Assert.assertNotNull(functionType14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + jSTypeNative20 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative20.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray21);
        org.junit.Assert.assertNotNull(jSType22);
        org.junit.Assert.assertTrue("'" + jSTypeNative26 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative26.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray27);
        org.junit.Assert.assertNotNull(jSType28);
        org.junit.Assert.assertNotNull(functionType31);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(objectTypeIterable35);
        org.junit.Assert.assertTrue("'" + jSTypeNative39 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative39.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray40);
        org.junit.Assert.assertNotNull(jSType41);
        org.junit.Assert.assertTrue("'" + jSTypeNative45 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative45.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray46);
        org.junit.Assert.assertNotNull(jSType47);
        org.junit.Assert.assertNotNull(functionType50);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertTrue("'" + jSTypeNative56 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative56.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray57);
        org.junit.Assert.assertNotNull(jSType58);
        org.junit.Assert.assertTrue("'" + jSTypeNative62 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative62.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray63);
        org.junit.Assert.assertNotNull(jSType64);
        org.junit.Assert.assertNotNull(functionType67);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
        org.junit.Assert.assertNotNull(jSType71);
        org.junit.Assert.assertNotNull(objectType72);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
        org.junit.Assert.assertTrue("'" + int75 + "' != '" + 0 + "'", int75 == 0);
        org.junit.Assert.assertNull(jSDocInfo76);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + true + "'", boolean77 == true);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative3 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray4 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative3 };
        com.google.javascript.rhino.jstype.JSType jSType5 = jSTypeRegistry2.createUnionType(jSTypeNativeArray4);
        com.google.javascript.rhino.ErrorReporter errorReporter6 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry8 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter6, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative9 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray10 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative9 };
        com.google.javascript.rhino.jstype.JSType jSType11 = jSTypeRegistry8.createUnionType(jSTypeNativeArray10);
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node((-1));
        com.google.javascript.rhino.jstype.FunctionType functionType14 = jSTypeRegistry2.createFunctionType(jSType11, node13);
        boolean boolean16 = functionType14.hasOwnProperty("hi!");
        com.google.javascript.rhino.ErrorReporter errorReporter17 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry19 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter17, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative20 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray21 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative20 };
        com.google.javascript.rhino.jstype.JSType jSType22 = jSTypeRegistry19.createUnionType(jSTypeNativeArray21);
        com.google.javascript.rhino.ErrorReporter errorReporter23 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry25 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter23, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative26 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray27 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative26 };
        com.google.javascript.rhino.jstype.JSType jSType28 = jSTypeRegistry25.createUnionType(jSTypeNativeArray27);
        com.google.javascript.rhino.Node node30 = new com.google.javascript.rhino.Node((-1));
        com.google.javascript.rhino.jstype.FunctionType functionType31 = jSTypeRegistry19.createFunctionType(jSType28, node30);
        boolean boolean33 = functionType31.hasOwnProperty("hi!");
        functionType14.setPrototypeBasedOn((com.google.javascript.rhino.jstype.ObjectType) functionType31);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable35 = functionType14.getCtorImplementedInterfaces();
        com.google.javascript.rhino.ErrorReporter errorReporter36 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry38 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter36, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative39 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray40 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative39 };
        com.google.javascript.rhino.jstype.JSType jSType41 = jSTypeRegistry38.createUnionType(jSTypeNativeArray40);
        com.google.javascript.rhino.ErrorReporter errorReporter42 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry44 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter42, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative45 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray46 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative45 };
        com.google.javascript.rhino.jstype.JSType jSType47 = jSTypeRegistry44.createUnionType(jSTypeNativeArray46);
        com.google.javascript.rhino.Node node49 = new com.google.javascript.rhino.Node((-1));
        com.google.javascript.rhino.jstype.FunctionType functionType50 = jSTypeRegistry38.createFunctionType(jSType47, node49);
        boolean boolean52 = functionType50.hasOwnProperty("hi!");
        com.google.javascript.rhino.ErrorReporter errorReporter53 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry55 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter53, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative56 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray57 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative56 };
        com.google.javascript.rhino.jstype.JSType jSType58 = jSTypeRegistry55.createUnionType(jSTypeNativeArray57);
        com.google.javascript.rhino.ErrorReporter errorReporter59 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry61 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter59, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative62 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray63 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative62 };
        com.google.javascript.rhino.jstype.JSType jSType64 = jSTypeRegistry61.createUnionType(jSTypeNativeArray63);
        com.google.javascript.rhino.Node node66 = new com.google.javascript.rhino.Node((-1));
        com.google.javascript.rhino.jstype.FunctionType functionType67 = jSTypeRegistry55.createFunctionType(jSType64, node66);
        boolean boolean69 = functionType67.hasOwnProperty("hi!");
        functionType50.setPrototypeBasedOn((com.google.javascript.rhino.jstype.ObjectType) functionType67);
        com.google.javascript.rhino.jstype.JSType jSType71 = functionType14.getLeastSupertype((com.google.javascript.rhino.jstype.JSType) functionType50);
        boolean boolean72 = functionType50.isCheckedUnknownType();
        boolean boolean73 = functionType50.isNativeObjectType();
        org.junit.Assert.assertTrue("'" + jSTypeNative3 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative3.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray4);
        org.junit.Assert.assertNotNull(jSType5);
        org.junit.Assert.assertTrue("'" + jSTypeNative9 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative9.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray10);
        org.junit.Assert.assertNotNull(jSType11);
        org.junit.Assert.assertNotNull(functionType14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + jSTypeNative20 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative20.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray21);
        org.junit.Assert.assertNotNull(jSType22);
        org.junit.Assert.assertTrue("'" + jSTypeNative26 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative26.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray27);
        org.junit.Assert.assertNotNull(jSType28);
        org.junit.Assert.assertNotNull(functionType31);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(objectTypeIterable35);
        org.junit.Assert.assertTrue("'" + jSTypeNative39 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative39.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray40);
        org.junit.Assert.assertNotNull(jSType41);
        org.junit.Assert.assertTrue("'" + jSTypeNative45 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative45.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray46);
        org.junit.Assert.assertNotNull(jSType47);
        org.junit.Assert.assertNotNull(functionType50);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertTrue("'" + jSTypeNative56 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative56.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray57);
        org.junit.Assert.assertNotNull(jSType58);
        org.junit.Assert.assertTrue("'" + jSTypeNative62 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative62.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray63);
        org.junit.Assert.assertNotNull(jSType64);
        org.junit.Assert.assertNotNull(functionType67);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
        org.junit.Assert.assertNotNull(jSType71);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
    }

//    @Test
//    public void test287() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test287");
//        try {
//            com.google.javascript.rhino.EvaluatorException evaluatorException1 = com.google.javascript.rhino.Context.reportRuntimeError("Fixed point computation not halting");
//            org.junit.Assert.fail("Expected exception of type com.google.javascript.rhino.EvaluatorException; message: Fixed point computation not halting");
//        } catch (com.google.javascript.rhino.EvaluatorException e) {
//        }
//    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.INVALID_CASTS;
        com.google.javascript.jscomp.DiagnosticGroups.CHECK_REGEXP = diagnosticGroup0;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.removeUnusedPrototypeProperties;
        compilerOptions0.removeEmptyFunctions = true;
        boolean boolean4 = compilerOptions0.instrumentForCoverageOnly;
        boolean boolean5 = compilerOptions0.crossModuleCodeMotion;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.DATE_TYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.DATE_TYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.DATE_TYPE));
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        int int0 = com.google.javascript.rhino.Token.XMLEND;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 144 + "'", int0 == 144);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.removeUnusedPrototypeProperties;
        compilerOptions0.removeEmptyFunctions = true;
        compilerOptions0.removeUnusedVars = false;
        compilerOptions0.gatherCssNames = true;
        compilerOptions0.setNameAnonymousFunctionsOnly(false);
        boolean boolean10 = compilerOptions0.instrumentForCoverage;
        compilerOptions0.checkMissingGetCssNameBlacklist = "EOF";
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.removeUnusedPrototypeProperties;
        compilerOptions0.nameReferenceGraphPath = "Unknown class name";
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        int int0 = com.google.javascript.rhino.Token.ENUM_NEXT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 59 + "'", int0 == 59);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode3 = new com.google.javascript.rhino.ScriptOrFnNode(11, 130, (int) (short) 100);
        int int6 = scriptOrFnNode3.addRegexp("language version", "hi!");
        java.lang.String str8 = scriptOrFnNode3.getRegexpFlags(0);
        scriptOrFnNode3.setOptionalArg(false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "hi!" + "'", str8.equals("hi!"));
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        int int0 = com.google.javascript.rhino.Token.GE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 17 + "'", int0 == 17);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        int int0 = com.google.javascript.rhino.Token.STRING;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 40 + "'", int0 == 40);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode3 = new com.google.javascript.rhino.ScriptOrFnNode(11, 130, (int) (short) 100);
        int int4 = scriptOrFnNode3.getEncodedSourceStart();
        boolean boolean6 = scriptOrFnNode3.addConst("hi!");
        scriptOrFnNode3.setEncodedSourceBounds((int) 'a', 54);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        int int0 = com.google.javascript.rhino.Token.ASSIGN;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 86 + "'", int0 == 86);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.disambiguateProperties;
        boolean boolean2 = compilerOptions0.ignoreCajaProperties;
        compilerOptions0.checkUnusedPropertiesEarly = false;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        java.io.InputStream inputStream1 = null;
        try {
            com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromInputStream("EOF", inputStream1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative3 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray4 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative3 };
        com.google.javascript.rhino.jstype.JSType jSType5 = jSTypeRegistry2.createUnionType(jSTypeNativeArray4);
        com.google.javascript.rhino.ErrorReporter errorReporter6 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry8 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter6, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative9 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray10 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative9 };
        com.google.javascript.rhino.jstype.JSType jSType11 = jSTypeRegistry8.createUnionType(jSTypeNativeArray10);
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node((-1));
        com.google.javascript.rhino.jstype.FunctionType functionType14 = jSTypeRegistry2.createFunctionType(jSType11, node13);
        com.google.javascript.rhino.ErrorReporter errorReporter15 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry17 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter15, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative18 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray19 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative18 };
        com.google.javascript.rhino.jstype.JSType jSType20 = jSTypeRegistry17.createUnionType(jSTypeNativeArray19);
        com.google.javascript.rhino.ErrorReporter errorReporter21 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry23 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter21, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative24 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray25 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative24 };
        com.google.javascript.rhino.jstype.JSType jSType26 = jSTypeRegistry23.createUnionType(jSTypeNativeArray25);
        com.google.javascript.rhino.Node node28 = new com.google.javascript.rhino.Node((-1));
        com.google.javascript.rhino.jstype.FunctionType functionType29 = jSTypeRegistry17.createFunctionType(jSType26, node28);
        boolean boolean31 = functionType29.hasOwnProperty("hi!");
        com.google.javascript.rhino.jstype.ObjectType objectType32 = jSTypeRegistry2.createObjectType((com.google.javascript.rhino.jstype.ObjectType) functionType29);
        java.lang.String str33 = functionType29.getNormalizedReferenceName();
        boolean boolean35 = functionType29.hasProperty("TYPEOF");
        org.junit.Assert.assertTrue("'" + jSTypeNative3 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative3.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray4);
        org.junit.Assert.assertNotNull(jSType5);
        org.junit.Assert.assertTrue("'" + jSTypeNative9 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative9.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray10);
        org.junit.Assert.assertNotNull(jSType11);
        org.junit.Assert.assertNotNull(functionType14);
        org.junit.Assert.assertTrue("'" + jSTypeNative18 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative18.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray19);
        org.junit.Assert.assertNotNull(jSType20);
        org.junit.Assert.assertTrue("'" + jSTypeNative24 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative24.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray25);
        org.junit.Assert.assertNotNull(jSType26);
        org.junit.Assert.assertNotNull(functionType29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(objectType32);
        org.junit.Assert.assertNull(str33);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        int int0 = com.google.javascript.rhino.Token.SETCONSTVAR;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 151 + "'", int0 == 151);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        int int0 = com.google.javascript.rhino.Node.EMPTY_BLOCK;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 38 + "'", int0 == 38);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        int int0 = com.google.javascript.rhino.Token.WHILE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 113 + "'", int0 == 113);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        com.google.javascript.rhino.JSDocInfoBuilder jSDocInfoBuilder1 = new com.google.javascript.rhino.JSDocInfoBuilder(true);
        boolean boolean3 = jSDocInfoBuilder1.recordBlockDescription("Fixed point computation not halting");
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.Node.newNumber((double) 150, (int) (byte) 10, (int) '4');
        jSDocInfoBuilder1.markTypeNode(node7, (int) (byte) 0, 0, 14, false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(node7);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        com.google.javascript.rhino.Node node1 = new com.google.javascript.rhino.Node((-1));
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString("hi!");
        com.google.javascript.rhino.Node node4 = node1.copyInformationFrom(node3);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(node4);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.STRING_VALUE_OR_OBJECT_TYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.STRING_VALUE_OR_OBJECT_TYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.STRING_VALUE_OR_OBJECT_TYPE));
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.common.collect.Multimap<com.google.javascript.jscomp.CustomPassExecutionTime, com.google.javascript.jscomp.CompilerPass> customPassExecutionTimeMultimap1 = null;
        compilerOptions0.customPasses = customPassExecutionTimeMultimap1;
        boolean boolean3 = compilerOptions0.inlineConstantVars;
        java.lang.String str4 = compilerOptions0.syntheticBlockStartMarker;
        compilerOptions0.decomposeExpressions = false;
        boolean boolean7 = compilerOptions0.checkTypes;
        java.lang.String str8 = compilerOptions0.sourceMapOutputPath;
        com.google.javascript.jscomp.CheckLevel checkLevel9 = compilerOptions0.brokenClosureRequiresLevel;
        compilerOptions0.aliasKeywords = false;
        compilerOptions0.disableRuntimeTypeCheck();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertTrue("'" + checkLevel9 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel9.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        try {
            com.google.javascript.rhino.Context.reportWarning("Fixed point computation not halting", "hi!", 54, "Fixed point computation not halting", 83);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: No Context associated with current Thread");
        } catch (java.lang.RuntimeException e) {
        }
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        com.google.javascript.rhino.Node.SideEffectFlags sideEffectFlags1 = new com.google.javascript.rhino.Node.SideEffectFlags((int) (short) 1);
        sideEffectFlags1.setReturnsTainted();
        sideEffectFlags1.setMutatesArguments();
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.common.collect.Multimap<com.google.javascript.jscomp.CustomPassExecutionTime, com.google.javascript.jscomp.CompilerPass> customPassExecutionTimeMultimap1 = null;
        compilerOptions0.customPasses = customPassExecutionTimeMultimap1;
        boolean boolean3 = compilerOptions0.inlineConstantVars;
        java.lang.String str4 = compilerOptions0.syntheticBlockStartMarker;
        compilerOptions0.decomposeExpressions = false;
        boolean boolean7 = compilerOptions0.checkTypes;
        java.lang.String str8 = compilerOptions0.sourceMapOutputPath;
        compilerOptions0.setDefineToNumberLiteral("Named type with empty name component", 0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(str8);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newString("hi!");
        java.lang.String str2 = node1.toString();
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode6 = new com.google.javascript.rhino.ScriptOrFnNode(11, 130, (int) (short) 100);
        int int9 = scriptOrFnNode6.addRegexp("language version", "hi!");
        int int10 = scriptOrFnNode6.getEndLineno();
        java.lang.String str12 = scriptOrFnNode6.getRegexpString(0);
        com.google.javascript.rhino.Node node14 = new com.google.javascript.rhino.Node(83);
        try {
            node1.replaceChildAfter((com.google.javascript.rhino.Node) scriptOrFnNode6, node14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: prev is not a child of this node.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "STRING hi!" + "'", str2.equals("STRING hi!"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "language version" + "'", str12.equals("language version"));
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        int int0 = com.google.javascript.rhino.Token.SETPROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 34 + "'", int0 == 34);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        int int0 = com.google.javascript.rhino.Token.DO;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 114 + "'", int0 == 114);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.common.collect.Multimap<com.google.javascript.jscomp.CustomPassExecutionTime, com.google.javascript.jscomp.CompilerPass> customPassExecutionTimeMultimap1 = null;
        compilerOptions0.customPasses = customPassExecutionTimeMultimap1;
        boolean boolean3 = compilerOptions0.inlineConstantVars;
        java.lang.String str4 = compilerOptions0.syntheticBlockStartMarker;
        compilerOptions0.decomposeExpressions = false;
        boolean boolean7 = compilerOptions0.checkTypes;
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup8 = com.google.javascript.jscomp.DiagnosticGroups.INVALID_CASTS;
        com.google.javascript.jscomp.CompilerOptions compilerOptions9 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel10 = compilerOptions9.checkMissingGetCssNameLevel;
        compilerOptions0.setWarningLevel(diagnosticGroup8, checkLevel10);
        java.lang.String str12 = compilerOptions0.appNameStr;
        compilerOptions0.nameReferenceGraphPath = "language version";
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(diagnosticGroup8);
        org.junit.Assert.assertTrue("'" + checkLevel10 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel10.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.ideMode = true;
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        try {
            com.google.javascript.rhino.Context.reportWarning("EOF", "EOF", (int) (short) -1, "hi!", 0);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: No Context associated with current Thread");
        } catch (java.lang.RuntimeException e) {
        }
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        int int0 = com.google.javascript.rhino.Node.DIRECTIVES;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 47 + "'", int0 == 47);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.Node.newString((int) '#', "EOF");
        boolean boolean4 = node2.getBooleanProp(100);
        boolean boolean5 = node2.isLocalResultCall();
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.ErrorReporter errorReporter3 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter3, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative6 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray7 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative6 };
        com.google.javascript.rhino.jstype.JSType jSType8 = jSTypeRegistry5.createUnionType(jSTypeNativeArray7);
        com.google.javascript.rhino.ErrorReporter errorReporter9 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry11 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter9, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative12 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray13 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative12 };
        com.google.javascript.rhino.jstype.JSType jSType14 = jSTypeRegistry11.createUnionType(jSTypeNativeArray13);
        com.google.javascript.rhino.Node node16 = new com.google.javascript.rhino.Node((-1));
        com.google.javascript.rhino.jstype.FunctionType functionType17 = jSTypeRegistry5.createFunctionType(jSType14, node16);
        com.google.javascript.rhino.Node node18 = new com.google.javascript.rhino.Node((int) ' ', node16);
        com.google.javascript.rhino.Node node19 = new com.google.javascript.rhino.Node((int) ' ', node18);
        java.lang.String str20 = closureCodingConvention0.getSingletonGetterClassName(node18);
        com.google.javascript.rhino.Node node24 = com.google.javascript.rhino.Node.newString("EOF", 93, 28);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode28 = new com.google.javascript.rhino.ScriptOrFnNode(11, 130, (int) (short) 100);
        int int29 = scriptOrFnNode28.getEncodedSourceStart();
        boolean boolean31 = scriptOrFnNode28.addConst("hi!");
        java.lang.String str32 = closureCodingConvention0.extractClassNameIfProvide(node24, (com.google.javascript.rhino.Node) scriptOrFnNode28);
        com.google.javascript.rhino.ErrorReporter errorReporter34 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry36 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter34, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative37 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray38 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative37 };
        com.google.javascript.rhino.jstype.JSType jSType39 = jSTypeRegistry36.createUnionType(jSTypeNativeArray38);
        com.google.javascript.rhino.ErrorReporter errorReporter40 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry42 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter40, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative43 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray44 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative43 };
        com.google.javascript.rhino.jstype.JSType jSType45 = jSTypeRegistry42.createUnionType(jSTypeNativeArray44);
        com.google.javascript.rhino.Node node47 = new com.google.javascript.rhino.Node((-1));
        com.google.javascript.rhino.jstype.FunctionType functionType48 = jSTypeRegistry36.createFunctionType(jSType45, node47);
        com.google.javascript.rhino.Node node49 = new com.google.javascript.rhino.Node((int) ' ', node47);
        try {
            boolean boolean50 = closureCodingConvention0.isPropertyTestFunction(node47);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + jSTypeNative6 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative6.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray7);
        org.junit.Assert.assertNotNull(jSType8);
        org.junit.Assert.assertTrue("'" + jSTypeNative12 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative12.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray13);
        org.junit.Assert.assertNotNull(jSType14);
        org.junit.Assert.assertNotNull(functionType17);
        org.junit.Assert.assertNull(str20);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertNull(str32);
        org.junit.Assert.assertTrue("'" + jSTypeNative37 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative37.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray38);
        org.junit.Assert.assertNotNull(jSType39);
        org.junit.Assert.assertTrue("'" + jSTypeNative43 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative43.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray44);
        org.junit.Assert.assertNotNull(jSType45);
        org.junit.Assert.assertNotNull(functionType48);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        int int0 = com.google.javascript.rhino.Context.VERSION_DEFAULT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative3 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray4 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative3 };
        com.google.javascript.rhino.jstype.JSType jSType5 = jSTypeRegistry2.createUnionType(jSTypeNativeArray4);
        com.google.javascript.rhino.ErrorReporter errorReporter6 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry8 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter6, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative9 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray10 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative9 };
        com.google.javascript.rhino.jstype.JSType jSType11 = jSTypeRegistry8.createUnionType(jSTypeNativeArray10);
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node((-1));
        com.google.javascript.rhino.jstype.FunctionType functionType14 = jSTypeRegistry2.createFunctionType(jSType11, node13);
        com.google.javascript.rhino.jstype.ObjectType objectType15 = jSTypeRegistry2.createAnonymousObjectType();
        com.google.javascript.rhino.ErrorReporter errorReporter17 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry19 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter17, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative20 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray21 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative20 };
        com.google.javascript.rhino.jstype.JSType jSType22 = jSTypeRegistry19.createUnionType(jSTypeNativeArray21);
        com.google.javascript.rhino.ErrorReporter errorReporter23 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry25 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter23, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative26 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray27 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative26 };
        com.google.javascript.rhino.jstype.JSType jSType28 = jSTypeRegistry25.createUnionType(jSTypeNativeArray27);
        com.google.javascript.rhino.Node node30 = new com.google.javascript.rhino.Node((-1));
        com.google.javascript.rhino.jstype.FunctionType functionType31 = jSTypeRegistry19.createFunctionType(jSType28, node30);
        com.google.javascript.rhino.ErrorReporter errorReporter32 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry34 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter32, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative35 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray36 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative35 };
        com.google.javascript.rhino.jstype.JSType jSType37 = jSTypeRegistry34.createUnionType(jSTypeNativeArray36);
        com.google.javascript.rhino.ErrorReporter errorReporter38 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry40 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter38, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative41 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray42 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative41 };
        com.google.javascript.rhino.jstype.JSType jSType43 = jSTypeRegistry40.createUnionType(jSTypeNativeArray42);
        com.google.javascript.rhino.Node node45 = new com.google.javascript.rhino.Node((-1));
        com.google.javascript.rhino.jstype.FunctionType functionType46 = jSTypeRegistry34.createFunctionType(jSType43, node45);
        com.google.javascript.rhino.ErrorReporter errorReporter47 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry49 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter47, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative50 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray51 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative50 };
        com.google.javascript.rhino.jstype.JSType jSType52 = jSTypeRegistry49.createUnionType(jSTypeNativeArray51);
        com.google.javascript.rhino.ErrorReporter errorReporter53 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry55 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter53, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative56 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray57 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative56 };
        com.google.javascript.rhino.jstype.JSType jSType58 = jSTypeRegistry55.createUnionType(jSTypeNativeArray57);
        com.google.javascript.rhino.Node node60 = new com.google.javascript.rhino.Node((-1));
        com.google.javascript.rhino.jstype.FunctionType functionType61 = jSTypeRegistry49.createFunctionType(jSType58, node60);
        boolean boolean63 = functionType61.hasOwnProperty("hi!");
        com.google.javascript.rhino.jstype.ObjectType objectType64 = jSTypeRegistry34.createObjectType((com.google.javascript.rhino.jstype.ObjectType) functionType61);
        com.google.javascript.rhino.jstype.JSType.TypePair typePair65 = jSType28.getTypesUnderShallowInequality((com.google.javascript.rhino.jstype.JSType) objectType64);
        jSTypeRegistry2.registerPropertyOnType("goog.exportSymbol", jSType28);
        com.google.javascript.rhino.jstype.JSType jSType71 = jSTypeRegistry2.createNamedType("STRING hi!", "TYPEOF", 47, (int) '#');
        org.junit.Assert.assertTrue("'" + jSTypeNative3 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative3.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray4);
        org.junit.Assert.assertNotNull(jSType5);
        org.junit.Assert.assertTrue("'" + jSTypeNative9 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative9.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray10);
        org.junit.Assert.assertNotNull(jSType11);
        org.junit.Assert.assertNotNull(functionType14);
        org.junit.Assert.assertNotNull(objectType15);
        org.junit.Assert.assertTrue("'" + jSTypeNative20 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative20.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray21);
        org.junit.Assert.assertNotNull(jSType22);
        org.junit.Assert.assertTrue("'" + jSTypeNative26 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative26.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray27);
        org.junit.Assert.assertNotNull(jSType28);
        org.junit.Assert.assertNotNull(functionType31);
        org.junit.Assert.assertTrue("'" + jSTypeNative35 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative35.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray36);
        org.junit.Assert.assertNotNull(jSType37);
        org.junit.Assert.assertTrue("'" + jSTypeNative41 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative41.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray42);
        org.junit.Assert.assertNotNull(jSType43);
        org.junit.Assert.assertNotNull(functionType46);
        org.junit.Assert.assertTrue("'" + jSTypeNative50 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative50.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray51);
        org.junit.Assert.assertNotNull(jSType52);
        org.junit.Assert.assertTrue("'" + jSTypeNative56 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative56.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray57);
        org.junit.Assert.assertNotNull(jSType58);
        org.junit.Assert.assertNotNull(functionType61);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertNotNull(objectType64);
        org.junit.Assert.assertNotNull(typePair65);
        org.junit.Assert.assertNotNull(jSType71);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        int int0 = com.google.javascript.rhino.Token.EMPTY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 124 + "'", int0 == 124);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        java.io.File file0 = null;
        java.nio.charset.Charset charset1 = null;
        try {
            com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromFile(file0, charset1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        int int0 = com.google.javascript.rhino.Token.GET;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 147 + "'", int0 == 147);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        java.lang.String str0 = com.google.javascript.rhino.Context.errorReporterProperty;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "error reporter" + "'", str0.equals("error reporter"));
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        com.google.javascript.jscomp.SourceFile sourceFile1 = com.google.javascript.jscomp.SourceFile.fromFile("EOF");
        try {
            java.io.Reader reader2 = sourceFile1.getCodeReader();
            org.junit.Assert.fail("Expected exception of type java.io.FileNotFoundException; message: EOF (No such file or directory)");
        } catch (java.io.FileNotFoundException e) {
        }
        org.junit.Assert.assertNotNull(sourceFile1);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newString("hi!");
        java.lang.String str2 = node1.toString();
        java.lang.String str6 = node1.toString(false, false, false);
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "STRING hi!" + "'", str2.equals("STRING hi!"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "STRING hi!" + "'", str6.equals("STRING hi!"));
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        com.google.javascript.rhino.JSDocInfoBuilder jSDocInfoBuilder1 = new com.google.javascript.rhino.JSDocInfoBuilder(true);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode5 = new com.google.javascript.rhino.ScriptOrFnNode(11, 130, (int) (short) 100);
        int int6 = scriptOrFnNode5.getEncodedSourceStart();
        com.google.javascript.rhino.JSTypeExpression jSTypeExpression8 = new com.google.javascript.rhino.JSTypeExpression((com.google.javascript.rhino.Node) scriptOrFnNode5, "Named type with empty name component");
        boolean boolean9 = jSDocInfoBuilder1.recordThrowType(jSTypeExpression8);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode14 = new com.google.javascript.rhino.ScriptOrFnNode(11, 130, (int) (short) 100);
        int int15 = scriptOrFnNode14.getEncodedSourceStart();
        com.google.javascript.rhino.JSTypeExpression jSTypeExpression17 = new com.google.javascript.rhino.JSTypeExpression((com.google.javascript.rhino.Node) scriptOrFnNode14, "Named type with empty name component");
        boolean boolean18 = jSDocInfoBuilder1.recordParameter("EOF", jSTypeExpression17);
        com.google.javascript.rhino.JSDocInfoBuilder jSDocInfoBuilder20 = new com.google.javascript.rhino.JSDocInfoBuilder(true);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode24 = new com.google.javascript.rhino.ScriptOrFnNode(11, 130, (int) (short) 100);
        int int25 = scriptOrFnNode24.getEncodedSourceStart();
        com.google.javascript.rhino.JSTypeExpression jSTypeExpression27 = new com.google.javascript.rhino.JSTypeExpression((com.google.javascript.rhino.Node) scriptOrFnNode24, "Named type with empty name component");
        boolean boolean28 = jSDocInfoBuilder20.recordThrowType(jSTypeExpression27);
        com.google.javascript.rhino.JSDocInfoBuilder jSDocInfoBuilder30 = new com.google.javascript.rhino.JSDocInfoBuilder(true);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode34 = new com.google.javascript.rhino.ScriptOrFnNode(11, 130, (int) (short) 100);
        int int35 = scriptOrFnNode34.getEncodedSourceStart();
        com.google.javascript.rhino.JSTypeExpression jSTypeExpression37 = new com.google.javascript.rhino.JSTypeExpression((com.google.javascript.rhino.Node) scriptOrFnNode34, "Named type with empty name component");
        boolean boolean38 = jSDocInfoBuilder30.recordThrowType(jSTypeExpression37);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode43 = new com.google.javascript.rhino.ScriptOrFnNode(11, 130, (int) (short) 100);
        int int44 = scriptOrFnNode43.getEncodedSourceStart();
        com.google.javascript.rhino.JSTypeExpression jSTypeExpression46 = new com.google.javascript.rhino.JSTypeExpression((com.google.javascript.rhino.Node) scriptOrFnNode43, "Named type with empty name component");
        boolean boolean47 = jSDocInfoBuilder30.recordParameter("EOF", jSTypeExpression46);
        boolean boolean49 = jSDocInfoBuilder20.recordThrowDescription(jSTypeExpression46, "Named type with empty name component");
        boolean boolean50 = jSDocInfoBuilder1.recordType(jSTypeExpression46);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.disambiguateProperties;
        com.google.javascript.jscomp.AnonymousFunctionNamingPolicy anonymousFunctionNamingPolicy2 = compilerOptions0.anonymousFunctionNaming;
        char[] charArray3 = anonymousFunctionNamingPolicy2.getReservedCharacters();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + anonymousFunctionNamingPolicy2 + "' != '" + com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF + "'", anonymousFunctionNamingPolicy2.equals(com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF));
        org.junit.Assert.assertNull(charArray3);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative3 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray4 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative3 };
        com.google.javascript.rhino.jstype.JSType jSType5 = jSTypeRegistry2.createUnionType(jSTypeNativeArray4);
        com.google.javascript.rhino.ErrorReporter errorReporter6 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry8 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter6, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative9 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray10 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative9 };
        com.google.javascript.rhino.jstype.JSType jSType11 = jSTypeRegistry8.createUnionType(jSTypeNativeArray10);
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node((-1));
        com.google.javascript.rhino.jstype.FunctionType functionType14 = jSTypeRegistry2.createFunctionType(jSType11, node13);
        boolean boolean16 = functionType14.hasOwnProperty("hi!");
        com.google.javascript.rhino.jstype.FunctionPrototypeType functionPrototypeType17 = null;
        boolean boolean18 = functionType14.setPrototype(functionPrototypeType17);
        com.google.javascript.rhino.ErrorReporter errorReporter19 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry21 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter19, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative22 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray23 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative22 };
        com.google.javascript.rhino.jstype.JSType jSType24 = jSTypeRegistry21.createUnionType(jSTypeNativeArray23);
        com.google.javascript.rhino.ErrorReporter errorReporter25 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry27 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter25, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative28 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray29 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative28 };
        com.google.javascript.rhino.jstype.JSType jSType30 = jSTypeRegistry27.createUnionType(jSTypeNativeArray29);
        com.google.javascript.rhino.Node node32 = new com.google.javascript.rhino.Node((-1));
        com.google.javascript.rhino.jstype.FunctionType functionType33 = jSTypeRegistry21.createFunctionType(jSType30, node32);
        com.google.javascript.rhino.ErrorReporter errorReporter34 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry36 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter34, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative37 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray38 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative37 };
        com.google.javascript.rhino.jstype.JSType jSType39 = jSTypeRegistry36.createUnionType(jSTypeNativeArray38);
        com.google.javascript.rhino.ErrorReporter errorReporter40 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry42 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter40, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative43 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray44 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative43 };
        com.google.javascript.rhino.jstype.JSType jSType45 = jSTypeRegistry42.createUnionType(jSTypeNativeArray44);
        com.google.javascript.rhino.Node node47 = new com.google.javascript.rhino.Node((-1));
        com.google.javascript.rhino.jstype.FunctionType functionType48 = jSTypeRegistry36.createFunctionType(jSType45, node47);
        boolean boolean50 = functionType48.hasOwnProperty("hi!");
        com.google.javascript.rhino.jstype.ObjectType objectType51 = jSTypeRegistry21.createObjectType((com.google.javascript.rhino.jstype.ObjectType) functionType48);
        com.google.javascript.rhino.ErrorReporter errorReporter52 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry54 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter52, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative55 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray56 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative55 };
        com.google.javascript.rhino.jstype.JSType jSType57 = jSTypeRegistry54.createUnionType(jSTypeNativeArray56);
        com.google.javascript.rhino.ErrorReporter errorReporter58 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry60 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter58, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative61 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray62 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative61 };
        com.google.javascript.rhino.jstype.JSType jSType63 = jSTypeRegistry60.createUnionType(jSTypeNativeArray62);
        com.google.javascript.rhino.Node node65 = new com.google.javascript.rhino.Node((-1));
        com.google.javascript.rhino.jstype.FunctionType functionType66 = jSTypeRegistry54.createFunctionType(jSType63, node65);
        boolean boolean68 = functionType66.hasOwnProperty("hi!");
        com.google.javascript.rhino.ErrorReporter errorReporter69 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry71 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter69, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative72 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray73 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative72 };
        com.google.javascript.rhino.jstype.JSType jSType74 = jSTypeRegistry71.createUnionType(jSTypeNativeArray73);
        com.google.javascript.rhino.ErrorReporter errorReporter75 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry77 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter75, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative78 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray79 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative78 };
        com.google.javascript.rhino.jstype.JSType jSType80 = jSTypeRegistry77.createUnionType(jSTypeNativeArray79);
        com.google.javascript.rhino.Node node82 = new com.google.javascript.rhino.Node((-1));
        com.google.javascript.rhino.jstype.FunctionType functionType83 = jSTypeRegistry71.createFunctionType(jSType80, node82);
        boolean boolean85 = functionType83.hasOwnProperty("hi!");
        functionType66.setPrototypeBasedOn((com.google.javascript.rhino.jstype.ObjectType) functionType83);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable87 = functionType66.getCtorImplementedInterfaces();
        boolean boolean88 = functionType66.isBooleanObjectType();
        boolean boolean89 = functionType48.hasEqualCallType(functionType66);
        boolean boolean90 = functionType48.isAllType();
        boolean boolean91 = com.google.javascript.rhino.jstype.JSType.isEquivalent((com.google.javascript.rhino.jstype.JSType) functionType14, (com.google.javascript.rhino.jstype.JSType) functionType48);
        org.junit.Assert.assertTrue("'" + jSTypeNative3 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative3.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray4);
        org.junit.Assert.assertNotNull(jSType5);
        org.junit.Assert.assertTrue("'" + jSTypeNative9 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative9.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray10);
        org.junit.Assert.assertNotNull(jSType11);
        org.junit.Assert.assertNotNull(functionType14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + jSTypeNative22 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative22.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray23);
        org.junit.Assert.assertNotNull(jSType24);
        org.junit.Assert.assertTrue("'" + jSTypeNative28 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative28.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray29);
        org.junit.Assert.assertNotNull(jSType30);
        org.junit.Assert.assertNotNull(functionType33);
        org.junit.Assert.assertTrue("'" + jSTypeNative37 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative37.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray38);
        org.junit.Assert.assertNotNull(jSType39);
        org.junit.Assert.assertTrue("'" + jSTypeNative43 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative43.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray44);
        org.junit.Assert.assertNotNull(jSType45);
        org.junit.Assert.assertNotNull(functionType48);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(objectType51);
        org.junit.Assert.assertTrue("'" + jSTypeNative55 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative55.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray56);
        org.junit.Assert.assertNotNull(jSType57);
        org.junit.Assert.assertTrue("'" + jSTypeNative61 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative61.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray62);
        org.junit.Assert.assertNotNull(jSType63);
        org.junit.Assert.assertNotNull(functionType66);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertTrue("'" + jSTypeNative72 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative72.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray73);
        org.junit.Assert.assertNotNull(jSType74);
        org.junit.Assert.assertTrue("'" + jSTypeNative78 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative78.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray79);
        org.junit.Assert.assertNotNull(jSType80);
        org.junit.Assert.assertNotNull(functionType83);
        org.junit.Assert.assertTrue("'" + boolean85 + "' != '" + false + "'", boolean85 == false);
        org.junit.Assert.assertNotNull(objectTypeIterable87);
        org.junit.Assert.assertTrue("'" + boolean88 + "' != '" + false + "'", boolean88 == false);
        org.junit.Assert.assertTrue("'" + boolean89 + "' != '" + false + "'", boolean89 == false);
        org.junit.Assert.assertTrue("'" + boolean90 + "' != '" + false + "'", boolean90 == false);
        org.junit.Assert.assertTrue("'" + boolean91 + "' != '" + false + "'", boolean91 == false);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        int int0 = com.google.javascript.rhino.Context.VERSION_UNKNOWN;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + (-1) + "'", int0 == (-1));
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        boolean boolean2 = closureCodingConvention0.isPrivate("EOF");
        com.google.javascript.rhino.ErrorReporter errorReporter3 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter3, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative6 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray7 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative6 };
        com.google.javascript.rhino.jstype.JSType jSType8 = jSTypeRegistry5.createUnionType(jSTypeNativeArray7);
        com.google.javascript.rhino.ErrorReporter errorReporter9 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry11 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter9, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative12 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray13 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative12 };
        com.google.javascript.rhino.jstype.JSType jSType14 = jSTypeRegistry11.createUnionType(jSTypeNativeArray13);
        com.google.javascript.rhino.Node node16 = new com.google.javascript.rhino.Node((-1));
        com.google.javascript.rhino.jstype.FunctionType functionType17 = jSTypeRegistry5.createFunctionType(jSType14, node16);
        boolean boolean18 = functionType17.matchesInt32Context();
        com.google.javascript.rhino.ErrorReporter errorReporter19 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry21 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter19, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative22 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray23 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative22 };
        com.google.javascript.rhino.jstype.JSType jSType24 = jSTypeRegistry21.createUnionType(jSTypeNativeArray23);
        com.google.javascript.rhino.ErrorReporter errorReporter25 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry27 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter25, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative28 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray29 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative28 };
        com.google.javascript.rhino.jstype.JSType jSType30 = jSTypeRegistry27.createUnionType(jSTypeNativeArray29);
        com.google.javascript.rhino.Node node32 = new com.google.javascript.rhino.Node((-1));
        com.google.javascript.rhino.jstype.FunctionType functionType33 = jSTypeRegistry21.createFunctionType(jSType30, node32);
        boolean boolean35 = functionType33.hasOwnProperty("hi!");
        com.google.javascript.rhino.jstype.FunctionPrototypeType functionPrototypeType36 = null;
        boolean boolean37 = functionType33.setPrototype(functionPrototypeType36);
        boolean boolean39 = functionType33.hasOwnProperty("");
        com.google.javascript.rhino.ErrorReporter errorReporter40 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry42 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter40, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative43 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray44 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative43 };
        com.google.javascript.rhino.jstype.JSType jSType45 = jSTypeRegistry42.createUnionType(jSTypeNativeArray44);
        com.google.javascript.rhino.ErrorReporter errorReporter46 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry48 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter46, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative49 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray50 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative49 };
        com.google.javascript.rhino.jstype.JSType jSType51 = jSTypeRegistry48.createUnionType(jSTypeNativeArray50);
        com.google.javascript.rhino.Node node53 = new com.google.javascript.rhino.Node((-1));
        com.google.javascript.rhino.jstype.FunctionType functionType54 = jSTypeRegistry42.createFunctionType(jSType51, node53);
        boolean boolean55 = functionType54.matchesInt32Context();
        boolean boolean56 = functionType54.isConstructor();
        functionType33.setPrototypeBasedOn((com.google.javascript.rhino.jstype.ObjectType) functionType54);
        com.google.javascript.rhino.jstype.FunctionType functionType58 = functionType54.getConstructor();
        com.google.javascript.rhino.ErrorReporter errorReporter59 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry61 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter59, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative62 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray63 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative62 };
        com.google.javascript.rhino.jstype.JSType jSType64 = jSTypeRegistry61.createUnionType(jSTypeNativeArray63);
        com.google.javascript.rhino.ErrorReporter errorReporter65 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry67 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter65, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative68 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray69 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative68 };
        com.google.javascript.rhino.jstype.JSType jSType70 = jSTypeRegistry67.createUnionType(jSTypeNativeArray69);
        com.google.javascript.rhino.Node node72 = new com.google.javascript.rhino.Node((-1));
        com.google.javascript.rhino.jstype.FunctionType functionType73 = jSTypeRegistry61.createFunctionType(jSType70, node72);
        com.google.javascript.rhino.ErrorReporter errorReporter74 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry76 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter74, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative77 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray78 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative77 };
        com.google.javascript.rhino.jstype.JSType jSType79 = jSTypeRegistry76.createUnionType(jSTypeNativeArray78);
        com.google.javascript.rhino.ErrorReporter errorReporter80 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry82 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter80, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative83 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray84 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative83 };
        com.google.javascript.rhino.jstype.JSType jSType85 = jSTypeRegistry82.createUnionType(jSTypeNativeArray84);
        com.google.javascript.rhino.Node node87 = new com.google.javascript.rhino.Node((-1));
        com.google.javascript.rhino.jstype.FunctionType functionType88 = jSTypeRegistry76.createFunctionType(jSType85, node87);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray89 = new com.google.javascript.rhino.jstype.JSType[] { jSType85 };
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList90 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean91 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList90, jSTypeArray89);
        com.google.javascript.rhino.Node node92 = jSTypeRegistry61.createParametersWithVarArgs((java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList90);
        jSTypeRegistry61.setLastGeneration(false);
        com.google.javascript.rhino.jstype.ObjectType objectType95 = jSTypeRegistry61.createAnonymousObjectType();
        boolean boolean96 = objectType95.hasCachedValues();
        closureCodingConvention0.applySingletonGetter(functionType17, functionType54, objectType95);
        java.util.Collection<com.google.javascript.jscomp.CodingConvention.AssertionFunctionSpec> assertionFunctionSpecCollection98 = closureCodingConvention0.getAssertionFunctions();
        java.util.Collection<com.google.javascript.jscomp.CodingConvention.AssertionFunctionSpec> assertionFunctionSpecCollection99 = closureCodingConvention0.getAssertionFunctions();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + jSTypeNative6 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative6.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray7);
        org.junit.Assert.assertNotNull(jSType8);
        org.junit.Assert.assertTrue("'" + jSTypeNative12 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative12.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray13);
        org.junit.Assert.assertNotNull(jSType14);
        org.junit.Assert.assertNotNull(functionType17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + jSTypeNative22 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative22.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray23);
        org.junit.Assert.assertNotNull(jSType24);
        org.junit.Assert.assertTrue("'" + jSTypeNative28 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative28.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray29);
        org.junit.Assert.assertNotNull(jSType30);
        org.junit.Assert.assertNotNull(functionType33);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + jSTypeNative43 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative43.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray44);
        org.junit.Assert.assertNotNull(jSType45);
        org.junit.Assert.assertTrue("'" + jSTypeNative49 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative49.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray50);
        org.junit.Assert.assertNotNull(jSType51);
        org.junit.Assert.assertNotNull(functionType54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertNull(functionType58);
        org.junit.Assert.assertTrue("'" + jSTypeNative62 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative62.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray63);
        org.junit.Assert.assertNotNull(jSType64);
        org.junit.Assert.assertTrue("'" + jSTypeNative68 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative68.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray69);
        org.junit.Assert.assertNotNull(jSType70);
        org.junit.Assert.assertNotNull(functionType73);
        org.junit.Assert.assertTrue("'" + jSTypeNative77 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative77.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray78);
        org.junit.Assert.assertNotNull(jSType79);
        org.junit.Assert.assertTrue("'" + jSTypeNative83 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative83.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray84);
        org.junit.Assert.assertNotNull(jSType85);
        org.junit.Assert.assertNotNull(functionType88);
        org.junit.Assert.assertNotNull(jSTypeArray89);
        org.junit.Assert.assertTrue("'" + boolean91 + "' != '" + true + "'", boolean91 == true);
        org.junit.Assert.assertNotNull(node92);
        org.junit.Assert.assertNotNull(objectType95);
        org.junit.Assert.assertTrue("'" + boolean96 + "' != '" + false + "'", boolean96 == false);
        org.junit.Assert.assertNotNull(assertionFunctionSpecCollection98);
        org.junit.Assert.assertNotNull(assertionFunctionSpecCollection99);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.CHECK_TYPES;
        com.google.javascript.jscomp.DiagnosticGroups.UNKNOWN_DEFINES = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticGroups.EXTERNS_VALIDATION = diagnosticGroup0;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative3 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray4 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative3 };
        com.google.javascript.rhino.jstype.JSType jSType5 = jSTypeRegistry2.createUnionType(jSTypeNativeArray4);
        com.google.javascript.rhino.ErrorReporter errorReporter6 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry8 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter6, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative9 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray10 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative9 };
        com.google.javascript.rhino.jstype.JSType jSType11 = jSTypeRegistry8.createUnionType(jSTypeNativeArray10);
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node((-1));
        com.google.javascript.rhino.jstype.FunctionType functionType14 = jSTypeRegistry2.createFunctionType(jSType11, node13);
        com.google.javascript.rhino.jstype.ObjectType objectType15 = jSTypeRegistry2.createAnonymousObjectType();
        com.google.javascript.rhino.ErrorReporter errorReporter17 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry19 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter17, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative20 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray21 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative20 };
        com.google.javascript.rhino.jstype.JSType jSType22 = jSTypeRegistry19.createUnionType(jSTypeNativeArray21);
        com.google.javascript.rhino.ErrorReporter errorReporter23 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry25 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter23, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative26 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray27 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative26 };
        com.google.javascript.rhino.jstype.JSType jSType28 = jSTypeRegistry25.createUnionType(jSTypeNativeArray27);
        com.google.javascript.rhino.Node node30 = new com.google.javascript.rhino.Node((-1));
        com.google.javascript.rhino.jstype.FunctionType functionType31 = jSTypeRegistry19.createFunctionType(jSType28, node30);
        com.google.javascript.rhino.ErrorReporter errorReporter32 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry34 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter32, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative35 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray36 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative35 };
        com.google.javascript.rhino.jstype.JSType jSType37 = jSTypeRegistry34.createUnionType(jSTypeNativeArray36);
        com.google.javascript.rhino.ErrorReporter errorReporter38 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry40 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter38, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative41 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray42 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative41 };
        com.google.javascript.rhino.jstype.JSType jSType43 = jSTypeRegistry40.createUnionType(jSTypeNativeArray42);
        com.google.javascript.rhino.Node node45 = new com.google.javascript.rhino.Node((-1));
        com.google.javascript.rhino.jstype.FunctionType functionType46 = jSTypeRegistry34.createFunctionType(jSType43, node45);
        com.google.javascript.rhino.ErrorReporter errorReporter47 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry49 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter47, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative50 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray51 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative50 };
        com.google.javascript.rhino.jstype.JSType jSType52 = jSTypeRegistry49.createUnionType(jSTypeNativeArray51);
        com.google.javascript.rhino.ErrorReporter errorReporter53 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry55 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter53, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative56 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray57 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative56 };
        com.google.javascript.rhino.jstype.JSType jSType58 = jSTypeRegistry55.createUnionType(jSTypeNativeArray57);
        com.google.javascript.rhino.Node node60 = new com.google.javascript.rhino.Node((-1));
        com.google.javascript.rhino.jstype.FunctionType functionType61 = jSTypeRegistry49.createFunctionType(jSType58, node60);
        boolean boolean63 = functionType61.hasOwnProperty("hi!");
        com.google.javascript.rhino.jstype.ObjectType objectType64 = jSTypeRegistry34.createObjectType((com.google.javascript.rhino.jstype.ObjectType) functionType61);
        com.google.javascript.rhino.jstype.JSType.TypePair typePair65 = jSType28.getTypesUnderShallowInequality((com.google.javascript.rhino.jstype.JSType) objectType64);
        jSTypeRegistry2.registerPropertyOnType("goog.exportSymbol", jSType28);
        com.google.javascript.rhino.jstype.FunctionParamBuilder functionParamBuilder67 = new com.google.javascript.rhino.jstype.FunctionParamBuilder(jSTypeRegistry2);
        org.junit.Assert.assertTrue("'" + jSTypeNative3 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative3.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray4);
        org.junit.Assert.assertNotNull(jSType5);
        org.junit.Assert.assertTrue("'" + jSTypeNative9 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative9.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray10);
        org.junit.Assert.assertNotNull(jSType11);
        org.junit.Assert.assertNotNull(functionType14);
        org.junit.Assert.assertNotNull(objectType15);
        org.junit.Assert.assertTrue("'" + jSTypeNative20 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative20.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray21);
        org.junit.Assert.assertNotNull(jSType22);
        org.junit.Assert.assertTrue("'" + jSTypeNative26 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative26.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray27);
        org.junit.Assert.assertNotNull(jSType28);
        org.junit.Assert.assertNotNull(functionType31);
        org.junit.Assert.assertTrue("'" + jSTypeNative35 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative35.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray36);
        org.junit.Assert.assertNotNull(jSType37);
        org.junit.Assert.assertTrue("'" + jSTypeNative41 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative41.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray42);
        org.junit.Assert.assertNotNull(jSType43);
        org.junit.Assert.assertNotNull(functionType46);
        org.junit.Assert.assertTrue("'" + jSTypeNative50 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative50.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray51);
        org.junit.Assert.assertNotNull(jSType52);
        org.junit.Assert.assertTrue("'" + jSTypeNative56 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative56.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray57);
        org.junit.Assert.assertNotNull(jSType58);
        org.junit.Assert.assertNotNull(functionType61);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertNotNull(objectType64);
        org.junit.Assert.assertNotNull(typePair65);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        try {
            com.google.javascript.rhino.EcmaError ecmaError2 = com.google.javascript.rhino.ScriptRuntime.typeError1("", "");
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property ");
        } catch (java.lang.RuntimeException e) {
        }
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        java.util.logging.Logger logger0 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager1 = new com.google.javascript.jscomp.LoggerErrorManager(logger0);
        com.google.javascript.jscomp.CheckLevel checkLevel2 = null;
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString((int) '#', "EOF");
        com.google.javascript.jscomp.DiagnosticType diagnosticType7 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        java.lang.String[] strArray14 = new java.lang.String[] { "error reporter", "EOF", "Named type with empty name component", "TYPEOF", "hi!", "Named type with empty name component" };
        com.google.javascript.jscomp.JSError jSError15 = com.google.javascript.jscomp.JSError.make("hi!", node6, diagnosticType7, strArray14);
        loggerErrorManager1.report(checkLevel2, jSError15);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(diagnosticType7);
        org.junit.Assert.assertNotNull(strArray14);
        org.junit.Assert.assertNotNull(jSError15);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.MISSING_PROPERTIES;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.PerformanceTracker performanceTracker2 = compiler1.tracker;
        try {
            com.google.javascript.jscomp.CompilerInput compilerInput4 = compiler1.getInput("language version");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(performanceTracker2);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative3 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray4 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative3 };
        com.google.javascript.rhino.jstype.JSType jSType5 = jSTypeRegistry2.createUnionType(jSTypeNativeArray4);
        com.google.javascript.rhino.ErrorReporter errorReporter6 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry8 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter6, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative9 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray10 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative9 };
        com.google.javascript.rhino.jstype.JSType jSType11 = jSTypeRegistry8.createUnionType(jSTypeNativeArray10);
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node((-1));
        com.google.javascript.rhino.jstype.FunctionType functionType14 = jSTypeRegistry2.createFunctionType(jSType11, node13);
        boolean boolean16 = functionType14.hasOwnProperty("hi!");
        com.google.javascript.rhino.jstype.FunctionPrototypeType functionPrototypeType17 = null;
        boolean boolean18 = functionType14.setPrototype(functionPrototypeType17);
        com.google.javascript.rhino.ErrorReporter errorReporter19 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry21 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter19, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative22 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray23 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative22 };
        com.google.javascript.rhino.jstype.JSType jSType24 = jSTypeRegistry21.createUnionType(jSTypeNativeArray23);
        com.google.javascript.rhino.ErrorReporter errorReporter25 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry27 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter25, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative28 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray29 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative28 };
        com.google.javascript.rhino.jstype.JSType jSType30 = jSTypeRegistry27.createUnionType(jSTypeNativeArray29);
        com.google.javascript.rhino.Node node32 = new com.google.javascript.rhino.Node((-1));
        com.google.javascript.rhino.jstype.FunctionType functionType33 = jSTypeRegistry21.createFunctionType(jSType30, node32);
        boolean boolean35 = functionType33.hasOwnProperty("hi!");
        com.google.javascript.rhino.ErrorReporter errorReporter36 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry38 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter36, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative39 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray40 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative39 };
        com.google.javascript.rhino.jstype.JSType jSType41 = jSTypeRegistry38.createUnionType(jSTypeNativeArray40);
        com.google.javascript.rhino.ErrorReporter errorReporter42 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry44 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter42, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative45 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray46 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative45 };
        com.google.javascript.rhino.jstype.JSType jSType47 = jSTypeRegistry44.createUnionType(jSTypeNativeArray46);
        com.google.javascript.rhino.Node node49 = new com.google.javascript.rhino.Node((-1));
        com.google.javascript.rhino.jstype.FunctionType functionType50 = jSTypeRegistry38.createFunctionType(jSType47, node49);
        boolean boolean52 = functionType50.hasOwnProperty("hi!");
        functionType33.setPrototypeBasedOn((com.google.javascript.rhino.jstype.ObjectType) functionType50);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable54 = functionType33.getCtorImplementedInterfaces();
        com.google.javascript.rhino.ErrorReporter errorReporter55 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry57 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter55, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative58 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray59 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative58 };
        com.google.javascript.rhino.jstype.JSType jSType60 = jSTypeRegistry57.createUnionType(jSTypeNativeArray59);
        com.google.javascript.rhino.ErrorReporter errorReporter61 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry63 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter61, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative64 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray65 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative64 };
        com.google.javascript.rhino.jstype.JSType jSType66 = jSTypeRegistry63.createUnionType(jSTypeNativeArray65);
        com.google.javascript.rhino.Node node68 = new com.google.javascript.rhino.Node((-1));
        com.google.javascript.rhino.jstype.FunctionType functionType69 = jSTypeRegistry57.createFunctionType(jSType66, node68);
        boolean boolean71 = functionType69.hasOwnProperty("hi!");
        com.google.javascript.rhino.ErrorReporter errorReporter72 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry74 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter72, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative75 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray76 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative75 };
        com.google.javascript.rhino.jstype.JSType jSType77 = jSTypeRegistry74.createUnionType(jSTypeNativeArray76);
        com.google.javascript.rhino.ErrorReporter errorReporter78 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry80 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter78, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative81 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray82 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative81 };
        com.google.javascript.rhino.jstype.JSType jSType83 = jSTypeRegistry80.createUnionType(jSTypeNativeArray82);
        com.google.javascript.rhino.Node node85 = new com.google.javascript.rhino.Node((-1));
        com.google.javascript.rhino.jstype.FunctionType functionType86 = jSTypeRegistry74.createFunctionType(jSType83, node85);
        boolean boolean88 = functionType86.hasOwnProperty("hi!");
        functionType69.setPrototypeBasedOn((com.google.javascript.rhino.jstype.ObjectType) functionType86);
        com.google.javascript.rhino.jstype.JSType jSType90 = functionType33.getLeastSupertype((com.google.javascript.rhino.jstype.JSType) functionType69);
        com.google.javascript.rhino.jstype.JSType.TypePair typePair91 = functionType14.getTypesUnderShallowInequality((com.google.javascript.rhino.jstype.JSType) functionType33);
        com.google.javascript.rhino.jstype.JSType jSType93 = functionType33.getRestrictedTypeGivenToBooleanOutcome(false);
        org.junit.Assert.assertTrue("'" + jSTypeNative3 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative3.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray4);
        org.junit.Assert.assertNotNull(jSType5);
        org.junit.Assert.assertTrue("'" + jSTypeNative9 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative9.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray10);
        org.junit.Assert.assertNotNull(jSType11);
        org.junit.Assert.assertNotNull(functionType14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + jSTypeNative22 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative22.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray23);
        org.junit.Assert.assertNotNull(jSType24);
        org.junit.Assert.assertTrue("'" + jSTypeNative28 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative28.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray29);
        org.junit.Assert.assertNotNull(jSType30);
        org.junit.Assert.assertNotNull(functionType33);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + jSTypeNative39 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative39.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray40);
        org.junit.Assert.assertNotNull(jSType41);
        org.junit.Assert.assertTrue("'" + jSTypeNative45 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative45.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray46);
        org.junit.Assert.assertNotNull(jSType47);
        org.junit.Assert.assertNotNull(functionType50);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertNotNull(objectTypeIterable54);
        org.junit.Assert.assertTrue("'" + jSTypeNative58 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative58.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray59);
        org.junit.Assert.assertNotNull(jSType60);
        org.junit.Assert.assertTrue("'" + jSTypeNative64 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative64.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray65);
        org.junit.Assert.assertNotNull(jSType66);
        org.junit.Assert.assertNotNull(functionType69);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
        org.junit.Assert.assertTrue("'" + jSTypeNative75 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative75.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray76);
        org.junit.Assert.assertNotNull(jSType77);
        org.junit.Assert.assertTrue("'" + jSTypeNative81 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative81.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray82);
        org.junit.Assert.assertNotNull(jSType83);
        org.junit.Assert.assertNotNull(functionType86);
        org.junit.Assert.assertTrue("'" + boolean88 + "' != '" + false + "'", boolean88 == false);
        org.junit.Assert.assertNotNull(jSType90);
        org.junit.Assert.assertNotNull(typePair91);
        org.junit.Assert.assertNotNull(jSType93);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.NUMBER_STRING;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.NUMBER_STRING + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.NUMBER_STRING));
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        int int0 = com.google.javascript.rhino.Token.NEW;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 30 + "'", int0 == 30);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.NON_STANDARD_JSDOC;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString("EOF", 93, 28);
        int int4 = node3.getSideEffectFlags();
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.PerformanceTracker performanceTracker2 = compiler1.tracker;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile5 = com.google.javascript.jscomp.JSSourceFile.fromCode("EOF", "language version");
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray6 = new com.google.javascript.jscomp.JSSourceFile[] {};
        com.google.javascript.jscomp.CompilerOptions compilerOptions7 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean8 = compilerOptions7.removeUnusedPrototypeProperties;
        compilerOptions7.removeEmptyFunctions = true;
        compilerOptions7.removeUnusedVars = false;
        compilerOptions7.gatherCssNames = true;
        com.google.javascript.jscomp.Result result15 = compiler1.compile(jSSourceFile5, jSSourceFileArray6, compilerOptions7);
        java.io.PrintStream printStream16 = null;
        com.google.javascript.jscomp.Compiler compiler17 = new com.google.javascript.jscomp.Compiler(printStream16);
        com.google.javascript.jscomp.Compiler.IntermediateState intermediateState18 = compiler17.getState();
        compiler1.setState(intermediateState18);
        org.junit.Assert.assertNull(performanceTracker2);
        org.junit.Assert.assertNotNull(jSSourceFile5);
        org.junit.Assert.assertNotNull(jSSourceFileArray6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(result15);
        org.junit.Assert.assertNotNull(intermediateState18);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        int int0 = com.google.javascript.rhino.Token.NUMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 39 + "'", int0 == 39);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        int int0 = com.google.javascript.rhino.Token.FIRST_ASSIGN;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 86 + "'", int0 == 86);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        int int0 = com.google.javascript.rhino.Token.COLON;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 99 + "'", int0 == 99);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.common.collect.Multimap<com.google.javascript.jscomp.CustomPassExecutionTime, com.google.javascript.jscomp.CompilerPass> customPassExecutionTimeMultimap1 = null;
        compilerOptions0.customPasses = customPassExecutionTimeMultimap1;
        boolean boolean3 = compilerOptions0.inlineConstantVars;
        com.google.javascript.jscomp.CompilerOptions compilerOptions4 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel5 = compilerOptions4.checkMissingGetCssNameLevel;
        compilerOptions0.checkRequires = checkLevel5;
        compilerOptions0.instrumentForCoverage = false;
        boolean boolean9 = compilerOptions0.generatePseudoNames;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + checkLevel5 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel5.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative3 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray4 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative3 };
        com.google.javascript.rhino.jstype.JSType jSType5 = jSTypeRegistry2.createUnionType(jSTypeNativeArray4);
        com.google.javascript.rhino.ErrorReporter errorReporter6 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry8 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter6, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative9 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray10 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative9 };
        com.google.javascript.rhino.jstype.JSType jSType11 = jSTypeRegistry8.createUnionType(jSTypeNativeArray10);
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node((-1));
        com.google.javascript.rhino.jstype.FunctionType functionType14 = jSTypeRegistry2.createFunctionType(jSType11, node13);
        boolean boolean16 = functionType14.hasOwnProperty("hi!");
        com.google.javascript.rhino.ErrorReporter errorReporter17 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry19 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter17, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative20 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray21 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative20 };
        com.google.javascript.rhino.jstype.JSType jSType22 = jSTypeRegistry19.createUnionType(jSTypeNativeArray21);
        com.google.javascript.rhino.ErrorReporter errorReporter23 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry25 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter23, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative26 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray27 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative26 };
        com.google.javascript.rhino.jstype.JSType jSType28 = jSTypeRegistry25.createUnionType(jSTypeNativeArray27);
        com.google.javascript.rhino.Node node30 = new com.google.javascript.rhino.Node((-1));
        com.google.javascript.rhino.jstype.FunctionType functionType31 = jSTypeRegistry19.createFunctionType(jSType28, node30);
        boolean boolean33 = functionType31.hasOwnProperty("hi!");
        functionType14.setPrototypeBasedOn((com.google.javascript.rhino.jstype.ObjectType) functionType31);
        boolean boolean35 = functionType31.isUnknownType();
        java.util.Set<java.lang.String> strSet36 = functionType31.getPropertyNames();
        org.junit.Assert.assertTrue("'" + jSTypeNative3 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative3.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray4);
        org.junit.Assert.assertNotNull(jSType5);
        org.junit.Assert.assertTrue("'" + jSTypeNative9 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative9.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray10);
        org.junit.Assert.assertNotNull(jSType11);
        org.junit.Assert.assertNotNull(functionType14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + jSTypeNative20 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative20.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray21);
        org.junit.Assert.assertNotNull(jSType22);
        org.junit.Assert.assertTrue("'" + jSTypeNative26 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative26.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray27);
        org.junit.Assert.assertNotNull(jSType28);
        org.junit.Assert.assertNotNull(functionType31);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(strSet36);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        int int0 = com.google.javascript.rhino.Node.BREAK_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative3 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray4 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative3 };
        com.google.javascript.rhino.jstype.JSType jSType5 = jSTypeRegistry2.createUnionType(jSTypeNativeArray4);
        com.google.javascript.rhino.ErrorReporter errorReporter6 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry8 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter6, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative9 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray10 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative9 };
        com.google.javascript.rhino.jstype.JSType jSType11 = jSTypeRegistry8.createUnionType(jSTypeNativeArray10);
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node((-1));
        com.google.javascript.rhino.jstype.FunctionType functionType14 = jSTypeRegistry2.createFunctionType(jSType11, node13);
        com.google.javascript.rhino.ErrorReporter errorReporter15 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry17 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter15, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative18 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray19 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative18 };
        com.google.javascript.rhino.jstype.JSType jSType20 = jSTypeRegistry17.createUnionType(jSTypeNativeArray19);
        com.google.javascript.rhino.ErrorReporter errorReporter21 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry23 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter21, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative24 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray25 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative24 };
        com.google.javascript.rhino.jstype.JSType jSType26 = jSTypeRegistry23.createUnionType(jSTypeNativeArray25);
        com.google.javascript.rhino.Node node28 = new com.google.javascript.rhino.Node((-1));
        com.google.javascript.rhino.jstype.FunctionType functionType29 = jSTypeRegistry17.createFunctionType(jSType26, node28);
        com.google.javascript.rhino.ErrorReporter errorReporter30 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry32 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter30, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative33 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray34 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative33 };
        com.google.javascript.rhino.jstype.JSType jSType35 = jSTypeRegistry32.createUnionType(jSTypeNativeArray34);
        com.google.javascript.rhino.ErrorReporter errorReporter36 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry38 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter36, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative39 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray40 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative39 };
        com.google.javascript.rhino.jstype.JSType jSType41 = jSTypeRegistry38.createUnionType(jSTypeNativeArray40);
        com.google.javascript.rhino.Node node43 = new com.google.javascript.rhino.Node((-1));
        com.google.javascript.rhino.jstype.FunctionType functionType44 = jSTypeRegistry32.createFunctionType(jSType41, node43);
        boolean boolean46 = functionType44.hasOwnProperty("hi!");
        com.google.javascript.rhino.jstype.ObjectType objectType47 = jSTypeRegistry17.createObjectType((com.google.javascript.rhino.jstype.ObjectType) functionType44);
        com.google.javascript.rhino.jstype.JSType.TypePair typePair48 = jSType11.getTypesUnderShallowInequality((com.google.javascript.rhino.jstype.JSType) objectType47);
        boolean boolean49 = objectType47.isInstanceType();
        org.junit.Assert.assertTrue("'" + jSTypeNative3 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative3.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray4);
        org.junit.Assert.assertNotNull(jSType5);
        org.junit.Assert.assertTrue("'" + jSTypeNative9 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative9.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray10);
        org.junit.Assert.assertNotNull(jSType11);
        org.junit.Assert.assertNotNull(functionType14);
        org.junit.Assert.assertTrue("'" + jSTypeNative18 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative18.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray19);
        org.junit.Assert.assertNotNull(jSType20);
        org.junit.Assert.assertTrue("'" + jSTypeNative24 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative24.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray25);
        org.junit.Assert.assertNotNull(jSType26);
        org.junit.Assert.assertNotNull(functionType29);
        org.junit.Assert.assertTrue("'" + jSTypeNative33 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative33.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray34);
        org.junit.Assert.assertNotNull(jSType35);
        org.junit.Assert.assertTrue("'" + jSTypeNative39 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative39.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray40);
        org.junit.Assert.assertNotNull(jSType41);
        org.junit.Assert.assertNotNull(functionType44);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(objectType47);
        org.junit.Assert.assertNotNull(typePair48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        com.google.javascript.jscomp.JSModule[] jSModuleArray0 = new com.google.javascript.jscomp.JSModule[] {};
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph1 = new com.google.javascript.jscomp.JSModuleGraph(jSModuleArray0);
        com.google.javascript.jscomp.JSModule jSModule2 = null;
        com.google.javascript.jscomp.JSModule jSModule3 = null;
        com.google.javascript.jscomp.JSModule jSModule4 = jSModuleGraph1.getDeepestCommonDependencyInclusive(jSModule2, jSModule3);
        org.junit.Assert.assertNotNull(jSModuleArray0);
        org.junit.Assert.assertNull(jSModule4);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        com.google.javascript.rhino.Node node1 = new com.google.javascript.rhino.Node((-1));
        com.google.javascript.rhino.Node node2 = null;
        try {
            boolean boolean3 = node1.checkTreeEqualsSilent(node2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.CHECK_TYPES;
        com.google.javascript.jscomp.CompilerOptions compilerOptions1 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel2 = compilerOptions1.checkMissingGetCssNameLevel;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard3 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup0, checkLevel2);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup4 = com.google.javascript.jscomp.DiagnosticGroups.CHECK_TYPES;
        com.google.javascript.jscomp.CompilerOptions compilerOptions5 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel6 = compilerOptions5.checkMissingGetCssNameLevel;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard7 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup4, checkLevel6);
        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray8 = new com.google.javascript.jscomp.WarningsGuard[] { diagnosticGroupWarningsGuard3, diagnosticGroupWarningsGuard7 };
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard9 = new com.google.javascript.jscomp.ComposeWarningsGuard(warningsGuardArray8);
        org.junit.Assert.assertNotNull(diagnosticGroup0);
        org.junit.Assert.assertTrue("'" + checkLevel2 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel2.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(diagnosticGroup4);
        org.junit.Assert.assertTrue("'" + checkLevel6 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel6.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(warningsGuardArray8);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.allowLegacyJsMessages = false;
        boolean boolean3 = compilerOptions0.groupVariableDeclarations;
        compilerOptions0.generatePseudoNames = true;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        int int0 = com.google.javascript.rhino.Token.LSH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 18 + "'", int0 == 18);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.removeUnusedPrototypeProperties;
        compilerOptions0.removeEmptyFunctions = true;
        boolean boolean4 = compilerOptions0.instrumentForCoverageOnly;
        compilerOptions0.syntheticBlockStartMarker = "";
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        boolean boolean2 = closureCodingConvention0.isPrivate("EOF");
        com.google.javascript.rhino.ErrorReporter errorReporter3 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter3, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative6 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray7 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative6 };
        com.google.javascript.rhino.jstype.JSType jSType8 = jSTypeRegistry5.createUnionType(jSTypeNativeArray7);
        com.google.javascript.rhino.ErrorReporter errorReporter9 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry11 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter9, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative12 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray13 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative12 };
        com.google.javascript.rhino.jstype.JSType jSType14 = jSTypeRegistry11.createUnionType(jSTypeNativeArray13);
        com.google.javascript.rhino.Node node16 = new com.google.javascript.rhino.Node((-1));
        com.google.javascript.rhino.jstype.FunctionType functionType17 = jSTypeRegistry5.createFunctionType(jSType14, node16);
        boolean boolean18 = functionType17.matchesInt32Context();
        com.google.javascript.rhino.ErrorReporter errorReporter19 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry21 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter19, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative22 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray23 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative22 };
        com.google.javascript.rhino.jstype.JSType jSType24 = jSTypeRegistry21.createUnionType(jSTypeNativeArray23);
        com.google.javascript.rhino.ErrorReporter errorReporter25 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry27 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter25, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative28 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray29 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative28 };
        com.google.javascript.rhino.jstype.JSType jSType30 = jSTypeRegistry27.createUnionType(jSTypeNativeArray29);
        com.google.javascript.rhino.Node node32 = new com.google.javascript.rhino.Node((-1));
        com.google.javascript.rhino.jstype.FunctionType functionType33 = jSTypeRegistry21.createFunctionType(jSType30, node32);
        boolean boolean35 = functionType33.hasOwnProperty("hi!");
        com.google.javascript.rhino.jstype.FunctionPrototypeType functionPrototypeType36 = null;
        boolean boolean37 = functionType33.setPrototype(functionPrototypeType36);
        boolean boolean39 = functionType33.hasOwnProperty("");
        com.google.javascript.rhino.ErrorReporter errorReporter40 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry42 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter40, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative43 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray44 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative43 };
        com.google.javascript.rhino.jstype.JSType jSType45 = jSTypeRegistry42.createUnionType(jSTypeNativeArray44);
        com.google.javascript.rhino.ErrorReporter errorReporter46 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry48 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter46, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative49 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray50 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative49 };
        com.google.javascript.rhino.jstype.JSType jSType51 = jSTypeRegistry48.createUnionType(jSTypeNativeArray50);
        com.google.javascript.rhino.Node node53 = new com.google.javascript.rhino.Node((-1));
        com.google.javascript.rhino.jstype.FunctionType functionType54 = jSTypeRegistry42.createFunctionType(jSType51, node53);
        boolean boolean55 = functionType54.matchesInt32Context();
        boolean boolean56 = functionType54.isConstructor();
        functionType33.setPrototypeBasedOn((com.google.javascript.rhino.jstype.ObjectType) functionType54);
        com.google.javascript.rhino.jstype.FunctionType functionType58 = functionType54.getConstructor();
        com.google.javascript.rhino.ErrorReporter errorReporter59 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry61 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter59, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative62 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray63 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative62 };
        com.google.javascript.rhino.jstype.JSType jSType64 = jSTypeRegistry61.createUnionType(jSTypeNativeArray63);
        com.google.javascript.rhino.ErrorReporter errorReporter65 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry67 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter65, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative68 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray69 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative68 };
        com.google.javascript.rhino.jstype.JSType jSType70 = jSTypeRegistry67.createUnionType(jSTypeNativeArray69);
        com.google.javascript.rhino.Node node72 = new com.google.javascript.rhino.Node((-1));
        com.google.javascript.rhino.jstype.FunctionType functionType73 = jSTypeRegistry61.createFunctionType(jSType70, node72);
        com.google.javascript.rhino.ErrorReporter errorReporter74 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry76 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter74, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative77 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray78 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative77 };
        com.google.javascript.rhino.jstype.JSType jSType79 = jSTypeRegistry76.createUnionType(jSTypeNativeArray78);
        com.google.javascript.rhino.ErrorReporter errorReporter80 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry82 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter80, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative83 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray84 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative83 };
        com.google.javascript.rhino.jstype.JSType jSType85 = jSTypeRegistry82.createUnionType(jSTypeNativeArray84);
        com.google.javascript.rhino.Node node87 = new com.google.javascript.rhino.Node((-1));
        com.google.javascript.rhino.jstype.FunctionType functionType88 = jSTypeRegistry76.createFunctionType(jSType85, node87);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray89 = new com.google.javascript.rhino.jstype.JSType[] { jSType85 };
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList90 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean91 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList90, jSTypeArray89);
        com.google.javascript.rhino.Node node92 = jSTypeRegistry61.createParametersWithVarArgs((java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList90);
        jSTypeRegistry61.setLastGeneration(false);
        com.google.javascript.rhino.jstype.ObjectType objectType95 = jSTypeRegistry61.createAnonymousObjectType();
        boolean boolean96 = objectType95.hasCachedValues();
        closureCodingConvention0.applySingletonGetter(functionType17, functionType54, objectType95);
        java.lang.String str98 = closureCodingConvention0.getExportSymbolFunction();
        java.lang.String str99 = closureCodingConvention0.getExportSymbolFunction();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + jSTypeNative6 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative6.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray7);
        org.junit.Assert.assertNotNull(jSType8);
        org.junit.Assert.assertTrue("'" + jSTypeNative12 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative12.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray13);
        org.junit.Assert.assertNotNull(jSType14);
        org.junit.Assert.assertNotNull(functionType17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + jSTypeNative22 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative22.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray23);
        org.junit.Assert.assertNotNull(jSType24);
        org.junit.Assert.assertTrue("'" + jSTypeNative28 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative28.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray29);
        org.junit.Assert.assertNotNull(jSType30);
        org.junit.Assert.assertNotNull(functionType33);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + jSTypeNative43 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative43.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray44);
        org.junit.Assert.assertNotNull(jSType45);
        org.junit.Assert.assertTrue("'" + jSTypeNative49 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative49.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray50);
        org.junit.Assert.assertNotNull(jSType51);
        org.junit.Assert.assertNotNull(functionType54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertNull(functionType58);
        org.junit.Assert.assertTrue("'" + jSTypeNative62 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative62.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray63);
        org.junit.Assert.assertNotNull(jSType64);
        org.junit.Assert.assertTrue("'" + jSTypeNative68 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative68.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray69);
        org.junit.Assert.assertNotNull(jSType70);
        org.junit.Assert.assertNotNull(functionType73);
        org.junit.Assert.assertTrue("'" + jSTypeNative77 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative77.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray78);
        org.junit.Assert.assertNotNull(jSType79);
        org.junit.Assert.assertTrue("'" + jSTypeNative83 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative83.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray84);
        org.junit.Assert.assertNotNull(jSType85);
        org.junit.Assert.assertNotNull(functionType88);
        org.junit.Assert.assertNotNull(jSTypeArray89);
        org.junit.Assert.assertTrue("'" + boolean91 + "' != '" + true + "'", boolean91 == true);
        org.junit.Assert.assertNotNull(node92);
        org.junit.Assert.assertNotNull(objectType95);
        org.junit.Assert.assertTrue("'" + boolean96 + "' != '" + false + "'", boolean96 == false);
        org.junit.Assert.assertTrue("'" + str98 + "' != '" + "goog.exportSymbol" + "'", str98.equals("goog.exportSymbol"));
        org.junit.Assert.assertTrue("'" + str99 + "' != '" + "goog.exportSymbol" + "'", str99.equals("goog.exportSymbol"));
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        com.google.javascript.rhino.ErrorReporter errorReporter2 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry4 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter2, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative5 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray6 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative5 };
        com.google.javascript.rhino.jstype.JSType jSType7 = jSTypeRegistry4.createUnionType(jSTypeNativeArray6);
        com.google.javascript.rhino.ErrorReporter errorReporter8 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry10 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter8, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative11 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray12 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative11 };
        com.google.javascript.rhino.jstype.JSType jSType13 = jSTypeRegistry10.createUnionType(jSTypeNativeArray12);
        com.google.javascript.rhino.Node node15 = new com.google.javascript.rhino.Node((-1));
        com.google.javascript.rhino.jstype.FunctionType functionType16 = jSTypeRegistry4.createFunctionType(jSType13, node15);
        com.google.javascript.rhino.Node node17 = new com.google.javascript.rhino.Node((int) ' ', node15);
        com.google.javascript.rhino.Node node18 = new com.google.javascript.rhino.Node((int) ' ', node17);
        try {
            com.google.javascript.rhino.Node node20 = node17.getChildAtIndex(305);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + jSTypeNative5 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative5.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray6);
        org.junit.Assert.assertNotNull(jSType7);
        org.junit.Assert.assertTrue("'" + jSTypeNative11 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative11.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray12);
        org.junit.Assert.assertNotNull(jSType13);
        org.junit.Assert.assertNotNull(functionType16);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        int int0 = com.google.javascript.rhino.Node.FIXUPS_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 9 + "'", int0 == 9);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.common.collect.Multimap<com.google.javascript.jscomp.CustomPassExecutionTime, com.google.javascript.jscomp.CompilerPass> customPassExecutionTimeMultimap1 = null;
        compilerOptions0.customPasses = customPassExecutionTimeMultimap1;
        boolean boolean3 = compilerOptions0.inlineConstantVars;
        java.lang.String str4 = compilerOptions0.syntheticBlockStartMarker;
        compilerOptions0.decomposeExpressions = false;
        boolean boolean7 = compilerOptions0.checkTypes;
        java.lang.String str8 = compilerOptions0.sourceMapOutputPath;
        boolean boolean9 = compilerOptions0.deadAssignmentElimination;
        java.lang.String[] strArray13 = new java.lang.String[] { "language version", "language version", "" };
        java.util.LinkedHashSet<java.lang.String> strSet14 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean15 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet14, strArray13);
        compilerOptions0.aliasableStrings = strSet14;
        java.util.Set<java.lang.String> strSet17 = compilerOptions0.stripNameSuffixes;
        compilerOptions0.checkDuplicateMessages = true;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(strArray13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(strSet17);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        int int0 = com.google.javascript.rhino.Token.RETHROW;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 50 + "'", int0 == 50);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        com.google.javascript.rhino.JSDocInfoBuilder jSDocInfoBuilder1 = new com.google.javascript.rhino.JSDocInfoBuilder(true);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode5 = new com.google.javascript.rhino.ScriptOrFnNode(11, 130, (int) (short) 100);
        int int6 = scriptOrFnNode5.getEncodedSourceStart();
        com.google.javascript.rhino.JSTypeExpression jSTypeExpression8 = new com.google.javascript.rhino.JSTypeExpression((com.google.javascript.rhino.Node) scriptOrFnNode5, "Named type with empty name component");
        boolean boolean9 = jSDocInfoBuilder1.recordThrowType(jSTypeExpression8);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode14 = new com.google.javascript.rhino.ScriptOrFnNode(11, 130, (int) (short) 100);
        int int15 = scriptOrFnNode14.getEncodedSourceStart();
        com.google.javascript.rhino.JSTypeExpression jSTypeExpression17 = new com.google.javascript.rhino.JSTypeExpression((com.google.javascript.rhino.Node) scriptOrFnNode14, "Named type with empty name component");
        boolean boolean18 = jSDocInfoBuilder1.recordParameter("EOF", jSTypeExpression17);
        boolean boolean19 = jSDocInfoBuilder1.recordImplicitCast();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.checkMissingGetCssNameLevel;
        boolean boolean2 = compilerOptions0.collapseProperties;
        boolean boolean3 = compilerOptions0.inlineLocalVariables;
        boolean boolean4 = compilerOptions0.gatherCssNames;
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.ErrorReporter errorReporter3 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter3, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative6 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray7 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative6 };
        com.google.javascript.rhino.jstype.JSType jSType8 = jSTypeRegistry5.createUnionType(jSTypeNativeArray7);
        com.google.javascript.rhino.ErrorReporter errorReporter9 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry11 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter9, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative12 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray13 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative12 };
        com.google.javascript.rhino.jstype.JSType jSType14 = jSTypeRegistry11.createUnionType(jSTypeNativeArray13);
        com.google.javascript.rhino.Node node16 = new com.google.javascript.rhino.Node((-1));
        com.google.javascript.rhino.jstype.FunctionType functionType17 = jSTypeRegistry5.createFunctionType(jSType14, node16);
        boolean boolean19 = functionType17.hasOwnProperty("hi!");
        com.google.javascript.rhino.jstype.ObjectType objectType20 = jSTypeRegistry2.createObjectType((com.google.javascript.rhino.jstype.ObjectType) functionType17);
        com.google.javascript.rhino.JSDocInfo jSDocInfo22 = null;
        functionType17.setPropertyJSDocInfo("TYPEOF", jSDocInfo22, true);
        int int25 = functionType17.getMinArguments();
        org.junit.Assert.assertTrue("'" + jSTypeNative6 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative6.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray7);
        org.junit.Assert.assertNotNull(jSType8);
        org.junit.Assert.assertTrue("'" + jSTypeNative12 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative12.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray13);
        org.junit.Assert.assertNotNull(jSType14);
        org.junit.Assert.assertNotNull(functionType17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(objectType20);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative3 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray4 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative3 };
        com.google.javascript.rhino.jstype.JSType jSType5 = jSTypeRegistry2.createUnionType(jSTypeNativeArray4);
        com.google.javascript.rhino.ErrorReporter errorReporter6 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry8 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter6, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative9 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray10 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative9 };
        com.google.javascript.rhino.jstype.JSType jSType11 = jSTypeRegistry8.createUnionType(jSTypeNativeArray10);
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node((-1));
        com.google.javascript.rhino.jstype.FunctionType functionType14 = jSTypeRegistry2.createFunctionType(jSType11, node13);
        com.google.javascript.rhino.ErrorReporter errorReporter15 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry17 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter15, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative18 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray19 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative18 };
        com.google.javascript.rhino.jstype.JSType jSType20 = jSTypeRegistry17.createUnionType(jSTypeNativeArray19);
        com.google.javascript.rhino.ErrorReporter errorReporter21 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry23 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter21, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative24 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray25 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative24 };
        com.google.javascript.rhino.jstype.JSType jSType26 = jSTypeRegistry23.createUnionType(jSTypeNativeArray25);
        com.google.javascript.rhino.Node node28 = new com.google.javascript.rhino.Node((-1));
        com.google.javascript.rhino.jstype.FunctionType functionType29 = jSTypeRegistry17.createFunctionType(jSType26, node28);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray30 = new com.google.javascript.rhino.jstype.JSType[] { jSType26 };
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList31 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean32 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList31, jSTypeArray30);
        com.google.javascript.rhino.Node node33 = jSTypeRegistry2.createParametersWithVarArgs((java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList31);
        jSTypeRegistry2.setLastGeneration(false);
        com.google.javascript.rhino.jstype.FunctionParamBuilder functionParamBuilder36 = new com.google.javascript.rhino.jstype.FunctionParamBuilder(jSTypeRegistry2);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative37 = com.google.javascript.rhino.jstype.JSTypeNative.NUMBER_TYPE;
        try {
            com.google.javascript.rhino.jstype.ObjectType objectType38 = jSTypeRegistry2.getNativeObjectType(jSTypeNative37);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: com.google.javascript.rhino.jstype.NumberType cannot be cast to com.google.javascript.rhino.jstype.ObjectType");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertTrue("'" + jSTypeNative3 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative3.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray4);
        org.junit.Assert.assertNotNull(jSType5);
        org.junit.Assert.assertTrue("'" + jSTypeNative9 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative9.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray10);
        org.junit.Assert.assertNotNull(jSType11);
        org.junit.Assert.assertNotNull(functionType14);
        org.junit.Assert.assertTrue("'" + jSTypeNative18 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative18.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray19);
        org.junit.Assert.assertNotNull(jSType20);
        org.junit.Assert.assertTrue("'" + jSTypeNative24 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative24.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray25);
        org.junit.Assert.assertNotNull(jSType26);
        org.junit.Assert.assertNotNull(functionType29);
        org.junit.Assert.assertNotNull(jSTypeArray30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNotNull(node33);
        org.junit.Assert.assertTrue("'" + jSTypeNative37 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.NUMBER_TYPE + "'", jSTypeNative37.equals(com.google.javascript.rhino.jstype.JSTypeNative.NUMBER_TYPE));
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.disambiguateProperties;
        compilerOptions0.removeUnusedPrototypeProperties = true;
        com.google.javascript.jscomp.CheckLevel checkLevel4 = compilerOptions0.checkMissingGetCssNameLevel;
        compilerOptions0.lineBreak = true;
        boolean boolean7 = compilerOptions0.labelRenaming;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + checkLevel4 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel4.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        int int0 = com.google.javascript.rhino.Token.LT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 14 + "'", int0 == 14);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative3 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray4 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative3 };
        com.google.javascript.rhino.jstype.JSType jSType5 = jSTypeRegistry2.createUnionType(jSTypeNativeArray4);
        com.google.javascript.rhino.ErrorReporter errorReporter6 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry8 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter6, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative9 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray10 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative9 };
        com.google.javascript.rhino.jstype.JSType jSType11 = jSTypeRegistry8.createUnionType(jSTypeNativeArray10);
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node((-1));
        com.google.javascript.rhino.jstype.FunctionType functionType14 = jSTypeRegistry2.createFunctionType(jSType11, node13);
        boolean boolean16 = functionType14.hasOwnProperty("hi!");
        com.google.javascript.rhino.ErrorReporter errorReporter17 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry19 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter17, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative20 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray21 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative20 };
        com.google.javascript.rhino.jstype.JSType jSType22 = jSTypeRegistry19.createUnionType(jSTypeNativeArray21);
        com.google.javascript.rhino.ErrorReporter errorReporter23 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry25 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter23, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative26 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray27 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative26 };
        com.google.javascript.rhino.jstype.JSType jSType28 = jSTypeRegistry25.createUnionType(jSTypeNativeArray27);
        com.google.javascript.rhino.Node node30 = new com.google.javascript.rhino.Node((-1));
        com.google.javascript.rhino.jstype.FunctionType functionType31 = jSTypeRegistry19.createFunctionType(jSType28, node30);
        boolean boolean33 = functionType31.hasOwnProperty("hi!");
        functionType14.setPrototypeBasedOn((com.google.javascript.rhino.jstype.ObjectType) functionType31);
        boolean boolean35 = functionType31.isUnknownType();
        boolean boolean36 = functionType31.hasInstanceType();
        java.lang.String str37 = functionType31.getNormalizedReferenceName();
        boolean boolean38 = functionType31.hasReferenceName();
        com.google.javascript.rhino.JSDocInfo jSDocInfo40 = null;
        functionType31.setPropertyJSDocInfo("goog.exportSymbol", jSDocInfo40, true);
        org.junit.Assert.assertTrue("'" + jSTypeNative3 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative3.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray4);
        org.junit.Assert.assertNotNull(jSType5);
        org.junit.Assert.assertTrue("'" + jSTypeNative9 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative9.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray10);
        org.junit.Assert.assertNotNull(jSType11);
        org.junit.Assert.assertNotNull(functionType14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + jSTypeNative20 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative20.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray21);
        org.junit.Assert.assertNotNull(jSType22);
        org.junit.Assert.assertTrue("'" + jSTypeNative26 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative26.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray27);
        org.junit.Assert.assertNotNull(jSType28);
        org.junit.Assert.assertNotNull(functionType31);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNull(str37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.Node.newString(4, "error reporter");
        org.junit.Assert.assertNotNull(node2);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        java.lang.String str1 = com.google.javascript.rhino.ScriptRuntime.escapeString("EOF");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "EOF" + "'", str1.equals("EOF"));
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.CHECK_TYPES;
        com.google.javascript.jscomp.DiagnosticGroups.UNKNOWN_DEFINES = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticGroups.UNKNOWN_DEFINES = diagnosticGroup0;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        int int0 = com.google.javascript.rhino.Token.IMPORT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 107 + "'", int0 == 107);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.disambiguateProperties;
        boolean boolean2 = compilerOptions0.isExternExportsEnabled();
        compilerOptions0.collapseVariableDeclarations = true;
        compilerOptions0.setRewriteNewDateGoogNow(false);
        com.google.javascript.jscomp.CompilerOptions compilerOptions7 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel8 = compilerOptions7.checkMissingGetCssNameLevel;
        java.util.Set<java.lang.String> strSet9 = compilerOptions7.stripNamePrefixes;
        compilerOptions0.setIdGenerators(strSet9);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + checkLevel8 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel8.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(strSet9);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.common.collect.Multimap<com.google.javascript.jscomp.CustomPassExecutionTime, com.google.javascript.jscomp.CompilerPass> customPassExecutionTimeMultimap1 = null;
        compilerOptions0.customPasses = customPassExecutionTimeMultimap1;
        boolean boolean3 = compilerOptions0.inlineConstantVars;
        java.lang.String str4 = compilerOptions0.syntheticBlockStartMarker;
        compilerOptions0.decomposeExpressions = false;
        boolean boolean7 = compilerOptions0.checkTypes;
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup8 = com.google.javascript.jscomp.DiagnosticGroups.INVALID_CASTS;
        com.google.javascript.jscomp.CompilerOptions compilerOptions9 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel10 = compilerOptions9.checkMissingGetCssNameLevel;
        compilerOptions0.setWarningLevel(diagnosticGroup8, checkLevel10);
        java.lang.String str12 = compilerOptions0.appNameStr;
        boolean boolean13 = compilerOptions0.ambiguateProperties;
        boolean boolean14 = compilerOptions0.shouldColorizeErrorOutput();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(diagnosticGroup8);
        org.junit.Assert.assertTrue("'" + checkLevel10 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel10.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.common.collect.Multimap<com.google.javascript.jscomp.CustomPassExecutionTime, com.google.javascript.jscomp.CompilerPass> customPassExecutionTimeMultimap1 = null;
        compilerOptions0.customPasses = customPassExecutionTimeMultimap1;
        boolean boolean3 = compilerOptions0.inlineConstantVars;
        java.lang.String str4 = compilerOptions0.syntheticBlockStartMarker;
        compilerOptions0.decomposeExpressions = false;
        boolean boolean7 = compilerOptions0.checkTypes;
        java.lang.String str8 = compilerOptions0.sourceMapOutputPath;
        com.google.javascript.jscomp.CheckLevel checkLevel9 = compilerOptions0.brokenClosureRequiresLevel;
        compilerOptions0.aliasKeywords = false;
        boolean boolean12 = compilerOptions0.labelRenaming;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertTrue("'" + checkLevel9 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel9.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        com.google.javascript.rhino.EvaluatorException evaluatorException5 = new com.google.javascript.rhino.EvaluatorException("", "", 100, "hi!", (int) (short) 1);
        java.lang.String str6 = evaluatorException5.sourceName();
        com.google.javascript.rhino.EvaluatorException evaluatorException12 = new com.google.javascript.rhino.EvaluatorException("", "", 100, "hi!", (int) (short) 1);
        evaluatorException5.addSuppressed((java.lang.Throwable) evaluatorException12);
        try {
            evaluatorException12.initLineNumber(14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        int int0 = com.google.javascript.rhino.Token.LEAVEWITH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative3 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray4 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative3 };
        com.google.javascript.rhino.jstype.JSType jSType5 = jSTypeRegistry2.createUnionType(jSTypeNativeArray4);
        com.google.javascript.rhino.ErrorReporter errorReporter6 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry8 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter6, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative9 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray10 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative9 };
        com.google.javascript.rhino.jstype.JSType jSType11 = jSTypeRegistry8.createUnionType(jSTypeNativeArray10);
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node((-1));
        com.google.javascript.rhino.jstype.FunctionType functionType14 = jSTypeRegistry2.createFunctionType(jSType11, node13);
        boolean boolean16 = functionType14.hasOwnProperty("hi!");
        com.google.javascript.rhino.ErrorReporter errorReporter17 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry19 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter17, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative20 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray21 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative20 };
        com.google.javascript.rhino.jstype.JSType jSType22 = jSTypeRegistry19.createUnionType(jSTypeNativeArray21);
        com.google.javascript.rhino.ErrorReporter errorReporter23 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry25 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter23, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative26 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray27 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative26 };
        com.google.javascript.rhino.jstype.JSType jSType28 = jSTypeRegistry25.createUnionType(jSTypeNativeArray27);
        com.google.javascript.rhino.Node node30 = new com.google.javascript.rhino.Node((-1));
        com.google.javascript.rhino.jstype.FunctionType functionType31 = jSTypeRegistry19.createFunctionType(jSType28, node30);
        boolean boolean33 = functionType31.hasOwnProperty("hi!");
        functionType14.setPrototypeBasedOn((com.google.javascript.rhino.jstype.ObjectType) functionType31);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable35 = functionType14.getCtorImplementedInterfaces();
        com.google.javascript.rhino.ErrorReporter errorReporter36 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry38 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter36, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative39 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray40 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative39 };
        com.google.javascript.rhino.jstype.JSType jSType41 = jSTypeRegistry38.createUnionType(jSTypeNativeArray40);
        com.google.javascript.rhino.ErrorReporter errorReporter42 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry44 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter42, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative45 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray46 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative45 };
        com.google.javascript.rhino.jstype.JSType jSType47 = jSTypeRegistry44.createUnionType(jSTypeNativeArray46);
        com.google.javascript.rhino.Node node49 = new com.google.javascript.rhino.Node((-1));
        com.google.javascript.rhino.jstype.FunctionType functionType50 = jSTypeRegistry38.createFunctionType(jSType47, node49);
        boolean boolean52 = functionType50.hasOwnProperty("hi!");
        com.google.javascript.rhino.ErrorReporter errorReporter53 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry55 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter53, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative56 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray57 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative56 };
        com.google.javascript.rhino.jstype.JSType jSType58 = jSTypeRegistry55.createUnionType(jSTypeNativeArray57);
        com.google.javascript.rhino.ErrorReporter errorReporter59 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry61 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter59, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative62 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray63 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative62 };
        com.google.javascript.rhino.jstype.JSType jSType64 = jSTypeRegistry61.createUnionType(jSTypeNativeArray63);
        com.google.javascript.rhino.Node node66 = new com.google.javascript.rhino.Node((-1));
        com.google.javascript.rhino.jstype.FunctionType functionType67 = jSTypeRegistry55.createFunctionType(jSType64, node66);
        boolean boolean69 = functionType67.hasOwnProperty("hi!");
        functionType50.setPrototypeBasedOn((com.google.javascript.rhino.jstype.ObjectType) functionType67);
        com.google.javascript.rhino.jstype.JSType jSType71 = functionType14.getLeastSupertype((com.google.javascript.rhino.jstype.JSType) functionType50);
        com.google.javascript.rhino.jstype.ObjectType objectType72 = functionType50.toObjectType();
        org.junit.Assert.assertTrue("'" + jSTypeNative3 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative3.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray4);
        org.junit.Assert.assertNotNull(jSType5);
        org.junit.Assert.assertTrue("'" + jSTypeNative9 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative9.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray10);
        org.junit.Assert.assertNotNull(jSType11);
        org.junit.Assert.assertNotNull(functionType14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + jSTypeNative20 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative20.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray21);
        org.junit.Assert.assertNotNull(jSType22);
        org.junit.Assert.assertTrue("'" + jSTypeNative26 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative26.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray27);
        org.junit.Assert.assertNotNull(jSType28);
        org.junit.Assert.assertNotNull(functionType31);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(objectTypeIterable35);
        org.junit.Assert.assertTrue("'" + jSTypeNative39 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative39.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray40);
        org.junit.Assert.assertNotNull(jSType41);
        org.junit.Assert.assertTrue("'" + jSTypeNative45 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative45.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray46);
        org.junit.Assert.assertNotNull(jSType47);
        org.junit.Assert.assertNotNull(functionType50);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertTrue("'" + jSTypeNative56 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative56.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray57);
        org.junit.Assert.assertNotNull(jSType58);
        org.junit.Assert.assertTrue("'" + jSTypeNative62 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative62.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray63);
        org.junit.Assert.assertNotNull(jSType64);
        org.junit.Assert.assertNotNull(functionType67);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
        org.junit.Assert.assertNotNull(jSType71);
        org.junit.Assert.assertNotNull(objectType72);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.common.collect.Multimap<com.google.javascript.jscomp.CustomPassExecutionTime, com.google.javascript.jscomp.CompilerPass> customPassExecutionTimeMultimap1 = null;
        compilerOptions0.customPasses = customPassExecutionTimeMultimap1;
        boolean boolean3 = compilerOptions0.inlineConstantVars;
        java.lang.String str4 = compilerOptions0.syntheticBlockStartMarker;
        compilerOptions0.inlineConstantVars = true;
        com.google.javascript.jscomp.CheckLevel checkLevel7 = compilerOptions0.checkShadowVars;
        compilerOptions0.labelRenaming = true;
        compilerOptions0.setColorizeErrorOutput(false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + checkLevel7 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel7.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.removeUnusedPrototypeProperties;
        compilerOptions0.removeEmptyFunctions = true;
        compilerOptions0.nameReferenceReportPath = "STRING hi!";
        compilerOptions0.checkEs5Strict = true;
        compilerOptions0.optimizeArgumentsArray = false;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        int int0 = com.google.javascript.rhino.Token.VOID;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 122 + "'", int0 == 122);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        com.google.javascript.rhino.ErrorReporter errorReporter1 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry3 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter1, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative4 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray5 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative4 };
        com.google.javascript.rhino.jstype.JSType jSType6 = jSTypeRegistry3.createUnionType(jSTypeNativeArray5);
        com.google.javascript.rhino.ErrorReporter errorReporter7 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry9 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter7, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative10 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray11 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative10 };
        com.google.javascript.rhino.jstype.JSType jSType12 = jSTypeRegistry9.createUnionType(jSTypeNativeArray11);
        com.google.javascript.rhino.Node node14 = new com.google.javascript.rhino.Node((-1));
        com.google.javascript.rhino.jstype.FunctionType functionType15 = jSTypeRegistry3.createFunctionType(jSType12, node14);
        com.google.javascript.rhino.Node node16 = new com.google.javascript.rhino.Node((int) ' ', node14);
        boolean boolean17 = node14.hasChildren();
        org.junit.Assert.assertTrue("'" + jSTypeNative4 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative4.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray5);
        org.junit.Assert.assertNotNull(jSType6);
        org.junit.Assert.assertTrue("'" + jSTypeNative10 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative10.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray11);
        org.junit.Assert.assertNotNull(jSType12);
        org.junit.Assert.assertNotNull(functionType15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.disambiguateProperties;
        com.google.javascript.jscomp.AnonymousFunctionNamingPolicy anonymousFunctionNamingPolicy2 = compilerOptions0.anonymousFunctionNaming;
        java.lang.String str3 = compilerOptions0.nameReferenceReportPath;
        compilerOptions0.setRewriteNewDateGoogNow(false);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + anonymousFunctionNamingPolicy2 + "' != '" + com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF + "'", anonymousFunctionNamingPolicy2.equals(com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF));
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        com.google.javascript.rhino.Node node2 = new com.google.javascript.rhino.Node((-1));
        node2.putIntProp(33, 130);
        com.google.javascript.rhino.jstype.JSType jSType6 = node2.getJSType();
        com.google.javascript.rhino.Node node8 = new com.google.javascript.rhino.Node((-1));
        node8.putIntProp(33, 130);
        com.google.javascript.rhino.jstype.JSType jSType12 = node8.getJSType();
        node8.setIsSyntheticBlock(true);
        com.google.javascript.rhino.Node node15 = node8.getNext();
        com.google.javascript.rhino.Node node17 = new com.google.javascript.rhino.Node((-1));
        node17.putIntProp(33, 130);
        com.google.javascript.rhino.jstype.JSType jSType21 = node17.getJSType();
        com.google.javascript.rhino.Node node24 = com.google.javascript.rhino.Node.newString("hi!");
        com.google.javascript.rhino.ErrorReporter errorReporter27 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry29 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter27, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative30 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray31 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative30 };
        com.google.javascript.rhino.jstype.JSType jSType32 = jSTypeRegistry29.createUnionType(jSTypeNativeArray31);
        com.google.javascript.rhino.ErrorReporter errorReporter33 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry35 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter33, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative36 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray37 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative36 };
        com.google.javascript.rhino.jstype.JSType jSType38 = jSTypeRegistry35.createUnionType(jSTypeNativeArray37);
        com.google.javascript.rhino.Node node40 = new com.google.javascript.rhino.Node((-1));
        com.google.javascript.rhino.jstype.FunctionType functionType41 = jSTypeRegistry29.createFunctionType(jSType38, node40);
        com.google.javascript.rhino.Node node42 = new com.google.javascript.rhino.Node((int) ' ', node40);
        com.google.javascript.rhino.Node node43 = new com.google.javascript.rhino.Node((int) ' ', node42);
        com.google.javascript.rhino.Node node45 = com.google.javascript.rhino.Node.newString("hi!");
        com.google.javascript.rhino.Node node46 = node45.getNext();
        com.google.javascript.rhino.Node node47 = new com.google.javascript.rhino.Node((int) (short) 100, node24, node43, node45);
        com.google.javascript.rhino.Node[] nodeArray48 = new com.google.javascript.rhino.Node[] { node2, node8, node17, node43 };
        try {
            com.google.javascript.rhino.Node node49 = new com.google.javascript.rhino.Node(30, nodeArray48);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(jSType6);
        org.junit.Assert.assertNull(jSType12);
        org.junit.Assert.assertNull(node15);
        org.junit.Assert.assertNull(jSType21);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertTrue("'" + jSTypeNative30 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative30.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray31);
        org.junit.Assert.assertNotNull(jSType32);
        org.junit.Assert.assertTrue("'" + jSTypeNative36 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative36.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray37);
        org.junit.Assert.assertNotNull(jSType38);
        org.junit.Assert.assertNotNull(functionType41);
        org.junit.Assert.assertNotNull(node45);
        org.junit.Assert.assertNull(node46);
        org.junit.Assert.assertNotNull(nodeArray48);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.disambiguateProperties;
        boolean boolean2 = compilerOptions0.isExternExportsEnabled();
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup3 = com.google.javascript.jscomp.DiagnosticGroups.CHECK_TYPES;
        com.google.javascript.jscomp.CompilerOptions compilerOptions4 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel5 = compilerOptions4.checkMissingGetCssNameLevel;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard6 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup3, checkLevel5);
        compilerOptions0.checkProvides = checkLevel5;
        boolean boolean8 = compilerOptions0.aliasAllStrings;
        com.google.javascript.jscomp.CheckLevel checkLevel9 = compilerOptions0.reportMissingOverride;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(diagnosticGroup3);
        org.junit.Assert.assertTrue("'" + checkLevel5 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel5.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + checkLevel9 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel9.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        com.google.javascript.jscomp.DiagnosticType diagnosticType2 = com.google.javascript.jscomp.DiagnosticType.disabled("Unknown class name", "STRING hi!");
        org.junit.Assert.assertNotNull(diagnosticType2);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative3 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray4 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative3 };
        com.google.javascript.rhino.jstype.JSType jSType5 = jSTypeRegistry2.createUnionType(jSTypeNativeArray4);
        com.google.javascript.rhino.ErrorReporter errorReporter6 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry8 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter6, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative9 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray10 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative9 };
        com.google.javascript.rhino.jstype.JSType jSType11 = jSTypeRegistry8.createUnionType(jSTypeNativeArray10);
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node((-1));
        com.google.javascript.rhino.jstype.FunctionType functionType14 = jSTypeRegistry2.createFunctionType(jSType11, node13);
        boolean boolean16 = functionType14.hasOwnProperty("hi!");
        com.google.javascript.rhino.ErrorReporter errorReporter17 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry19 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter17, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative20 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray21 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative20 };
        com.google.javascript.rhino.jstype.JSType jSType22 = jSTypeRegistry19.createUnionType(jSTypeNativeArray21);
        com.google.javascript.rhino.ErrorReporter errorReporter23 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry25 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter23, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative26 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray27 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative26 };
        com.google.javascript.rhino.jstype.JSType jSType28 = jSTypeRegistry25.createUnionType(jSTypeNativeArray27);
        com.google.javascript.rhino.Node node30 = new com.google.javascript.rhino.Node((-1));
        com.google.javascript.rhino.jstype.FunctionType functionType31 = jSTypeRegistry19.createFunctionType(jSType28, node30);
        boolean boolean33 = functionType31.hasOwnProperty("hi!");
        functionType14.setPrototypeBasedOn((com.google.javascript.rhino.jstype.ObjectType) functionType31);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable35 = functionType14.getCtorImplementedInterfaces();
        com.google.javascript.rhino.ErrorReporter errorReporter36 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry38 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter36, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative39 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray40 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative39 };
        com.google.javascript.rhino.jstype.JSType jSType41 = jSTypeRegistry38.createUnionType(jSTypeNativeArray40);
        com.google.javascript.rhino.ErrorReporter errorReporter42 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry44 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter42, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative45 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray46 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative45 };
        com.google.javascript.rhino.jstype.JSType jSType47 = jSTypeRegistry44.createUnionType(jSTypeNativeArray46);
        com.google.javascript.rhino.Node node49 = new com.google.javascript.rhino.Node((-1));
        com.google.javascript.rhino.jstype.FunctionType functionType50 = jSTypeRegistry38.createFunctionType(jSType47, node49);
        boolean boolean52 = functionType50.hasOwnProperty("hi!");
        com.google.javascript.rhino.ErrorReporter errorReporter53 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry55 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter53, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative56 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray57 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative56 };
        com.google.javascript.rhino.jstype.JSType jSType58 = jSTypeRegistry55.createUnionType(jSTypeNativeArray57);
        com.google.javascript.rhino.ErrorReporter errorReporter59 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry61 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter59, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative62 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray63 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative62 };
        com.google.javascript.rhino.jstype.JSType jSType64 = jSTypeRegistry61.createUnionType(jSTypeNativeArray63);
        com.google.javascript.rhino.Node node66 = new com.google.javascript.rhino.Node((-1));
        com.google.javascript.rhino.jstype.FunctionType functionType67 = jSTypeRegistry55.createFunctionType(jSType64, node66);
        boolean boolean69 = functionType67.hasOwnProperty("hi!");
        functionType50.setPrototypeBasedOn((com.google.javascript.rhino.jstype.ObjectType) functionType67);
        com.google.javascript.rhino.jstype.JSType jSType71 = functionType14.getLeastSupertype((com.google.javascript.rhino.jstype.JSType) functionType50);
        boolean boolean72 = functionType50.isCheckedUnknownType();
        java.io.PrintStream printStream73 = null;
        com.google.javascript.jscomp.Compiler compiler74 = new com.google.javascript.jscomp.Compiler(printStream73);
        boolean boolean75 = functionType50.equals((java.lang.Object) compiler74);
        try {
            compiler74.rebuildInputsFromModules();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + jSTypeNative3 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative3.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray4);
        org.junit.Assert.assertNotNull(jSType5);
        org.junit.Assert.assertTrue("'" + jSTypeNative9 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative9.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray10);
        org.junit.Assert.assertNotNull(jSType11);
        org.junit.Assert.assertNotNull(functionType14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + jSTypeNative20 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative20.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray21);
        org.junit.Assert.assertNotNull(jSType22);
        org.junit.Assert.assertTrue("'" + jSTypeNative26 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative26.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray27);
        org.junit.Assert.assertNotNull(jSType28);
        org.junit.Assert.assertNotNull(functionType31);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(objectTypeIterable35);
        org.junit.Assert.assertTrue("'" + jSTypeNative39 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative39.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray40);
        org.junit.Assert.assertNotNull(jSType41);
        org.junit.Assert.assertTrue("'" + jSTypeNative45 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative45.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray46);
        org.junit.Assert.assertNotNull(jSType47);
        org.junit.Assert.assertNotNull(functionType50);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertTrue("'" + jSTypeNative56 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative56.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray57);
        org.junit.Assert.assertNotNull(jSType58);
        org.junit.Assert.assertTrue("'" + jSTypeNative62 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative62.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray63);
        org.junit.Assert.assertNotNull(jSType64);
        org.junit.Assert.assertNotNull(functionType67);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
        org.junit.Assert.assertNotNull(jSType71);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.disambiguateProperties;
        compilerOptions0.removeUnusedPrototypeProperties = true;
        com.google.javascript.jscomp.CheckLevel checkLevel4 = compilerOptions0.checkMissingGetCssNameLevel;
        compilerOptions0.inferTypesInGlobalScope = false;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + checkLevel4 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel4.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newString("hi!");
        int int2 = node1.getSideEffectFlags();
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative3 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray4 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative3 };
        com.google.javascript.rhino.jstype.JSType jSType5 = jSTypeRegistry2.createUnionType(jSTypeNativeArray4);
        com.google.javascript.rhino.ErrorReporter errorReporter6 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry8 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter6, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative9 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray10 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative9 };
        com.google.javascript.rhino.jstype.JSType jSType11 = jSTypeRegistry8.createUnionType(jSTypeNativeArray10);
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node((-1));
        com.google.javascript.rhino.jstype.FunctionType functionType14 = jSTypeRegistry2.createFunctionType(jSType11, node13);
        boolean boolean16 = functionType14.hasOwnProperty("hi!");
        com.google.javascript.rhino.jstype.FunctionPrototypeType functionPrototypeType17 = null;
        boolean boolean18 = functionType14.setPrototype(functionPrototypeType17);
        boolean boolean20 = functionType14.hasOwnProperty("");
        com.google.javascript.rhino.ErrorReporter errorReporter21 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry23 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter21, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative24 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray25 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative24 };
        com.google.javascript.rhino.jstype.JSType jSType26 = jSTypeRegistry23.createUnionType(jSTypeNativeArray25);
        com.google.javascript.rhino.ErrorReporter errorReporter27 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry29 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter27, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative30 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray31 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative30 };
        com.google.javascript.rhino.jstype.JSType jSType32 = jSTypeRegistry29.createUnionType(jSTypeNativeArray31);
        com.google.javascript.rhino.Node node34 = new com.google.javascript.rhino.Node((-1));
        com.google.javascript.rhino.jstype.FunctionType functionType35 = jSTypeRegistry23.createFunctionType(jSType32, node34);
        boolean boolean36 = functionType35.matchesInt32Context();
        boolean boolean37 = functionType35.isConstructor();
        functionType14.setPrototypeBasedOn((com.google.javascript.rhino.jstype.ObjectType) functionType35);
        com.google.javascript.rhino.jstype.FunctionType functionType39 = functionType35.getConstructor();
        try {
            boolean boolean40 = functionType39.matchesStringContext();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + jSTypeNative3 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative3.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray4);
        org.junit.Assert.assertNotNull(jSType5);
        org.junit.Assert.assertTrue("'" + jSTypeNative9 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative9.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray10);
        org.junit.Assert.assertNotNull(jSType11);
        org.junit.Assert.assertNotNull(functionType14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + jSTypeNative24 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative24.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray25);
        org.junit.Assert.assertNotNull(jSType26);
        org.junit.Assert.assertTrue("'" + jSTypeNative30 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative30.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray31);
        org.junit.Assert.assertNotNull(jSType32);
        org.junit.Assert.assertNotNull(functionType35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNull(functionType39);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.ErrorReporter errorReporter3 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter3, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative6 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray7 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative6 };
        com.google.javascript.rhino.jstype.JSType jSType8 = jSTypeRegistry5.createUnionType(jSTypeNativeArray7);
        com.google.javascript.rhino.ErrorReporter errorReporter9 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry11 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter9, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative12 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray13 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative12 };
        com.google.javascript.rhino.jstype.JSType jSType14 = jSTypeRegistry11.createUnionType(jSTypeNativeArray13);
        com.google.javascript.rhino.Node node16 = new com.google.javascript.rhino.Node((-1));
        com.google.javascript.rhino.jstype.FunctionType functionType17 = jSTypeRegistry5.createFunctionType(jSType14, node16);
        com.google.javascript.rhino.Node node18 = new com.google.javascript.rhino.Node((int) ' ', node16);
        com.google.javascript.rhino.Node node19 = new com.google.javascript.rhino.Node((int) ' ', node18);
        java.lang.String str20 = closureCodingConvention0.getSingletonGetterClassName(node18);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode24 = new com.google.javascript.rhino.ScriptOrFnNode(11, 130, (int) (short) 100);
        int int27 = scriptOrFnNode24.addRegexp("language version", "hi!");
        boolean boolean28 = closureCodingConvention0.isOptionalParameter((com.google.javascript.rhino.Node) scriptOrFnNode24);
        int int29 = scriptOrFnNode24.getEncodedSourceStart();
        org.junit.Assert.assertTrue("'" + jSTypeNative6 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative6.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray7);
        org.junit.Assert.assertNotNull(jSType8);
        org.junit.Assert.assertTrue("'" + jSTypeNative12 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative12.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray13);
        org.junit.Assert.assertNotNull(jSType14);
        org.junit.Assert.assertNotNull(functionType17);
        org.junit.Assert.assertNull(str20);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        com.google.javascript.rhino.EcmaError ecmaError1 = com.google.javascript.rhino.ScriptRuntime.typeError("EOF");
        java.lang.String str2 = ecmaError1.getSourceName();
        org.junit.Assert.assertNotNull(ecmaError1);
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.ALL_TYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.ALL_TYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.ALL_TYPE));
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.common.collect.Multimap<com.google.javascript.jscomp.CustomPassExecutionTime, com.google.javascript.jscomp.CompilerPass> customPassExecutionTimeMultimap1 = null;
        compilerOptions0.customPasses = customPassExecutionTimeMultimap1;
        boolean boolean3 = compilerOptions0.inlineConstantVars;
        java.lang.String str4 = compilerOptions0.syntheticBlockStartMarker;
        compilerOptions0.decomposeExpressions = false;
        boolean boolean7 = compilerOptions0.checkTypes;
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup8 = com.google.javascript.jscomp.DiagnosticGroups.INVALID_CASTS;
        com.google.javascript.jscomp.CompilerOptions compilerOptions9 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel10 = compilerOptions9.checkMissingGetCssNameLevel;
        compilerOptions0.setWarningLevel(diagnosticGroup8, checkLevel10);
        com.google.javascript.jscomp.DiagnosticGroups.DEPRECATED = diagnosticGroup8;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(diagnosticGroup8);
        org.junit.Assert.assertTrue("'" + checkLevel10 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel10.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative3 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray4 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative3 };
        com.google.javascript.rhino.jstype.JSType jSType5 = jSTypeRegistry2.createUnionType(jSTypeNativeArray4);
        com.google.javascript.rhino.ErrorReporter errorReporter6 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry8 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter6, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative9 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray10 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative9 };
        com.google.javascript.rhino.jstype.JSType jSType11 = jSTypeRegistry8.createUnionType(jSTypeNativeArray10);
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node((-1));
        com.google.javascript.rhino.jstype.FunctionType functionType14 = jSTypeRegistry2.createFunctionType(jSType11, node13);
        boolean boolean16 = functionType14.hasOwnProperty("hi!");
        com.google.javascript.rhino.jstype.FunctionPrototypeType functionPrototypeType17 = null;
        boolean boolean18 = functionType14.setPrototype(functionPrototypeType17);
        java.lang.String str19 = functionType14.getDisplayName();
        boolean boolean20 = functionType14.isRecordType();
        com.google.javascript.rhino.JSDocInfo jSDocInfo22 = functionType14.getOwnPropertyJSDocInfo("goog.exportSymbol");
        org.junit.Assert.assertTrue("'" + jSTypeNative3 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative3.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray4);
        org.junit.Assert.assertNotNull(jSType5);
        org.junit.Assert.assertTrue("'" + jSTypeNative9 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative9.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray10);
        org.junit.Assert.assertNotNull(jSType11);
        org.junit.Assert.assertNotNull(functionType14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNull(str19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNull(jSDocInfo22);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.REGEXP_FUNCTION_TYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.REGEXP_FUNCTION_TYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.REGEXP_FUNCTION_TYPE));
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.common.collect.Multimap<com.google.javascript.jscomp.CustomPassExecutionTime, com.google.javascript.jscomp.CompilerPass> customPassExecutionTimeMultimap1 = null;
        compilerOptions0.customPasses = customPassExecutionTimeMultimap1;
        compilerOptions0.devirtualizePrototypeMethods = true;
        compilerOptions0.checkDuplicateMessages = false;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy7 = null;
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy8 = null;
        compilerOptions0.setRenamingPolicy(variableRenamingPolicy7, propertyRenamingPolicy8);
        boolean boolean10 = compilerOptions0.convertToDottedProperties;
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.removeUnusedPrototypeProperties;
        compilerOptions0.removeEmptyFunctions = true;
        compilerOptions0.nameReferenceReportPath = "STRING hi!";
        java.lang.String str6 = compilerOptions0.aliasableGlobals;
        com.google.javascript.jscomp.CheckLevel checkLevel7 = null;
        compilerOptions0.checkFunctions = checkLevel7;
        compilerOptions0.flowSensitiveInlineVariables = false;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNull(str6);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        boolean boolean2 = closureCodingConvention0.isPrivate("EOF");
        java.lang.String str3 = closureCodingConvention0.getExportPropertyFunction();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "goog.exportProperty" + "'", str3.equals("goog.exportProperty"));
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        com.google.javascript.rhino.jstype.JSTypeRegistry.ResolveMode resolveMode0 = com.google.javascript.rhino.jstype.JSTypeRegistry.ResolveMode.IMMEDIATE;
        org.junit.Assert.assertTrue("'" + resolveMode0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeRegistry.ResolveMode.IMMEDIATE + "'", resolveMode0.equals(com.google.javascript.rhino.jstype.JSTypeRegistry.ResolveMode.IMMEDIATE));
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.common.collect.Multimap<com.google.javascript.jscomp.CustomPassExecutionTime, com.google.javascript.jscomp.CompilerPass> customPassExecutionTimeMultimap1 = null;
        compilerOptions0.customPasses = customPassExecutionTimeMultimap1;
        boolean boolean3 = compilerOptions0.inlineConstantVars;
        java.lang.String str4 = compilerOptions0.syntheticBlockStartMarker;
        compilerOptions0.decomposeExpressions = false;
        boolean boolean7 = compilerOptions0.checkTypes;
        compilerOptions0.instrumentationTemplate = "";
        byte[] byteArray15 = new byte[] { (byte) 10, (byte) 10, (byte) 100, (byte) 1, (byte) 1 };
        compilerOptions0.inputVariableMapSerialized = byteArray15;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(byteArray15);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        com.google.javascript.rhino.Context context0 = com.google.javascript.rhino.Context.enter();
        java.util.Locale locale1 = context0.getLocale();
        boolean boolean2 = context0.hasCompileFunctionsWithDynamicScope();
        com.google.javascript.rhino.ErrorReporter errorReporter3 = null;
        try {
            com.google.javascript.rhino.ErrorReporter errorReporter4 = context0.setErrorReporter(errorReporter3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(context0);
        org.junit.Assert.assertNotNull(locale1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        com.google.javascript.rhino.Node node3 = new com.google.javascript.rhino.Node(48, 0, 22);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        int int0 = com.google.javascript.rhino.Node.DIRECTCALL_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 26 + "'", int0 == 26);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.common.collect.Multimap<com.google.javascript.jscomp.CustomPassExecutionTime, com.google.javascript.jscomp.CompilerPass> customPassExecutionTimeMultimap1 = null;
        compilerOptions0.customPasses = customPassExecutionTimeMultimap1;
        compilerOptions0.devirtualizePrototypeMethods = true;
        compilerOptions0.setOutputCharset("goog.exportSymbol");
        java.util.List<java.lang.String> strList8 = null;
        try {
            compilerOptions0.setReplaceStringsConfiguration("language version", strList8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.PerformanceTracker performanceTracker2 = compiler1.tracker;
        com.google.javascript.jscomp.CompilerOptions compilerOptions3 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.common.collect.Multimap<com.google.javascript.jscomp.CustomPassExecutionTime, com.google.javascript.jscomp.CompilerPass> customPassExecutionTimeMultimap4 = null;
        compilerOptions3.customPasses = customPassExecutionTimeMultimap4;
        boolean boolean6 = compilerOptions3.inlineConstantVars;
        java.lang.String str7 = compilerOptions3.syntheticBlockStartMarker;
        compilerOptions3.decomposeExpressions = false;
        boolean boolean10 = compilerOptions3.checkTypes;
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup11 = com.google.javascript.jscomp.DiagnosticGroups.INVALID_CASTS;
        com.google.javascript.jscomp.CompilerOptions compilerOptions12 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel13 = compilerOptions12.checkMissingGetCssNameLevel;
        compilerOptions3.setWarningLevel(diagnosticGroup11, checkLevel13);
        compiler1.initOptions(compilerOptions3);
        org.junit.Assert.assertNull(performanceTracker2);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(diagnosticGroup11);
        org.junit.Assert.assertTrue("'" + checkLevel13 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel13.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.common.collect.Multimap<com.google.javascript.jscomp.CustomPassExecutionTime, com.google.javascript.jscomp.CompilerPass> customPassExecutionTimeMultimap1 = null;
        compilerOptions0.customPasses = customPassExecutionTimeMultimap1;
        compilerOptions0.devirtualizePrototypeMethods = true;
        compilerOptions0.checkDuplicateMessages = false;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy7 = null;
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy8 = null;
        compilerOptions0.setRenamingPolicy(variableRenamingPolicy7, propertyRenamingPolicy8);
        com.google.javascript.jscomp.CheckLevel checkLevel10 = compilerOptions0.checkUndefinedProperties;
        boolean boolean11 = compilerOptions0.smartNameRemoval;
        org.junit.Assert.assertTrue("'" + checkLevel10 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel10.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.SYNTAX_ERROR_TYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.SYNTAX_ERROR_TYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.SYNTAX_ERROR_TYPE));
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative3 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray4 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative3 };
        com.google.javascript.rhino.jstype.JSType jSType5 = jSTypeRegistry2.createUnionType(jSTypeNativeArray4);
        com.google.javascript.rhino.ErrorReporter errorReporter6 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry8 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter6, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative9 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray10 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative9 };
        com.google.javascript.rhino.jstype.JSType jSType11 = jSTypeRegistry8.createUnionType(jSTypeNativeArray10);
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node((-1));
        com.google.javascript.rhino.jstype.FunctionType functionType14 = jSTypeRegistry2.createFunctionType(jSType11, node13);
        com.google.javascript.rhino.ErrorReporter errorReporter15 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry17 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter15, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative18 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray19 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative18 };
        com.google.javascript.rhino.jstype.JSType jSType20 = jSTypeRegistry17.createUnionType(jSTypeNativeArray19);
        com.google.javascript.rhino.ErrorReporter errorReporter21 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry23 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter21, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative24 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray25 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative24 };
        com.google.javascript.rhino.jstype.JSType jSType26 = jSTypeRegistry23.createUnionType(jSTypeNativeArray25);
        com.google.javascript.rhino.Node node28 = new com.google.javascript.rhino.Node((-1));
        com.google.javascript.rhino.jstype.FunctionType functionType29 = jSTypeRegistry17.createFunctionType(jSType26, node28);
        boolean boolean31 = functionType29.hasOwnProperty("hi!");
        com.google.javascript.rhino.jstype.ObjectType objectType32 = jSTypeRegistry2.createObjectType((com.google.javascript.rhino.jstype.ObjectType) functionType29);
        com.google.javascript.rhino.ErrorReporter errorReporter33 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry35 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter33, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative36 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray37 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative36 };
        com.google.javascript.rhino.jstype.JSType jSType38 = jSTypeRegistry35.createUnionType(jSTypeNativeArray37);
        com.google.javascript.rhino.ErrorReporter errorReporter39 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry41 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter39, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative42 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray43 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative42 };
        com.google.javascript.rhino.jstype.JSType jSType44 = jSTypeRegistry41.createUnionType(jSTypeNativeArray43);
        com.google.javascript.rhino.Node node46 = new com.google.javascript.rhino.Node((-1));
        com.google.javascript.rhino.jstype.FunctionType functionType47 = jSTypeRegistry35.createFunctionType(jSType44, node46);
        boolean boolean49 = functionType47.hasOwnProperty("hi!");
        com.google.javascript.rhino.jstype.FunctionPrototypeType functionPrototypeType50 = null;
        boolean boolean51 = functionType47.setPrototype(functionPrototypeType50);
        com.google.javascript.rhino.jstype.ObjectType objectType52 = functionType47.toObjectType();
        boolean boolean53 = objectType32.isEquivalentTo((com.google.javascript.rhino.jstype.JSType) functionType47);
        com.google.javascript.rhino.jstype.JSType jSType54 = functionType47.unboxesTo();
        org.junit.Assert.assertTrue("'" + jSTypeNative3 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative3.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray4);
        org.junit.Assert.assertNotNull(jSType5);
        org.junit.Assert.assertTrue("'" + jSTypeNative9 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative9.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray10);
        org.junit.Assert.assertNotNull(jSType11);
        org.junit.Assert.assertNotNull(functionType14);
        org.junit.Assert.assertTrue("'" + jSTypeNative18 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative18.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray19);
        org.junit.Assert.assertNotNull(jSType20);
        org.junit.Assert.assertTrue("'" + jSTypeNative24 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative24.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray25);
        org.junit.Assert.assertNotNull(jSType26);
        org.junit.Assert.assertNotNull(functionType29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(objectType32);
        org.junit.Assert.assertTrue("'" + jSTypeNative36 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative36.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray37);
        org.junit.Assert.assertNotNull(jSType38);
        org.junit.Assert.assertTrue("'" + jSTypeNative42 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative42.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray43);
        org.junit.Assert.assertNotNull(jSType44);
        org.junit.Assert.assertNotNull(functionType47);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertNotNull(objectType52);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNull(jSType54);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        int int0 = com.google.javascript.rhino.jstype.JSType.ENUMDECL;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        java.lang.String str2 = com.google.javascript.rhino.ScriptRuntime.numberToString(0.0d, 79);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0" + "'", str2.equals("0"));
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        int int0 = com.google.javascript.rhino.Node.FLAG_ARGUMENTS_UNMODIFIED;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.CHECK_REGEXP;
        com.google.javascript.jscomp.DiagnosticGroups.STRICT_MODULE_DEP_CHECK = diagnosticGroup0;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        com.google.javascript.jscomp.MessageFormatter messageFormatter0 = null;
        java.util.logging.Logger logger1 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager2 = new com.google.javascript.jscomp.LoggerErrorManager(messageFormatter0, logger1);
        com.google.javascript.jscomp.JSError[] jSErrorArray3 = loggerErrorManager2.getErrors();
        loggerErrorManager2.generateReport();
        com.google.javascript.jscomp.JSError[] jSErrorArray5 = loggerErrorManager2.getErrors();
        org.junit.Assert.assertNotNull(jSErrorArray3);
        org.junit.Assert.assertNotNull(jSErrorArray5);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        com.google.javascript.rhino.Context context0 = com.google.javascript.rhino.Context.enter();
        java.util.Locale locale1 = context0.getLocale();
        long long2 = com.google.javascript.rhino.ScriptRuntime.lastUint32Result(context0);
        try {
            context0.setLanguageVersion(121);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Bad language version: 121");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(context0);
        org.junit.Assert.assertNotNull(locale1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        com.google.javascript.rhino.Context context0 = com.google.javascript.rhino.Context.enter();
        java.util.Locale locale1 = context0.getLocale();
        boolean boolean2 = context0.hasCompileFunctionsWithDynamicScope();
        long long3 = com.google.javascript.rhino.ScriptRuntime.lastUint32Result(context0);
        org.junit.Assert.assertNotNull(context0);
        org.junit.Assert.assertNotNull(locale1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode3 = new com.google.javascript.rhino.ScriptOrFnNode(11, 130, (int) (short) 100);
        java.lang.String str4 = scriptOrFnNode3.getSourceName();
        boolean[] booleanArray5 = scriptOrFnNode3.getParamAndVarConst();
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNotNull(booleanArray5);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        com.google.javascript.rhino.EvaluatorException evaluatorException5 = new com.google.javascript.rhino.EvaluatorException("", "", 100, "hi!", (int) (short) 1);
        java.lang.String str6 = evaluatorException5.sourceName();
        com.google.javascript.rhino.EvaluatorException evaluatorException12 = new com.google.javascript.rhino.EvaluatorException("", "", 100, "hi!", (int) (short) 1);
        evaluatorException5.addSuppressed((java.lang.Throwable) evaluatorException12);
        com.google.javascript.rhino.EcmaError ecmaError20 = com.google.javascript.rhino.ScriptRuntime.constructError("", "Fixed point computation not halting", "", 78, "language version", 33);
        evaluatorException5.addSuppressed((java.lang.Throwable) ecmaError20);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertNotNull(ecmaError20);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy0 = com.google.javascript.jscomp.VariableRenamingPolicy.LOCAL;
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy0 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.LOCAL + "'", variableRenamingPolicy0.equals(com.google.javascript.jscomp.VariableRenamingPolicy.LOCAL));
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        com.google.javascript.jscomp.SourceAst sourceAst0 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(sourceAst0, "", true);
        com.google.javascript.jscomp.SourceAst sourceAst4 = compilerInput3.getSourceAst();
        java.io.PrintStream printStream5 = null;
        com.google.javascript.jscomp.Compiler compiler6 = new com.google.javascript.jscomp.Compiler(printStream5);
        com.google.javascript.jscomp.PerformanceTracker performanceTracker7 = compiler6.tracker;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile10 = com.google.javascript.jscomp.JSSourceFile.fromCode("EOF", "language version");
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray11 = new com.google.javascript.jscomp.JSSourceFile[] {};
        com.google.javascript.jscomp.CompilerOptions compilerOptions12 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean13 = compilerOptions12.removeUnusedPrototypeProperties;
        compilerOptions12.removeEmptyFunctions = true;
        compilerOptions12.removeUnusedVars = false;
        compilerOptions12.gatherCssNames = true;
        com.google.javascript.jscomp.Result result20 = compiler6.compile(jSSourceFile10, jSSourceFileArray11, compilerOptions12);
        try {
            compilerInput3.setSourceFile((com.google.javascript.jscomp.SourceFile) jSSourceFile10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(sourceAst4);
        org.junit.Assert.assertNull(performanceTracker7);
        org.junit.Assert.assertNotNull(jSSourceFile10);
        org.junit.Assert.assertNotNull(jSSourceFileArray11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(result20);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        com.google.javascript.rhino.JSDocInfoBuilder jSDocInfoBuilder1 = new com.google.javascript.rhino.JSDocInfoBuilder(false);
        com.google.javascript.jscomp.CompilerOptions compilerOptions2 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.common.collect.Multimap<com.google.javascript.jscomp.CustomPassExecutionTime, com.google.javascript.jscomp.CompilerPass> customPassExecutionTimeMultimap3 = null;
        compilerOptions2.customPasses = customPassExecutionTimeMultimap3;
        boolean boolean5 = compilerOptions2.inlineConstantVars;
        java.lang.String str6 = compilerOptions2.syntheticBlockStartMarker;
        compilerOptions2.decomposeExpressions = false;
        boolean boolean9 = compilerOptions2.checkTypes;
        java.lang.String str10 = compilerOptions2.sourceMapOutputPath;
        boolean boolean11 = compilerOptions2.deadAssignmentElimination;
        java.lang.String[] strArray15 = new java.lang.String[] { "language version", "language version", "" };
        java.util.LinkedHashSet<java.lang.String> strSet16 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean17 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet16, strArray15);
        compilerOptions2.aliasableStrings = strSet16;
        boolean boolean19 = jSDocInfoBuilder1.recordModifies((java.util.Set<java.lang.String>) strSet16);
        boolean boolean20 = jSDocInfoBuilder1.recordImplicitCast();
        boolean boolean21 = jSDocInfoBuilder1.recordExport();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(strArray15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.checkMissingGetCssNameLevel;
        boolean boolean2 = compilerOptions0.collapseProperties;
        boolean boolean3 = compilerOptions0.checkUnusedPropertiesEarly;
        compilerOptions0.removeUnusedVars = true;
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative3 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray4 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative3 };
        com.google.javascript.rhino.jstype.JSType jSType5 = jSTypeRegistry2.createUnionType(jSTypeNativeArray4);
        com.google.javascript.rhino.ErrorReporter errorReporter6 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry8 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter6, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative9 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray10 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative9 };
        com.google.javascript.rhino.jstype.JSType jSType11 = jSTypeRegistry8.createUnionType(jSTypeNativeArray10);
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node((-1));
        com.google.javascript.rhino.jstype.FunctionType functionType14 = jSTypeRegistry2.createFunctionType(jSType11, node13);
        boolean boolean16 = functionType14.hasOwnProperty("hi!");
        com.google.javascript.rhino.jstype.FunctionPrototypeType functionPrototypeType17 = null;
        boolean boolean18 = functionType14.setPrototype(functionPrototypeType17);
        boolean boolean20 = functionType14.hasOwnProperty("hi!");
        boolean boolean21 = functionType14.hasInstanceType();
        boolean boolean22 = functionType14.isNativeObjectType();
        org.junit.Assert.assertTrue("'" + jSTypeNative3 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative3.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray4);
        org.junit.Assert.assertNotNull(jSType5);
        org.junit.Assert.assertTrue("'" + jSTypeNative9 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative9.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray10);
        org.junit.Assert.assertNotNull(jSType11);
        org.junit.Assert.assertNotNull(functionType14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        com.google.javascript.jscomp.DiagnosticType diagnosticType0 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        com.google.javascript.jscomp.DiagnosticType diagnosticType3 = com.google.javascript.jscomp.DiagnosticType.warning("", "");
        int int4 = diagnosticType0.compareTo(diagnosticType3);
        java.lang.String str5 = diagnosticType0.toString();
        org.junit.Assert.assertNotNull(diagnosticType0);
        org.junit.Assert.assertNotNull(diagnosticType3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 23 + "'", int4 == 23);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of optimization iterations: {0}" + "'", str5.equals("JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of optimization iterations: {0}"));
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.removeUnusedPrototypeProperties;
        compilerOptions0.removeEmptyFunctions = true;
        compilerOptions0.removeUnusedVars = false;
        compilerOptions0.gatherCssNames = true;
        compilerOptions0.setNameAnonymousFunctionsOnly(false);
        compilerOptions0.devirtualizePrototypeMethods = false;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.common.collect.Multimap<com.google.javascript.jscomp.CustomPassExecutionTime, com.google.javascript.jscomp.CompilerPass> customPassExecutionTimeMultimap1 = null;
        compilerOptions0.customPasses = customPassExecutionTimeMultimap1;
        boolean boolean3 = compilerOptions0.inlineConstantVars;
        java.lang.String str4 = compilerOptions0.syntheticBlockStartMarker;
        compilerOptions0.decomposeExpressions = false;
        boolean boolean7 = compilerOptions0.checkTypes;
        java.lang.String str8 = compilerOptions0.sourceMapOutputPath;
        boolean boolean9 = compilerOptions0.deadAssignmentElimination;
        java.lang.String[] strArray13 = new java.lang.String[] { "language version", "language version", "" };
        java.util.LinkedHashSet<java.lang.String> strSet14 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean15 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet14, strArray13);
        compilerOptions0.aliasableStrings = strSet14;
        java.util.Set<java.lang.String> strSet17 = compilerOptions0.stripNameSuffixes;
        compilerOptions0.setColorizeErrorOutput(false);
        java.util.List<java.lang.String> strList21 = null;
        try {
            compilerOptions0.setReplaceStringsConfiguration("error reporter", strList21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(strArray13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(strSet17);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.Node node4 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType5 = jSTypeRegistry2.createInterfaceType("", node4);
        functionType5.clearResolved();
        org.junit.Assert.assertNotNull(functionType5);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        int int0 = com.google.javascript.rhino.Node.SPECIALCALL_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 27 + "'", int0 == 27);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.ErrorReporter errorReporter3 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter3, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative6 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray7 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative6 };
        com.google.javascript.rhino.jstype.JSType jSType8 = jSTypeRegistry5.createUnionType(jSTypeNativeArray7);
        com.google.javascript.rhino.ErrorReporter errorReporter9 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry11 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter9, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative12 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray13 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative12 };
        com.google.javascript.rhino.jstype.JSType jSType14 = jSTypeRegistry11.createUnionType(jSTypeNativeArray13);
        com.google.javascript.rhino.Node node16 = new com.google.javascript.rhino.Node((-1));
        com.google.javascript.rhino.jstype.FunctionType functionType17 = jSTypeRegistry5.createFunctionType(jSType14, node16);
        boolean boolean19 = functionType17.hasOwnProperty("hi!");
        com.google.javascript.rhino.jstype.ObjectType objectType20 = jSTypeRegistry2.createObjectType((com.google.javascript.rhino.jstype.ObjectType) functionType17);
        com.google.javascript.rhino.ErrorReporter errorReporter21 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry23 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter21, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative24 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray25 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative24 };
        com.google.javascript.rhino.jstype.JSType jSType26 = jSTypeRegistry23.createUnionType(jSTypeNativeArray25);
        com.google.javascript.rhino.jstype.JSType jSType27 = jSTypeRegistry2.createUnionType(jSTypeNativeArray25);
        org.junit.Assert.assertTrue("'" + jSTypeNative6 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative6.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray7);
        org.junit.Assert.assertNotNull(jSType8);
        org.junit.Assert.assertTrue("'" + jSTypeNative12 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative12.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray13);
        org.junit.Assert.assertNotNull(jSType14);
        org.junit.Assert.assertNotNull(functionType17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(objectType20);
        org.junit.Assert.assertTrue("'" + jSTypeNative24 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative24.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray25);
        org.junit.Assert.assertNotNull(jSType26);
        org.junit.Assert.assertNotNull(jSType27);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        com.google.javascript.rhino.JSDocInfoBuilder jSDocInfoBuilder1 = new com.google.javascript.rhino.JSDocInfoBuilder(false);
        com.google.javascript.jscomp.CompilerOptions compilerOptions2 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.common.collect.Multimap<com.google.javascript.jscomp.CustomPassExecutionTime, com.google.javascript.jscomp.CompilerPass> customPassExecutionTimeMultimap3 = null;
        compilerOptions2.customPasses = customPassExecutionTimeMultimap3;
        boolean boolean5 = compilerOptions2.inlineConstantVars;
        java.lang.String str6 = compilerOptions2.syntheticBlockStartMarker;
        compilerOptions2.decomposeExpressions = false;
        boolean boolean9 = compilerOptions2.checkTypes;
        java.lang.String str10 = compilerOptions2.sourceMapOutputPath;
        boolean boolean11 = compilerOptions2.deadAssignmentElimination;
        java.lang.String[] strArray15 = new java.lang.String[] { "language version", "language version", "" };
        java.util.LinkedHashSet<java.lang.String> strSet16 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean17 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet16, strArray15);
        compilerOptions2.aliasableStrings = strSet16;
        boolean boolean19 = jSDocInfoBuilder1.recordModifies((java.util.Set<java.lang.String>) strSet16);
        boolean boolean20 = jSDocInfoBuilder1.recordImplicitCast();
        com.google.javascript.rhino.JSDocInfo jSDocInfo22 = jSDocInfoBuilder1.build("Named type with empty name component");
        boolean boolean23 = jSDocInfo22.isNoCompile();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(strArray15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(jSDocInfo22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.STRING_OBJECT_TYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.STRING_OBJECT_TYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.STRING_OBJECT_TYPE));
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.removeUnusedPrototypeProperties;
        compilerOptions0.removeEmptyFunctions = true;
        boolean boolean4 = compilerOptions0.instrumentForCoverageOnly;
        compilerOptions0.sourceMapOutputPath = "STRING hi!";
        compilerOptions0.ignoreCajaProperties = true;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.removeUnusedPrototypeProperties;
        compilerOptions0.removeEmptyFunctions = true;
        compilerOptions0.nameReferenceReportPath = "STRING hi!";
        compilerOptions0.disableRuntimeTypeCheck();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.Node.newString("hi!");
        com.google.javascript.rhino.ErrorReporter errorReporter5 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry7 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter5, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative8 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray9 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative8 };
        com.google.javascript.rhino.jstype.JSType jSType10 = jSTypeRegistry7.createUnionType(jSTypeNativeArray9);
        com.google.javascript.rhino.ErrorReporter errorReporter11 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry13 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter11, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative14 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray15 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative14 };
        com.google.javascript.rhino.jstype.JSType jSType16 = jSTypeRegistry13.createUnionType(jSTypeNativeArray15);
        com.google.javascript.rhino.Node node18 = new com.google.javascript.rhino.Node((-1));
        com.google.javascript.rhino.jstype.FunctionType functionType19 = jSTypeRegistry7.createFunctionType(jSType16, node18);
        com.google.javascript.rhino.Node node20 = new com.google.javascript.rhino.Node((int) ' ', node18);
        com.google.javascript.rhino.Node node21 = new com.google.javascript.rhino.Node((int) ' ', node20);
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newString("hi!");
        com.google.javascript.rhino.Node node24 = node23.getNext();
        com.google.javascript.rhino.Node node25 = new com.google.javascript.rhino.Node((int) (short) 100, node2, node21, node23);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder26 = node21.getJsDocBuilderForNode();
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertTrue("'" + jSTypeNative8 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative8.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray9);
        org.junit.Assert.assertNotNull(jSType10);
        org.junit.Assert.assertTrue("'" + jSTypeNative14 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative14.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray15);
        org.junit.Assert.assertNotNull(jSType16);
        org.junit.Assert.assertNotNull(functionType19);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNull(node24);
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder26);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.disambiguateProperties;
        boolean boolean2 = compilerOptions0.isExternExportsEnabled();
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup3 = com.google.javascript.jscomp.DiagnosticGroups.CHECK_TYPES;
        com.google.javascript.jscomp.CompilerOptions compilerOptions4 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel5 = compilerOptions4.checkMissingGetCssNameLevel;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard6 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup3, checkLevel5);
        compilerOptions0.checkProvides = checkLevel5;
        boolean boolean8 = compilerOptions0.aliasAllStrings;
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup9 = com.google.javascript.jscomp.DiagnosticGroups.CHECK_TYPES;
        com.google.javascript.jscomp.CompilerOptions compilerOptions10 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean11 = compilerOptions10.disambiguateProperties;
        boolean boolean12 = compilerOptions10.isExternExportsEnabled();
        com.google.javascript.jscomp.CheckLevel checkLevel13 = compilerOptions10.checkMethods;
        compilerOptions0.setWarningLevel(diagnosticGroup9, checkLevel13);
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.Node.newString((int) '#', "EOF");
        com.google.javascript.jscomp.DiagnosticType diagnosticType19 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        java.lang.String[] strArray26 = new java.lang.String[] { "error reporter", "EOF", "Named type with empty name component", "TYPEOF", "hi!", "Named type with empty name component" };
        com.google.javascript.jscomp.JSError jSError27 = com.google.javascript.jscomp.JSError.make("hi!", node18, diagnosticType19, strArray26);
        boolean boolean28 = diagnosticGroup9.matches(jSError27);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(diagnosticGroup3);
        org.junit.Assert.assertTrue("'" + checkLevel5 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel5.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(diagnosticGroup9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + checkLevel13 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel13.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNotNull(diagnosticType19);
        org.junit.Assert.assertNotNull(strArray26);
        org.junit.Assert.assertNotNull(jSError27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.disambiguateProperties;
        boolean boolean2 = compilerOptions0.isExternExportsEnabled();
        com.google.javascript.jscomp.ErrorFormat errorFormat3 = null;
        compilerOptions0.errorFormat = errorFormat3;
        compilerOptions0.generatePseudoNames = false;
        compilerOptions0.allowLegacyJsMessages = false;
        compilerOptions0.inputDelimiter = "JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of optimization iterations: {0}";
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.ERROR_TYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.ERROR_TYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.ERROR_TYPE));
    }

//    @Test
//    public void test441() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test441");
//        try {
//            com.google.javascript.rhino.Context.reportError("goog.exportProperty", "language version", 38, "Named type with empty name component", (int) (byte) 10);
//            org.junit.Assert.fail("Expected exception of type com.google.javascript.rhino.EvaluatorException; message: goog.exportProperty (language version#38)");
//        } catch (com.google.javascript.rhino.EvaluatorException e) {
//        }
//    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.ErrorReporter errorReporter3 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter3, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative6 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray7 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative6 };
        com.google.javascript.rhino.jstype.JSType jSType8 = jSTypeRegistry5.createUnionType(jSTypeNativeArray7);
        com.google.javascript.rhino.ErrorReporter errorReporter9 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry11 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter9, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative12 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray13 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative12 };
        com.google.javascript.rhino.jstype.JSType jSType14 = jSTypeRegistry11.createUnionType(jSTypeNativeArray13);
        com.google.javascript.rhino.Node node16 = new com.google.javascript.rhino.Node((-1));
        com.google.javascript.rhino.jstype.FunctionType functionType17 = jSTypeRegistry5.createFunctionType(jSType14, node16);
        com.google.javascript.rhino.Node node18 = new com.google.javascript.rhino.Node((int) ' ', node16);
        com.google.javascript.rhino.Node node19 = new com.google.javascript.rhino.Node((int) ' ', node18);
        java.lang.String str20 = closureCodingConvention0.getSingletonGetterClassName(node18);
        com.google.javascript.rhino.Node node24 = com.google.javascript.rhino.Node.newString("EOF", 93, 28);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode28 = new com.google.javascript.rhino.ScriptOrFnNode(11, 130, (int) (short) 100);
        int int29 = scriptOrFnNode28.getEncodedSourceStart();
        boolean boolean31 = scriptOrFnNode28.addConst("hi!");
        java.lang.String str32 = closureCodingConvention0.extractClassNameIfProvide(node24, (com.google.javascript.rhino.Node) scriptOrFnNode28);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode36 = new com.google.javascript.rhino.ScriptOrFnNode(11, 130, (int) (short) 100);
        int int39 = scriptOrFnNode36.addRegexp("language version", "hi!");
        int int40 = scriptOrFnNode36.getEndLineno();
        boolean boolean41 = closureCodingConvention0.isVarArgsParameter((com.google.javascript.rhino.Node) scriptOrFnNode36);
        int int42 = scriptOrFnNode36.getParamCount();
        org.junit.Assert.assertTrue("'" + jSTypeNative6 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative6.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray7);
        org.junit.Assert.assertNotNull(jSType8);
        org.junit.Assert.assertTrue("'" + jSTypeNative12 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative12.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray13);
        org.junit.Assert.assertNotNull(jSType14);
        org.junit.Assert.assertNotNull(functionType17);
        org.junit.Assert.assertNull(str20);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertNull(str32);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + (-1) + "'", int40 == (-1));
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.common.collect.Multimap<com.google.javascript.jscomp.CustomPassExecutionTime, com.google.javascript.jscomp.CompilerPass> customPassExecutionTimeMultimap1 = null;
        compilerOptions0.customPasses = customPassExecutionTimeMultimap1;
        boolean boolean3 = compilerOptions0.inlineConstantVars;
        java.lang.String str4 = compilerOptions0.syntheticBlockStartMarker;
        compilerOptions0.decomposeExpressions = false;
        boolean boolean7 = compilerOptions0.checkTypes;
        java.lang.String str8 = compilerOptions0.sourceMapOutputPath;
        com.google.javascript.jscomp.CheckLevel checkLevel9 = compilerOptions0.brokenClosureRequiresLevel;
        compilerOptions0.aliasExternals = true;
        boolean boolean12 = compilerOptions0.rewriteFunctionExpressions;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertTrue("'" + checkLevel9 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel9.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        int int0 = com.google.javascript.rhino.Node.REGEXP_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 12 + "'", int0 == 12);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        try {
            com.google.javascript.rhino.EcmaError ecmaError3 = com.google.javascript.rhino.ScriptRuntime.typeError2("TYPEOF", "goog.exportProperty", "Named type with empty name component");
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property TYPEOF");
        } catch (java.lang.RuntimeException e) {
        }
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        int int0 = com.google.javascript.rhino.Node.ORIGINALNAME_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 39 + "'", int0 == 39);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.ErrorReporter errorReporter1 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry3 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter1, false);
        com.google.javascript.rhino.ErrorReporter errorReporter4 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry6 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter4, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative7 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray8 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative7 };
        com.google.javascript.rhino.jstype.JSType jSType9 = jSTypeRegistry6.createUnionType(jSTypeNativeArray8);
        com.google.javascript.rhino.ErrorReporter errorReporter10 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry12 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter10, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative13 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray14 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative13 };
        com.google.javascript.rhino.jstype.JSType jSType15 = jSTypeRegistry12.createUnionType(jSTypeNativeArray14);
        com.google.javascript.rhino.Node node17 = new com.google.javascript.rhino.Node((-1));
        com.google.javascript.rhino.jstype.FunctionType functionType18 = jSTypeRegistry6.createFunctionType(jSType15, node17);
        boolean boolean20 = functionType18.hasOwnProperty("hi!");
        com.google.javascript.rhino.jstype.ObjectType objectType21 = jSTypeRegistry3.createObjectType((com.google.javascript.rhino.jstype.ObjectType) functionType18);
        boolean boolean22 = functionType18.isCheckedUnknownType();
        java.lang.RuntimeException runtimeException24 = com.google.javascript.rhino.ScriptRuntime.undefWriteError((java.lang.Object) closureCodingConvention0, (java.lang.Object) functionType18, (java.lang.Object) 30);
        java.lang.String str25 = closureCodingConvention0.getGlobalObject();
        org.junit.Assert.assertTrue("'" + jSTypeNative7 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative7.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray8);
        org.junit.Assert.assertNotNull(jSType9);
        org.junit.Assert.assertTrue("'" + jSTypeNative13 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative13.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray14);
        org.junit.Assert.assertNotNull(jSType15);
        org.junit.Assert.assertNotNull(functionType18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(objectType21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(runtimeException24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "goog.global" + "'", str25.equals("goog.global"));
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.removeUnusedPrototypeProperties;
        compilerOptions0.removeEmptyFunctions = true;
        compilerOptions0.removeUnusedVars = false;
        compilerOptions0.gatherCssNames = true;
        compilerOptions0.setNameAnonymousFunctionsOnly(false);
        com.google.javascript.jscomp.CompilerOptions compilerOptions10 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.common.collect.Multimap<com.google.javascript.jscomp.CustomPassExecutionTime, com.google.javascript.jscomp.CompilerPass> customPassExecutionTimeMultimap11 = null;
        compilerOptions10.customPasses = customPassExecutionTimeMultimap11;
        com.google.javascript.jscomp.ErrorFormat errorFormat13 = compilerOptions10.errorFormat;
        compilerOptions0.errorFormat = errorFormat13;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(errorFormat13);
    }

//    @Test
//    public void test449() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test449");
//        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
//        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative3 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
//        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray4 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative3 };
//        com.google.javascript.rhino.jstype.JSType jSType5 = jSTypeRegistry2.createUnionType(jSTypeNativeArray4);
//        com.google.javascript.rhino.ErrorReporter errorReporter6 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry8 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter6, false);
//        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative9 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
//        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray10 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative9 };
//        com.google.javascript.rhino.jstype.JSType jSType11 = jSTypeRegistry8.createUnionType(jSTypeNativeArray10);
//        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node((-1));
//        com.google.javascript.rhino.jstype.FunctionType functionType14 = jSTypeRegistry2.createFunctionType(jSType11, node13);
//        com.google.javascript.rhino.ErrorReporter errorReporter15 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry17 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter15, false);
//        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative18 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
//        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray19 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative18 };
//        com.google.javascript.rhino.jstype.JSType jSType20 = jSTypeRegistry17.createUnionType(jSTypeNativeArray19);
//        com.google.javascript.rhino.ErrorReporter errorReporter21 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry23 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter21, false);
//        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative24 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
//        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray25 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative24 };
//        com.google.javascript.rhino.jstype.JSType jSType26 = jSTypeRegistry23.createUnionType(jSTypeNativeArray25);
//        com.google.javascript.rhino.Node node28 = new com.google.javascript.rhino.Node((-1));
//        com.google.javascript.rhino.jstype.FunctionType functionType29 = jSTypeRegistry17.createFunctionType(jSType26, node28);
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray30 = new com.google.javascript.rhino.jstype.JSType[] { jSType26 };
//        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList31 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
//        boolean boolean32 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList31, jSTypeArray30);
//        com.google.javascript.rhino.Node node33 = jSTypeRegistry2.createParametersWithVarArgs((java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList31);
//        jSTypeRegistry2.setLastGeneration(false);
//        com.google.javascript.rhino.jstype.ObjectType objectType36 = jSTypeRegistry2.createAnonymousObjectType();
//        boolean boolean37 = objectType36.isEmptyType();
//        java.lang.String str38 = objectType36.toDebugHashCodeString();
//        org.junit.Assert.assertTrue("'" + jSTypeNative3 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative3.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
//        org.junit.Assert.assertNotNull(jSTypeNativeArray4);
//        org.junit.Assert.assertNotNull(jSType5);
//        org.junit.Assert.assertTrue("'" + jSTypeNative9 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative9.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
//        org.junit.Assert.assertNotNull(jSTypeNativeArray10);
//        org.junit.Assert.assertNotNull(jSType11);
//        org.junit.Assert.assertNotNull(functionType14);
//        org.junit.Assert.assertTrue("'" + jSTypeNative18 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative18.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
//        org.junit.Assert.assertNotNull(jSTypeNativeArray19);
//        org.junit.Assert.assertNotNull(jSType20);
//        org.junit.Assert.assertTrue("'" + jSTypeNative24 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative24.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
//        org.junit.Assert.assertNotNull(jSTypeNativeArray25);
//        org.junit.Assert.assertNotNull(jSType26);
//        org.junit.Assert.assertNotNull(functionType29);
//        org.junit.Assert.assertNotNull(jSTypeArray30);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
//        org.junit.Assert.assertNotNull(node33);
//        org.junit.Assert.assertNotNull(objectType36);
//        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
//        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "{1350500668}" + "'", str38.equals("{1350500668}"));
//    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        int int0 = com.google.javascript.rhino.Token.THROW;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 49 + "'", int0 == 49);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        int int0 = com.google.javascript.rhino.Node.OPT_ARG_NAME;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 36 + "'", int0 == 36);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.RANGE_ERROR_TYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.RANGE_ERROR_TYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.RANGE_ERROR_TYPE));
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        com.google.javascript.rhino.FunctionNode functionNode3 = new com.google.javascript.rhino.FunctionNode("", 25, 93);
        java.lang.String str4 = functionNode3.getFunctionName();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative3 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray4 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative3 };
        com.google.javascript.rhino.jstype.JSType jSType5 = jSTypeRegistry2.createUnionType(jSTypeNativeArray4);
        com.google.javascript.rhino.ErrorReporter errorReporter6 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry8 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter6, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative9 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray10 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative9 };
        com.google.javascript.rhino.jstype.JSType jSType11 = jSTypeRegistry8.createUnionType(jSTypeNativeArray10);
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node((-1));
        com.google.javascript.rhino.jstype.FunctionType functionType14 = jSTypeRegistry2.createFunctionType(jSType11, node13);
        boolean boolean16 = functionType14.hasOwnProperty("hi!");
        com.google.javascript.rhino.ErrorReporter errorReporter17 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry19 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter17, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative20 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray21 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative20 };
        com.google.javascript.rhino.jstype.JSType jSType22 = jSTypeRegistry19.createUnionType(jSTypeNativeArray21);
        com.google.javascript.rhino.ErrorReporter errorReporter23 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry25 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter23, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative26 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray27 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative26 };
        com.google.javascript.rhino.jstype.JSType jSType28 = jSTypeRegistry25.createUnionType(jSTypeNativeArray27);
        com.google.javascript.rhino.Node node30 = new com.google.javascript.rhino.Node((-1));
        com.google.javascript.rhino.jstype.FunctionType functionType31 = jSTypeRegistry19.createFunctionType(jSType28, node30);
        boolean boolean33 = functionType31.hasOwnProperty("hi!");
        functionType14.setPrototypeBasedOn((com.google.javascript.rhino.jstype.ObjectType) functionType31);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable35 = functionType14.getCtorImplementedInterfaces();
        boolean boolean36 = functionType14.isBooleanObjectType();
        com.google.javascript.rhino.ErrorReporter errorReporter37 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry39 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter37, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative40 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray41 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative40 };
        com.google.javascript.rhino.jstype.JSType jSType42 = jSTypeRegistry39.createUnionType(jSTypeNativeArray41);
        com.google.javascript.rhino.jstype.JSType.TypePair typePair43 = functionType14.getTypesUnderShallowInequality(jSType42);
        org.junit.Assert.assertTrue("'" + jSTypeNative3 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative3.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray4);
        org.junit.Assert.assertNotNull(jSType5);
        org.junit.Assert.assertTrue("'" + jSTypeNative9 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative9.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray10);
        org.junit.Assert.assertNotNull(jSType11);
        org.junit.Assert.assertNotNull(functionType14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + jSTypeNative20 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative20.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray21);
        org.junit.Assert.assertNotNull(jSType22);
        org.junit.Assert.assertTrue("'" + jSTypeNative26 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative26.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray27);
        org.junit.Assert.assertNotNull(jSType28);
        org.junit.Assert.assertNotNull(functionType31);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(objectTypeIterable35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + jSTypeNative40 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative40.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray41);
        org.junit.Assert.assertNotNull(jSType42);
        org.junit.Assert.assertNotNull(typePair43);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        int int0 = com.google.javascript.rhino.Token.LAST_TOKEN;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 153 + "'", int0 == 153);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        com.google.javascript.rhino.Node.SideEffectFlags sideEffectFlags1 = new com.google.javascript.rhino.Node.SideEffectFlags((int) (short) 1);
        sideEffectFlags1.setReturnsTainted();
        int int3 = sideEffectFlags1.valueOf();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        int int0 = com.google.javascript.rhino.Token.RESERVED;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 123 + "'", int0 == 123);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        com.google.javascript.rhino.JSDocInfoBuilder jSDocInfoBuilder1 = new com.google.javascript.rhino.JSDocInfoBuilder(false);
        com.google.javascript.jscomp.CompilerOptions compilerOptions2 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.common.collect.Multimap<com.google.javascript.jscomp.CustomPassExecutionTime, com.google.javascript.jscomp.CompilerPass> customPassExecutionTimeMultimap3 = null;
        compilerOptions2.customPasses = customPassExecutionTimeMultimap3;
        boolean boolean5 = compilerOptions2.inlineConstantVars;
        java.lang.String str6 = compilerOptions2.syntheticBlockStartMarker;
        compilerOptions2.decomposeExpressions = false;
        boolean boolean9 = compilerOptions2.checkTypes;
        java.lang.String str10 = compilerOptions2.sourceMapOutputPath;
        boolean boolean11 = compilerOptions2.deadAssignmentElimination;
        java.lang.String[] strArray15 = new java.lang.String[] { "language version", "language version", "" };
        java.util.LinkedHashSet<java.lang.String> strSet16 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean17 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet16, strArray15);
        compilerOptions2.aliasableStrings = strSet16;
        boolean boolean19 = jSDocInfoBuilder1.recordModifies((java.util.Set<java.lang.String>) strSet16);
        boolean boolean20 = jSDocInfoBuilder1.recordImplicitCast();
        com.google.javascript.rhino.JSDocInfo jSDocInfo22 = jSDocInfoBuilder1.build("Named type with empty name component");
        boolean boolean23 = jSDocInfo22.isDefine();
        java.lang.String str24 = jSDocInfo22.toString();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(strArray15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(jSDocInfo22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "JSDocInfo" + "'", str24.equals("JSDocInfo"));
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative3 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray4 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative3 };
        com.google.javascript.rhino.jstype.JSType jSType5 = jSTypeRegistry2.createUnionType(jSTypeNativeArray4);
        com.google.javascript.rhino.ErrorReporter errorReporter6 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry8 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter6, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative9 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray10 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative9 };
        com.google.javascript.rhino.jstype.JSType jSType11 = jSTypeRegistry8.createUnionType(jSTypeNativeArray10);
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node((-1));
        com.google.javascript.rhino.jstype.FunctionType functionType14 = jSTypeRegistry2.createFunctionType(jSType11, node13);
        com.google.javascript.rhino.ErrorReporter errorReporter15 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry17 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter15, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative18 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray19 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative18 };
        com.google.javascript.rhino.jstype.JSType jSType20 = jSTypeRegistry17.createUnionType(jSTypeNativeArray19);
        com.google.javascript.rhino.ErrorReporter errorReporter21 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry23 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter21, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative24 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray25 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative24 };
        com.google.javascript.rhino.jstype.JSType jSType26 = jSTypeRegistry23.createUnionType(jSTypeNativeArray25);
        com.google.javascript.rhino.Node node28 = new com.google.javascript.rhino.Node((-1));
        com.google.javascript.rhino.jstype.FunctionType functionType29 = jSTypeRegistry17.createFunctionType(jSType26, node28);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray30 = new com.google.javascript.rhino.jstype.JSType[] { jSType26 };
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList31 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean32 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList31, jSTypeArray30);
        com.google.javascript.rhino.Node node33 = jSTypeRegistry2.createParametersWithVarArgs((java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList31);
        jSTypeRegistry2.setLastGeneration(false);
        com.google.javascript.rhino.jstype.ObjectType objectType36 = jSTypeRegistry2.createAnonymousObjectType();
        boolean boolean37 = objectType36.isEmptyType();
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention38 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.ErrorReporter errorReporter39 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry41 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter39, false);
        com.google.javascript.rhino.ErrorReporter errorReporter42 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry44 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter42, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative45 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray46 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative45 };
        com.google.javascript.rhino.jstype.JSType jSType47 = jSTypeRegistry44.createUnionType(jSTypeNativeArray46);
        com.google.javascript.rhino.ErrorReporter errorReporter48 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry50 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter48, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative51 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray52 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative51 };
        com.google.javascript.rhino.jstype.JSType jSType53 = jSTypeRegistry50.createUnionType(jSTypeNativeArray52);
        com.google.javascript.rhino.Node node55 = new com.google.javascript.rhino.Node((-1));
        com.google.javascript.rhino.jstype.FunctionType functionType56 = jSTypeRegistry44.createFunctionType(jSType53, node55);
        boolean boolean58 = functionType56.hasOwnProperty("hi!");
        com.google.javascript.rhino.jstype.ObjectType objectType59 = jSTypeRegistry41.createObjectType((com.google.javascript.rhino.jstype.ObjectType) functionType56);
        boolean boolean60 = functionType56.isCheckedUnknownType();
        java.lang.RuntimeException runtimeException62 = com.google.javascript.rhino.ScriptRuntime.undefWriteError((java.lang.Object) closureCodingConvention38, (java.lang.Object) functionType56, (java.lang.Object) 30);
        com.google.javascript.rhino.jstype.JSType.TypePair typePair63 = objectType36.getTypesUnderShallowEquality((com.google.javascript.rhino.jstype.JSType) functionType56);
        org.junit.Assert.assertTrue("'" + jSTypeNative3 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative3.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray4);
        org.junit.Assert.assertNotNull(jSType5);
        org.junit.Assert.assertTrue("'" + jSTypeNative9 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative9.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray10);
        org.junit.Assert.assertNotNull(jSType11);
        org.junit.Assert.assertNotNull(functionType14);
        org.junit.Assert.assertTrue("'" + jSTypeNative18 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative18.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray19);
        org.junit.Assert.assertNotNull(jSType20);
        org.junit.Assert.assertTrue("'" + jSTypeNative24 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative24.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray25);
        org.junit.Assert.assertNotNull(jSType26);
        org.junit.Assert.assertNotNull(functionType29);
        org.junit.Assert.assertNotNull(jSTypeArray30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNotNull(node33);
        org.junit.Assert.assertNotNull(objectType36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + jSTypeNative45 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative45.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray46);
        org.junit.Assert.assertNotNull(jSType47);
        org.junit.Assert.assertTrue("'" + jSTypeNative51 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative51.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray52);
        org.junit.Assert.assertNotNull(jSType53);
        org.junit.Assert.assertNotNull(functionType56);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(objectType59);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertNotNull(runtimeException62);
        org.junit.Assert.assertNotNull(typePair63);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy0 = com.google.javascript.jscomp.PropertyRenamingPolicy.UNSPECIFIED;
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy0 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.UNSPECIFIED + "'", propertyRenamingPolicy0.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.UNSPECIFIED));
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        com.google.javascript.rhino.JSDocInfoBuilder jSDocInfoBuilder1 = new com.google.javascript.rhino.JSDocInfoBuilder(false);
        com.google.javascript.jscomp.CompilerOptions compilerOptions2 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.common.collect.Multimap<com.google.javascript.jscomp.CustomPassExecutionTime, com.google.javascript.jscomp.CompilerPass> customPassExecutionTimeMultimap3 = null;
        compilerOptions2.customPasses = customPassExecutionTimeMultimap3;
        boolean boolean5 = compilerOptions2.inlineConstantVars;
        java.lang.String str6 = compilerOptions2.syntheticBlockStartMarker;
        compilerOptions2.decomposeExpressions = false;
        boolean boolean9 = compilerOptions2.checkTypes;
        java.lang.String str10 = compilerOptions2.sourceMapOutputPath;
        boolean boolean11 = compilerOptions2.deadAssignmentElimination;
        java.lang.String[] strArray15 = new java.lang.String[] { "language version", "language version", "" };
        java.util.LinkedHashSet<java.lang.String> strSet16 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean17 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet16, strArray15);
        compilerOptions2.aliasableStrings = strSet16;
        boolean boolean19 = jSDocInfoBuilder1.recordModifies((java.util.Set<java.lang.String>) strSet16);
        boolean boolean20 = jSDocInfoBuilder1.recordImplicitCast();
        com.google.javascript.rhino.JSDocInfo jSDocInfo22 = jSDocInfoBuilder1.build("Named type with empty name component");
        com.google.javascript.rhino.JSTypeExpression jSTypeExpression23 = jSDocInfo22.getType();
        java.lang.String str24 = jSDocInfo22.getTemplateTypeName();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(strArray15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(jSDocInfo22);
        org.junit.Assert.assertNull(jSTypeExpression23);
        org.junit.Assert.assertNull(str24);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        com.google.javascript.jscomp.MessageFormatter messageFormatter0 = null;
        java.util.logging.Logger logger1 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager2 = new com.google.javascript.jscomp.LoggerErrorManager(messageFormatter0, logger1);
        com.google.javascript.jscomp.Compiler compiler3 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager2);
        try {
            compiler3.parse();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        int int0 = com.google.javascript.rhino.Token.BITNOT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 27 + "'", int0 == 27);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative3 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray4 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative3 };
        com.google.javascript.rhino.jstype.JSType jSType5 = jSTypeRegistry2.createUnionType(jSTypeNativeArray4);
        com.google.javascript.rhino.ErrorReporter errorReporter6 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry8 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter6, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative9 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray10 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative9 };
        com.google.javascript.rhino.jstype.JSType jSType11 = jSTypeRegistry8.createUnionType(jSTypeNativeArray10);
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node((-1));
        com.google.javascript.rhino.jstype.FunctionType functionType14 = jSTypeRegistry2.createFunctionType(jSType11, node13);
        boolean boolean16 = functionType14.hasOwnProperty("hi!");
        com.google.javascript.rhino.jstype.FunctionPrototypeType functionPrototypeType17 = null;
        boolean boolean18 = functionType14.setPrototype(functionPrototypeType17);
        java.lang.String str19 = functionType14.getDisplayName();
        com.google.javascript.rhino.Node node20 = functionType14.getSource();
        org.junit.Assert.assertTrue("'" + jSTypeNative3 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative3.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray4);
        org.junit.Assert.assertNotNull(jSType5);
        org.junit.Assert.assertTrue("'" + jSTypeNative9 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative9.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray10);
        org.junit.Assert.assertNotNull(jSType11);
        org.junit.Assert.assertNotNull(functionType14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNull(str19);
        org.junit.Assert.assertNull(node20);
    }

//    @Test
//    public void test465() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test465");
//        try {
//            com.google.javascript.rhino.EvaluatorException evaluatorException1 = com.google.javascript.rhino.Context.reportRuntimeError("");
//            org.junit.Assert.fail("Expected exception of type com.google.javascript.rhino.EvaluatorException; message: ");
//        } catch (com.google.javascript.rhino.EvaluatorException e) {
//        }
//    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative3 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray4 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative3 };
        com.google.javascript.rhino.jstype.JSType jSType5 = jSTypeRegistry2.createUnionType(jSTypeNativeArray4);
        com.google.javascript.rhino.ErrorReporter errorReporter6 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry8 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter6, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative9 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray10 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative9 };
        com.google.javascript.rhino.jstype.JSType jSType11 = jSTypeRegistry8.createUnionType(jSTypeNativeArray10);
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node((-1));
        com.google.javascript.rhino.jstype.FunctionType functionType14 = jSTypeRegistry2.createFunctionType(jSType11, node13);
        boolean boolean16 = functionType14.hasOwnProperty("hi!");
        com.google.javascript.rhino.ErrorReporter errorReporter17 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry19 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter17, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative20 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray21 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative20 };
        com.google.javascript.rhino.jstype.JSType jSType22 = jSTypeRegistry19.createUnionType(jSTypeNativeArray21);
        com.google.javascript.rhino.ErrorReporter errorReporter23 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry25 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter23, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative26 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray27 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative26 };
        com.google.javascript.rhino.jstype.JSType jSType28 = jSTypeRegistry25.createUnionType(jSTypeNativeArray27);
        com.google.javascript.rhino.Node node30 = new com.google.javascript.rhino.Node((-1));
        com.google.javascript.rhino.jstype.FunctionType functionType31 = jSTypeRegistry19.createFunctionType(jSType28, node30);
        boolean boolean33 = functionType31.hasOwnProperty("hi!");
        functionType14.setPrototypeBasedOn((com.google.javascript.rhino.jstype.ObjectType) functionType31);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable35 = functionType14.getCtorImplementedInterfaces();
        com.google.javascript.rhino.ErrorReporter errorReporter36 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry38 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter36, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative39 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray40 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative39 };
        com.google.javascript.rhino.jstype.JSType jSType41 = jSTypeRegistry38.createUnionType(jSTypeNativeArray40);
        com.google.javascript.rhino.ErrorReporter errorReporter42 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry44 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter42, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative45 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray46 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative45 };
        com.google.javascript.rhino.jstype.JSType jSType47 = jSTypeRegistry44.createUnionType(jSTypeNativeArray46);
        com.google.javascript.rhino.Node node49 = new com.google.javascript.rhino.Node((-1));
        com.google.javascript.rhino.jstype.FunctionType functionType50 = jSTypeRegistry38.createFunctionType(jSType47, node49);
        boolean boolean52 = functionType50.hasOwnProperty("hi!");
        com.google.javascript.rhino.ErrorReporter errorReporter53 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry55 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter53, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative56 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray57 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative56 };
        com.google.javascript.rhino.jstype.JSType jSType58 = jSTypeRegistry55.createUnionType(jSTypeNativeArray57);
        com.google.javascript.rhino.ErrorReporter errorReporter59 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry61 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter59, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative62 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray63 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative62 };
        com.google.javascript.rhino.jstype.JSType jSType64 = jSTypeRegistry61.createUnionType(jSTypeNativeArray63);
        com.google.javascript.rhino.Node node66 = new com.google.javascript.rhino.Node((-1));
        com.google.javascript.rhino.jstype.FunctionType functionType67 = jSTypeRegistry55.createFunctionType(jSType64, node66);
        boolean boolean69 = functionType67.hasOwnProperty("hi!");
        functionType50.setPrototypeBasedOn((com.google.javascript.rhino.jstype.ObjectType) functionType67);
        com.google.javascript.rhino.jstype.JSType jSType71 = functionType14.getLeastSupertype((com.google.javascript.rhino.jstype.JSType) functionType50);
        com.google.javascript.rhino.jstype.ObjectType objectType72 = functionType14.getImplicitPrototype();
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable73 = functionType14.getParameters();
        com.google.javascript.rhino.jstype.BooleanLiteralSet booleanLiteralSet74 = functionType14.getPossibleToBooleanOutcomes();
        com.google.javascript.rhino.ErrorReporter errorReporter76 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry78 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter76, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative79 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray80 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative79 };
        com.google.javascript.rhino.jstype.JSType jSType81 = jSTypeRegistry78.createUnionType(jSTypeNativeArray80);
        com.google.javascript.rhino.ErrorReporter errorReporter82 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry84 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter82, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative85 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray86 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative85 };
        com.google.javascript.rhino.jstype.JSType jSType87 = jSTypeRegistry84.createUnionType(jSTypeNativeArray86);
        com.google.javascript.rhino.Node node89 = new com.google.javascript.rhino.Node((-1));
        com.google.javascript.rhino.jstype.FunctionType functionType90 = jSTypeRegistry78.createFunctionType(jSType87, node89);
        boolean boolean92 = functionType90.hasOwnProperty("hi!");
        com.google.javascript.rhino.jstype.FunctionPrototypeType functionPrototypeType93 = null;
        boolean boolean94 = functionType90.setPrototype(functionPrototypeType93);
        java.lang.String str95 = functionType90.getDisplayName();
        boolean boolean96 = functionType90.isRecordType();
        boolean boolean98 = functionType14.defineDeclaredProperty("{1350500668}", (com.google.javascript.rhino.jstype.JSType) functionType90, true);
        org.junit.Assert.assertTrue("'" + jSTypeNative3 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative3.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray4);
        org.junit.Assert.assertNotNull(jSType5);
        org.junit.Assert.assertTrue("'" + jSTypeNative9 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative9.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray10);
        org.junit.Assert.assertNotNull(jSType11);
        org.junit.Assert.assertNotNull(functionType14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + jSTypeNative20 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative20.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray21);
        org.junit.Assert.assertNotNull(jSType22);
        org.junit.Assert.assertTrue("'" + jSTypeNative26 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative26.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray27);
        org.junit.Assert.assertNotNull(jSType28);
        org.junit.Assert.assertNotNull(functionType31);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(objectTypeIterable35);
        org.junit.Assert.assertTrue("'" + jSTypeNative39 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative39.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray40);
        org.junit.Assert.assertNotNull(jSType41);
        org.junit.Assert.assertTrue("'" + jSTypeNative45 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative45.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray46);
        org.junit.Assert.assertNotNull(jSType47);
        org.junit.Assert.assertNotNull(functionType50);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertTrue("'" + jSTypeNative56 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative56.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray57);
        org.junit.Assert.assertNotNull(jSType58);
        org.junit.Assert.assertTrue("'" + jSTypeNative62 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative62.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray63);
        org.junit.Assert.assertNotNull(jSType64);
        org.junit.Assert.assertNotNull(functionType67);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
        org.junit.Assert.assertNotNull(jSType71);
        org.junit.Assert.assertNotNull(objectType72);
        org.junit.Assert.assertNotNull(nodeIterable73);
        org.junit.Assert.assertTrue("'" + booleanLiteralSet74 + "' != '" + com.google.javascript.rhino.jstype.BooleanLiteralSet.TRUE + "'", booleanLiteralSet74.equals(com.google.javascript.rhino.jstype.BooleanLiteralSet.TRUE));
        org.junit.Assert.assertTrue("'" + jSTypeNative79 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative79.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray80);
        org.junit.Assert.assertNotNull(jSType81);
        org.junit.Assert.assertTrue("'" + jSTypeNative85 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative85.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray86);
        org.junit.Assert.assertNotNull(jSType87);
        org.junit.Assert.assertNotNull(functionType90);
        org.junit.Assert.assertTrue("'" + boolean92 + "' != '" + false + "'", boolean92 == false);
        org.junit.Assert.assertTrue("'" + boolean94 + "' != '" + false + "'", boolean94 == false);
        org.junit.Assert.assertNull(str95);
        org.junit.Assert.assertTrue("'" + boolean96 + "' != '" + false + "'", boolean96 == false);
        org.junit.Assert.assertTrue("'" + boolean98 + "' != '" + true + "'", boolean98 == true);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        com.google.javascript.rhino.JSDocInfoBuilder jSDocInfoBuilder1 = new com.google.javascript.rhino.JSDocInfoBuilder(true);
        boolean boolean3 = jSDocInfoBuilder1.recordBlockDescription("Fixed point computation not halting");
        jSDocInfoBuilder1.markText("Named type with empty name component", 19, 0, 20, 302);
        jSDocInfoBuilder1.markText("function (): function (new:TypeError, *, *, *): TypeError", (int) (byte) 0, 108, 44, 27);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        com.google.javascript.rhino.JSDocInfoBuilder jSDocInfoBuilder1 = new com.google.javascript.rhino.JSDocInfoBuilder(true);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode5 = new com.google.javascript.rhino.ScriptOrFnNode(11, 130, (int) (short) 100);
        int int6 = scriptOrFnNode5.getEncodedSourceStart();
        com.google.javascript.rhino.JSTypeExpression jSTypeExpression8 = new com.google.javascript.rhino.JSTypeExpression((com.google.javascript.rhino.Node) scriptOrFnNode5, "Named type with empty name component");
        boolean boolean9 = jSDocInfoBuilder1.recordThrowType(jSTypeExpression8);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode14 = new com.google.javascript.rhino.ScriptOrFnNode(11, 130, (int) (short) 100);
        int int15 = scriptOrFnNode14.getEncodedSourceStart();
        com.google.javascript.rhino.JSTypeExpression jSTypeExpression17 = new com.google.javascript.rhino.JSTypeExpression((com.google.javascript.rhino.Node) scriptOrFnNode14, "Named type with empty name component");
        boolean boolean18 = jSDocInfoBuilder1.recordParameter("EOF", jSTypeExpression17);
        com.google.javascript.rhino.JSDocInfoBuilder jSDocInfoBuilder20 = new com.google.javascript.rhino.JSDocInfoBuilder(true);
        boolean boolean22 = jSDocInfoBuilder20.recordBlockDescription("Fixed point computation not halting");
        jSDocInfoBuilder20.markText("Named type with empty name component", 19, 0, 20, 302);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode32 = new com.google.javascript.rhino.ScriptOrFnNode(11, 130, (int) (short) 100);
        int int33 = scriptOrFnNode32.getEncodedSourceStart();
        com.google.javascript.rhino.JSTypeExpression jSTypeExpression35 = new com.google.javascript.rhino.JSTypeExpression((com.google.javascript.rhino.Node) scriptOrFnNode32, "Named type with empty name component");
        boolean boolean37 = jSDocInfoBuilder20.recordThrowDescription(jSTypeExpression35, "Named type with empty name component");
        boolean boolean39 = jSDocInfoBuilder1.recordThrowDescription(jSTypeExpression35, "STRING hi!");
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.common.collect.Multimap<com.google.javascript.jscomp.CustomPassExecutionTime, com.google.javascript.jscomp.CompilerPass> customPassExecutionTimeMultimap1 = null;
        compilerOptions0.customPasses = customPassExecutionTimeMultimap1;
        compilerOptions0.devirtualizePrototypeMethods = true;
        compilerOptions0.checkDuplicateMessages = false;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy7 = null;
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy8 = null;
        compilerOptions0.setRenamingPolicy(variableRenamingPolicy7, propertyRenamingPolicy8);
        com.google.javascript.jscomp.CheckLevel checkLevel10 = compilerOptions0.checkUndefinedProperties;
        compilerOptions0.disableRuntimeTypeCheck();
        org.junit.Assert.assertTrue("'" + checkLevel10 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel10.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.Scope scope2 = compiler1.getTopScope();
        try {
            boolean boolean3 = compiler1.acceptEcmaScript5();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(scope2);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        com.google.javascript.rhino.Node node1 = new com.google.javascript.rhino.Node((-1));
        node1.putIntProp(33, 130);
        com.google.javascript.rhino.jstype.JSType jSType5 = node1.getJSType();
        node1.setIsSyntheticBlock(true);
        boolean boolean8 = node1.hasSideEffects();
        org.junit.Assert.assertNull(jSType5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        int int0 = com.google.javascript.rhino.Token.SETPROP_OP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 135 + "'", int0 == 135);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        com.google.javascript.rhino.JSDocInfoBuilder jSDocInfoBuilder1 = new com.google.javascript.rhino.JSDocInfoBuilder(true);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode5 = new com.google.javascript.rhino.ScriptOrFnNode(11, 130, (int) (short) 100);
        int int6 = scriptOrFnNode5.getEncodedSourceStart();
        com.google.javascript.rhino.JSTypeExpression jSTypeExpression8 = new com.google.javascript.rhino.JSTypeExpression((com.google.javascript.rhino.Node) scriptOrFnNode5, "Named type with empty name component");
        boolean boolean9 = jSDocInfoBuilder1.recordBaseType(jSTypeExpression8);
        boolean boolean10 = jSDocInfoBuilder1.recordNoCompile();
        boolean boolean11 = jSDocInfoBuilder1.recordNoShadow();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative3 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray4 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative3 };
        com.google.javascript.rhino.jstype.JSType jSType5 = jSTypeRegistry2.createUnionType(jSTypeNativeArray4);
        com.google.javascript.rhino.ErrorReporter errorReporter6 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry8 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter6, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative9 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray10 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative9 };
        com.google.javascript.rhino.jstype.JSType jSType11 = jSTypeRegistry8.createUnionType(jSTypeNativeArray10);
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node((-1));
        com.google.javascript.rhino.jstype.FunctionType functionType14 = jSTypeRegistry2.createFunctionType(jSType11, node13);
        boolean boolean16 = functionType14.hasOwnProperty("hi!");
        com.google.javascript.rhino.ErrorReporter errorReporter17 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry19 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter17, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative20 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray21 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative20 };
        com.google.javascript.rhino.jstype.JSType jSType22 = jSTypeRegistry19.createUnionType(jSTypeNativeArray21);
        com.google.javascript.rhino.ErrorReporter errorReporter23 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry25 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter23, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative26 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray27 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative26 };
        com.google.javascript.rhino.jstype.JSType jSType28 = jSTypeRegistry25.createUnionType(jSTypeNativeArray27);
        com.google.javascript.rhino.Node node30 = new com.google.javascript.rhino.Node((-1));
        com.google.javascript.rhino.jstype.FunctionType functionType31 = jSTypeRegistry19.createFunctionType(jSType28, node30);
        boolean boolean33 = functionType31.hasOwnProperty("hi!");
        functionType14.setPrototypeBasedOn((com.google.javascript.rhino.jstype.ObjectType) functionType31);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable35 = functionType14.getCtorImplementedInterfaces();
        com.google.javascript.rhino.ErrorReporter errorReporter36 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry38 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter36, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative39 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray40 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative39 };
        com.google.javascript.rhino.jstype.JSType jSType41 = jSTypeRegistry38.createUnionType(jSTypeNativeArray40);
        com.google.javascript.rhino.ErrorReporter errorReporter42 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry44 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter42, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative45 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray46 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative45 };
        com.google.javascript.rhino.jstype.JSType jSType47 = jSTypeRegistry44.createUnionType(jSTypeNativeArray46);
        com.google.javascript.rhino.Node node49 = new com.google.javascript.rhino.Node((-1));
        com.google.javascript.rhino.jstype.FunctionType functionType50 = jSTypeRegistry38.createFunctionType(jSType47, node49);
        boolean boolean52 = functionType50.hasOwnProperty("hi!");
        com.google.javascript.rhino.ErrorReporter errorReporter53 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry55 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter53, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative56 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray57 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative56 };
        com.google.javascript.rhino.jstype.JSType jSType58 = jSTypeRegistry55.createUnionType(jSTypeNativeArray57);
        com.google.javascript.rhino.ErrorReporter errorReporter59 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry61 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter59, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative62 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray63 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative62 };
        com.google.javascript.rhino.jstype.JSType jSType64 = jSTypeRegistry61.createUnionType(jSTypeNativeArray63);
        com.google.javascript.rhino.Node node66 = new com.google.javascript.rhino.Node((-1));
        com.google.javascript.rhino.jstype.FunctionType functionType67 = jSTypeRegistry55.createFunctionType(jSType64, node66);
        boolean boolean69 = functionType67.hasOwnProperty("hi!");
        functionType50.setPrototypeBasedOn((com.google.javascript.rhino.jstype.ObjectType) functionType67);
        com.google.javascript.rhino.jstype.JSType jSType71 = functionType14.getLeastSupertype((com.google.javascript.rhino.jstype.JSType) functionType50);
        com.google.javascript.rhino.jstype.ObjectType objectType72 = functionType14.getImplicitPrototype();
        boolean boolean74 = functionType14.hasOwnProperty("hi!");
        int int75 = functionType14.getPropertiesCount();
        com.google.javascript.rhino.JSDocInfo jSDocInfo76 = functionType14.getJSDocInfo();
        boolean boolean77 = functionType14.matchesStringContext();
        org.junit.Assert.assertTrue("'" + jSTypeNative3 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative3.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray4);
        org.junit.Assert.assertNotNull(jSType5);
        org.junit.Assert.assertTrue("'" + jSTypeNative9 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative9.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray10);
        org.junit.Assert.assertNotNull(jSType11);
        org.junit.Assert.assertNotNull(functionType14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + jSTypeNative20 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative20.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray21);
        org.junit.Assert.assertNotNull(jSType22);
        org.junit.Assert.assertTrue("'" + jSTypeNative26 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative26.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray27);
        org.junit.Assert.assertNotNull(jSType28);
        org.junit.Assert.assertNotNull(functionType31);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(objectTypeIterable35);
        org.junit.Assert.assertTrue("'" + jSTypeNative39 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative39.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray40);
        org.junit.Assert.assertNotNull(jSType41);
        org.junit.Assert.assertTrue("'" + jSTypeNative45 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative45.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray46);
        org.junit.Assert.assertNotNull(jSType47);
        org.junit.Assert.assertNotNull(functionType50);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertTrue("'" + jSTypeNative56 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative56.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray57);
        org.junit.Assert.assertNotNull(jSType58);
        org.junit.Assert.assertTrue("'" + jSTypeNative62 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative62.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray63);
        org.junit.Assert.assertNotNull(jSType64);
        org.junit.Assert.assertNotNull(functionType67);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
        org.junit.Assert.assertNotNull(jSType71);
        org.junit.Assert.assertNotNull(objectType72);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
        org.junit.Assert.assertTrue("'" + int75 + "' != '" + 0 + "'", int75 == 0);
        org.junit.Assert.assertNull(jSDocInfo76);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.checkMissingGetCssNameLevel;
        java.util.Set<java.lang.String> strSet2 = compilerOptions0.stripNamePrefixes;
        com.google.javascript.jscomp.CodingConvention codingConvention3 = compilerOptions0.getCodingConvention();
        boolean boolean4 = compilerOptions0.optimizeParameters;
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(strSet2);
        org.junit.Assert.assertNull(codingConvention3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative3 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray4 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative3 };
        com.google.javascript.rhino.jstype.JSType jSType5 = jSTypeRegistry2.createUnionType(jSTypeNativeArray4);
        com.google.javascript.rhino.ErrorReporter errorReporter6 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry8 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter6, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative9 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray10 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative9 };
        com.google.javascript.rhino.jstype.JSType jSType11 = jSTypeRegistry8.createUnionType(jSTypeNativeArray10);
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node((-1));
        com.google.javascript.rhino.jstype.FunctionType functionType14 = jSTypeRegistry2.createFunctionType(jSType11, node13);
        int int15 = node13.getLineno();
        boolean boolean16 = node13.isQualifiedName();
        boolean boolean17 = node13.isQuotedString();
        org.junit.Assert.assertTrue("'" + jSTypeNative3 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative3.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray4);
        org.junit.Assert.assertNotNull(jSType5);
        org.junit.Assert.assertTrue("'" + jSTypeNative9 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative9.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray10);
        org.junit.Assert.assertNotNull(jSType11);
        org.junit.Assert.assertNotNull(functionType14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.CHECK_VARIABLES;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        int int0 = com.google.javascript.rhino.Node.FREE_CALL;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 49 + "'", int0 == 49);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative3 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray4 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative3 };
        com.google.javascript.rhino.jstype.JSType jSType5 = jSTypeRegistry2.createUnionType(jSTypeNativeArray4);
        com.google.javascript.rhino.ErrorReporter errorReporter6 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry8 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter6, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative9 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray10 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative9 };
        com.google.javascript.rhino.jstype.JSType jSType11 = jSTypeRegistry8.createUnionType(jSTypeNativeArray10);
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node((-1));
        com.google.javascript.rhino.jstype.FunctionType functionType14 = jSTypeRegistry2.createFunctionType(jSType11, node13);
        boolean boolean16 = functionType14.hasOwnProperty("hi!");
        com.google.javascript.rhino.ErrorReporter errorReporter17 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry19 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter17, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative20 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray21 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative20 };
        com.google.javascript.rhino.jstype.JSType jSType22 = jSTypeRegistry19.createUnionType(jSTypeNativeArray21);
        com.google.javascript.rhino.ErrorReporter errorReporter23 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry25 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter23, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative26 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray27 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative26 };
        com.google.javascript.rhino.jstype.JSType jSType28 = jSTypeRegistry25.createUnionType(jSTypeNativeArray27);
        com.google.javascript.rhino.Node node30 = new com.google.javascript.rhino.Node((-1));
        com.google.javascript.rhino.jstype.FunctionType functionType31 = jSTypeRegistry19.createFunctionType(jSType28, node30);
        boolean boolean33 = functionType31.hasOwnProperty("hi!");
        functionType14.setPrototypeBasedOn((com.google.javascript.rhino.jstype.ObjectType) functionType31);
        com.google.javascript.rhino.ErrorReporter errorReporter35 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry37 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter35, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative38 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray39 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative38 };
        com.google.javascript.rhino.jstype.JSType jSType40 = jSTypeRegistry37.createUnionType(jSTypeNativeArray39);
        com.google.javascript.rhino.ErrorReporter errorReporter41 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry43 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter41, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative44 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray45 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative44 };
        com.google.javascript.rhino.jstype.JSType jSType46 = jSTypeRegistry43.createUnionType(jSTypeNativeArray45);
        com.google.javascript.rhino.Node node48 = new com.google.javascript.rhino.Node((-1));
        com.google.javascript.rhino.jstype.FunctionType functionType49 = jSTypeRegistry37.createFunctionType(jSType46, node48);
        boolean boolean51 = functionType49.hasOwnProperty("hi!");
        com.google.javascript.rhino.ErrorReporter errorReporter52 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry54 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter52, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative55 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray56 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative55 };
        com.google.javascript.rhino.jstype.JSType jSType57 = jSTypeRegistry54.createUnionType(jSTypeNativeArray56);
        com.google.javascript.rhino.ErrorReporter errorReporter58 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry60 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter58, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative61 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray62 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative61 };
        com.google.javascript.rhino.jstype.JSType jSType63 = jSTypeRegistry60.createUnionType(jSTypeNativeArray62);
        com.google.javascript.rhino.Node node65 = new com.google.javascript.rhino.Node((-1));
        com.google.javascript.rhino.jstype.FunctionType functionType66 = jSTypeRegistry54.createFunctionType(jSType63, node65);
        boolean boolean68 = functionType66.hasOwnProperty("hi!");
        functionType49.setPrototypeBasedOn((com.google.javascript.rhino.jstype.ObjectType) functionType66);
        boolean boolean70 = functionType14.hasEqualCallType(functionType66);
        org.junit.Assert.assertTrue("'" + jSTypeNative3 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative3.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray4);
        org.junit.Assert.assertNotNull(jSType5);
        org.junit.Assert.assertTrue("'" + jSTypeNative9 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative9.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray10);
        org.junit.Assert.assertNotNull(jSType11);
        org.junit.Assert.assertNotNull(functionType14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + jSTypeNative20 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative20.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray21);
        org.junit.Assert.assertNotNull(jSType22);
        org.junit.Assert.assertTrue("'" + jSTypeNative26 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative26.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray27);
        org.junit.Assert.assertNotNull(jSType28);
        org.junit.Assert.assertNotNull(functionType31);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + jSTypeNative38 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative38.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray39);
        org.junit.Assert.assertNotNull(jSType40);
        org.junit.Assert.assertTrue("'" + jSTypeNative44 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative44.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray45);
        org.junit.Assert.assertNotNull(jSType46);
        org.junit.Assert.assertNotNull(functionType49);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertTrue("'" + jSTypeNative55 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative55.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray56);
        org.junit.Assert.assertNotNull(jSType57);
        org.junit.Assert.assertTrue("'" + jSTypeNative61 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative61.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray62);
        org.junit.Assert.assertNotNull(jSType63);
        org.junit.Assert.assertNotNull(functionType66);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention0 = new com.google.javascript.jscomp.DefaultCodingConvention();
        boolean boolean3 = defaultCodingConvention0.isExported("JSDocInfo", true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.common.collect.Multimap<com.google.javascript.jscomp.CustomPassExecutionTime, com.google.javascript.jscomp.CompilerPass> customPassExecutionTimeMultimap1 = null;
        compilerOptions0.customPasses = customPassExecutionTimeMultimap1;
        boolean boolean3 = compilerOptions0.inlineConstantVars;
        java.lang.String str4 = compilerOptions0.syntheticBlockStartMarker;
        compilerOptions0.decomposeExpressions = false;
        boolean boolean7 = compilerOptions0.checkTypes;
        java.lang.String str8 = compilerOptions0.sourceMapOutputPath;
        com.google.javascript.jscomp.CheckLevel checkLevel9 = compilerOptions0.brokenClosureRequiresLevel;
        com.google.javascript.jscomp.CompilerOptions compilerOptions10 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean11 = compilerOptions10.disambiguateProperties;
        boolean boolean12 = compilerOptions10.isExternExportsEnabled();
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup13 = com.google.javascript.jscomp.DiagnosticGroups.CHECK_TYPES;
        com.google.javascript.jscomp.CompilerOptions compilerOptions14 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel15 = compilerOptions14.checkMissingGetCssNameLevel;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard16 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup13, checkLevel15);
        compilerOptions10.checkProvides = checkLevel15;
        boolean boolean18 = compilerOptions10.aliasAllStrings;
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup19 = com.google.javascript.jscomp.DiagnosticGroups.CHECK_TYPES;
        com.google.javascript.jscomp.CompilerOptions compilerOptions20 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean21 = compilerOptions20.disambiguateProperties;
        boolean boolean22 = compilerOptions20.isExternExportsEnabled();
        com.google.javascript.jscomp.CheckLevel checkLevel23 = compilerOptions20.checkMethods;
        compilerOptions10.setWarningLevel(diagnosticGroup19, checkLevel23);
        compilerOptions0.reportMissingOverride = checkLevel23;
        com.google.javascript.jscomp.CompilerOptions compilerOptions26 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.common.collect.Multimap<com.google.javascript.jscomp.CustomPassExecutionTime, com.google.javascript.jscomp.CompilerPass> customPassExecutionTimeMultimap27 = null;
        compilerOptions26.customPasses = customPassExecutionTimeMultimap27;
        compilerOptions26.devirtualizePrototypeMethods = true;
        compilerOptions26.checkDuplicateMessages = false;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy33 = null;
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy34 = null;
        compilerOptions26.setRenamingPolicy(variableRenamingPolicy33, propertyRenamingPolicy34);
        com.google.javascript.jscomp.CheckLevel checkLevel36 = compilerOptions26.checkUndefinedProperties;
        compilerOptions0.checkRequires = checkLevel36;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertTrue("'" + checkLevel9 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel9.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(diagnosticGroup13);
        org.junit.Assert.assertTrue("'" + checkLevel15 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel15.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(diagnosticGroup19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + checkLevel23 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel23.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + checkLevel36 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel36.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_NUMBER_STRING;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_NUMBER_STRING + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_NUMBER_STRING));
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromCode("EOF", "language version");
        java.lang.String str3 = jSSourceFile2.getCode();
        org.junit.Assert.assertNotNull(jSSourceFile2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "language version" + "'", str3.equals("language version"));
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.removeUnusedPrototypeProperties;
        compilerOptions0.removeEmptyFunctions = true;
        compilerOptions0.removeUnusedVars = false;
        compilerOptions0.setDefineToNumberLiteral("", 21);
        compilerOptions0.markNoSideEffectCalls = true;
        compilerOptions0.inlineFunctions = false;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.common.collect.Multimap<com.google.javascript.jscomp.CustomPassExecutionTime, com.google.javascript.jscomp.CompilerPass> customPassExecutionTimeMultimap1 = null;
        compilerOptions0.customPasses = customPassExecutionTimeMultimap1;
        boolean boolean3 = compilerOptions0.inlineConstantVars;
        java.lang.String str4 = compilerOptions0.syntheticBlockStartMarker;
        compilerOptions0.decomposeExpressions = false;
        boolean boolean7 = compilerOptions0.checkTypes;
        java.lang.String str8 = compilerOptions0.sourceMapOutputPath;
        compilerOptions0.allowLegacyJsMessages = true;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(str8);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        int int0 = com.google.javascript.rhino.Token.OBJECTLIT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 64 + "'", int0 == 64);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.ErrorReporter errorReporter3 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter3, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative6 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray7 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative6 };
        com.google.javascript.rhino.jstype.JSType jSType8 = jSTypeRegistry5.createUnionType(jSTypeNativeArray7);
        com.google.javascript.rhino.ErrorReporter errorReporter9 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry11 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter9, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative12 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray13 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative12 };
        com.google.javascript.rhino.jstype.JSType jSType14 = jSTypeRegistry11.createUnionType(jSTypeNativeArray13);
        com.google.javascript.rhino.Node node16 = new com.google.javascript.rhino.Node((-1));
        com.google.javascript.rhino.jstype.FunctionType functionType17 = jSTypeRegistry5.createFunctionType(jSType14, node16);
        com.google.javascript.rhino.Node node18 = new com.google.javascript.rhino.Node((int) ' ', node16);
        com.google.javascript.rhino.Node node19 = new com.google.javascript.rhino.Node((int) ' ', node18);
        java.lang.String str20 = closureCodingConvention0.getSingletonGetterClassName(node18);
        com.google.javascript.rhino.Node node24 = com.google.javascript.rhino.Node.newString("EOF", 93, 28);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode28 = new com.google.javascript.rhino.ScriptOrFnNode(11, 130, (int) (short) 100);
        int int29 = scriptOrFnNode28.getEncodedSourceStart();
        boolean boolean31 = scriptOrFnNode28.addConst("hi!");
        java.lang.String str32 = closureCodingConvention0.extractClassNameIfProvide(node24, (com.google.javascript.rhino.Node) scriptOrFnNode28);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode36 = new com.google.javascript.rhino.ScriptOrFnNode(11, 130, (int) (short) 100);
        int int39 = scriptOrFnNode36.addRegexp("language version", "hi!");
        int int40 = scriptOrFnNode36.getEndLineno();
        boolean boolean41 = closureCodingConvention0.isVarArgsParameter((com.google.javascript.rhino.Node) scriptOrFnNode36);
        com.google.javascript.rhino.ErrorReporter errorReporter42 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry44 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter42, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative45 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray46 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative45 };
        com.google.javascript.rhino.jstype.JSType jSType47 = jSTypeRegistry44.createUnionType(jSTypeNativeArray46);
        com.google.javascript.rhino.jstype.JSType jSType52 = jSTypeRegistry44.createNamedType("EOF", "STRING hi!", 73, 100);
        scriptOrFnNode36.setCompilerData((java.lang.Object) "STRING hi!");
        org.junit.Assert.assertTrue("'" + jSTypeNative6 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative6.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray7);
        org.junit.Assert.assertNotNull(jSType8);
        org.junit.Assert.assertTrue("'" + jSTypeNative12 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative12.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray13);
        org.junit.Assert.assertNotNull(jSType14);
        org.junit.Assert.assertNotNull(functionType17);
        org.junit.Assert.assertNull(str20);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertNull(str32);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + (-1) + "'", int40 == (-1));
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + jSTypeNative45 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative45.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray46);
        org.junit.Assert.assertNotNull(jSType47);
        org.junit.Assert.assertNotNull(jSType52);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        int int0 = com.google.javascript.rhino.Token.EQUALS;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 307 + "'", int0 == 307);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        com.google.javascript.rhino.Node node1 = new com.google.javascript.rhino.Node((-1));
        node1.putIntProp(33, 130);
        com.google.javascript.rhino.jstype.JSType jSType5 = node1.getJSType();
        node1.setIsSyntheticBlock(true);
        com.google.javascript.rhino.Node node8 = node1.getNext();
        boolean boolean9 = node1.isOnlyModifiesThisCall();
        org.junit.Assert.assertNull(jSType5);
        org.junit.Assert.assertNull(node8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newString("hi!");
        java.lang.String str2 = node1.toString();
        com.google.javascript.rhino.ErrorReporter errorReporter4 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry6 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter4, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative7 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray8 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative7 };
        com.google.javascript.rhino.jstype.JSType jSType9 = jSTypeRegistry6.createUnionType(jSTypeNativeArray8);
        com.google.javascript.rhino.ErrorReporter errorReporter10 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry12 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter10, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative13 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray14 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative13 };
        com.google.javascript.rhino.jstype.JSType jSType15 = jSTypeRegistry12.createUnionType(jSTypeNativeArray14);
        com.google.javascript.rhino.Node node17 = new com.google.javascript.rhino.Node((-1));
        com.google.javascript.rhino.jstype.FunctionType functionType18 = jSTypeRegistry6.createFunctionType(jSType15, node17);
        com.google.javascript.rhino.Node node19 = new com.google.javascript.rhino.Node((int) ' ', node17);
        boolean boolean20 = node19.hasSideEffects();
        boolean boolean21 = node1.hasChild(node19);
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "STRING hi!" + "'", str2.equals("STRING hi!"));
        org.junit.Assert.assertTrue("'" + jSTypeNative7 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative7.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray8);
        org.junit.Assert.assertNotNull(jSType9);
        org.junit.Assert.assertTrue("'" + jSTypeNative13 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative13.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray14);
        org.junit.Assert.assertNotNull(jSType15);
        org.junit.Assert.assertNotNull(functionType18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        int int0 = com.google.javascript.rhino.Token.DOT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 104 + "'", int0 == 104);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.disambiguateProperties;
        compilerOptions0.removeUnusedPrototypeProperties = true;
        boolean boolean4 = compilerOptions0.optimizeCalls;
        boolean boolean5 = compilerOptions0.aliasAllStrings;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        com.google.javascript.rhino.JSDocInfo.Visibility visibility0 = com.google.javascript.rhino.JSDocInfo.Visibility.PUBLIC;
        org.junit.Assert.assertTrue("'" + visibility0 + "' != '" + com.google.javascript.rhino.JSDocInfo.Visibility.PUBLIC + "'", visibility0.equals(com.google.javascript.rhino.JSDocInfo.Visibility.PUBLIC));
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        com.google.javascript.rhino.ErrorReporter errorReporter1 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry3 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter1, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative4 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray5 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative4 };
        com.google.javascript.rhino.jstype.JSType jSType6 = jSTypeRegistry3.createUnionType(jSTypeNativeArray5);
        com.google.javascript.rhino.ErrorReporter errorReporter7 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry9 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter7, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative10 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray11 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative10 };
        com.google.javascript.rhino.jstype.JSType jSType12 = jSTypeRegistry9.createUnionType(jSTypeNativeArray11);
        com.google.javascript.rhino.Node node14 = new com.google.javascript.rhino.Node((-1));
        com.google.javascript.rhino.jstype.FunctionType functionType15 = jSTypeRegistry3.createFunctionType(jSType12, node14);
        com.google.javascript.rhino.ErrorReporter errorReporter16 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry18 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter16, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative19 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray20 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative19 };
        com.google.javascript.rhino.jstype.JSType jSType21 = jSTypeRegistry18.createUnionType(jSTypeNativeArray20);
        com.google.javascript.rhino.ErrorReporter errorReporter22 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry24 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter22, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative25 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray26 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative25 };
        com.google.javascript.rhino.jstype.JSType jSType27 = jSTypeRegistry24.createUnionType(jSTypeNativeArray26);
        com.google.javascript.rhino.Node node29 = new com.google.javascript.rhino.Node((-1));
        com.google.javascript.rhino.jstype.FunctionType functionType30 = jSTypeRegistry18.createFunctionType(jSType27, node29);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray31 = new com.google.javascript.rhino.jstype.JSType[] { jSType27 };
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList32 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean33 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList32, jSTypeArray31);
        com.google.javascript.rhino.Node node34 = jSTypeRegistry3.createParametersWithVarArgs((java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList32);
        jSTypeRegistry3.setLastGeneration(false);
        com.google.javascript.rhino.jstype.FunctionParamBuilder functionParamBuilder37 = new com.google.javascript.rhino.jstype.FunctionParamBuilder(jSTypeRegistry3);
        com.google.javascript.rhino.ErrorReporter errorReporter38 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry40 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter38, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative41 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray42 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative41 };
        com.google.javascript.rhino.jstype.JSType jSType43 = jSTypeRegistry40.createUnionType(jSTypeNativeArray42);
        com.google.javascript.rhino.ErrorReporter errorReporter44 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry46 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter44, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative47 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray48 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative47 };
        com.google.javascript.rhino.jstype.JSType jSType49 = jSTypeRegistry46.createUnionType(jSTypeNativeArray48);
        com.google.javascript.rhino.Node node51 = new com.google.javascript.rhino.Node((-1));
        com.google.javascript.rhino.jstype.FunctionType functionType52 = jSTypeRegistry40.createFunctionType(jSType49, node51);
        com.google.javascript.rhino.ErrorReporter errorReporter53 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry55 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter53, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative56 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray57 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative56 };
        com.google.javascript.rhino.jstype.JSType jSType58 = jSTypeRegistry55.createUnionType(jSTypeNativeArray57);
        com.google.javascript.rhino.ErrorReporter errorReporter59 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry61 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter59, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative62 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray63 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative62 };
        com.google.javascript.rhino.jstype.JSType jSType64 = jSTypeRegistry61.createUnionType(jSTypeNativeArray63);
        com.google.javascript.rhino.Node node66 = new com.google.javascript.rhino.Node((-1));
        com.google.javascript.rhino.jstype.FunctionType functionType67 = jSTypeRegistry55.createFunctionType(jSType64, node66);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray68 = new com.google.javascript.rhino.jstype.JSType[] { jSType64 };
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList69 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean70 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList69, jSTypeArray68);
        com.google.javascript.rhino.Node node71 = jSTypeRegistry40.createParametersWithVarArgs((java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList69);
        com.google.javascript.rhino.Node node72 = jSTypeRegistry3.createParametersWithVarArgs((java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList69);
        com.google.javascript.rhino.Node node75 = new com.google.javascript.rhino.Node(100, node72, 73, 23);
        org.junit.Assert.assertTrue("'" + jSTypeNative4 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative4.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray5);
        org.junit.Assert.assertNotNull(jSType6);
        org.junit.Assert.assertTrue("'" + jSTypeNative10 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative10.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray11);
        org.junit.Assert.assertNotNull(jSType12);
        org.junit.Assert.assertNotNull(functionType15);
        org.junit.Assert.assertTrue("'" + jSTypeNative19 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative19.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray20);
        org.junit.Assert.assertNotNull(jSType21);
        org.junit.Assert.assertTrue("'" + jSTypeNative25 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative25.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray26);
        org.junit.Assert.assertNotNull(jSType27);
        org.junit.Assert.assertNotNull(functionType30);
        org.junit.Assert.assertNotNull(jSTypeArray31);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertNotNull(node34);
        org.junit.Assert.assertTrue("'" + jSTypeNative41 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative41.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray42);
        org.junit.Assert.assertNotNull(jSType43);
        org.junit.Assert.assertTrue("'" + jSTypeNative47 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative47.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray48);
        org.junit.Assert.assertNotNull(jSType49);
        org.junit.Assert.assertNotNull(functionType52);
        org.junit.Assert.assertTrue("'" + jSTypeNative56 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative56.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray57);
        org.junit.Assert.assertNotNull(jSType58);
        org.junit.Assert.assertTrue("'" + jSTypeNative62 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative62.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray63);
        org.junit.Assert.assertNotNull(jSType64);
        org.junit.Assert.assertNotNull(functionType67);
        org.junit.Assert.assertNotNull(jSTypeArray68);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + true + "'", boolean70 == true);
        org.junit.Assert.assertNotNull(node71);
        org.junit.Assert.assertNotNull(node72);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        int int0 = com.google.javascript.rhino.Node.BOTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode3 = new com.google.javascript.rhino.ScriptOrFnNode(11, 130, (int) (short) 100);
        scriptOrFnNode3.setBaseLineno(21);
        java.lang.String str6 = scriptOrFnNode3.getSourceName();
        org.junit.Assert.assertNull(str6);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.common.collect.Multimap<com.google.javascript.jscomp.CustomPassExecutionTime, com.google.javascript.jscomp.CompilerPass> customPassExecutionTimeMultimap1 = null;
        compilerOptions0.customPasses = customPassExecutionTimeMultimap1;
        boolean boolean3 = compilerOptions0.inlineConstantVars;
        java.lang.String str4 = compilerOptions0.syntheticBlockStartMarker;
        compilerOptions0.decomposeExpressions = false;
        boolean boolean7 = compilerOptions0.checkTypes;
        java.lang.String str8 = compilerOptions0.sourceMapOutputPath;
        boolean boolean9 = compilerOptions0.deadAssignmentElimination;
        boolean boolean10 = compilerOptions0.flowSensitiveInlineVariables;
        boolean boolean11 = compilerOptions0.groupVariableDeclarations;
        java.lang.String str12 = compilerOptions0.jsOutputFile;
        compilerOptions0.locale = "language version";
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_NUMBER_STRING_BOOLEAN;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_NUMBER_STRING_BOOLEAN + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_NUMBER_STRING_BOOLEAN));
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.common.collect.Multimap<com.google.javascript.jscomp.CustomPassExecutionTime, com.google.javascript.jscomp.CompilerPass> customPassExecutionTimeMultimap1 = null;
        compilerOptions0.customPasses = customPassExecutionTimeMultimap1;
        compilerOptions0.devirtualizePrototypeMethods = true;
        compilerOptions0.checkDuplicateMessages = false;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy7 = null;
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy8 = null;
        compilerOptions0.setRenamingPolicy(variableRenamingPolicy7, propertyRenamingPolicy8);
        com.google.javascript.jscomp.CheckLevel checkLevel10 = compilerOptions0.checkUndefinedProperties;
        compilerOptions0.optimizeReturns = false;
        org.junit.Assert.assertTrue("'" + checkLevel10 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel10.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.disambiguateProperties;
        boolean boolean2 = compilerOptions0.isExternExportsEnabled();
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup3 = com.google.javascript.jscomp.DiagnosticGroups.CHECK_TYPES;
        com.google.javascript.jscomp.CompilerOptions compilerOptions4 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel5 = compilerOptions4.checkMissingGetCssNameLevel;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard6 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup3, checkLevel5);
        compilerOptions0.checkProvides = checkLevel5;
        boolean boolean8 = compilerOptions0.aliasExternals;
        boolean boolean9 = compilerOptions0.rewriteFunctionExpressions;
        compilerOptions0.removeUnusedVars = false;
        boolean boolean12 = compilerOptions0.convertToDottedProperties;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(diagnosticGroup3);
        org.junit.Assert.assertTrue("'" + checkLevel5 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel5.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }
}

