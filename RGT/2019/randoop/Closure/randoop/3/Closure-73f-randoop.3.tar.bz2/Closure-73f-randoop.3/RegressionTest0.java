import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        com.google.javascript.rhino.jstype.JSType jSType0 = null;
        com.google.javascript.rhino.jstype.JSType jSType1 = null;
        boolean boolean2 = com.google.javascript.rhino.jstype.JSType.isEquivalent(jSType0, jSType1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        int int0 = com.google.javascript.rhino.Node.LOCALCOUNT_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 21 + "'", int0 == 21);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.CHECK_TYPES;
        com.google.javascript.jscomp.DiagnosticGroups.NON_STANDARD_JSDOC = diagnosticGroup0;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = null;
        com.google.javascript.jscomp.DiagnosticGroups.CHECK_TYPES = diagnosticGroup0;
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        int int0 = com.google.javascript.rhino.Node.FLAG_NO_THROWS;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 8 + "'", int0 == 8);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        int int0 = com.google.javascript.rhino.Node.BOTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        int int0 = com.google.javascript.rhino.Node.QUOTED_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 35 + "'", int0 == 35);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        int int0 = com.google.javascript.rhino.Node.OBJECT_IDS_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + (-2) + "'", int0 == (-2));
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.ACCESS_CONTROLS;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        int int0 = com.google.javascript.rhino.Node.IS_CONSTANT_NAME;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 42 + "'", int0 == 42);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        com.google.javascript.rhino.jstype.JSType jSType0 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType1 = com.google.javascript.rhino.jstype.ObjectType.cast(jSType0);
        org.junit.Assert.assertNull(objectType1);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        java.lang.String str0 = com.google.javascript.rhino.jstype.JSType.NOT_A_CLASS;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "Not declared as a constructor" + "'", str0.equals("Not declared as a constructor"));
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        int int0 = com.google.javascript.rhino.Node.SOURCENAME_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 16 + "'", int0 == 16);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        int int0 = com.google.javascript.rhino.Node.SPECIALCALL_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 27 + "'", int0 == 27);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        int int0 = com.google.javascript.rhino.Context.FEATURE_RESERVED_KEYWORD_AS_IDENTIFIER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        java.lang.Object[] objArray0 = com.google.javascript.rhino.Context.emptyArgs;
        org.junit.Assert.assertNotNull(objArray0);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        int int0 = com.google.javascript.rhino.Node.FLAG_THIS_UNMODIFIED;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        int int0 = com.google.javascript.rhino.Context.FEATURE_WARNING_AS_ERROR;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 12 + "'", int0 == 12);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        int int0 = com.google.javascript.rhino.Node.DIRECTIVES;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 47 + "'", int0 == 47);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        int int0 = com.google.javascript.rhino.Context.VERSION_1_2;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 120 + "'", int0 == 120);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        int int0 = com.google.javascript.rhino.Node.IS_VAR_ARGS_PARAM;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 44 + "'", int0 == 44);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        java.io.InputStream inputStream1 = null;
        try {
            com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromInputStream("Not declared as a constructor", inputStream1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.CHECK_TYPES;
        com.google.javascript.jscomp.DiagnosticGroups.ACCESS_CONTROLS = diagnosticGroup0;
        org.junit.Assert.assertNull(diagnosticGroup0);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        java.lang.String str0 = com.google.javascript.rhino.Context.errorReporterProperty;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "error reporter" + "'", str0.equals("error reporter"));
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node.SideEffectFlags sideEffectFlags2 = null;
        try {
            node1.setSideEffectFlags(sideEffectFlags2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node1);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        int int0 = com.google.javascript.rhino.Node.PARENTHESIZED_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 34 + "'", int0 == 34);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        int int0 = com.google.javascript.rhino.Node.SIDE_EFFECT_FLAGS;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 41 + "'", int0 == 41);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        com.google.javascript.jscomp.SourceAst sourceAst0 = null;
        try {
            com.google.javascript.jscomp.CompilerInput compilerInput2 = new com.google.javascript.jscomp.CompilerInput(sourceAst0, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        try {
            java.lang.String str4 = com.google.javascript.rhino.ScriptRuntime.getMessage3("hi!", (java.lang.Object) true, (java.lang.Object) 'a', (java.lang.Object) 47);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property hi!");
        } catch (java.lang.RuntimeException e) {
        }
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        com.google.javascript.jscomp.CompilerOptions.TracerMode tracerMode0 = com.google.javascript.jscomp.CompilerOptions.TracerMode.ALL;
        org.junit.Assert.assertTrue("'" + tracerMode0 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TracerMode.ALL + "'", tracerMode0.equals(com.google.javascript.jscomp.CompilerOptions.TracerMode.ALL));
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        com.google.javascript.jscomp.mozilla.rhino.ast.AstRoot astRoot0 = null;
        com.google.javascript.jscomp.parsing.Config config2 = null;
        com.google.javascript.jscomp.mozilla.rhino.ErrorReporter errorReporter3 = null;
        try {
            com.google.javascript.rhino.Node node4 = com.google.javascript.jscomp.parsing.IRFactory.transformTree(astRoot0, "Not declared as a constructor", config2, errorReporter3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test032() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test032");
//        try {
//            java.lang.String str2 = com.google.javascript.rhino.ScriptRuntime.numberToString((double) 21, (int) '4');
//            org.junit.Assert.fail("Expected exception of type com.google.javascript.rhino.EvaluatorException; message: illegal radix 52.");
//        } catch (com.google.javascript.rhino.EvaluatorException e) {
//        }
//    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        java.util.logging.Level level0 = null;
        com.google.javascript.jscomp.Compiler.setLoggingLevel(level0);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node2 = node1.getParent();
        try {
            boolean boolean4 = node2.getBooleanProp(35);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertNull(node2);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        com.google.javascript.jscomp.DiagnosticType diagnosticType2 = com.google.javascript.jscomp.DiagnosticType.warning("error reporter", "");
        org.junit.Assert.assertNotNull(diagnosticType2);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        com.google.javascript.jscomp.SourceFile.Generator generator1 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("", generator1);
        com.google.javascript.jscomp.CompilerInput compilerInput4 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2, true);
        try {
            java.lang.String str5 = compilerInput4.getPathRelativeToClosureBase();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: null");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile2);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        com.google.javascript.jscomp.SourceFile.Generator generator3 = null;
        com.google.javascript.jscomp.SourceFile sourceFile4 = com.google.javascript.jscomp.SourceFile.fromGenerator("", generator3);
        java.lang.String str5 = sourceFile4.getOriginalPath();
        com.google.javascript.jscomp.JsAst jsAst6 = new com.google.javascript.jscomp.JsAst(sourceFile4);
        com.google.javascript.jscomp.SourceFile.Generator generator8 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile9 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("", generator8);
        com.google.javascript.jscomp.CompilerInput compilerInput11 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile9, true);
        try {
            java.lang.String str12 = com.google.javascript.rhino.ScriptRuntime.getMessage3("hi!", (java.lang.Object) 47, (java.lang.Object) sourceFile4, (java.lang.Object) true);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property hi!");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(sourceFile4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertNotNull(jSSourceFile9);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        int int0 = com.google.javascript.rhino.Node.IS_OPTIONAL_PARAM;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 43 + "'", int0 == 43);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newString("");
        try {
            int int3 = node1.getExistingIntProp(47);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: FAILED ASSERTION");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(node1);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node2 = node1.getParent();
        try {
            node2.setType(34);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertNull(node2);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        int int0 = com.google.javascript.rhino.Node.FLAG_ARGUMENTS_UNMODIFIED;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        com.google.javascript.jscomp.SourceMap.DetailLevel detailLevel0 = com.google.javascript.jscomp.SourceMap.DetailLevel.SYMBOLS;
        org.junit.Assert.assertNotNull(detailLevel0);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node2 = node1.getParent();
        try {
            com.google.javascript.rhino.Node.AncestorIterable ancestorIterable3 = node2.getAncestors();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertNull(node2);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.Node.newString("");
        int int3 = node2.getSideEffectFlags();
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node6 = node5.getParent();
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node9 = node8.getParent();
        boolean boolean10 = node8.isQuotedString();
        try {
            com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node(12, node2, node6, node8, 43, (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNull(node6);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNull(node9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        int int0 = com.google.javascript.rhino.Node.LABEL_ID_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        int int0 = com.google.javascript.rhino.Node.REGEXP_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 12 + "'", int0 == 12);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        int int0 = com.google.javascript.rhino.Context.FEATURE_STRICT_MODE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 11 + "'", int0 == 11);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node2 = node1.getParent();
        try {
            node2.setType((-1));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertNull(node2);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        int int0 = com.google.javascript.rhino.Node.VARIABLE_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 23 + "'", int0 == 23);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        try {
            com.google.javascript.rhino.EcmaError ecmaError2 = com.google.javascript.rhino.ScriptRuntime.typeError1("Not declared as a constructor", "error reporter");
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property Not declared as a constructor");
        } catch (java.lang.RuntimeException e) {
        }
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        com.google.javascript.jscomp.DiagnosticGroups diagnosticGroups0 = new com.google.javascript.jscomp.DiagnosticGroups();
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        com.google.javascript.rhino.EvaluatorException evaluatorException5 = new com.google.javascript.rhino.EvaluatorException("Not declared as a constructor", "Not declared as a constructor", 0, "window", 23);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        try {
            com.google.javascript.rhino.Context.reportWarning("");
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: No Context associated with current Thread");
        } catch (java.lang.RuntimeException e) {
        }
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        com.google.javascript.jscomp.mozilla.rhino.ast.AstRoot astRoot0 = null;
        com.google.javascript.jscomp.parsing.Config config2 = null;
        com.google.javascript.jscomp.mozilla.rhino.ErrorReporter errorReporter3 = null;
        try {
            com.google.javascript.rhino.Node node4 = com.google.javascript.jscomp.parsing.IRFactory.transformTree(astRoot0, "STRING  [empty_block: 1]", config2, errorReporter3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.CHECK_TYPES;
        com.google.javascript.jscomp.DiagnosticGroups.VISIBILITY = diagnosticGroup0;
        org.junit.Assert.assertNull(diagnosticGroup0);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        int int0 = com.google.javascript.rhino.Node.DECR_FLAG;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.CHECK_TYPES;
        com.google.javascript.jscomp.DiagnosticGroups.CHECK_USELESS_CODE = diagnosticGroup0;
        org.junit.Assert.assertNull(diagnosticGroup0);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        boolean boolean1 = com.google.javascript.rhino.Context.isValidOptimizationLevel(0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention0 = new com.google.javascript.jscomp.DefaultCodingConvention();
        java.lang.String str1 = defaultCodingConvention0.getGlobalObject();
        com.google.javascript.rhino.Node node2 = null;
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention3 = new com.google.javascript.jscomp.DefaultCodingConvention();
        java.lang.String str4 = defaultCodingConvention3.getExportSymbolFunction();
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node7 = node6.getParent();
        boolean boolean8 = node6.isQuotedString();
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship9 = defaultCodingConvention3.getDelegateRelationship(node6);
        com.google.javascript.rhino.Node node10 = com.google.javascript.jscomp.NodeUtil.newExpr(node6);
        try {
            java.lang.String str11 = defaultCodingConvention0.extractClassNameIfRequire(node2, node6);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: only implemented in GoogleCodingConvention");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "window" + "'", str1.equals("window"));
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNull(node7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNull(delegateRelationship9);
        org.junit.Assert.assertNotNull(node10);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        try {
            com.google.javascript.rhino.EcmaError ecmaError1 = com.google.javascript.rhino.ScriptRuntime.typeError0("window");
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property window");
        } catch (java.lang.RuntimeException e) {
        }
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        com.google.javascript.jscomp.SourceFile.Generator generator1 = null;
        com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromGenerator("", generator1);
        java.lang.String str3 = sourceFile2.getOriginalPath();
        com.google.javascript.jscomp.JsAst jsAst4 = new com.google.javascript.jscomp.JsAst(sourceFile2);
        com.google.javascript.jscomp.SourceFile.Generator generator6 = null;
        com.google.javascript.jscomp.SourceFile sourceFile7 = com.google.javascript.jscomp.SourceFile.fromGenerator("", generator6);
        java.lang.String str8 = sourceFile7.getName();
        jsAst4.setSourceFile(sourceFile7);
        com.google.javascript.jscomp.AbstractCompiler abstractCompiler10 = null;
        try {
            com.google.javascript.rhino.Node node11 = jsAst4.getAstRoot(abstractCompiler10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(sourceFile2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
        org.junit.Assert.assertNotNull(sourceFile7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        int int0 = com.google.javascript.rhino.Node.LOCAL_BLOCK_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + (-3) + "'", int0 == (-3));
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        java.util.List<com.google.javascript.jscomp.WarningsGuard> warningsGuardList0 = null;
        try {
            com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard1 = new com.google.javascript.jscomp.ComposeWarningsGuard(warningsGuardList0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        com.google.javascript.jscomp.SourceFile.Generator generator1 = null;
        com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromGenerator("", generator1);
        java.lang.String str3 = sourceFile2.getOriginalPath();
        com.google.javascript.jscomp.JsAst jsAst4 = new com.google.javascript.jscomp.JsAst(sourceFile2);
        try {
            java.lang.String str6 = sourceFile2.getLine(34);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(sourceFile2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.Node.newString("");
        int int3 = node2.getSideEffectFlags();
        boolean boolean4 = node2.isOptionalArg();
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention5 = new com.google.javascript.jscomp.DefaultCodingConvention();
        java.lang.String str6 = defaultCodingConvention5.getExportSymbolFunction();
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node9 = node8.getParent();
        boolean boolean10 = node8.isQuotedString();
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship11 = defaultCodingConvention5.getDelegateRelationship(node8);
        com.google.javascript.rhino.Node node12 = com.google.javascript.jscomp.NodeUtil.newExpr(node8);
        com.google.javascript.rhino.Node node15 = new com.google.javascript.rhino.Node((int) (short) 0, node2, node12, (int) (byte) 1, 0);
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention16 = new com.google.javascript.jscomp.DefaultCodingConvention();
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention17 = new com.google.javascript.jscomp.DefaultCodingConvention();
        java.lang.String str18 = defaultCodingConvention17.getExportSymbolFunction();
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node21 = node20.getParent();
        boolean boolean22 = node20.isQuotedString();
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship23 = defaultCodingConvention17.getDelegateRelationship(node20);
        com.google.javascript.jscomp.CodingConvention.SubclassRelationship subclassRelationship24 = defaultCodingConvention16.getClassesDefinedByCall(node20);
        java.lang.String str25 = node2.checkTreeEquals(node20);
        try {
            node2.setDouble(0.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: STRING  is not a string node");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNull(node9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNull(delegateRelationship11);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNull(str18);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNull(node21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNull(delegateRelationship23);
        org.junit.Assert.assertNull(subclassRelationship24);
        org.junit.Assert.assertNull(str25);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newString("");
        node1.setCharno((int) (byte) 100);
        java.lang.String str4 = com.google.javascript.rhino.ScriptRuntime.toString((java.lang.Object) (byte) 100);
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "100" + "'", str4.equals("100"));
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        com.google.javascript.rhino.Node.SideEffectFlags sideEffectFlags1 = new com.google.javascript.rhino.Node.SideEffectFlags((int) ' ');
        sideEffectFlags1.setMutatesArguments();
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        try {
            com.google.javascript.rhino.Context.reportWarning("100");
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: No Context associated with current Thread");
        } catch (java.lang.RuntimeException e) {
        }
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.CHECK_VARIABLES;
        com.google.javascript.jscomp.DiagnosticGroups.FILEOVERVIEW_JSDOC = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticGroups.MISSING_PROPERTIES = diagnosticGroup0;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        int int0 = com.google.javascript.rhino.jstype.JSType.NOT_ENUMDECL;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        int int0 = com.google.javascript.rhino.Context.FEATURE_NON_ECMA_GET_YEAR;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.CHECK_USELESS_CODE;
        com.google.javascript.jscomp.DiagnosticGroups.STRICT_MODULE_DEP_CHECK = diagnosticGroup0;
        org.junit.Assert.assertNull(diagnosticGroup0);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        java.lang.String str1 = com.google.javascript.rhino.jstype.ObjectType.createDelegateSuffix("STRING  [empty_block: 1]");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "(STRING  [empty_block: 1])" + "'", str1.equals("(STRING  [empty_block: 1])"));
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newString("");
        int int2 = node1.getSideEffectFlags();
        java.util.Collection<com.google.javascript.rhino.Node> nodeCollection3 = com.google.javascript.jscomp.NodeUtil.getVarsDeclaredInBranch(node1);
        int int4 = node1.getChildCount();
        boolean boolean5 = node1.isQuotedString();
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(nodeCollection3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        long long1 = com.google.javascript.rhino.ScriptRuntime.testUint32String("");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1L) + "'", long1 == (-1L));
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        try {
            com.google.javascript.rhino.EcmaError ecmaError3 = com.google.javascript.rhino.ScriptRuntime.typeError2("(STRING  [empty_block: 1])", "window", "STRING  [empty_block: 1]");
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property (STRING  [empty_block: 1])");
        } catch (java.lang.RuntimeException e) {
        }
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newString("");
        int int2 = node1.getSideEffectFlags();
        java.util.Collection<com.google.javascript.rhino.Node> nodeCollection3 = com.google.javascript.jscomp.NodeUtil.getVarsDeclaredInBranch(node1);
        try {
            com.google.javascript.rhino.Node node4 = node1.detachFromParent();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(nodeCollection3);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        int int0 = com.google.javascript.rhino.Node.SKIP_INDEXES_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 30 + "'", int0 == 30);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        com.google.javascript.jscomp.SourceAst sourceAst0 = null;
        try {
            com.google.javascript.jscomp.CompilerInput compilerInput1 = new com.google.javascript.jscomp.CompilerInput(sourceAst0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        com.google.javascript.jscomp.Compiler.CodeBuilder codeBuilder0 = new com.google.javascript.jscomp.Compiler.CodeBuilder();
        int int1 = codeBuilder0.getLength();
        java.lang.String str2 = codeBuilder0.toString();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        com.google.javascript.rhino.Context context0 = null;
        com.google.javascript.rhino.Context context1 = com.google.javascript.rhino.Context.enter(context0);
        try {
            context1.unseal((java.lang.Object) "");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(context1);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        int int0 = com.google.javascript.rhino.Node.LAST_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 49 + "'", int0 == 49);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        int int0 = com.google.javascript.rhino.Node.JSDOC_INFO_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 29 + "'", int0 == 29);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        int int0 = com.google.javascript.rhino.Node.LEFT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        int int0 = com.google.javascript.rhino.Node.CASEARRAY_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 15 + "'", int0 == 15);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention1 = new com.google.javascript.jscomp.DefaultCodingConvention();
        java.lang.String str2 = defaultCodingConvention1.getExportSymbolFunction();
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node5 = node4.getParent();
        boolean boolean6 = node4.isQuotedString();
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship7 = defaultCodingConvention1.getDelegateRelationship(node4);
        com.google.javascript.rhino.Node node8 = com.google.javascript.jscomp.NodeUtil.newExpr(node4);
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node11 = node10.getParent();
        boolean boolean12 = node10.isQuotedString();
        com.google.javascript.rhino.Node node15 = new com.google.javascript.rhino.Node(4, node8, node10, 35, 0);
        java.lang.RuntimeException runtimeException18 = com.google.javascript.rhino.ScriptRuntime.undefWriteError((java.lang.Object) 0, (java.lang.Object) "hi!", (java.lang.Object) "window");
        com.google.javascript.rhino.EvaluatorException evaluatorException20 = new com.google.javascript.rhino.EvaluatorException("error reporter");
        runtimeException18.addSuppressed((java.lang.Throwable) evaluatorException20);
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNull(node5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(delegateRelationship7);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNull(node11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(runtimeException18);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        com.google.javascript.jscomp.SourceFile.Generator generator1 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("", generator1);
        com.google.javascript.jscomp.CompilerInput compilerInput4 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2, true);
        try {
            java.lang.String str5 = jSSourceFile2.getCode();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile2);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        com.google.javascript.jscomp.SourceFile.Generator generator1 = null;
        com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromGenerator("", generator1);
        java.lang.String str3 = sourceFile2.getOriginalPath();
        try {
            com.google.javascript.jscomp.Region region5 = sourceFile2.getRegion((int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(sourceFile2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = null;
        com.google.javascript.jscomp.DiagnosticGroups.UNKNOWN_DEFINES = diagnosticGroup0;
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        int int0 = com.google.javascript.rhino.Node.VAR_ARGS_NAME;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 29 + "'", int0 == 29);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.CHECK_USELESS_CODE;
        com.google.javascript.jscomp.DiagnosticGroups.UNDEFINED_VARIABLES = diagnosticGroup0;
        org.junit.Assert.assertNull(diagnosticGroup0);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention1 = new com.google.javascript.jscomp.DefaultCodingConvention();
        java.lang.String str2 = defaultCodingConvention1.getExportSymbolFunction();
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node5 = node4.getParent();
        boolean boolean6 = node4.isQuotedString();
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship7 = defaultCodingConvention1.getDelegateRelationship(node4);
        com.google.javascript.rhino.Node node8 = com.google.javascript.jscomp.NodeUtil.newExpr(node4);
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node11 = node10.getParent();
        boolean boolean12 = node10.isQuotedString();
        com.google.javascript.rhino.Node node15 = new com.google.javascript.rhino.Node(4, node8, node10, 35, 0);
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.Node.newString("");
        int int19 = node18.getSideEffectFlags();
        boolean boolean20 = node18.isOptionalArg();
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention21 = new com.google.javascript.jscomp.DefaultCodingConvention();
        java.lang.String str22 = defaultCodingConvention21.getExportSymbolFunction();
        com.google.javascript.rhino.Node node24 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node25 = node24.getParent();
        boolean boolean26 = node24.isQuotedString();
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship27 = defaultCodingConvention21.getDelegateRelationship(node24);
        com.google.javascript.rhino.Node node28 = com.google.javascript.jscomp.NodeUtil.newExpr(node24);
        com.google.javascript.rhino.Node node31 = new com.google.javascript.rhino.Node((int) (short) 0, node18, node28, (int) (byte) 1, 0);
        com.google.javascript.rhino.Node node32 = node8.clonePropsFrom(node28);
        com.google.javascript.rhino.Node node34 = com.google.javascript.rhino.Node.newString("");
        int int35 = node34.getSideEffectFlags();
        java.util.Collection<com.google.javascript.rhino.Node> nodeCollection36 = com.google.javascript.jscomp.NodeUtil.getVarsDeclaredInBranch(node34);
        com.google.javascript.rhino.Node node37 = null;
        try {
            node32.replaceChildAfter(node34, node37);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: prev is not a child of this node.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNull(node5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(delegateRelationship7);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNull(node11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNull(str22);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertNull(node25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNull(delegateRelationship27);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertNotNull(node32);
        org.junit.Assert.assertNotNull(node34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
        org.junit.Assert.assertNotNull(nodeCollection36);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        int int0 = com.google.javascript.rhino.Node.FIXUPS_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 9 + "'", int0 == 9);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        java.lang.String str0 = com.google.javascript.rhino.Context.languageVersionProperty;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "language version" + "'", str0.equals("language version"));
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        int int0 = com.google.javascript.rhino.jstype.JSType.ENUMDECL;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString("");
        int int4 = node3.getSideEffectFlags();
        boolean boolean5 = node3.isOptionalArg();
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention6 = new com.google.javascript.jscomp.DefaultCodingConvention();
        java.lang.String str7 = defaultCodingConvention6.getExportSymbolFunction();
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node10 = node9.getParent();
        boolean boolean11 = node9.isQuotedString();
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship12 = defaultCodingConvention6.getDelegateRelationship(node9);
        com.google.javascript.rhino.Node node13 = com.google.javascript.jscomp.NodeUtil.newExpr(node9);
        com.google.javascript.rhino.Node node16 = new com.google.javascript.rhino.Node((int) (short) 0, node3, node13, (int) (byte) 1, 0);
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node19 = node18.getParent();
        boolean boolean20 = node18.hasChildren();
        node18.detachChildren();
        com.google.javascript.rhino.Node node22 = node18.cloneTree();
        com.google.javascript.rhino.Node[] nodeArray23 = new com.google.javascript.rhino.Node[] { node13, node22 };
        try {
            com.google.javascript.rhino.Node node24 = new com.google.javascript.rhino.Node(10, nodeArray23);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNull(node10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNull(delegateRelationship12);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNull(node19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertNotNull(nodeArray23);
    }

//    @Test
//    public void test097() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test097");
//        try {
//            com.google.javascript.rhino.Context.reportError("(STRING  [empty_block: 1])", "<No stack trace available>", 27, "language version", (int) (short) 10);
//            org.junit.Assert.fail("Expected exception of type com.google.javascript.rhino.EvaluatorException; message: (STRING  [empty_block: 1]) (<No stack trace available>#27)");
//        } catch (com.google.javascript.rhino.EvaluatorException e) {
//        }
//    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        java.lang.String str0 = com.google.javascript.rhino.jstype.JSType.UNKNOWN_NAME;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "Unknown class name" + "'", str0.equals("Unknown class name"));
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        com.google.javascript.rhino.Node node1 = null;
        com.google.javascript.jscomp.CheckLevel checkLevel2 = null;
        com.google.javascript.jscomp.DiagnosticType diagnosticType3 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray4 = new java.lang.String[] {};
        try {
            com.google.javascript.jscomp.JSError jSError5 = com.google.javascript.jscomp.JSError.make("STRING  [empty_block: 1]", node1, checkLevel2, diagnosticType3, strArray4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(diagnosticType3);
        org.junit.Assert.assertNotNull(strArray4);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        try {
            com.google.javascript.rhino.Context.reportWarning("window");
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: No Context associated with current Thread");
        } catch (java.lang.RuntimeException e) {
        }
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention0 = new com.google.javascript.jscomp.DefaultCodingConvention();
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention1 = new com.google.javascript.jscomp.DefaultCodingConvention();
        java.lang.String str2 = defaultCodingConvention1.getExportSymbolFunction();
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node5 = node4.getParent();
        boolean boolean6 = node4.isQuotedString();
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship7 = defaultCodingConvention1.getDelegateRelationship(node4);
        java.util.Collection<com.google.javascript.rhino.Node> nodeCollection8 = com.google.javascript.jscomp.NodeUtil.getVarsDeclaredInBranch(node4);
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.Node.newString("");
        int int12 = node11.getSideEffectFlags();
        boolean boolean13 = node11.isOptionalArg();
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention14 = new com.google.javascript.jscomp.DefaultCodingConvention();
        java.lang.String str15 = defaultCodingConvention14.getExportSymbolFunction();
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node18 = node17.getParent();
        boolean boolean19 = node17.isQuotedString();
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship20 = defaultCodingConvention14.getDelegateRelationship(node17);
        com.google.javascript.rhino.Node node21 = com.google.javascript.jscomp.NodeUtil.newExpr(node17);
        com.google.javascript.rhino.Node node24 = new com.google.javascript.rhino.Node((int) (short) 0, node11, node21, (int) (byte) 1, 0);
        try {
            java.lang.String str25 = defaultCodingConvention0.extractClassNameIfProvide(node4, node24);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: only implemented in GoogleCodingConvention");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNull(node5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(delegateRelationship7);
        org.junit.Assert.assertNotNull(nodeCollection8);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNull(str15);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNull(node18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNull(delegateRelationship20);
        org.junit.Assert.assertNotNull(node21);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        com.google.javascript.jscomp.ErrorFormat errorFormat0 = com.google.javascript.jscomp.ErrorFormat.SINGLELINE;
        com.google.javascript.jscomp.SourceExcerptProvider sourceExcerptProvider1 = null;
        try {
            com.google.javascript.jscomp.MessageFormatter messageFormatter3 = errorFormat0.toFormatter(sourceExcerptProvider1, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(errorFormat0);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.Node.newString("");
        int int3 = node2.getSideEffectFlags();
        java.util.Collection<com.google.javascript.rhino.Node> nodeCollection4 = com.google.javascript.jscomp.NodeUtil.getVarsDeclaredInBranch(node2);
        int int5 = node2.getChildCount();
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString("");
        int int9 = node8.getSideEffectFlags();
        try {
            java.lang.String str10 = com.google.javascript.rhino.ScriptRuntime.getMessage3("", (java.lang.Object) int5, (java.lang.Object) 100, (java.lang.Object) int9);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property ");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(nodeCollection4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        java.io.File file0 = null;
        try {
            com.google.javascript.jscomp.SourceFile sourceFile1 = com.google.javascript.jscomp.SourceFile.fromFile(file0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.Node.newString("");
        int int3 = node2.getSideEffectFlags();
        java.util.Collection<com.google.javascript.rhino.Node> nodeCollection4 = com.google.javascript.jscomp.NodeUtil.getVarsDeclaredInBranch(node2);
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention6 = new com.google.javascript.jscomp.DefaultCodingConvention();
        java.lang.String str7 = defaultCodingConvention6.getExportSymbolFunction();
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node10 = node9.getParent();
        boolean boolean11 = node9.isQuotedString();
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship12 = defaultCodingConvention6.getDelegateRelationship(node9);
        com.google.javascript.rhino.Node node13 = com.google.javascript.jscomp.NodeUtil.newExpr(node9);
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node16 = node15.getParent();
        boolean boolean17 = node15.isQuotedString();
        com.google.javascript.rhino.Node node20 = new com.google.javascript.rhino.Node(4, node13, node15, 35, 0);
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newString("");
        int int24 = node23.getSideEffectFlags();
        boolean boolean25 = node23.isOptionalArg();
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention26 = new com.google.javascript.jscomp.DefaultCodingConvention();
        java.lang.String str27 = defaultCodingConvention26.getExportSymbolFunction();
        com.google.javascript.rhino.Node node29 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node30 = node29.getParent();
        boolean boolean31 = node29.isQuotedString();
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship32 = defaultCodingConvention26.getDelegateRelationship(node29);
        com.google.javascript.rhino.Node node33 = com.google.javascript.jscomp.NodeUtil.newExpr(node29);
        com.google.javascript.rhino.Node node36 = new com.google.javascript.rhino.Node((int) (short) 0, node23, node33, (int) (byte) 1, 0);
        com.google.javascript.rhino.Node node37 = node13.clonePropsFrom(node33);
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention38 = new com.google.javascript.jscomp.DefaultCodingConvention();
        java.lang.String str39 = defaultCodingConvention38.getExportSymbolFunction();
        com.google.javascript.rhino.Node node41 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node42 = node41.getParent();
        boolean boolean43 = node41.isQuotedString();
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship44 = defaultCodingConvention38.getDelegateRelationship(node41);
        java.util.Collection<com.google.javascript.rhino.Node> nodeCollection45 = com.google.javascript.jscomp.NodeUtil.getVarsDeclaredInBranch(node41);
        node41.setWasEmptyNode(true);
        try {
            com.google.javascript.rhino.Node node48 = new com.google.javascript.rhino.Node((-2), node2, node37, node41);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(nodeCollection4);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNull(node10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNull(delegateRelationship12);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertNull(node16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNull(str27);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNull(node30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNull(delegateRelationship32);
        org.junit.Assert.assertNotNull(node33);
        org.junit.Assert.assertNotNull(node37);
        org.junit.Assert.assertNull(str39);
        org.junit.Assert.assertNotNull(node41);
        org.junit.Assert.assertNull(node42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNull(delegateRelationship44);
        org.junit.Assert.assertNotNull(nodeCollection45);
    }

//    @Test
//    public void test106() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test106");
//        com.google.javascript.rhino.Context context0 = null;
//        com.google.javascript.rhino.Context context1 = com.google.javascript.rhino.Context.enter(context0);
//        java.util.Locale locale2 = null;
//        java.util.Locale locale3 = context1.setLocale(locale2);
//        com.google.javascript.rhino.ErrorReporter errorReporter4 = null;
//        try {
//            com.google.javascript.rhino.ErrorReporter errorReporter5 = context1.setErrorReporter(errorReporter4);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(context1);
//        org.junit.Assert.assertNull(locale3);
//    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy0 = com.google.javascript.jscomp.VariableRenamingPolicy.ALL;
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy0 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.ALL + "'", variableRenamingPolicy0.equals(com.google.javascript.jscomp.VariableRenamingPolicy.ALL));
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        com.google.javascript.rhino.Context context0 = null;
        try {
            long long1 = com.google.javascript.rhino.ScriptRuntime.lastUint32Result(context0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.UNDEFINED_VARIABLES;
        org.junit.Assert.assertNull(diagnosticGroup0);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        java.nio.charset.Charset charset1 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromFile("error reporter", charset1);
        org.junit.Assert.assertNotNull(jSSourceFile2);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        try {
            com.google.javascript.rhino.EcmaError ecmaError4 = com.google.javascript.rhino.ScriptRuntime.typeError3("hi!", "(STRING  [empty_block: 1])", "error reporter", "error reporter");
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property hi!");
        } catch (java.lang.RuntimeException e) {
        }
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        com.google.javascript.jscomp.SourceFile.Generator generator1 = null;
        com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromGenerator("", generator1);
        java.lang.String str3 = sourceFile2.getOriginalPath();
        com.google.javascript.jscomp.JsAst jsAst4 = new com.google.javascript.jscomp.JsAst(sourceFile2);
        try {
            com.google.javascript.jscomp.Region region6 = sourceFile2.getRegion(11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(sourceFile2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        com.google.javascript.rhino.Context context0 = null;
        com.google.javascript.rhino.Context context1 = com.google.javascript.rhino.Context.enter(context0);
        java.lang.Object obj2 = context1.getDebuggerContextData();
        java.beans.PropertyChangeListener propertyChangeListener3 = null;
        try {
            context1.removePropertyChangeListener(propertyChangeListener3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(context1);
        org.junit.Assert.assertNull(obj2);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.Node.newString("");
        int int3 = node2.getSideEffectFlags();
        boolean boolean4 = node2.isOptionalArg();
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention5 = new com.google.javascript.jscomp.DefaultCodingConvention();
        java.lang.String str6 = defaultCodingConvention5.getExportSymbolFunction();
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node9 = node8.getParent();
        boolean boolean10 = node8.isQuotedString();
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship11 = defaultCodingConvention5.getDelegateRelationship(node8);
        com.google.javascript.rhino.Node node12 = com.google.javascript.jscomp.NodeUtil.newExpr(node8);
        com.google.javascript.rhino.Node node15 = new com.google.javascript.rhino.Node((int) (short) 0, node2, node12, (int) (byte) 1, 0);
        try {
            node12.setString("STRING  [empty_block: 1]");
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: EXPR_RESULT is not a string node");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNull(node9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNull(delegateRelationship11);
        org.junit.Assert.assertNotNull(node12);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        com.google.javascript.jscomp.SourceFile.Generator generator1 = null;
        com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromGenerator("error reporter", generator1);
        java.lang.String str3 = sourceFile2.getOriginalPath();
        java.lang.String str4 = sourceFile2.toString();
        org.junit.Assert.assertNotNull(sourceFile2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "error reporter" + "'", str3.equals("error reporter"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "error reporter" + "'", str4.equals("error reporter"));
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        int int0 = com.google.javascript.rhino.Context.VERSION_1_6;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 160 + "'", int0 == 160);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString("");
        int int4 = node3.getSideEffectFlags();
        boolean boolean5 = node3.isOptionalArg();
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention6 = new com.google.javascript.jscomp.DefaultCodingConvention();
        java.lang.String str7 = defaultCodingConvention6.getExportSymbolFunction();
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node10 = node9.getParent();
        boolean boolean11 = node9.isQuotedString();
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship12 = defaultCodingConvention6.getDelegateRelationship(node9);
        com.google.javascript.rhino.Node node13 = com.google.javascript.jscomp.NodeUtil.newExpr(node9);
        com.google.javascript.rhino.Node node16 = new com.google.javascript.rhino.Node((int) (short) 0, node3, node13, (int) (byte) 1, 0);
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention17 = new com.google.javascript.jscomp.DefaultCodingConvention();
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention18 = new com.google.javascript.jscomp.DefaultCodingConvention();
        java.lang.String str19 = defaultCodingConvention18.getExportSymbolFunction();
        com.google.javascript.rhino.Node node21 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node22 = node21.getParent();
        boolean boolean23 = node21.isQuotedString();
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship24 = defaultCodingConvention18.getDelegateRelationship(node21);
        com.google.javascript.jscomp.CodingConvention.SubclassRelationship subclassRelationship25 = defaultCodingConvention17.getClassesDefinedByCall(node21);
        java.lang.String str26 = node3.checkTreeEquals(node21);
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention27 = new com.google.javascript.jscomp.DefaultCodingConvention();
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention28 = new com.google.javascript.jscomp.DefaultCodingConvention();
        java.lang.String str29 = defaultCodingConvention28.getExportSymbolFunction();
        com.google.javascript.rhino.Node node31 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node32 = node31.getParent();
        boolean boolean33 = node31.isQuotedString();
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship34 = defaultCodingConvention28.getDelegateRelationship(node31);
        com.google.javascript.jscomp.CodingConvention.SubclassRelationship subclassRelationship35 = defaultCodingConvention27.getClassesDefinedByCall(node31);
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention37 = new com.google.javascript.jscomp.DefaultCodingConvention();
        java.lang.String str38 = defaultCodingConvention37.getExportSymbolFunction();
        com.google.javascript.rhino.Node node40 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node41 = node40.getParent();
        boolean boolean42 = node40.isQuotedString();
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship43 = defaultCodingConvention37.getDelegateRelationship(node40);
        com.google.javascript.rhino.Node node44 = com.google.javascript.jscomp.NodeUtil.newExpr(node40);
        com.google.javascript.rhino.Node node46 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node47 = node46.getParent();
        boolean boolean48 = node46.isQuotedString();
        com.google.javascript.rhino.Node node51 = new com.google.javascript.rhino.Node(4, node44, node46, 35, 0);
        java.lang.String str52 = defaultCodingConvention27.getSingletonGetterClassName(node46);
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention53 = new com.google.javascript.jscomp.DefaultCodingConvention();
        java.lang.String str54 = defaultCodingConvention53.getExportSymbolFunction();
        com.google.javascript.rhino.Node node56 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node57 = node56.getParent();
        boolean boolean58 = node56.isQuotedString();
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship59 = defaultCodingConvention53.getDelegateRelationship(node56);
        java.util.Collection<com.google.javascript.rhino.Node> nodeCollection60 = com.google.javascript.jscomp.NodeUtil.getVarsDeclaredInBranch(node56);
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable61 = node56.children();
        try {
            com.google.javascript.rhino.Node node62 = new com.google.javascript.rhino.Node((-2), node21, node46, node56);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNull(node10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNull(delegateRelationship12);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNull(str19);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertNull(node22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNull(delegateRelationship24);
        org.junit.Assert.assertNull(subclassRelationship25);
        org.junit.Assert.assertNull(str26);
        org.junit.Assert.assertNull(str29);
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertNull(node32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNull(delegateRelationship34);
        org.junit.Assert.assertNull(subclassRelationship35);
        org.junit.Assert.assertNull(str38);
        org.junit.Assert.assertNotNull(node40);
        org.junit.Assert.assertNull(node41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNull(delegateRelationship43);
        org.junit.Assert.assertNotNull(node44);
        org.junit.Assert.assertNotNull(node46);
        org.junit.Assert.assertNull(node47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNull(str52);
        org.junit.Assert.assertNull(str54);
        org.junit.Assert.assertNotNull(node56);
        org.junit.Assert.assertNull(node57);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNull(delegateRelationship59);
        org.junit.Assert.assertNotNull(nodeCollection60);
        org.junit.Assert.assertNotNull(nodeIterable61);
    }

//    @Test
//    public void test118() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test118");
//        try {
//            com.google.javascript.rhino.EvaluatorException evaluatorException1 = com.google.javascript.rhino.Context.reportRuntimeError("hi!");
//            org.junit.Assert.fail("Expected exception of type com.google.javascript.rhino.EvaluatorException; message: hi!");
//        } catch (com.google.javascript.rhino.EvaluatorException e) {
//        }
//    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node2 = node1.getParent();
        boolean boolean3 = node1.isQuotedString();
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString("");
        int int7 = node6.getSideEffectFlags();
        boolean boolean8 = node6.isOptionalArg();
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention9 = new com.google.javascript.jscomp.DefaultCodingConvention();
        java.lang.String str10 = defaultCodingConvention9.getExportSymbolFunction();
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node13 = node12.getParent();
        boolean boolean14 = node12.isQuotedString();
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship15 = defaultCodingConvention9.getDelegateRelationship(node12);
        com.google.javascript.rhino.Node node16 = com.google.javascript.jscomp.NodeUtil.newExpr(node12);
        com.google.javascript.rhino.Node node19 = new com.google.javascript.rhino.Node((int) (short) 0, node6, node16, (int) (byte) 1, 0);
        com.google.javascript.rhino.Node node20 = null;
        try {
            node1.addChildAfter(node19, node20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertNull(node2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNull(node13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNull(delegateRelationship15);
        org.junit.Assert.assertNotNull(node16);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        int int0 = com.google.javascript.rhino.Context.FEATURE_MEMBER_EXPR_AS_FUNCTION_NAME;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy0 = com.google.javascript.jscomp.PropertyRenamingPolicy.HEURISTIC;
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy0 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.HEURISTIC + "'", propertyRenamingPolicy0.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.HEURISTIC));
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention0 = new com.google.javascript.jscomp.DefaultCodingConvention();
        java.lang.String str1 = defaultCodingConvention0.getGlobalObject();
        boolean boolean3 = defaultCodingConvention0.isConstant("window");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "window" + "'", str1.equals("window"));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        int int0 = com.google.javascript.rhino.Node.SPECIAL_PROP_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 18 + "'", int0 == 18);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        java.lang.String str2 = com.google.javascript.rhino.ScriptRuntime.numberToString((double) 21, (int) (short) 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "21" + "'", str2.equals("21"));
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newString("");
        int int2 = node1.getSideEffectFlags();
        java.util.Collection<com.google.javascript.rhino.Node> nodeCollection3 = com.google.javascript.jscomp.NodeUtil.getVarsDeclaredInBranch(node1);
        int int4 = node1.getChildCount();
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable5 = node1.siblings();
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(nodeCollection3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(nodeIterable5);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        int int0 = com.google.javascript.rhino.Node.DESCENDANTS_FLAG;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        int int0 = com.google.javascript.rhino.Node.NO_SIDE_EFFECTS;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 15 + "'", int0 == 15);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        int int0 = com.google.javascript.rhino.Node.DIRECT_EVAL;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 48 + "'", int0 == 48);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention1 = new com.google.javascript.jscomp.DefaultCodingConvention();
        java.lang.String str2 = defaultCodingConvention1.getExportSymbolFunction();
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node5 = node4.getParent();
        boolean boolean6 = node4.isQuotedString();
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship7 = defaultCodingConvention1.getDelegateRelationship(node4);
        com.google.javascript.rhino.JSDocInfo jSDocInfo8 = null;
        node4.setJSDocInfo(jSDocInfo8);
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention10 = new com.google.javascript.jscomp.DefaultCodingConvention();
        java.lang.String str11 = defaultCodingConvention10.getExportSymbolFunction();
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node14 = node13.getParent();
        boolean boolean15 = node13.isQuotedString();
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship16 = defaultCodingConvention10.getDelegateRelationship(node13);
        com.google.javascript.rhino.Node node17 = com.google.javascript.jscomp.NodeUtil.newExpr(node13);
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention18 = new com.google.javascript.jscomp.DefaultCodingConvention();
        java.lang.String str19 = defaultCodingConvention18.getExportSymbolFunction();
        com.google.javascript.rhino.Node node21 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node22 = node21.getParent();
        boolean boolean23 = node21.isQuotedString();
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship24 = defaultCodingConvention18.getDelegateRelationship(node21);
        com.google.javascript.rhino.Node node25 = com.google.javascript.jscomp.NodeUtil.newExpr(node21);
        com.google.javascript.rhino.Node node27 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node28 = node27.getParent();
        boolean boolean29 = node27.hasChildren();
        node27.detachChildren();
        try {
            com.google.javascript.rhino.Node node33 = new com.google.javascript.rhino.Node(3, node4, node13, node21, node27, 21, 8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNull(node5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(delegateRelationship7);
        org.junit.Assert.assertNull(str11);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNull(node14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNull(delegateRelationship16);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNull(str19);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertNull(node22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNull(delegateRelationship24);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNotNull(node27);
        org.junit.Assert.assertNull(node28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        int int0 = com.google.javascript.rhino.Node.NAME_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 33 + "'", int0 == 33);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        java.lang.String str1 = com.google.javascript.rhino.Node.tokenToName(29);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "neg" + "'", str1.equals("neg"));
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention0 = new com.google.javascript.jscomp.DefaultCodingConvention();
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention1 = new com.google.javascript.jscomp.DefaultCodingConvention();
        java.lang.String str2 = defaultCodingConvention1.getExportSymbolFunction();
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node5 = node4.getParent();
        boolean boolean6 = node4.isQuotedString();
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship7 = defaultCodingConvention1.getDelegateRelationship(node4);
        com.google.javascript.jscomp.CodingConvention.SubclassRelationship subclassRelationship8 = defaultCodingConvention0.getClassesDefinedByCall(node4);
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention10 = new com.google.javascript.jscomp.DefaultCodingConvention();
        java.lang.String str11 = defaultCodingConvention10.getExportSymbolFunction();
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node14 = node13.getParent();
        boolean boolean15 = node13.isQuotedString();
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship16 = defaultCodingConvention10.getDelegateRelationship(node13);
        com.google.javascript.rhino.Node node17 = com.google.javascript.jscomp.NodeUtil.newExpr(node13);
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node20 = node19.getParent();
        boolean boolean21 = node19.isQuotedString();
        com.google.javascript.rhino.Node node24 = new com.google.javascript.rhino.Node(4, node17, node19, 35, 0);
        java.lang.String str25 = defaultCodingConvention0.getSingletonGetterClassName(node19);
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention26 = new com.google.javascript.jscomp.DefaultCodingConvention();
        java.lang.String str27 = defaultCodingConvention26.getExportSymbolFunction();
        com.google.javascript.rhino.Node node29 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node30 = node29.getParent();
        boolean boolean31 = node29.isQuotedString();
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship32 = defaultCodingConvention26.getDelegateRelationship(node29);
        java.util.Collection<com.google.javascript.rhino.Node> nodeCollection33 = com.google.javascript.jscomp.NodeUtil.getVarsDeclaredInBranch(node29);
        node29.setWasEmptyNode(true);
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention37 = new com.google.javascript.jscomp.DefaultCodingConvention();
        java.lang.String str38 = defaultCodingConvention37.getExportSymbolFunction();
        com.google.javascript.rhino.Node node40 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node41 = node40.getParent();
        boolean boolean42 = node40.isQuotedString();
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship43 = defaultCodingConvention37.getDelegateRelationship(node40);
        com.google.javascript.rhino.Node node44 = com.google.javascript.jscomp.NodeUtil.newExpr(node40);
        com.google.javascript.rhino.Node node46 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node47 = node46.getParent();
        boolean boolean48 = node46.isQuotedString();
        com.google.javascript.rhino.Node node51 = new com.google.javascript.rhino.Node(4, node44, node46, 35, 0);
        try {
            java.lang.String str52 = defaultCodingConvention0.extractClassNameIfProvide(node29, node51);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: only implemented in GoogleCodingConvention");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNull(node5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(delegateRelationship7);
        org.junit.Assert.assertNull(subclassRelationship8);
        org.junit.Assert.assertNull(str11);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNull(node14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNull(delegateRelationship16);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNull(node20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNull(str25);
        org.junit.Assert.assertNull(str27);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNull(node30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNull(delegateRelationship32);
        org.junit.Assert.assertNotNull(nodeCollection33);
        org.junit.Assert.assertNull(str38);
        org.junit.Assert.assertNotNull(node40);
        org.junit.Assert.assertNull(node41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNull(delegateRelationship43);
        org.junit.Assert.assertNotNull(node44);
        org.junit.Assert.assertNotNull(node46);
        org.junit.Assert.assertNull(node47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        java.lang.Object obj1 = null;
        try {
            java.lang.String str2 = com.google.javascript.rhino.ScriptRuntime.getMessage1("hi!", obj1);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property hi!");
        } catch (java.lang.RuntimeException e) {
        }
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.INVALID_CASTS;
        com.google.javascript.jscomp.DiagnosticGroups.NON_STANDARD_JSDOC = diagnosticGroup0;
        com.google.javascript.jscomp.JSError jSError2 = null;
        try {
            boolean boolean3 = diagnosticGroup0.matches(jSError2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        int int0 = com.google.javascript.rhino.Context.VERSION_1_4;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 140 + "'", int0 == 140);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention1 = new com.google.javascript.jscomp.DefaultCodingConvention();
        java.lang.String str2 = defaultCodingConvention1.getExportSymbolFunction();
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node5 = node4.getParent();
        boolean boolean6 = node4.isQuotedString();
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship7 = defaultCodingConvention1.getDelegateRelationship(node4);
        com.google.javascript.rhino.Node node8 = com.google.javascript.jscomp.NodeUtil.newExpr(node4);
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node11 = node10.getParent();
        boolean boolean12 = node10.isQuotedString();
        com.google.javascript.rhino.Node node15 = new com.google.javascript.rhino.Node(4, node8, node10, 35, 0);
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.Node.newString("");
        int int19 = node18.getSideEffectFlags();
        boolean boolean20 = node18.isOptionalArg();
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention21 = new com.google.javascript.jscomp.DefaultCodingConvention();
        java.lang.String str22 = defaultCodingConvention21.getExportSymbolFunction();
        com.google.javascript.rhino.Node node24 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node25 = node24.getParent();
        boolean boolean26 = node24.isQuotedString();
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship27 = defaultCodingConvention21.getDelegateRelationship(node24);
        com.google.javascript.rhino.Node node28 = com.google.javascript.jscomp.NodeUtil.newExpr(node24);
        com.google.javascript.rhino.Node node31 = new com.google.javascript.rhino.Node((int) (short) 0, node18, node28, (int) (byte) 1, 0);
        com.google.javascript.rhino.Node node32 = node8.clonePropsFrom(node28);
        try {
            node28.setQuotedString();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: FAILED ASSERTION");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNull(node5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(delegateRelationship7);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNull(node11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNull(str22);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertNull(node25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNull(delegateRelationship27);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertNotNull(node32);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        com.google.javascript.rhino.Context context0 = null;
        com.google.javascript.rhino.Context context1 = com.google.javascript.rhino.Context.enter(context0);
        com.google.javascript.rhino.ErrorReporter errorReporter2 = null;
        try {
            com.google.javascript.rhino.ErrorReporter errorReporter3 = context1.setErrorReporter(errorReporter2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(context1);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        com.google.javascript.jscomp.SourceFile.Generator generator1 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("", generator1);
        com.google.javascript.jscomp.CompilerInput compilerInput4 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2, true);
        com.google.javascript.jscomp.SourceFile sourceFile5 = compilerInput4.getSourceFile();
        java.lang.String str6 = sourceFile5.getName();
        org.junit.Assert.assertNotNull(jSSourceFile2);
        org.junit.Assert.assertNotNull(sourceFile5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        com.google.javascript.jscomp.SourceFile sourceFile3 = com.google.javascript.jscomp.SourceFile.fromCode("hi!", "window", "");
        java.lang.String str4 = sourceFile3.getOriginalPath();
        org.junit.Assert.assertNotNull(sourceFile3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "window" + "'", str4.equals("window"));
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        com.google.javascript.rhino.EcmaError ecmaError1 = com.google.javascript.rhino.ScriptRuntime.typeError("100");
        java.lang.String str2 = ecmaError1.lineSource();
        org.junit.Assert.assertNotNull(ecmaError1);
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention0 = new com.google.javascript.jscomp.DefaultCodingConvention();
        java.lang.String str1 = defaultCodingConvention0.getExportSymbolFunction();
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node4 = node3.getParent();
        boolean boolean5 = node3.isQuotedString();
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship6 = defaultCodingConvention0.getDelegateRelationship(node3);
        java.util.Collection<com.google.javascript.rhino.Node> nodeCollection7 = com.google.javascript.jscomp.NodeUtil.getVarsDeclaredInBranch(node3);
        com.google.javascript.rhino.JSDocInfo jSDocInfo8 = node3.getJSDocInfo();
        try {
            int int10 = node3.getExistingIntProp(33);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: FAILED ASSERTION");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNull(node4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(delegateRelationship6);
        org.junit.Assert.assertNotNull(nodeCollection7);
        org.junit.Assert.assertNull(jSDocInfo8);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        com.google.javascript.jscomp.SourceFile.Generator generator1 = null;
        com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromGenerator("", generator1);
        sourceFile2.setOriginalPath("(STRING  [empty_block: 1])");
        org.junit.Assert.assertNotNull(sourceFile2);
    }

//    @Test
//    public void test143() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test143");
//        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.CHECK_TYPES;
//        com.google.javascript.jscomp.DiagnosticGroups.NON_STANDARD_JSDOC = diagnosticGroup0;
//        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup2 = com.google.javascript.jscomp.DiagnosticGroups.INVALID_CASTS;
//        com.google.javascript.jscomp.DiagnosticGroups.NON_STANDARD_JSDOC = diagnosticGroup2;
//        com.google.javascript.jscomp.DiagnosticGroups.CHECK_TYPES = diagnosticGroup2;
//        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup5 = com.google.javascript.jscomp.DiagnosticGroups.ACCESS_CONTROLS;
//        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup6 = com.google.javascript.jscomp.DiagnosticGroups.INTERNET_EXPLORER_CHECKS;
//        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup7 = com.google.javascript.jscomp.DiagnosticGroups.NON_STANDARD_JSDOC;
//        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup8 = com.google.javascript.jscomp.DiagnosticGroups.CHECK_VARIABLES;
//        com.google.javascript.jscomp.DiagnosticGroups.FILEOVERVIEW_JSDOC = diagnosticGroup8;
//        com.google.javascript.jscomp.DiagnosticGroups.MISSING_PROPERTIES = diagnosticGroup8;
//        com.google.javascript.jscomp.DiagnosticGroup[] diagnosticGroupArray11 = new com.google.javascript.jscomp.DiagnosticGroup[] { diagnosticGroup0, diagnosticGroup2, diagnosticGroup5, diagnosticGroup6, diagnosticGroup7, diagnosticGroup8 };
//        try {
//            com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup12 = new com.google.javascript.jscomp.DiagnosticGroup(diagnosticGroupArray11);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(diagnosticGroup0);
//        org.junit.Assert.assertNotNull(diagnosticGroup2);
//        org.junit.Assert.assertNull(diagnosticGroup5);
//        org.junit.Assert.assertNotNull(diagnosticGroup6);
//        org.junit.Assert.assertNotNull(diagnosticGroup7);
//        org.junit.Assert.assertNotNull(diagnosticGroup8);
//        org.junit.Assert.assertNotNull(diagnosticGroupArray11);
//    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        int int0 = com.google.javascript.rhino.Context.FEATURE_STRICT_VARS;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 8 + "'", int0 == 8);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        double double0 = com.google.javascript.rhino.ScriptRuntime.NaN;
        org.junit.Assert.assertEquals((double) double0, Double.NaN, 0);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        com.google.javascript.jscomp.CompilerOptions.TracerMode tracerMode0 = com.google.javascript.jscomp.CompilerOptions.TracerMode.OFF;
        org.junit.Assert.assertTrue("'" + tracerMode0 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TracerMode.OFF + "'", tracerMode0.equals(com.google.javascript.jscomp.CompilerOptions.TracerMode.OFF));
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        com.google.javascript.jscomp.parsing.Config config2 = null;
        com.google.javascript.jscomp.mozilla.rhino.ErrorReporter errorReporter3 = null;
        java.util.logging.Logger logger4 = null;
        try {
            com.google.javascript.rhino.Node node5 = com.google.javascript.jscomp.parsing.ParserRunner.parse("21", "window", config2, errorReporter3, logger4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention0 = new com.google.javascript.jscomp.DefaultCodingConvention();
        java.lang.String str1 = defaultCodingConvention0.getExportSymbolFunction();
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node4 = node3.getParent();
        boolean boolean5 = node3.isQuotedString();
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship6 = defaultCodingConvention0.getDelegateRelationship(node3);
        java.util.Collection<com.google.javascript.rhino.Node> nodeCollection7 = com.google.javascript.jscomp.NodeUtil.getVarsDeclaredInBranch(node3);
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention9 = new com.google.javascript.jscomp.DefaultCodingConvention();
        java.lang.String str10 = defaultCodingConvention9.getExportSymbolFunction();
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node13 = node12.getParent();
        boolean boolean14 = node12.isQuotedString();
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship15 = defaultCodingConvention9.getDelegateRelationship(node12);
        com.google.javascript.rhino.Node node16 = com.google.javascript.jscomp.NodeUtil.newExpr(node12);
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node19 = node18.getParent();
        boolean boolean20 = node18.isQuotedString();
        com.google.javascript.rhino.Node node23 = new com.google.javascript.rhino.Node(4, node16, node18, 35, 0);
        com.google.javascript.rhino.Node node26 = com.google.javascript.rhino.Node.newString("");
        int int27 = node26.getSideEffectFlags();
        boolean boolean28 = node26.isOptionalArg();
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention29 = new com.google.javascript.jscomp.DefaultCodingConvention();
        java.lang.String str30 = defaultCodingConvention29.getExportSymbolFunction();
        com.google.javascript.rhino.Node node32 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node33 = node32.getParent();
        boolean boolean34 = node32.isQuotedString();
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship35 = defaultCodingConvention29.getDelegateRelationship(node32);
        com.google.javascript.rhino.Node node36 = com.google.javascript.jscomp.NodeUtil.newExpr(node32);
        com.google.javascript.rhino.Node node39 = new com.google.javascript.rhino.Node((int) (short) 0, node26, node36, (int) (byte) 1, 0);
        com.google.javascript.rhino.Node node40 = node16.clonePropsFrom(node36);
        try {
            com.google.javascript.rhino.Node node41 = node3.removeChildAfter(node40);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: prev is not a child of this node.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNull(node4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(delegateRelationship6);
        org.junit.Assert.assertNotNull(nodeCollection7);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNull(node13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNull(delegateRelationship15);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNull(node19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNull(str30);
        org.junit.Assert.assertNotNull(node32);
        org.junit.Assert.assertNull(node33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNull(delegateRelationship35);
        org.junit.Assert.assertNotNull(node36);
        org.junit.Assert.assertNotNull(node40);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        com.google.javascript.jscomp.SourceFile.Generator generator1 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("", generator1);
        com.google.javascript.jscomp.CompilerInput compilerInput4 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2, true);
        try {
            java.lang.String str6 = jSSourceFile2.getLine(47);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile2);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention1 = new com.google.javascript.jscomp.DefaultCodingConvention();
        java.lang.String str2 = defaultCodingConvention1.getExportSymbolFunction();
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node5 = node4.getParent();
        boolean boolean6 = node4.isQuotedString();
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship7 = defaultCodingConvention1.getDelegateRelationship(node4);
        com.google.javascript.rhino.Node node8 = com.google.javascript.jscomp.NodeUtil.newExpr(node4);
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node11 = node10.getParent();
        boolean boolean12 = node10.isQuotedString();
        com.google.javascript.rhino.Node node15 = new com.google.javascript.rhino.Node(4, node8, node10, 35, 0);
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.Node.newString("");
        int int19 = node18.getSideEffectFlags();
        boolean boolean20 = node18.isOptionalArg();
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention21 = new com.google.javascript.jscomp.DefaultCodingConvention();
        java.lang.String str22 = defaultCodingConvention21.getExportSymbolFunction();
        com.google.javascript.rhino.Node node24 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node25 = node24.getParent();
        boolean boolean26 = node24.isQuotedString();
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship27 = defaultCodingConvention21.getDelegateRelationship(node24);
        com.google.javascript.rhino.Node node28 = com.google.javascript.jscomp.NodeUtil.newExpr(node24);
        com.google.javascript.rhino.Node node31 = new com.google.javascript.rhino.Node((int) (short) 0, node18, node28, (int) (byte) 1, 0);
        com.google.javascript.rhino.Node node32 = node8.clonePropsFrom(node28);
        try {
            node28.setString("Unknown class name");
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: EXPR_RESULT is not a string node");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNull(node5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(delegateRelationship7);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNull(node11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNull(str22);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertNull(node25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNull(delegateRelationship27);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertNotNull(node32);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention0 = new com.google.javascript.jscomp.DefaultCodingConvention();
        java.lang.String str1 = defaultCodingConvention0.getExportSymbolFunction();
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node4 = node3.getParent();
        boolean boolean5 = node3.isQuotedString();
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship6 = defaultCodingConvention0.getDelegateRelationship(node3);
        java.util.Collection<com.google.javascript.rhino.Node> nodeCollection7 = com.google.javascript.jscomp.NodeUtil.getVarsDeclaredInBranch(node3);
        node3.setWasEmptyNode(true);
        java.lang.String str13 = node3.toString(false, true, false);
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.Node.newString("");
        int int16 = node15.getSideEffectFlags();
        java.util.Collection<com.google.javascript.rhino.Node> nodeCollection17 = com.google.javascript.jscomp.NodeUtil.getVarsDeclaredInBranch(node15);
        java.lang.String str18 = node15.getString();
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.Node.newString("");
        int int21 = node20.getSideEffectFlags();
        boolean boolean22 = node20.isOptionalArg();
        try {
            node3.replaceChildAfter(node15, node20);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: prev is not a child of this node.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNull(node4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(delegateRelationship6);
        org.junit.Assert.assertNotNull(nodeCollection7);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "STRING  [empty_block: 1]" + "'", str13.equals("STRING  [empty_block: 1]"));
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNotNull(nodeCollection17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "" + "'", str18.equals(""));
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        com.google.javascript.jscomp.SourceFile.Generator generator1 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("", generator1);
        com.google.javascript.jscomp.CompilerInput compilerInput4 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2, true);
        java.nio.charset.Charset charset6 = null;
        com.google.javascript.jscomp.SourceFile sourceFile7 = com.google.javascript.jscomp.SourceFile.fromFile("", charset6);
        compilerInput4.setSourceFile(sourceFile7);
        com.google.javascript.jscomp.SourceFile.Generator generator10 = null;
        com.google.javascript.jscomp.SourceFile sourceFile11 = com.google.javascript.jscomp.SourceFile.fromGenerator("", generator10);
        java.lang.String str12 = sourceFile11.getOriginalPath();
        compilerInput4.setSourceFile(sourceFile11);
        try {
            java.lang.String str14 = compilerInput4.getPathRelativeToClosureBase();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: null");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile2);
        org.junit.Assert.assertNotNull(sourceFile7);
        org.junit.Assert.assertNotNull(sourceFile11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        java.lang.Object[] objArray0 = com.google.javascript.rhino.ScriptRuntime.emptyArgs;
        org.junit.Assert.assertNotNull(objArray0);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        com.google.javascript.rhino.EcmaError ecmaError2 = com.google.javascript.rhino.ScriptRuntime.constructError("100", "Not declared as a constructor");
        java.io.FilenameFilter filenameFilter3 = null;
        java.lang.String str4 = ecmaError2.getScriptStackTrace(filenameFilter3);
        java.lang.String str5 = ecmaError2.toString();
        org.junit.Assert.assertNotNull(ecmaError2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "<No stack trace available>" + "'", str4.equals("<No stack trace available>"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "com.google.javascript.rhino.EcmaError: 100: Not declared as a constructor" + "'", str5.equals("com.google.javascript.rhino.EcmaError: 100: Not declared as a constructor"));
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newString("(STRING  [empty_block: 1])");
        org.junit.Assert.assertNotNull(node1);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newString("");
        int int2 = node1.getSideEffectFlags();
        java.util.Collection<com.google.javascript.rhino.Node> nodeCollection3 = com.google.javascript.jscomp.NodeUtil.getVarsDeclaredInBranch(node1);
        java.lang.String str4 = node1.getString();
        com.google.javascript.rhino.Node node5 = node1.getLastSibling();
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(nodeCollection3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertNotNull(node5);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        int int0 = com.google.javascript.rhino.Node.POST_FLAG;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        int int0 = com.google.javascript.rhino.Context.FEATURE_LOCATION_INFORMATION_IN_ERROR;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.VISIBILITY;
        org.junit.Assert.assertNull(diagnosticGroup0);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        int int0 = com.google.javascript.rhino.Node.TYPE_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 17 + "'", int0 == 17);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.NON_STANDARD_JSDOC;
        com.google.javascript.jscomp.DiagnosticGroups.TWEAKS = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticGroups.ACCESS_CONTROLS = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticGroups.DEPRECATED = diagnosticGroup0;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        java.lang.String str0 = com.google.javascript.rhino.jstype.JSType.EMPTY_TYPE_COMPONENT;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "Named type with empty name component" + "'", str0.equals("Named type with empty name component"));
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node4 = node3.getParent();
        boolean boolean5 = node3.isQuotedString();
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node8 = node7.getParent();
        boolean boolean9 = node7.hasChildren();
        node7.detachChildren();
        java.lang.String str11 = node7.getString();
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node14 = node13.getParent();
        boolean boolean15 = node13.isQuotedString();
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newString("");
        int int18 = node17.getSideEffectFlags();
        boolean boolean19 = node17.isOptionalArg();
        com.google.javascript.rhino.Node node20 = node17.getLastSibling();
        com.google.javascript.rhino.Node node23 = new com.google.javascript.rhino.Node((int) (short) 10, node3, node7, node13, node17, (int) '4', (int) 'a');
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention24 = new com.google.javascript.jscomp.DefaultCodingConvention();
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention25 = new com.google.javascript.jscomp.DefaultCodingConvention();
        java.lang.String str26 = defaultCodingConvention25.getExportSymbolFunction();
        com.google.javascript.rhino.Node node28 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node29 = node28.getParent();
        boolean boolean30 = node28.isQuotedString();
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship31 = defaultCodingConvention25.getDelegateRelationship(node28);
        com.google.javascript.jscomp.CodingConvention.SubclassRelationship subclassRelationship32 = defaultCodingConvention24.getClassesDefinedByCall(node28);
        try {
            com.google.javascript.rhino.Node node35 = new com.google.javascript.rhino.Node(34, node13, node28, 2, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: first new child has existing parent");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNull(node4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertNull(node8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNull(node14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNull(str26);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertNull(node29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNull(delegateRelationship31);
        org.junit.Assert.assertNull(subclassRelationship32);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        com.google.javascript.jscomp.SourceFile.Generator generator1 = null;
        com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromGenerator("hi!", generator1);
        org.junit.Assert.assertNotNull(sourceFile2);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        java.io.File file0 = null;
        java.nio.charset.Charset charset1 = null;
        try {
            com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromFile(file0, charset1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.Compiler.IntermediateState intermediateState1 = compiler0.getState();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile3 = com.google.javascript.jscomp.JSSourceFile.fromFile("(STRING  [empty_block: 1])");
        com.google.javascript.jscomp.SourceFile.Generator generator5 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile6 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("", generator5);
        com.google.javascript.jscomp.CompilerInput compilerInput8 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile6, true);
        java.nio.charset.Charset charset10 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile11 = com.google.javascript.jscomp.JSSourceFile.fromFile("error reporter", charset10);
        com.google.javascript.jscomp.SourceFile.Generator generator13 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile14 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("", generator13);
        com.google.javascript.jscomp.CompilerInput compilerInput16 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile14, true);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile18 = com.google.javascript.jscomp.JSSourceFile.fromFile("(STRING  [empty_block: 1])");
        com.google.javascript.jscomp.SourceFile.Generator generator20 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile21 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("", generator20);
        com.google.javascript.jscomp.CompilerInput compilerInput23 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile21, true);
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray24 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile3, jSSourceFile6, jSSourceFile11, jSSourceFile14, jSSourceFile18, jSSourceFile21 };
        com.google.javascript.jscomp.JSModule[] jSModuleArray25 = new com.google.javascript.jscomp.JSModule[] {};
        com.google.javascript.jscomp.CompilerOptions compilerOptions26 = null;
        try {
            compiler0.init(jSSourceFileArray24, jSModuleArray25, compilerOptions26);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intermediateState1);
        org.junit.Assert.assertNotNull(jSSourceFile3);
        org.junit.Assert.assertNotNull(jSSourceFile6);
        org.junit.Assert.assertNotNull(jSSourceFile11);
        org.junit.Assert.assertNotNull(jSSourceFile14);
        org.junit.Assert.assertNotNull(jSSourceFile18);
        org.junit.Assert.assertNotNull(jSSourceFile21);
        org.junit.Assert.assertNotNull(jSSourceFileArray24);
        org.junit.Assert.assertNotNull(jSModuleArray25);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        int int0 = com.google.javascript.rhino.Node.FINALLY_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 20 + "'", int0 == 20);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.Compiler.IntermediateState intermediateState1 = compiler0.getState();
        com.google.javascript.jscomp.SourceFile.Generator generator3 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile4 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("", generator3);
        com.google.javascript.jscomp.JSModule[] jSModuleArray5 = new com.google.javascript.jscomp.JSModule[] {};
        com.google.javascript.jscomp.CompilerOptions compilerOptions6 = null;
        try {
            com.google.javascript.jscomp.Result result7 = compiler0.compile(jSSourceFile4, jSModuleArray5, compilerOptions6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intermediateState1);
        org.junit.Assert.assertNotNull(jSSourceFile4);
        org.junit.Assert.assertNotNull(jSModuleArray5);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention0 = new com.google.javascript.jscomp.DefaultCodingConvention();
        java.lang.String str1 = defaultCodingConvention0.getExportSymbolFunction();
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node4 = node3.getParent();
        boolean boolean5 = node3.isQuotedString();
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship6 = defaultCodingConvention0.getDelegateRelationship(node3);
        java.util.Collection<com.google.javascript.rhino.Node> nodeCollection7 = com.google.javascript.jscomp.NodeUtil.getVarsDeclaredInBranch(node3);
        node3.setWasEmptyNode(true);
        java.lang.Appendable appendable10 = null;
        try {
            node3.appendStringTree(appendable10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNull(node4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(delegateRelationship6);
        org.junit.Assert.assertNotNull(nodeCollection7);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.Compiler.IntermediateState intermediateState1 = compiler0.getState();
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention3 = new com.google.javascript.jscomp.DefaultCodingConvention();
        java.lang.String str4 = defaultCodingConvention3.getExportSymbolFunction();
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node7 = node6.getParent();
        boolean boolean8 = node6.isQuotedString();
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship9 = defaultCodingConvention3.getDelegateRelationship(node6);
        com.google.javascript.rhino.Node node10 = com.google.javascript.jscomp.NodeUtil.newExpr(node6);
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node13 = node12.getParent();
        boolean boolean14 = node12.isQuotedString();
        com.google.javascript.rhino.Node node17 = new com.google.javascript.rhino.Node(4, node10, node12, 35, 0);
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.Node.newString("");
        int int21 = node20.getSideEffectFlags();
        boolean boolean22 = node20.isOptionalArg();
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention23 = new com.google.javascript.jscomp.DefaultCodingConvention();
        java.lang.String str24 = defaultCodingConvention23.getExportSymbolFunction();
        com.google.javascript.rhino.Node node26 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node27 = node26.getParent();
        boolean boolean28 = node26.isQuotedString();
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship29 = defaultCodingConvention23.getDelegateRelationship(node26);
        com.google.javascript.rhino.Node node30 = com.google.javascript.jscomp.NodeUtil.newExpr(node26);
        com.google.javascript.rhino.Node node33 = new com.google.javascript.rhino.Node((int) (short) 0, node20, node30, (int) (byte) 1, 0);
        com.google.javascript.rhino.Node node34 = node10.clonePropsFrom(node30);
        boolean boolean35 = node10.isSyntheticBlock();
        com.google.javascript.jscomp.NodeTraversal.Callback callback36 = null;
        try {
            com.google.javascript.jscomp.NodeTraversal.traverse((com.google.javascript.jscomp.AbstractCompiler) compiler0, node10, callback36);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: INTERNAL COMPILER ERROR.\nPlease report this problem.\nnull");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(intermediateState1);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNull(node7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNull(delegateRelationship9);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNull(node13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNull(str24);
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertNull(node27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNull(delegateRelationship29);
        org.junit.Assert.assertNotNull(node30);
        org.junit.Assert.assertNotNull(node34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy0 = com.google.javascript.jscomp.PropertyRenamingPolicy.OFF;
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy0 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.OFF + "'", propertyRenamingPolicy0.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.OFF));
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.INVALID_CASTS;
        com.google.javascript.jscomp.DiagnosticGroups.INVALID_CASTS = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticGroups.GLOBAL_THIS = diagnosticGroup0;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        try {
            java.lang.String str1 = com.google.javascript.rhino.ScriptRuntime.getMessage0("window");
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property window");
        } catch (java.lang.RuntimeException e) {
        }
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node4 = node3.getParent();
        boolean boolean5 = node3.isQuotedString();
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node8 = node7.getParent();
        boolean boolean9 = node7.hasChildren();
        node7.detachChildren();
        java.lang.String str11 = node7.getString();
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node14 = node13.getParent();
        boolean boolean15 = node13.isQuotedString();
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newString("");
        int int18 = node17.getSideEffectFlags();
        boolean boolean19 = node17.isOptionalArg();
        com.google.javascript.rhino.Node node20 = node17.getLastSibling();
        com.google.javascript.rhino.Node node23 = new com.google.javascript.rhino.Node((int) (short) 10, node3, node7, node13, node17, (int) '4', (int) 'a');
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention25 = new com.google.javascript.jscomp.DefaultCodingConvention();
        java.lang.String str26 = defaultCodingConvention25.getExportSymbolFunction();
        com.google.javascript.rhino.Node node28 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node29 = node28.getParent();
        boolean boolean30 = node28.isQuotedString();
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship31 = defaultCodingConvention25.getDelegateRelationship(node28);
        com.google.javascript.rhino.Node node32 = com.google.javascript.jscomp.NodeUtil.newExpr(node28);
        com.google.javascript.rhino.Node node34 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node35 = node34.getParent();
        boolean boolean36 = node34.isQuotedString();
        com.google.javascript.rhino.Node node39 = new com.google.javascript.rhino.Node(4, node32, node34, 35, 0);
        try {
            com.google.javascript.rhino.Node node40 = new com.google.javascript.rhino.Node((int) (short) -1, node23, node34);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: second new child has existing parent");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNull(node4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertNull(node8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNull(node14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNull(str26);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertNull(node29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNull(delegateRelationship31);
        org.junit.Assert.assertNotNull(node32);
        org.junit.Assert.assertNotNull(node34);
        org.junit.Assert.assertNull(node35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.CONSTANT_PROPERTY;
        com.google.javascript.jscomp.DiagnosticGroups.CHECK_REGEXP = diagnosticGroup0;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.TYPE_INVALIDATION;
        com.google.javascript.jscomp.DiagnosticGroups.CHECK_VARIABLES = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticGroups.GLOBAL_THIS = diagnosticGroup0;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention1 = new com.google.javascript.jscomp.DefaultCodingConvention();
        java.lang.String str2 = defaultCodingConvention1.getExportSymbolFunction();
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node5 = node4.getParent();
        boolean boolean6 = node4.isQuotedString();
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship7 = defaultCodingConvention1.getDelegateRelationship(node4);
        java.util.Collection<com.google.javascript.rhino.Node> nodeCollection8 = com.google.javascript.jscomp.NodeUtil.getVarsDeclaredInBranch(node4);
        node4.setWasEmptyNode(true);
        com.google.javascript.jscomp.NodeTraversal.Callback callback11 = null;
        try {
            com.google.javascript.jscomp.NodeTraversal.traverse((com.google.javascript.jscomp.AbstractCompiler) compiler0, node4, callback11);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: INTERNAL COMPILER ERROR.\nPlease report this problem.\nnull");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNull(node5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(delegateRelationship7);
        org.junit.Assert.assertNotNull(nodeCollection8);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        int int0 = com.google.javascript.rhino.Node.TARGET_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        java.io.Reader reader1 = null;
        try {
            com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromReader("100", reader1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        com.google.javascript.jscomp.DiagnosticType diagnosticType2 = com.google.javascript.jscomp.DiagnosticType.warning("window", "");
        org.junit.Assert.assertNotNull(diagnosticType2);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        com.google.javascript.jscomp.SourceFile.Generator generator1 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("", generator1);
        com.google.javascript.jscomp.CompilerInput compilerInput4 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2, true);
        com.google.javascript.jscomp.SourceFile sourceFile5 = compilerInput4.getSourceFile();
        try {
            java.lang.String str6 = compilerInput4.getCode();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile2);
        org.junit.Assert.assertNotNull(sourceFile5);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node3 = node2.getParent();
        boolean boolean4 = node2.isQuotedString();
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node7 = node6.getParent();
        boolean boolean8 = node6.hasChildren();
        node6.detachChildren();
        java.lang.String str10 = node6.getString();
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node13 = node12.getParent();
        boolean boolean14 = node12.isQuotedString();
        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.Node.newString("");
        int int17 = node16.getSideEffectFlags();
        boolean boolean18 = node16.isOptionalArg();
        com.google.javascript.rhino.Node node19 = node16.getLastSibling();
        com.google.javascript.rhino.Node node22 = new com.google.javascript.rhino.Node((int) (short) 10, node2, node6, node12, node16, (int) '4', (int) 'a');
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention24 = new com.google.javascript.jscomp.DefaultCodingConvention();
        java.lang.String str25 = defaultCodingConvention24.getExportSymbolFunction();
        com.google.javascript.rhino.Node node27 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node28 = node27.getParent();
        boolean boolean29 = node27.isQuotedString();
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship30 = defaultCodingConvention24.getDelegateRelationship(node27);
        com.google.javascript.rhino.Node node31 = com.google.javascript.jscomp.NodeUtil.newExpr(node27);
        com.google.javascript.rhino.Node node33 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node34 = node33.getParent();
        boolean boolean35 = node33.isQuotedString();
        com.google.javascript.rhino.Node node38 = new com.google.javascript.rhino.Node(4, node31, node33, 35, 0);
        com.google.javascript.rhino.Node node41 = com.google.javascript.rhino.Node.newString("");
        int int42 = node41.getSideEffectFlags();
        boolean boolean43 = node41.isOptionalArg();
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention44 = new com.google.javascript.jscomp.DefaultCodingConvention();
        java.lang.String str45 = defaultCodingConvention44.getExportSymbolFunction();
        com.google.javascript.rhino.Node node47 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node48 = node47.getParent();
        boolean boolean49 = node47.isQuotedString();
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship50 = defaultCodingConvention44.getDelegateRelationship(node47);
        com.google.javascript.rhino.Node node51 = com.google.javascript.jscomp.NodeUtil.newExpr(node47);
        com.google.javascript.rhino.Node node54 = new com.google.javascript.rhino.Node((int) (short) 0, node41, node51, (int) (byte) 1, 0);
        com.google.javascript.rhino.Node node55 = node31.clonePropsFrom(node51);
        com.google.javascript.rhino.Node node57 = com.google.javascript.rhino.Node.newString("");
        int int58 = node57.getSideEffectFlags();
        boolean boolean59 = node57.isOptionalArg();
        com.google.javascript.rhino.Node node60 = node57.getLastSibling();
        try {
            node22.replaceChildAfter(node51, node57);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: prev is not a child of this node.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertNull(node3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNull(node7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNull(node13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNull(str25);
        org.junit.Assert.assertNotNull(node27);
        org.junit.Assert.assertNull(node28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNull(delegateRelationship30);
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertNotNull(node33);
        org.junit.Assert.assertNull(node34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(node41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNull(str45);
        org.junit.Assert.assertNotNull(node47);
        org.junit.Assert.assertNull(node48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNull(delegateRelationship50);
        org.junit.Assert.assertNotNull(node51);
        org.junit.Assert.assertNotNull(node55);
        org.junit.Assert.assertNotNull(node57);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 0 + "'", int58 == 0);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertNotNull(node60);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.Compiler.IntermediateState intermediateState1 = compiler0.getState();
        com.google.javascript.jscomp.SourceFile.Generator generator3 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile4 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("", generator3);
        com.google.javascript.jscomp.CompilerInput compilerInput6 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile4, true);
        com.google.javascript.jscomp.SourceFile.Generator generator8 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile9 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("", generator8);
        com.google.javascript.jscomp.SourceFile.Generator generator11 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile12 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("", generator11);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile14 = com.google.javascript.jscomp.JSSourceFile.fromFile("(STRING  [empty_block: 1])");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile16 = com.google.javascript.jscomp.JSSourceFile.fromFile("(STRING  [empty_block: 1])");
        com.google.javascript.jscomp.SourceFile.Generator generator18 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile19 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("", generator18);
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray20 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile4, jSSourceFile9, jSSourceFile12, jSSourceFile14, jSSourceFile16, jSSourceFile19 };
        com.google.javascript.jscomp.SourceFile.Generator generator22 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile23 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("", generator22);
        com.google.javascript.jscomp.SourceFile.Generator generator25 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile26 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("", generator25);
        com.google.javascript.jscomp.CompilerInput compilerInput28 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile26, true);
        com.google.javascript.jscomp.SourceFile.Generator generator30 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile31 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("", generator30);
        com.google.javascript.jscomp.SourceFile.Generator generator33 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile34 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("", generator33);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile36 = com.google.javascript.jscomp.JSSourceFile.fromFile("(STRING  [empty_block: 1])");
        com.google.javascript.jscomp.SourceFile.Generator generator38 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile39 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("", generator38);
        com.google.javascript.jscomp.CompilerInput compilerInput41 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile39, true);
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray42 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile23, jSSourceFile26, jSSourceFile31, jSSourceFile34, jSSourceFile36, jSSourceFile39 };
        com.google.javascript.jscomp.CompilerOptions compilerOptions43 = null;
        try {
            com.google.javascript.jscomp.Result result44 = compiler0.compile(jSSourceFileArray20, jSSourceFileArray42, compilerOptions43);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intermediateState1);
        org.junit.Assert.assertNotNull(jSSourceFile4);
        org.junit.Assert.assertNotNull(jSSourceFile9);
        org.junit.Assert.assertNotNull(jSSourceFile12);
        org.junit.Assert.assertNotNull(jSSourceFile14);
        org.junit.Assert.assertNotNull(jSSourceFile16);
        org.junit.Assert.assertNotNull(jSSourceFile19);
        org.junit.Assert.assertNotNull(jSSourceFileArray20);
        org.junit.Assert.assertNotNull(jSSourceFile23);
        org.junit.Assert.assertNotNull(jSSourceFile26);
        org.junit.Assert.assertNotNull(jSSourceFile31);
        org.junit.Assert.assertNotNull(jSSourceFile34);
        org.junit.Assert.assertNotNull(jSSourceFile36);
        org.junit.Assert.assertNotNull(jSSourceFile39);
        org.junit.Assert.assertNotNull(jSSourceFileArray42);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        int int0 = com.google.javascript.rhino.Node.MEMBER_TYPE_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 32 + "'", int0 == 32);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        int int0 = com.google.javascript.rhino.Node.DIRECTCALL_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 26 + "'", int0 == 26);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        com.google.javascript.jscomp.JSModule jSModule0 = null;
        com.google.javascript.jscomp.JSModule[] jSModuleArray1 = new com.google.javascript.jscomp.JSModule[] { jSModule0 };
        try {
            com.google.javascript.jscomp.JSModuleGraph jSModuleGraph2 = new com.google.javascript.jscomp.JSModuleGraph(jSModuleArray1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jSModuleArray1);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.JSError jSError2 = null;
        try {
            com.google.javascript.jscomp.CheckLevel checkLevel3 = compiler1.getErrorLevel(jSError2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        com.google.javascript.jscomp.JSModule[] jSModuleArray0 = new com.google.javascript.jscomp.JSModule[] {};
        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList1 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList1, jSModuleArray0);
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph3 = new com.google.javascript.jscomp.JSModuleGraph((java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList1);
        com.google.javascript.jscomp.JSModule[] jSModuleArray4 = new com.google.javascript.jscomp.JSModule[] {};
        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList5 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
        boolean boolean6 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList5, jSModuleArray4);
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph7 = new com.google.javascript.jscomp.JSModuleGraph((java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList5);
        try {
            com.google.javascript.jscomp.JSModule jSModule8 = jSModuleGraph3.getDeepestCommonDependencyInclusive((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList5);
            org.junit.Assert.fail("Expected exception of type java.util.NoSuchElementException; message: null");
        } catch (java.util.NoSuchElementException e) {
        }
        org.junit.Assert.assertNotNull(jSModuleArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(jSModuleArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newString("");
        int int2 = node1.getSideEffectFlags();
        boolean boolean3 = node1.isOptionalArg();
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newString("");
        int int6 = node5.getSideEffectFlags();
        boolean boolean7 = node5.isOptionalArg();
        boolean boolean8 = node5.isQuotedString();
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention9 = new com.google.javascript.jscomp.DefaultCodingConvention();
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention10 = new com.google.javascript.jscomp.DefaultCodingConvention();
        java.lang.String str11 = defaultCodingConvention10.getExportSymbolFunction();
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node14 = node13.getParent();
        boolean boolean15 = node13.isQuotedString();
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship16 = defaultCodingConvention10.getDelegateRelationship(node13);
        com.google.javascript.jscomp.CodingConvention.SubclassRelationship subclassRelationship17 = defaultCodingConvention9.getClassesDefinedByCall(node13);
        boolean boolean18 = node5.isEquivalentToTyped(node13);
        boolean boolean19 = node1.isEquivalentToTyped(node13);
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNull(str11);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNull(node14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNull(delegateRelationship16);
        org.junit.Assert.assertNull(subclassRelationship17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        try {
            com.google.javascript.jscomp.Result result2 = compiler1.getResult();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        java.lang.String str1 = com.google.javascript.rhino.ScriptRuntime.toString((java.lang.Object) 16);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "16" + "'", str1.equals("16"));
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node2 = node1.getParent();
        com.google.javascript.rhino.Node.AncestorIterable ancestorIterable3 = node1.getAncestors();
        java.util.Iterator<com.google.javascript.rhino.Node> nodeItor4 = ancestorIterable3.iterator();
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertNull(node2);
        org.junit.Assert.assertNotNull(ancestorIterable3);
        org.junit.Assert.assertNotNull(nodeItor4);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention0 = new com.google.javascript.jscomp.DefaultCodingConvention();
        java.lang.String str1 = defaultCodingConvention0.getGlobalObject();
        boolean boolean3 = defaultCodingConvention0.isExported("hi!");
        com.google.javascript.jscomp.NodeTraversal nodeTraversal4 = null;
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString("");
        int int7 = node6.getSideEffectFlags();
        boolean boolean8 = node6.isOptionalArg();
        boolean boolean9 = node6.isQuotedString();
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention10 = new com.google.javascript.jscomp.DefaultCodingConvention();
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention11 = new com.google.javascript.jscomp.DefaultCodingConvention();
        java.lang.String str12 = defaultCodingConvention11.getExportSymbolFunction();
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node15 = node14.getParent();
        boolean boolean16 = node14.isQuotedString();
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship17 = defaultCodingConvention11.getDelegateRelationship(node14);
        com.google.javascript.jscomp.CodingConvention.SubclassRelationship subclassRelationship18 = defaultCodingConvention10.getClassesDefinedByCall(node14);
        boolean boolean19 = node6.isEquivalentToTyped(node14);
        com.google.javascript.jscomp.CodingConvention.ObjectLiteralCast objectLiteralCast20 = defaultCodingConvention0.getObjectLiteralCast(nodeTraversal4, node14);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "window" + "'", str1.equals("window"));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNull(node15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNull(delegateRelationship17);
        org.junit.Assert.assertNull(subclassRelationship18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNull(objectLiteralCast20);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        int int0 = com.google.javascript.rhino.Node.OPT_ARG_NAME;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 36 + "'", int0 == 36);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        com.google.javascript.jscomp.SourceFile.Generator generator1 = null;
        com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromGenerator("", generator1);
        java.lang.String str3 = sourceFile2.getOriginalPath();
        com.google.javascript.jscomp.JsAst jsAst4 = new com.google.javascript.jscomp.JsAst(sourceFile2);
        com.google.javascript.jscomp.SourceFile sourceFile5 = jsAst4.getSourceFile();
        com.google.javascript.jscomp.SourceFile.Generator generator7 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile8 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("", generator7);
        com.google.javascript.jscomp.CompilerInput compilerInput10 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile8, true);
        java.nio.charset.Charset charset12 = null;
        com.google.javascript.jscomp.SourceFile sourceFile13 = com.google.javascript.jscomp.SourceFile.fromFile("", charset12);
        compilerInput10.setSourceFile(sourceFile13);
        jsAst4.setSourceFile(sourceFile13);
        org.junit.Assert.assertNotNull(sourceFile2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
        org.junit.Assert.assertNotNull(sourceFile5);
        org.junit.Assert.assertNotNull(jSSourceFile8);
        org.junit.Assert.assertNotNull(sourceFile13);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        int int0 = com.google.javascript.rhino.Node.FUNCTION_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 5 + "'", int0 == 5);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        java.lang.String str1 = com.google.javascript.rhino.jstype.ObjectType.createDelegateSuffix("");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "()" + "'", str1.equals("()"));
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        int int0 = com.google.javascript.rhino.Node.LOCAL_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 7 + "'", int0 == 7);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        try {
            java.lang.String str1 = com.google.javascript.rhino.ScriptRuntime.getMessage0("()");
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property ()");
        } catch (java.lang.RuntimeException e) {
        }
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        java.lang.String str1 = com.google.javascript.rhino.ScriptRuntime.escapeString("language version");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "language version" + "'", str1.equals("language version"));
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        com.google.javascript.jscomp.CompilerOptions.TweakProcessing tweakProcessing0 = com.google.javascript.jscomp.CompilerOptions.TweakProcessing.STRIP;
        org.junit.Assert.assertTrue("'" + tweakProcessing0 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TweakProcessing.STRIP + "'", tweakProcessing0.equals(com.google.javascript.jscomp.CompilerOptions.TweakProcessing.STRIP));
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        int int0 = com.google.javascript.rhino.Node.COLUMN_MASK;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4095 + "'", int0 == 4095);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        int int0 = com.google.javascript.rhino.Context.VERSION_1_1;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 110 + "'", int0 == 110);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention1 = new com.google.javascript.jscomp.DefaultCodingConvention();
        java.lang.String str2 = defaultCodingConvention1.getExportSymbolFunction();
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node5 = node4.getParent();
        boolean boolean6 = node4.isQuotedString();
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship7 = defaultCodingConvention1.getDelegateRelationship(node4);
        java.util.Collection<com.google.javascript.rhino.Node> nodeCollection8 = com.google.javascript.jscomp.NodeUtil.getVarsDeclaredInBranch(node4);
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention10 = new com.google.javascript.jscomp.DefaultCodingConvention();
        java.lang.String str11 = defaultCodingConvention10.getExportSymbolFunction();
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node14 = node13.getParent();
        boolean boolean15 = node13.isQuotedString();
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship16 = defaultCodingConvention10.getDelegateRelationship(node13);
        com.google.javascript.rhino.Node node17 = com.google.javascript.jscomp.NodeUtil.newExpr(node13);
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node20 = node19.getParent();
        boolean boolean21 = node19.isQuotedString();
        com.google.javascript.rhino.Node node24 = new com.google.javascript.rhino.Node(4, node17, node19, 35, 0);
        com.google.javascript.rhino.Node node27 = com.google.javascript.rhino.Node.newString("");
        int int28 = node27.getSideEffectFlags();
        boolean boolean29 = node27.isOptionalArg();
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention30 = new com.google.javascript.jscomp.DefaultCodingConvention();
        java.lang.String str31 = defaultCodingConvention30.getExportSymbolFunction();
        com.google.javascript.rhino.Node node33 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node34 = node33.getParent();
        boolean boolean35 = node33.isQuotedString();
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship36 = defaultCodingConvention30.getDelegateRelationship(node33);
        com.google.javascript.rhino.Node node37 = com.google.javascript.jscomp.NodeUtil.newExpr(node33);
        com.google.javascript.rhino.Node node40 = new com.google.javascript.rhino.Node((int) (short) 0, node27, node37, (int) (byte) 1, 0);
        com.google.javascript.rhino.Node node41 = node17.clonePropsFrom(node37);
        com.google.javascript.rhino.Node[] nodeArray42 = new com.google.javascript.rhino.Node[] { node4, node17 };
        try {
            com.google.javascript.rhino.Node node43 = new com.google.javascript.rhino.Node(15, nodeArray42);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNull(node5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(delegateRelationship7);
        org.junit.Assert.assertNotNull(nodeCollection8);
        org.junit.Assert.assertNull(str11);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNull(node14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNull(delegateRelationship16);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNull(node20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(node27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNull(str31);
        org.junit.Assert.assertNotNull(node33);
        org.junit.Assert.assertNull(node34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNull(delegateRelationship36);
        org.junit.Assert.assertNotNull(node37);
        org.junit.Assert.assertNotNull(node41);
        org.junit.Assert.assertNotNull(nodeArray42);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.Compiler.IntermediateState intermediateState1 = compiler0.getState();
        com.google.javascript.jscomp.CompilerOptions compilerOptions2 = null;
        try {
            compiler0.initOptions(compilerOptions2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intermediateState1);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        try {
            boolean boolean2 = compiler1.acceptConstKeyword();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile3 = com.google.javascript.jscomp.JSSourceFile.fromFile("(STRING  [empty_block: 1])");
        com.google.javascript.jscomp.SourceFile.Generator generator5 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile6 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("Not declared as a constructor", generator5);
        com.google.javascript.jscomp.SourceFile.Generator generator8 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile9 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("Not declared as a constructor", generator8);
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray10 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile6, jSSourceFile9 };
        com.google.javascript.jscomp.CompilerOptions compilerOptions11 = null;
        try {
            com.google.javascript.jscomp.Result result12 = compiler1.compile(jSSourceFile3, jSSourceFileArray10, compilerOptions11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile3);
        org.junit.Assert.assertNotNull(jSSourceFile6);
        org.junit.Assert.assertNotNull(jSSourceFile9);
        org.junit.Assert.assertNotNull(jSSourceFileArray10);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        int int0 = com.google.javascript.rhino.Node.SIDE_EFFECTS_FLAGS_MASK;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 31 + "'", int0 == 31);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node2 = node1.getParent();
        java.lang.String str3 = node1.getQualifiedName();
        java.lang.Appendable appendable4 = null;
        try {
            node1.appendStringTree(appendable4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertNull(node2);
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.CompilerOptions compilerOptions1 = null;
        try {
            compiler0.initOptions(compilerOptions1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        int int0 = com.google.javascript.rhino.Node.NON_SPECIALCALL;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        int int0 = com.google.javascript.rhino.Node.SIDE_EFFECTS_ALL;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newString("");
        int int2 = node1.getSideEffectFlags();
        boolean boolean3 = node1.isOptionalArg();
        boolean boolean4 = node1.isQuotedString();
        node1.setWasEmptyNode(false);
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

//    @Test
//    public void test214() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test214");
//        try {
//            com.google.javascript.rhino.EvaluatorException evaluatorException1 = com.google.javascript.rhino.Context.reportRuntimeError("neg");
//            org.junit.Assert.fail("Expected exception of type com.google.javascript.rhino.EvaluatorException; message: neg");
//        } catch (com.google.javascript.rhino.EvaluatorException e) {
//        }
//    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        int int0 = com.google.javascript.rhino.Node.SPECIALCALL_WITH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        try {
            com.google.javascript.jscomp.CompilerInput compilerInput3 = compiler1.newExternInput("100");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        com.google.javascript.rhino.Context context0 = com.google.javascript.rhino.Context.enter();
        context0.setCompileFunctionsWithDynamicScope(true);
        org.junit.Assert.assertNotNull(context0);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        com.google.javascript.jscomp.DiagnosticGroup[] diagnosticGroupArray1 = null;
        try {
            com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup2 = new com.google.javascript.jscomp.DiagnosticGroup("100", diagnosticGroupArray1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        int int0 = com.google.javascript.rhino.Node.TARGETBLOCK_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 22 + "'", int0 == 22);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node4 = node3.getParent();
        boolean boolean5 = node3.isQuotedString();
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node8 = node7.getParent();
        boolean boolean9 = node7.hasChildren();
        node7.detachChildren();
        java.lang.String str11 = node7.getString();
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node14 = node13.getParent();
        boolean boolean15 = node13.isQuotedString();
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newString("");
        int int18 = node17.getSideEffectFlags();
        boolean boolean19 = node17.isOptionalArg();
        com.google.javascript.rhino.Node node20 = node17.getLastSibling();
        com.google.javascript.rhino.Node node23 = new com.google.javascript.rhino.Node((int) (short) 10, node3, node7, node13, node17, (int) '4', (int) 'a');
        try {
            com.google.javascript.rhino.Node node24 = new com.google.javascript.rhino.Node((-2), node17);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: new child has existing parent");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNull(node4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertNull(node8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNull(node14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(node20);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        try {
            com.google.javascript.rhino.Context.checkOptimizationLevel(16);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Optimization level outside [-1..9]: 16");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromCode("error reporter", "<No stack trace available>");
        org.junit.Assert.assertNotNull(sourceFile2);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.SourceFile.Generator generator3 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile4 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("", generator3);
        java.nio.charset.Charset charset6 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile7 = com.google.javascript.jscomp.JSSourceFile.fromFile("error reporter", charset6);
        com.google.javascript.jscomp.SourceFile.Generator generator9 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile10 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("", generator9);
        com.google.javascript.jscomp.CompilerInput compilerInput12 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile10, true);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile14 = com.google.javascript.jscomp.JSSourceFile.fromFile("(STRING  [empty_block: 1])");
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray15 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile4, jSSourceFile7, jSSourceFile10, jSSourceFile14 };
        java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList16 = new java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile>();
        boolean boolean17 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList16, jSSourceFileArray15);
        com.google.javascript.jscomp.JSModule[] jSModuleArray18 = new com.google.javascript.jscomp.JSModule[] {};
        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList19 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
        boolean boolean20 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList19, jSModuleArray18);
        com.google.javascript.jscomp.CompilerOptions compilerOptions21 = null;
        try {
            com.google.javascript.jscomp.Result result22 = compiler1.compileModules((java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList16, (java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList19, compilerOptions21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile4);
        org.junit.Assert.assertNotNull(jSSourceFile7);
        org.junit.Assert.assertNotNull(jSSourceFile10);
        org.junit.Assert.assertNotNull(jSSourceFile14);
        org.junit.Assert.assertNotNull(jSSourceFileArray15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(jSModuleArray18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node2 = node1.getParent();
        boolean boolean3 = node1.isQuotedString();
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention4 = new com.google.javascript.jscomp.DefaultCodingConvention();
        java.lang.String str5 = defaultCodingConvention4.getExportSymbolFunction();
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node8 = node7.getParent();
        boolean boolean9 = node7.isQuotedString();
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship10 = defaultCodingConvention4.getDelegateRelationship(node7);
        java.util.Collection<com.google.javascript.rhino.Node> nodeCollection11 = com.google.javascript.jscomp.NodeUtil.getVarsDeclaredInBranch(node7);
        com.google.javascript.rhino.JSDocInfo jSDocInfo12 = node7.getJSDocInfo();
        com.google.javascript.rhino.Node node13 = node1.copyInformationFromForTree(node7);
        boolean boolean14 = node7.hasSideEffects();
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertNull(node2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertNull(node8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(delegateRelationship10);
        org.junit.Assert.assertNotNull(nodeCollection11);
        org.junit.Assert.assertNull(jSDocInfo12);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        int int0 = com.google.javascript.rhino.Node.COLUMN_BITS;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 12 + "'", int0 == 12);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        com.google.javascript.jscomp.parsing.Config config1 = com.google.javascript.jscomp.parsing.ParserRunner.createConfig(false);
        org.junit.Assert.assertNotNull(config1);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        int int0 = com.google.javascript.rhino.Node.USES_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 11 + "'", int0 == 11);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node2 = node1.getParent();
        boolean boolean3 = node1.hasChildren();
        node1.detachChildren();
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder5 = node1.getJsDocBuilderForNode();
        fileLevelJsDocBuilder5.append("");
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertNull(node2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder5);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.Compiler.IntermediateState intermediateState1 = compiler0.getState();
        com.google.javascript.jscomp.JSModule jSModule2 = null;
        try {
            java.lang.String str3 = compiler0.toSource(jSModule2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intermediateState1);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        try {
            java.lang.String str2 = com.google.javascript.rhino.ScriptRuntime.getMessage1("<No stack trace available>", (java.lang.Object) 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property <No stack trace available>");
        } catch (java.lang.RuntimeException e) {
        }
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        int int0 = com.google.javascript.rhino.Node.BRACELESS_TYPE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 40 + "'", int0 == 40);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node2 = node1.getParent();
        boolean boolean3 = node1.hasChildren();
        node1.detachChildren();
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder5 = node1.getJsDocBuilderForNode();
        fileLevelJsDocBuilder5.append("language version");
        fileLevelJsDocBuilder5.append("neg");
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertNull(node2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder5);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        com.google.javascript.jscomp.CompilerOptions.TweakProcessing tweakProcessing0 = com.google.javascript.jscomp.CompilerOptions.TweakProcessing.OFF;
        org.junit.Assert.assertTrue("'" + tweakProcessing0 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TweakProcessing.OFF + "'", tweakProcessing0.equals(com.google.javascript.jscomp.CompilerOptions.TweakProcessing.OFF));
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node2 = node1.getParent();
        java.lang.String str3 = node1.getQualifiedName();
        com.google.javascript.rhino.EvaluatorException evaluatorException6 = new com.google.javascript.rhino.EvaluatorException("error reporter");
        node1.putProp((int) (byte) 1, (java.lang.Object) evaluatorException6);
        com.google.javascript.rhino.Node node8 = node1.getLastChild();
        try {
            node8.setDouble((double) 18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertNull(node2);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNull(node8);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.SourceFile.Generator generator2 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile3 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("", generator2);
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray4 = null;
        com.google.javascript.jscomp.CompilerOptions compilerOptions5 = null;
        try {
            com.google.javascript.jscomp.Result result6 = compiler0.compile(jSSourceFile3, jSSourceFileArray4, compilerOptions5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile3);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node2 = node1.getParent();
        com.google.javascript.rhino.Node.AncestorIterable ancestorIterable3 = node1.getAncestors();
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node6 = node5.getParent();
        boolean boolean7 = node5.isQuotedString();
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention8 = new com.google.javascript.jscomp.DefaultCodingConvention();
        java.lang.String str9 = defaultCodingConvention8.getExportSymbolFunction();
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node12 = node11.getParent();
        boolean boolean13 = node11.isQuotedString();
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship14 = defaultCodingConvention8.getDelegateRelationship(node11);
        java.util.Collection<com.google.javascript.rhino.Node> nodeCollection15 = com.google.javascript.jscomp.NodeUtil.getVarsDeclaredInBranch(node11);
        com.google.javascript.rhino.JSDocInfo jSDocInfo16 = node11.getJSDocInfo();
        com.google.javascript.rhino.Node node17 = node5.copyInformationFromForTree(node11);
        node1.addChildToBack(node11);
        try {
            int int20 = node11.getExistingIntProp(110);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: FAILED ASSERTION");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertNull(node2);
        org.junit.Assert.assertNotNull(ancestorIterable3);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNull(node6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertNull(node12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNull(delegateRelationship14);
        org.junit.Assert.assertNotNull(nodeCollection15);
        org.junit.Assert.assertNull(jSDocInfo16);
        org.junit.Assert.assertNotNull(node17);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node2 = node1.getParent();
        boolean boolean3 = node1.hasChildren();
        node1.detachChildren();
        java.lang.String str5 = node1.getString();
        boolean boolean6 = node1.isQualifiedName();
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertNull(node2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

//    @Test
//    public void test238() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test238");
//        try {
//            com.google.javascript.rhino.Context.reportError("language version");
//            org.junit.Assert.fail("Expected exception of type com.google.javascript.rhino.EvaluatorException; message: language version");
//        } catch (com.google.javascript.rhino.EvaluatorException e) {
//        }
//    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention0 = new com.google.javascript.jscomp.DefaultCodingConvention();
        java.lang.String str1 = defaultCodingConvention0.getGlobalObject();
        boolean boolean3 = defaultCodingConvention0.isExported("hi!");
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node6 = node5.getParent();
        try {
            boolean boolean7 = defaultCodingConvention0.isVarArgsParameter(node6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "window" + "'", str1.equals("window"));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNull(node6);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention0 = new com.google.javascript.jscomp.DefaultCodingConvention();
        java.lang.String str1 = defaultCodingConvention0.getExportSymbolFunction();
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node4 = node3.getParent();
        boolean boolean5 = node3.isQuotedString();
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship6 = defaultCodingConvention0.getDelegateRelationship(node3);
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node10 = node9.getParent();
        boolean boolean11 = node9.isQuotedString();
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node14 = node13.getParent();
        boolean boolean15 = node13.hasChildren();
        node13.detachChildren();
        java.lang.String str17 = node13.getString();
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node20 = node19.getParent();
        boolean boolean21 = node19.isQuotedString();
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newString("");
        int int24 = node23.getSideEffectFlags();
        boolean boolean25 = node23.isOptionalArg();
        com.google.javascript.rhino.Node node26 = node23.getLastSibling();
        com.google.javascript.rhino.Node node29 = new com.google.javascript.rhino.Node((int) (short) 10, node9, node13, node19, node23, (int) '4', (int) 'a');
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention31 = new com.google.javascript.jscomp.DefaultCodingConvention();
        java.lang.String str32 = defaultCodingConvention31.getExportSymbolFunction();
        com.google.javascript.rhino.Node node34 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node35 = node34.getParent();
        boolean boolean36 = node34.isQuotedString();
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship37 = defaultCodingConvention31.getDelegateRelationship(node34);
        com.google.javascript.rhino.Node node38 = com.google.javascript.jscomp.NodeUtil.newExpr(node34);
        com.google.javascript.rhino.Node node40 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node41 = node40.getParent();
        boolean boolean42 = node40.isQuotedString();
        com.google.javascript.rhino.Node node45 = new com.google.javascript.rhino.Node(4, node38, node40, 35, 0);
        try {
            node3.addChildAfter(node23, node38);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The new child node already has a parent.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNull(node4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(delegateRelationship6);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNull(node10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNull(node14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNull(node20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertNull(str32);
        org.junit.Assert.assertNotNull(node34);
        org.junit.Assert.assertNull(node35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNull(delegateRelationship37);
        org.junit.Assert.assertNotNull(node38);
        org.junit.Assert.assertNotNull(node40);
        org.junit.Assert.assertNull(node41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        com.google.javascript.rhino.Node.SideEffectFlags sideEffectFlags1 = new com.google.javascript.rhino.Node.SideEffectFlags((int) ' ');
        sideEffectFlags1.setReturnsTainted();
        int int3 = sideEffectFlags1.valueOf();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 32 + "'", int3 == 32);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.SourceFile.Generator generator3 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile4 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("", generator3);
        com.google.javascript.jscomp.SourceFile.Generator generator6 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile7 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("", generator6);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile9 = com.google.javascript.jscomp.JSSourceFile.fromFile("(STRING  [empty_block: 1])");
        java.nio.charset.Charset charset11 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile12 = com.google.javascript.jscomp.JSSourceFile.fromFile("error reporter", charset11);
        com.google.javascript.jscomp.SourceFile.Generator generator14 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile15 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("", generator14);
        com.google.javascript.jscomp.CompilerInput compilerInput17 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile15, true);
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray18 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile7, jSSourceFile9, jSSourceFile12, jSSourceFile15 };
        com.google.javascript.jscomp.CompilerOptions compilerOptions19 = null;
        try {
            com.google.javascript.jscomp.Result result20 = compiler1.compile(jSSourceFile4, jSSourceFileArray18, compilerOptions19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile4);
        org.junit.Assert.assertNotNull(jSSourceFile7);
        org.junit.Assert.assertNotNull(jSSourceFile9);
        org.junit.Assert.assertNotNull(jSSourceFile12);
        org.junit.Assert.assertNotNull(jSSourceFile15);
        org.junit.Assert.assertNotNull(jSSourceFileArray18);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        int int0 = com.google.javascript.rhino.Context.FEATURE_STRICT_EVAL;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 9 + "'", int0 == 9);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        com.google.javascript.jscomp.DiagnosticType diagnosticType2 = com.google.javascript.jscomp.DiagnosticType.warning("hi!", "100");
        java.lang.String str3 = diagnosticType2.key;
        org.junit.Assert.assertNotNull(diagnosticType2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "hi!" + "'", str3.equals("hi!"));
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        com.google.javascript.jscomp.SourceMap.Format format0 = com.google.javascript.jscomp.SourceMap.Format.DEFAULT;
        org.junit.Assert.assertNotNull(format0);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.Compiler.IntermediateState intermediateState1 = compiler0.getState();
        java.nio.charset.Charset charset3 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile4 = com.google.javascript.jscomp.JSSourceFile.fromFile("error reporter", charset3);
        java.nio.charset.Charset charset6 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile7 = com.google.javascript.jscomp.JSSourceFile.fromFile("error reporter", charset6);
        com.google.javascript.jscomp.SourceFile.Generator generator9 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile10 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("Not declared as a constructor", generator9);
        com.google.javascript.jscomp.SourceFile.Generator generator12 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile13 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("", generator12);
        com.google.javascript.jscomp.CompilerInput compilerInput15 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile13, true);
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray16 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile4, jSSourceFile7, jSSourceFile10, jSSourceFile13 };
        com.google.javascript.jscomp.SourceFile.Generator generator18 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile19 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("Not declared as a constructor", generator18);
        com.google.javascript.jscomp.SourceFile.Generator generator21 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile22 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("", generator21);
        com.google.javascript.jscomp.CompilerInput compilerInput24 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile22, true);
        java.nio.charset.Charset charset26 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile27 = com.google.javascript.jscomp.JSSourceFile.fromFile("error reporter", charset26);
        com.google.javascript.jscomp.SourceFile.Generator generator29 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile30 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("Not declared as a constructor", generator29);
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray31 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile19, jSSourceFile22, jSSourceFile27, jSSourceFile30 };
        com.google.javascript.jscomp.CompilerOptions compilerOptions32 = null;
        try {
            com.google.javascript.jscomp.Result result33 = compiler0.compile(jSSourceFileArray16, jSSourceFileArray31, compilerOptions32);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intermediateState1);
        org.junit.Assert.assertNotNull(jSSourceFile4);
        org.junit.Assert.assertNotNull(jSSourceFile7);
        org.junit.Assert.assertNotNull(jSSourceFile10);
        org.junit.Assert.assertNotNull(jSSourceFile13);
        org.junit.Assert.assertNotNull(jSSourceFileArray16);
        org.junit.Assert.assertNotNull(jSSourceFile19);
        org.junit.Assert.assertNotNull(jSSourceFile22);
        org.junit.Assert.assertNotNull(jSSourceFile27);
        org.junit.Assert.assertNotNull(jSSourceFile30);
        org.junit.Assert.assertNotNull(jSSourceFileArray31);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        try {
            com.google.javascript.rhino.EcmaError ecmaError3 = com.google.javascript.rhino.ScriptRuntime.typeError2("16", "neg", "(STRING  [empty_block: 1])");
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property 16");
        } catch (java.lang.RuntimeException e) {
        }
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        java.lang.Double double0 = com.google.javascript.rhino.ScriptRuntime.NaNobj;
        org.junit.Assert.assertEquals((double) double0, Double.NaN, 0);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention1 = new com.google.javascript.jscomp.DefaultCodingConvention();
        java.lang.String str2 = defaultCodingConvention1.getExportSymbolFunction();
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node5 = node4.getParent();
        boolean boolean6 = node4.isQuotedString();
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship7 = defaultCodingConvention1.getDelegateRelationship(node4);
        com.google.javascript.rhino.Node node8 = com.google.javascript.jscomp.NodeUtil.newExpr(node4);
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention9 = new com.google.javascript.jscomp.DefaultCodingConvention();
        java.lang.String str10 = defaultCodingConvention9.getExportSymbolFunction();
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node13 = node12.getParent();
        boolean boolean14 = node12.isQuotedString();
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship15 = defaultCodingConvention9.getDelegateRelationship(node12);
        java.util.Collection<com.google.javascript.rhino.Node> nodeCollection16 = com.google.javascript.jscomp.NodeUtil.getVarsDeclaredInBranch(node12);
        node12.setWasEmptyNode(true);
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node21 = node20.getNext();
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention22 = new com.google.javascript.jscomp.DefaultCodingConvention();
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention23 = new com.google.javascript.jscomp.DefaultCodingConvention();
        java.lang.String str24 = defaultCodingConvention23.getExportSymbolFunction();
        com.google.javascript.rhino.Node node26 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node27 = node26.getParent();
        boolean boolean28 = node26.isQuotedString();
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship29 = defaultCodingConvention23.getDelegateRelationship(node26);
        com.google.javascript.jscomp.CodingConvention.SubclassRelationship subclassRelationship30 = defaultCodingConvention22.getClassesDefinedByCall(node26);
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention32 = new com.google.javascript.jscomp.DefaultCodingConvention();
        java.lang.String str33 = defaultCodingConvention32.getExportSymbolFunction();
        com.google.javascript.rhino.Node node35 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node36 = node35.getParent();
        boolean boolean37 = node35.isQuotedString();
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship38 = defaultCodingConvention32.getDelegateRelationship(node35);
        com.google.javascript.rhino.Node node39 = com.google.javascript.jscomp.NodeUtil.newExpr(node35);
        com.google.javascript.rhino.Node node41 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node42 = node41.getParent();
        boolean boolean43 = node41.isQuotedString();
        com.google.javascript.rhino.Node node46 = new com.google.javascript.rhino.Node(4, node39, node41, 35, 0);
        java.lang.String str47 = defaultCodingConvention22.getSingletonGetterClassName(node41);
        com.google.javascript.rhino.Node node48 = node41.getFirstChild();
        try {
            com.google.javascript.rhino.Node node51 = new com.google.javascript.rhino.Node(2, node8, node12, node21, node41, 0, 160);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNull(node5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(delegateRelationship7);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNull(node13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNull(delegateRelationship15);
        org.junit.Assert.assertNotNull(nodeCollection16);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNull(node21);
        org.junit.Assert.assertNull(str24);
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertNull(node27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNull(delegateRelationship29);
        org.junit.Assert.assertNull(subclassRelationship30);
        org.junit.Assert.assertNull(str33);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertNull(node36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNull(delegateRelationship38);
        org.junit.Assert.assertNotNull(node39);
        org.junit.Assert.assertNotNull(node41);
        org.junit.Assert.assertNull(node42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNull(str47);
        org.junit.Assert.assertNull(node48);
    }

//    @Test
//    public void test250() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test250");
//        try {
//            com.google.javascript.rhino.Context.exit();
//            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Calling Context.exit without previous Context.enter");
//        } catch (java.lang.RuntimeException e) {
//        }
//    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        com.google.javascript.jscomp.SourceFile.Generator generator1 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("", generator1);
        com.google.javascript.jscomp.CompilerInput compilerInput4 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2, true);
        com.google.javascript.jscomp.SourceFile sourceFile5 = compilerInput4.getSourceFile();
        com.google.javascript.jscomp.SourceFile sourceFile6 = compilerInput4.getSourceFile();
        try {
            java.util.Collection<java.lang.String> strCollection7 = compilerInput4.getRequires();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Expected setErrorManager to be called first");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile2);
        org.junit.Assert.assertNotNull(sourceFile5);
        org.junit.Assert.assertNotNull(sourceFile6);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        com.google.javascript.rhino.EcmaError ecmaError2 = com.google.javascript.rhino.ScriptRuntime.constructError("100", "Not declared as a constructor");
        java.lang.String str3 = ecmaError2.getScriptStackTrace();
        java.lang.String str4 = ecmaError2.lineSource();
        ecmaError2.initSourceName("16");
        org.junit.Assert.assertNotNull(ecmaError2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "<No stack trace available>" + "'", str3.equals("<No stack trace available>"));
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        com.google.javascript.rhino.Context context0 = null;
        com.google.javascript.rhino.Context context1 = com.google.javascript.rhino.Context.enter(context0);
        boolean boolean2 = context1.isGeneratingDebugChanged();
        java.beans.PropertyChangeListener propertyChangeListener3 = null;
        try {
            context1.removePropertyChangeListener(propertyChangeListener3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(context1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        int int0 = com.google.javascript.rhino.Context.VERSION_UNKNOWN;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + (-1) + "'", int0 == (-1));
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.Node.newString("");
        int int3 = node2.getSideEffectFlags();
        boolean boolean4 = node2.isOptionalArg();
        com.google.javascript.rhino.Node node5 = node2.getLastSibling();
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node8 = node7.getParent();
        com.google.javascript.rhino.Node.AncestorIterable ancestorIterable9 = node7.getAncestors();
        com.google.javascript.rhino.Node node10 = new com.google.javascript.rhino.Node((int) (byte) 1, node5, node7);
        boolean boolean11 = node10.hasMoreThanOneChild();
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertNull(node8);
        org.junit.Assert.assertNotNull(ancestorIterable9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node2 = node1.getParent();
        boolean boolean3 = node1.hasChildren();
        node1.detachChildren();
        java.lang.String str5 = node1.getString();
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable6 = node1.children();
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertNull(node2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertNotNull(nodeIterable6);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        com.google.javascript.jscomp.SourceFile.Generator generator1 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("", generator1);
        com.google.javascript.jscomp.CompilerInput compilerInput4 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2, true);
        java.util.logging.Logger logger5 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager6 = new com.google.javascript.jscomp.LoggerErrorManager(logger5);
        compilerInput4.setErrorManager((com.google.javascript.jscomp.ErrorManager) loggerErrorManager6);
        com.google.javascript.jscomp.SourceFile sourceFile10 = com.google.javascript.jscomp.SourceFile.fromCode("", "21");
        compilerInput4.setSourceFile(sourceFile10);
        org.junit.Assert.assertNotNull(jSSourceFile2);
        org.junit.Assert.assertNotNull(sourceFile10);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        com.google.javascript.jscomp.SourceFile.Generator generator1 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("", generator1);
        com.google.javascript.jscomp.CompilerInput compilerInput4 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2, true);
        com.google.javascript.jscomp.SourceFile sourceFile5 = compilerInput4.getSourceFile();
        try {
            java.lang.String str7 = compilerInput4.getLine(29);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile2);
        org.junit.Assert.assertNotNull(sourceFile5);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        try {
            com.google.javascript.rhino.EcmaError ecmaError4 = com.google.javascript.rhino.ScriptRuntime.typeError3("<No stack trace available>", "", "(STRING  [empty_block: 1])", "16");
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property <No stack trace available>");
        } catch (java.lang.RuntimeException e) {
        }
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        java.util.List<com.google.javascript.jscomp.JSModule> jSModuleList0 = null;
        try {
            com.google.javascript.jscomp.JSModuleGraph jSModuleGraph1 = new com.google.javascript.jscomp.JSModuleGraph(jSModuleList0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromCode("window", "");
        org.junit.Assert.assertNotNull(sourceFile2);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newString("");
        int int2 = node1.getSideEffectFlags();
        java.util.Collection<com.google.javascript.rhino.Node> nodeCollection3 = com.google.javascript.jscomp.NodeUtil.getVarsDeclaredInBranch(node1);
        int int4 = node1.getChildCount();
        com.google.javascript.rhino.Node node5 = node1.getParent();
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(nodeCollection3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNull(node5);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        com.google.javascript.jscomp.SourceFile.Generator generator1 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("", generator1);
        com.google.javascript.jscomp.CompilerInput compilerInput4 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2, true);
        java.nio.charset.Charset charset6 = null;
        com.google.javascript.jscomp.SourceFile sourceFile7 = com.google.javascript.jscomp.SourceFile.fromFile("", charset6);
        compilerInput4.setSourceFile(sourceFile7);
        com.google.javascript.jscomp.SourceFile.Generator generator10 = null;
        com.google.javascript.jscomp.SourceFile sourceFile11 = com.google.javascript.jscomp.SourceFile.fromGenerator("", generator10);
        java.lang.String str12 = sourceFile11.getOriginalPath();
        compilerInput4.setSourceFile(sourceFile11);
        com.google.javascript.jscomp.ErrorManager errorManager14 = null;
        compilerInput4.setErrorManager(errorManager14);
        com.google.javascript.jscomp.Compiler compiler16 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node node17 = compiler16.getRoot();
        try {
            com.google.javascript.rhino.Node node18 = compilerInput4.getAstRoot((com.google.javascript.jscomp.AbstractCompiler) compiler16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile2);
        org.junit.Assert.assertNotNull(sourceFile7);
        org.junit.Assert.assertNotNull(sourceFile11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertNull(node17);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        try {
            com.google.javascript.rhino.Context.reportWarning("Named type with empty name component", "21", 18, "language version", (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: No Context associated with current Thread");
        } catch (java.lang.RuntimeException e) {
        }
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        com.google.javascript.jscomp.SourceFile.Generator generator1 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("", generator1);
        com.google.javascript.jscomp.CompilerInput compilerInput4 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2, true);
        java.nio.charset.Charset charset6 = null;
        com.google.javascript.jscomp.SourceFile sourceFile7 = com.google.javascript.jscomp.SourceFile.fromFile("", charset6);
        compilerInput4.setSourceFile(sourceFile7);
        com.google.javascript.jscomp.SourceFile.Generator generator10 = null;
        com.google.javascript.jscomp.SourceFile sourceFile11 = com.google.javascript.jscomp.SourceFile.fromGenerator("", generator10);
        java.lang.String str12 = sourceFile11.getOriginalPath();
        compilerInput4.setSourceFile(sourceFile11);
        com.google.javascript.jscomp.ErrorManager errorManager14 = null;
        compilerInput4.setErrorManager(errorManager14);
        java.lang.String str16 = compilerInput4.getName();
        compilerInput4.clearAst();
        org.junit.Assert.assertNotNull(jSSourceFile2);
        org.junit.Assert.assertNotNull(sourceFile7);
        org.junit.Assert.assertNotNull(sourceFile11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        int int0 = com.google.javascript.rhino.Node.LABEL_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 19 + "'", int0 == 19);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        int int0 = com.google.javascript.rhino.Node.MAX_COLUMN_NUMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4095 + "'", int0 == 4095);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        int int0 = com.google.javascript.rhino.Node.DEFAULT_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 14 + "'", int0 == 14);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        com.google.javascript.rhino.Node.SideEffectFlags sideEffectFlags1 = new com.google.javascript.rhino.Node.SideEffectFlags((int) ' ');
        sideEffectFlags1.setMutatesThis();
        sideEffectFlags1.clearSideEffectFlags();
        sideEffectFlags1.clearSideEffectFlags();
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        com.google.javascript.jscomp.DiagnosticType diagnosticType2 = com.google.javascript.jscomp.DiagnosticType.disabled("()", "");
        org.junit.Assert.assertNotNull(diagnosticType2);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        long long1 = com.google.javascript.rhino.ScriptRuntime.testUint32String("16");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 16L + "'", long1 == 16L);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        com.google.javascript.rhino.EcmaError ecmaError1 = com.google.javascript.rhino.ScriptRuntime.typeError("100");
        java.lang.String str2 = ecmaError1.getName();
        java.lang.String str3 = ecmaError1.getScriptStackTrace();
        java.lang.String str4 = ecmaError1.getLineSource();
        org.junit.Assert.assertNotNull(ecmaError1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "TypeError" + "'", str2.equals("TypeError"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "<No stack trace available>" + "'", str3.equals("<No stack trace available>"));
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newString("");
        int int2 = node1.getSideEffectFlags();
        java.util.Collection<com.google.javascript.rhino.Node> nodeCollection3 = com.google.javascript.jscomp.NodeUtil.getVarsDeclaredInBranch(node1);
        try {
            int int5 = node1.getExistingIntProp(12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: FAILED ASSERTION");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(nodeCollection3);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node2 = node1.getParent();
        java.lang.String str3 = node1.getQualifiedName();
        com.google.javascript.rhino.EvaluatorException evaluatorException6 = new com.google.javascript.rhino.EvaluatorException("error reporter");
        node1.putProp((int) (byte) 1, (java.lang.Object) evaluatorException6);
        com.google.javascript.rhino.Node node8 = node1.getLastChild();
        try {
            node8.removeProp(4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertNull(node2);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNull(node8);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        try {
            com.google.javascript.jscomp.JSError[] jSErrorArray2 = compiler1.getWarnings();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        com.google.javascript.jscomp.SourceFile sourceFile1 = com.google.javascript.jscomp.SourceFile.fromFile("window");
        java.lang.String str2 = sourceFile1.getName();
        org.junit.Assert.assertNotNull(sourceFile1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "window" + "'", str2.equals("window"));
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        java.lang.String str1 = com.google.javascript.rhino.jstype.ObjectType.createDelegateSuffix("Not declared as a constructor");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "(Not declared as a constructor)" + "'", str1.equals("(Not declared as a constructor)"));
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup1 = com.google.javascript.jscomp.DiagnosticGroups.TWEAKS;
        com.google.javascript.jscomp.CheckLevel checkLevel2 = com.google.javascript.jscomp.CheckLevel.OFF;
        compilerOptions0.setWarningLevel(diagnosticGroup1, checkLevel2);
        com.google.javascript.jscomp.WarningsGuard warningsGuard4 = null;
        try {
            compilerOptions0.addWarningsGuard(warningsGuard4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(diagnosticGroup1);
        org.junit.Assert.assertTrue("'" + checkLevel2 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel2.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        double double0 = com.google.javascript.rhino.ScriptRuntime.negativeZero;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + (-0.0d) + "'", double0 == (-0.0d));
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        int int0 = com.google.javascript.rhino.Node.CATCH_SCOPE_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + (-1) + "'", int0 == (-1));
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention1 = new com.google.javascript.jscomp.DefaultCodingConvention();
        java.lang.String str2 = defaultCodingConvention1.getExportSymbolFunction();
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node5 = node4.getParent();
        boolean boolean6 = node4.isQuotedString();
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship7 = defaultCodingConvention1.getDelegateRelationship(node4);
        com.google.javascript.rhino.Node node8 = com.google.javascript.jscomp.NodeUtil.newExpr(node4);
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node11 = node10.getParent();
        boolean boolean12 = node10.isQuotedString();
        com.google.javascript.rhino.Node node15 = new com.google.javascript.rhino.Node(4, node8, node10, 35, 0);
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.Node.newString("");
        int int19 = node18.getSideEffectFlags();
        boolean boolean20 = node18.isOptionalArg();
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention21 = new com.google.javascript.jscomp.DefaultCodingConvention();
        java.lang.String str22 = defaultCodingConvention21.getExportSymbolFunction();
        com.google.javascript.rhino.Node node24 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node25 = node24.getParent();
        boolean boolean26 = node24.isQuotedString();
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship27 = defaultCodingConvention21.getDelegateRelationship(node24);
        com.google.javascript.rhino.Node node28 = com.google.javascript.jscomp.NodeUtil.newExpr(node24);
        com.google.javascript.rhino.Node node31 = new com.google.javascript.rhino.Node((int) (short) 0, node18, node28, (int) (byte) 1, 0);
        com.google.javascript.rhino.Node node32 = node8.clonePropsFrom(node28);
        int int33 = node32.getCharno();
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNull(node5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(delegateRelationship7);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNull(node11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNull(str22);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertNull(node25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNull(delegateRelationship27);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertNotNull(node32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + (-1) + "'", int33 == (-1));
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        java.lang.String str0 = com.google.javascript.rhino.jstype.JSType.NOT_A_TYPE;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "Not declared as a type name" + "'", str0.equals("Not declared as a type name"));
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.Node.newString("");
        int int3 = node2.getSideEffectFlags();
        boolean boolean4 = node2.isOptionalArg();
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention5 = new com.google.javascript.jscomp.DefaultCodingConvention();
        java.lang.String str6 = defaultCodingConvention5.getExportSymbolFunction();
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node9 = node8.getParent();
        boolean boolean10 = node8.isQuotedString();
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship11 = defaultCodingConvention5.getDelegateRelationship(node8);
        com.google.javascript.rhino.Node node12 = com.google.javascript.jscomp.NodeUtil.newExpr(node8);
        com.google.javascript.rhino.Node node15 = new com.google.javascript.rhino.Node((int) (short) 0, node2, node12, (int) (byte) 1, 0);
        boolean boolean16 = node15.hasMoreThanOneChild();
        com.google.javascript.rhino.JSDocInfo jSDocInfo17 = node15.getJSDocInfo();
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNull(node9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNull(delegateRelationship11);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNull(jSDocInfo17);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        int int0 = com.google.javascript.rhino.Node.FLAG_LOCAL_RESULTS;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 16 + "'", int0 == 16);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        try {
            com.google.javascript.rhino.Context.reportWarning("()");
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: No Context associated with current Thread");
        } catch (java.lang.RuntimeException e) {
        }
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        com.google.javascript.jscomp.DiagnosticType diagnosticType2 = com.google.javascript.jscomp.DiagnosticType.error("com.google.javascript.rhino.EcmaError: 100: Not declared as a constructor", "21");
        org.junit.Assert.assertNotNull(diagnosticType2);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        com.google.javascript.rhino.EcmaError ecmaError1 = com.google.javascript.rhino.ScriptRuntime.typeError("100");
        int int2 = ecmaError1.getLineNumber();
        org.junit.Assert.assertNotNull(ecmaError1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        try {
            com.google.javascript.rhino.Context.reportWarning("", "window", (int) 'a', "16", 0);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: No Context associated with current Thread");
        } catch (java.lang.RuntimeException e) {
        }
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        try {
            com.google.javascript.rhino.Context.checkOptimizationLevel(20);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Optimization level outside [-1..9]: 20");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newString("");
        int int2 = node1.getSideEffectFlags();
        boolean boolean3 = node1.isOptionalArg();
        int int5 = node1.getIntProp(34);
        node1.setLineno(4095);
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        int int0 = com.google.javascript.rhino.Context.VERSION_1_5;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 150 + "'", int0 == 150);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        try {
            com.google.javascript.rhino.EcmaError ecmaError4 = com.google.javascript.rhino.ScriptRuntime.typeError3("21", "16", "STRING ", "<No stack trace available>");
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property 21");
        } catch (java.lang.RuntimeException e) {
        }
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.SourceFile.Generator generator3 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile4 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("", generator3);
        com.google.javascript.jscomp.CompilerInput compilerInput5 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile4);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile7 = com.google.javascript.jscomp.JSSourceFile.fromFile("(STRING  [empty_block: 1])");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile9 = com.google.javascript.jscomp.JSSourceFile.fromFile("(STRING  [empty_block: 1])");
        com.google.javascript.jscomp.SourceFile.Generator generator11 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile12 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("", generator11);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile14 = com.google.javascript.jscomp.JSSourceFile.fromFile("(STRING  [empty_block: 1])");
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray15 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile4, jSSourceFile7, jSSourceFile9, jSSourceFile12, jSSourceFile14 };
        com.google.javascript.jscomp.JSModule[] jSModuleArray16 = new com.google.javascript.jscomp.JSModule[] {};
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph17 = new com.google.javascript.jscomp.JSModuleGraph(jSModuleArray16);
        com.google.javascript.jscomp.CompilerOptions compilerOptions18 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CompilerOptions.TracerMode tracerMode19 = compilerOptions18.tracer;
        compiler1.init(jSSourceFileArray15, jSModuleArray16, compilerOptions18);
        boolean boolean21 = compiler1.isTypeCheckingEnabled();
        try {
            compiler1.normalize();
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: INTERNAL COMPILER ERROR.\nPlease report this problem.\nnull");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile4);
        org.junit.Assert.assertNotNull(jSSourceFile7);
        org.junit.Assert.assertNotNull(jSSourceFile9);
        org.junit.Assert.assertNotNull(jSSourceFile12);
        org.junit.Assert.assertNotNull(jSSourceFile14);
        org.junit.Assert.assertNotNull(jSSourceFileArray15);
        org.junit.Assert.assertNotNull(jSModuleArray16);
        org.junit.Assert.assertTrue("'" + tracerMode19 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TracerMode.OFF + "'", tracerMode19.equals(com.google.javascript.jscomp.CompilerOptions.TracerMode.OFF));
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy0 = com.google.javascript.jscomp.PropertyRenamingPolicy.UNSPECIFIED;
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy0 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.UNSPECIFIED + "'", propertyRenamingPolicy0.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.UNSPECIFIED));
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        com.google.javascript.jscomp.SourceFile.Generator generator1 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("", generator1);
        com.google.javascript.jscomp.CompilerInput compilerInput4 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2, true);
        try {
            com.google.javascript.jscomp.Region region6 = compilerInput4.getRegion(0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile2);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        com.google.javascript.jscomp.SourceFile.Generator generator1 = null;
        com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromGenerator("window", generator1);
        org.junit.Assert.assertNotNull(sourceFile2);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        int int0 = com.google.javascript.rhino.Context.FEATURE_TO_STRING_AS_SOURCE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.SourceFile.Generator generator3 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile4 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("", generator3);
        com.google.javascript.jscomp.CompilerInput compilerInput5 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile4);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile7 = com.google.javascript.jscomp.JSSourceFile.fromFile("(STRING  [empty_block: 1])");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile9 = com.google.javascript.jscomp.JSSourceFile.fromFile("(STRING  [empty_block: 1])");
        com.google.javascript.jscomp.SourceFile.Generator generator11 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile12 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("", generator11);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile14 = com.google.javascript.jscomp.JSSourceFile.fromFile("(STRING  [empty_block: 1])");
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray15 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile4, jSSourceFile7, jSSourceFile9, jSSourceFile12, jSSourceFile14 };
        com.google.javascript.jscomp.JSModule[] jSModuleArray16 = new com.google.javascript.jscomp.JSModule[] {};
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph17 = new com.google.javascript.jscomp.JSModuleGraph(jSModuleArray16);
        com.google.javascript.jscomp.CompilerOptions compilerOptions18 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CompilerOptions.TracerMode tracerMode19 = compilerOptions18.tracer;
        compiler1.init(jSSourceFileArray15, jSModuleArray16, compilerOptions18);
        compilerOptions18.setGenerateExports(true);
        compilerOptions18.jsOutputFile = "21";
        compilerOptions18.removeUnusedPrototypeProperties = false;
        byte[] byteArray27 = compilerOptions18.inputVariableMapSerialized;
        compilerOptions18.syntheticBlockStartMarker = "";
        org.junit.Assert.assertNotNull(jSSourceFile4);
        org.junit.Assert.assertNotNull(jSSourceFile7);
        org.junit.Assert.assertNotNull(jSSourceFile9);
        org.junit.Assert.assertNotNull(jSSourceFile12);
        org.junit.Assert.assertNotNull(jSSourceFile14);
        org.junit.Assert.assertNotNull(jSSourceFileArray15);
        org.junit.Assert.assertNotNull(jSModuleArray16);
        org.junit.Assert.assertTrue("'" + tracerMode19 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TracerMode.OFF + "'", tracerMode19.equals(com.google.javascript.jscomp.CompilerOptions.TracerMode.OFF));
        org.junit.Assert.assertNull(byteArray27);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        com.google.javascript.jscomp.DiagnosticType diagnosticType2 = com.google.javascript.jscomp.DiagnosticType.error("100", "language version");
        com.google.javascript.jscomp.CheckLevel checkLevel3 = diagnosticType2.defaultLevel;
        java.lang.String str4 = diagnosticType2.toString();
        org.junit.Assert.assertNotNull(diagnosticType2);
        org.junit.Assert.assertTrue("'" + checkLevel3 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel3.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "100: language version" + "'", str4.equals("100: language version"));
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        com.google.javascript.jscomp.SourceFile.Generator generator1 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("", generator1);
        com.google.javascript.jscomp.CompilerInput compilerInput4 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2, true);
        java.util.logging.Logger logger5 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager6 = new com.google.javascript.jscomp.LoggerErrorManager(logger5);
        compilerInput4.setErrorManager((com.google.javascript.jscomp.ErrorManager) loggerErrorManager6);
        com.google.javascript.jscomp.SourceFile.Generator generator9 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile10 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("", generator9);
        com.google.javascript.jscomp.CompilerInput compilerInput12 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile10, true);
        java.nio.charset.Charset charset14 = null;
        com.google.javascript.jscomp.SourceFile sourceFile15 = com.google.javascript.jscomp.SourceFile.fromFile("", charset14);
        compilerInput12.setSourceFile(sourceFile15);
        com.google.javascript.jscomp.SourceFile.Generator generator18 = null;
        com.google.javascript.jscomp.SourceFile sourceFile19 = com.google.javascript.jscomp.SourceFile.fromGenerator("", generator18);
        java.lang.String str20 = sourceFile19.getOriginalPath();
        compilerInput12.setSourceFile(sourceFile19);
        com.google.javascript.jscomp.JSModule jSModule22 = null;
        compilerInput12.setModule(jSModule22);
        com.google.javascript.jscomp.SourceFile.Generator generator25 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile26 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("", generator25);
        com.google.javascript.jscomp.CompilerInput compilerInput28 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile26, true);
        com.google.javascript.jscomp.SourceFile.Generator generator30 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile31 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("", generator30);
        com.google.javascript.jscomp.CompilerInput compilerInput33 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile31, true);
        java.nio.charset.Charset charset35 = null;
        com.google.javascript.jscomp.SourceFile sourceFile36 = com.google.javascript.jscomp.SourceFile.fromFile("", charset35);
        compilerInput33.setSourceFile(sourceFile36);
        com.google.javascript.jscomp.SourceFile.Generator generator39 = null;
        com.google.javascript.jscomp.SourceFile sourceFile40 = com.google.javascript.jscomp.SourceFile.fromGenerator("", generator39);
        java.lang.String str41 = sourceFile40.getOriginalPath();
        compilerInput33.setSourceFile(sourceFile40);
        com.google.javascript.jscomp.ErrorManager errorManager43 = null;
        compilerInput33.setErrorManager(errorManager43);
        java.lang.String str45 = compilerInput33.getName();
        compilerInput33.clearAst();
        com.google.javascript.jscomp.SourceFile.Generator generator48 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile49 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("", generator48);
        com.google.javascript.jscomp.CompilerInput compilerInput51 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile49, true);
        java.util.logging.Logger logger52 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager53 = new com.google.javascript.jscomp.LoggerErrorManager(logger52);
        compilerInput51.setErrorManager((com.google.javascript.jscomp.ErrorManager) loggerErrorManager53);
        com.google.javascript.jscomp.SourceFile sourceFile57 = com.google.javascript.jscomp.SourceFile.fromCode("", "21");
        compilerInput51.setSourceFile(sourceFile57);
        com.google.javascript.jscomp.CompilerInput[] compilerInputArray59 = new com.google.javascript.jscomp.CompilerInput[] { compilerInput4, compilerInput12, compilerInput28, compilerInput33, compilerInput51 };
        java.util.ArrayList<com.google.javascript.jscomp.CompilerInput> compilerInputList60 = new java.util.ArrayList<com.google.javascript.jscomp.CompilerInput>();
        boolean boolean61 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.CompilerInput>) compilerInputList60, compilerInputArray59);
        try {
            com.google.javascript.jscomp.deps.SortedDependencies<com.google.javascript.jscomp.CompilerInput> compilerInputSortedDependencies62 = new com.google.javascript.jscomp.deps.SortedDependencies<com.google.javascript.jscomp.CompilerInput>((java.util.List<com.google.javascript.jscomp.CompilerInput>) compilerInputList60);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile2);
        org.junit.Assert.assertNotNull(jSSourceFile10);
        org.junit.Assert.assertNotNull(sourceFile15);
        org.junit.Assert.assertNotNull(sourceFile19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "" + "'", str20.equals(""));
        org.junit.Assert.assertNotNull(jSSourceFile26);
        org.junit.Assert.assertNotNull(jSSourceFile31);
        org.junit.Assert.assertNotNull(sourceFile36);
        org.junit.Assert.assertNotNull(sourceFile40);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "" + "'", str41.equals(""));
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "" + "'", str45.equals(""));
        org.junit.Assert.assertNotNull(jSSourceFile49);
        org.junit.Assert.assertNotNull(sourceFile57);
        org.junit.Assert.assertNotNull(compilerInputArray59);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + true + "'", boolean61 == true);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        com.google.javascript.rhino.Node.SideEffectFlags sideEffectFlags1 = new com.google.javascript.rhino.Node.SideEffectFlags((int) ' ');
        sideEffectFlags1.setReturnsTainted();
        boolean boolean3 = sideEffectFlags1.areAllFlagsSet();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.INVALID_CASTS;
        com.google.javascript.jscomp.DiagnosticGroups.NON_STANDARD_JSDOC = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticGroups.CONSTANT_PROPERTY = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticGroups.DEPRECATED = diagnosticGroup0;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.SourceFile.Generator generator3 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile4 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("", generator3);
        com.google.javascript.jscomp.CompilerInput compilerInput5 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile4);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile7 = com.google.javascript.jscomp.JSSourceFile.fromFile("(STRING  [empty_block: 1])");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile9 = com.google.javascript.jscomp.JSSourceFile.fromFile("(STRING  [empty_block: 1])");
        com.google.javascript.jscomp.SourceFile.Generator generator11 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile12 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("", generator11);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile14 = com.google.javascript.jscomp.JSSourceFile.fromFile("(STRING  [empty_block: 1])");
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray15 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile4, jSSourceFile7, jSSourceFile9, jSSourceFile12, jSSourceFile14 };
        com.google.javascript.jscomp.JSModule[] jSModuleArray16 = new com.google.javascript.jscomp.JSModule[] {};
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph17 = new com.google.javascript.jscomp.JSModuleGraph(jSModuleArray16);
        com.google.javascript.jscomp.CompilerOptions compilerOptions18 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CompilerOptions.TracerMode tracerMode19 = compilerOptions18.tracer;
        compiler1.init(jSSourceFileArray15, jSModuleArray16, compilerOptions18);
        compilerOptions18.checkEs5Strict = false;
        compilerOptions18.flowSensitiveInlineVariables = false;
        compilerOptions18.removeTryCatchFinally = true;
        compilerOptions18.setCollapsePropertiesOnExternTypes(true);
        com.google.javascript.jscomp.CheckLevel checkLevel29 = compilerOptions18.reportMissingOverride;
        org.junit.Assert.assertNotNull(jSSourceFile4);
        org.junit.Assert.assertNotNull(jSSourceFile7);
        org.junit.Assert.assertNotNull(jSSourceFile9);
        org.junit.Assert.assertNotNull(jSSourceFile12);
        org.junit.Assert.assertNotNull(jSSourceFile14);
        org.junit.Assert.assertNotNull(jSSourceFileArray15);
        org.junit.Assert.assertNotNull(jSModuleArray16);
        org.junit.Assert.assertTrue("'" + tracerMode19 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TracerMode.OFF + "'", tracerMode19.equals(com.google.javascript.jscomp.CompilerOptions.TracerMode.OFF));
        org.junit.Assert.assertTrue("'" + checkLevel29 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel29.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

//    @Test
//    public void test304() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test304");
//        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.STRICT_MODULE_DEP_CHECK;
//        org.junit.Assert.assertNotNull(diagnosticGroup0);
//    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.SourceFile.Generator generator3 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile4 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("", generator3);
        com.google.javascript.jscomp.CompilerInput compilerInput5 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile4);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile7 = com.google.javascript.jscomp.JSSourceFile.fromFile("(STRING  [empty_block: 1])");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile9 = com.google.javascript.jscomp.JSSourceFile.fromFile("(STRING  [empty_block: 1])");
        com.google.javascript.jscomp.SourceFile.Generator generator11 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile12 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("", generator11);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile14 = com.google.javascript.jscomp.JSSourceFile.fromFile("(STRING  [empty_block: 1])");
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray15 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile4, jSSourceFile7, jSSourceFile9, jSSourceFile12, jSSourceFile14 };
        com.google.javascript.jscomp.JSModule[] jSModuleArray16 = new com.google.javascript.jscomp.JSModule[] {};
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph17 = new com.google.javascript.jscomp.JSModuleGraph(jSModuleArray16);
        com.google.javascript.jscomp.CompilerOptions compilerOptions18 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CompilerOptions.TracerMode tracerMode19 = compilerOptions18.tracer;
        compiler1.init(jSSourceFileArray15, jSModuleArray16, compilerOptions18);
        compilerOptions18.setGenerateExports(true);
        compilerOptions18.jsOutputFile = "21";
        compilerOptions18.removeUnusedPrototypeProperties = false;
        byte[] byteArray27 = compilerOptions18.inputVariableMapSerialized;
        java.io.PrintStream printStream28 = null;
        com.google.javascript.jscomp.Compiler compiler29 = new com.google.javascript.jscomp.Compiler(printStream28);
        com.google.javascript.jscomp.SourceFile.Generator generator31 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile32 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("", generator31);
        com.google.javascript.jscomp.CompilerInput compilerInput33 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile32);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile35 = com.google.javascript.jscomp.JSSourceFile.fromFile("(STRING  [empty_block: 1])");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile37 = com.google.javascript.jscomp.JSSourceFile.fromFile("(STRING  [empty_block: 1])");
        com.google.javascript.jscomp.SourceFile.Generator generator39 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile40 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("", generator39);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile42 = com.google.javascript.jscomp.JSSourceFile.fromFile("(STRING  [empty_block: 1])");
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray43 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile32, jSSourceFile35, jSSourceFile37, jSSourceFile40, jSSourceFile42 };
        com.google.javascript.jscomp.JSModule[] jSModuleArray44 = new com.google.javascript.jscomp.JSModule[] {};
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph45 = new com.google.javascript.jscomp.JSModuleGraph(jSModuleArray44);
        com.google.javascript.jscomp.CompilerOptions compilerOptions46 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CompilerOptions.TracerMode tracerMode47 = compilerOptions46.tracer;
        compiler29.init(jSSourceFileArray43, jSModuleArray44, compilerOptions46);
        compilerOptions46.setGenerateExports(true);
        compilerOptions46.jsOutputFile = "21";
        compilerOptions46.removeUnusedPrototypeProperties = false;
        byte[] byteArray55 = compilerOptions46.inputVariableMapSerialized;
        java.util.Set<java.lang.String> strSet56 = compilerOptions46.stripNameSuffixes;
        compilerOptions18.aliasableStrings = strSet56;
        boolean boolean58 = compilerOptions18.deadAssignmentElimination;
        boolean boolean59 = compilerOptions18.computeFunctionSideEffects;
        com.google.javascript.jscomp.DiagnosticType diagnosticType63 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray69 = new java.lang.String[] { "Named type with empty name component", "(STRING  [empty_block: 1])", "100", "Not declared as a constructor", "(STRING  [empty_block: 1])" };
        com.google.javascript.jscomp.JSError jSError70 = com.google.javascript.jscomp.JSError.make("", (int) (byte) 1, (int) '#', diagnosticType63, strArray69);
        com.google.javascript.jscomp.CheckLevel checkLevel71 = jSError70.level;
        compilerOptions18.checkUndefinedProperties = checkLevel71;
        org.junit.Assert.assertNotNull(jSSourceFile4);
        org.junit.Assert.assertNotNull(jSSourceFile7);
        org.junit.Assert.assertNotNull(jSSourceFile9);
        org.junit.Assert.assertNotNull(jSSourceFile12);
        org.junit.Assert.assertNotNull(jSSourceFile14);
        org.junit.Assert.assertNotNull(jSSourceFileArray15);
        org.junit.Assert.assertNotNull(jSModuleArray16);
        org.junit.Assert.assertTrue("'" + tracerMode19 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TracerMode.OFF + "'", tracerMode19.equals(com.google.javascript.jscomp.CompilerOptions.TracerMode.OFF));
        org.junit.Assert.assertNull(byteArray27);
        org.junit.Assert.assertNotNull(jSSourceFile32);
        org.junit.Assert.assertNotNull(jSSourceFile35);
        org.junit.Assert.assertNotNull(jSSourceFile37);
        org.junit.Assert.assertNotNull(jSSourceFile40);
        org.junit.Assert.assertNotNull(jSSourceFile42);
        org.junit.Assert.assertNotNull(jSSourceFileArray43);
        org.junit.Assert.assertNotNull(jSModuleArray44);
        org.junit.Assert.assertTrue("'" + tracerMode47 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TracerMode.OFF + "'", tracerMode47.equals(com.google.javascript.jscomp.CompilerOptions.TracerMode.OFF));
        org.junit.Assert.assertNull(byteArray55);
        org.junit.Assert.assertNotNull(strSet56);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertNotNull(diagnosticType63);
        org.junit.Assert.assertNotNull(strArray69);
        org.junit.Assert.assertNotNull(jSError70);
        org.junit.Assert.assertTrue("'" + checkLevel71 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel71.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        com.google.javascript.jscomp.SourceMap.DetailLevel detailLevel0 = com.google.javascript.jscomp.SourceMap.DetailLevel.ALL;
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node4 = node3.getParent();
        boolean boolean5 = node3.isQuotedString();
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node8 = node7.getParent();
        boolean boolean9 = node7.hasChildren();
        node7.detachChildren();
        java.lang.String str11 = node7.getString();
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node14 = node13.getParent();
        boolean boolean15 = node13.isQuotedString();
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newString("");
        int int18 = node17.getSideEffectFlags();
        boolean boolean19 = node17.isOptionalArg();
        com.google.javascript.rhino.Node node20 = node17.getLastSibling();
        com.google.javascript.rhino.Node node23 = new com.google.javascript.rhino.Node((int) (short) 10, node3, node7, node13, node17, (int) '4', (int) 'a');
        boolean boolean24 = detailLevel0.apply(node13);
        node13.setCharno((int) (byte) 100);
        org.junit.Assert.assertNotNull(detailLevel0);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNull(node4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertNull(node8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNull(node14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node2 = node1.getParent();
        boolean boolean3 = node1.hasChildren();
        java.lang.String str4 = node1.getQualifiedName();
        java.lang.Object obj6 = node1.getProp(100);
        int int7 = node1.getLineno();
        com.google.javascript.rhino.Node node8 = null;
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node11 = node10.getParent();
        boolean boolean12 = node10.hasChildren();
        java.lang.String str13 = node10.getQualifiedName();
        java.lang.Object obj15 = node10.getProp(100);
        try {
            node1.replaceChild(node8, node10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertNull(node2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNull(obj6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNull(node11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertNull(obj15);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        com.google.javascript.rhino.Node node1 = new com.google.javascript.rhino.Node((int) (short) -1);
        node1.removeProp((int) (byte) 100);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        com.google.javascript.rhino.Node.SideEffectFlags sideEffectFlags0 = new com.google.javascript.rhino.Node.SideEffectFlags();
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        int int0 = com.google.javascript.rhino.Node.ATTRIBUTE_FLAG;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        com.google.javascript.rhino.Node node3 = new com.google.javascript.rhino.Node((int) '4', 1, 29);
        try {
            int int5 = node3.getExistingIntProp(49);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: FAILED ASSERTION");
        } catch (java.lang.IllegalStateException e) {
        }
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node2 = node1.getParent();
        boolean boolean3 = node1.isQuotedString();
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention4 = new com.google.javascript.jscomp.DefaultCodingConvention();
        java.lang.String str5 = defaultCodingConvention4.getExportSymbolFunction();
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node8 = node7.getParent();
        boolean boolean9 = node7.isQuotedString();
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship10 = defaultCodingConvention4.getDelegateRelationship(node7);
        java.util.Collection<com.google.javascript.rhino.Node> nodeCollection11 = com.google.javascript.jscomp.NodeUtil.getVarsDeclaredInBranch(node7);
        com.google.javascript.rhino.JSDocInfo jSDocInfo12 = node7.getJSDocInfo();
        com.google.javascript.rhino.Node node13 = node1.copyInformationFromForTree(node7);
        node7.setIsSyntheticBlock(true);
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertNull(node2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertNull(node8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(delegateRelationship10);
        org.junit.Assert.assertNotNull(nodeCollection11);
        org.junit.Assert.assertNull(jSDocInfo12);
        org.junit.Assert.assertNotNull(node13);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString((int) ' ', "", 11, 4);
        org.junit.Assert.assertNotNull(node4);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node2 = node1.getParent();
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup5 = com.google.javascript.jscomp.DiagnosticGroups.CHECK_TYPES;
        com.google.javascript.jscomp.DiagnosticGroups.NON_STANDARD_JSDOC = diagnosticGroup5;
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup7 = com.google.javascript.jscomp.DiagnosticGroups.TYPE_INVALIDATION;
        com.google.javascript.jscomp.DiagnosticGroups.CHECK_VARIABLES = diagnosticGroup7;
        com.google.javascript.jscomp.DiagnosticGroup[] diagnosticGroupArray9 = new com.google.javascript.jscomp.DiagnosticGroup[] { diagnosticGroup5, diagnosticGroup7 };
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup10 = new com.google.javascript.jscomp.DiagnosticGroup("TypeError", diagnosticGroupArray9);
        try {
            node2.putProp(17, (java.lang.Object) diagnosticGroup10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertNull(node2);
        org.junit.Assert.assertNotNull(diagnosticGroup5);
        org.junit.Assert.assertNotNull(diagnosticGroup7);
        org.junit.Assert.assertNotNull(diagnosticGroupArray9);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.SourceFile.Generator generator3 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile4 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("", generator3);
        com.google.javascript.jscomp.CompilerInput compilerInput5 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile4);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile7 = com.google.javascript.jscomp.JSSourceFile.fromFile("(STRING  [empty_block: 1])");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile9 = com.google.javascript.jscomp.JSSourceFile.fromFile("(STRING  [empty_block: 1])");
        com.google.javascript.jscomp.SourceFile.Generator generator11 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile12 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("", generator11);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile14 = com.google.javascript.jscomp.JSSourceFile.fromFile("(STRING  [empty_block: 1])");
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray15 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile4, jSSourceFile7, jSSourceFile9, jSSourceFile12, jSSourceFile14 };
        com.google.javascript.jscomp.JSModule[] jSModuleArray16 = new com.google.javascript.jscomp.JSModule[] {};
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph17 = new com.google.javascript.jscomp.JSModuleGraph(jSModuleArray16);
        com.google.javascript.jscomp.CompilerOptions compilerOptions18 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CompilerOptions.TracerMode tracerMode19 = compilerOptions18.tracer;
        compiler1.init(jSSourceFileArray15, jSModuleArray16, compilerOptions18);
        com.google.javascript.jscomp.CompilerOptions compilerOptions21 = null;
        try {
            compiler1.initOptions(compilerOptions21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile4);
        org.junit.Assert.assertNotNull(jSSourceFile7);
        org.junit.Assert.assertNotNull(jSSourceFile9);
        org.junit.Assert.assertNotNull(jSSourceFile12);
        org.junit.Assert.assertNotNull(jSSourceFile14);
        org.junit.Assert.assertNotNull(jSSourceFileArray15);
        org.junit.Assert.assertNotNull(jSModuleArray16);
        org.junit.Assert.assertTrue("'" + tracerMode19 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TracerMode.OFF + "'", tracerMode19.equals(com.google.javascript.jscomp.CompilerOptions.TracerMode.OFF));
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention0 = new com.google.javascript.jscomp.DefaultCodingConvention();
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention1 = new com.google.javascript.jscomp.DefaultCodingConvention();
        java.lang.String str2 = defaultCodingConvention1.getExportSymbolFunction();
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node5 = node4.getParent();
        boolean boolean6 = node4.isQuotedString();
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship7 = defaultCodingConvention1.getDelegateRelationship(node4);
        com.google.javascript.jscomp.CodingConvention.SubclassRelationship subclassRelationship8 = defaultCodingConvention0.getClassesDefinedByCall(node4);
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention10 = new com.google.javascript.jscomp.DefaultCodingConvention();
        java.lang.String str11 = defaultCodingConvention10.getExportSymbolFunction();
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node14 = node13.getParent();
        boolean boolean15 = node13.isQuotedString();
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship16 = defaultCodingConvention10.getDelegateRelationship(node13);
        com.google.javascript.rhino.Node node17 = com.google.javascript.jscomp.NodeUtil.newExpr(node13);
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node20 = node19.getParent();
        boolean boolean21 = node19.isQuotedString();
        com.google.javascript.rhino.Node node24 = new com.google.javascript.rhino.Node(4, node17, node19, 35, 0);
        java.lang.String str25 = defaultCodingConvention0.getSingletonGetterClassName(node19);
        com.google.javascript.rhino.Node node28 = com.google.javascript.rhino.Node.newString("");
        int int29 = node28.getSideEffectFlags();
        boolean boolean30 = node28.isOptionalArg();
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention31 = new com.google.javascript.jscomp.DefaultCodingConvention();
        java.lang.String str32 = defaultCodingConvention31.getExportSymbolFunction();
        com.google.javascript.rhino.Node node34 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node35 = node34.getParent();
        boolean boolean36 = node34.isQuotedString();
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship37 = defaultCodingConvention31.getDelegateRelationship(node34);
        com.google.javascript.rhino.Node node38 = com.google.javascript.jscomp.NodeUtil.newExpr(node34);
        com.google.javascript.rhino.Node node41 = new com.google.javascript.rhino.Node((int) (short) 0, node28, node38, (int) (byte) 1, 0);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder42 = node41.getJsDocBuilderForNode();
        com.google.javascript.jscomp.CheckLevel checkLevel44 = null;
        com.google.javascript.jscomp.DiagnosticType diagnosticType46 = com.google.javascript.jscomp.DiagnosticType.make("", checkLevel44, "Not declared as a constructor");
        com.google.javascript.rhino.Node node48 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node49 = node48.getParent();
        boolean boolean50 = node48.hasChildren();
        node48.detachChildren();
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup52 = com.google.javascript.jscomp.DiagnosticGroups.CHECK_USELESS_CODE;
        java.lang.RuntimeException runtimeException53 = com.google.javascript.rhino.ScriptRuntime.undefWriteError((java.lang.Object) "Not declared as a constructor", (java.lang.Object) node48, (java.lang.Object) diagnosticGroup52);
        try {
            java.lang.String str54 = defaultCodingConvention0.extractClassNameIfRequire(node41, node48);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: only implemented in GoogleCodingConvention");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNull(node5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(delegateRelationship7);
        org.junit.Assert.assertNull(subclassRelationship8);
        org.junit.Assert.assertNull(str11);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNull(node14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNull(delegateRelationship16);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNull(node20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNull(str25);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNull(str32);
        org.junit.Assert.assertNotNull(node34);
        org.junit.Assert.assertNull(node35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNull(delegateRelationship37);
        org.junit.Assert.assertNotNull(node38);
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder42);
        org.junit.Assert.assertNotNull(diagnosticType46);
        org.junit.Assert.assertNotNull(node48);
        org.junit.Assert.assertNull(node49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNull(diagnosticGroup52);
        org.junit.Assert.assertNotNull(runtimeException53);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention1 = new com.google.javascript.jscomp.DefaultCodingConvention();
        boolean boolean3 = defaultCodingConvention1.isExported("window");
        compilerOptions0.setCodingConvention((com.google.javascript.jscomp.CodingConvention) defaultCodingConvention1);
        java.lang.Object obj5 = compilerOptions0.clone();
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy6 = com.google.javascript.jscomp.VariableRenamingPolicy.UNSPECIFIED;
        compilerOptions0.variableRenaming = variableRenamingPolicy6;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy6 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.UNSPECIFIED + "'", variableRenamingPolicy6.equals(com.google.javascript.jscomp.VariableRenamingPolicy.UNSPECIFIED));
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        com.google.javascript.rhino.EcmaError ecmaError1 = com.google.javascript.rhino.ScriptRuntime.typeError("100");
        java.lang.String str2 = ecmaError1.getErrorMessage();
        org.junit.Assert.assertNotNull(ecmaError1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "100" + "'", str2.equals("100"));
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        com.google.javascript.rhino.Node node1 = new com.google.javascript.rhino.Node(18);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node2 = node1.getParent();
        boolean boolean3 = node1.hasChildren();
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder4 = node1.getJsDocBuilderForNode();
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention5 = new com.google.javascript.jscomp.DefaultCodingConvention();
        java.lang.String str6 = defaultCodingConvention5.getExportSymbolFunction();
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node9 = node8.getParent();
        boolean boolean10 = node8.isQuotedString();
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship11 = defaultCodingConvention5.getDelegateRelationship(node8);
        com.google.javascript.rhino.Node node12 = node8.getParent();
        try {
            com.google.javascript.rhino.Node node13 = node1.removeChildAfter(node12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertNull(node2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder4);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNull(node9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNull(delegateRelationship11);
        org.junit.Assert.assertNull(node12);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        com.google.javascript.rhino.EvaluatorException evaluatorException3 = new com.google.javascript.rhino.EvaluatorException("com.google.javascript.rhino.EcmaError: 100: Not declared as a constructor", "hi!", 23);
        try {
            evaluatorException3.initLineNumber((-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: -1");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention1 = new com.google.javascript.jscomp.DefaultCodingConvention();
        java.lang.String str2 = defaultCodingConvention1.getExportSymbolFunction();
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node5 = node4.getParent();
        boolean boolean6 = node4.isQuotedString();
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship7 = defaultCodingConvention1.getDelegateRelationship(node4);
        java.util.Collection<com.google.javascript.rhino.Node> nodeCollection8 = com.google.javascript.jscomp.NodeUtil.getVarsDeclaredInBranch(node4);
        com.google.javascript.rhino.JSDocInfo jSDocInfo9 = node4.getJSDocInfo();
        boolean boolean10 = node4.isNoSideEffectsCall();
        com.google.javascript.rhino.Node node11 = null;
        com.google.javascript.rhino.Node node12 = null;
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention13 = new com.google.javascript.jscomp.DefaultCodingConvention();
        java.lang.String str14 = defaultCodingConvention13.getExportSymbolFunction();
        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node17 = node16.getParent();
        boolean boolean18 = node16.isQuotedString();
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship19 = defaultCodingConvention13.getDelegateRelationship(node16);
        com.google.javascript.rhino.JSDocInfo jSDocInfo20 = null;
        node16.setJSDocInfo(jSDocInfo20);
        boolean boolean22 = node16.isUnscopedQualifiedName();
        try {
            com.google.javascript.rhino.Node node25 = new com.google.javascript.rhino.Node((int) (short) 0, node4, node11, node12, node16, 4095, 5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNull(node5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(delegateRelationship7);
        org.junit.Assert.assertNotNull(nodeCollection8);
        org.junit.Assert.assertNull(jSDocInfo9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertNull(node17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNull(delegateRelationship19);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.SourceFile.Generator generator3 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile4 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("", generator3);
        com.google.javascript.jscomp.CompilerInput compilerInput5 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile4);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile7 = com.google.javascript.jscomp.JSSourceFile.fromFile("(STRING  [empty_block: 1])");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile9 = com.google.javascript.jscomp.JSSourceFile.fromFile("(STRING  [empty_block: 1])");
        com.google.javascript.jscomp.SourceFile.Generator generator11 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile12 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("", generator11);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile14 = com.google.javascript.jscomp.JSSourceFile.fromFile("(STRING  [empty_block: 1])");
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray15 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile4, jSSourceFile7, jSSourceFile9, jSSourceFile12, jSSourceFile14 };
        com.google.javascript.jscomp.JSModule[] jSModuleArray16 = new com.google.javascript.jscomp.JSModule[] {};
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph17 = new com.google.javascript.jscomp.JSModuleGraph(jSModuleArray16);
        com.google.javascript.jscomp.CompilerOptions compilerOptions18 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CompilerOptions.TracerMode tracerMode19 = compilerOptions18.tracer;
        compiler1.init(jSSourceFileArray15, jSModuleArray16, compilerOptions18);
        com.google.javascript.jscomp.SourceFile.Generator generator22 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile23 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("", generator22);
        com.google.javascript.jscomp.CompilerInput compilerInput25 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile23, true);
        com.google.javascript.jscomp.SourceFile.Generator generator27 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile28 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("Not declared as a constructor", generator27);
        com.google.javascript.jscomp.SourceFile.Generator generator30 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile31 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("", generator30);
        com.google.javascript.jscomp.CompilerInput compilerInput32 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile31);
        com.google.javascript.jscomp.SourceFile.Generator generator34 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile35 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("", generator34);
        com.google.javascript.jscomp.CompilerInput compilerInput37 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile35, true);
        com.google.javascript.jscomp.SourceFile.Generator generator39 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile40 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("", generator39);
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray41 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile28, jSSourceFile31, jSSourceFile35, jSSourceFile40 };
        com.google.javascript.jscomp.CompilerOptions compilerOptions42 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention43 = new com.google.javascript.jscomp.DefaultCodingConvention();
        boolean boolean45 = defaultCodingConvention43.isExported("window");
        compilerOptions42.setCodingConvention((com.google.javascript.jscomp.CodingConvention) defaultCodingConvention43);
        com.google.javascript.jscomp.Result result47 = compiler1.compile(jSSourceFile23, jSSourceFileArray41, compilerOptions42);
        java.io.PrintStream printStream48 = null;
        com.google.javascript.jscomp.Compiler compiler49 = new com.google.javascript.jscomp.Compiler(printStream48);
        com.google.javascript.jscomp.SourceFile.Generator generator51 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile52 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("", generator51);
        com.google.javascript.jscomp.CompilerInput compilerInput53 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile52);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile55 = com.google.javascript.jscomp.JSSourceFile.fromFile("(STRING  [empty_block: 1])");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile57 = com.google.javascript.jscomp.JSSourceFile.fromFile("(STRING  [empty_block: 1])");
        com.google.javascript.jscomp.SourceFile.Generator generator59 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile60 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("", generator59);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile62 = com.google.javascript.jscomp.JSSourceFile.fromFile("(STRING  [empty_block: 1])");
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray63 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile52, jSSourceFile55, jSSourceFile57, jSSourceFile60, jSSourceFile62 };
        com.google.javascript.jscomp.JSModule[] jSModuleArray64 = new com.google.javascript.jscomp.JSModule[] {};
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph65 = new com.google.javascript.jscomp.JSModuleGraph(jSModuleArray64);
        com.google.javascript.jscomp.CompilerOptions compilerOptions66 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CompilerOptions.TracerMode tracerMode67 = compilerOptions66.tracer;
        compiler49.init(jSSourceFileArray63, jSModuleArray64, compilerOptions66);
        com.google.javascript.jscomp.SourceFile.Generator generator70 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile71 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("", generator70);
        com.google.javascript.jscomp.CompilerInput compilerInput73 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile71, true);
        com.google.javascript.jscomp.SourceFile.Generator generator75 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile76 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("Not declared as a constructor", generator75);
        com.google.javascript.jscomp.SourceFile.Generator generator78 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile79 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("", generator78);
        com.google.javascript.jscomp.CompilerInput compilerInput80 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile79);
        com.google.javascript.jscomp.SourceFile.Generator generator82 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile83 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("", generator82);
        com.google.javascript.jscomp.CompilerInput compilerInput85 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile83, true);
        com.google.javascript.jscomp.SourceFile.Generator generator87 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile88 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("", generator87);
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray89 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile76, jSSourceFile79, jSSourceFile83, jSSourceFile88 };
        com.google.javascript.jscomp.CompilerOptions compilerOptions90 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention91 = new com.google.javascript.jscomp.DefaultCodingConvention();
        boolean boolean93 = defaultCodingConvention91.isExported("window");
        compilerOptions90.setCodingConvention((com.google.javascript.jscomp.CodingConvention) defaultCodingConvention91);
        com.google.javascript.jscomp.Result result95 = compiler49.compile(jSSourceFile71, jSSourceFileArray89, compilerOptions90);
        com.google.javascript.jscomp.JSModule[] jSModuleArray96 = null;
        com.google.javascript.jscomp.CompilerOptions compilerOptions97 = null;
        try {
            com.google.javascript.jscomp.Result result98 = compiler1.compile(jSSourceFileArray89, jSModuleArray96, compilerOptions97);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile4);
        org.junit.Assert.assertNotNull(jSSourceFile7);
        org.junit.Assert.assertNotNull(jSSourceFile9);
        org.junit.Assert.assertNotNull(jSSourceFile12);
        org.junit.Assert.assertNotNull(jSSourceFile14);
        org.junit.Assert.assertNotNull(jSSourceFileArray15);
        org.junit.Assert.assertNotNull(jSModuleArray16);
        org.junit.Assert.assertTrue("'" + tracerMode19 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TracerMode.OFF + "'", tracerMode19.equals(com.google.javascript.jscomp.CompilerOptions.TracerMode.OFF));
        org.junit.Assert.assertNotNull(jSSourceFile23);
        org.junit.Assert.assertNotNull(jSSourceFile28);
        org.junit.Assert.assertNotNull(jSSourceFile31);
        org.junit.Assert.assertNotNull(jSSourceFile35);
        org.junit.Assert.assertNotNull(jSSourceFile40);
        org.junit.Assert.assertNotNull(jSSourceFileArray41);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(result47);
        org.junit.Assert.assertNotNull(jSSourceFile52);
        org.junit.Assert.assertNotNull(jSSourceFile55);
        org.junit.Assert.assertNotNull(jSSourceFile57);
        org.junit.Assert.assertNotNull(jSSourceFile60);
        org.junit.Assert.assertNotNull(jSSourceFile62);
        org.junit.Assert.assertNotNull(jSSourceFileArray63);
        org.junit.Assert.assertNotNull(jSModuleArray64);
        org.junit.Assert.assertTrue("'" + tracerMode67 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TracerMode.OFF + "'", tracerMode67.equals(com.google.javascript.jscomp.CompilerOptions.TracerMode.OFF));
        org.junit.Assert.assertNotNull(jSSourceFile71);
        org.junit.Assert.assertNotNull(jSSourceFile76);
        org.junit.Assert.assertNotNull(jSSourceFile79);
        org.junit.Assert.assertNotNull(jSSourceFile83);
        org.junit.Assert.assertNotNull(jSSourceFile88);
        org.junit.Assert.assertNotNull(jSSourceFileArray89);
        org.junit.Assert.assertTrue("'" + boolean93 + "' != '" + false + "'", boolean93 == false);
        org.junit.Assert.assertNotNull(result95);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newString("");
        int int2 = node1.getSideEffectFlags();
        java.util.Collection<com.google.javascript.rhino.Node> nodeCollection3 = com.google.javascript.jscomp.NodeUtil.getVarsDeclaredInBranch(node1);
        java.lang.String str4 = node1.getString();
        java.util.Set<java.lang.String> strSet5 = node1.getDirectives();
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(nodeCollection3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertNull(strSet5);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.SourceFile.Generator generator3 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile4 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("", generator3);
        com.google.javascript.jscomp.CompilerInput compilerInput5 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile4);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile7 = com.google.javascript.jscomp.JSSourceFile.fromFile("(STRING  [empty_block: 1])");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile9 = com.google.javascript.jscomp.JSSourceFile.fromFile("(STRING  [empty_block: 1])");
        com.google.javascript.jscomp.SourceFile.Generator generator11 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile12 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("", generator11);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile14 = com.google.javascript.jscomp.JSSourceFile.fromFile("(STRING  [empty_block: 1])");
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray15 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile4, jSSourceFile7, jSSourceFile9, jSSourceFile12, jSSourceFile14 };
        com.google.javascript.jscomp.JSModule[] jSModuleArray16 = new com.google.javascript.jscomp.JSModule[] {};
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph17 = new com.google.javascript.jscomp.JSModuleGraph(jSModuleArray16);
        com.google.javascript.jscomp.CompilerOptions compilerOptions18 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CompilerOptions.TracerMode tracerMode19 = compilerOptions18.tracer;
        compiler1.init(jSSourceFileArray15, jSModuleArray16, compilerOptions18);
        compilerOptions18.checkEs5Strict = false;
        compilerOptions18.flowSensitiveInlineVariables = false;
        compilerOptions18.removeTryCatchFinally = true;
        compilerOptions18.setCollapsePropertiesOnExternTypes(true);
        compilerOptions18.computeFunctionSideEffects = true;
        org.junit.Assert.assertNotNull(jSSourceFile4);
        org.junit.Assert.assertNotNull(jSSourceFile7);
        org.junit.Assert.assertNotNull(jSSourceFile9);
        org.junit.Assert.assertNotNull(jSSourceFile12);
        org.junit.Assert.assertNotNull(jSSourceFile14);
        org.junit.Assert.assertNotNull(jSSourceFileArray15);
        org.junit.Assert.assertNotNull(jSModuleArray16);
        org.junit.Assert.assertTrue("'" + tracerMode19 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TracerMode.OFF + "'", tracerMode19.equals(com.google.javascript.jscomp.CompilerOptions.TracerMode.OFF));
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention0 = new com.google.javascript.jscomp.DefaultCodingConvention();
        java.lang.String str1 = defaultCodingConvention0.getExportSymbolFunction();
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node4 = node3.getParent();
        boolean boolean5 = node3.isQuotedString();
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship6 = defaultCodingConvention0.getDelegateRelationship(node3);
        java.util.Collection<com.google.javascript.rhino.Node> nodeCollection7 = com.google.javascript.jscomp.NodeUtil.getVarsDeclaredInBranch(node3);
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node11 = node10.getParent();
        boolean boolean12 = node10.isQuotedString();
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node15 = node14.getParent();
        boolean boolean16 = node14.hasChildren();
        node14.detachChildren();
        java.lang.String str18 = node14.getString();
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node21 = node20.getParent();
        boolean boolean22 = node20.isQuotedString();
        com.google.javascript.rhino.Node node24 = com.google.javascript.rhino.Node.newString("");
        int int25 = node24.getSideEffectFlags();
        boolean boolean26 = node24.isOptionalArg();
        com.google.javascript.rhino.Node node27 = node24.getLastSibling();
        com.google.javascript.rhino.Node node30 = new com.google.javascript.rhino.Node((int) (short) 10, node10, node14, node20, node24, (int) '4', (int) 'a');
        com.google.javascript.rhino.Node node31 = node3.copyInformationFrom(node14);
        java.lang.Appendable appendable32 = null;
        try {
            node31.appendStringTree(appendable32);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNull(node4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(delegateRelationship6);
        org.junit.Assert.assertNotNull(nodeCollection7);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNull(node11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNull(node15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "" + "'", str18.equals(""));
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNull(node21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(node27);
        org.junit.Assert.assertNotNull(node31);
    }

//    @Test
//    public void test327() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test327");
//        com.google.javascript.rhino.Context context0 = null;
//        com.google.javascript.rhino.Context context1 = com.google.javascript.rhino.Context.enter(context0);
//        java.util.Locale locale2 = null;
//        java.util.Locale locale3 = context1.setLocale(locale2);
//        context1.setCompileFunctionsWithDynamicScope(true);
//        context1.setInstructionObserverThreshold((int) (byte) 10);
//        boolean boolean9 = context1.isActivationNeeded("com.google.javascript.rhino.EcmaError: 100: Not declared as a constructor");
//        org.junit.Assert.assertNotNull(context1);
//        org.junit.Assert.assertNull(locale3);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.Node.newString("");
        int int3 = node2.getSideEffectFlags();
        boolean boolean4 = node2.isOptionalArg();
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention5 = new com.google.javascript.jscomp.DefaultCodingConvention();
        java.lang.String str6 = defaultCodingConvention5.getExportSymbolFunction();
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node9 = node8.getParent();
        boolean boolean10 = node8.isQuotedString();
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship11 = defaultCodingConvention5.getDelegateRelationship(node8);
        com.google.javascript.rhino.Node node12 = com.google.javascript.jscomp.NodeUtil.newExpr(node8);
        com.google.javascript.rhino.Node node15 = new com.google.javascript.rhino.Node((int) (short) 0, node2, node12, (int) (byte) 1, 0);
        boolean boolean16 = node15.hasMoreThanOneChild();
        try {
            com.google.javascript.rhino.Node node17 = node15.detachFromParent();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNull(node9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNull(delegateRelationship11);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newString("");
        int int2 = node1.getSideEffectFlags();
        boolean boolean3 = node1.isOptionalArg();
        int int5 = node1.getIntProp(34);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder6 = node1.new FileLevelJsDocBuilder();
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.SourceFile.Generator generator3 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile4 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("", generator3);
        com.google.javascript.jscomp.CompilerInput compilerInput5 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile4);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile7 = com.google.javascript.jscomp.JSSourceFile.fromFile("(STRING  [empty_block: 1])");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile9 = com.google.javascript.jscomp.JSSourceFile.fromFile("(STRING  [empty_block: 1])");
        com.google.javascript.jscomp.SourceFile.Generator generator11 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile12 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("", generator11);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile14 = com.google.javascript.jscomp.JSSourceFile.fromFile("(STRING  [empty_block: 1])");
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray15 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile4, jSSourceFile7, jSSourceFile9, jSSourceFile12, jSSourceFile14 };
        com.google.javascript.jscomp.JSModule[] jSModuleArray16 = new com.google.javascript.jscomp.JSModule[] {};
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph17 = new com.google.javascript.jscomp.JSModuleGraph(jSModuleArray16);
        com.google.javascript.jscomp.CompilerOptions compilerOptions18 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CompilerOptions.TracerMode tracerMode19 = compilerOptions18.tracer;
        compiler1.init(jSSourceFileArray15, jSModuleArray16, compilerOptions18);
        compilerOptions18.setGenerateExports(true);
        compilerOptions18.jsOutputFile = "21";
        compilerOptions18.removeUnusedPrototypeProperties = false;
        compilerOptions18.markAsCompiled = false;
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention31 = new com.google.javascript.jscomp.DefaultCodingConvention();
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention32 = new com.google.javascript.jscomp.DefaultCodingConvention();
        java.lang.String str33 = defaultCodingConvention32.getExportSymbolFunction();
        com.google.javascript.rhino.Node node35 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node36 = node35.getParent();
        boolean boolean37 = node35.isQuotedString();
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship38 = defaultCodingConvention32.getDelegateRelationship(node35);
        com.google.javascript.jscomp.CodingConvention.SubclassRelationship subclassRelationship39 = defaultCodingConvention31.getClassesDefinedByCall(node35);
        com.google.javascript.jscomp.CheckLevel checkLevel41 = com.google.javascript.jscomp.CheckLevel.ERROR;
        com.google.javascript.jscomp.DiagnosticType diagnosticType43 = com.google.javascript.jscomp.DiagnosticType.make("@IMPLEMENTATION.VERSION@", checkLevel41, "error reporter");
        com.google.javascript.jscomp.DiagnosticType diagnosticType46 = com.google.javascript.jscomp.DiagnosticType.error("100", "language version");
        java.lang.String[] strArray47 = com.google.javascript.rhino.ScriptRuntime.emptyStrings;
        com.google.javascript.jscomp.JSError jSError48 = com.google.javascript.jscomp.JSError.make("STRING  [empty_block: 1]", node35, checkLevel41, diagnosticType46, strArray47);
        com.google.javascript.jscomp.DiagnosticType diagnosticType50 = com.google.javascript.jscomp.DiagnosticType.make("", checkLevel41, "STRING  [empty_block: 1]");
        compilerOptions18.checkShadowVars = checkLevel41;
        compilerOptions18.debugFunctionSideEffectsPath = "language version";
        org.junit.Assert.assertNotNull(jSSourceFile4);
        org.junit.Assert.assertNotNull(jSSourceFile7);
        org.junit.Assert.assertNotNull(jSSourceFile9);
        org.junit.Assert.assertNotNull(jSSourceFile12);
        org.junit.Assert.assertNotNull(jSSourceFile14);
        org.junit.Assert.assertNotNull(jSSourceFileArray15);
        org.junit.Assert.assertNotNull(jSModuleArray16);
        org.junit.Assert.assertTrue("'" + tracerMode19 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TracerMode.OFF + "'", tracerMode19.equals(com.google.javascript.jscomp.CompilerOptions.TracerMode.OFF));
        org.junit.Assert.assertNull(str33);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertNull(node36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNull(delegateRelationship38);
        org.junit.Assert.assertNull(subclassRelationship39);
        org.junit.Assert.assertTrue("'" + checkLevel41 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel41.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticType43);
        org.junit.Assert.assertNotNull(diagnosticType46);
        org.junit.Assert.assertNotNull(strArray47);
        org.junit.Assert.assertNotNull(jSError48);
        org.junit.Assert.assertNotNull(diagnosticType50);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.Node.newString("");
        int int3 = node2.getSideEffectFlags();
        boolean boolean4 = node2.isOptionalArg();
        int int6 = node2.getIntProp(34);
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString("");
        int int9 = node8.getSideEffectFlags();
        boolean boolean10 = node8.isOptionalArg();
        com.google.javascript.rhino.Node node11 = null;
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node14 = node13.getParent();
        boolean boolean15 = node13.hasChildren();
        node13.detachChildren();
        java.lang.String str17 = node13.getString();
        try {
            com.google.javascript.rhino.Node node20 = new com.google.javascript.rhino.Node(160, node2, node8, node11, node13, 150, (-2));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNull(node14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node3 = node2.getParent();
        boolean boolean4 = node2.isQuotedString();
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString("");
        int int7 = node6.getSideEffectFlags();
        boolean boolean8 = node6.isOptionalArg();
        com.google.javascript.rhino.Node node9 = node6.getLastSibling();
        com.google.javascript.rhino.Node node10 = new com.google.javascript.rhino.Node((int) (byte) 1, node2, node6);
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertNull(node3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(node9);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.shouldColorizeErrorOutput();
        boolean boolean2 = compilerOptions0.reserveRawExports;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        int int0 = com.google.javascript.rhino.Context.VERSION_1_0;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 100 + "'", int0 == 100);
    }

//    @Test
//    public void test335() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test335");
//        com.google.javascript.rhino.Context context0 = null;
//        com.google.javascript.rhino.Context context1 = com.google.javascript.rhino.Context.enter(context0);
//        java.util.Locale locale2 = null;
//        java.util.Locale locale3 = context1.setLocale(locale2);
//        context1.setCompileFunctionsWithDynamicScope(true);
//        java.beans.PropertyChangeListener propertyChangeListener6 = null;
//        try {
//            context1.addPropertyChangeListener(propertyChangeListener6);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(context1);
//        org.junit.Assert.assertNull(locale3);
//    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node2 = node1.getParent();
        boolean boolean3 = node1.hasChildren();
        java.lang.String str4 = node1.getQualifiedName();
        java.lang.Object obj6 = node1.getProp(100);
        int int7 = node1.getLineno();
        try {
            int int9 = node1.getExistingIntProp((int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: FAILED ASSERTION");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertNull(node2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNull(obj6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        com.google.javascript.jscomp.DiagnosticType diagnosticType0 = com.google.javascript.jscomp.Compiler.MOTION_ITERATIONS_ERROR;
        com.google.javascript.jscomp.DiagnosticType diagnosticType3 = com.google.javascript.jscomp.DiagnosticType.warning("window", "");
        com.google.javascript.jscomp.DiagnosticType diagnosticType6 = com.google.javascript.jscomp.DiagnosticType.error("100", "language version");
        com.google.javascript.jscomp.CheckLevel checkLevel7 = diagnosticType6.defaultLevel;
        java.lang.String str8 = diagnosticType6.toString();
        com.google.javascript.jscomp.DiagnosticType diagnosticType9 = com.google.javascript.jscomp.Compiler.MOTION_ITERATIONS_ERROR;
        com.google.javascript.jscomp.CheckLevel checkLevel10 = diagnosticType9.level;
        com.google.javascript.jscomp.MessageFormatter messageFormatter11 = null;
        java.util.logging.Logger logger12 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager13 = new com.google.javascript.jscomp.LoggerErrorManager(messageFormatter11, logger12);
        loggerErrorManager13.setTypedPercent((double) (-2));
        com.google.javascript.jscomp.CheckLevel checkLevel17 = com.google.javascript.jscomp.CheckLevel.ERROR;
        com.google.javascript.jscomp.DiagnosticType diagnosticType19 = com.google.javascript.jscomp.DiagnosticType.make("@IMPLEMENTATION.VERSION@", checkLevel17, "error reporter");
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention20 = new com.google.javascript.jscomp.DefaultCodingConvention();
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention21 = new com.google.javascript.jscomp.DefaultCodingConvention();
        java.lang.String str22 = defaultCodingConvention21.getExportSymbolFunction();
        com.google.javascript.rhino.Node node24 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node25 = node24.getParent();
        boolean boolean26 = node24.isQuotedString();
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship27 = defaultCodingConvention21.getDelegateRelationship(node24);
        com.google.javascript.jscomp.CodingConvention.SubclassRelationship subclassRelationship28 = defaultCodingConvention20.getClassesDefinedByCall(node24);
        java.lang.RuntimeException runtimeException29 = com.google.javascript.rhino.ScriptRuntime.undefWriteError((java.lang.Object) (-2), (java.lang.Object) diagnosticType19, (java.lang.Object) defaultCodingConvention20);
        com.google.javascript.jscomp.DiagnosticType diagnosticType30 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        com.google.javascript.jscomp.DiagnosticType[] diagnosticTypeArray31 = new com.google.javascript.jscomp.DiagnosticType[] { diagnosticType0, diagnosticType3, diagnosticType6, diagnosticType9, diagnosticType19, diagnosticType30 };
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup32 = new com.google.javascript.jscomp.DiagnosticGroup(diagnosticTypeArray31);
        org.junit.Assert.assertNotNull(diagnosticType0);
        org.junit.Assert.assertNotNull(diagnosticType3);
        org.junit.Assert.assertNotNull(diagnosticType6);
        org.junit.Assert.assertTrue("'" + checkLevel7 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel7.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "100: language version" + "'", str8.equals("100: language version"));
        org.junit.Assert.assertNotNull(diagnosticType9);
        org.junit.Assert.assertTrue("'" + checkLevel10 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel10.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + checkLevel17 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel17.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticType19);
        org.junit.Assert.assertNull(str22);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertNull(node25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNull(delegateRelationship27);
        org.junit.Assert.assertNull(subclassRelationship28);
        org.junit.Assert.assertNotNull(runtimeException29);
        org.junit.Assert.assertNotNull(diagnosticType30);
        org.junit.Assert.assertNotNull(diagnosticTypeArray31);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        com.google.javascript.rhino.Node.SideEffectFlags sideEffectFlags1 = new com.google.javascript.rhino.Node.SideEffectFlags((int) ' ');
        sideEffectFlags1.setMutatesThis();
        sideEffectFlags1.setMutatesArguments();
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.SourceFile.Generator generator3 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile4 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("", generator3);
        com.google.javascript.jscomp.CompilerInput compilerInput5 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile4);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile7 = com.google.javascript.jscomp.JSSourceFile.fromFile("(STRING  [empty_block: 1])");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile9 = com.google.javascript.jscomp.JSSourceFile.fromFile("(STRING  [empty_block: 1])");
        com.google.javascript.jscomp.SourceFile.Generator generator11 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile12 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("", generator11);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile14 = com.google.javascript.jscomp.JSSourceFile.fromFile("(STRING  [empty_block: 1])");
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray15 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile4, jSSourceFile7, jSSourceFile9, jSSourceFile12, jSSourceFile14 };
        com.google.javascript.jscomp.JSModule[] jSModuleArray16 = new com.google.javascript.jscomp.JSModule[] {};
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph17 = new com.google.javascript.jscomp.JSModuleGraph(jSModuleArray16);
        com.google.javascript.jscomp.CompilerOptions compilerOptions18 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CompilerOptions.TracerMode tracerMode19 = compilerOptions18.tracer;
        compiler1.init(jSSourceFileArray15, jSModuleArray16, compilerOptions18);
        compilerOptions18.setGenerateExports(true);
        compilerOptions18.jsOutputFile = "21";
        compilerOptions18.removeUnusedPrototypeProperties = false;
        byte[] byteArray27 = compilerOptions18.inputVariableMapSerialized;
        java.util.Set<java.lang.String> strSet28 = compilerOptions18.stripNameSuffixes;
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention30 = new com.google.javascript.jscomp.DefaultCodingConvention();
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention31 = new com.google.javascript.jscomp.DefaultCodingConvention();
        java.lang.String str32 = defaultCodingConvention31.getExportSymbolFunction();
        com.google.javascript.rhino.Node node34 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node35 = node34.getParent();
        boolean boolean36 = node34.isQuotedString();
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship37 = defaultCodingConvention31.getDelegateRelationship(node34);
        com.google.javascript.jscomp.CodingConvention.SubclassRelationship subclassRelationship38 = defaultCodingConvention30.getClassesDefinedByCall(node34);
        com.google.javascript.jscomp.CheckLevel checkLevel40 = com.google.javascript.jscomp.CheckLevel.ERROR;
        com.google.javascript.jscomp.DiagnosticType diagnosticType42 = com.google.javascript.jscomp.DiagnosticType.make("@IMPLEMENTATION.VERSION@", checkLevel40, "error reporter");
        com.google.javascript.jscomp.DiagnosticType diagnosticType45 = com.google.javascript.jscomp.DiagnosticType.error("100", "language version");
        java.lang.String[] strArray46 = com.google.javascript.rhino.ScriptRuntime.emptyStrings;
        com.google.javascript.jscomp.JSError jSError47 = com.google.javascript.jscomp.JSError.make("STRING  [empty_block: 1]", node34, checkLevel40, diagnosticType45, strArray46);
        compilerOptions18.checkMissingGetCssNameLevel = checkLevel40;
        compilerOptions18.decomposeExpressions = true;
        org.junit.Assert.assertNotNull(jSSourceFile4);
        org.junit.Assert.assertNotNull(jSSourceFile7);
        org.junit.Assert.assertNotNull(jSSourceFile9);
        org.junit.Assert.assertNotNull(jSSourceFile12);
        org.junit.Assert.assertNotNull(jSSourceFile14);
        org.junit.Assert.assertNotNull(jSSourceFileArray15);
        org.junit.Assert.assertNotNull(jSModuleArray16);
        org.junit.Assert.assertTrue("'" + tracerMode19 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TracerMode.OFF + "'", tracerMode19.equals(com.google.javascript.jscomp.CompilerOptions.TracerMode.OFF));
        org.junit.Assert.assertNull(byteArray27);
        org.junit.Assert.assertNotNull(strSet28);
        org.junit.Assert.assertNull(str32);
        org.junit.Assert.assertNotNull(node34);
        org.junit.Assert.assertNull(node35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNull(delegateRelationship37);
        org.junit.Assert.assertNull(subclassRelationship38);
        org.junit.Assert.assertTrue("'" + checkLevel40 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel40.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticType42);
        org.junit.Assert.assertNotNull(diagnosticType45);
        org.junit.Assert.assertNotNull(strArray46);
        org.junit.Assert.assertNotNull(jSError47);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        int int0 = com.google.javascript.rhino.Node.RIGHT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        com.google.javascript.rhino.Context context0 = null;
        com.google.javascript.rhino.Context context1 = com.google.javascript.rhino.Context.enter(context0);
        java.util.Locale locale2 = context1.getLocale();
        boolean boolean3 = context1.isGeneratingDebug();
        com.google.javascript.rhino.ErrorReporter errorReporter4 = null;
        try {
            com.google.javascript.rhino.ErrorReporter errorReporter5 = context1.setErrorReporter(errorReporter4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(context1);
        org.junit.Assert.assertNotNull(locale2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        try {
            com.google.javascript.rhino.Context.checkOptimizationLevel(36);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Optimization level outside [-1..9]: 36");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test343() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test343");
//        try {
//            com.google.javascript.rhino.EvaluatorException evaluatorException1 = com.google.javascript.rhino.Context.reportRuntimeError("STRING  [empty_block: 1]");
//            org.junit.Assert.fail("Expected exception of type com.google.javascript.rhino.EvaluatorException; message: STRING  [empty_block: 1]");
//        } catch (com.google.javascript.rhino.EvaluatorException e) {
//        }
//    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.SourceFile.Generator generator3 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile4 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("", generator3);
        com.google.javascript.jscomp.CompilerInput compilerInput5 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile4);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile7 = com.google.javascript.jscomp.JSSourceFile.fromFile("(STRING  [empty_block: 1])");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile9 = com.google.javascript.jscomp.JSSourceFile.fromFile("(STRING  [empty_block: 1])");
        com.google.javascript.jscomp.SourceFile.Generator generator11 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile12 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("", generator11);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile14 = com.google.javascript.jscomp.JSSourceFile.fromFile("(STRING  [empty_block: 1])");
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray15 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile4, jSSourceFile7, jSSourceFile9, jSSourceFile12, jSSourceFile14 };
        com.google.javascript.jscomp.JSModule[] jSModuleArray16 = new com.google.javascript.jscomp.JSModule[] {};
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph17 = new com.google.javascript.jscomp.JSModuleGraph(jSModuleArray16);
        com.google.javascript.jscomp.CompilerOptions compilerOptions18 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CompilerOptions.TracerMode tracerMode19 = compilerOptions18.tracer;
        compiler1.init(jSSourceFileArray15, jSModuleArray16, compilerOptions18);
        compilerOptions18.checkEs5Strict = false;
        compilerOptions18.flowSensitiveInlineVariables = false;
        compilerOptions18.removeTryCatchFinally = true;
        compilerOptions18.setCollapsePropertiesOnExternTypes(true);
        compilerOptions18.foldConstants = false;
        org.junit.Assert.assertNotNull(jSSourceFile4);
        org.junit.Assert.assertNotNull(jSSourceFile7);
        org.junit.Assert.assertNotNull(jSSourceFile9);
        org.junit.Assert.assertNotNull(jSSourceFile12);
        org.junit.Assert.assertNotNull(jSSourceFile14);
        org.junit.Assert.assertNotNull(jSSourceFileArray15);
        org.junit.Assert.assertNotNull(jSModuleArray16);
        org.junit.Assert.assertTrue("'" + tracerMode19 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TracerMode.OFF + "'", tracerMode19.equals(com.google.javascript.jscomp.CompilerOptions.TracerMode.OFF));
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention0 = new com.google.javascript.jscomp.DefaultCodingConvention();
        java.lang.String str1 = defaultCodingConvention0.getExportSymbolFunction();
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node4 = node3.getParent();
        boolean boolean5 = node3.isQuotedString();
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship6 = defaultCodingConvention0.getDelegateRelationship(node3);
        java.util.Collection<com.google.javascript.rhino.Node> nodeCollection7 = com.google.javascript.jscomp.NodeUtil.getVarsDeclaredInBranch(node3);
        node3.setWasEmptyNode(true);
        com.google.javascript.rhino.Node node10 = null;
        try {
            boolean boolean11 = node3.isEquivalentTo(node10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNull(node4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(delegateRelationship6);
        org.junit.Assert.assertNotNull(nodeCollection7);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        java.lang.Object obj0 = null;
        java.lang.Object obj1 = null;
        java.lang.RuntimeException runtimeException2 = com.google.javascript.rhino.ScriptRuntime.undefCallError(obj0, obj1);
        org.junit.Assert.assertNotNull(runtimeException2);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        com.google.javascript.rhino.EcmaError ecmaError1 = com.google.javascript.rhino.ScriptRuntime.typeError("100");
        ecmaError1.initSourceName("com.google.javascript.rhino.EcmaError: 100: Not declared as a constructor");
        int int4 = ecmaError1.getLineNumber();
        org.junit.Assert.assertNotNull(ecmaError1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        com.google.javascript.rhino.Node.SideEffectFlags sideEffectFlags1 = new com.google.javascript.rhino.Node.SideEffectFlags((int) ' ');
        sideEffectFlags1.setReturnsTainted();
        sideEffectFlags1.setMutatesGlobalState();
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.CHECK_TYPES;
        com.google.javascript.jscomp.DiagnosticGroups.CHECK_TYPES = diagnosticGroup0;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.TYPE_INVALIDATION;
        com.google.javascript.jscomp.DiagnosticGroups.INTERNET_EXPLORER_CHECKS = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticGroups.CHECK_TYPES = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticGroups.VISIBILITY = diagnosticGroup0;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        java.lang.String str1 = com.google.javascript.rhino.jstype.ObjectType.createDelegateSuffix("100");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "(100)" + "'", str1.equals("(100)"));
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.AMBIGUOUS_FUNCTION_DECL;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention0 = new com.google.javascript.jscomp.DefaultCodingConvention();
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention1 = new com.google.javascript.jscomp.DefaultCodingConvention();
        java.lang.String str2 = defaultCodingConvention1.getExportSymbolFunction();
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node5 = node4.getParent();
        boolean boolean6 = node4.isQuotedString();
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship7 = defaultCodingConvention1.getDelegateRelationship(node4);
        com.google.javascript.jscomp.CodingConvention.SubclassRelationship subclassRelationship8 = defaultCodingConvention0.getClassesDefinedByCall(node4);
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention9 = new com.google.javascript.jscomp.DefaultCodingConvention();
        java.lang.String str10 = defaultCodingConvention9.getExportSymbolFunction();
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node13 = node12.getParent();
        boolean boolean14 = node12.isQuotedString();
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship15 = defaultCodingConvention9.getDelegateRelationship(node12);
        java.util.Collection<com.google.javascript.rhino.Node> nodeCollection16 = com.google.javascript.jscomp.NodeUtil.getVarsDeclaredInBranch(node12);
        com.google.javascript.rhino.JSDocInfo jSDocInfo17 = node12.getJSDocInfo();
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node20 = node19.getParent();
        boolean boolean21 = node19.hasChildren();
        node19.detachChildren();
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder23 = node19.getJsDocBuilderForNode();
        int int24 = node19.getType();
        com.google.javascript.rhino.Node node25 = node12.copyInformationFrom(node19);
        boolean boolean26 = node19.hasOneChild();
        java.lang.String str27 = defaultCodingConvention0.identifyTypeDefAssign(node19);
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNull(node5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(delegateRelationship7);
        org.junit.Assert.assertNull(subclassRelationship8);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNull(node13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNull(delegateRelationship15);
        org.junit.Assert.assertNotNull(nodeCollection16);
        org.junit.Assert.assertNull(jSDocInfo17);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNull(node20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 40 + "'", int24 == 40);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNull(str27);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        com.google.javascript.jscomp.SourceFile.Generator generator1 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("", generator1);
        com.google.javascript.jscomp.CompilerInput compilerInput4 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2, true);
        java.nio.charset.Charset charset6 = null;
        com.google.javascript.jscomp.SourceFile sourceFile7 = com.google.javascript.jscomp.SourceFile.fromFile("", charset6);
        compilerInput4.setSourceFile(sourceFile7);
        com.google.javascript.jscomp.SourceFile.Generator generator10 = null;
        com.google.javascript.jscomp.SourceFile sourceFile11 = com.google.javascript.jscomp.SourceFile.fromGenerator("", generator10);
        java.lang.String str12 = sourceFile11.getOriginalPath();
        compilerInput4.setSourceFile(sourceFile11);
        com.google.javascript.jscomp.JSModule jSModule14 = null;
        compilerInput4.setModule(jSModule14);
        compilerInput4.clearAst();
        com.google.javascript.jscomp.SourceFile sourceFile20 = com.google.javascript.jscomp.SourceFile.fromCode("hi!", "window", "");
        try {
            compilerInput4.setSourceFile(sourceFile20);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile2);
        org.junit.Assert.assertNotNull(sourceFile7);
        org.junit.Assert.assertNotNull(sourceFile11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertNotNull(sourceFile20);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = null;
        com.google.javascript.jscomp.DiagnosticGroups.GLOBAL_THIS = diagnosticGroup0;
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.CHECK_VARIABLES;
        com.google.javascript.jscomp.DiagnosticGroups.FILEOVERVIEW_JSDOC = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticGroups.CHECK_TYPES = diagnosticGroup0;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.Compiler.IntermediateState intermediateState1 = compiler0.getState();
        com.google.javascript.jscomp.PassConfig passConfig2 = null;
        try {
            compiler0.setPassConfig(passConfig2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intermediateState1);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.SourceFile.Generator generator3 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile4 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("", generator3);
        com.google.javascript.jscomp.CompilerInput compilerInput5 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile4);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile7 = com.google.javascript.jscomp.JSSourceFile.fromFile("(STRING  [empty_block: 1])");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile9 = com.google.javascript.jscomp.JSSourceFile.fromFile("(STRING  [empty_block: 1])");
        com.google.javascript.jscomp.SourceFile.Generator generator11 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile12 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("", generator11);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile14 = com.google.javascript.jscomp.JSSourceFile.fromFile("(STRING  [empty_block: 1])");
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray15 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile4, jSSourceFile7, jSSourceFile9, jSSourceFile12, jSSourceFile14 };
        com.google.javascript.jscomp.JSModule[] jSModuleArray16 = new com.google.javascript.jscomp.JSModule[] {};
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph17 = new com.google.javascript.jscomp.JSModuleGraph(jSModuleArray16);
        com.google.javascript.jscomp.CompilerOptions compilerOptions18 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CompilerOptions.TracerMode tracerMode19 = compilerOptions18.tracer;
        compiler1.init(jSSourceFileArray15, jSModuleArray16, compilerOptions18);
        compilerOptions18.setGenerateExports(true);
        compilerOptions18.jsOutputFile = "21";
        compilerOptions18.removeUnusedPrototypeProperties = false;
        byte[] byteArray27 = compilerOptions18.inputVariableMapSerialized;
        java.util.Set<java.lang.String> strSet28 = compilerOptions18.stripNameSuffixes;
        boolean boolean29 = compilerOptions18.crossModuleMethodMotion;
        org.junit.Assert.assertNotNull(jSSourceFile4);
        org.junit.Assert.assertNotNull(jSSourceFile7);
        org.junit.Assert.assertNotNull(jSSourceFile9);
        org.junit.Assert.assertNotNull(jSSourceFile12);
        org.junit.Assert.assertNotNull(jSSourceFile14);
        org.junit.Assert.assertNotNull(jSSourceFileArray15);
        org.junit.Assert.assertNotNull(jSModuleArray16);
        org.junit.Assert.assertTrue("'" + tracerMode19 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TracerMode.OFF + "'", tracerMode19.equals(com.google.javascript.jscomp.CompilerOptions.TracerMode.OFF));
        org.junit.Assert.assertNull(byteArray27);
        org.junit.Assert.assertNotNull(strSet28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        java.io.InputStream inputStream1 = null;
        try {
            com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromInputStream("com.google.javascript.rhino.EcmaError: 100: Not declared as a constructor", inputStream1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention0 = new com.google.javascript.jscomp.DefaultCodingConvention();
        java.lang.String str1 = defaultCodingConvention0.getGlobalObject();
        java.lang.String str2 = defaultCodingConvention0.getExportSymbolFunction();
        com.google.javascript.jscomp.NodeTraversal nodeTraversal3 = null;
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString("");
        int int7 = node6.getSideEffectFlags();
        boolean boolean8 = node6.isOptionalArg();
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention9 = new com.google.javascript.jscomp.DefaultCodingConvention();
        java.lang.String str10 = defaultCodingConvention9.getExportSymbolFunction();
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node13 = node12.getParent();
        boolean boolean14 = node12.isQuotedString();
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship15 = defaultCodingConvention9.getDelegateRelationship(node12);
        com.google.javascript.rhino.Node node16 = com.google.javascript.jscomp.NodeUtil.newExpr(node12);
        com.google.javascript.rhino.Node node19 = new com.google.javascript.rhino.Node((int) (short) 0, node6, node16, (int) (byte) 1, 0);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder20 = node19.getJsDocBuilderForNode();
        com.google.javascript.rhino.Node node21 = com.google.javascript.jscomp.NodeUtil.newExpr(node19);
        com.google.javascript.jscomp.CodingConvention.ObjectLiteralCast objectLiteralCast22 = defaultCodingConvention0.getObjectLiteralCast(nodeTraversal3, node19);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "window" + "'", str1.equals("window"));
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNull(node13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNull(delegateRelationship15);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder20);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertNull(objectLiteralCast22);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.SourceFile.Generator generator3 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile4 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("", generator3);
        com.google.javascript.jscomp.CompilerInput compilerInput5 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile4);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile7 = com.google.javascript.jscomp.JSSourceFile.fromFile("(STRING  [empty_block: 1])");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile9 = com.google.javascript.jscomp.JSSourceFile.fromFile("(STRING  [empty_block: 1])");
        com.google.javascript.jscomp.SourceFile.Generator generator11 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile12 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("", generator11);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile14 = com.google.javascript.jscomp.JSSourceFile.fromFile("(STRING  [empty_block: 1])");
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray15 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile4, jSSourceFile7, jSSourceFile9, jSSourceFile12, jSSourceFile14 };
        com.google.javascript.jscomp.JSModule[] jSModuleArray16 = new com.google.javascript.jscomp.JSModule[] {};
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph17 = new com.google.javascript.jscomp.JSModuleGraph(jSModuleArray16);
        com.google.javascript.jscomp.CompilerOptions compilerOptions18 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CompilerOptions.TracerMode tracerMode19 = compilerOptions18.tracer;
        compiler1.init(jSSourceFileArray15, jSModuleArray16, compilerOptions18);
        boolean boolean21 = compiler1.isTypeCheckingEnabled();
        java.util.List<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList22 = null;
        com.google.javascript.jscomp.JSModule[] jSModuleArray23 = new com.google.javascript.jscomp.JSModule[] {};
        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList24 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
        boolean boolean25 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList24, jSModuleArray23);
        java.io.PrintStream printStream26 = null;
        com.google.javascript.jscomp.Compiler compiler27 = new com.google.javascript.jscomp.Compiler(printStream26);
        com.google.javascript.jscomp.SourceFile.Generator generator29 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile30 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("", generator29);
        com.google.javascript.jscomp.CompilerInput compilerInput31 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile30);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile33 = com.google.javascript.jscomp.JSSourceFile.fromFile("(STRING  [empty_block: 1])");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile35 = com.google.javascript.jscomp.JSSourceFile.fromFile("(STRING  [empty_block: 1])");
        com.google.javascript.jscomp.SourceFile.Generator generator37 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile38 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("", generator37);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile40 = com.google.javascript.jscomp.JSSourceFile.fromFile("(STRING  [empty_block: 1])");
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray41 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile30, jSSourceFile33, jSSourceFile35, jSSourceFile38, jSSourceFile40 };
        com.google.javascript.jscomp.JSModule[] jSModuleArray42 = new com.google.javascript.jscomp.JSModule[] {};
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph43 = new com.google.javascript.jscomp.JSModuleGraph(jSModuleArray42);
        com.google.javascript.jscomp.CompilerOptions compilerOptions44 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CompilerOptions.TracerMode tracerMode45 = compilerOptions44.tracer;
        compiler27.init(jSSourceFileArray41, jSModuleArray42, compilerOptions44);
        compilerOptions44.setGenerateExports(true);
        compilerOptions44.inferTypesInGlobalScope = true;
        boolean boolean51 = compilerOptions44.inferTypesInGlobalScope;
        try {
            com.google.javascript.jscomp.Result result52 = compiler1.compileModules(jSSourceFileList22, (java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList24, compilerOptions44);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile4);
        org.junit.Assert.assertNotNull(jSSourceFile7);
        org.junit.Assert.assertNotNull(jSSourceFile9);
        org.junit.Assert.assertNotNull(jSSourceFile12);
        org.junit.Assert.assertNotNull(jSSourceFile14);
        org.junit.Assert.assertNotNull(jSSourceFileArray15);
        org.junit.Assert.assertNotNull(jSModuleArray16);
        org.junit.Assert.assertTrue("'" + tracerMode19 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TracerMode.OFF + "'", tracerMode19.equals(com.google.javascript.jscomp.CompilerOptions.TracerMode.OFF));
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(jSModuleArray23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(jSSourceFile30);
        org.junit.Assert.assertNotNull(jSSourceFile33);
        org.junit.Assert.assertNotNull(jSSourceFile35);
        org.junit.Assert.assertNotNull(jSSourceFile38);
        org.junit.Assert.assertNotNull(jSSourceFile40);
        org.junit.Assert.assertNotNull(jSSourceFileArray41);
        org.junit.Assert.assertNotNull(jSModuleArray42);
        org.junit.Assert.assertTrue("'" + tracerMode45 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TracerMode.OFF + "'", tracerMode45.equals(com.google.javascript.jscomp.CompilerOptions.TracerMode.OFF));
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + true + "'", boolean51 == true);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        int int0 = com.google.javascript.rhino.Node.ISNUMBER_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 25 + "'", int0 == 25);
    }

//    @Test
//    public void test363() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test363");
//        com.google.javascript.rhino.Context context0 = null;
//        com.google.javascript.rhino.Context context1 = com.google.javascript.rhino.Context.enter(context0);
//        java.util.Locale locale2 = null;
//        java.util.Locale locale3 = context1.setLocale(locale2);
//        context1.setCompileFunctionsWithDynamicScope(true);
//        context1.setInstructionObserverThreshold((int) (byte) 10);
//        long long8 = com.google.javascript.rhino.ScriptRuntime.lastUint32Result(context1);
//        java.lang.String str9 = context1.getImplementationVersion();
//        java.beans.PropertyChangeListener propertyChangeListener10 = null;
//        try {
//            context1.addPropertyChangeListener(propertyChangeListener10);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(context1);
//        org.junit.Assert.assertNull(locale3);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "@IMPLEMENTATION.VERSION@" + "'", str9.equals("@IMPLEMENTATION.VERSION@"));
//    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        java.lang.String str1 = com.google.javascript.rhino.Node.tokenToName(3);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "leavewith" + "'", str1.equals("leavewith"));
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention0 = new com.google.javascript.jscomp.DefaultCodingConvention();
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention1 = new com.google.javascript.jscomp.DefaultCodingConvention();
        java.lang.String str2 = defaultCodingConvention1.getExportSymbolFunction();
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node5 = node4.getParent();
        boolean boolean6 = node4.isQuotedString();
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship7 = defaultCodingConvention1.getDelegateRelationship(node4);
        com.google.javascript.jscomp.CodingConvention.SubclassRelationship subclassRelationship8 = defaultCodingConvention0.getClassesDefinedByCall(node4);
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention10 = new com.google.javascript.jscomp.DefaultCodingConvention();
        java.lang.String str11 = defaultCodingConvention10.getExportSymbolFunction();
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node14 = node13.getParent();
        boolean boolean15 = node13.isQuotedString();
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship16 = defaultCodingConvention10.getDelegateRelationship(node13);
        com.google.javascript.rhino.Node node17 = com.google.javascript.jscomp.NodeUtil.newExpr(node13);
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node20 = node19.getParent();
        boolean boolean21 = node19.isQuotedString();
        com.google.javascript.rhino.Node node24 = new com.google.javascript.rhino.Node(4, node17, node19, 35, 0);
        java.lang.String str25 = defaultCodingConvention0.getSingletonGetterClassName(node19);
        boolean boolean27 = defaultCodingConvention0.isSuperClassReference("language version");
        boolean boolean29 = defaultCodingConvention0.isValidEnumKey("error reporter");
        java.lang.String str30 = defaultCodingConvention0.getGlobalObject();
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNull(node5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(delegateRelationship7);
        org.junit.Assert.assertNull(subclassRelationship8);
        org.junit.Assert.assertNull(str11);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNull(node14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNull(delegateRelationship16);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNull(node20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNull(str25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "window" + "'", str30.equals("window"));
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        com.google.javascript.rhino.Context context0 = null;
        com.google.javascript.rhino.Context context1 = com.google.javascript.rhino.Context.enter(context0);
        java.util.Locale locale2 = context1.getLocale();
        boolean boolean3 = context1.isGeneratingDebug();
        java.lang.String str4 = context1.getImplementationVersion();
        context1.setLanguageVersion((int) (short) 0);
        context1.setGeneratingSource(false);
        org.junit.Assert.assertNotNull(context1);
        org.junit.Assert.assertNotNull(locale2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "@IMPLEMENTATION.VERSION@" + "'", str4.equals("@IMPLEMENTATION.VERSION@"));
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        com.google.javascript.rhino.Context context0 = null;
        com.google.javascript.rhino.Context context1 = com.google.javascript.rhino.Context.enter(context0);
        java.lang.Object obj2 = context1.getDebuggerContextData();
        context1.removeActivationName("21");
        com.google.javascript.rhino.ErrorReporter errorReporter5 = context1.getErrorReporter();
        long long6 = com.google.javascript.rhino.ScriptRuntime.lastUint32Result(context1);
        org.junit.Assert.assertNotNull(context1);
        org.junit.Assert.assertNull(obj2);
        org.junit.Assert.assertNull(errorReporter5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        java.io.File file0 = null;
        java.nio.charset.Charset charset1 = null;
        try {
            com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromFile(file0, charset1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        com.google.javascript.jscomp.SourceExcerptProvider sourceExcerptProvider0 = null;
        try {
            com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter1 = new com.google.javascript.jscomp.LightweightMessageFormatter(sourceExcerptProvider0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.SourceFile.Generator generator3 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile4 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("", generator3);
        com.google.javascript.jscomp.CompilerInput compilerInput5 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile4);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile7 = com.google.javascript.jscomp.JSSourceFile.fromFile("(STRING  [empty_block: 1])");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile9 = com.google.javascript.jscomp.JSSourceFile.fromFile("(STRING  [empty_block: 1])");
        com.google.javascript.jscomp.SourceFile.Generator generator11 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile12 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("", generator11);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile14 = com.google.javascript.jscomp.JSSourceFile.fromFile("(STRING  [empty_block: 1])");
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray15 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile4, jSSourceFile7, jSSourceFile9, jSSourceFile12, jSSourceFile14 };
        com.google.javascript.jscomp.JSModule[] jSModuleArray16 = new com.google.javascript.jscomp.JSModule[] {};
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph17 = new com.google.javascript.jscomp.JSModuleGraph(jSModuleArray16);
        com.google.javascript.jscomp.CompilerOptions compilerOptions18 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CompilerOptions.TracerMode tracerMode19 = compilerOptions18.tracer;
        compiler1.init(jSSourceFileArray15, jSModuleArray16, compilerOptions18);
        compilerOptions18.setGenerateExports(true);
        compilerOptions18.jsOutputFile = "21";
        compilerOptions18.removeUnusedPrototypeProperties = false;
        byte[] byteArray27 = compilerOptions18.inputVariableMapSerialized;
        compilerOptions18.setAcceptConstKeyword(false);
        compilerOptions18.generateExports = false;
        org.junit.Assert.assertNotNull(jSSourceFile4);
        org.junit.Assert.assertNotNull(jSSourceFile7);
        org.junit.Assert.assertNotNull(jSSourceFile9);
        org.junit.Assert.assertNotNull(jSSourceFile12);
        org.junit.Assert.assertNotNull(jSSourceFile14);
        org.junit.Assert.assertNotNull(jSSourceFileArray15);
        org.junit.Assert.assertNotNull(jSModuleArray16);
        org.junit.Assert.assertTrue("'" + tracerMode19 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TracerMode.OFF + "'", tracerMode19.equals(com.google.javascript.jscomp.CompilerOptions.TracerMode.OFF));
        org.junit.Assert.assertNull(byteArray27);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        com.google.javascript.jscomp.CompilerOptions.TracerMode tracerMode0 = com.google.javascript.jscomp.CompilerOptions.TracerMode.FAST;
        org.junit.Assert.assertTrue("'" + tracerMode0 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TracerMode.FAST + "'", tracerMode0.equals(com.google.javascript.jscomp.CompilerOptions.TracerMode.FAST));
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        com.google.javascript.rhino.Node.SideEffectFlags sideEffectFlags1 = new com.google.javascript.rhino.Node.SideEffectFlags(0);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        com.google.javascript.rhino.Node node1 = new com.google.javascript.rhino.Node((int) (short) -1);
        com.google.javascript.rhino.Node node2 = node1.getParent();
        org.junit.Assert.assertNull(node2);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup1 = com.google.javascript.jscomp.DiagnosticGroups.CHECK_TYPES;
        com.google.javascript.jscomp.DiagnosticGroups.NON_STANDARD_JSDOC = diagnosticGroup1;
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup3 = com.google.javascript.jscomp.DiagnosticGroups.TYPE_INVALIDATION;
        com.google.javascript.jscomp.DiagnosticGroups.CHECK_VARIABLES = diagnosticGroup3;
        com.google.javascript.jscomp.DiagnosticGroup[] diagnosticGroupArray5 = new com.google.javascript.jscomp.DiagnosticGroup[] { diagnosticGroup1, diagnosticGroup3 };
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup6 = new com.google.javascript.jscomp.DiagnosticGroup("TypeError", diagnosticGroupArray5);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup7 = new com.google.javascript.jscomp.DiagnosticGroup(diagnosticGroupArray5);
        org.junit.Assert.assertNotNull(diagnosticGroup1);
        org.junit.Assert.assertNotNull(diagnosticGroup3);
        org.junit.Assert.assertNotNull(diagnosticGroupArray5);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.SourceFile.Generator generator3 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile4 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("", generator3);
        com.google.javascript.jscomp.CompilerInput compilerInput5 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile4);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile7 = com.google.javascript.jscomp.JSSourceFile.fromFile("(STRING  [empty_block: 1])");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile9 = com.google.javascript.jscomp.JSSourceFile.fromFile("(STRING  [empty_block: 1])");
        com.google.javascript.jscomp.SourceFile.Generator generator11 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile12 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("", generator11);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile14 = com.google.javascript.jscomp.JSSourceFile.fromFile("(STRING  [empty_block: 1])");
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray15 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile4, jSSourceFile7, jSSourceFile9, jSSourceFile12, jSSourceFile14 };
        com.google.javascript.jscomp.JSModule[] jSModuleArray16 = new com.google.javascript.jscomp.JSModule[] {};
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph17 = new com.google.javascript.jscomp.JSModuleGraph(jSModuleArray16);
        com.google.javascript.jscomp.CompilerOptions compilerOptions18 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CompilerOptions.TracerMode tracerMode19 = compilerOptions18.tracer;
        compiler1.init(jSSourceFileArray15, jSModuleArray16, compilerOptions18);
        compilerOptions18.setGenerateExports(true);
        compilerOptions18.jsOutputFile = "21";
        compilerOptions18.removeUnusedPrototypeProperties = false;
        byte[] byteArray27 = compilerOptions18.inputVariableMapSerialized;
        java.io.PrintStream printStream28 = null;
        com.google.javascript.jscomp.Compiler compiler29 = new com.google.javascript.jscomp.Compiler(printStream28);
        com.google.javascript.jscomp.SourceFile.Generator generator31 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile32 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("", generator31);
        com.google.javascript.jscomp.CompilerInput compilerInput33 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile32);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile35 = com.google.javascript.jscomp.JSSourceFile.fromFile("(STRING  [empty_block: 1])");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile37 = com.google.javascript.jscomp.JSSourceFile.fromFile("(STRING  [empty_block: 1])");
        com.google.javascript.jscomp.SourceFile.Generator generator39 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile40 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("", generator39);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile42 = com.google.javascript.jscomp.JSSourceFile.fromFile("(STRING  [empty_block: 1])");
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray43 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile32, jSSourceFile35, jSSourceFile37, jSSourceFile40, jSSourceFile42 };
        com.google.javascript.jscomp.JSModule[] jSModuleArray44 = new com.google.javascript.jscomp.JSModule[] {};
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph45 = new com.google.javascript.jscomp.JSModuleGraph(jSModuleArray44);
        com.google.javascript.jscomp.CompilerOptions compilerOptions46 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CompilerOptions.TracerMode tracerMode47 = compilerOptions46.tracer;
        compiler29.init(jSSourceFileArray43, jSModuleArray44, compilerOptions46);
        compilerOptions46.setGenerateExports(true);
        compilerOptions46.jsOutputFile = "21";
        compilerOptions46.removeUnusedPrototypeProperties = false;
        byte[] byteArray55 = compilerOptions46.inputVariableMapSerialized;
        java.util.Set<java.lang.String> strSet56 = compilerOptions46.stripNameSuffixes;
        compilerOptions18.aliasableStrings = strSet56;
        boolean boolean58 = compilerOptions18.deadAssignmentElimination;
        boolean boolean59 = compilerOptions18.computeFunctionSideEffects;
        compilerOptions18.crossModuleMethodMotion = true;
        compilerOptions18.aliasExternals = false;
        boolean boolean64 = compilerOptions18.collapseProperties;
        org.junit.Assert.assertNotNull(jSSourceFile4);
        org.junit.Assert.assertNotNull(jSSourceFile7);
        org.junit.Assert.assertNotNull(jSSourceFile9);
        org.junit.Assert.assertNotNull(jSSourceFile12);
        org.junit.Assert.assertNotNull(jSSourceFile14);
        org.junit.Assert.assertNotNull(jSSourceFileArray15);
        org.junit.Assert.assertNotNull(jSModuleArray16);
        org.junit.Assert.assertTrue("'" + tracerMode19 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TracerMode.OFF + "'", tracerMode19.equals(com.google.javascript.jscomp.CompilerOptions.TracerMode.OFF));
        org.junit.Assert.assertNull(byteArray27);
        org.junit.Assert.assertNotNull(jSSourceFile32);
        org.junit.Assert.assertNotNull(jSSourceFile35);
        org.junit.Assert.assertNotNull(jSSourceFile37);
        org.junit.Assert.assertNotNull(jSSourceFile40);
        org.junit.Assert.assertNotNull(jSSourceFile42);
        org.junit.Assert.assertNotNull(jSSourceFileArray43);
        org.junit.Assert.assertNotNull(jSModuleArray44);
        org.junit.Assert.assertTrue("'" + tracerMode47 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TracerMode.OFF + "'", tracerMode47.equals(com.google.javascript.jscomp.CompilerOptions.TracerMode.OFF));
        org.junit.Assert.assertNull(byteArray55);
        org.junit.Assert.assertNotNull(strSet56);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention1 = new com.google.javascript.jscomp.DefaultCodingConvention();
        boolean boolean3 = defaultCodingConvention1.isExported("window");
        compilerOptions0.setCodingConvention((com.google.javascript.jscomp.CodingConvention) defaultCodingConvention1);
        java.lang.String str5 = compilerOptions0.renamePrefix;
        java.util.Set<java.lang.String> strSet6 = compilerOptions0.stripNameSuffixes;
        boolean boolean7 = compilerOptions0.removeUnusedVars;
        boolean boolean8 = compilerOptions0.smartNameRemoval;
        compilerOptions0.markNoSideEffectCalls = false;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertNotNull(strSet6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        com.google.javascript.rhino.EvaluatorException evaluatorException4 = new com.google.javascript.rhino.EvaluatorException("com.google.javascript.rhino.EcmaError: 100: Not declared as a constructor", "hi!", 23);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup5 = com.google.javascript.jscomp.DiagnosticGroups.NON_STANDARD_JSDOC;
        com.google.javascript.jscomp.DiagnosticGroups.FILEOVERVIEW_JSDOC = diagnosticGroup5;
        com.google.javascript.jscomp.DiagnosticGroups.CHECK_REGEXP = diagnosticGroup5;
        try {
            java.lang.String str8 = com.google.javascript.rhino.ScriptRuntime.getMessage2("(100)", (java.lang.Object) 23, (java.lang.Object) diagnosticGroup5);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property (100)");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(diagnosticGroup5);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.Node.newString("");
        int int3 = node2.getSideEffectFlags();
        boolean boolean4 = node2.isOptionalArg();
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention5 = new com.google.javascript.jscomp.DefaultCodingConvention();
        java.lang.String str6 = defaultCodingConvention5.getExportSymbolFunction();
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node9 = node8.getParent();
        boolean boolean10 = node8.isQuotedString();
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship11 = defaultCodingConvention5.getDelegateRelationship(node8);
        com.google.javascript.rhino.Node node12 = com.google.javascript.jscomp.NodeUtil.newExpr(node8);
        com.google.javascript.rhino.Node node15 = new com.google.javascript.rhino.Node((int) (short) 0, node2, node12, (int) (byte) 1, 0);
        node2.setWasEmptyNode(false);
        node2.putBooleanProp(5, false);
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNull(node9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNull(delegateRelationship11);
        org.junit.Assert.assertNotNull(node12);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CompilerOptions.TracerMode tracerMode1 = compilerOptions0.tracer;
        boolean boolean2 = compilerOptions0.smartNameRemoval;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy3 = compilerOptions0.variableRenaming;
        compilerOptions0.decomposeExpressions = false;
        com.google.javascript.jscomp.ErrorFormat errorFormat6 = compilerOptions0.errorFormat;
        org.junit.Assert.assertTrue("'" + tracerMode1 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TracerMode.OFF + "'", tracerMode1.equals(com.google.javascript.jscomp.CompilerOptions.TracerMode.OFF));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy3 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.OFF + "'", variableRenamingPolicy3.equals(com.google.javascript.jscomp.VariableRenamingPolicy.OFF));
        org.junit.Assert.assertNotNull(errorFormat6);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        com.google.javascript.rhino.EvaluatorException evaluatorException5 = new com.google.javascript.rhino.EvaluatorException("21", "", (int) '#', "", 0);
    }

//    @Test
//    public void test381() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test381");
//        com.google.javascript.rhino.Context context0 = null;
//        com.google.javascript.rhino.Context context1 = com.google.javascript.rhino.Context.enter(context0);
//        java.util.Locale locale2 = null;
//        java.util.Locale locale3 = context1.setLocale(locale2);
//        boolean boolean4 = context1.isGeneratingDebug();
//        org.junit.Assert.assertNotNull(context1);
//        org.junit.Assert.assertNull(locale3);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node4 = node3.getParent();
        boolean boolean5 = node3.isQuotedString();
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention6 = new com.google.javascript.jscomp.DefaultCodingConvention();
        java.lang.String str7 = defaultCodingConvention6.getExportSymbolFunction();
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node10 = node9.getParent();
        boolean boolean11 = node9.isQuotedString();
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship12 = defaultCodingConvention6.getDelegateRelationship(node9);
        java.util.Collection<com.google.javascript.rhino.Node> nodeCollection13 = com.google.javascript.jscomp.NodeUtil.getVarsDeclaredInBranch(node9);
        com.google.javascript.rhino.JSDocInfo jSDocInfo14 = node9.getJSDocInfo();
        com.google.javascript.rhino.Node node15 = node3.copyInformationFromForTree(node9);
        boolean boolean16 = node9.hasSideEffects();
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node19 = node18.getParent();
        boolean boolean20 = node18.hasChildren();
        node18.detachChildren();
        node18.setWasEmptyNode(true);
        com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node26 = node25.getParent();
        boolean boolean27 = node25.hasChildren();
        node25.detachChildren();
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder29 = node25.getJsDocBuilderForNode();
        com.google.javascript.rhino.Node[] nodeArray30 = new com.google.javascript.rhino.Node[] { node9, node18, node25 };
        com.google.javascript.rhino.Node node33 = new com.google.javascript.rhino.Node(22, nodeArray30, 18, (int) (short) 1);
        try {
            com.google.javascript.rhino.Node node34 = new com.google.javascript.rhino.Node(8, nodeArray30);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: duplicate child");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNull(node4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNull(node10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNull(delegateRelationship12);
        org.junit.Assert.assertNotNull(nodeCollection13);
        org.junit.Assert.assertNull(jSDocInfo14);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNull(node19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNull(node26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder29);
        org.junit.Assert.assertNotNull(nodeArray30);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.SourceFile.Generator generator3 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile4 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("", generator3);
        com.google.javascript.jscomp.CompilerInput compilerInput5 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile4);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile7 = com.google.javascript.jscomp.JSSourceFile.fromFile("(STRING  [empty_block: 1])");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile9 = com.google.javascript.jscomp.JSSourceFile.fromFile("(STRING  [empty_block: 1])");
        com.google.javascript.jscomp.SourceFile.Generator generator11 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile12 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("", generator11);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile14 = com.google.javascript.jscomp.JSSourceFile.fromFile("(STRING  [empty_block: 1])");
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray15 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile4, jSSourceFile7, jSSourceFile9, jSSourceFile12, jSSourceFile14 };
        com.google.javascript.jscomp.JSModule[] jSModuleArray16 = new com.google.javascript.jscomp.JSModule[] {};
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph17 = new com.google.javascript.jscomp.JSModuleGraph(jSModuleArray16);
        com.google.javascript.jscomp.CompilerOptions compilerOptions18 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CompilerOptions.TracerMode tracerMode19 = compilerOptions18.tracer;
        compiler1.init(jSSourceFileArray15, jSModuleArray16, compilerOptions18);
        compilerOptions18.checkEs5Strict = false;
        boolean boolean23 = compilerOptions18.collapseProperties;
        compilerOptions18.instrumentationTemplate = "100: language version";
        org.junit.Assert.assertNotNull(jSSourceFile4);
        org.junit.Assert.assertNotNull(jSSourceFile7);
        org.junit.Assert.assertNotNull(jSSourceFile9);
        org.junit.Assert.assertNotNull(jSSourceFile12);
        org.junit.Assert.assertNotNull(jSSourceFile14);
        org.junit.Assert.assertNotNull(jSSourceFileArray15);
        org.junit.Assert.assertNotNull(jSModuleArray16);
        org.junit.Assert.assertTrue("'" + tracerMode19 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TracerMode.OFF + "'", tracerMode19.equals(com.google.javascript.jscomp.CompilerOptions.TracerMode.OFF));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.inlineFunctions;
        compilerOptions0.printInputDelimiter = false;
        compilerOptions0.markNoSideEffectCalls = false;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        com.google.javascript.jscomp.ErrorFormat errorFormat0 = com.google.javascript.jscomp.ErrorFormat.SOURCELESS;
        org.junit.Assert.assertNotNull(errorFormat0);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.Compiler.IntermediateState intermediateState1 = compiler0.getState();
        com.google.javascript.jscomp.JSModule jSModule2 = null;
        try {
            java.lang.String[] strArray3 = compiler0.toSourceArray(jSModule2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intermediateState1);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention1 = new com.google.javascript.jscomp.DefaultCodingConvention();
        boolean boolean3 = defaultCodingConvention1.isExported("window");
        compilerOptions0.setCodingConvention((com.google.javascript.jscomp.CodingConvention) defaultCodingConvention1);
        java.lang.String str5 = compilerOptions0.renamePrefix;
        java.util.Set<java.lang.String> strSet6 = compilerOptions0.stripNameSuffixes;
        boolean boolean7 = compilerOptions0.removeUnusedVars;
        java.lang.String str8 = compilerOptions0.aliasStringsBlacklist;
        boolean boolean9 = compilerOptions0.shouldColorizeErrorOutput();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertNotNull(strSet6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node2 = node1.getParent();
        boolean boolean3 = node1.hasChildren();
        node1.detachChildren();
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder5 = node1.getJsDocBuilderForNode();
        int int6 = node1.getType();
        com.google.javascript.rhino.jstype.JSType jSType7 = null;
        node1.setJSType(jSType7);
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertNull(node2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 40 + "'", int6 == 40);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        int int0 = com.google.javascript.rhino.Node.ENUM_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention0 = new com.google.javascript.jscomp.DefaultCodingConvention();
        java.lang.String str1 = defaultCodingConvention0.getExportSymbolFunction();
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node4 = node3.getParent();
        boolean boolean5 = node3.isQuotedString();
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship6 = defaultCodingConvention0.getDelegateRelationship(node3);
        com.google.javascript.rhino.Node node7 = com.google.javascript.jscomp.NodeUtil.newExpr(node3);
        java.lang.RuntimeException runtimeException8 = com.google.javascript.rhino.ScriptRuntime.notFunctionError((java.lang.Object) node7);
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNull(node4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(delegateRelationship6);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertNotNull(runtimeException8);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention1 = new com.google.javascript.jscomp.DefaultCodingConvention();
        boolean boolean3 = defaultCodingConvention1.isExported("window");
        compilerOptions0.setCodingConvention((com.google.javascript.jscomp.CodingConvention) defaultCodingConvention1);
        java.lang.String str5 = compilerOptions0.renamePrefix;
        java.util.Set<java.lang.String> strSet6 = compilerOptions0.stripNameSuffixes;
        boolean boolean7 = compilerOptions0.removeUnusedLocalVars;
        compilerOptions0.markNoSideEffectCalls = true;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertNotNull(strSet6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.SourceFile.Generator generator3 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile4 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("", generator3);
        com.google.javascript.jscomp.CompilerInput compilerInput5 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile4);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile7 = com.google.javascript.jscomp.JSSourceFile.fromFile("(STRING  [empty_block: 1])");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile9 = com.google.javascript.jscomp.JSSourceFile.fromFile("(STRING  [empty_block: 1])");
        com.google.javascript.jscomp.SourceFile.Generator generator11 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile12 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("", generator11);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile14 = com.google.javascript.jscomp.JSSourceFile.fromFile("(STRING  [empty_block: 1])");
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray15 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile4, jSSourceFile7, jSSourceFile9, jSSourceFile12, jSSourceFile14 };
        com.google.javascript.jscomp.JSModule[] jSModuleArray16 = new com.google.javascript.jscomp.JSModule[] {};
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph17 = new com.google.javascript.jscomp.JSModuleGraph(jSModuleArray16);
        com.google.javascript.jscomp.CompilerOptions compilerOptions18 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CompilerOptions.TracerMode tracerMode19 = compilerOptions18.tracer;
        compiler1.init(jSSourceFileArray15, jSModuleArray16, compilerOptions18);
        compilerOptions18.setGenerateExports(true);
        compilerOptions18.jsOutputFile = "21";
        compilerOptions18.removeUnusedPrototypeProperties = false;
        compilerOptions18.markAsCompiled = false;
        compilerOptions18.removeDeadCode = false;
        com.google.javascript.jscomp.CheckLevel checkLevel31 = compilerOptions18.checkProvides;
        compilerOptions18.setColorizeErrorOutput(false);
        org.junit.Assert.assertNotNull(jSSourceFile4);
        org.junit.Assert.assertNotNull(jSSourceFile7);
        org.junit.Assert.assertNotNull(jSSourceFile9);
        org.junit.Assert.assertNotNull(jSSourceFile12);
        org.junit.Assert.assertNotNull(jSSourceFile14);
        org.junit.Assert.assertNotNull(jSSourceFileArray15);
        org.junit.Assert.assertNotNull(jSModuleArray16);
        org.junit.Assert.assertTrue("'" + tracerMode19 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TracerMode.OFF + "'", tracerMode19.equals(com.google.javascript.jscomp.CompilerOptions.TracerMode.OFF));
        org.junit.Assert.assertTrue("'" + checkLevel31 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel31.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention0 = new com.google.javascript.jscomp.DefaultCodingConvention();
        java.lang.String str1 = defaultCodingConvention0.getExportSymbolFunction();
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node4 = node3.getParent();
        boolean boolean5 = node3.isQuotedString();
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship6 = defaultCodingConvention0.getDelegateRelationship(node3);
        com.google.javascript.rhino.Node node7 = com.google.javascript.jscomp.NodeUtil.newExpr(node3);
        com.google.javascript.jscomp.SourceFile.Generator generator10 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile11 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("", generator10);
        com.google.javascript.jscomp.CompilerInput compilerInput13 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile11, true);
        com.google.javascript.jscomp.SourceFile sourceFile14 = compilerInput13.getSourceFile();
        com.google.javascript.jscomp.SourceFile sourceFile15 = compilerInput13.getSourceFile();
        node3.putProp(40, (java.lang.Object) sourceFile15);
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNull(node4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(delegateRelationship6);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertNotNull(jSSourceFile11);
        org.junit.Assert.assertNotNull(sourceFile14);
        org.junit.Assert.assertNotNull(sourceFile15);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention1 = new com.google.javascript.jscomp.DefaultCodingConvention();
        boolean boolean3 = defaultCodingConvention1.isExported("window");
        compilerOptions0.setCodingConvention((com.google.javascript.jscomp.CodingConvention) defaultCodingConvention1);
        java.lang.String str5 = compilerOptions0.renamePrefix;
        java.util.Set<java.lang.String> strSet6 = compilerOptions0.stripNameSuffixes;
        boolean boolean7 = compilerOptions0.generatePseudoNames;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertNotNull(strSet6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention0 = new com.google.javascript.jscomp.DefaultCodingConvention();
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention1 = new com.google.javascript.jscomp.DefaultCodingConvention();
        java.lang.String str2 = defaultCodingConvention1.getExportSymbolFunction();
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node5 = node4.getParent();
        boolean boolean6 = node4.isQuotedString();
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship7 = defaultCodingConvention1.getDelegateRelationship(node4);
        com.google.javascript.jscomp.CodingConvention.SubclassRelationship subclassRelationship8 = defaultCodingConvention0.getClassesDefinedByCall(node4);
        boolean boolean9 = node4.isQualifiedName();
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNull(node5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(delegateRelationship7);
        org.junit.Assert.assertNull(subclassRelationship8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        int int0 = com.google.javascript.rhino.Context.VERSION_DEFAULT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.CHECK_TYPES;
        com.google.javascript.jscomp.DiagnosticGroups.GLOBAL_THIS = diagnosticGroup0;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        int int0 = com.google.javascript.rhino.Node.EMPTY_BLOCK;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 38 + "'", int0 == 38);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node node1 = compiler0.getRoot();
        com.google.javascript.jscomp.Compiler.IntermediateState intermediateState2 = compiler0.getState();
        com.google.javascript.jscomp.SourceFile.Generator generator4 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile5 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("", generator4);
        com.google.javascript.jscomp.JSModule[] jSModuleArray6 = null;
        java.io.PrintStream printStream7 = null;
        com.google.javascript.jscomp.Compiler compiler8 = new com.google.javascript.jscomp.Compiler(printStream7);
        com.google.javascript.jscomp.SourceFile.Generator generator10 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile11 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("", generator10);
        com.google.javascript.jscomp.CompilerInput compilerInput12 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile11);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile14 = com.google.javascript.jscomp.JSSourceFile.fromFile("(STRING  [empty_block: 1])");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile16 = com.google.javascript.jscomp.JSSourceFile.fromFile("(STRING  [empty_block: 1])");
        com.google.javascript.jscomp.SourceFile.Generator generator18 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile19 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("", generator18);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile21 = com.google.javascript.jscomp.JSSourceFile.fromFile("(STRING  [empty_block: 1])");
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray22 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile11, jSSourceFile14, jSSourceFile16, jSSourceFile19, jSSourceFile21 };
        com.google.javascript.jscomp.JSModule[] jSModuleArray23 = new com.google.javascript.jscomp.JSModule[] {};
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph24 = new com.google.javascript.jscomp.JSModuleGraph(jSModuleArray23);
        com.google.javascript.jscomp.CompilerOptions compilerOptions25 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CompilerOptions.TracerMode tracerMode26 = compilerOptions25.tracer;
        compiler8.init(jSSourceFileArray22, jSModuleArray23, compilerOptions25);
        compilerOptions25.setGenerateExports(true);
        compilerOptions25.jsOutputFile = "21";
        compilerOptions25.removeUnusedPrototypeProperties = false;
        byte[] byteArray34 = compilerOptions25.inputVariableMapSerialized;
        java.io.PrintStream printStream35 = null;
        com.google.javascript.jscomp.Compiler compiler36 = new com.google.javascript.jscomp.Compiler(printStream35);
        com.google.javascript.jscomp.SourceFile.Generator generator38 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile39 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("", generator38);
        com.google.javascript.jscomp.CompilerInput compilerInput40 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile39);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile42 = com.google.javascript.jscomp.JSSourceFile.fromFile("(STRING  [empty_block: 1])");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile44 = com.google.javascript.jscomp.JSSourceFile.fromFile("(STRING  [empty_block: 1])");
        com.google.javascript.jscomp.SourceFile.Generator generator46 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile47 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("", generator46);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile49 = com.google.javascript.jscomp.JSSourceFile.fromFile("(STRING  [empty_block: 1])");
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray50 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile39, jSSourceFile42, jSSourceFile44, jSSourceFile47, jSSourceFile49 };
        com.google.javascript.jscomp.JSModule[] jSModuleArray51 = new com.google.javascript.jscomp.JSModule[] {};
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph52 = new com.google.javascript.jscomp.JSModuleGraph(jSModuleArray51);
        com.google.javascript.jscomp.CompilerOptions compilerOptions53 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CompilerOptions.TracerMode tracerMode54 = compilerOptions53.tracer;
        compiler36.init(jSSourceFileArray50, jSModuleArray51, compilerOptions53);
        compilerOptions53.setGenerateExports(true);
        compilerOptions53.jsOutputFile = "21";
        compilerOptions53.removeUnusedPrototypeProperties = false;
        byte[] byteArray62 = compilerOptions53.inputVariableMapSerialized;
        java.util.Set<java.lang.String> strSet63 = compilerOptions53.stripNameSuffixes;
        compilerOptions25.aliasableStrings = strSet63;
        boolean boolean65 = compilerOptions25.deadAssignmentElimination;
        boolean boolean66 = compilerOptions25.computeFunctionSideEffects;
        compilerOptions25.renamePrefix = "Not declared as a constructor";
        compilerOptions25.inlineLocalFunctions = false;
        try {
            com.google.javascript.jscomp.Result result71 = compiler0.compile(jSSourceFile5, jSModuleArray6, compilerOptions25);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(node1);
        org.junit.Assert.assertNotNull(intermediateState2);
        org.junit.Assert.assertNotNull(jSSourceFile5);
        org.junit.Assert.assertNotNull(jSSourceFile11);
        org.junit.Assert.assertNotNull(jSSourceFile14);
        org.junit.Assert.assertNotNull(jSSourceFile16);
        org.junit.Assert.assertNotNull(jSSourceFile19);
        org.junit.Assert.assertNotNull(jSSourceFile21);
        org.junit.Assert.assertNotNull(jSSourceFileArray22);
        org.junit.Assert.assertNotNull(jSModuleArray23);
        org.junit.Assert.assertTrue("'" + tracerMode26 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TracerMode.OFF + "'", tracerMode26.equals(com.google.javascript.jscomp.CompilerOptions.TracerMode.OFF));
        org.junit.Assert.assertNull(byteArray34);
        org.junit.Assert.assertNotNull(jSSourceFile39);
        org.junit.Assert.assertNotNull(jSSourceFile42);
        org.junit.Assert.assertNotNull(jSSourceFile44);
        org.junit.Assert.assertNotNull(jSSourceFile47);
        org.junit.Assert.assertNotNull(jSSourceFile49);
        org.junit.Assert.assertNotNull(jSSourceFileArray50);
        org.junit.Assert.assertNotNull(jSModuleArray51);
        org.junit.Assert.assertTrue("'" + tracerMode54 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TracerMode.OFF + "'", tracerMode54.equals(com.google.javascript.jscomp.CompilerOptions.TracerMode.OFF));
        org.junit.Assert.assertNull(byteArray62);
        org.junit.Assert.assertNotNull(strSet63);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        try {
            com.google.javascript.rhino.EcmaError ecmaError3 = com.google.javascript.rhino.ScriptRuntime.typeError2("()", "(Not declared as a constructor)", "neg");
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property ()");
        } catch (java.lang.RuntimeException e) {
        }
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node node1 = compiler0.getRoot();
        com.google.javascript.jscomp.Compiler compiler2 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.Compiler.IntermediateState intermediateState3 = compiler2.getState();
        compiler0.setState(intermediateState3);
        com.google.javascript.jscomp.SourceFile.Generator generator6 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile7 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("Not declared as a constructor", generator6);
        com.google.javascript.jscomp.SourceFile.Generator generator9 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile10 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("Not declared as a constructor", generator9);
        java.io.PrintStream printStream11 = null;
        com.google.javascript.jscomp.Compiler compiler12 = new com.google.javascript.jscomp.Compiler(printStream11);
        com.google.javascript.jscomp.SourceFile.Generator generator14 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile15 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("", generator14);
        com.google.javascript.jscomp.CompilerInput compilerInput16 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile15);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile18 = com.google.javascript.jscomp.JSSourceFile.fromFile("(STRING  [empty_block: 1])");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile20 = com.google.javascript.jscomp.JSSourceFile.fromFile("(STRING  [empty_block: 1])");
        com.google.javascript.jscomp.SourceFile.Generator generator22 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile23 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("", generator22);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile25 = com.google.javascript.jscomp.JSSourceFile.fromFile("(STRING  [empty_block: 1])");
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray26 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile15, jSSourceFile18, jSSourceFile20, jSSourceFile23, jSSourceFile25 };
        com.google.javascript.jscomp.JSModule[] jSModuleArray27 = new com.google.javascript.jscomp.JSModule[] {};
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph28 = new com.google.javascript.jscomp.JSModuleGraph(jSModuleArray27);
        com.google.javascript.jscomp.CompilerOptions compilerOptions29 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CompilerOptions.TracerMode tracerMode30 = compilerOptions29.tracer;
        compiler12.init(jSSourceFileArray26, jSModuleArray27, compilerOptions29);
        com.google.javascript.jscomp.SourceFile.Generator generator33 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile34 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("", generator33);
        com.google.javascript.jscomp.CompilerInput compilerInput36 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile34, true);
        com.google.javascript.jscomp.SourceFile.Generator generator38 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile39 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("Not declared as a constructor", generator38);
        com.google.javascript.jscomp.SourceFile.Generator generator41 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile42 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("", generator41);
        com.google.javascript.jscomp.CompilerInput compilerInput43 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile42);
        com.google.javascript.jscomp.SourceFile.Generator generator45 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile46 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("", generator45);
        com.google.javascript.jscomp.CompilerInput compilerInput48 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile46, true);
        com.google.javascript.jscomp.SourceFile.Generator generator50 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile51 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("", generator50);
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray52 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile39, jSSourceFile42, jSSourceFile46, jSSourceFile51 };
        com.google.javascript.jscomp.CompilerOptions compilerOptions53 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention54 = new com.google.javascript.jscomp.DefaultCodingConvention();
        boolean boolean56 = defaultCodingConvention54.isExported("window");
        compilerOptions53.setCodingConvention((com.google.javascript.jscomp.CodingConvention) defaultCodingConvention54);
        com.google.javascript.jscomp.Result result58 = compiler12.compile(jSSourceFile34, jSSourceFileArray52, compilerOptions53);
        java.nio.charset.Charset charset60 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile61 = com.google.javascript.jscomp.JSSourceFile.fromFile("error reporter", charset60);
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray62 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile7, jSSourceFile10, jSSourceFile34, jSSourceFile61 };
        com.google.javascript.jscomp.JSModule[] jSModuleArray63 = new com.google.javascript.jscomp.JSModule[] {};
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph64 = new com.google.javascript.jscomp.JSModuleGraph(jSModuleArray63);
        com.google.javascript.jscomp.CompilerOptions compilerOptions65 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention66 = new com.google.javascript.jscomp.DefaultCodingConvention();
        boolean boolean68 = defaultCodingConvention66.isExported("window");
        compilerOptions65.setCodingConvention((com.google.javascript.jscomp.CodingConvention) defaultCodingConvention66);
        java.lang.Object obj70 = compilerOptions65.clone();
        compilerOptions65.strictMessageReplacement = false;
        compilerOptions65.enableRuntimeTypeCheck("");
        compiler0.init(jSSourceFileArray62, jSModuleArray63, compilerOptions65);
        boolean boolean76 = compilerOptions65.removeUnusedPrototypePropertiesInExterns;
        org.junit.Assert.assertNull(node1);
        org.junit.Assert.assertNotNull(intermediateState3);
        org.junit.Assert.assertNotNull(jSSourceFile7);
        org.junit.Assert.assertNotNull(jSSourceFile10);
        org.junit.Assert.assertNotNull(jSSourceFile15);
        org.junit.Assert.assertNotNull(jSSourceFile18);
        org.junit.Assert.assertNotNull(jSSourceFile20);
        org.junit.Assert.assertNotNull(jSSourceFile23);
        org.junit.Assert.assertNotNull(jSSourceFile25);
        org.junit.Assert.assertNotNull(jSSourceFileArray26);
        org.junit.Assert.assertNotNull(jSModuleArray27);
        org.junit.Assert.assertTrue("'" + tracerMode30 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TracerMode.OFF + "'", tracerMode30.equals(com.google.javascript.jscomp.CompilerOptions.TracerMode.OFF));
        org.junit.Assert.assertNotNull(jSSourceFile34);
        org.junit.Assert.assertNotNull(jSSourceFile39);
        org.junit.Assert.assertNotNull(jSSourceFile42);
        org.junit.Assert.assertNotNull(jSSourceFile46);
        org.junit.Assert.assertNotNull(jSSourceFile51);
        org.junit.Assert.assertNotNull(jSSourceFileArray52);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertNotNull(result58);
        org.junit.Assert.assertNotNull(jSSourceFile61);
        org.junit.Assert.assertNotNull(jSSourceFileArray62);
        org.junit.Assert.assertNotNull(jSModuleArray63);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertNotNull(obj70);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node2 = node1.getParent();
        java.lang.String str3 = node1.getQualifiedName();
        com.google.javascript.rhino.EvaluatorException evaluatorException6 = new com.google.javascript.rhino.EvaluatorException("error reporter");
        node1.putProp((int) (byte) 1, (java.lang.Object) evaluatorException6);
        com.google.javascript.rhino.Node node8 = null;
        try {
            node1.addChildrenToFront(node8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertNull(node2);
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.TYPE_INVALIDATION;
        com.google.javascript.jscomp.DiagnosticGroups.INTERNET_EXPLORER_CHECKS = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticGroups.CHECK_REGEXP = diagnosticGroup0;
        java.lang.Class<?> wildcardClass3 = diagnosticGroup0.getClass();
        org.junit.Assert.assertNotNull(diagnosticGroup0);
        org.junit.Assert.assertNotNull(wildcardClass3);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        try {
            com.google.javascript.rhino.Context.reportWarning("JSC_OPTIMIZE_LOOP_ERROR", "", 36, "", 0);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: No Context associated with current Thread");
        } catch (java.lang.RuntimeException e) {
        }
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention0 = new com.google.javascript.jscomp.DefaultCodingConvention();
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention1 = new com.google.javascript.jscomp.DefaultCodingConvention();
        java.lang.String str2 = defaultCodingConvention1.getExportSymbolFunction();
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node5 = node4.getParent();
        boolean boolean6 = node4.isQuotedString();
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship7 = defaultCodingConvention1.getDelegateRelationship(node4);
        com.google.javascript.jscomp.CodingConvention.SubclassRelationship subclassRelationship8 = defaultCodingConvention0.getClassesDefinedByCall(node4);
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention10 = new com.google.javascript.jscomp.DefaultCodingConvention();
        java.lang.String str11 = defaultCodingConvention10.getExportSymbolFunction();
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node14 = node13.getParent();
        boolean boolean15 = node13.isQuotedString();
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship16 = defaultCodingConvention10.getDelegateRelationship(node13);
        com.google.javascript.rhino.Node node17 = com.google.javascript.jscomp.NodeUtil.newExpr(node13);
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node20 = node19.getParent();
        boolean boolean21 = node19.isQuotedString();
        com.google.javascript.rhino.Node node24 = new com.google.javascript.rhino.Node(4, node17, node19, 35, 0);
        java.lang.String str25 = defaultCodingConvention0.getSingletonGetterClassName(node19);
        com.google.javascript.rhino.Node node27 = com.google.javascript.rhino.Node.newString("");
        int int28 = node27.getSideEffectFlags();
        java.util.Collection<com.google.javascript.rhino.Node> nodeCollection29 = com.google.javascript.jscomp.NodeUtil.getVarsDeclaredInBranch(node27);
        java.lang.String str30 = node27.getString();
        boolean boolean31 = defaultCodingConvention0.isPropertyTestFunction(node27);
        boolean boolean34 = defaultCodingConvention0.isExported("Named type with empty name component", true);
        boolean boolean36 = defaultCodingConvention0.isConstantKey("");
        boolean boolean39 = defaultCodingConvention0.isExported("com.google.javascript.rhino.EcmaError: 100: Not declared as a constructor", true);
        boolean boolean41 = defaultCodingConvention0.isValidEnumKey("language version");
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNull(node5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(delegateRelationship7);
        org.junit.Assert.assertNull(subclassRelationship8);
        org.junit.Assert.assertNull(str11);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNull(node14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNull(delegateRelationship16);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNull(node20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNull(str25);
        org.junit.Assert.assertNotNull(node27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertNotNull(nodeCollection29);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "" + "'", str30.equals(""));
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.SourceFile.Generator generator3 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile4 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("", generator3);
        com.google.javascript.jscomp.CompilerInput compilerInput5 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile4);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile7 = com.google.javascript.jscomp.JSSourceFile.fromFile("(STRING  [empty_block: 1])");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile9 = com.google.javascript.jscomp.JSSourceFile.fromFile("(STRING  [empty_block: 1])");
        com.google.javascript.jscomp.SourceFile.Generator generator11 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile12 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("", generator11);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile14 = com.google.javascript.jscomp.JSSourceFile.fromFile("(STRING  [empty_block: 1])");
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray15 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile4, jSSourceFile7, jSSourceFile9, jSSourceFile12, jSSourceFile14 };
        com.google.javascript.jscomp.JSModule[] jSModuleArray16 = new com.google.javascript.jscomp.JSModule[] {};
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph17 = new com.google.javascript.jscomp.JSModuleGraph(jSModuleArray16);
        com.google.javascript.jscomp.CompilerOptions compilerOptions18 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CompilerOptions.TracerMode tracerMode19 = compilerOptions18.tracer;
        compiler1.init(jSSourceFileArray15, jSModuleArray16, compilerOptions18);
        java.io.PrintStream printStream21 = null;
        com.google.javascript.jscomp.Compiler compiler22 = new com.google.javascript.jscomp.Compiler(printStream21);
        com.google.javascript.jscomp.SourceFile.Generator generator24 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile25 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("", generator24);
        com.google.javascript.jscomp.CompilerInput compilerInput26 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile25);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile28 = com.google.javascript.jscomp.JSSourceFile.fromFile("(STRING  [empty_block: 1])");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile30 = com.google.javascript.jscomp.JSSourceFile.fromFile("(STRING  [empty_block: 1])");
        com.google.javascript.jscomp.SourceFile.Generator generator32 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile33 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("", generator32);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile35 = com.google.javascript.jscomp.JSSourceFile.fromFile("(STRING  [empty_block: 1])");
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray36 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile25, jSSourceFile28, jSSourceFile30, jSSourceFile33, jSSourceFile35 };
        com.google.javascript.jscomp.JSModule[] jSModuleArray37 = new com.google.javascript.jscomp.JSModule[] {};
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph38 = new com.google.javascript.jscomp.JSModuleGraph(jSModuleArray37);
        com.google.javascript.jscomp.CompilerOptions compilerOptions39 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CompilerOptions.TracerMode tracerMode40 = compilerOptions39.tracer;
        compiler22.init(jSSourceFileArray36, jSModuleArray37, compilerOptions39);
        compilerOptions39.setGenerateExports(true);
        compilerOptions39.jsOutputFile = "21";
        compilerOptions39.removeUnusedPrototypeProperties = false;
        byte[] byteArray48 = compilerOptions39.inputVariableMapSerialized;
        java.util.Set<java.lang.String> strSet49 = compilerOptions39.stripNameSuffixes;
        compilerOptions18.stripTypes = strSet49;
        boolean boolean51 = compilerOptions18.crossModuleMethodMotion;
        org.junit.Assert.assertNotNull(jSSourceFile4);
        org.junit.Assert.assertNotNull(jSSourceFile7);
        org.junit.Assert.assertNotNull(jSSourceFile9);
        org.junit.Assert.assertNotNull(jSSourceFile12);
        org.junit.Assert.assertNotNull(jSSourceFile14);
        org.junit.Assert.assertNotNull(jSSourceFileArray15);
        org.junit.Assert.assertNotNull(jSModuleArray16);
        org.junit.Assert.assertTrue("'" + tracerMode19 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TracerMode.OFF + "'", tracerMode19.equals(com.google.javascript.jscomp.CompilerOptions.TracerMode.OFF));
        org.junit.Assert.assertNotNull(jSSourceFile25);
        org.junit.Assert.assertNotNull(jSSourceFile28);
        org.junit.Assert.assertNotNull(jSSourceFile30);
        org.junit.Assert.assertNotNull(jSSourceFile33);
        org.junit.Assert.assertNotNull(jSSourceFile35);
        org.junit.Assert.assertNotNull(jSSourceFileArray36);
        org.junit.Assert.assertNotNull(jSModuleArray37);
        org.junit.Assert.assertTrue("'" + tracerMode40 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TracerMode.OFF + "'", tracerMode40.equals(com.google.javascript.jscomp.CompilerOptions.TracerMode.OFF));
        org.junit.Assert.assertNull(byteArray48);
        org.junit.Assert.assertNotNull(strSet49);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        java.nio.charset.Charset charset1 = null;
        com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromFile("", charset1);
        sourceFile2.setOriginalPath("(Not declared as a constructor)");
        org.junit.Assert.assertNotNull(sourceFile2);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention0 = new com.google.javascript.jscomp.DefaultCodingConvention();
        boolean boolean2 = defaultCodingConvention0.isExported("window");
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention3 = new com.google.javascript.jscomp.DefaultCodingConvention();
        java.lang.String str4 = defaultCodingConvention3.getExportSymbolFunction();
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node7 = node6.getParent();
        boolean boolean8 = node6.isQuotedString();
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship9 = defaultCodingConvention3.getDelegateRelationship(node6);
        java.util.Collection<com.google.javascript.rhino.Node> nodeCollection10 = com.google.javascript.jscomp.NodeUtil.getVarsDeclaredInBranch(node6);
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable11 = node6.children();
        com.google.javascript.rhino.Node node12 = node6.getParent();
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship13 = defaultCodingConvention0.getDelegateRelationship(node6);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNull(node7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNull(delegateRelationship9);
        org.junit.Assert.assertNotNull(nodeCollection10);
        org.junit.Assert.assertNotNull(nodeIterable11);
        org.junit.Assert.assertNull(node12);
        org.junit.Assert.assertNull(delegateRelationship13);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.SourceFile.Generator generator3 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile4 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("", generator3);
        com.google.javascript.jscomp.CompilerInput compilerInput5 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile4);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile7 = com.google.javascript.jscomp.JSSourceFile.fromFile("(STRING  [empty_block: 1])");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile9 = com.google.javascript.jscomp.JSSourceFile.fromFile("(STRING  [empty_block: 1])");
        com.google.javascript.jscomp.SourceFile.Generator generator11 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile12 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("", generator11);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile14 = com.google.javascript.jscomp.JSSourceFile.fromFile("(STRING  [empty_block: 1])");
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray15 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile4, jSSourceFile7, jSSourceFile9, jSSourceFile12, jSSourceFile14 };
        com.google.javascript.jscomp.JSModule[] jSModuleArray16 = new com.google.javascript.jscomp.JSModule[] {};
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph17 = new com.google.javascript.jscomp.JSModuleGraph(jSModuleArray16);
        com.google.javascript.jscomp.CompilerOptions compilerOptions18 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CompilerOptions.TracerMode tracerMode19 = compilerOptions18.tracer;
        compiler1.init(jSSourceFileArray15, jSModuleArray16, compilerOptions18);
        compilerOptions18.setGenerateExports(true);
        compilerOptions18.jsOutputFile = "21";
        compilerOptions18.removeUnusedPrototypeProperties = false;
        com.google.javascript.jscomp.CheckLevel checkLevel27 = compilerOptions18.checkGlobalNamesLevel;
        boolean boolean28 = compilerOptions18.aliasAllStrings;
        compilerOptions18.setSummaryDetailLevel(0);
        boolean boolean31 = compilerOptions18.exportTestFunctions;
        org.junit.Assert.assertNotNull(jSSourceFile4);
        org.junit.Assert.assertNotNull(jSSourceFile7);
        org.junit.Assert.assertNotNull(jSSourceFile9);
        org.junit.Assert.assertNotNull(jSSourceFile12);
        org.junit.Assert.assertNotNull(jSSourceFile14);
        org.junit.Assert.assertNotNull(jSSourceFileArray15);
        org.junit.Assert.assertNotNull(jSModuleArray16);
        org.junit.Assert.assertTrue("'" + tracerMode19 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TracerMode.OFF + "'", tracerMode19.equals(com.google.javascript.jscomp.CompilerOptions.TracerMode.OFF));
        org.junit.Assert.assertTrue("'" + checkLevel27 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel27.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.SourceFile.Generator generator3 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile4 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("", generator3);
        com.google.javascript.jscomp.CompilerInput compilerInput5 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile4);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile7 = com.google.javascript.jscomp.JSSourceFile.fromFile("(STRING  [empty_block: 1])");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile9 = com.google.javascript.jscomp.JSSourceFile.fromFile("(STRING  [empty_block: 1])");
        com.google.javascript.jscomp.SourceFile.Generator generator11 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile12 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("", generator11);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile14 = com.google.javascript.jscomp.JSSourceFile.fromFile("(STRING  [empty_block: 1])");
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray15 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile4, jSSourceFile7, jSSourceFile9, jSSourceFile12, jSSourceFile14 };
        com.google.javascript.jscomp.JSModule[] jSModuleArray16 = new com.google.javascript.jscomp.JSModule[] {};
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph17 = new com.google.javascript.jscomp.JSModuleGraph(jSModuleArray16);
        com.google.javascript.jscomp.CompilerOptions compilerOptions18 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CompilerOptions.TracerMode tracerMode19 = compilerOptions18.tracer;
        compiler1.init(jSSourceFileArray15, jSModuleArray16, compilerOptions18);
        compilerOptions18.setGenerateExports(true);
        compilerOptions18.jsOutputFile = "21";
        compilerOptions18.removeUnusedPrototypeProperties = false;
        byte[] byteArray27 = compilerOptions18.inputVariableMapSerialized;
        compilerOptions18.setAcceptConstKeyword(false);
        boolean boolean30 = compilerOptions18.inlineFunctions;
        org.junit.Assert.assertNotNull(jSSourceFile4);
        org.junit.Assert.assertNotNull(jSSourceFile7);
        org.junit.Assert.assertNotNull(jSSourceFile9);
        org.junit.Assert.assertNotNull(jSSourceFile12);
        org.junit.Assert.assertNotNull(jSSourceFile14);
        org.junit.Assert.assertNotNull(jSSourceFileArray15);
        org.junit.Assert.assertNotNull(jSModuleArray16);
        org.junit.Assert.assertTrue("'" + tracerMode19 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TracerMode.OFF + "'", tracerMode19.equals(com.google.javascript.jscomp.CompilerOptions.TracerMode.OFF));
        org.junit.Assert.assertNull(byteArray27);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        java.util.List<com.google.javascript.jscomp.deps.DependencyInfo> dependencyInfoList0 = null;
        try {
            com.google.javascript.jscomp.deps.SortedDependencies<com.google.javascript.jscomp.deps.DependencyInfo> dependencyInfoSortedDependencies1 = new com.google.javascript.jscomp.deps.SortedDependencies<com.google.javascript.jscomp.deps.DependencyInfo>(dependencyInfoList0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node2 = node1.getParent();
        boolean boolean3 = node1.hasChildren();
        java.lang.String str4 = node1.getQualifiedName();
        java.io.PrintStream printStream5 = null;
        com.google.javascript.jscomp.Compiler compiler6 = new com.google.javascript.jscomp.Compiler(printStream5);
        com.google.javascript.jscomp.SourceFile.Generator generator8 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile9 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("", generator8);
        com.google.javascript.jscomp.CompilerInput compilerInput10 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile9);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile12 = com.google.javascript.jscomp.JSSourceFile.fromFile("(STRING  [empty_block: 1])");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile14 = com.google.javascript.jscomp.JSSourceFile.fromFile("(STRING  [empty_block: 1])");
        com.google.javascript.jscomp.SourceFile.Generator generator16 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile17 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("", generator16);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile19 = com.google.javascript.jscomp.JSSourceFile.fromFile("(STRING  [empty_block: 1])");
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray20 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile9, jSSourceFile12, jSSourceFile14, jSSourceFile17, jSSourceFile19 };
        com.google.javascript.jscomp.JSModule[] jSModuleArray21 = new com.google.javascript.jscomp.JSModule[] {};
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph22 = new com.google.javascript.jscomp.JSModuleGraph(jSModuleArray21);
        com.google.javascript.jscomp.CompilerOptions compilerOptions23 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CompilerOptions.TracerMode tracerMode24 = compilerOptions23.tracer;
        compiler6.init(jSSourceFileArray20, jSModuleArray21, compilerOptions23);
        java.io.PrintStream printStream26 = null;
        com.google.javascript.jscomp.Compiler compiler27 = new com.google.javascript.jscomp.Compiler(printStream26);
        com.google.javascript.jscomp.SourceFile.Generator generator29 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile30 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("", generator29);
        com.google.javascript.jscomp.CompilerInput compilerInput31 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile30);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile33 = com.google.javascript.jscomp.JSSourceFile.fromFile("(STRING  [empty_block: 1])");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile35 = com.google.javascript.jscomp.JSSourceFile.fromFile("(STRING  [empty_block: 1])");
        com.google.javascript.jscomp.SourceFile.Generator generator37 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile38 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("", generator37);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile40 = com.google.javascript.jscomp.JSSourceFile.fromFile("(STRING  [empty_block: 1])");
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray41 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile30, jSSourceFile33, jSSourceFile35, jSSourceFile38, jSSourceFile40 };
        com.google.javascript.jscomp.JSModule[] jSModuleArray42 = new com.google.javascript.jscomp.JSModule[] {};
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph43 = new com.google.javascript.jscomp.JSModuleGraph(jSModuleArray42);
        com.google.javascript.jscomp.CompilerOptions compilerOptions44 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CompilerOptions.TracerMode tracerMode45 = compilerOptions44.tracer;
        compiler27.init(jSSourceFileArray41, jSModuleArray42, compilerOptions44);
        compilerOptions44.setGenerateExports(true);
        compilerOptions44.jsOutputFile = "21";
        compilerOptions44.removeUnusedPrototypeProperties = false;
        byte[] byteArray53 = compilerOptions44.inputVariableMapSerialized;
        java.util.Set<java.lang.String> strSet54 = compilerOptions44.stripNameSuffixes;
        compilerOptions23.stripTypes = strSet54;
        node1.setDirectives(strSet54);
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertNull(node2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNotNull(jSSourceFile9);
        org.junit.Assert.assertNotNull(jSSourceFile12);
        org.junit.Assert.assertNotNull(jSSourceFile14);
        org.junit.Assert.assertNotNull(jSSourceFile17);
        org.junit.Assert.assertNotNull(jSSourceFile19);
        org.junit.Assert.assertNotNull(jSSourceFileArray20);
        org.junit.Assert.assertNotNull(jSModuleArray21);
        org.junit.Assert.assertTrue("'" + tracerMode24 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TracerMode.OFF + "'", tracerMode24.equals(com.google.javascript.jscomp.CompilerOptions.TracerMode.OFF));
        org.junit.Assert.assertNotNull(jSSourceFile30);
        org.junit.Assert.assertNotNull(jSSourceFile33);
        org.junit.Assert.assertNotNull(jSSourceFile35);
        org.junit.Assert.assertNotNull(jSSourceFile38);
        org.junit.Assert.assertNotNull(jSSourceFile40);
        org.junit.Assert.assertNotNull(jSSourceFileArray41);
        org.junit.Assert.assertNotNull(jSModuleArray42);
        org.junit.Assert.assertTrue("'" + tracerMode45 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TracerMode.OFF + "'", tracerMode45.equals(com.google.javascript.jscomp.CompilerOptions.TracerMode.OFF));
        org.junit.Assert.assertNull(byteArray53);
        org.junit.Assert.assertNotNull(strSet54);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node5 = node4.getParent();
        boolean boolean6 = node4.hasChildren();
        node4.detachChildren();
        com.google.javascript.rhino.Node node8 = node4.cloneTree();
        com.google.javascript.rhino.Node node11 = new com.google.javascript.rhino.Node(160, node2, node8, 34, 0);
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.Node.newString("");
        int int15 = node14.getSideEffectFlags();
        boolean boolean16 = node14.isOptionalArg();
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention17 = new com.google.javascript.jscomp.DefaultCodingConvention();
        java.lang.String str18 = defaultCodingConvention17.getExportSymbolFunction();
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node21 = node20.getParent();
        boolean boolean22 = node20.isQuotedString();
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship23 = defaultCodingConvention17.getDelegateRelationship(node20);
        com.google.javascript.rhino.Node node24 = com.google.javascript.jscomp.NodeUtil.newExpr(node20);
        com.google.javascript.rhino.Node node27 = new com.google.javascript.rhino.Node((int) (short) 0, node14, node24, (int) (byte) 1, 0);
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention28 = new com.google.javascript.jscomp.DefaultCodingConvention();
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention29 = new com.google.javascript.jscomp.DefaultCodingConvention();
        java.lang.String str30 = defaultCodingConvention29.getExportSymbolFunction();
        com.google.javascript.rhino.Node node32 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node33 = node32.getParent();
        boolean boolean34 = node32.isQuotedString();
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship35 = defaultCodingConvention29.getDelegateRelationship(node32);
        com.google.javascript.jscomp.CodingConvention.SubclassRelationship subclassRelationship36 = defaultCodingConvention28.getClassesDefinedByCall(node32);
        java.lang.String str37 = node14.checkTreeEquals(node32);
        try {
            node11.addChildrenToBack(node14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNull(node5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNull(str18);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNull(node21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNull(delegateRelationship23);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertNull(str30);
        org.junit.Assert.assertNotNull(node32);
        org.junit.Assert.assertNull(node33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNull(delegateRelationship35);
        org.junit.Assert.assertNull(subclassRelationship36);
        org.junit.Assert.assertNull(str37);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention1 = new com.google.javascript.jscomp.DefaultCodingConvention();
        java.lang.String str2 = defaultCodingConvention1.getExportSymbolFunction();
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node5 = node4.getParent();
        boolean boolean6 = node4.isQuotedString();
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship7 = defaultCodingConvention1.getDelegateRelationship(node4);
        com.google.javascript.rhino.Node node8 = com.google.javascript.jscomp.NodeUtil.newExpr(node4);
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node11 = node10.getParent();
        boolean boolean12 = node10.isQuotedString();
        com.google.javascript.rhino.Node node15 = new com.google.javascript.rhino.Node(4, node8, node10, 35, 0);
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.Node.newString("");
        int int19 = node18.getSideEffectFlags();
        boolean boolean20 = node18.isOptionalArg();
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention21 = new com.google.javascript.jscomp.DefaultCodingConvention();
        java.lang.String str22 = defaultCodingConvention21.getExportSymbolFunction();
        com.google.javascript.rhino.Node node24 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node25 = node24.getParent();
        boolean boolean26 = node24.isQuotedString();
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship27 = defaultCodingConvention21.getDelegateRelationship(node24);
        com.google.javascript.rhino.Node node28 = com.google.javascript.jscomp.NodeUtil.newExpr(node24);
        com.google.javascript.rhino.Node node31 = new com.google.javascript.rhino.Node((int) (short) 0, node18, node28, (int) (byte) 1, 0);
        com.google.javascript.rhino.Node node32 = node8.clonePropsFrom(node28);
        boolean boolean33 = node32.hasChildren();
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNull(node5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(delegateRelationship7);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNull(node11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNull(str22);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertNull(node25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNull(delegateRelationship27);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertNotNull(node32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        com.google.javascript.rhino.Context context0 = null;
        com.google.javascript.rhino.Context context1 = com.google.javascript.rhino.Context.enter(context0);
        java.util.Locale locale2 = context1.getLocale();
        boolean boolean3 = context1.isGeneratingDebug();
        context1.setCompileFunctionsWithDynamicScope(true);
        com.google.javascript.jscomp.DiagnosticType diagnosticType8 = com.google.javascript.jscomp.DiagnosticType.warning("window", "hi!");
        com.google.javascript.jscomp.DiagnosticType diagnosticType12 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray18 = new java.lang.String[] { "Named type with empty name component", "(STRING  [empty_block: 1])", "100", "Not declared as a constructor", "(STRING  [empty_block: 1])" };
        com.google.javascript.jscomp.JSError jSError19 = com.google.javascript.jscomp.JSError.make("", (int) (byte) 1, (int) '#', diagnosticType12, strArray18);
        int int20 = diagnosticType8.compareTo(diagnosticType12);
        context1.seal((java.lang.Object) diagnosticType12);
        org.junit.Assert.assertNotNull(context1);
        org.junit.Assert.assertNotNull(locale2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(diagnosticType8);
        org.junit.Assert.assertNotNull(diagnosticType12);
        org.junit.Assert.assertNotNull(strArray18);
        org.junit.Assert.assertNotNull(jSError19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 45 + "'", int20 == 45);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        try {
            com.google.javascript.rhino.EcmaError ecmaError2 = com.google.javascript.rhino.ScriptRuntime.typeError1("", "Named type with empty name component");
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property ");
        } catch (java.lang.RuntimeException e) {
        }
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.SourceFile.Generator generator3 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile4 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("", generator3);
        com.google.javascript.jscomp.CompilerInput compilerInput5 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile4);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile7 = com.google.javascript.jscomp.JSSourceFile.fromFile("(STRING  [empty_block: 1])");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile9 = com.google.javascript.jscomp.JSSourceFile.fromFile("(STRING  [empty_block: 1])");
        com.google.javascript.jscomp.SourceFile.Generator generator11 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile12 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("", generator11);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile14 = com.google.javascript.jscomp.JSSourceFile.fromFile("(STRING  [empty_block: 1])");
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray15 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile4, jSSourceFile7, jSSourceFile9, jSSourceFile12, jSSourceFile14 };
        com.google.javascript.jscomp.JSModule[] jSModuleArray16 = new com.google.javascript.jscomp.JSModule[] {};
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph17 = new com.google.javascript.jscomp.JSModuleGraph(jSModuleArray16);
        com.google.javascript.jscomp.CompilerOptions compilerOptions18 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CompilerOptions.TracerMode tracerMode19 = compilerOptions18.tracer;
        compiler1.init(jSSourceFileArray15, jSModuleArray16, compilerOptions18);
        compilerOptions18.setGenerateExports(true);
        compilerOptions18.jsOutputFile = "21";
        compilerOptions18.removeUnusedPrototypeProperties = false;
        compilerOptions18.crossModuleMethodMotion = false;
        java.util.Map<java.lang.String, com.google.javascript.rhino.Node> strMap29 = compilerOptions18.getDefineReplacements();
        org.junit.Assert.assertNotNull(jSSourceFile4);
        org.junit.Assert.assertNotNull(jSSourceFile7);
        org.junit.Assert.assertNotNull(jSSourceFile9);
        org.junit.Assert.assertNotNull(jSSourceFile12);
        org.junit.Assert.assertNotNull(jSSourceFile14);
        org.junit.Assert.assertNotNull(jSSourceFileArray15);
        org.junit.Assert.assertNotNull(jSModuleArray16);
        org.junit.Assert.assertTrue("'" + tracerMode19 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TracerMode.OFF + "'", tracerMode19.equals(com.google.javascript.jscomp.CompilerOptions.TracerMode.OFF));
        org.junit.Assert.assertNotNull(strMap29);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.SourceFile.Generator generator3 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile4 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("", generator3);
        com.google.javascript.jscomp.CompilerInput compilerInput5 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile4);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile7 = com.google.javascript.jscomp.JSSourceFile.fromFile("(STRING  [empty_block: 1])");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile9 = com.google.javascript.jscomp.JSSourceFile.fromFile("(STRING  [empty_block: 1])");
        com.google.javascript.jscomp.SourceFile.Generator generator11 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile12 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("", generator11);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile14 = com.google.javascript.jscomp.JSSourceFile.fromFile("(STRING  [empty_block: 1])");
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray15 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile4, jSSourceFile7, jSSourceFile9, jSSourceFile12, jSSourceFile14 };
        com.google.javascript.jscomp.JSModule[] jSModuleArray16 = new com.google.javascript.jscomp.JSModule[] {};
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph17 = new com.google.javascript.jscomp.JSModuleGraph(jSModuleArray16);
        com.google.javascript.jscomp.CompilerOptions compilerOptions18 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CompilerOptions.TracerMode tracerMode19 = compilerOptions18.tracer;
        compiler1.init(jSSourceFileArray15, jSModuleArray16, compilerOptions18);
        compilerOptions18.setGenerateExports(true);
        compilerOptions18.jsOutputFile = "21";
        compilerOptions18.removeUnusedPrototypeProperties = false;
        com.google.javascript.jscomp.CheckLevel checkLevel27 = compilerOptions18.checkGlobalNamesLevel;
        compilerOptions18.checkControlStructures = false;
        java.util.Set<java.lang.String> strSet30 = compilerOptions18.stripTypePrefixes;
        com.google.javascript.jscomp.WarningsGuard warningsGuard31 = null;
        try {
            compilerOptions18.addWarningsGuard(warningsGuard31);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile4);
        org.junit.Assert.assertNotNull(jSSourceFile7);
        org.junit.Assert.assertNotNull(jSSourceFile9);
        org.junit.Assert.assertNotNull(jSSourceFile12);
        org.junit.Assert.assertNotNull(jSSourceFile14);
        org.junit.Assert.assertNotNull(jSSourceFileArray15);
        org.junit.Assert.assertNotNull(jSModuleArray16);
        org.junit.Assert.assertTrue("'" + tracerMode19 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TracerMode.OFF + "'", tracerMode19.equals(com.google.javascript.jscomp.CompilerOptions.TracerMode.OFF));
        org.junit.Assert.assertTrue("'" + checkLevel27 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel27.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(strSet30);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention0 = new com.google.javascript.jscomp.DefaultCodingConvention();
        java.lang.String str1 = defaultCodingConvention0.getExportSymbolFunction();
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node4 = node3.getParent();
        boolean boolean5 = node3.isQuotedString();
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship6 = defaultCodingConvention0.getDelegateRelationship(node3);
        com.google.javascript.rhino.Node node7 = com.google.javascript.jscomp.NodeUtil.newExpr(node3);
        boolean boolean8 = node3.isOnlyModifiesThisCall();
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNull(node4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(delegateRelationship6);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        com.google.javascript.rhino.Node.SideEffectFlags sideEffectFlags1 = new com.google.javascript.rhino.Node.SideEffectFlags((int) ' ');
        int int2 = sideEffectFlags1.valueOf();
        sideEffectFlags1.setAllFlags();
        sideEffectFlags1.clearAllFlags();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 32 + "'", int2 == 32);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        com.google.javascript.rhino.EcmaError ecmaError6 = com.google.javascript.rhino.ScriptRuntime.constructError("Named type with empty name component", "21", "STRING  [empty_block: 1]", 20, "<No stack trace available>", (int) (byte) 0);
        java.lang.String str7 = ecmaError6.getScriptStackTrace();
        org.junit.Assert.assertNotNull(ecmaError6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "<No stack trace available>" + "'", str7.equals("<No stack trace available>"));
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.specializeInitialModule;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

//    @Test
//    public void test423() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test423");
//        com.google.javascript.rhino.Context context0 = null;
//        com.google.javascript.rhino.Context context1 = com.google.javascript.rhino.Context.enter(context0);
//        java.util.Locale locale2 = context1.getLocale();
//        com.google.javascript.rhino.Context context3 = null;
//        com.google.javascript.rhino.Context context4 = com.google.javascript.rhino.Context.enter(context3);
//        java.util.Locale locale5 = context4.getLocale();
//        java.util.Locale locale6 = context1.setLocale(locale5);
//        int int7 = context1.getInstructionObserverThreshold();
//        org.junit.Assert.assertNotNull(context1);
//        org.junit.Assert.assertNotNull(locale2);
//        org.junit.Assert.assertNotNull(context4);
//        org.junit.Assert.assertNotNull(locale5);
//        org.junit.Assert.assertNotNull(locale6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention0 = new com.google.javascript.jscomp.DefaultCodingConvention();
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention1 = new com.google.javascript.jscomp.DefaultCodingConvention();
        java.lang.String str2 = defaultCodingConvention1.getExportSymbolFunction();
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node5 = node4.getParent();
        boolean boolean6 = node4.isQuotedString();
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship7 = defaultCodingConvention1.getDelegateRelationship(node4);
        com.google.javascript.jscomp.CodingConvention.SubclassRelationship subclassRelationship8 = defaultCodingConvention0.getClassesDefinedByCall(node4);
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention10 = new com.google.javascript.jscomp.DefaultCodingConvention();
        java.lang.String str11 = defaultCodingConvention10.getExportSymbolFunction();
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node14 = node13.getParent();
        boolean boolean15 = node13.isQuotedString();
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship16 = defaultCodingConvention10.getDelegateRelationship(node13);
        com.google.javascript.rhino.Node node17 = com.google.javascript.jscomp.NodeUtil.newExpr(node13);
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node20 = node19.getParent();
        boolean boolean21 = node19.isQuotedString();
        com.google.javascript.rhino.Node node24 = new com.google.javascript.rhino.Node(4, node17, node19, 35, 0);
        java.lang.String str25 = defaultCodingConvention0.getSingletonGetterClassName(node19);
        com.google.javascript.rhino.Node node27 = com.google.javascript.rhino.Node.newString("");
        int int28 = node27.getSideEffectFlags();
        java.util.Collection<com.google.javascript.rhino.Node> nodeCollection29 = com.google.javascript.jscomp.NodeUtil.getVarsDeclaredInBranch(node27);
        java.lang.String str30 = node27.getString();
        boolean boolean31 = defaultCodingConvention0.isPropertyTestFunction(node27);
        boolean boolean32 = node27.isQuotedString();
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNull(node5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(delegateRelationship7);
        org.junit.Assert.assertNull(subclassRelationship8);
        org.junit.Assert.assertNull(str11);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNull(node14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNull(delegateRelationship16);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNull(node20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNull(str25);
        org.junit.Assert.assertNotNull(node27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertNotNull(nodeCollection29);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "" + "'", str30.equals(""));
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        com.google.javascript.jscomp.SourceFile.Generator generator1 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("", generator1);
        com.google.javascript.jscomp.CompilerInput compilerInput4 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2, true);
        java.util.logging.Logger logger5 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager6 = new com.google.javascript.jscomp.LoggerErrorManager(logger5);
        compilerInput4.setErrorManager((com.google.javascript.jscomp.ErrorManager) loggerErrorManager6);
        compilerInput4.clearAst();
        org.junit.Assert.assertNotNull(jSSourceFile2);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.SourceFile.Generator generator3 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile4 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("", generator3);
        com.google.javascript.jscomp.CompilerInput compilerInput5 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile4);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile7 = com.google.javascript.jscomp.JSSourceFile.fromFile("(STRING  [empty_block: 1])");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile9 = com.google.javascript.jscomp.JSSourceFile.fromFile("(STRING  [empty_block: 1])");
        com.google.javascript.jscomp.SourceFile.Generator generator11 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile12 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("", generator11);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile14 = com.google.javascript.jscomp.JSSourceFile.fromFile("(STRING  [empty_block: 1])");
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray15 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile4, jSSourceFile7, jSSourceFile9, jSSourceFile12, jSSourceFile14 };
        com.google.javascript.jscomp.JSModule[] jSModuleArray16 = new com.google.javascript.jscomp.JSModule[] {};
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph17 = new com.google.javascript.jscomp.JSModuleGraph(jSModuleArray16);
        com.google.javascript.jscomp.CompilerOptions compilerOptions18 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CompilerOptions.TracerMode tracerMode19 = compilerOptions18.tracer;
        compiler1.init(jSSourceFileArray15, jSModuleArray16, compilerOptions18);
        compilerOptions18.setGenerateExports(true);
        compilerOptions18.inferTypesInGlobalScope = true;
        boolean boolean25 = compilerOptions18.inferTypesInGlobalScope;
        boolean boolean26 = compilerOptions18.gatherCssNames;
        compilerOptions18.inputDelimiter = "language version";
        compilerOptions18.setRemoveClosureAsserts(false);
        boolean boolean31 = compilerOptions18.collapseVariableDeclarations;
        org.junit.Assert.assertNotNull(jSSourceFile4);
        org.junit.Assert.assertNotNull(jSSourceFile7);
        org.junit.Assert.assertNotNull(jSSourceFile9);
        org.junit.Assert.assertNotNull(jSSourceFile12);
        org.junit.Assert.assertNotNull(jSSourceFile14);
        org.junit.Assert.assertNotNull(jSSourceFileArray15);
        org.junit.Assert.assertNotNull(jSModuleArray16);
        org.junit.Assert.assertTrue("'" + tracerMode19 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TracerMode.OFF + "'", tracerMode19.equals(com.google.javascript.jscomp.CompilerOptions.TracerMode.OFF));
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        com.google.javascript.rhino.EcmaError ecmaError1 = com.google.javascript.rhino.ScriptRuntime.typeError("100");
        int int2 = ecmaError1.columnNumber();
        java.lang.String str3 = ecmaError1.details();
        org.junit.Assert.assertNotNull(ecmaError1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "TypeError: 100" + "'", str3.equals("TypeError: 100"));
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CompilerOptions.TracerMode tracerMode1 = compilerOptions0.tracer;
        boolean boolean2 = compilerOptions0.removeDeadCode;
        boolean boolean3 = compilerOptions0.inlineLocalFunctions;
        org.junit.Assert.assertTrue("'" + tracerMode1 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TracerMode.OFF + "'", tracerMode1.equals(com.google.javascript.jscomp.CompilerOptions.TracerMode.OFF));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention1 = new com.google.javascript.jscomp.DefaultCodingConvention();
        boolean boolean3 = defaultCodingConvention1.isExported("window");
        compilerOptions0.setCodingConvention((com.google.javascript.jscomp.CodingConvention) defaultCodingConvention1);
        boolean boolean5 = compilerOptions0.optimizeArgumentsArray;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        int int0 = com.google.javascript.rhino.Node.SYNTHETIC_BLOCK_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 37 + "'", int0 == 37);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.SourceFile.Generator generator3 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile4 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("", generator3);
        com.google.javascript.jscomp.CompilerInput compilerInput5 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile4);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile7 = com.google.javascript.jscomp.JSSourceFile.fromFile("(STRING  [empty_block: 1])");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile9 = com.google.javascript.jscomp.JSSourceFile.fromFile("(STRING  [empty_block: 1])");
        com.google.javascript.jscomp.SourceFile.Generator generator11 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile12 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("", generator11);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile14 = com.google.javascript.jscomp.JSSourceFile.fromFile("(STRING  [empty_block: 1])");
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray15 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile4, jSSourceFile7, jSSourceFile9, jSSourceFile12, jSSourceFile14 };
        com.google.javascript.jscomp.JSModule[] jSModuleArray16 = new com.google.javascript.jscomp.JSModule[] {};
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph17 = new com.google.javascript.jscomp.JSModuleGraph(jSModuleArray16);
        com.google.javascript.jscomp.CompilerOptions compilerOptions18 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CompilerOptions.TracerMode tracerMode19 = compilerOptions18.tracer;
        compiler1.init(jSSourceFileArray15, jSModuleArray16, compilerOptions18);
        compilerOptions18.checkEs5Strict = false;
        com.google.javascript.jscomp.CodingConvention codingConvention23 = compilerOptions18.getCodingConvention();
        compilerOptions18.checkControlStructures = true;
        compilerOptions18.inlineLocalVariables = false;
        compilerOptions18.instrumentationTemplate = "JSC_OPTIMIZE_LOOP_ERROR";
        org.junit.Assert.assertNotNull(jSSourceFile4);
        org.junit.Assert.assertNotNull(jSSourceFile7);
        org.junit.Assert.assertNotNull(jSSourceFile9);
        org.junit.Assert.assertNotNull(jSSourceFile12);
        org.junit.Assert.assertNotNull(jSSourceFile14);
        org.junit.Assert.assertNotNull(jSSourceFileArray15);
        org.junit.Assert.assertNotNull(jSModuleArray16);
        org.junit.Assert.assertTrue("'" + tracerMode19 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TracerMode.OFF + "'", tracerMode19.equals(com.google.javascript.jscomp.CompilerOptions.TracerMode.OFF));
        org.junit.Assert.assertNull(codingConvention23);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        com.google.javascript.jscomp.SourceFile.Generator generator1 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("", generator1);
        com.google.javascript.jscomp.CompilerInput compilerInput4 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2, true);
        java.util.logging.Logger logger5 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager6 = new com.google.javascript.jscomp.LoggerErrorManager(logger5);
        compilerInput4.setErrorManager((com.google.javascript.jscomp.ErrorManager) loggerErrorManager6);
        try {
            com.google.javascript.jscomp.Region region9 = compilerInput4.getRegion((int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile2);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = null;
        com.google.javascript.jscomp.DiagnosticGroups.FILEOVERVIEW_JSDOC = diagnosticGroup0;
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        com.google.javascript.jscomp.SourceMap.Format format0 = com.google.javascript.jscomp.SourceMap.Format.LEGACY;
        org.junit.Assert.assertNotNull(format0);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node node1 = compiler0.getRoot();
        com.google.javascript.jscomp.Compiler compiler2 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.Compiler.IntermediateState intermediateState3 = compiler2.getState();
        compiler0.setState(intermediateState3);
        com.google.javascript.jscomp.SourceFile.Generator generator6 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile7 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("Not declared as a constructor", generator6);
        com.google.javascript.jscomp.SourceFile.Generator generator9 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile10 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("Not declared as a constructor", generator9);
        java.io.PrintStream printStream11 = null;
        com.google.javascript.jscomp.Compiler compiler12 = new com.google.javascript.jscomp.Compiler(printStream11);
        com.google.javascript.jscomp.SourceFile.Generator generator14 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile15 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("", generator14);
        com.google.javascript.jscomp.CompilerInput compilerInput16 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile15);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile18 = com.google.javascript.jscomp.JSSourceFile.fromFile("(STRING  [empty_block: 1])");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile20 = com.google.javascript.jscomp.JSSourceFile.fromFile("(STRING  [empty_block: 1])");
        com.google.javascript.jscomp.SourceFile.Generator generator22 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile23 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("", generator22);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile25 = com.google.javascript.jscomp.JSSourceFile.fromFile("(STRING  [empty_block: 1])");
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray26 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile15, jSSourceFile18, jSSourceFile20, jSSourceFile23, jSSourceFile25 };
        com.google.javascript.jscomp.JSModule[] jSModuleArray27 = new com.google.javascript.jscomp.JSModule[] {};
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph28 = new com.google.javascript.jscomp.JSModuleGraph(jSModuleArray27);
        com.google.javascript.jscomp.CompilerOptions compilerOptions29 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CompilerOptions.TracerMode tracerMode30 = compilerOptions29.tracer;
        compiler12.init(jSSourceFileArray26, jSModuleArray27, compilerOptions29);
        com.google.javascript.jscomp.SourceFile.Generator generator33 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile34 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("", generator33);
        com.google.javascript.jscomp.CompilerInput compilerInput36 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile34, true);
        com.google.javascript.jscomp.SourceFile.Generator generator38 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile39 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("Not declared as a constructor", generator38);
        com.google.javascript.jscomp.SourceFile.Generator generator41 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile42 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("", generator41);
        com.google.javascript.jscomp.CompilerInput compilerInput43 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile42);
        com.google.javascript.jscomp.SourceFile.Generator generator45 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile46 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("", generator45);
        com.google.javascript.jscomp.CompilerInput compilerInput48 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile46, true);
        com.google.javascript.jscomp.SourceFile.Generator generator50 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile51 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("", generator50);
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray52 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile39, jSSourceFile42, jSSourceFile46, jSSourceFile51 };
        com.google.javascript.jscomp.CompilerOptions compilerOptions53 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention54 = new com.google.javascript.jscomp.DefaultCodingConvention();
        boolean boolean56 = defaultCodingConvention54.isExported("window");
        compilerOptions53.setCodingConvention((com.google.javascript.jscomp.CodingConvention) defaultCodingConvention54);
        com.google.javascript.jscomp.Result result58 = compiler12.compile(jSSourceFile34, jSSourceFileArray52, compilerOptions53);
        java.nio.charset.Charset charset60 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile61 = com.google.javascript.jscomp.JSSourceFile.fromFile("error reporter", charset60);
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray62 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile7, jSSourceFile10, jSSourceFile34, jSSourceFile61 };
        com.google.javascript.jscomp.JSModule[] jSModuleArray63 = new com.google.javascript.jscomp.JSModule[] {};
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph64 = new com.google.javascript.jscomp.JSModuleGraph(jSModuleArray63);
        com.google.javascript.jscomp.CompilerOptions compilerOptions65 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention66 = new com.google.javascript.jscomp.DefaultCodingConvention();
        boolean boolean68 = defaultCodingConvention66.isExported("window");
        compilerOptions65.setCodingConvention((com.google.javascript.jscomp.CodingConvention) defaultCodingConvention66);
        java.lang.Object obj70 = compilerOptions65.clone();
        compilerOptions65.strictMessageReplacement = false;
        compilerOptions65.enableRuntimeTypeCheck("");
        compiler0.init(jSSourceFileArray62, jSModuleArray63, compilerOptions65);
        com.google.javascript.jscomp.PassConfig passConfig76 = null;
        try {
            compiler0.setPassConfig(passConfig76);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(node1);
        org.junit.Assert.assertNotNull(intermediateState3);
        org.junit.Assert.assertNotNull(jSSourceFile7);
        org.junit.Assert.assertNotNull(jSSourceFile10);
        org.junit.Assert.assertNotNull(jSSourceFile15);
        org.junit.Assert.assertNotNull(jSSourceFile18);
        org.junit.Assert.assertNotNull(jSSourceFile20);
        org.junit.Assert.assertNotNull(jSSourceFile23);
        org.junit.Assert.assertNotNull(jSSourceFile25);
        org.junit.Assert.assertNotNull(jSSourceFileArray26);
        org.junit.Assert.assertNotNull(jSModuleArray27);
        org.junit.Assert.assertTrue("'" + tracerMode30 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TracerMode.OFF + "'", tracerMode30.equals(com.google.javascript.jscomp.CompilerOptions.TracerMode.OFF));
        org.junit.Assert.assertNotNull(jSSourceFile34);
        org.junit.Assert.assertNotNull(jSSourceFile39);
        org.junit.Assert.assertNotNull(jSSourceFile42);
        org.junit.Assert.assertNotNull(jSSourceFile46);
        org.junit.Assert.assertNotNull(jSSourceFile51);
        org.junit.Assert.assertNotNull(jSSourceFileArray52);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertNotNull(result58);
        org.junit.Assert.assertNotNull(jSSourceFile61);
        org.junit.Assert.assertNotNull(jSSourceFileArray62);
        org.junit.Assert.assertNotNull(jSModuleArray63);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertNotNull(obj70);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.SourceFile.Generator generator3 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile4 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("", generator3);
        com.google.javascript.jscomp.CompilerInput compilerInput5 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile4);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile7 = com.google.javascript.jscomp.JSSourceFile.fromFile("(STRING  [empty_block: 1])");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile9 = com.google.javascript.jscomp.JSSourceFile.fromFile("(STRING  [empty_block: 1])");
        com.google.javascript.jscomp.SourceFile.Generator generator11 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile12 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("", generator11);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile14 = com.google.javascript.jscomp.JSSourceFile.fromFile("(STRING  [empty_block: 1])");
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray15 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile4, jSSourceFile7, jSSourceFile9, jSSourceFile12, jSSourceFile14 };
        com.google.javascript.jscomp.JSModule[] jSModuleArray16 = new com.google.javascript.jscomp.JSModule[] {};
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph17 = new com.google.javascript.jscomp.JSModuleGraph(jSModuleArray16);
        com.google.javascript.jscomp.CompilerOptions compilerOptions18 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CompilerOptions.TracerMode tracerMode19 = compilerOptions18.tracer;
        compiler1.init(jSSourceFileArray15, jSModuleArray16, compilerOptions18);
        compilerOptions18.setGenerateExports(true);
        compilerOptions18.jsOutputFile = "21";
        boolean boolean25 = compilerOptions18.checkEs5Strict;
        compilerOptions18.skipAllCompilerPasses();
        org.junit.Assert.assertNotNull(jSSourceFile4);
        org.junit.Assert.assertNotNull(jSSourceFile7);
        org.junit.Assert.assertNotNull(jSSourceFile9);
        org.junit.Assert.assertNotNull(jSSourceFile12);
        org.junit.Assert.assertNotNull(jSSourceFile14);
        org.junit.Assert.assertNotNull(jSSourceFileArray15);
        org.junit.Assert.assertNotNull(jSModuleArray16);
        org.junit.Assert.assertTrue("'" + tracerMode19 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TracerMode.OFF + "'", tracerMode19.equals(com.google.javascript.jscomp.CompilerOptions.TracerMode.OFF));
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        java.lang.Object obj0 = null;
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup1 = com.google.javascript.jscomp.DiagnosticGroups.NON_STANDARD_JSDOC;
        com.google.javascript.jscomp.DiagnosticGroups.TWEAKS = diagnosticGroup1;
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention4 = new com.google.javascript.jscomp.DefaultCodingConvention();
        java.lang.String str5 = defaultCodingConvention4.getExportSymbolFunction();
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node8 = node7.getParent();
        boolean boolean9 = node7.isQuotedString();
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship10 = defaultCodingConvention4.getDelegateRelationship(node7);
        com.google.javascript.rhino.Node node11 = com.google.javascript.jscomp.NodeUtil.newExpr(node7);
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node14 = node13.getParent();
        boolean boolean15 = node13.isQuotedString();
        com.google.javascript.rhino.Node node18 = new com.google.javascript.rhino.Node(4, node11, node13, 35, 0);
        java.lang.RuntimeException runtimeException21 = com.google.javascript.rhino.ScriptRuntime.undefWriteError((java.lang.Object) 0, (java.lang.Object) "hi!", (java.lang.Object) "window");
        java.lang.RuntimeException runtimeException22 = com.google.javascript.rhino.ScriptRuntime.undefWriteError(obj0, (java.lang.Object) diagnosticGroup1, (java.lang.Object) runtimeException21);
        com.google.javascript.rhino.EcmaError ecmaError25 = com.google.javascript.rhino.ScriptRuntime.constructError("100", "Not declared as a constructor");
        java.lang.String str26 = ecmaError25.getErrorMessage();
        runtimeException21.addSuppressed((java.lang.Throwable) ecmaError25);
        java.lang.String str28 = ecmaError25.getSourceName();
        java.lang.String str29 = ecmaError25.details();
        org.junit.Assert.assertNotNull(diagnosticGroup1);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertNull(node8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(delegateRelationship10);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNull(node14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(runtimeException21);
        org.junit.Assert.assertNotNull(runtimeException22);
        org.junit.Assert.assertNotNull(ecmaError25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "Not declared as a constructor" + "'", str26.equals("Not declared as a constructor"));
        org.junit.Assert.assertNull(str28);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "100: Not declared as a constructor" + "'", str29.equals("100: Not declared as a constructor"));
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        com.google.javascript.jscomp.SourceFile.Generator generator1 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("", generator1);
        com.google.javascript.jscomp.CompilerInput compilerInput4 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2, true);
        java.nio.charset.Charset charset6 = null;
        com.google.javascript.jscomp.SourceFile sourceFile7 = com.google.javascript.jscomp.SourceFile.fromFile("", charset6);
        compilerInput4.setSourceFile(sourceFile7);
        com.google.javascript.jscomp.SourceFile.Generator generator10 = null;
        com.google.javascript.jscomp.SourceFile sourceFile11 = com.google.javascript.jscomp.SourceFile.fromGenerator("", generator10);
        java.lang.String str12 = sourceFile11.getOriginalPath();
        compilerInput4.setSourceFile(sourceFile11);
        boolean boolean14 = compilerInput4.isExtern();
        compilerInput4.clearAst();
        try {
            java.util.Collection<java.lang.String> strCollection16 = compilerInput4.getRequires();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Expected setErrorManager to be called first");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile2);
        org.junit.Assert.assertNotNull(sourceFile7);
        org.junit.Assert.assertNotNull(sourceFile11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.SourceFile.Generator generator3 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile4 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("", generator3);
        com.google.javascript.jscomp.CompilerInput compilerInput5 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile4);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile7 = com.google.javascript.jscomp.JSSourceFile.fromFile("(STRING  [empty_block: 1])");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile9 = com.google.javascript.jscomp.JSSourceFile.fromFile("(STRING  [empty_block: 1])");
        com.google.javascript.jscomp.SourceFile.Generator generator11 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile12 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("", generator11);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile14 = com.google.javascript.jscomp.JSSourceFile.fromFile("(STRING  [empty_block: 1])");
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray15 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile4, jSSourceFile7, jSSourceFile9, jSSourceFile12, jSSourceFile14 };
        com.google.javascript.jscomp.JSModule[] jSModuleArray16 = new com.google.javascript.jscomp.JSModule[] {};
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph17 = new com.google.javascript.jscomp.JSModuleGraph(jSModuleArray16);
        com.google.javascript.jscomp.CompilerOptions compilerOptions18 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CompilerOptions.TracerMode tracerMode19 = compilerOptions18.tracer;
        compiler1.init(jSSourceFileArray15, jSModuleArray16, compilerOptions18);
        compilerOptions18.setGenerateExports(true);
        compilerOptions18.jsOutputFile = "21";
        compilerOptions18.removeUnusedPrototypeProperties = false;
        byte[] byteArray27 = compilerOptions18.inputVariableMapSerialized;
        java.io.PrintStream printStream28 = null;
        com.google.javascript.jscomp.Compiler compiler29 = new com.google.javascript.jscomp.Compiler(printStream28);
        com.google.javascript.jscomp.SourceFile.Generator generator31 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile32 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("", generator31);
        com.google.javascript.jscomp.CompilerInput compilerInput33 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile32);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile35 = com.google.javascript.jscomp.JSSourceFile.fromFile("(STRING  [empty_block: 1])");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile37 = com.google.javascript.jscomp.JSSourceFile.fromFile("(STRING  [empty_block: 1])");
        com.google.javascript.jscomp.SourceFile.Generator generator39 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile40 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("", generator39);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile42 = com.google.javascript.jscomp.JSSourceFile.fromFile("(STRING  [empty_block: 1])");
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray43 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile32, jSSourceFile35, jSSourceFile37, jSSourceFile40, jSSourceFile42 };
        com.google.javascript.jscomp.JSModule[] jSModuleArray44 = new com.google.javascript.jscomp.JSModule[] {};
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph45 = new com.google.javascript.jscomp.JSModuleGraph(jSModuleArray44);
        com.google.javascript.jscomp.CompilerOptions compilerOptions46 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CompilerOptions.TracerMode tracerMode47 = compilerOptions46.tracer;
        compiler29.init(jSSourceFileArray43, jSModuleArray44, compilerOptions46);
        compilerOptions46.setGenerateExports(true);
        compilerOptions46.jsOutputFile = "21";
        compilerOptions46.removeUnusedPrototypeProperties = false;
        byte[] byteArray55 = compilerOptions46.inputVariableMapSerialized;
        java.util.Set<java.lang.String> strSet56 = compilerOptions46.stripNameSuffixes;
        compilerOptions18.aliasableStrings = strSet56;
        boolean boolean58 = compilerOptions18.deadAssignmentElimination;
        boolean boolean59 = compilerOptions18.computeFunctionSideEffects;
        compilerOptions18.crossModuleMethodMotion = true;
        compilerOptions18.groupVariableDeclarations = true;
        java.lang.String str64 = compilerOptions18.aliasableGlobals;
        boolean boolean65 = compilerOptions18.prettyPrint;
        compilerOptions18.optimizeArgumentsArray = false;
        com.google.javascript.jscomp.DefaultPassConfig defaultPassConfig68 = new com.google.javascript.jscomp.DefaultPassConfig(compilerOptions18);
        org.junit.Assert.assertNotNull(jSSourceFile4);
        org.junit.Assert.assertNotNull(jSSourceFile7);
        org.junit.Assert.assertNotNull(jSSourceFile9);
        org.junit.Assert.assertNotNull(jSSourceFile12);
        org.junit.Assert.assertNotNull(jSSourceFile14);
        org.junit.Assert.assertNotNull(jSSourceFileArray15);
        org.junit.Assert.assertNotNull(jSModuleArray16);
        org.junit.Assert.assertTrue("'" + tracerMode19 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TracerMode.OFF + "'", tracerMode19.equals(com.google.javascript.jscomp.CompilerOptions.TracerMode.OFF));
        org.junit.Assert.assertNull(byteArray27);
        org.junit.Assert.assertNotNull(jSSourceFile32);
        org.junit.Assert.assertNotNull(jSSourceFile35);
        org.junit.Assert.assertNotNull(jSSourceFile37);
        org.junit.Assert.assertNotNull(jSSourceFile40);
        org.junit.Assert.assertNotNull(jSSourceFile42);
        org.junit.Assert.assertNotNull(jSSourceFileArray43);
        org.junit.Assert.assertNotNull(jSModuleArray44);
        org.junit.Assert.assertTrue("'" + tracerMode47 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TracerMode.OFF + "'", tracerMode47.equals(com.google.javascript.jscomp.CompilerOptions.TracerMode.OFF));
        org.junit.Assert.assertNull(byteArray55);
        org.junit.Assert.assertNotNull(strSet56);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertNull(str64);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.SourceFile.Generator generator3 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile4 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("", generator3);
        com.google.javascript.jscomp.CompilerInput compilerInput5 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile4);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile7 = com.google.javascript.jscomp.JSSourceFile.fromFile("(STRING  [empty_block: 1])");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile9 = com.google.javascript.jscomp.JSSourceFile.fromFile("(STRING  [empty_block: 1])");
        com.google.javascript.jscomp.SourceFile.Generator generator11 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile12 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("", generator11);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile14 = com.google.javascript.jscomp.JSSourceFile.fromFile("(STRING  [empty_block: 1])");
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray15 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile4, jSSourceFile7, jSSourceFile9, jSSourceFile12, jSSourceFile14 };
        com.google.javascript.jscomp.JSModule[] jSModuleArray16 = new com.google.javascript.jscomp.JSModule[] {};
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph17 = new com.google.javascript.jscomp.JSModuleGraph(jSModuleArray16);
        com.google.javascript.jscomp.CompilerOptions compilerOptions18 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CompilerOptions.TracerMode tracerMode19 = compilerOptions18.tracer;
        compiler1.init(jSSourceFileArray15, jSModuleArray16, compilerOptions18);
        compilerOptions18.setGenerateExports(true);
        compilerOptions18.jsOutputFile = "21";
        boolean boolean25 = compilerOptions18.checkEs5Strict;
        boolean boolean26 = compilerOptions18.isExternExportsEnabled();
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy27 = compilerOptions18.propertyRenaming;
        org.junit.Assert.assertNotNull(jSSourceFile4);
        org.junit.Assert.assertNotNull(jSSourceFile7);
        org.junit.Assert.assertNotNull(jSSourceFile9);
        org.junit.Assert.assertNotNull(jSSourceFile12);
        org.junit.Assert.assertNotNull(jSSourceFile14);
        org.junit.Assert.assertNotNull(jSSourceFileArray15);
        org.junit.Assert.assertNotNull(jSModuleArray16);
        org.junit.Assert.assertTrue("'" + tracerMode19 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TracerMode.OFF + "'", tracerMode19.equals(com.google.javascript.jscomp.CompilerOptions.TracerMode.OFF));
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy27 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.OFF + "'", propertyRenamingPolicy27.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.OFF));
    }

//    @Test
//    public void test441() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test441");
//        com.google.javascript.rhino.Context context0 = null;
//        com.google.javascript.rhino.Context context1 = com.google.javascript.rhino.Context.enter(context0);
//        java.util.Locale locale2 = context1.getLocale();
//        boolean boolean3 = context1.isGeneratingDebug();
//        java.lang.String str4 = context1.getImplementationVersion();
//        long long5 = com.google.javascript.rhino.ScriptRuntime.lastUint32Result(context1);
//        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention6 = new com.google.javascript.jscomp.DefaultCodingConvention();
//        java.lang.String str7 = defaultCodingConvention6.getExportSymbolFunction();
//        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString("");
//        com.google.javascript.rhino.Node node10 = node9.getParent();
//        boolean boolean11 = node9.isQuotedString();
//        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship12 = defaultCodingConvention6.getDelegateRelationship(node9);
//        java.util.Collection<com.google.javascript.rhino.Node> nodeCollection13 = com.google.javascript.jscomp.NodeUtil.getVarsDeclaredInBranch(node9);
//        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.Node.newString("");
//        com.google.javascript.rhino.Node node17 = node16.getParent();
//        boolean boolean18 = node16.isQuotedString();
//        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.Node.newString("");
//        com.google.javascript.rhino.Node node21 = node20.getParent();
//        boolean boolean22 = node20.hasChildren();
//        node20.detachChildren();
//        java.lang.String str24 = node20.getString();
//        com.google.javascript.rhino.Node node26 = com.google.javascript.rhino.Node.newString("");
//        com.google.javascript.rhino.Node node27 = node26.getParent();
//        boolean boolean28 = node26.isQuotedString();
//        com.google.javascript.rhino.Node node30 = com.google.javascript.rhino.Node.newString("");
//        int int31 = node30.getSideEffectFlags();
//        boolean boolean32 = node30.isOptionalArg();
//        com.google.javascript.rhino.Node node33 = node30.getLastSibling();
//        com.google.javascript.rhino.Node node36 = new com.google.javascript.rhino.Node((int) (short) 10, node16, node20, node26, node30, (int) '4', (int) 'a');
//        com.google.javascript.rhino.Node node37 = node9.copyInformationFrom(node20);
//        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup38 = com.google.javascript.jscomp.DiagnosticGroups.CONSTANT_PROPERTY;
//        context1.putThreadLocal((java.lang.Object) node37, (java.lang.Object) diagnosticGroup38);
//        boolean boolean40 = context1.isGeneratingSource();
//        org.junit.Assert.assertNotNull(context1);
//        org.junit.Assert.assertNotNull(locale2);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "@IMPLEMENTATION.VERSION@" + "'", str4.equals("@IMPLEMENTATION.VERSION@"));
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
//        org.junit.Assert.assertNull(str7);
//        org.junit.Assert.assertNotNull(node9);
//        org.junit.Assert.assertNull(node10);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertNull(delegateRelationship12);
//        org.junit.Assert.assertNotNull(nodeCollection13);
//        org.junit.Assert.assertNotNull(node16);
//        org.junit.Assert.assertNull(node17);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//        org.junit.Assert.assertNotNull(node20);
//        org.junit.Assert.assertNull(node21);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "" + "'", str24.equals(""));
//        org.junit.Assert.assertNotNull(node26);
//        org.junit.Assert.assertNull(node27);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//        org.junit.Assert.assertNotNull(node30);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//        org.junit.Assert.assertNotNull(node33);
//        org.junit.Assert.assertNotNull(node37);
//        org.junit.Assert.assertNotNull(diagnosticGroup38);
//        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
//    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node node1 = compiler0.getRoot();
        com.google.javascript.jscomp.Compiler compiler2 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.Compiler.IntermediateState intermediateState3 = compiler2.getState();
        compiler0.setState(intermediateState3);
        com.google.javascript.jscomp.SourceFile.Generator generator6 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile7 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("Not declared as a constructor", generator6);
        com.google.javascript.jscomp.SourceFile.Generator generator9 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile10 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("Not declared as a constructor", generator9);
        java.io.PrintStream printStream11 = null;
        com.google.javascript.jscomp.Compiler compiler12 = new com.google.javascript.jscomp.Compiler(printStream11);
        com.google.javascript.jscomp.SourceFile.Generator generator14 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile15 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("", generator14);
        com.google.javascript.jscomp.CompilerInput compilerInput16 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile15);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile18 = com.google.javascript.jscomp.JSSourceFile.fromFile("(STRING  [empty_block: 1])");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile20 = com.google.javascript.jscomp.JSSourceFile.fromFile("(STRING  [empty_block: 1])");
        com.google.javascript.jscomp.SourceFile.Generator generator22 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile23 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("", generator22);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile25 = com.google.javascript.jscomp.JSSourceFile.fromFile("(STRING  [empty_block: 1])");
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray26 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile15, jSSourceFile18, jSSourceFile20, jSSourceFile23, jSSourceFile25 };
        com.google.javascript.jscomp.JSModule[] jSModuleArray27 = new com.google.javascript.jscomp.JSModule[] {};
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph28 = new com.google.javascript.jscomp.JSModuleGraph(jSModuleArray27);
        com.google.javascript.jscomp.CompilerOptions compilerOptions29 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CompilerOptions.TracerMode tracerMode30 = compilerOptions29.tracer;
        compiler12.init(jSSourceFileArray26, jSModuleArray27, compilerOptions29);
        com.google.javascript.jscomp.SourceFile.Generator generator33 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile34 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("", generator33);
        com.google.javascript.jscomp.CompilerInput compilerInput36 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile34, true);
        com.google.javascript.jscomp.SourceFile.Generator generator38 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile39 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("Not declared as a constructor", generator38);
        com.google.javascript.jscomp.SourceFile.Generator generator41 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile42 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("", generator41);
        com.google.javascript.jscomp.CompilerInput compilerInput43 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile42);
        com.google.javascript.jscomp.SourceFile.Generator generator45 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile46 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("", generator45);
        com.google.javascript.jscomp.CompilerInput compilerInput48 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile46, true);
        com.google.javascript.jscomp.SourceFile.Generator generator50 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile51 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("", generator50);
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray52 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile39, jSSourceFile42, jSSourceFile46, jSSourceFile51 };
        com.google.javascript.jscomp.CompilerOptions compilerOptions53 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention54 = new com.google.javascript.jscomp.DefaultCodingConvention();
        boolean boolean56 = defaultCodingConvention54.isExported("window");
        compilerOptions53.setCodingConvention((com.google.javascript.jscomp.CodingConvention) defaultCodingConvention54);
        com.google.javascript.jscomp.Result result58 = compiler12.compile(jSSourceFile34, jSSourceFileArray52, compilerOptions53);
        java.nio.charset.Charset charset60 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile61 = com.google.javascript.jscomp.JSSourceFile.fromFile("error reporter", charset60);
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray62 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile7, jSSourceFile10, jSSourceFile34, jSSourceFile61 };
        com.google.javascript.jscomp.JSModule[] jSModuleArray63 = new com.google.javascript.jscomp.JSModule[] {};
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph64 = new com.google.javascript.jscomp.JSModuleGraph(jSModuleArray63);
        com.google.javascript.jscomp.CompilerOptions compilerOptions65 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention66 = new com.google.javascript.jscomp.DefaultCodingConvention();
        boolean boolean68 = defaultCodingConvention66.isExported("window");
        compilerOptions65.setCodingConvention((com.google.javascript.jscomp.CodingConvention) defaultCodingConvention66);
        java.lang.Object obj70 = compilerOptions65.clone();
        compilerOptions65.strictMessageReplacement = false;
        compilerOptions65.enableRuntimeTypeCheck("");
        compiler0.init(jSSourceFileArray62, jSModuleArray63, compilerOptions65);
        java.lang.Class<?> wildcardClass76 = compilerOptions65.getClass();
        org.junit.Assert.assertNull(node1);
        org.junit.Assert.assertNotNull(intermediateState3);
        org.junit.Assert.assertNotNull(jSSourceFile7);
        org.junit.Assert.assertNotNull(jSSourceFile10);
        org.junit.Assert.assertNotNull(jSSourceFile15);
        org.junit.Assert.assertNotNull(jSSourceFile18);
        org.junit.Assert.assertNotNull(jSSourceFile20);
        org.junit.Assert.assertNotNull(jSSourceFile23);
        org.junit.Assert.assertNotNull(jSSourceFile25);
        org.junit.Assert.assertNotNull(jSSourceFileArray26);
        org.junit.Assert.assertNotNull(jSModuleArray27);
        org.junit.Assert.assertTrue("'" + tracerMode30 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TracerMode.OFF + "'", tracerMode30.equals(com.google.javascript.jscomp.CompilerOptions.TracerMode.OFF));
        org.junit.Assert.assertNotNull(jSSourceFile34);
        org.junit.Assert.assertNotNull(jSSourceFile39);
        org.junit.Assert.assertNotNull(jSSourceFile42);
        org.junit.Assert.assertNotNull(jSSourceFile46);
        org.junit.Assert.assertNotNull(jSSourceFile51);
        org.junit.Assert.assertNotNull(jSSourceFileArray52);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertNotNull(result58);
        org.junit.Assert.assertNotNull(jSSourceFile61);
        org.junit.Assert.assertNotNull(jSSourceFileArray62);
        org.junit.Assert.assertNotNull(jSModuleArray63);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertNotNull(obj70);
        org.junit.Assert.assertNotNull(wildcardClass76);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CompilerOptions.TracerMode tracerMode1 = compilerOptions0.tracer;
        boolean boolean2 = compilerOptions0.smartNameRemoval;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy3 = compilerOptions0.variableRenaming;
        compilerOptions0.decomposeExpressions = false;
        boolean boolean6 = compilerOptions0.devirtualizePrototypeMethods;
        compilerOptions0.strictMessageReplacement = true;
        org.junit.Assert.assertTrue("'" + tracerMode1 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TracerMode.OFF + "'", tracerMode1.equals(com.google.javascript.jscomp.CompilerOptions.TracerMode.OFF));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy3 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.OFF + "'", variableRenamingPolicy3.equals(com.google.javascript.jscomp.VariableRenamingPolicy.OFF));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.EXTERNS_VALIDATION;
        com.google.javascript.jscomp.DiagnosticGroups.DEPRECATED = diagnosticGroup0;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.SourceFile.Generator generator3 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile4 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("", generator3);
        com.google.javascript.jscomp.CompilerInput compilerInput5 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile4);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile7 = com.google.javascript.jscomp.JSSourceFile.fromFile("(STRING  [empty_block: 1])");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile9 = com.google.javascript.jscomp.JSSourceFile.fromFile("(STRING  [empty_block: 1])");
        com.google.javascript.jscomp.SourceFile.Generator generator11 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile12 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("", generator11);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile14 = com.google.javascript.jscomp.JSSourceFile.fromFile("(STRING  [empty_block: 1])");
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray15 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile4, jSSourceFile7, jSSourceFile9, jSSourceFile12, jSSourceFile14 };
        com.google.javascript.jscomp.JSModule[] jSModuleArray16 = new com.google.javascript.jscomp.JSModule[] {};
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph17 = new com.google.javascript.jscomp.JSModuleGraph(jSModuleArray16);
        com.google.javascript.jscomp.CompilerOptions compilerOptions18 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CompilerOptions.TracerMode tracerMode19 = compilerOptions18.tracer;
        compiler1.init(jSSourceFileArray15, jSModuleArray16, compilerOptions18);
        com.google.javascript.jscomp.JSError[] jSErrorArray21 = compiler1.getWarnings();
        com.google.javascript.jscomp.SourceExcerptProvider.SourceExcerpt sourceExcerpt22 = null;
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter23 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler1, sourceExcerpt22);
        com.google.javascript.jscomp.JSError jSError24 = null;
        try {
            java.lang.String str25 = lightweightMessageFormatter23.formatError(jSError24);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile4);
        org.junit.Assert.assertNotNull(jSSourceFile7);
        org.junit.Assert.assertNotNull(jSSourceFile9);
        org.junit.Assert.assertNotNull(jSSourceFile12);
        org.junit.Assert.assertNotNull(jSSourceFile14);
        org.junit.Assert.assertNotNull(jSSourceFileArray15);
        org.junit.Assert.assertNotNull(jSModuleArray16);
        org.junit.Assert.assertTrue("'" + tracerMode19 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TracerMode.OFF + "'", tracerMode19.equals(com.google.javascript.jscomp.CompilerOptions.TracerMode.OFF));
        org.junit.Assert.assertNotNull(jSErrorArray21);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        com.google.javascript.jscomp.SourceFile.Generator generator1 = null;
        com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromGenerator("", generator1);
        java.lang.String str3 = sourceFile2.getOriginalPath();
        com.google.javascript.jscomp.JsAst jsAst4 = new com.google.javascript.jscomp.JsAst(sourceFile2);
        jsAst4.clearAst();
        jsAst4.clearAst();
        org.junit.Assert.assertNotNull(sourceFile2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.Compiler.IntermediateState intermediateState1 = compiler0.getState();
        java.io.PrintStream printStream2 = null;
        com.google.javascript.jscomp.Compiler compiler3 = new com.google.javascript.jscomp.Compiler(printStream2);
        com.google.javascript.jscomp.SourceFile.Generator generator5 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile6 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("", generator5);
        com.google.javascript.jscomp.CompilerInput compilerInput7 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile6);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile9 = com.google.javascript.jscomp.JSSourceFile.fromFile("(STRING  [empty_block: 1])");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile11 = com.google.javascript.jscomp.JSSourceFile.fromFile("(STRING  [empty_block: 1])");
        com.google.javascript.jscomp.SourceFile.Generator generator13 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile14 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("", generator13);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile16 = com.google.javascript.jscomp.JSSourceFile.fromFile("(STRING  [empty_block: 1])");
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray17 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile6, jSSourceFile9, jSSourceFile11, jSSourceFile14, jSSourceFile16 };
        com.google.javascript.jscomp.JSModule[] jSModuleArray18 = new com.google.javascript.jscomp.JSModule[] {};
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph19 = new com.google.javascript.jscomp.JSModuleGraph(jSModuleArray18);
        com.google.javascript.jscomp.CompilerOptions compilerOptions20 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CompilerOptions.TracerMode tracerMode21 = compilerOptions20.tracer;
        compiler3.init(jSSourceFileArray17, jSModuleArray18, compilerOptions20);
        compilerOptions20.setGenerateExports(true);
        compilerOptions20.jsOutputFile = "21";
        compiler0.initOptions(compilerOptions20);
        boolean boolean28 = compiler0.acceptConstKeyword();
        org.junit.Assert.assertNotNull(intermediateState1);
        org.junit.Assert.assertNotNull(jSSourceFile6);
        org.junit.Assert.assertNotNull(jSSourceFile9);
        org.junit.Assert.assertNotNull(jSSourceFile11);
        org.junit.Assert.assertNotNull(jSSourceFile14);
        org.junit.Assert.assertNotNull(jSSourceFile16);
        org.junit.Assert.assertNotNull(jSSourceFileArray17);
        org.junit.Assert.assertNotNull(jSModuleArray18);
        org.junit.Assert.assertTrue("'" + tracerMode21 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TracerMode.OFF + "'", tracerMode21.equals(com.google.javascript.jscomp.CompilerOptions.TracerMode.OFF));
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CompilerOptions.TracerMode tracerMode1 = compilerOptions0.tracer;
        compilerOptions0.inlineLocalVariables = true;
        compilerOptions0.closurePass = false;
        compilerOptions0.checkDuplicateMessages = false;
        org.junit.Assert.assertTrue("'" + tracerMode1 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TracerMode.OFF + "'", tracerMode1.equals(com.google.javascript.jscomp.CompilerOptions.TracerMode.OFF));
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newString("");
        int int2 = node1.getSideEffectFlags();
        java.util.Collection<com.google.javascript.rhino.Node> nodeCollection3 = com.google.javascript.jscomp.NodeUtil.getVarsDeclaredInBranch(node1);
        java.lang.String str4 = node1.getString();
        boolean boolean5 = node1.hasMoreThanOneChild();
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(nodeCollection3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.TYPE_INVALIDATION;
        com.google.javascript.jscomp.DiagnosticGroups.INTERNET_EXPLORER_CHECKS = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticGroups.GLOBAL_THIS = diagnosticGroup0;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.inlineFunctions;
        compilerOptions0.printInputDelimiter = false;
        com.google.javascript.jscomp.AnonymousFunctionNamingPolicy anonymousFunctionNamingPolicy4 = com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.UNMAPPED;
        compilerOptions0.anonymousFunctionNaming = anonymousFunctionNamingPolicy4;
        compilerOptions0.setDefineToNumberLiteral("", 45);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + anonymousFunctionNamingPolicy4 + "' != '" + com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.UNMAPPED + "'", anonymousFunctionNamingPolicy4.equals(com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.UNMAPPED));
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        com.google.javascript.jscomp.SourceFile.Generator generator1 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("", generator1);
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2);
        try {
            java.lang.String str4 = compilerInput3.getCode();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile2);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.SourceFile.Generator generator3 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile4 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("", generator3);
        com.google.javascript.jscomp.CompilerInput compilerInput5 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile4);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile7 = com.google.javascript.jscomp.JSSourceFile.fromFile("(STRING  [empty_block: 1])");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile9 = com.google.javascript.jscomp.JSSourceFile.fromFile("(STRING  [empty_block: 1])");
        com.google.javascript.jscomp.SourceFile.Generator generator11 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile12 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("", generator11);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile14 = com.google.javascript.jscomp.JSSourceFile.fromFile("(STRING  [empty_block: 1])");
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray15 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile4, jSSourceFile7, jSSourceFile9, jSSourceFile12, jSSourceFile14 };
        com.google.javascript.jscomp.JSModule[] jSModuleArray16 = new com.google.javascript.jscomp.JSModule[] {};
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph17 = new com.google.javascript.jscomp.JSModuleGraph(jSModuleArray16);
        com.google.javascript.jscomp.CompilerOptions compilerOptions18 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CompilerOptions.TracerMode tracerMode19 = compilerOptions18.tracer;
        compiler1.init(jSSourceFileArray15, jSModuleArray16, compilerOptions18);
        compilerOptions18.setGenerateExports(true);
        compilerOptions18.jsOutputFile = "21";
        compilerOptions18.removeUnusedPrototypeProperties = false;
        byte[] byteArray27 = compilerOptions18.inputVariableMapSerialized;
        compilerOptions18.setAcceptConstKeyword(false);
        compilerOptions18.setGenerateExports(false);
        compilerOptions18.inlineFunctions = true;
        org.junit.Assert.assertNotNull(jSSourceFile4);
        org.junit.Assert.assertNotNull(jSSourceFile7);
        org.junit.Assert.assertNotNull(jSSourceFile9);
        org.junit.Assert.assertNotNull(jSSourceFile12);
        org.junit.Assert.assertNotNull(jSSourceFile14);
        org.junit.Assert.assertNotNull(jSSourceFileArray15);
        org.junit.Assert.assertNotNull(jSModuleArray16);
        org.junit.Assert.assertTrue("'" + tracerMode19 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TracerMode.OFF + "'", tracerMode19.equals(com.google.javascript.jscomp.CompilerOptions.TracerMode.OFF));
        org.junit.Assert.assertNull(byteArray27);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.SourceFile.Generator generator3 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile4 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("", generator3);
        com.google.javascript.jscomp.CompilerInput compilerInput5 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile4);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile7 = com.google.javascript.jscomp.JSSourceFile.fromFile("(STRING  [empty_block: 1])");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile9 = com.google.javascript.jscomp.JSSourceFile.fromFile("(STRING  [empty_block: 1])");
        com.google.javascript.jscomp.SourceFile.Generator generator11 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile12 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("", generator11);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile14 = com.google.javascript.jscomp.JSSourceFile.fromFile("(STRING  [empty_block: 1])");
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray15 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile4, jSSourceFile7, jSSourceFile9, jSSourceFile12, jSSourceFile14 };
        com.google.javascript.jscomp.JSModule[] jSModuleArray16 = new com.google.javascript.jscomp.JSModule[] {};
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph17 = new com.google.javascript.jscomp.JSModuleGraph(jSModuleArray16);
        com.google.javascript.jscomp.CompilerOptions compilerOptions18 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CompilerOptions.TracerMode tracerMode19 = compilerOptions18.tracer;
        compiler1.init(jSSourceFileArray15, jSModuleArray16, compilerOptions18);
        compilerOptions18.setGenerateExports(true);
        compilerOptions18.jsOutputFile = "21";
        compilerOptions18.removeUnusedPrototypeProperties = false;
        com.google.javascript.jscomp.CheckLevel checkLevel27 = compilerOptions18.checkGlobalNamesLevel;
        boolean boolean28 = compilerOptions18.aliasAllStrings;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap29 = compilerOptions18.cssRenamingMap;
        compilerOptions18.setNameAnonymousFunctionsOnly(true);
        org.junit.Assert.assertNotNull(jSSourceFile4);
        org.junit.Assert.assertNotNull(jSSourceFile7);
        org.junit.Assert.assertNotNull(jSSourceFile9);
        org.junit.Assert.assertNotNull(jSSourceFile12);
        org.junit.Assert.assertNotNull(jSSourceFile14);
        org.junit.Assert.assertNotNull(jSSourceFileArray15);
        org.junit.Assert.assertNotNull(jSModuleArray16);
        org.junit.Assert.assertTrue("'" + tracerMode19 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TracerMode.OFF + "'", tracerMode19.equals(com.google.javascript.jscomp.CompilerOptions.TracerMode.OFF));
        org.junit.Assert.assertTrue("'" + checkLevel27 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel27.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNull(cssRenamingMap29);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.SourceFile.Generator generator3 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile4 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("", generator3);
        com.google.javascript.jscomp.CompilerInput compilerInput5 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile4);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile7 = com.google.javascript.jscomp.JSSourceFile.fromFile("(STRING  [empty_block: 1])");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile9 = com.google.javascript.jscomp.JSSourceFile.fromFile("(STRING  [empty_block: 1])");
        com.google.javascript.jscomp.SourceFile.Generator generator11 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile12 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("", generator11);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile14 = com.google.javascript.jscomp.JSSourceFile.fromFile("(STRING  [empty_block: 1])");
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray15 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile4, jSSourceFile7, jSSourceFile9, jSSourceFile12, jSSourceFile14 };
        com.google.javascript.jscomp.JSModule[] jSModuleArray16 = new com.google.javascript.jscomp.JSModule[] {};
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph17 = new com.google.javascript.jscomp.JSModuleGraph(jSModuleArray16);
        com.google.javascript.jscomp.CompilerOptions compilerOptions18 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CompilerOptions.TracerMode tracerMode19 = compilerOptions18.tracer;
        compiler1.init(jSSourceFileArray15, jSModuleArray16, compilerOptions18);
        compilerOptions18.checkEs5Strict = false;
        compilerOptions18.flowSensitiveInlineVariables = false;
        compilerOptions18.removeTryCatchFinally = true;
        compilerOptions18.setCollapsePropertiesOnExternTypes(true);
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy29 = com.google.javascript.jscomp.VariableRenamingPolicy.LOCAL;
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy30 = com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC;
        compilerOptions18.setRenamingPolicy(variableRenamingPolicy29, propertyRenamingPolicy30);
        boolean boolean32 = compilerOptions18.checkDuplicateMessages;
        compilerOptions18.setRewriteNewDateGoogNow(false);
        org.junit.Assert.assertNotNull(jSSourceFile4);
        org.junit.Assert.assertNotNull(jSSourceFile7);
        org.junit.Assert.assertNotNull(jSSourceFile9);
        org.junit.Assert.assertNotNull(jSSourceFile12);
        org.junit.Assert.assertNotNull(jSSourceFile14);
        org.junit.Assert.assertNotNull(jSSourceFileArray15);
        org.junit.Assert.assertNotNull(jSModuleArray16);
        org.junit.Assert.assertTrue("'" + tracerMode19 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TracerMode.OFF + "'", tracerMode19.equals(com.google.javascript.jscomp.CompilerOptions.TracerMode.OFF));
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy29 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.LOCAL + "'", variableRenamingPolicy29.equals(com.google.javascript.jscomp.VariableRenamingPolicy.LOCAL));
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy30 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC + "'", propertyRenamingPolicy30.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC));
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        com.google.javascript.jscomp.SourceFile.Generator generator1 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("", generator1);
        com.google.javascript.jscomp.CompilerInput compilerInput4 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2, true);
        java.nio.charset.Charset charset6 = null;
        com.google.javascript.jscomp.SourceFile sourceFile7 = com.google.javascript.jscomp.SourceFile.fromFile("", charset6);
        compilerInput4.setSourceFile(sourceFile7);
        com.google.javascript.jscomp.SourceFile.Generator generator10 = null;
        com.google.javascript.jscomp.SourceFile sourceFile11 = com.google.javascript.jscomp.SourceFile.fromGenerator("", generator10);
        java.lang.String str12 = sourceFile11.getOriginalPath();
        compilerInput4.setSourceFile(sourceFile11);
        com.google.javascript.jscomp.ErrorManager errorManager14 = null;
        compilerInput4.setErrorManager(errorManager14);
        java.lang.String str16 = compilerInput4.getName();
        try {
            java.lang.String str17 = compilerInput4.getPathRelativeToClosureBase();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: null");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile2);
        org.junit.Assert.assertNotNull(sourceFile7);
        org.junit.Assert.assertNotNull(sourceFile11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.TYPE_INVALIDATION;
        com.google.javascript.jscomp.DiagnosticGroups.INTERNET_EXPLORER_CHECKS = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticGroups.CHECK_TYPES = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticGroups.STRICT_MODULE_DEP_CHECK = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticGroups.CONSTANT_PROPERTY = diagnosticGroup0;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        java.nio.charset.Charset charset1 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromFile("(100)", charset1);
        org.junit.Assert.assertNotNull(jSSourceFile2);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.Node.newString("");
        int int3 = node2.getSideEffectFlags();
        boolean boolean4 = node2.isOptionalArg();
        com.google.javascript.rhino.Node node5 = node2.getLastSibling();
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.Node.newString("");
        int int8 = node7.getSideEffectFlags();
        boolean boolean9 = node7.isOptionalArg();
        boolean boolean10 = node7.isQuotedString();
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString("");
        int int13 = node12.getSideEffectFlags();
        java.util.Collection<com.google.javascript.rhino.Node> nodeCollection14 = com.google.javascript.jscomp.NodeUtil.getVarsDeclaredInBranch(node12);
        java.lang.String str15 = node12.getString();
        com.google.javascript.rhino.Node node16 = new com.google.javascript.rhino.Node((int) (byte) 10, node2, node7, node12);
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.Node.newString("");
        int int20 = node19.getSideEffectFlags();
        boolean boolean21 = node19.isOptionalArg();
        com.google.javascript.rhino.Node node22 = node19.getLastSibling();
        com.google.javascript.rhino.Node node24 = com.google.javascript.rhino.Node.newString("");
        int int25 = node24.getSideEffectFlags();
        boolean boolean26 = node24.isOptionalArg();
        boolean boolean27 = node24.isQuotedString();
        com.google.javascript.rhino.Node node29 = com.google.javascript.rhino.Node.newString("");
        int int30 = node29.getSideEffectFlags();
        java.util.Collection<com.google.javascript.rhino.Node> nodeCollection31 = com.google.javascript.jscomp.NodeUtil.getVarsDeclaredInBranch(node29);
        java.lang.String str32 = node29.getString();
        com.google.javascript.rhino.Node node33 = new com.google.javascript.rhino.Node((int) (byte) 10, node19, node24, node29);
        node29.setLineno(160);
        com.google.javascript.rhino.Node node36 = null;
        try {
            node7.replaceChild(node29, node36);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(nodeCollection14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertNotNull(nodeCollection31);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "" + "'", str32.equals(""));
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention1 = new com.google.javascript.jscomp.DefaultCodingConvention();
        boolean boolean3 = defaultCodingConvention1.isExported("window");
        compilerOptions0.setCodingConvention((com.google.javascript.jscomp.CodingConvention) defaultCodingConvention1);
        java.lang.String str5 = compilerOptions0.renamePrefix;
        java.util.Set<java.lang.String> strSet6 = compilerOptions0.stripNameSuffixes;
        boolean boolean7 = compilerOptions0.removeUnusedVars;
        boolean boolean8 = compilerOptions0.rewriteFunctionExpressions;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertNotNull(strSet6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromCode("(STRING  [empty_block: 1])", "language version");
        org.junit.Assert.assertNotNull(jSSourceFile2);
    }

//    @Test
//    public void test462() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test462");
//        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention2 = new com.google.javascript.jscomp.DefaultCodingConvention();
//        java.lang.String str3 = defaultCodingConvention2.getExportSymbolFunction();
//        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newString("");
//        com.google.javascript.rhino.Node node6 = node5.getParent();
//        boolean boolean7 = node5.isQuotedString();
//        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship8 = defaultCodingConvention2.getDelegateRelationship(node5);
//        com.google.javascript.rhino.Node node9 = com.google.javascript.jscomp.NodeUtil.newExpr(node5);
//        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.Node.newString("");
//        com.google.javascript.rhino.Node node12 = node11.getParent();
//        boolean boolean13 = node11.isQuotedString();
//        com.google.javascript.rhino.Node node16 = new com.google.javascript.rhino.Node(4, node9, node11, 35, 0);
//        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention18 = new com.google.javascript.jscomp.DefaultCodingConvention();
//        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention19 = new com.google.javascript.jscomp.DefaultCodingConvention();
//        java.lang.String str20 = defaultCodingConvention19.getExportSymbolFunction();
//        com.google.javascript.rhino.Node node22 = com.google.javascript.rhino.Node.newString("");
//        com.google.javascript.rhino.Node node23 = node22.getParent();
//        boolean boolean24 = node22.isQuotedString();
//        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship25 = defaultCodingConvention19.getDelegateRelationship(node22);
//        com.google.javascript.jscomp.CodingConvention.SubclassRelationship subclassRelationship26 = defaultCodingConvention18.getClassesDefinedByCall(node22);
//        com.google.javascript.jscomp.CheckLevel checkLevel28 = com.google.javascript.jscomp.CheckLevel.ERROR;
//        com.google.javascript.jscomp.DiagnosticType diagnosticType30 = com.google.javascript.jscomp.DiagnosticType.make("@IMPLEMENTATION.VERSION@", checkLevel28, "error reporter");
//        com.google.javascript.jscomp.DiagnosticType diagnosticType33 = com.google.javascript.jscomp.DiagnosticType.error("100", "language version");
//        java.lang.String[] strArray34 = com.google.javascript.rhino.ScriptRuntime.emptyStrings;
//        com.google.javascript.jscomp.JSError jSError35 = com.google.javascript.jscomp.JSError.make("STRING  [empty_block: 1]", node22, checkLevel28, diagnosticType33, strArray34);
//        com.google.javascript.rhino.Node node37 = com.google.javascript.rhino.Node.newString("");
//        com.google.javascript.rhino.Node node38 = node37.getParent();
//        boolean boolean39 = node37.hasChildren();
//        com.google.javascript.rhino.Context context40 = null;
//        com.google.javascript.rhino.Context context41 = com.google.javascript.rhino.Context.enter(context40);
//        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention42 = new com.google.javascript.jscomp.DefaultCodingConvention();
//        java.lang.String str43 = defaultCodingConvention42.getExportSymbolFunction();
//        com.google.javascript.rhino.Node node45 = com.google.javascript.rhino.Node.newString("");
//        com.google.javascript.rhino.Node node46 = node45.getParent();
//        boolean boolean47 = node45.isQuotedString();
//        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship48 = defaultCodingConvention42.getDelegateRelationship(node45);
//        java.util.Collection<com.google.javascript.rhino.Node> nodeCollection49 = com.google.javascript.jscomp.NodeUtil.getVarsDeclaredInBranch(node45);
//        com.google.javascript.rhino.JSDocInfo jSDocInfo50 = node45.getJSDocInfo();
//        com.google.javascript.rhino.Node node52 = com.google.javascript.rhino.Node.newString("");
//        com.google.javascript.rhino.Node node53 = node52.getParent();
//        boolean boolean54 = node52.hasChildren();
//        node52.detachChildren();
//        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder56 = node52.getJsDocBuilderForNode();
//        int int57 = node52.getType();
//        com.google.javascript.rhino.Node node58 = node45.copyInformationFrom(node52);
//        context41.removeThreadLocal((java.lang.Object) node45);
//        com.google.javascript.rhino.Node node60 = node45.getNext();
//        try {
//            com.google.javascript.rhino.Node node61 = new com.google.javascript.rhino.Node(27, node9, node22, node37, node45);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNull(str3);
//        org.junit.Assert.assertNotNull(node5);
//        org.junit.Assert.assertNull(node6);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertNull(delegateRelationship8);
//        org.junit.Assert.assertNotNull(node9);
//        org.junit.Assert.assertNotNull(node11);
//        org.junit.Assert.assertNull(node12);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertNull(str20);
//        org.junit.Assert.assertNotNull(node22);
//        org.junit.Assert.assertNull(node23);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
//        org.junit.Assert.assertNull(delegateRelationship25);
//        org.junit.Assert.assertNull(subclassRelationship26);
//        org.junit.Assert.assertTrue("'" + checkLevel28 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel28.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
//        org.junit.Assert.assertNotNull(diagnosticType30);
//        org.junit.Assert.assertNotNull(diagnosticType33);
//        org.junit.Assert.assertNotNull(strArray34);
//        org.junit.Assert.assertNotNull(jSError35);
//        org.junit.Assert.assertNotNull(node37);
//        org.junit.Assert.assertNull(node38);
//        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
//        org.junit.Assert.assertNotNull(context41);
//        org.junit.Assert.assertNull(str43);
//        org.junit.Assert.assertNotNull(node45);
//        org.junit.Assert.assertNull(node46);
//        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
//        org.junit.Assert.assertNull(delegateRelationship48);
//        org.junit.Assert.assertNotNull(nodeCollection49);
//        org.junit.Assert.assertNull(jSDocInfo50);
//        org.junit.Assert.assertNotNull(node52);
//        org.junit.Assert.assertNull(node53);
//        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
//        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder56);
//        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 40 + "'", int57 == 40);
//        org.junit.Assert.assertNotNull(node58);
//        org.junit.Assert.assertNull(node60);
//    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention0 = new com.google.javascript.jscomp.DefaultCodingConvention();
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention1 = new com.google.javascript.jscomp.DefaultCodingConvention();
        java.lang.String str2 = defaultCodingConvention1.getExportSymbolFunction();
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node5 = node4.getParent();
        boolean boolean6 = node4.isQuotedString();
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship7 = defaultCodingConvention1.getDelegateRelationship(node4);
        com.google.javascript.jscomp.CodingConvention.SubclassRelationship subclassRelationship8 = defaultCodingConvention0.getClassesDefinedByCall(node4);
        try {
            int int10 = node4.getExistingIntProp(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: FAILED ASSERTION");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNull(node5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(delegateRelationship7);
        org.junit.Assert.assertNull(subclassRelationship8);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        com.google.javascript.jscomp.SourceFile.Generator generator1 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("", generator1);
        com.google.javascript.jscomp.CompilerInput compilerInput4 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2, true);
        com.google.javascript.jscomp.JSModule jSModule5 = null;
        compilerInput4.setModule(jSModule5);
        com.google.javascript.jscomp.SourceAst sourceAst7 = compilerInput4.getSourceAst();
        com.google.javascript.jscomp.SourceFile sourceFile8 = compilerInput4.getSourceFile();
        org.junit.Assert.assertNotNull(jSSourceFile2);
        org.junit.Assert.assertNotNull(sourceAst7);
        org.junit.Assert.assertNotNull(sourceFile8);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        com.google.javascript.jscomp.SourceFile sourceFile1 = com.google.javascript.jscomp.SourceFile.fromFile("");
        org.junit.Assert.assertNotNull(sourceFile1);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        com.google.javascript.jscomp.SourceFile.Generator generator1 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("", generator1);
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2);
        com.google.javascript.jscomp.SourceAst sourceAst4 = compilerInput3.getSourceAst();
        org.junit.Assert.assertNotNull(jSSourceFile2);
        org.junit.Assert.assertNotNull(sourceAst4);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CompilerOptions.TracerMode tracerMode1 = compilerOptions0.tracer;
        boolean boolean2 = compilerOptions0.smartNameRemoval;
        boolean boolean3 = compilerOptions0.printInputDelimiter;
        com.google.javascript.jscomp.SourceMap.Format format4 = com.google.javascript.jscomp.SourceMap.Format.EXPERIMENTIAL;
        compilerOptions0.sourceMapFormat = format4;
        org.junit.Assert.assertTrue("'" + tracerMode1 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TracerMode.OFF + "'", tracerMode1.equals(com.google.javascript.jscomp.CompilerOptions.TracerMode.OFF));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(format4);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newString("");
        int int2 = node1.getSideEffectFlags();
        boolean boolean3 = node1.isOptionalArg();
        com.google.javascript.rhino.Node node4 = node1.getLastSibling();
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.Node.newString("");
        int int8 = node7.getSideEffectFlags();
        boolean boolean9 = node7.isOptionalArg();
        com.google.javascript.rhino.Node node10 = node7.getLastSibling();
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString("");
        int int13 = node12.getSideEffectFlags();
        boolean boolean14 = node12.isOptionalArg();
        boolean boolean15 = node12.isQuotedString();
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newString("");
        int int18 = node17.getSideEffectFlags();
        java.util.Collection<com.google.javascript.rhino.Node> nodeCollection19 = com.google.javascript.jscomp.NodeUtil.getVarsDeclaredInBranch(node17);
        java.lang.String str20 = node17.getString();
        com.google.javascript.rhino.Node node21 = new com.google.javascript.rhino.Node((int) (byte) 10, node7, node12, node17);
        try {
            node1.addChildrenToFront(node12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNotNull(nodeCollection19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "" + "'", str20.equals(""));
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newString("");
        int int2 = node1.getSideEffectFlags();
        java.util.Collection<com.google.javascript.rhino.Node> nodeCollection3 = com.google.javascript.jscomp.NodeUtil.getVarsDeclaredInBranch(node1);
        com.google.javascript.rhino.Node node4 = node1.getLastSibling();
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(nodeCollection3);
        org.junit.Assert.assertNotNull(node4);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.SourceFile.Generator generator3 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile4 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("", generator3);
        com.google.javascript.jscomp.CompilerInput compilerInput5 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile4);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile7 = com.google.javascript.jscomp.JSSourceFile.fromFile("(STRING  [empty_block: 1])");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile9 = com.google.javascript.jscomp.JSSourceFile.fromFile("(STRING  [empty_block: 1])");
        com.google.javascript.jscomp.SourceFile.Generator generator11 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile12 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("", generator11);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile14 = com.google.javascript.jscomp.JSSourceFile.fromFile("(STRING  [empty_block: 1])");
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray15 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile4, jSSourceFile7, jSSourceFile9, jSSourceFile12, jSSourceFile14 };
        com.google.javascript.jscomp.JSModule[] jSModuleArray16 = new com.google.javascript.jscomp.JSModule[] {};
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph17 = new com.google.javascript.jscomp.JSModuleGraph(jSModuleArray16);
        com.google.javascript.jscomp.CompilerOptions compilerOptions18 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CompilerOptions.TracerMode tracerMode19 = compilerOptions18.tracer;
        compiler1.init(jSSourceFileArray15, jSModuleArray16, compilerOptions18);
        com.google.javascript.jscomp.JSError[] jSErrorArray21 = compiler1.getWarnings();
        com.google.javascript.jscomp.SourceFile.Generator generator23 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile24 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("", generator23);
        com.google.javascript.jscomp.CompilerInput compilerInput25 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile24);
        try {
            com.google.javascript.rhino.Node node26 = compiler1.parse(jSSourceFile24);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile4);
        org.junit.Assert.assertNotNull(jSSourceFile7);
        org.junit.Assert.assertNotNull(jSSourceFile9);
        org.junit.Assert.assertNotNull(jSSourceFile12);
        org.junit.Assert.assertNotNull(jSSourceFile14);
        org.junit.Assert.assertNotNull(jSSourceFileArray15);
        org.junit.Assert.assertNotNull(jSModuleArray16);
        org.junit.Assert.assertTrue("'" + tracerMode19 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TracerMode.OFF + "'", tracerMode19.equals(com.google.javascript.jscomp.CompilerOptions.TracerMode.OFF));
        org.junit.Assert.assertNotNull(jSErrorArray21);
        org.junit.Assert.assertNotNull(jSSourceFile24);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        com.google.javascript.rhino.EcmaError ecmaError2 = com.google.javascript.rhino.ScriptRuntime.constructError("100", "Not declared as a constructor");
        java.io.FilenameFilter filenameFilter3 = null;
        java.lang.String str4 = ecmaError2.getScriptStackTrace(filenameFilter3);
        java.lang.String str5 = ecmaError2.getSourceName();
        ecmaError2.initLineNumber(29);
        int int8 = ecmaError2.getColumnNumber();
        org.junit.Assert.assertNotNull(ecmaError2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "<No stack trace available>" + "'", str4.equals("<No stack trace available>"));
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention0 = new com.google.javascript.jscomp.DefaultCodingConvention();
        java.lang.String str1 = defaultCodingConvention0.getExportSymbolFunction();
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node4 = node3.getParent();
        boolean boolean5 = node3.isQuotedString();
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship6 = defaultCodingConvention0.getDelegateRelationship(node3);
        com.google.javascript.rhino.Node node10 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode((com.google.javascript.jscomp.CodingConvention) defaultCodingConvention0, "neg", 27, 40);
        boolean boolean12 = defaultCodingConvention0.isConstantKey("neg");
        java.lang.String str13 = defaultCodingConvention0.getAbstractMethodName();
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNull(node4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(delegateRelationship6);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNull(str13);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention1 = new com.google.javascript.jscomp.DefaultCodingConvention();
        java.lang.String str2 = defaultCodingConvention1.getExportSymbolFunction();
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node5 = node4.getParent();
        boolean boolean6 = node4.isQuotedString();
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship7 = defaultCodingConvention1.getDelegateRelationship(node4);
        com.google.javascript.rhino.Node node8 = node4.getParent();
        com.google.javascript.rhino.Node node9 = null;
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node12 = node11.getParent();
        boolean boolean13 = node11.hasChildren();
        node11.detachChildren();
        com.google.javascript.rhino.Node node15 = node11.cloneTree();
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention17 = new com.google.javascript.jscomp.DefaultCodingConvention();
        java.lang.String str18 = defaultCodingConvention17.getExportSymbolFunction();
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node21 = node20.getParent();
        boolean boolean22 = node20.isQuotedString();
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship23 = defaultCodingConvention17.getDelegateRelationship(node20);
        com.google.javascript.rhino.Node node24 = com.google.javascript.jscomp.NodeUtil.newExpr(node20);
        com.google.javascript.rhino.Node node26 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node27 = node26.getParent();
        boolean boolean28 = node26.isQuotedString();
        com.google.javascript.rhino.Node node31 = new com.google.javascript.rhino.Node(4, node24, node26, 35, 0);
        com.google.javascript.rhino.Node node34 = com.google.javascript.rhino.Node.newString("");
        int int35 = node34.getSideEffectFlags();
        boolean boolean36 = node34.isOptionalArg();
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention37 = new com.google.javascript.jscomp.DefaultCodingConvention();
        java.lang.String str38 = defaultCodingConvention37.getExportSymbolFunction();
        com.google.javascript.rhino.Node node40 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node41 = node40.getParent();
        boolean boolean42 = node40.isQuotedString();
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship43 = defaultCodingConvention37.getDelegateRelationship(node40);
        com.google.javascript.rhino.Node node44 = com.google.javascript.jscomp.NodeUtil.newExpr(node40);
        com.google.javascript.rhino.Node node47 = new com.google.javascript.rhino.Node((int) (short) 0, node34, node44, (int) (byte) 1, 0);
        com.google.javascript.rhino.Node node48 = node24.clonePropsFrom(node44);
        node48.putIntProp(27, 48);
        try {
            com.google.javascript.rhino.Node node52 = new com.google.javascript.rhino.Node(15, node8, node9, node15, node48);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNull(node5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(delegateRelationship7);
        org.junit.Assert.assertNull(node8);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertNull(node12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertNull(str18);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNull(node21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNull(delegateRelationship23);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertNull(node27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(node34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNull(str38);
        org.junit.Assert.assertNotNull(node40);
        org.junit.Assert.assertNull(node41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNull(delegateRelationship43);
        org.junit.Assert.assertNotNull(node44);
        org.junit.Assert.assertNotNull(node48);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        int int0 = com.google.javascript.rhino.Context.FEATURE_E4X;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 6 + "'", int0 == 6);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node2 = node1.getParent();
        boolean boolean3 = node1.hasChildren();
        node1.detachChildren();
        node1.setWasEmptyNode(true);
        java.lang.String str7 = node1.toStringTree();
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertNull(node2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "STRING  [empty_block: 1]\n" + "'", str7.equals("STRING  [empty_block: 1]\n"));
    }

//    @Test
//    public void test476() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test476");
//        com.google.javascript.rhino.Context context0 = null;
//        com.google.javascript.rhino.Context context1 = com.google.javascript.rhino.Context.enter(context0);
//        java.util.Locale locale2 = context1.getLocale();
//        boolean boolean3 = context1.isGeneratingDebug();
//        context1.removeActivationName("neg");
//        boolean boolean6 = context1.isSealed();
//        org.junit.Assert.assertNotNull(context1);
//        org.junit.Assert.assertNotNull(locale2);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.SourceFile.Generator generator3 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile4 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("", generator3);
        com.google.javascript.jscomp.CompilerInput compilerInput5 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile4);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile7 = com.google.javascript.jscomp.JSSourceFile.fromFile("(STRING  [empty_block: 1])");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile9 = com.google.javascript.jscomp.JSSourceFile.fromFile("(STRING  [empty_block: 1])");
        com.google.javascript.jscomp.SourceFile.Generator generator11 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile12 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("", generator11);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile14 = com.google.javascript.jscomp.JSSourceFile.fromFile("(STRING  [empty_block: 1])");
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray15 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile4, jSSourceFile7, jSSourceFile9, jSSourceFile12, jSSourceFile14 };
        com.google.javascript.jscomp.JSModule[] jSModuleArray16 = new com.google.javascript.jscomp.JSModule[] {};
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph17 = new com.google.javascript.jscomp.JSModuleGraph(jSModuleArray16);
        com.google.javascript.jscomp.CompilerOptions compilerOptions18 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CompilerOptions.TracerMode tracerMode19 = compilerOptions18.tracer;
        compiler1.init(jSSourceFileArray15, jSModuleArray16, compilerOptions18);
        compilerOptions18.setGenerateExports(true);
        compilerOptions18.checkControlStructures = false;
        compilerOptions18.removeEmptyFunctions = false;
        compilerOptions18.checkEs5Strict = false;
        org.junit.Assert.assertNotNull(jSSourceFile4);
        org.junit.Assert.assertNotNull(jSSourceFile7);
        org.junit.Assert.assertNotNull(jSSourceFile9);
        org.junit.Assert.assertNotNull(jSSourceFile12);
        org.junit.Assert.assertNotNull(jSSourceFile14);
        org.junit.Assert.assertNotNull(jSSourceFileArray15);
        org.junit.Assert.assertNotNull(jSModuleArray16);
        org.junit.Assert.assertTrue("'" + tracerMode19 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TracerMode.OFF + "'", tracerMode19.equals(com.google.javascript.jscomp.CompilerOptions.TracerMode.OFF));
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention1 = new com.google.javascript.jscomp.DefaultCodingConvention();
        java.lang.String str2 = defaultCodingConvention1.getExportSymbolFunction();
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node5 = node4.getParent();
        boolean boolean6 = node4.isQuotedString();
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship7 = defaultCodingConvention1.getDelegateRelationship(node4);
        com.google.javascript.rhino.Node node8 = com.google.javascript.jscomp.NodeUtil.newExpr(node4);
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node11 = node10.getParent();
        boolean boolean12 = node10.isQuotedString();
        com.google.javascript.rhino.Node node15 = new com.google.javascript.rhino.Node(4, node8, node10, 35, 0);
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.Node.newString("");
        int int19 = node18.getSideEffectFlags();
        boolean boolean20 = node18.isOptionalArg();
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention21 = new com.google.javascript.jscomp.DefaultCodingConvention();
        java.lang.String str22 = defaultCodingConvention21.getExportSymbolFunction();
        com.google.javascript.rhino.Node node24 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node25 = node24.getParent();
        boolean boolean26 = node24.isQuotedString();
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship27 = defaultCodingConvention21.getDelegateRelationship(node24);
        com.google.javascript.rhino.Node node28 = com.google.javascript.jscomp.NodeUtil.newExpr(node24);
        com.google.javascript.rhino.Node node31 = new com.google.javascript.rhino.Node((int) (short) 0, node18, node28, (int) (byte) 1, 0);
        com.google.javascript.rhino.Node node32 = node8.clonePropsFrom(node28);
        boolean boolean33 = node8.hasOneChild();
        boolean boolean34 = node8.isQuotedString();
        com.google.javascript.rhino.Node node37 = com.google.javascript.rhino.Node.newString("");
        int int38 = node37.getSideEffectFlags();
        boolean boolean39 = node37.isOptionalArg();
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention40 = new com.google.javascript.jscomp.DefaultCodingConvention();
        java.lang.String str41 = defaultCodingConvention40.getExportSymbolFunction();
        com.google.javascript.rhino.Node node43 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node44 = node43.getParent();
        boolean boolean45 = node43.isQuotedString();
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship46 = defaultCodingConvention40.getDelegateRelationship(node43);
        com.google.javascript.rhino.Node node47 = com.google.javascript.jscomp.NodeUtil.newExpr(node43);
        com.google.javascript.rhino.Node node50 = new com.google.javascript.rhino.Node((int) (short) 0, node37, node47, (int) (byte) 1, 0);
        boolean boolean51 = node50.hasMoreThanOneChild();
        node8.addChildrenToBack(node50);
        com.google.javascript.rhino.Node.SideEffectFlags sideEffectFlags54 = new com.google.javascript.rhino.Node.SideEffectFlags((int) ' ');
        sideEffectFlags54.setMutatesThis();
        sideEffectFlags54.clearSideEffectFlags();
        try {
            node50.setSideEffectFlags(sideEffectFlags54);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: setIsNoSideEffectsCall only supports CALL and NEW nodes, got EOF");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNull(node5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(delegateRelationship7);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNull(node11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNull(str22);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertNull(node25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNull(delegateRelationship27);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertNotNull(node32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(node37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 0 + "'", int38 == 0);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNull(str41);
        org.junit.Assert.assertNotNull(node43);
        org.junit.Assert.assertNull(node44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNull(delegateRelationship46);
        org.junit.Assert.assertNotNull(node47);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + true + "'", boolean51 == true);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        java.util.logging.Logger logger0 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager1 = new com.google.javascript.jscomp.LoggerErrorManager(logger0);
        com.google.javascript.jscomp.JSError[] jSErrorArray2 = loggerErrorManager1.getWarnings();
        org.junit.Assert.assertNotNull(jSErrorArray2);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy0 = com.google.javascript.jscomp.VariableRenamingPolicy.OFF;
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy0 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.OFF + "'", variableRenamingPolicy0.equals(com.google.javascript.jscomp.VariableRenamingPolicy.OFF));
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.Node.newString("");
        int int3 = node2.getSideEffectFlags();
        boolean boolean4 = node2.isOptionalArg();
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention5 = new com.google.javascript.jscomp.DefaultCodingConvention();
        java.lang.String str6 = defaultCodingConvention5.getExportSymbolFunction();
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node9 = node8.getParent();
        boolean boolean10 = node8.isQuotedString();
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship11 = defaultCodingConvention5.getDelegateRelationship(node8);
        com.google.javascript.rhino.Node node12 = com.google.javascript.jscomp.NodeUtil.newExpr(node8);
        com.google.javascript.rhino.Node node15 = new com.google.javascript.rhino.Node((int) (short) 0, node2, node12, (int) (byte) 1, 0);
        java.lang.String str16 = node15.getQualifiedName();
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder17 = node15.getJsDocBuilderForNode();
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNull(node9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNull(delegateRelationship11);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder17);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.SourceFile.Generator generator3 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile4 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("", generator3);
        com.google.javascript.jscomp.CompilerInput compilerInput5 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile4);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile7 = com.google.javascript.jscomp.JSSourceFile.fromFile("(STRING  [empty_block: 1])");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile9 = com.google.javascript.jscomp.JSSourceFile.fromFile("(STRING  [empty_block: 1])");
        com.google.javascript.jscomp.SourceFile.Generator generator11 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile12 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("", generator11);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile14 = com.google.javascript.jscomp.JSSourceFile.fromFile("(STRING  [empty_block: 1])");
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray15 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile4, jSSourceFile7, jSSourceFile9, jSSourceFile12, jSSourceFile14 };
        com.google.javascript.jscomp.JSModule[] jSModuleArray16 = new com.google.javascript.jscomp.JSModule[] {};
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph17 = new com.google.javascript.jscomp.JSModuleGraph(jSModuleArray16);
        com.google.javascript.jscomp.CompilerOptions compilerOptions18 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CompilerOptions.TracerMode tracerMode19 = compilerOptions18.tracer;
        compiler1.init(jSSourceFileArray15, jSModuleArray16, compilerOptions18);
        compilerOptions18.setGenerateExports(true);
        compilerOptions18.jsOutputFile = "21";
        compilerOptions18.removeUnusedPrototypeProperties = false;
        byte[] byteArray27 = compilerOptions18.inputVariableMapSerialized;
        compilerOptions18.setAcceptConstKeyword(false);
        java.lang.String str30 = compilerOptions18.jsOutputFile;
        compilerOptions18.closurePass = false;
        java.lang.String[] strArray41 = new java.lang.String[] { "STRING  [empty_block: 1]\n", "neg", "window", "neg", "neg", "21", "100: language version" };
        java.util.ArrayList<java.lang.String> strList42 = new java.util.ArrayList<java.lang.String>();
        boolean boolean43 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strList42, strArray41);
        compilerOptions18.setReplaceStringsConfiguration("com.google.javascript.rhino.EcmaError: 100: Not declared as a constructor", (java.util.List<java.lang.String>) strList42);
        org.junit.Assert.assertNotNull(jSSourceFile4);
        org.junit.Assert.assertNotNull(jSSourceFile7);
        org.junit.Assert.assertNotNull(jSSourceFile9);
        org.junit.Assert.assertNotNull(jSSourceFile12);
        org.junit.Assert.assertNotNull(jSSourceFile14);
        org.junit.Assert.assertNotNull(jSSourceFileArray15);
        org.junit.Assert.assertNotNull(jSModuleArray16);
        org.junit.Assert.assertTrue("'" + tracerMode19 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TracerMode.OFF + "'", tracerMode19.equals(com.google.javascript.jscomp.CompilerOptions.TracerMode.OFF));
        org.junit.Assert.assertNull(byteArray27);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "21" + "'", str30.equals("21"));
        org.junit.Assert.assertNotNull(strArray41);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.SourceFile.Generator generator3 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile4 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("", generator3);
        com.google.javascript.jscomp.CompilerInput compilerInput5 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile4);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile7 = com.google.javascript.jscomp.JSSourceFile.fromFile("(STRING  [empty_block: 1])");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile9 = com.google.javascript.jscomp.JSSourceFile.fromFile("(STRING  [empty_block: 1])");
        com.google.javascript.jscomp.SourceFile.Generator generator11 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile12 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("", generator11);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile14 = com.google.javascript.jscomp.JSSourceFile.fromFile("(STRING  [empty_block: 1])");
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray15 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile4, jSSourceFile7, jSSourceFile9, jSSourceFile12, jSSourceFile14 };
        com.google.javascript.jscomp.JSModule[] jSModuleArray16 = new com.google.javascript.jscomp.JSModule[] {};
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph17 = new com.google.javascript.jscomp.JSModuleGraph(jSModuleArray16);
        com.google.javascript.jscomp.CompilerOptions compilerOptions18 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CompilerOptions.TracerMode tracerMode19 = compilerOptions18.tracer;
        compiler1.init(jSSourceFileArray15, jSModuleArray16, compilerOptions18);
        compilerOptions18.setGenerateExports(true);
        compilerOptions18.jsOutputFile = "21";
        compilerOptions18.removeUnusedPrototypeProperties = false;
        byte[] byteArray27 = compilerOptions18.inputVariableMapSerialized;
        compilerOptions18.setAcceptConstKeyword(false);
        java.lang.String str30 = compilerOptions18.jsOutputFile;
        compilerOptions18.closurePass = false;
        java.lang.String str33 = compilerOptions18.aliasStringsBlacklist;
        org.junit.Assert.assertNotNull(jSSourceFile4);
        org.junit.Assert.assertNotNull(jSSourceFile7);
        org.junit.Assert.assertNotNull(jSSourceFile9);
        org.junit.Assert.assertNotNull(jSSourceFile12);
        org.junit.Assert.assertNotNull(jSSourceFile14);
        org.junit.Assert.assertNotNull(jSSourceFileArray15);
        org.junit.Assert.assertNotNull(jSModuleArray16);
        org.junit.Assert.assertTrue("'" + tracerMode19 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TracerMode.OFF + "'", tracerMode19.equals(com.google.javascript.jscomp.CompilerOptions.TracerMode.OFF));
        org.junit.Assert.assertNull(byteArray27);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "21" + "'", str30.equals("21"));
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "" + "'", str33.equals(""));
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CompilerOptions.TracerMode tracerMode1 = compilerOptions0.tracer;
        boolean boolean2 = compilerOptions0.smartNameRemoval;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy3 = compilerOptions0.variableRenaming;
        compilerOptions0.decomposeExpressions = false;
        compilerOptions0.foldConstants = true;
        org.junit.Assert.assertTrue("'" + tracerMode1 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TracerMode.OFF + "'", tracerMode1.equals(com.google.javascript.jscomp.CompilerOptions.TracerMode.OFF));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy3 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.OFF + "'", variableRenamingPolicy3.equals(com.google.javascript.jscomp.VariableRenamingPolicy.OFF));
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node node1 = compiler0.getRoot();
        com.google.javascript.jscomp.Compiler compiler2 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.Compiler.IntermediateState intermediateState3 = compiler2.getState();
        compiler0.setState(intermediateState3);
        com.google.javascript.jscomp.SourceFile.Generator generator6 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile7 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("Not declared as a constructor", generator6);
        com.google.javascript.jscomp.SourceFile.Generator generator9 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile10 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("Not declared as a constructor", generator9);
        java.io.PrintStream printStream11 = null;
        com.google.javascript.jscomp.Compiler compiler12 = new com.google.javascript.jscomp.Compiler(printStream11);
        com.google.javascript.jscomp.SourceFile.Generator generator14 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile15 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("", generator14);
        com.google.javascript.jscomp.CompilerInput compilerInput16 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile15);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile18 = com.google.javascript.jscomp.JSSourceFile.fromFile("(STRING  [empty_block: 1])");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile20 = com.google.javascript.jscomp.JSSourceFile.fromFile("(STRING  [empty_block: 1])");
        com.google.javascript.jscomp.SourceFile.Generator generator22 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile23 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("", generator22);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile25 = com.google.javascript.jscomp.JSSourceFile.fromFile("(STRING  [empty_block: 1])");
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray26 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile15, jSSourceFile18, jSSourceFile20, jSSourceFile23, jSSourceFile25 };
        com.google.javascript.jscomp.JSModule[] jSModuleArray27 = new com.google.javascript.jscomp.JSModule[] {};
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph28 = new com.google.javascript.jscomp.JSModuleGraph(jSModuleArray27);
        com.google.javascript.jscomp.CompilerOptions compilerOptions29 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CompilerOptions.TracerMode tracerMode30 = compilerOptions29.tracer;
        compiler12.init(jSSourceFileArray26, jSModuleArray27, compilerOptions29);
        com.google.javascript.jscomp.SourceFile.Generator generator33 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile34 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("", generator33);
        com.google.javascript.jscomp.CompilerInput compilerInput36 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile34, true);
        com.google.javascript.jscomp.SourceFile.Generator generator38 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile39 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("Not declared as a constructor", generator38);
        com.google.javascript.jscomp.SourceFile.Generator generator41 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile42 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("", generator41);
        com.google.javascript.jscomp.CompilerInput compilerInput43 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile42);
        com.google.javascript.jscomp.SourceFile.Generator generator45 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile46 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("", generator45);
        com.google.javascript.jscomp.CompilerInput compilerInput48 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile46, true);
        com.google.javascript.jscomp.SourceFile.Generator generator50 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile51 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("", generator50);
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray52 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile39, jSSourceFile42, jSSourceFile46, jSSourceFile51 };
        com.google.javascript.jscomp.CompilerOptions compilerOptions53 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention54 = new com.google.javascript.jscomp.DefaultCodingConvention();
        boolean boolean56 = defaultCodingConvention54.isExported("window");
        compilerOptions53.setCodingConvention((com.google.javascript.jscomp.CodingConvention) defaultCodingConvention54);
        com.google.javascript.jscomp.Result result58 = compiler12.compile(jSSourceFile34, jSSourceFileArray52, compilerOptions53);
        java.nio.charset.Charset charset60 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile61 = com.google.javascript.jscomp.JSSourceFile.fromFile("error reporter", charset60);
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray62 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile7, jSSourceFile10, jSSourceFile34, jSSourceFile61 };
        com.google.javascript.jscomp.JSModule[] jSModuleArray63 = new com.google.javascript.jscomp.JSModule[] {};
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph64 = new com.google.javascript.jscomp.JSModuleGraph(jSModuleArray63);
        com.google.javascript.jscomp.CompilerOptions compilerOptions65 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention66 = new com.google.javascript.jscomp.DefaultCodingConvention();
        boolean boolean68 = defaultCodingConvention66.isExported("window");
        compilerOptions65.setCodingConvention((com.google.javascript.jscomp.CodingConvention) defaultCodingConvention66);
        java.lang.Object obj70 = compilerOptions65.clone();
        compilerOptions65.strictMessageReplacement = false;
        compilerOptions65.enableRuntimeTypeCheck("");
        compiler0.init(jSSourceFileArray62, jSModuleArray63, compilerOptions65);
        boolean boolean76 = compilerOptions65.inlineAnonymousFunctionExpressions;
        boolean boolean77 = compilerOptions65.removeDeadCode;
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy78 = com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC;
        compilerOptions65.propertyRenaming = propertyRenamingPolicy78;
        org.junit.Assert.assertNull(node1);
        org.junit.Assert.assertNotNull(intermediateState3);
        org.junit.Assert.assertNotNull(jSSourceFile7);
        org.junit.Assert.assertNotNull(jSSourceFile10);
        org.junit.Assert.assertNotNull(jSSourceFile15);
        org.junit.Assert.assertNotNull(jSSourceFile18);
        org.junit.Assert.assertNotNull(jSSourceFile20);
        org.junit.Assert.assertNotNull(jSSourceFile23);
        org.junit.Assert.assertNotNull(jSSourceFile25);
        org.junit.Assert.assertNotNull(jSSourceFileArray26);
        org.junit.Assert.assertNotNull(jSModuleArray27);
        org.junit.Assert.assertTrue("'" + tracerMode30 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TracerMode.OFF + "'", tracerMode30.equals(com.google.javascript.jscomp.CompilerOptions.TracerMode.OFF));
        org.junit.Assert.assertNotNull(jSSourceFile34);
        org.junit.Assert.assertNotNull(jSSourceFile39);
        org.junit.Assert.assertNotNull(jSSourceFile42);
        org.junit.Assert.assertNotNull(jSSourceFile46);
        org.junit.Assert.assertNotNull(jSSourceFile51);
        org.junit.Assert.assertNotNull(jSSourceFileArray52);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertNotNull(result58);
        org.junit.Assert.assertNotNull(jSSourceFile61);
        org.junit.Assert.assertNotNull(jSSourceFileArray62);
        org.junit.Assert.assertNotNull(jSModuleArray63);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertNotNull(obj70);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy78 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC + "'", propertyRenamingPolicy78.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC));
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention1 = new com.google.javascript.jscomp.DefaultCodingConvention();
        boolean boolean3 = defaultCodingConvention1.isExported("window");
        compilerOptions0.setCodingConvention((com.google.javascript.jscomp.CodingConvention) defaultCodingConvention1);
        java.lang.Object obj5 = compilerOptions0.clone();
        compilerOptions0.nameReferenceReportPath = "21";
        java.io.PrintStream printStream8 = null;
        com.google.javascript.jscomp.Compiler compiler9 = new com.google.javascript.jscomp.Compiler(printStream8);
        com.google.javascript.jscomp.SourceFile.Generator generator11 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile12 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("", generator11);
        com.google.javascript.jscomp.CompilerInput compilerInput13 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile12);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile15 = com.google.javascript.jscomp.JSSourceFile.fromFile("(STRING  [empty_block: 1])");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile17 = com.google.javascript.jscomp.JSSourceFile.fromFile("(STRING  [empty_block: 1])");
        com.google.javascript.jscomp.SourceFile.Generator generator19 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile20 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("", generator19);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile22 = com.google.javascript.jscomp.JSSourceFile.fromFile("(STRING  [empty_block: 1])");
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray23 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile12, jSSourceFile15, jSSourceFile17, jSSourceFile20, jSSourceFile22 };
        com.google.javascript.jscomp.JSModule[] jSModuleArray24 = new com.google.javascript.jscomp.JSModule[] {};
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph25 = new com.google.javascript.jscomp.JSModuleGraph(jSModuleArray24);
        com.google.javascript.jscomp.CompilerOptions compilerOptions26 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CompilerOptions.TracerMode tracerMode27 = compilerOptions26.tracer;
        compiler9.init(jSSourceFileArray23, jSModuleArray24, compilerOptions26);
        compilerOptions26.checkEs5Strict = false;
        compilerOptions26.flowSensitiveInlineVariables = false;
        compilerOptions26.removeTryCatchFinally = true;
        compilerOptions26.setCollapsePropertiesOnExternTypes(true);
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy37 = com.google.javascript.jscomp.VariableRenamingPolicy.LOCAL;
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy38 = com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC;
        compilerOptions26.setRenamingPolicy(variableRenamingPolicy37, propertyRenamingPolicy38);
        java.io.PrintStream printStream40 = null;
        com.google.javascript.jscomp.Compiler compiler41 = new com.google.javascript.jscomp.Compiler(printStream40);
        com.google.javascript.jscomp.SourceFile.Generator generator43 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile44 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("", generator43);
        com.google.javascript.jscomp.CompilerInput compilerInput45 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile44);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile47 = com.google.javascript.jscomp.JSSourceFile.fromFile("(STRING  [empty_block: 1])");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile49 = com.google.javascript.jscomp.JSSourceFile.fromFile("(STRING  [empty_block: 1])");
        com.google.javascript.jscomp.SourceFile.Generator generator51 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile52 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("", generator51);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile54 = com.google.javascript.jscomp.JSSourceFile.fromFile("(STRING  [empty_block: 1])");
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray55 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile44, jSSourceFile47, jSSourceFile49, jSSourceFile52, jSSourceFile54 };
        com.google.javascript.jscomp.JSModule[] jSModuleArray56 = new com.google.javascript.jscomp.JSModule[] {};
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph57 = new com.google.javascript.jscomp.JSModuleGraph(jSModuleArray56);
        com.google.javascript.jscomp.CompilerOptions compilerOptions58 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CompilerOptions.TracerMode tracerMode59 = compilerOptions58.tracer;
        compiler41.init(jSSourceFileArray55, jSModuleArray56, compilerOptions58);
        compilerOptions58.checkEs5Strict = false;
        compilerOptions58.flowSensitiveInlineVariables = false;
        compilerOptions58.removeTryCatchFinally = true;
        compilerOptions58.setCollapsePropertiesOnExternTypes(true);
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy69 = com.google.javascript.jscomp.VariableRenamingPolicy.LOCAL;
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy70 = com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC;
        compilerOptions58.setRenamingPolicy(variableRenamingPolicy69, propertyRenamingPolicy70);
        compilerOptions0.setRenamingPolicy(variableRenamingPolicy37, propertyRenamingPolicy70);
        compilerOptions0.checkSuspiciousCode = true;
        compilerOptions0.disableRuntimeTypeCheck();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertNotNull(jSSourceFile12);
        org.junit.Assert.assertNotNull(jSSourceFile15);
        org.junit.Assert.assertNotNull(jSSourceFile17);
        org.junit.Assert.assertNotNull(jSSourceFile20);
        org.junit.Assert.assertNotNull(jSSourceFile22);
        org.junit.Assert.assertNotNull(jSSourceFileArray23);
        org.junit.Assert.assertNotNull(jSModuleArray24);
        org.junit.Assert.assertTrue("'" + tracerMode27 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TracerMode.OFF + "'", tracerMode27.equals(com.google.javascript.jscomp.CompilerOptions.TracerMode.OFF));
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy37 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.LOCAL + "'", variableRenamingPolicy37.equals(com.google.javascript.jscomp.VariableRenamingPolicy.LOCAL));
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy38 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC + "'", propertyRenamingPolicy38.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC));
        org.junit.Assert.assertNotNull(jSSourceFile44);
        org.junit.Assert.assertNotNull(jSSourceFile47);
        org.junit.Assert.assertNotNull(jSSourceFile49);
        org.junit.Assert.assertNotNull(jSSourceFile52);
        org.junit.Assert.assertNotNull(jSSourceFile54);
        org.junit.Assert.assertNotNull(jSSourceFileArray55);
        org.junit.Assert.assertNotNull(jSModuleArray56);
        org.junit.Assert.assertTrue("'" + tracerMode59 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TracerMode.OFF + "'", tracerMode59.equals(com.google.javascript.jscomp.CompilerOptions.TracerMode.OFF));
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy69 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.LOCAL + "'", variableRenamingPolicy69.equals(com.google.javascript.jscomp.VariableRenamingPolicy.LOCAL));
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy70 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC + "'", propertyRenamingPolicy70.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC));
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        com.google.javascript.rhino.EcmaError ecmaError2 = com.google.javascript.rhino.ScriptRuntime.constructError("100", "Not declared as a constructor");
        java.lang.String str3 = ecmaError2.getErrorMessage();
        ecmaError2.initColumnNumber(29);
        java.lang.String str6 = ecmaError2.getSourceName();
        java.lang.String str7 = ecmaError2.getSourceName();
        java.lang.String str8 = ecmaError2.getErrorMessage();
        org.junit.Assert.assertNotNull(ecmaError2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Not declared as a constructor" + "'", str3.equals("Not declared as a constructor"));
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Not declared as a constructor" + "'", str8.equals("Not declared as a constructor"));
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention0 = new com.google.javascript.jscomp.DefaultCodingConvention();
        java.lang.String str1 = defaultCodingConvention0.getGlobalObject();
        boolean boolean3 = defaultCodingConvention0.isExported("hi!");
        java.lang.String str4 = defaultCodingConvention0.getAbstractMethodName();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "window" + "'", str1.equals("window"));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.TYPE_INVALIDATION;
        com.google.javascript.jscomp.DiagnosticGroups.CHECK_VARIABLES = diagnosticGroup0;
        java.lang.String str2 = diagnosticGroup0.toString();
        org.junit.Assert.assertNotNull(diagnosticGroup0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "DiagnosticGroup<typeInvalidation>" + "'", str2.equals("DiagnosticGroup<typeInvalidation>"));
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention1 = new com.google.javascript.jscomp.DefaultCodingConvention();
        boolean boolean3 = defaultCodingConvention1.isExported("window");
        compilerOptions0.setCodingConvention((com.google.javascript.jscomp.CodingConvention) defaultCodingConvention1);
        java.lang.String str5 = compilerOptions0.renamePrefix;
        java.util.Set<java.lang.String> strSet6 = compilerOptions0.stripNameSuffixes;
        boolean boolean7 = compilerOptions0.removeUnusedLocalVars;
        compilerOptions0.instrumentationTemplate = "16";
        com.google.javascript.jscomp.CheckLevel checkLevel11 = com.google.javascript.jscomp.CheckLevel.ERROR;
        com.google.javascript.jscomp.DiagnosticType diagnosticType13 = com.google.javascript.jscomp.DiagnosticType.make("@IMPLEMENTATION.VERSION@", checkLevel11, "error reporter");
        compilerOptions0.checkUndefinedProperties = checkLevel11;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertNotNull(strSet6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + checkLevel11 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel11.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticType13);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        com.google.javascript.rhino.Node node4 = new com.google.javascript.rhino.Node(48, (int) (byte) 1, 45);
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention6 = new com.google.javascript.jscomp.DefaultCodingConvention();
        java.lang.String str7 = defaultCodingConvention6.getExportSymbolFunction();
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node10 = node9.getParent();
        boolean boolean11 = node9.isQuotedString();
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship12 = defaultCodingConvention6.getDelegateRelationship(node9);
        com.google.javascript.rhino.Node node13 = com.google.javascript.jscomp.NodeUtil.newExpr(node9);
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node16 = node15.getParent();
        boolean boolean17 = node15.isQuotedString();
        com.google.javascript.rhino.Node node20 = new com.google.javascript.rhino.Node(4, node13, node15, 35, 0);
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newString("");
        int int24 = node23.getSideEffectFlags();
        boolean boolean25 = node23.isOptionalArg();
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention26 = new com.google.javascript.jscomp.DefaultCodingConvention();
        java.lang.String str27 = defaultCodingConvention26.getExportSymbolFunction();
        com.google.javascript.rhino.Node node29 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node30 = node29.getParent();
        boolean boolean31 = node29.isQuotedString();
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship32 = defaultCodingConvention26.getDelegateRelationship(node29);
        com.google.javascript.rhino.Node node33 = com.google.javascript.jscomp.NodeUtil.newExpr(node29);
        com.google.javascript.rhino.Node node36 = new com.google.javascript.rhino.Node((int) (short) 0, node23, node33, (int) (byte) 1, 0);
        com.google.javascript.rhino.Node node37 = node13.clonePropsFrom(node33);
        boolean boolean38 = node13.hasOneChild();
        try {
            com.google.javascript.rhino.Node node41 = new com.google.javascript.rhino.Node(4095, node4, node13, 10, 48);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: second new child has existing parent");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNull(node10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNull(delegateRelationship12);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertNull(node16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNull(str27);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNull(node30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNull(delegateRelationship32);
        org.junit.Assert.assertNotNull(node33);
        org.junit.Assert.assertNotNull(node37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention0 = new com.google.javascript.jscomp.DefaultCodingConvention();
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention1 = new com.google.javascript.jscomp.DefaultCodingConvention();
        java.lang.String str2 = defaultCodingConvention1.getExportSymbolFunction();
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node5 = node4.getParent();
        boolean boolean6 = node4.isQuotedString();
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship7 = defaultCodingConvention1.getDelegateRelationship(node4);
        com.google.javascript.jscomp.CodingConvention.SubclassRelationship subclassRelationship8 = defaultCodingConvention0.getClassesDefinedByCall(node4);
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention10 = new com.google.javascript.jscomp.DefaultCodingConvention();
        java.lang.String str11 = defaultCodingConvention10.getExportSymbolFunction();
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node14 = node13.getParent();
        boolean boolean15 = node13.isQuotedString();
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship16 = defaultCodingConvention10.getDelegateRelationship(node13);
        com.google.javascript.rhino.Node node17 = com.google.javascript.jscomp.NodeUtil.newExpr(node13);
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node20 = node19.getParent();
        boolean boolean21 = node19.isQuotedString();
        com.google.javascript.rhino.Node node24 = new com.google.javascript.rhino.Node(4, node17, node19, 35, 0);
        java.lang.String str25 = defaultCodingConvention0.getSingletonGetterClassName(node19);
        com.google.javascript.rhino.Node node26 = node19.getFirstChild();
        java.util.Set<java.lang.String> strSet27 = null;
        try {
            node26.setDirectives(strSet27);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNull(node5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(delegateRelationship7);
        org.junit.Assert.assertNull(subclassRelationship8);
        org.junit.Assert.assertNull(str11);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNull(node14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNull(delegateRelationship16);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNull(node20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNull(str25);
        org.junit.Assert.assertNull(node26);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CompilerOptions.TracerMode tracerMode1 = compilerOptions0.tracer;
        boolean boolean2 = compilerOptions0.smartNameRemoval;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy3 = compilerOptions0.variableRenaming;
        compilerOptions0.decomposeExpressions = false;
        boolean boolean6 = compilerOptions0.devirtualizePrototypeMethods;
        boolean boolean7 = compilerOptions0.removeDeadCode;
        org.junit.Assert.assertTrue("'" + tracerMode1 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TracerMode.OFF + "'", tracerMode1.equals(com.google.javascript.jscomp.CompilerOptions.TracerMode.OFF));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy3 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.OFF + "'", variableRenamingPolicy3.equals(com.google.javascript.jscomp.VariableRenamingPolicy.OFF));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.SourceFile.Generator generator3 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile4 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("", generator3);
        com.google.javascript.jscomp.CompilerInput compilerInput5 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile4);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile7 = com.google.javascript.jscomp.JSSourceFile.fromFile("(STRING  [empty_block: 1])");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile9 = com.google.javascript.jscomp.JSSourceFile.fromFile("(STRING  [empty_block: 1])");
        com.google.javascript.jscomp.SourceFile.Generator generator11 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile12 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("", generator11);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile14 = com.google.javascript.jscomp.JSSourceFile.fromFile("(STRING  [empty_block: 1])");
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray15 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile4, jSSourceFile7, jSSourceFile9, jSSourceFile12, jSSourceFile14 };
        com.google.javascript.jscomp.JSModule[] jSModuleArray16 = new com.google.javascript.jscomp.JSModule[] {};
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph17 = new com.google.javascript.jscomp.JSModuleGraph(jSModuleArray16);
        com.google.javascript.jscomp.CompilerOptions compilerOptions18 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CompilerOptions.TracerMode tracerMode19 = compilerOptions18.tracer;
        compiler1.init(jSSourceFileArray15, jSModuleArray16, compilerOptions18);
        compilerOptions18.setGenerateExports(true);
        compilerOptions18.jsOutputFile = "21";
        compilerOptions18.removeUnusedPrototypeProperties = false;
        byte[] byteArray27 = compilerOptions18.inputVariableMapSerialized;
        java.io.PrintStream printStream28 = null;
        com.google.javascript.jscomp.Compiler compiler29 = new com.google.javascript.jscomp.Compiler(printStream28);
        com.google.javascript.jscomp.SourceFile.Generator generator31 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile32 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("", generator31);
        com.google.javascript.jscomp.CompilerInput compilerInput33 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile32);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile35 = com.google.javascript.jscomp.JSSourceFile.fromFile("(STRING  [empty_block: 1])");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile37 = com.google.javascript.jscomp.JSSourceFile.fromFile("(STRING  [empty_block: 1])");
        com.google.javascript.jscomp.SourceFile.Generator generator39 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile40 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("", generator39);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile42 = com.google.javascript.jscomp.JSSourceFile.fromFile("(STRING  [empty_block: 1])");
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray43 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile32, jSSourceFile35, jSSourceFile37, jSSourceFile40, jSSourceFile42 };
        com.google.javascript.jscomp.JSModule[] jSModuleArray44 = new com.google.javascript.jscomp.JSModule[] {};
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph45 = new com.google.javascript.jscomp.JSModuleGraph(jSModuleArray44);
        com.google.javascript.jscomp.CompilerOptions compilerOptions46 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CompilerOptions.TracerMode tracerMode47 = compilerOptions46.tracer;
        compiler29.init(jSSourceFileArray43, jSModuleArray44, compilerOptions46);
        compilerOptions46.setGenerateExports(true);
        compilerOptions46.jsOutputFile = "21";
        compilerOptions46.removeUnusedPrototypeProperties = false;
        byte[] byteArray55 = compilerOptions46.inputVariableMapSerialized;
        java.util.Set<java.lang.String> strSet56 = compilerOptions46.stripNameSuffixes;
        compilerOptions18.aliasableStrings = strSet56;
        boolean boolean58 = compilerOptions18.deadAssignmentElimination;
        boolean boolean59 = compilerOptions18.computeFunctionSideEffects;
        compilerOptions18.renamePrefix = "Not declared as a constructor";
        java.lang.String str62 = compilerOptions18.instrumentationTemplate;
        compilerOptions18.locale = "100";
        org.junit.Assert.assertNotNull(jSSourceFile4);
        org.junit.Assert.assertNotNull(jSSourceFile7);
        org.junit.Assert.assertNotNull(jSSourceFile9);
        org.junit.Assert.assertNotNull(jSSourceFile12);
        org.junit.Assert.assertNotNull(jSSourceFile14);
        org.junit.Assert.assertNotNull(jSSourceFileArray15);
        org.junit.Assert.assertNotNull(jSModuleArray16);
        org.junit.Assert.assertTrue("'" + tracerMode19 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TracerMode.OFF + "'", tracerMode19.equals(com.google.javascript.jscomp.CompilerOptions.TracerMode.OFF));
        org.junit.Assert.assertNull(byteArray27);
        org.junit.Assert.assertNotNull(jSSourceFile32);
        org.junit.Assert.assertNotNull(jSSourceFile35);
        org.junit.Assert.assertNotNull(jSSourceFile37);
        org.junit.Assert.assertNotNull(jSSourceFile40);
        org.junit.Assert.assertNotNull(jSSourceFile42);
        org.junit.Assert.assertNotNull(jSSourceFileArray43);
        org.junit.Assert.assertNotNull(jSModuleArray44);
        org.junit.Assert.assertTrue("'" + tracerMode47 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TracerMode.OFF + "'", tracerMode47.equals(com.google.javascript.jscomp.CompilerOptions.TracerMode.OFF));
        org.junit.Assert.assertNull(byteArray55);
        org.junit.Assert.assertNotNull(strSet56);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertNull(str62);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention0 = new com.google.javascript.jscomp.DefaultCodingConvention();
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention1 = new com.google.javascript.jscomp.DefaultCodingConvention();
        java.lang.String str2 = defaultCodingConvention1.getExportSymbolFunction();
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node5 = node4.getParent();
        boolean boolean6 = node4.isQuotedString();
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship7 = defaultCodingConvention1.getDelegateRelationship(node4);
        com.google.javascript.jscomp.CodingConvention.SubclassRelationship subclassRelationship8 = defaultCodingConvention0.getClassesDefinedByCall(node4);
        boolean boolean9 = node4.isQuotedString();
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNull(node5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(delegateRelationship7);
        org.junit.Assert.assertNull(subclassRelationship8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.SourceFile.Generator generator3 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile4 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("", generator3);
        com.google.javascript.jscomp.CompilerInput compilerInput5 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile4);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile7 = com.google.javascript.jscomp.JSSourceFile.fromFile("(STRING  [empty_block: 1])");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile9 = com.google.javascript.jscomp.JSSourceFile.fromFile("(STRING  [empty_block: 1])");
        com.google.javascript.jscomp.SourceFile.Generator generator11 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile12 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("", generator11);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile14 = com.google.javascript.jscomp.JSSourceFile.fromFile("(STRING  [empty_block: 1])");
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray15 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile4, jSSourceFile7, jSSourceFile9, jSSourceFile12, jSSourceFile14 };
        com.google.javascript.jscomp.JSModule[] jSModuleArray16 = new com.google.javascript.jscomp.JSModule[] {};
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph17 = new com.google.javascript.jscomp.JSModuleGraph(jSModuleArray16);
        com.google.javascript.jscomp.CompilerOptions compilerOptions18 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CompilerOptions.TracerMode tracerMode19 = compilerOptions18.tracer;
        compiler1.init(jSSourceFileArray15, jSModuleArray16, compilerOptions18);
        compilerOptions18.checkEs5Strict = false;
        boolean boolean23 = compilerOptions18.collapseProperties;
        boolean boolean24 = compilerOptions18.extractPrototypeMemberDeclarations;
        boolean boolean25 = compilerOptions18.rewriteFunctionExpressions;
        org.junit.Assert.assertNotNull(jSSourceFile4);
        org.junit.Assert.assertNotNull(jSSourceFile7);
        org.junit.Assert.assertNotNull(jSSourceFile9);
        org.junit.Assert.assertNotNull(jSSourceFile12);
        org.junit.Assert.assertNotNull(jSSourceFile14);
        org.junit.Assert.assertNotNull(jSSourceFileArray15);
        org.junit.Assert.assertNotNull(jSModuleArray16);
        org.junit.Assert.assertTrue("'" + tracerMode19 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TracerMode.OFF + "'", tracerMode19.equals(com.google.javascript.jscomp.CompilerOptions.TracerMode.OFF));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        boolean boolean1 = com.google.javascript.rhino.Context.isValidOptimizationLevel((int) ' ');
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        try {
            com.google.javascript.rhino.Context.reportWarning("(STRING  [empty_block: 1])");
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: No Context associated with current Thread");
        } catch (java.lang.RuntimeException e) {
        }
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        com.google.javascript.jscomp.parsing.Config config1 = com.google.javascript.jscomp.parsing.ParserRunner.createConfig(true);
        org.junit.Assert.assertNotNull(config1);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        com.google.javascript.jscomp.SourceFile sourceFile3 = com.google.javascript.jscomp.SourceFile.fromCode("window", "STRING  [empty_block: 1]");
        java.io.Reader reader4 = sourceFile3.getCodeReader();
        com.google.javascript.jscomp.SourceFile sourceFile5 = com.google.javascript.jscomp.SourceFile.fromReader("JSC_OPTIMIZE_LOOP_ERROR", reader4);
        org.junit.Assert.assertNotNull(sourceFile3);
        org.junit.Assert.assertNotNull(reader4);
        org.junit.Assert.assertNotNull(sourceFile5);
    }
}

