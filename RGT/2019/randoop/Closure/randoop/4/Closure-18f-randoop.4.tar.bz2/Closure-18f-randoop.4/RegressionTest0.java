import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        com.google.javascript.rhino.Node node0 = null;
        com.google.javascript.rhino.Node node1 = null;
        com.google.javascript.rhino.Node node2 = null;
        try {
            com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.IR.function(node0, node1, node2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.REGEXP_TYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.REGEXP_TYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.REGEXP_TYPE));
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = null;
        com.google.javascript.jscomp.DiagnosticGroups.UNDEFINED_NAMES = diagnosticGroup0;
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.EVAL_ERROR_TYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.EVAL_ERROR_TYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.EVAL_ERROR_TYPE));
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        int int0 = com.google.javascript.rhino.Node.PARENTHESIZED_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 35 + "'", int0 == 35);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        java.lang.String str2 = com.google.javascript.jscomp.ProcessCommonJSModules.toModuleName("hi!", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "module$hi!" + "'", str2.equals("module$hi!"));
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        double double0 = com.google.javascript.rhino.ScriptRuntime.negativeZero;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + (-0.0d) + "'", double0 == (-0.0d));
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.returnNode();
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.IR.stringKey("");
        com.google.javascript.rhino.Node node3 = null;
        int int4 = node2.getIndexOfChild(node3);
        try {
            com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.IR.ifNode(node0, node3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        int int1 = com.google.javascript.jscomp.NodeUtil.getInverseOperator((int) (short) 100);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        int int0 = com.google.javascript.rhino.Node.SIDE_EFFECT_FLAGS;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 42 + "'", int0 == 42);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.IR.stringKey("");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.IR.stringKey("");
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.IR.block();
        com.google.javascript.rhino.Node node8 = new com.google.javascript.rhino.Node((int) ' ', node2, node4, node5, 0, (int) (short) -1);
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.IR.stringKey("");
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.IR.stringKey("");
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.IR.block();
        com.google.javascript.rhino.Node node17 = new com.google.javascript.rhino.Node((int) ' ', node11, node13, node14, 0, (int) (short) -1);
        try {
            com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.IR.regexp(node5, node11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(node14);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.stringKey("");
        com.google.javascript.rhino.Node node2 = null;
        int int3 = node1.getIndexOfChild(node2);
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.IR.returnNode();
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.IR.stringKey("");
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.IR.stringKey("");
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.IR.block();
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node((int) ' ', node7, node9, node10, 0, (int) (short) -1);
        try {
            node1.addChildBefore(node4, node7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The existing child node of the parent should not be null.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node10);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        boolean boolean1 = com.google.javascript.rhino.ScriptRuntime.isJSLineTerminator(35);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        java.lang.String str0 = com.google.javascript.jscomp.ProcessCommonJSModules.DEFAULT_FILENAME_PREFIX;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "./" + "'", str0.equals("./"));
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.IR.stringKey("");
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable4 = node3.siblings();
        com.google.javascript.rhino.Node node7 = new com.google.javascript.rhino.Node((int) (short) 100, node3, (int) (short) 1, (int) (short) 10);
        java.lang.String str8 = node3.getQualifiedName();
        try {
            com.google.javascript.rhino.Node node9 = new com.google.javascript.rhino.Node((int) (short) 10, node3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: new child has existing parent");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(nodeIterable4);
        org.junit.Assert.assertNull(str8);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.STRING_OBJECT_TYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.STRING_OBJECT_TYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.STRING_OBJECT_TYPE));
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        java.lang.String str1 = com.google.javascript.rhino.ScriptRuntime.escapeString("./");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "./" + "'", str1.equals("./"));
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        com.google.javascript.jscomp.CompilerOptions.TracerMode tracerMode0 = com.google.javascript.jscomp.CompilerOptions.TracerMode.OFF;
        org.junit.Assert.assertTrue("'" + tracerMode0 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TracerMode.OFF + "'", tracerMode0.equals(com.google.javascript.jscomp.CompilerOptions.TracerMode.OFF));
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.IR.stringKey("");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.IR.stringKey("");
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.IR.block();
        com.google.javascript.rhino.Node node8 = new com.google.javascript.rhino.Node((int) ' ', node2, node4, node5, 0, (int) (short) -1);
        try {
            com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.IR.defaultCase(node4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(node5);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.TOP_LEVEL_PROTOTYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TOP_LEVEL_PROTOTYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.TOP_LEVEL_PROTOTYPE));
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        com.google.javascript.rhino.Node node0 = null;
        try {
            com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.voidNode(node0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        com.google.javascript.jscomp.CompilerOptions.TweakProcessing tweakProcessing0 = com.google.javascript.jscomp.CompilerOptions.TweakProcessing.CHECK;
        org.junit.Assert.assertTrue("'" + tweakProcessing0 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TweakProcessing.CHECK + "'", tweakProcessing0.equals(com.google.javascript.jscomp.CompilerOptions.TweakProcessing.CHECK));
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = null;
        com.google.javascript.jscomp.DiagnosticGroups.UNKNOWN_DEFINES = diagnosticGroup0;
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        com.google.javascript.jscomp.CompilerOptions.LanguageMode languageMode0 = com.google.javascript.jscomp.CompilerOptions.LanguageMode.ECMASCRIPT5_STRICT;
        org.junit.Assert.assertTrue("'" + languageMode0 + "' != '" + com.google.javascript.jscomp.CompilerOptions.LanguageMode.ECMASCRIPT5_STRICT + "'", languageMode0.equals(com.google.javascript.jscomp.CompilerOptions.LanguageMode.ECMASCRIPT5_STRICT));
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.RANGE_ERROR_TYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.RANGE_ERROR_TYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.RANGE_ERROR_TYPE));
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        try {
            java.util.Map<com.google.javascript.rhino.InputId, com.google.javascript.jscomp.CompilerInput> inputIdMap2 = compiler1.getInputsById();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        java.util.logging.Level level0 = null;
        com.google.javascript.jscomp.Compiler.setLoggingLevel(level0);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        try {
            com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.labelName("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        com.google.javascript.rhino.jstype.JSTypeRegistry.ResolveMode resolveMode0 = com.google.javascript.rhino.jstype.JSTypeRegistry.ResolveMode.IMMEDIATE;
        org.junit.Assert.assertTrue("'" + resolveMode0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeRegistry.ResolveMode.IMMEDIATE + "'", resolveMode0.equals(com.google.javascript.rhino.jstype.JSTypeRegistry.ResolveMode.IMMEDIATE));
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        int int0 = com.google.javascript.rhino.Node.SIDE_EFFECTS_ALL;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        int int0 = com.google.javascript.rhino.Node.IS_DISPATCHER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 47 + "'", int0 == 47);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        com.google.javascript.rhino.JSDocInfo jSDocInfo0 = new com.google.javascript.rhino.JSDocInfo();
        java.util.List<com.google.javascript.rhino.JSTypeExpression> jSTypeExpressionList1 = jSDocInfo0.getImplementedInterfaces();
        java.lang.String str2 = jSDocInfo0.getBlockDescription();
        org.junit.Assert.assertNotNull(jSTypeExpressionList1);
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.DATE_FUNCTION_TYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.DATE_FUNCTION_TYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.DATE_FUNCTION_TYPE));
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.VOID_TYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.VOID_TYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.VOID_TYPE));
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.REGEXP_FUNCTION_TYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.REGEXP_FUNCTION_TYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.REGEXP_FUNCTION_TYPE));
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.stringKey("");
        int int2 = node1.getLineno();
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.IR.block();
        java.lang.String str7 = node3.toString(false, false, false);
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.IR.block();
        java.lang.String str12 = node8.toString(false, false, false);
        com.google.javascript.rhino.Node node13 = node3.useSourceInfoIfMissingFrom(node8);
        com.google.javascript.rhino.Node node14 = node1.srcrefTree(node3);
        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.IR.continueNode();
        com.google.javascript.rhino.Node node19 = new com.google.javascript.rhino.Node(10, node16, 35, 0);
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.IR.block();
        java.lang.String str24 = node20.toString(false, false, false);
        try {
            com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.IR.function(node14, node19, node20);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "BLOCK" + "'", str7.equals("BLOCK"));
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "BLOCK" + "'", str12.equals("BLOCK"));
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "BLOCK" + "'", str24.equals("BLOCK"));
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.SYNTAX_ERROR_TYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.SYNTAX_ERROR_TYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.SYNTAX_ERROR_TYPE));
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.NUMBER_OBJECT_FUNCTION_TYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.NUMBER_OBJECT_FUNCTION_TYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.NUMBER_OBJECT_FUNCTION_TYPE));
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.ERROR_FUNCTION_TYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.ERROR_FUNCTION_TYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.ERROR_FUNCTION_TYPE));
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.block();
        java.lang.String str4 = node0.toString(false, false, false);
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.IR.block();
        java.lang.String str9 = node5.toString(false, false, false);
        com.google.javascript.rhino.Node node10 = node0.useSourceInfoIfMissingFrom(node5);
        com.google.javascript.rhino.jstype.StaticSourceFile staticSourceFile11 = node5.getStaticSourceFile();
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "BLOCK" + "'", str4.equals("BLOCK"));
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "BLOCK" + "'", str9.equals("BLOCK"));
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNull(staticSourceFile11);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.NodeTraversal.Callback callback2 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal3 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler1, callback2);
        try {
            boolean boolean4 = compiler1.hasErrors();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        try {
            compiler1.check();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.stringKey("");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.IR.stringKey("");
        com.google.javascript.rhino.Node node4 = null;
        int int5 = node3.getIndexOfChild(node4);
        node1.addChildrenToBack(node3);
        try {
            com.google.javascript.rhino.Node node7 = com.google.javascript.jscomp.NodeUtil.getRootOfQualifiedName(node1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        com.google.javascript.jscomp.SourceAst sourceAst0 = null;
        try {
            com.google.javascript.jscomp.CompilerInput compilerInput2 = new com.google.javascript.jscomp.CompilerInput(sourceAst0, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.RANGE_ERROR_FUNCTION_TYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.RANGE_ERROR_FUNCTION_TYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.RANGE_ERROR_FUNCTION_TYPE));
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        com.google.javascript.rhino.Node[] nodeArray0 = null;
        try {
            com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.block(nodeArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_TYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_TYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_TYPE));
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.IR.stringKey("");
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable3 = node2.siblings();
        com.google.javascript.rhino.Node node6 = new com.google.javascript.rhino.Node((int) (short) 100, node2, (int) (short) 1, (int) (short) 10);
        java.lang.String str7 = node2.getQualifiedName();
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.IR.trueNode();
        java.lang.String str10 = node9.getSourceFileName();
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.IR.stringKey("");
        int int13 = node12.getLineno();
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.IR.block();
        java.lang.String str18 = node14.toString(false, false, false);
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.IR.block();
        java.lang.String str23 = node19.toString(false, false, false);
        com.google.javascript.rhino.Node node24 = node14.useSourceInfoIfMissingFrom(node19);
        com.google.javascript.rhino.Node node25 = node12.srcrefTree(node14);
        com.google.javascript.rhino.Node node26 = com.google.javascript.rhino.IR.returnNode();
        com.google.javascript.rhino.Node node27 = new com.google.javascript.rhino.Node((int) (short) 100, node9, node12, node26);
        try {
            com.google.javascript.rhino.Node node28 = com.google.javascript.rhino.IR.getelem(node2, node12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertNotNull(nodeIterable3);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "BLOCK" + "'", str18.equals("BLOCK"));
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "BLOCK" + "'", str23.equals("BLOCK"));
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNotNull(node26);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        com.google.javascript.jscomp.CompilerOptions.LanguageMode languageMode0 = com.google.javascript.jscomp.CompilerOptions.LanguageMode.ECMASCRIPT3;
        org.junit.Assert.assertTrue("'" + languageMode0 + "' != '" + com.google.javascript.jscomp.CompilerOptions.LanguageMode.ECMASCRIPT3 + "'", languageMode0.equals(com.google.javascript.jscomp.CompilerOptions.LanguageMode.ECMASCRIPT3));
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.stringKey("");
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable2 = node1.siblings();
        try {
            com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.IR.exprResult(node1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertNotNull(nodeIterable2);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        com.google.javascript.rhino.JSDocInfo jSDocInfo0 = new com.google.javascript.rhino.JSDocInfo();
        java.util.List<com.google.javascript.rhino.JSTypeExpression> jSTypeExpressionList1 = jSDocInfo0.getImplementedInterfaces();
        int int2 = jSDocInfo0.getImplementedInterfaceCount();
        org.junit.Assert.assertNotNull(jSTypeExpressionList1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.continueNode();
        com.google.javascript.rhino.Node node4 = new com.google.javascript.rhino.Node(10, node1, 35, 0);
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.IR.block();
        java.lang.String str9 = node5.toString(false, false, false);
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.IR.stringKey("");
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable13 = node12.siblings();
        com.google.javascript.rhino.Node node16 = new com.google.javascript.rhino.Node((int) (short) 100, node12, (int) (short) 1, (int) (short) 10);
        com.google.javascript.rhino.Node node17 = node5.useSourceInfoIfMissingFrom(node16);
        boolean boolean18 = node1.isEquivalentTo(node17);
        try {
            com.google.javascript.rhino.Node node19 = node17.detachFromParent();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "BLOCK" + "'", str9.equals("BLOCK"));
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(nodeIterable13);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.ErrorManager errorManager2 = null;
        try {
            compiler1.setErrorManager(errorManager2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: the error manager cannot be null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.stringKey("");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.IR.continueNode();
        com.google.javascript.rhino.Node node6 = new com.google.javascript.rhino.Node(10, node3, 35, 0);
        try {
            com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.IR.doNode(node1, node6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertNotNull(node3);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.stringKey("");
        com.google.javascript.rhino.Node node2 = null;
        int int3 = node1.getIndexOfChild(node2);
        node1.setString("module$hi!");
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.IR.stringKey("");
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.IR.stringKey("");
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.IR.block();
        com.google.javascript.rhino.Node node14 = new com.google.javascript.rhino.Node((int) ' ', node8, node10, node11, 0, (int) (short) -1);
        boolean boolean15 = node8.isThrow();
        com.google.javascript.rhino.Node node16 = node8.getParent();
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.IR.stringKey("");
        com.google.javascript.rhino.Node node19 = null;
        int int20 = node18.getIndexOfChild(node19);
        try {
            node1.addChildAfter(node8, node19);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The new child node has siblings.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        com.google.javascript.jscomp.SourceAst sourceAst0 = null;
        try {
            com.google.javascript.jscomp.CompilerInput compilerInput1 = new com.google.javascript.jscomp.CompilerInput(sourceAst0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        int int0 = com.google.javascript.rhino.Node.COLUMN_BITS;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 12 + "'", int0 == 12);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.IR.stringKey("");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.IR.stringKey("");
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.IR.block();
        com.google.javascript.rhino.Node node8 = new com.google.javascript.rhino.Node((int) ' ', node2, node4, node5, 0, (int) (short) -1);
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.IR.stringKey("");
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.IR.stringKey("");
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.IR.block();
        com.google.javascript.rhino.Node node17 = new com.google.javascript.rhino.Node((int) ' ', node11, node13, node14, 0, (int) (short) -1);
        boolean boolean18 = node11.isThrow();
        int int19 = node5.getIndexOfChild(node11);
        com.google.javascript.rhino.Node node21 = com.google.javascript.rhino.IR.continueNode();
        com.google.javascript.rhino.Node node24 = new com.google.javascript.rhino.Node(10, node21, 35, 0);
        boolean boolean26 = node21.getBooleanProp((-1));
        com.google.javascript.rhino.Node node28 = com.google.javascript.rhino.IR.trueNode();
        java.lang.String str29 = node28.getSourceFileName();
        com.google.javascript.rhino.Node node31 = com.google.javascript.rhino.IR.stringKey("");
        int int32 = node31.getLineno();
        com.google.javascript.rhino.Node node33 = com.google.javascript.rhino.IR.block();
        java.lang.String str37 = node33.toString(false, false, false);
        com.google.javascript.rhino.Node node38 = com.google.javascript.rhino.IR.block();
        java.lang.String str42 = node38.toString(false, false, false);
        com.google.javascript.rhino.Node node43 = node33.useSourceInfoIfMissingFrom(node38);
        com.google.javascript.rhino.Node node44 = node31.srcrefTree(node33);
        com.google.javascript.rhino.Node node45 = com.google.javascript.rhino.IR.returnNode();
        com.google.javascript.rhino.Node node46 = new com.google.javascript.rhino.Node((int) (short) 100, node28, node31, node45);
        com.google.javascript.rhino.Node node47 = com.google.javascript.rhino.IR.continueNode();
        com.google.javascript.rhino.Node node49 = com.google.javascript.rhino.IR.stringKey("");
        com.google.javascript.rhino.Node node51 = com.google.javascript.rhino.IR.stringKey("");
        com.google.javascript.rhino.Node node52 = null;
        int int53 = node51.getIndexOfChild(node52);
        com.google.javascript.rhino.Node[] nodeArray54 = new com.google.javascript.rhino.Node[] { node5, node21, node45, node47, node49, node52 };
        try {
            com.google.javascript.rhino.Node node55 = com.google.javascript.rhino.IR.block(nodeArray54);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertNull(str29);
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-1) + "'", int32 == (-1));
        org.junit.Assert.assertNotNull(node33);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "BLOCK" + "'", str37.equals("BLOCK"));
        org.junit.Assert.assertNotNull(node38);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "BLOCK" + "'", str42.equals("BLOCK"));
        org.junit.Assert.assertNotNull(node43);
        org.junit.Assert.assertNotNull(node44);
        org.junit.Assert.assertNotNull(node45);
        org.junit.Assert.assertNotNull(node47);
        org.junit.Assert.assertNotNull(node49);
        org.junit.Assert.assertNotNull(node51);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + (-1) + "'", int53 == (-1));
        org.junit.Assert.assertNotNull(nodeArray54);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.NodeTraversal.Callback callback2 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal3 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler1, callback2);
        try {
            compiler1.parse();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.LEAST_FUNCTION_TYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.LEAST_FUNCTION_TYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.LEAST_FUNCTION_TYPE));
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.stringKey("");
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable2 = node1.siblings();
        boolean boolean3 = node1.isQualifiedName();
        node1.setString("");
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.IR.stringKey("");
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable9 = node8.siblings();
        com.google.javascript.rhino.Node node12 = new com.google.javascript.rhino.Node((int) (short) 100, node8, (int) (short) 1, (int) (short) 10);
        try {
            com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.IR.caseNode(node1, node12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertNotNull(nodeIterable2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNotNull(nodeIterable9);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.block();
        java.lang.String str4 = node0.toString(false, false, false);
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.IR.block();
        java.lang.String str9 = node5.toString(false, false, false);
        com.google.javascript.rhino.Node node10 = node0.useSourceInfoIfMissingFrom(node5);
        boolean boolean11 = node10.isWith();
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "BLOCK" + "'", str4.equals("BLOCK"));
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "BLOCK" + "'", str9.equals("BLOCK"));
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention0 = new com.google.javascript.jscomp.GoogleCodingConvention();
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention1 = new com.google.javascript.jscomp.ClosureCodingConvention((com.google.javascript.jscomp.CodingConvention) googleCodingConvention0);
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.IR.returnNode();
        try {
            com.google.javascript.jscomp.CodingConvention.ObjectLiteralCast objectLiteralCast3 = closureCodingConvention1.getObjectLiteralCast(node2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node2);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        com.google.javascript.rhino.jstype.ObjectType objectType0 = null;
        try {
            com.google.javascript.rhino.jstype.ObjectType objectType2 = com.google.javascript.rhino.jstype.FunctionType.getTopDefiningInterface(objectType0, "./");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        com.google.javascript.jscomp.ErrorManager errorManager0 = null;
        com.google.javascript.jscomp.deps.JsFileParser jsFileParser1 = new com.google.javascript.jscomp.deps.JsFileParser(errorManager0);
        try {
            com.google.javascript.jscomp.deps.DependencyInfo dependencyInfo4 = jsFileParser1.parseFile("hi!", "BLOCK");
            org.junit.Assert.fail("Expected exception of type java.io.FileNotFoundException; message: hi! (No such file or directory)");
        } catch (java.io.FileNotFoundException e) {
        }
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.ACCESS_CONTROLS;
        com.google.javascript.jscomp.DiagnosticGroups.INTERNET_EXPLORER_CHECKS = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticGroups.VISIBILITY = diagnosticGroup0;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        try {
            java.lang.String str2 = compiler1.toSource();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.continueNode();
        com.google.javascript.rhino.Node node4 = new com.google.javascript.rhino.Node(10, node1, 35, 0);
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.IR.block();
        java.lang.String str9 = node5.toString(false, false, false);
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.IR.stringKey("");
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable13 = node12.siblings();
        com.google.javascript.rhino.Node node16 = new com.google.javascript.rhino.Node((int) (short) 100, node12, (int) (short) 1, (int) (short) 10);
        com.google.javascript.rhino.Node node17 = node5.useSourceInfoIfMissingFrom(node16);
        boolean boolean18 = node1.isEquivalentTo(node17);
        boolean boolean19 = node1.isLabelName();
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "BLOCK" + "'", str9.equals("BLOCK"));
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(nodeIterable13);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        int int0 = com.google.javascript.rhino.Node.FREE_CALL;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 50 + "'", int0 == 50);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        com.google.javascript.jscomp.ErrorManager errorManager0 = null;
        com.google.javascript.jscomp.deps.JsFileParser jsFileParser1 = new com.google.javascript.jscomp.deps.JsFileParser(errorManager0);
        try {
            com.google.javascript.jscomp.deps.DependencyInfo dependencyInfo4 = jsFileParser1.parseFile("", "");
            org.junit.Assert.fail("Expected exception of type java.io.FileNotFoundException; message:  (No such file or directory)");
        } catch (java.io.FileNotFoundException e) {
        }
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.block();
        java.lang.String str4 = node0.toString(false, false, false);
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.IR.block();
        java.lang.String str9 = node5.toString(false, false, false);
        com.google.javascript.rhino.Node node10 = node0.useSourceInfoIfMissingFrom(node5);
        com.google.javascript.rhino.Node node11 = null;
        try {
            com.google.javascript.rhino.Node node12 = node10.srcrefTree(node11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "BLOCK" + "'", str4.equals("BLOCK"));
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "BLOCK" + "'", str9.equals("BLOCK"));
        org.junit.Assert.assertNotNull(node10);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.PassConfig passConfig2 = null;
        try {
            compiler1.setPassConfig(passConfig2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.JsAst jsAst2 = null;
        try {
            compiler1.addNewScript(jsAst2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.NodeTraversal.Callback callback2 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal3 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler1, callback2);
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.IR.stringKey("");
        int int6 = node5.getLineno();
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.IR.block();
        java.lang.String str11 = node7.toString(false, false, false);
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.IR.block();
        java.lang.String str16 = node12.toString(false, false, false);
        com.google.javascript.rhino.Node node17 = node7.useSourceInfoIfMissingFrom(node12);
        com.google.javascript.rhino.Node node18 = node5.srcrefTree(node7);
        com.google.javascript.jscomp.DiagnosticType diagnosticType19 = null;
        java.lang.String[] strArray20 = new java.lang.String[] {};
        try {
            nodeTraversal3.report(node18, diagnosticType19, strArray20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "BLOCK" + "'", str11.equals("BLOCK"));
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "BLOCK" + "'", str16.equals("BLOCK"));
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNotNull(strArray20);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.NodeTraversal.Callback callback2 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal3 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler1, callback2);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile4 = null;
        com.google.javascript.jscomp.JSModule[] jSModuleArray5 = new com.google.javascript.jscomp.JSModule[] {};
        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList6 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
        boolean boolean7 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList6, jSModuleArray5);
        com.google.javascript.jscomp.JSModule[] jSModuleArray8 = com.google.javascript.jscomp.JSModule.sortJsModules((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList6);
        com.google.javascript.jscomp.CompilerOptions compilerOptions9 = null;
        try {
            com.google.javascript.jscomp.Result result10 = compiler1.compile(jSSourceFile4, jSModuleArray8, compilerOptions9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jSModuleArray5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(jSModuleArray8);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.stringKey("");
        java.lang.String str2 = node1.getString();
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.NUMBER_OBJECT_TYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.NUMBER_OBJECT_TYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.NUMBER_OBJECT_TYPE));
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.NodeTraversal.Callback callback2 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal3 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler1, callback2);
        com.google.javascript.jscomp.Compiler.IntermediateState intermediateState4 = compiler1.getState();
        com.google.javascript.jscomp.SourceFile sourceFile5 = null;
        try {
            com.google.javascript.rhino.Node node6 = compiler1.parse(sourceFile5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intermediateState4);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        java.util.List<java.lang.String> strList2 = null;
        java.lang.String[] strArray7 = new java.lang.String[] { "BLOCK", "BLOCK", "hi!", "BLOCK" };
        java.util.ArrayList<java.lang.String> strList8 = new java.util.ArrayList<java.lang.String>();
        boolean boolean9 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strList8, strArray7);
        com.google.javascript.jscomp.deps.SimpleDependencyInfo simpleDependencyInfo10 = new com.google.javascript.jscomp.deps.SimpleDependencyInfo("hi!", "hi!", strList2, (java.util.List<java.lang.String>) strList8);
        com.google.javascript.jscomp.deps.DependencyInfo[] dependencyInfoArray11 = new com.google.javascript.jscomp.deps.DependencyInfo[] { simpleDependencyInfo10 };
        java.util.ArrayList<com.google.javascript.jscomp.deps.DependencyInfo> dependencyInfoList12 = new java.util.ArrayList<com.google.javascript.jscomp.deps.DependencyInfo>();
        boolean boolean13 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.deps.DependencyInfo>) dependencyInfoList12, dependencyInfoArray11);
        try {
            com.google.javascript.jscomp.deps.SortedDependencies<com.google.javascript.jscomp.deps.DependencyInfo> dependencyInfoSortedDependencies14 = new com.google.javascript.jscomp.deps.SortedDependencies<com.google.javascript.jscomp.deps.DependencyInfo>((java.util.List<com.google.javascript.jscomp.deps.DependencyInfo>) dependencyInfoList12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(dependencyInfoArray11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        com.google.javascript.rhino.JSTypeExpression jSTypeExpression0 = null;
        try {
            com.google.javascript.rhino.JSTypeExpression jSTypeExpression1 = com.google.javascript.rhino.JSTypeExpression.makeOptionalArg(jSTypeExpression0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        java.lang.String str0 = com.google.javascript.rhino.jstype.JSType.NOT_A_CLASS;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "Not declared as a constructor" + "'", str0.equals("Not declared as a constructor"));
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        int int0 = com.google.javascript.rhino.Node.INPUT_ID;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 53 + "'", int0 == 53);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        int int0 = com.google.javascript.rhino.Node.INCRDECR_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 32 + "'", int0 == 32);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.block();
        java.lang.String str4 = node0.toString(false, false, false);
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.IR.block();
        java.lang.String str9 = node5.toString(false, false, false);
        com.google.javascript.rhino.Node node10 = node0.useSourceInfoIfMissingFrom(node5);
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.IR.stringKey("");
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.IR.stringKey("");
        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.IR.block();
        com.google.javascript.rhino.Node node19 = new com.google.javascript.rhino.Node((int) ' ', node13, node15, node16, 0, (int) (short) -1);
        node19.setSourceFileForTesting("module$hi!");
        boolean boolean22 = node19.isReturn();
        try {
            com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.IR.var(node5, node19);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "BLOCK" + "'", str4.equals("BLOCK"));
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "BLOCK" + "'", str9.equals("BLOCK"));
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        long long1 = com.google.javascript.rhino.ScriptRuntime.testUint32String("");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1L) + "'", long1 == (-1L));
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        java.lang.String str1 = com.google.javascript.jscomp.ProcessCommonJSModules.toModuleName("hi!");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "module$hi!" + "'", str1.equals("module$hi!"));
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.JsAst jsAst2 = null;
        try {
            compiler1.replaceScript(jsAst2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        com.google.javascript.rhino.JSDocInfo.TypePosition typePosition0 = new com.google.javascript.rhino.JSDocInfo.TypePosition();
        try {
            typePosition0.setPositionInformation((int) '4', (int) (short) 100, (int) '4', (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Recorded bad position information\nstart-char: 100\nend-char: 32");
        } catch (java.lang.IllegalStateException e) {
        }
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        com.google.javascript.jscomp.SourceAst sourceAst0 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(sourceAst0, "Not declared as a constructor", true);
        try {
            com.google.javascript.jscomp.CompilerInput compilerInput5 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput3, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention0 = new com.google.javascript.jscomp.GoogleCodingConvention();
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention1 = new com.google.javascript.jscomp.ClosureCodingConvention((com.google.javascript.jscomp.CodingConvention) googleCodingConvention0);
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.IR.returnNode();
        java.util.Set<java.lang.String> strSet3 = node2.getDirectives();
        int int4 = node2.getType();
        try {
            boolean boolean5 = googleCodingConvention0.isInlinableFunction(node2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertNull(strSet3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 4 + "'", int4 == 4);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.NodeTraversal.Callback callback2 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal3 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler1, callback2);
        com.google.javascript.jscomp.Compiler.IntermediateState intermediateState4 = compiler1.getState();
        com.google.javascript.jscomp.JsAst jsAst5 = null;
        try {
            compiler1.replaceScript(jsAst5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intermediateState4);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        int int0 = com.google.javascript.rhino.Node.COLUMN_MASK;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4095 + "'", int0 == 4095);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.NULL_TYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.NULL_TYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.NULL_TYPE));
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention0 = new com.google.javascript.jscomp.GoogleCodingConvention();
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention1 = new com.google.javascript.jscomp.ClosureCodingConvention((com.google.javascript.jscomp.CodingConvention) googleCodingConvention0);
        com.google.javascript.rhino.Node node2 = null;
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship3 = googleCodingConvention0.getDelegateRelationship(node2);
        java.lang.String str4 = googleCodingConvention0.getGlobalObject();
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.IR.returnNode();
        java.util.Set<java.lang.String> strSet6 = node5.getDirectives();
        try {
            com.google.javascript.jscomp.CodingConvention.SubclassRelationship subclassRelationship7 = googleCodingConvention0.getClassesDefinedByCall(node5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(delegateRelationship3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "goog.global" + "'", str4.equals("goog.global"));
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNull(strSet6);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        com.google.javascript.rhino.JSDocInfo jSDocInfo0 = new com.google.javascript.rhino.JSDocInfo();
        java.util.List<com.google.javascript.rhino.JSTypeExpression> jSTypeExpressionList1 = jSDocInfo0.getImplementedInterfaces();
        boolean boolean3 = jSDocInfo0.hasDescriptionForParameter("./");
        java.lang.String str5 = jSDocInfo0.getDescriptionForParameter("goog.global");
        boolean boolean6 = jSDocInfo0.hasEnumParameterType();
        org.junit.Assert.assertNotNull(jSTypeExpressionList1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.UNKNOWN_DEFINES;
        org.junit.Assert.assertNull(diagnosticGroup0);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.NodeTraversal.Callback callback2 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal3 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler1, callback2);
        java.lang.String str4 = compiler1.getAstDotGraph();
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray5 = new com.google.javascript.jscomp.JSSourceFile[] {};
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray6 = new com.google.javascript.jscomp.JSSourceFile[] {};
        com.google.javascript.jscomp.CompilerOptions compilerOptions7 = null;
        try {
            com.google.javascript.jscomp.Result result8 = compiler1.compile(jSSourceFileArray5, jSSourceFileArray6, compilerOptions7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertNotNull(jSSourceFileArray5);
        org.junit.Assert.assertNotNull(jSSourceFileArray6);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.IR.stringKey("");
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable4 = node3.siblings();
        boolean boolean5 = node3.isQualifiedName();
        node3.setString("");
        node3.removeProp((int) ' ');
        com.google.javascript.jscomp.NodeTraversal.Callback callback10 = null;
        try {
            com.google.javascript.jscomp.NodeTraversal.traverse((com.google.javascript.jscomp.AbstractCompiler) compiler1, node3, callback10);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: INTERNAL COMPILER ERROR.\nPlease report this problem.\nnull");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(nodeIterable4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        com.google.javascript.jscomp.AnonymousFunctionNamingPolicy anonymousFunctionNamingPolicy0 = com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.UNMAPPED;
        org.junit.Assert.assertTrue("'" + anonymousFunctionNamingPolicy0 + "' != '" + com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.UNMAPPED + "'", anonymousFunctionNamingPolicy0.equals(com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.UNMAPPED));
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = null;
        com.google.javascript.jscomp.DiagnosticGroups.INTERNET_EXPLORER_CHECKS = diagnosticGroup0;
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable3 = jSTypeRegistry1.getEachReferenceTypeWithProperty("goog.global");
        com.google.javascript.rhino.jstype.JSType jSType4 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray5 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType6 = jSTypeRegistry1.createConstructorTypeWithVarArgs(jSType4, jSTypeArray5);
        com.google.javascript.rhino.jstype.ObjectType objectType7 = null;
        try {
            functionType6.setPrototypeBasedOn(objectType7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(objectTypeIterable3);
        org.junit.Assert.assertNotNull(jSTypeArray5);
        org.junit.Assert.assertNotNull(functionType6);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        int int0 = com.google.javascript.rhino.jstype.JSType.NOT_ENUMDECL;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        com.google.javascript.jscomp.SourceAst sourceAst0 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(sourceAst0, "Not declared as a constructor", true);
        com.google.javascript.jscomp.SourceAst sourceAst4 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput7 = new com.google.javascript.jscomp.CompilerInput(sourceAst4, "Not declared as a constructor", true);
        com.google.javascript.rhino.InputId inputId8 = compilerInput7.getInputId();
        try {
            com.google.javascript.jscomp.CompilerInput compilerInput10 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput3, inputId8, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(inputId8);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.IR.stringKey("");
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.IR.stringKey("");
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.IR.block();
        com.google.javascript.rhino.Node node9 = new com.google.javascript.rhino.Node((int) ' ', node3, node5, node6, 0, (int) (short) -1);
        boolean boolean10 = node3.isThrow();
        boolean boolean11 = node3.isTry();
        boolean boolean12 = node3.isIn();
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.IR.stringKey("");
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.IR.stringKey("");
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.IR.block();
        com.google.javascript.rhino.Node node21 = new com.google.javascript.rhino.Node((int) ' ', node15, node17, node18, 0, (int) (short) -1);
        node21.setSourceFileForTesting("module$hi!");
        try {
            node0.replaceChildAfter(node3, node21);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: prev is not a child of this node.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(node18);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        java.util.List<java.lang.String> strList2 = null;
        java.lang.String[] strArray7 = new java.lang.String[] { "BLOCK", "BLOCK", "hi!", "BLOCK" };
        java.util.ArrayList<java.lang.String> strList8 = new java.util.ArrayList<java.lang.String>();
        boolean boolean9 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strList8, strArray7);
        com.google.javascript.jscomp.deps.SimpleDependencyInfo simpleDependencyInfo10 = new com.google.javascript.jscomp.deps.SimpleDependencyInfo("hi!", "hi!", strList2, (java.util.List<java.lang.String>) strList8);
        try {
            java.util.Collection<java.lang.String> strCollection11 = simpleDependencyInfo10.getProvides();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.block();
        java.lang.String str4 = node0.toString(false, false, false);
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.IR.block();
        java.lang.String str9 = node5.toString(false, false, false);
        com.google.javascript.rhino.Node node10 = node0.useSourceInfoIfMissingFrom(node5);
        try {
            com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.IR.neg(node0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "BLOCK" + "'", str4.equals("BLOCK"));
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "BLOCK" + "'", str9.equals("BLOCK"));
        org.junit.Assert.assertNotNull(node10);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newNumber((double) (short) 0, 35, (int) (byte) 0);
        org.junit.Assert.assertNotNull(node3);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.stringKey("");
        com.google.javascript.rhino.Node node2 = null;
        int int3 = node1.getIndexOfChild(node2);
        try {
            com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.IR.pos(node2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable3 = jSTypeRegistry1.getEachReferenceTypeWithProperty("goog.global");
        com.google.javascript.rhino.jstype.JSType jSType4 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray5 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType6 = jSTypeRegistry1.createConstructorTypeWithVarArgs(jSType4, jSTypeArray5);
        com.google.javascript.rhino.JSDocInfo jSDocInfo7 = functionType6.getJSDocInfo();
        com.google.javascript.rhino.jstype.JSType jSType9 = functionType6.findPropertyType("");
        try {
            boolean boolean10 = jSType9.isCheckedUnknownType();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(objectTypeIterable3);
        org.junit.Assert.assertNotNull(jSTypeArray5);
        org.junit.Assert.assertNotNull(functionType6);
        org.junit.Assert.assertNull(jSDocInfo7);
        org.junit.Assert.assertNull(jSType9);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean1 = node0.isOptionalArg();
        boolean boolean2 = node0.isIn();
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        int int0 = com.google.javascript.rhino.Node.MAX_COLUMN_NUMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4095 + "'", int0 == 4095);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_TYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_TYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_TYPE));
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.block();
        java.lang.String str4 = node0.toString(false, false, false);
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.IR.block();
        java.lang.String str9 = node5.toString(false, false, false);
        com.google.javascript.rhino.Node node10 = node0.useSourceInfoIfMissingFrom(node5);
        boolean boolean11 = node10.isWith();
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean13 = node12.isOptionalArg();
        com.google.javascript.rhino.Node[] nodeArray14 = new com.google.javascript.rhino.Node[] { node10, node12 };
        try {
            com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.IR.paramList(nodeArray14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "BLOCK" + "'", str4.equals("BLOCK"));
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "BLOCK" + "'", str9.equals("BLOCK"));
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(nodeArray14);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        com.google.javascript.jscomp.SourceAst sourceAst0 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(sourceAst0, "Not declared as a constructor", true);
        try {
            com.google.javascript.jscomp.Region region5 = compilerInput3.getRegion((int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.URI_ERROR_TYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.URI_ERROR_TYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.URI_ERROR_TYPE));
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.NodeTraversal.Callback callback2 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal3 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler1, callback2);
        com.google.javascript.jscomp.Compiler.IntermediateState intermediateState4 = compiler1.getState();
        try {
            boolean boolean5 = compiler1.isIdeMode();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intermediateState4);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.IR.stringKey("");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.IR.stringKey("");
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.IR.block();
        com.google.javascript.rhino.Node node8 = new com.google.javascript.rhino.Node((int) ' ', node2, node4, node5, 0, (int) (short) -1);
        boolean boolean9 = node2.isThrow();
        com.google.javascript.rhino.Node node10 = node2.getParent();
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.IR.stringKey("");
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.IR.stringKey("");
        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.IR.block();
        com.google.javascript.rhino.Node node19 = new com.google.javascript.rhino.Node((int) ' ', node13, node15, node16, 0, (int) (short) -1);
        boolean boolean20 = node13.isThrow();
        boolean boolean21 = node13.isTry();
        boolean boolean22 = node13.isIn();
        try {
            node2.addChildToBack(node13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        com.google.javascript.rhino.JSDocInfo jSDocInfo0 = new com.google.javascript.rhino.JSDocInfo();
        java.util.List<com.google.javascript.rhino.JSTypeExpression> jSTypeExpressionList1 = jSDocInfo0.getImplementedInterfaces();
        boolean boolean3 = jSDocInfo0.hasDescriptionForParameter("./");
        java.lang.String str5 = jSDocInfo0.getDescriptionForParameter("goog.global");
        boolean boolean6 = jSDocInfo0.isOverride();
        org.junit.Assert.assertNotNull(jSTypeExpressionList1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.block();
        java.lang.String str4 = node0.toString(false, false, false);
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.IR.block();
        java.lang.String str9 = node5.toString(false, false, false);
        com.google.javascript.rhino.Node node10 = node0.useSourceInfoIfMissingFrom(node5);
        boolean boolean11 = node10.isParamList();
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.Node.newString("goog.global", 53, 0);
        try {
            com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.IR.label(node10, node15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "BLOCK" + "'", str4.equals("BLOCK"));
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "BLOCK" + "'", str9.equals("BLOCK"));
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(node15);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.continueNode();
        com.google.javascript.rhino.Node node4 = new com.google.javascript.rhino.Node(10, node1, 35, 0);
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.IR.block();
        java.lang.String str9 = node5.toString(false, false, false);
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.IR.stringKey("");
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable13 = node12.siblings();
        com.google.javascript.rhino.Node node16 = new com.google.javascript.rhino.Node((int) (short) 100, node12, (int) (short) 1, (int) (short) 10);
        com.google.javascript.rhino.Node node17 = node5.useSourceInfoIfMissingFrom(node16);
        boolean boolean18 = node1.isEquivalentTo(node17);
        com.google.javascript.rhino.Node node20 = node1.getAncestor(12);
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "BLOCK" + "'", str9.equals("BLOCK"));
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(nodeIterable13);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNull(node20);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.IR.stringKey("");
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable3 = node2.siblings();
        com.google.javascript.rhino.Node node6 = new com.google.javascript.rhino.Node((int) (short) 100, node2, (int) (short) 1, (int) (short) 10);
        boolean boolean7 = node6.isExprResult();
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertNotNull(nodeIterable3);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy0 = com.google.javascript.jscomp.PropertyRenamingPolicy.OFF;
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy0 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.OFF + "'", propertyRenamingPolicy0.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.OFF));
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.stringKey("");
        com.google.javascript.rhino.Node node2 = null;
        int int3 = node1.getIndexOfChild(node2);
        node1.setString("module$hi!");
        boolean boolean6 = node1.isStringKey();
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.IR.thisNode();
        java.lang.String str8 = node7.getQualifiedName();
        try {
            com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.IR.tryCatch(node1, node7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "this" + "'", str8.equals("this"));
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.continueNode();
        com.google.javascript.rhino.Node node4 = new com.google.javascript.rhino.Node(10, node1, 35, 0);
        node1.setLength((int) 'a');
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.IR.trueNode();
        try {
            com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.IR.comma(node1, node7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertNotNull(node7);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        com.google.javascript.jscomp.SourceAst sourceAst0 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(sourceAst0, "Not declared as a constructor", true);
        com.google.javascript.rhino.InputId inputId4 = compilerInput3.getInputId();
        try {
            compilerInput3.removeRequire("hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Expected setCompiler to be called first: Not declared as a constructor");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(inputId4);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        int int0 = com.google.javascript.rhino.Node.SLASH_V;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 54 + "'", int0 == 54);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.rhino.Node node2 = null;
        com.google.javascript.jscomp.NodeTraversal.Callback callback3 = null;
        try {
            com.google.javascript.jscomp.NodeTraversal.traverse((com.google.javascript.jscomp.AbstractCompiler) compiler1, node2, callback3);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: INTERNAL COMPILER ERROR.\nPlease report this problem.\nnull");
        } catch (java.lang.RuntimeException e) {
        }
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.NodeTraversal.Callback callback2 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal3 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler1, callback2);
        java.lang.String str4 = compiler1.getAstDotGraph();
        try {
            java.lang.String str7 = compiler1.getSourceLine("JSDocInfo", 50);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        java.util.List<java.lang.String> strList2 = null;
        java.lang.String[] strArray7 = new java.lang.String[] { "BLOCK", "BLOCK", "hi!", "BLOCK" };
        java.util.ArrayList<java.lang.String> strList8 = new java.util.ArrayList<java.lang.String>();
        boolean boolean9 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strList8, strArray7);
        com.google.javascript.jscomp.deps.SimpleDependencyInfo simpleDependencyInfo10 = new com.google.javascript.jscomp.deps.SimpleDependencyInfo("hi!", "hi!", strList2, (java.util.List<java.lang.String>) strList8);
        java.lang.String str11 = simpleDependencyInfo10.getPathRelativeToClosureBase();
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "hi!" + "'", str11.equals("hi!"));
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        int int0 = com.google.javascript.rhino.Node.FLAG_THIS_UNMODIFIED;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable3 = jSTypeRegistry1.getEachReferenceTypeWithProperty("goog.global");
        com.google.javascript.rhino.jstype.JSType jSType4 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray5 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType6 = jSTypeRegistry1.createConstructorTypeWithVarArgs(jSType4, jSTypeArray5);
        com.google.javascript.rhino.jstype.JSType jSType7 = null;
        try {
            com.google.javascript.rhino.jstype.JSType jSType8 = functionType6.getLeastSupertype(jSType7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(objectTypeIterable3);
        org.junit.Assert.assertNotNull(jSTypeArray5);
        org.junit.Assert.assertNotNull(functionType6);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        com.google.javascript.rhino.Node node0 = null;
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.IR.continueNode();
        com.google.javascript.rhino.Node node5 = new com.google.javascript.rhino.Node(10, node2, 35, 0);
        com.google.javascript.rhino.jstype.StaticSourceFile staticSourceFile6 = node2.getStaticSourceFile();
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.IR.stringKey("");
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.IR.stringKey("");
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.IR.block();
        com.google.javascript.rhino.Node node15 = new com.google.javascript.rhino.Node((int) ' ', node9, node11, node12, 0, (int) (short) -1);
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.IR.stringKey("");
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.IR.stringKey("");
        com.google.javascript.rhino.Node node21 = com.google.javascript.rhino.IR.block();
        com.google.javascript.rhino.Node node24 = new com.google.javascript.rhino.Node((int) ' ', node18, node20, node21, 0, (int) (short) -1);
        boolean boolean25 = node18.isThrow();
        int int26 = node12.getIndexOfChild(node18);
        try {
            com.google.javascript.rhino.Node node27 = com.google.javascript.rhino.IR.ifNode(node0, node2, node12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertNull(staticSourceFile6);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.NodeTraversal.Callback callback2 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal3 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler1, callback2);
        com.google.javascript.jscomp.Compiler.IntermediateState intermediateState4 = compiler1.getState();
        try {
            java.lang.String[] strArray5 = compiler1.toSourceArray();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intermediateState4);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        com.google.javascript.rhino.Node node1 = null;
        try {
            com.google.javascript.rhino.Node node4 = new com.google.javascript.rhino.Node(0, node1, 1, 12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.IR.stringKey("");
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable3 = node2.siblings();
        com.google.javascript.rhino.Node node6 = new com.google.javascript.rhino.Node((int) (short) 100, node2, (int) (short) 1, (int) (short) 10);
        java.lang.String str7 = node2.getQualifiedName();
        node2.setOptionalArg(true);
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertNotNull(nodeIterable3);
        org.junit.Assert.assertNull(str7);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable3 = jSTypeRegistry1.getEachReferenceTypeWithProperty("goog.global");
        com.google.javascript.rhino.jstype.JSType jSType4 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray5 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType6 = jSTypeRegistry1.createConstructorTypeWithVarArgs(jSType4, jSTypeArray5);
        com.google.javascript.rhino.JSDocInfo jSDocInfo7 = functionType6.getJSDocInfo();
        boolean boolean8 = functionType6.isAllType();
        com.google.javascript.rhino.ErrorReporter errorReporter9 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry10 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter9);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable12 = jSTypeRegistry10.getEachReferenceTypeWithProperty("goog.global");
        com.google.javascript.rhino.jstype.JSType jSType13 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray14 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType15 = jSTypeRegistry10.createConstructorTypeWithVarArgs(jSType13, jSTypeArray14);
        int int16 = functionType15.getMaxArguments();
        boolean boolean17 = functionType6.isSubtype((com.google.javascript.rhino.jstype.JSType) functionType15);
        com.google.javascript.rhino.jstype.JSType jSType18 = functionType6.collapseUnion();
        com.google.javascript.rhino.jstype.TemplateType templateType19 = functionType6.toMaybeTemplateType();
        com.google.javascript.rhino.JSDocInfo jSDocInfo21 = new com.google.javascript.rhino.JSDocInfo();
        boolean boolean22 = jSDocInfo21.isImplicitCast();
        try {
            templateType19.setPropertyJSDocInfo("goog.exportProperty", jSDocInfo21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(objectTypeIterable3);
        org.junit.Assert.assertNotNull(jSTypeArray5);
        org.junit.Assert.assertNotNull(functionType6);
        org.junit.Assert.assertNull(jSDocInfo7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(objectTypeIterable12);
        org.junit.Assert.assertNotNull(jSTypeArray14);
        org.junit.Assert.assertNotNull(functionType15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(jSType18);
        org.junit.Assert.assertNull(templateType19);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.block();
        java.lang.String str4 = node0.toString(false, false, false);
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.IR.stringKey("");
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable8 = node7.siblings();
        com.google.javascript.rhino.Node node11 = new com.google.javascript.rhino.Node((int) (short) 100, node7, (int) (short) 1, (int) (short) 10);
        com.google.javascript.rhino.Node node12 = node0.useSourceInfoIfMissingFrom(node11);
        boolean boolean13 = node12.hasMoreThanOneChild();
        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.IR.stringKey("");
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.IR.stringKey("");
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.IR.block();
        com.google.javascript.rhino.Node node22 = new com.google.javascript.rhino.Node((int) ' ', node16, node18, node19, 0, (int) (short) -1);
        boolean boolean23 = node16.isThrow();
        com.google.javascript.rhino.Node node24 = node16.getParent();
        try {
            com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.IR.add(node12, node16);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "BLOCK" + "'", str4.equals("BLOCK"));
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertNotNull(nodeIterable8);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(node24);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        com.google.javascript.jscomp.SourceMap.LocationMapping locationMapping2 = new com.google.javascript.jscomp.SourceMap.LocationMapping("this", "Not declared as a constructor");
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.FILEOVERVIEW_JSDOC;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.IR.stringKey("");
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable4 = node3.siblings();
        com.google.javascript.rhino.Node node7 = new com.google.javascript.rhino.Node((int) (short) 100, node3, (int) (short) 1, (int) (short) 10);
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.IR.block();
        java.lang.String str12 = node8.toString(false, false, false);
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.IR.block();
        java.lang.String str17 = node13.toString(false, false, false);
        com.google.javascript.rhino.Node node18 = node8.useSourceInfoIfMissingFrom(node13);
        try {
            com.google.javascript.rhino.Node node19 = new com.google.javascript.rhino.Node(4095, node3, node18);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: first new child has existing parent");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(nodeIterable4);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "BLOCK" + "'", str12.equals("BLOCK"));
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "BLOCK" + "'", str17.equals("BLOCK"));
        org.junit.Assert.assertNotNull(node18);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable3 = jSTypeRegistry1.getEachReferenceTypeWithProperty("goog.global");
        com.google.javascript.rhino.jstype.JSType jSType4 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray5 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType6 = jSTypeRegistry1.createConstructorTypeWithVarArgs(jSType4, jSTypeArray5);
        com.google.javascript.rhino.JSDocInfo jSDocInfo7 = functionType6.getJSDocInfo();
        boolean boolean8 = functionType6.isAllType();
        int int9 = functionType6.getMaxArguments();
        com.google.javascript.rhino.Node node10 = functionType6.getParametersNode();
        com.google.common.base.Predicate<com.google.javascript.rhino.jstype.JSType> jSTypePredicate11 = null;
        try {
            boolean boolean12 = functionType6.setValidator(jSTypePredicate11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(objectTypeIterable3);
        org.junit.Assert.assertNotNull(jSTypeArray5);
        org.junit.Assert.assertNotNull(functionType6);
        org.junit.Assert.assertNull(jSDocInfo7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(node10);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        com.google.javascript.rhino.JSDocInfo jSDocInfo0 = new com.google.javascript.rhino.JSDocInfo();
        java.util.List<com.google.javascript.rhino.JSTypeExpression> jSTypeExpressionList1 = jSDocInfo0.getImplementedInterfaces();
        java.util.Set<java.lang.String> strSet2 = jSDocInfo0.getSuppressions();
        java.lang.String str3 = jSDocInfo0.getVersion();
        boolean boolean4 = jSDocInfo0.isImplicitCast();
        java.util.List<com.google.javascript.rhino.JSTypeExpression> jSTypeExpressionList5 = jSDocInfo0.getImplementedInterfaces();
        org.junit.Assert.assertNotNull(jSTypeExpressionList1);
        org.junit.Assert.assertNotNull(strSet2);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(jSTypeExpressionList5);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.computeFunctionSideEffects = true;
        java.lang.String str3 = compilerOptions0.renamePrefix;
        boolean boolean4 = compilerOptions0.crossModuleMethodMotion;
        compilerOptions0.setRemoveAbstractMethods(true);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        java.lang.String str1 = com.google.javascript.jscomp.ProcessCommonJSModules.toModuleName("BLOCK");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "module$BLOCK" + "'", str1.equals("module$BLOCK"));
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        com.google.javascript.jscomp.SourceAst sourceAst0 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(sourceAst0, "Not declared as a constructor", true);
        try {
            compilerInput3.removeRequire("BLOCK");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Expected setCompiler to be called first: Not declared as a constructor");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.returnNode();
        boolean boolean1 = node0.isEmpty();
        int int2 = node0.getSourceOffset();
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.IR.stringKey("");
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.IR.stringKey("");
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.IR.block();
        com.google.javascript.rhino.Node node11 = new com.google.javascript.rhino.Node((int) ' ', node5, node7, node8, 0, (int) (short) -1);
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.IR.stringKey("");
        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.IR.stringKey("");
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.IR.block();
        com.google.javascript.rhino.Node node20 = new com.google.javascript.rhino.Node((int) ' ', node14, node16, node17, 0, (int) (short) -1);
        boolean boolean21 = node14.isThrow();
        int int22 = node8.getIndexOfChild(node14);
        com.google.javascript.rhino.Node node24 = com.google.javascript.rhino.IR.stringKey("");
        int int25 = node24.getLineno();
        com.google.javascript.rhino.Node node26 = com.google.javascript.rhino.IR.block();
        java.lang.String str30 = node26.toString(false, false, false);
        com.google.javascript.rhino.Node node31 = com.google.javascript.rhino.IR.block();
        java.lang.String str35 = node31.toString(false, false, false);
        com.google.javascript.rhino.Node node36 = node26.useSourceInfoIfMissingFrom(node31);
        com.google.javascript.rhino.Node node37 = node24.srcrefTree(node26);
        com.google.javascript.rhino.Node node38 = node8.useSourceInfoIfMissingFromForTree(node24);
        try {
            com.google.javascript.rhino.Node node39 = com.google.javascript.rhino.IR.sub(node0, node24);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-1) + "'", int25 == (-1));
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "BLOCK" + "'", str30.equals("BLOCK"));
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "BLOCK" + "'", str35.equals("BLOCK"));
        org.junit.Assert.assertNotNull(node36);
        org.junit.Assert.assertNotNull(node37);
        org.junit.Assert.assertNotNull(node38);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.SourceFile sourceFile3 = com.google.javascript.jscomp.SourceFile.fromFile("./");
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray4 = new com.google.javascript.jscomp.JSSourceFile[] {};
        com.google.javascript.jscomp.CompilerOptions compilerOptions5 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean6 = compilerOptions5.isExternExportsEnabled();
        com.google.javascript.jscomp.Result result7 = compiler1.compile(sourceFile3, jSSourceFileArray4, compilerOptions5);
        com.google.javascript.jscomp.SourceMap sourceMap8 = compiler1.getSourceMap();
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter9 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler1);
        com.google.javascript.jscomp.JSError jSError10 = null;
        try {
            compiler1.report(jSError10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(sourceFile3);
        org.junit.Assert.assertNotNull(jSSourceFileArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(result7);
        org.junit.Assert.assertNull(sourceMap8);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        com.google.javascript.jscomp.parsing.Config.LanguageMode languageMode1 = com.google.javascript.jscomp.parsing.Config.LanguageMode.ECMASCRIPT5_STRICT;
        com.google.javascript.jscomp.parsing.Config config3 = com.google.javascript.jscomp.parsing.ParserRunner.createConfig(true, languageMode1, true);
        java.lang.Class<?> wildcardClass4 = languageMode1.getClass();
        org.junit.Assert.assertTrue("'" + languageMode1 + "' != '" + com.google.javascript.jscomp.parsing.Config.LanguageMode.ECMASCRIPT5_STRICT + "'", languageMode1.equals(com.google.javascript.jscomp.parsing.Config.LanguageMode.ECMASCRIPT5_STRICT));
        org.junit.Assert.assertNotNull(config3);
        org.junit.Assert.assertNotNull(wildcardClass4);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newNumber(100.0d);
        org.junit.Assert.assertNotNull(node1);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        com.google.javascript.rhino.ErrorReporter errorReporter2 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry3 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter2);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable5 = jSTypeRegistry3.getEachReferenceTypeWithProperty("goog.global");
        com.google.javascript.rhino.jstype.JSType jSType6 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray7 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType8 = jSTypeRegistry3.createConstructorTypeWithVarArgs(jSType6, jSTypeArray7);
        com.google.javascript.rhino.JSDocInfo jSDocInfo9 = functionType8.getJSDocInfo();
        boolean boolean10 = functionType8.isAllType();
        com.google.javascript.rhino.ErrorReporter errorReporter11 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry12 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter11);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable14 = jSTypeRegistry12.getEachReferenceTypeWithProperty("goog.global");
        com.google.javascript.rhino.jstype.JSType jSType15 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray16 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType17 = jSTypeRegistry12.createConstructorTypeWithVarArgs(jSType15, jSTypeArray16);
        int int18 = functionType17.getMaxArguments();
        boolean boolean19 = functionType8.isSubtype((com.google.javascript.rhino.jstype.JSType) functionType17);
        com.google.javascript.rhino.ErrorReporter errorReporter21 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry22 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter21);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable24 = jSTypeRegistry22.getEachReferenceTypeWithProperty("goog.global");
        com.google.javascript.rhino.jstype.JSType jSType25 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray26 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType27 = jSTypeRegistry22.createConstructorTypeWithVarArgs(jSType25, jSTypeArray26);
        com.google.javascript.rhino.JSDocInfo jSDocInfo28 = functionType27.getJSDocInfo();
        boolean boolean29 = functionType27.isAllType();
        int int30 = functionType27.getMaxArguments();
        com.google.javascript.rhino.Node node31 = com.google.javascript.rhino.IR.trueNode();
        java.lang.String str32 = node31.getSourceFileName();
        boolean boolean33 = node31.isOr();
        boolean boolean34 = functionType17.defineInferredProperty("hi!", (com.google.javascript.rhino.jstype.JSType) functionType27, node31);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray36 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType37 = jSTypeRegistry1.createConstructorType((com.google.javascript.rhino.jstype.JSType) functionType27, false, jSTypeArray36);
        com.google.javascript.rhino.ErrorReporter errorReporter38 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry39 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter38);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable41 = jSTypeRegistry39.getEachReferenceTypeWithProperty("goog.global");
        com.google.javascript.rhino.jstype.JSType jSType42 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray43 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType44 = jSTypeRegistry39.createConstructorTypeWithVarArgs(jSType42, jSTypeArray43);
        com.google.javascript.rhino.JSDocInfo jSDocInfo45 = functionType44.getJSDocInfo();
        boolean boolean46 = functionType44.isAllType();
        com.google.javascript.rhino.ErrorReporter errorReporter47 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry48 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter47);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable50 = jSTypeRegistry48.getEachReferenceTypeWithProperty("goog.global");
        com.google.javascript.rhino.jstype.JSType jSType51 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray52 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType53 = jSTypeRegistry48.createConstructorTypeWithVarArgs(jSType51, jSTypeArray52);
        int int54 = functionType53.getMaxArguments();
        boolean boolean55 = functionType44.isSubtype((com.google.javascript.rhino.jstype.JSType) functionType53);
        java.io.PrintStream printStream56 = null;
        com.google.javascript.jscomp.Compiler compiler57 = new com.google.javascript.jscomp.Compiler(printStream56);
        com.google.javascript.jscomp.NodeTraversal.Callback callback58 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal59 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler57, callback58);
        boolean boolean60 = functionType44.equals((java.lang.Object) nodeTraversal59);
        com.google.javascript.rhino.jstype.JSType jSType61 = jSTypeRegistry1.createOptionalNullableType((com.google.javascript.rhino.jstype.JSType) functionType44);
        java.lang.String str62 = functionType44.getDisplayName();
        org.junit.Assert.assertNotNull(objectTypeIterable5);
        org.junit.Assert.assertNotNull(jSTypeArray7);
        org.junit.Assert.assertNotNull(functionType8);
        org.junit.Assert.assertNull(jSDocInfo9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(objectTypeIterable14);
        org.junit.Assert.assertNotNull(jSTypeArray16);
        org.junit.Assert.assertNotNull(functionType17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(objectTypeIterable24);
        org.junit.Assert.assertNotNull(jSTypeArray26);
        org.junit.Assert.assertNotNull(functionType27);
        org.junit.Assert.assertNull(jSDocInfo28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertNull(str32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertNotNull(jSTypeArray36);
        org.junit.Assert.assertNotNull(functionType37);
        org.junit.Assert.assertNotNull(objectTypeIterable41);
        org.junit.Assert.assertNotNull(jSTypeArray43);
        org.junit.Assert.assertNotNull(functionType44);
        org.junit.Assert.assertNull(jSDocInfo45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(objectTypeIterable50);
        org.junit.Assert.assertNotNull(jSTypeArray52);
        org.junit.Assert.assertNotNull(functionType53);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 0 + "'", int54 == 0);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + true + "'", boolean55 == true);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertNotNull(jSType61);
        org.junit.Assert.assertNull(str62);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable3 = jSTypeRegistry1.getEachReferenceTypeWithProperty("goog.global");
        com.google.javascript.rhino.jstype.JSType jSType4 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray5 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType6 = jSTypeRegistry1.createConstructorTypeWithVarArgs(jSType4, jSTypeArray5);
        com.google.javascript.rhino.JSDocInfo jSDocInfo7 = functionType6.getJSDocInfo();
        boolean boolean8 = functionType6.isAllType();
        com.google.javascript.rhino.ErrorReporter errorReporter9 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry10 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter9);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable12 = jSTypeRegistry10.getEachReferenceTypeWithProperty("goog.global");
        com.google.javascript.rhino.jstype.JSType jSType13 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray14 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType15 = jSTypeRegistry10.createConstructorTypeWithVarArgs(jSType13, jSTypeArray14);
        int int16 = functionType15.getMaxArguments();
        boolean boolean17 = functionType6.isSubtype((com.google.javascript.rhino.jstype.JSType) functionType15);
        com.google.javascript.rhino.jstype.JSType jSType18 = functionType6.collapseUnion();
        java.lang.String str19 = jSType18.toString();
        org.junit.Assert.assertNotNull(objectTypeIterable3);
        org.junit.Assert.assertNotNull(jSTypeArray5);
        org.junit.Assert.assertNotNull(functionType6);
        org.junit.Assert.assertNull(jSDocInfo7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(objectTypeIterable12);
        org.junit.Assert.assertNotNull(jSTypeArray14);
        org.junit.Assert.assertNotNull(functionType15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(jSType18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "function (new:{...}): ?" + "'", str19.equals("function (new:{...}): ?"));
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable3 = jSTypeRegistry1.getEachReferenceTypeWithProperty("goog.global");
        com.google.javascript.rhino.jstype.JSType jSType4 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray5 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType6 = jSTypeRegistry1.createConstructorTypeWithVarArgs(jSType4, jSTypeArray5);
        com.google.javascript.rhino.JSDocInfo jSDocInfo7 = functionType6.getJSDocInfo();
        boolean boolean8 = functionType6.isAllType();
        int int9 = functionType6.getMaxArguments();
        com.google.javascript.rhino.Node node10 = functionType6.getParametersNode();
        boolean boolean11 = functionType6.isNumberObjectType();
        boolean boolean12 = functionType6.hasCachedValues();
        org.junit.Assert.assertNotNull(objectTypeIterable3);
        org.junit.Assert.assertNotNull(jSTypeArray5);
        org.junit.Assert.assertNotNull(functionType6);
        org.junit.Assert.assertNull(jSDocInfo7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        com.google.javascript.rhino.ErrorReporter errorReporter2 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry3 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter2);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable5 = jSTypeRegistry3.getEachReferenceTypeWithProperty("goog.global");
        com.google.javascript.rhino.jstype.JSType jSType6 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray7 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType8 = jSTypeRegistry3.createConstructorTypeWithVarArgs(jSType6, jSTypeArray7);
        com.google.javascript.rhino.JSDocInfo jSDocInfo9 = functionType8.getJSDocInfo();
        boolean boolean10 = functionType8.isAllType();
        com.google.javascript.rhino.ErrorReporter errorReporter11 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry12 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter11);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable14 = jSTypeRegistry12.getEachReferenceTypeWithProperty("goog.global");
        com.google.javascript.rhino.jstype.JSType jSType15 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray16 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType17 = jSTypeRegistry12.createConstructorTypeWithVarArgs(jSType15, jSTypeArray16);
        int int18 = functionType17.getMaxArguments();
        boolean boolean19 = functionType8.isSubtype((com.google.javascript.rhino.jstype.JSType) functionType17);
        com.google.javascript.rhino.ErrorReporter errorReporter21 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry22 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter21);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable24 = jSTypeRegistry22.getEachReferenceTypeWithProperty("goog.global");
        com.google.javascript.rhino.jstype.JSType jSType25 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray26 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType27 = jSTypeRegistry22.createConstructorTypeWithVarArgs(jSType25, jSTypeArray26);
        com.google.javascript.rhino.JSDocInfo jSDocInfo28 = functionType27.getJSDocInfo();
        boolean boolean29 = functionType27.isAllType();
        int int30 = functionType27.getMaxArguments();
        com.google.javascript.rhino.Node node31 = com.google.javascript.rhino.IR.trueNode();
        java.lang.String str32 = node31.getSourceFileName();
        boolean boolean33 = node31.isOr();
        boolean boolean34 = functionType17.defineInferredProperty("hi!", (com.google.javascript.rhino.jstype.JSType) functionType27, node31);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray36 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType37 = jSTypeRegistry1.createConstructorType((com.google.javascript.rhino.jstype.JSType) functionType27, false, jSTypeArray36);
        com.google.javascript.rhino.ErrorReporter errorReporter38 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry39 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter38);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable41 = jSTypeRegistry39.getEachReferenceTypeWithProperty("goog.global");
        com.google.javascript.rhino.jstype.JSType jSType42 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray43 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType44 = jSTypeRegistry39.createConstructorTypeWithVarArgs(jSType42, jSTypeArray43);
        com.google.javascript.rhino.JSDocInfo jSDocInfo45 = functionType44.getJSDocInfo();
        boolean boolean46 = functionType44.isAllType();
        com.google.javascript.rhino.ErrorReporter errorReporter47 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry48 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter47);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable50 = jSTypeRegistry48.getEachReferenceTypeWithProperty("goog.global");
        com.google.javascript.rhino.jstype.JSType jSType51 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray52 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType53 = jSTypeRegistry48.createConstructorTypeWithVarArgs(jSType51, jSTypeArray52);
        int int54 = functionType53.getMaxArguments();
        boolean boolean55 = functionType44.isSubtype((com.google.javascript.rhino.jstype.JSType) functionType53);
        java.io.PrintStream printStream56 = null;
        com.google.javascript.jscomp.Compiler compiler57 = new com.google.javascript.jscomp.Compiler(printStream56);
        com.google.javascript.jscomp.NodeTraversal.Callback callback58 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal59 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler57, callback58);
        boolean boolean60 = functionType44.equals((java.lang.Object) nodeTraversal59);
        com.google.javascript.rhino.jstype.JSType jSType61 = jSTypeRegistry1.createOptionalNullableType((com.google.javascript.rhino.jstype.JSType) functionType44);
        boolean boolean62 = jSType61.isEmptyType();
        boolean boolean63 = jSType61.isNumberObjectType();
        org.junit.Assert.assertNotNull(objectTypeIterable5);
        org.junit.Assert.assertNotNull(jSTypeArray7);
        org.junit.Assert.assertNotNull(functionType8);
        org.junit.Assert.assertNull(jSDocInfo9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(objectTypeIterable14);
        org.junit.Assert.assertNotNull(jSTypeArray16);
        org.junit.Assert.assertNotNull(functionType17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(objectTypeIterable24);
        org.junit.Assert.assertNotNull(jSTypeArray26);
        org.junit.Assert.assertNotNull(functionType27);
        org.junit.Assert.assertNull(jSDocInfo28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertNull(str32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertNotNull(jSTypeArray36);
        org.junit.Assert.assertNotNull(functionType37);
        org.junit.Assert.assertNotNull(objectTypeIterable41);
        org.junit.Assert.assertNotNull(jSTypeArray43);
        org.junit.Assert.assertNotNull(functionType44);
        org.junit.Assert.assertNull(jSDocInfo45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(objectTypeIterable50);
        org.junit.Assert.assertNotNull(jSTypeArray52);
        org.junit.Assert.assertNotNull(functionType53);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 0 + "'", int54 == 0);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + true + "'", boolean55 == true);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertNotNull(jSType61);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable3 = jSTypeRegistry1.getEachReferenceTypeWithProperty("goog.global");
        com.google.javascript.rhino.jstype.JSType jSType4 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray5 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType6 = jSTypeRegistry1.createConstructorTypeWithVarArgs(jSType4, jSTypeArray5);
        com.google.javascript.rhino.JSDocInfo jSDocInfo7 = functionType6.getJSDocInfo();
        boolean boolean8 = functionType6.isAllType();
        com.google.javascript.rhino.ErrorReporter errorReporter9 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry10 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter9);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable12 = jSTypeRegistry10.getEachReferenceTypeWithProperty("goog.global");
        com.google.javascript.rhino.jstype.JSType jSType13 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray14 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType15 = jSTypeRegistry10.createConstructorTypeWithVarArgs(jSType13, jSTypeArray14);
        int int16 = functionType15.getMaxArguments();
        boolean boolean17 = functionType6.isSubtype((com.google.javascript.rhino.jstype.JSType) functionType15);
        java.io.PrintStream printStream18 = null;
        com.google.javascript.jscomp.Compiler compiler19 = new com.google.javascript.jscomp.Compiler(printStream18);
        com.google.javascript.jscomp.NodeTraversal.Callback callback20 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal21 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler19, callback20);
        boolean boolean22 = functionType6.equals((java.lang.Object) nodeTraversal21);
        boolean boolean23 = functionType6.isUnknownType();
        boolean boolean24 = functionType6.isNativeObjectType();
        org.junit.Assert.assertNotNull(objectTypeIterable3);
        org.junit.Assert.assertNotNull(jSTypeArray5);
        org.junit.Assert.assertNotNull(functionType6);
        org.junit.Assert.assertNull(jSDocInfo7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(objectTypeIterable12);
        org.junit.Assert.assertNotNull(jSTypeArray14);
        org.junit.Assert.assertNotNull(functionType15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.SourceFile sourceFile3 = com.google.javascript.jscomp.SourceFile.fromFile("./");
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray4 = new com.google.javascript.jscomp.JSSourceFile[] {};
        com.google.javascript.jscomp.CompilerOptions compilerOptions5 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean6 = compilerOptions5.isExternExportsEnabled();
        com.google.javascript.jscomp.Result result7 = compiler1.compile(sourceFile3, jSSourceFileArray4, compilerOptions5);
        com.google.javascript.jscomp.SourceFile sourceFile9 = com.google.javascript.jscomp.SourceFile.fromFile("./");
        java.lang.String str10 = sourceFile9.getOriginalPath();
        java.io.PrintStream printStream11 = null;
        com.google.javascript.jscomp.Compiler compiler12 = new com.google.javascript.jscomp.Compiler(printStream11);
        com.google.javascript.jscomp.SourceFile sourceFile14 = com.google.javascript.jscomp.SourceFile.fromFile("./");
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray15 = new com.google.javascript.jscomp.JSSourceFile[] {};
        com.google.javascript.jscomp.CompilerOptions compilerOptions16 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean17 = compilerOptions16.isExternExportsEnabled();
        com.google.javascript.jscomp.Result result18 = compiler12.compile(sourceFile14, jSSourceFileArray15, compilerOptions16);
        com.google.javascript.jscomp.CompilerOptions compilerOptions19 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions19.computeFunctionSideEffects = true;
        boolean boolean22 = compilerOptions19.isRemoveUnusedClassProperties();
        com.google.javascript.jscomp.ErrorHandler errorHandler23 = null;
        compilerOptions19.setErrorHandler(errorHandler23);
        java.util.List<com.google.javascript.jscomp.SourceMap.LocationMapping> locationMappingList25 = compilerOptions19.sourceMapLocationMappings;
        com.google.javascript.jscomp.CheckLevel checkLevel26 = com.google.javascript.jscomp.CheckLevel.ERROR;
        compilerOptions19.setCheckProvides(checkLevel26);
        compilerOptions19.setSourceMapOutputPath("hi!");
        try {
            com.google.javascript.jscomp.Result result30 = compiler1.compile(sourceFile9, jSSourceFileArray15, compilerOptions19);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(sourceFile3);
        org.junit.Assert.assertNotNull(jSSourceFileArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(result7);
        org.junit.Assert.assertNotNull(sourceFile9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "." + "'", str10.equals("."));
        org.junit.Assert.assertNotNull(sourceFile14);
        org.junit.Assert.assertNotNull(jSSourceFileArray15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(result18);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(locationMappingList25);
        org.junit.Assert.assertTrue("'" + checkLevel26 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel26.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.U2U_CONSTRUCTOR_TYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.U2U_CONSTRUCTOR_TYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.U2U_CONSTRUCTOR_TYPE));
    }

//    @Test
//    public void test157() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test157");
//        java.lang.String str0 = com.google.javascript.jscomp.Compiler.getReleaseDate();
//        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "2019/06/10 13:01" + "'", str0.equals("2019/06/10 13:01"));
//    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.IR.stringKey("");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.IR.stringKey("");
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.IR.block();
        com.google.javascript.rhino.Node node8 = new com.google.javascript.rhino.Node((int) ' ', node2, node4, node5, 0, (int) (short) -1);
        com.google.javascript.rhino.Node node9 = node5.getFirstChild();
        com.google.javascript.rhino.ErrorReporter errorReporter10 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry11 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter10);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable13 = jSTypeRegistry11.getEachReferenceTypeWithProperty("goog.global");
        com.google.javascript.rhino.jstype.JSType jSType14 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray15 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType16 = jSTypeRegistry11.createConstructorTypeWithVarArgs(jSType14, jSTypeArray15);
        com.google.javascript.rhino.JSDocInfo jSDocInfo17 = functionType16.getJSDocInfo();
        boolean boolean18 = functionType16.isAllType();
        int int19 = functionType16.getMaxArguments();
        com.google.javascript.rhino.Node node20 = functionType16.getParametersNode();
        com.google.javascript.rhino.Node node22 = com.google.javascript.rhino.IR.stringKey("");
        int int23 = node22.getLineno();
        com.google.javascript.rhino.Node node24 = com.google.javascript.rhino.IR.block();
        java.lang.String str28 = node24.toString(false, false, false);
        com.google.javascript.rhino.Node node29 = com.google.javascript.rhino.IR.block();
        java.lang.String str33 = node29.toString(false, false, false);
        com.google.javascript.rhino.Node node34 = node24.useSourceInfoIfMissingFrom(node29);
        com.google.javascript.rhino.Node node35 = node22.srcrefTree(node24);
        boolean boolean36 = node35.isSwitch();
        boolean boolean37 = node35.isSwitch();
        try {
            com.google.javascript.rhino.Node node38 = com.google.javascript.rhino.IR.forIn(node9, node20, node35);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNull(node9);
        org.junit.Assert.assertNotNull(objectTypeIterable13);
        org.junit.Assert.assertNotNull(jSTypeArray15);
        org.junit.Assert.assertNotNull(functionType16);
        org.junit.Assert.assertNull(jSDocInfo17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "BLOCK" + "'", str28.equals("BLOCK"));
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "BLOCK" + "'", str33.equals("BLOCK"));
        org.junit.Assert.assertNotNull(node34);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable3 = jSTypeRegistry1.getEachReferenceTypeWithProperty("goog.global");
        com.google.javascript.rhino.jstype.JSType jSType4 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray5 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType6 = jSTypeRegistry1.createConstructorTypeWithVarArgs(jSType4, jSTypeArray5);
        java.lang.Iterable<com.google.javascript.rhino.jstype.JSType> jSTypeIterable8 = jSTypeRegistry1.getTypesWithProperty("Not declared as a constructor");
        jSTypeRegistry1.clearTemplateTypeNames();
        org.junit.Assert.assertNotNull(objectTypeIterable3);
        org.junit.Assert.assertNotNull(jSTypeArray5);
        org.junit.Assert.assertNotNull(functionType6);
        org.junit.Assert.assertNotNull(jSTypeIterable8);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        com.google.javascript.rhino.JSDocInfo jSDocInfo0 = new com.google.javascript.rhino.JSDocInfo();
        java.util.List<com.google.javascript.rhino.JSTypeExpression> jSTypeExpressionList1 = jSDocInfo0.getImplementedInterfaces();
        boolean boolean3 = jSDocInfo0.hasDescriptionForParameter("./");
        java.lang.String str4 = jSDocInfo0.getOriginalCommentString();
        org.junit.Assert.assertNotNull(jSTypeExpressionList1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.block();
        java.lang.String str4 = node0.toString(false, false, false);
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.IR.block();
        java.lang.String str9 = node5.toString(false, false, false);
        com.google.javascript.rhino.Node node10 = node0.useSourceInfoIfMissingFrom(node5);
        boolean boolean11 = node10.isSwitch();
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "BLOCK" + "'", str4.equals("BLOCK"));
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "BLOCK" + "'", str9.equals("BLOCK"));
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.computeFunctionSideEffects = true;
        boolean boolean3 = compilerOptions0.removeUnusedVars;
        java.lang.String[] strArray15 = new java.lang.String[] { "InputId: Not declared as a constructor", ".", "BLOCK", "InputId: Not declared as a constructor", "Not declared as a constructor", "module$hi!", ".", "JSDocInfo", "module$hi!", ".", "hi!" };
        java.util.LinkedHashSet<java.lang.String> strSet16 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean17 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet16, strArray15);
        compilerOptions0.setIdGenerators((java.util.Set<java.lang.String>) strSet16);
        compilerOptions0.setInlineLocalFunctions(true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(strArray15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        int int0 = com.google.javascript.rhino.Node.FLAG_NO_THROWS;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 8 + "'", int0 == 8);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.ACCESS_CONTROLS;
        com.google.javascript.jscomp.CheckLevel checkLevel1 = com.google.javascript.jscomp.CheckLevel.ERROR;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard2 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup0, checkLevel1);
        com.google.javascript.jscomp.DiagnosticGroups.UNDEFINED_NAMES = diagnosticGroup0;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.returnNode();
        java.util.Set<java.lang.String> strSet1 = node0.getDirectives();
        boolean boolean2 = node0.isParamList();
        try {
            double double3 = node0.getDouble();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: RETURN is not a number node");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertNull(strSet1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        int int0 = com.google.javascript.rhino.Node.OPT_ARG_NAME;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 37 + "'", int0 == 37);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.continueNode();
        com.google.javascript.rhino.Node node4 = new com.google.javascript.rhino.Node(10, node1, 35, 0);
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.IR.block();
        java.lang.String str9 = node5.toString(false, false, false);
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.IR.stringKey("");
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable13 = node12.siblings();
        com.google.javascript.rhino.Node node16 = new com.google.javascript.rhino.Node((int) (short) 100, node12, (int) (short) 1, (int) (short) 10);
        com.google.javascript.rhino.Node node17 = node5.useSourceInfoIfMissingFrom(node16);
        boolean boolean18 = node1.isEquivalentTo(node17);
        com.google.javascript.rhino.InputId inputId19 = com.google.javascript.jscomp.NodeUtil.getInputId(node17);
        try {
            com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.IR.throwNode(node17);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "BLOCK" + "'", str9.equals("BLOCK"));
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(nodeIterable13);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNull(inputId19);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        java.lang.String[] strArray5 = new java.lang.String[] { "module$hi!", "", "hi!" };
        java.util.ArrayList<java.lang.String> strList6 = new java.util.ArrayList<java.lang.String>();
        boolean boolean7 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strList6, strArray5);
        java.lang.String[] strArray18 = new java.lang.String[] { "Not declared as a constructor", "InputId: Not declared as a constructor", "goog.global", "./", "./", "BLOCK", "Not declared as a constructor", "JSDocInfo", "InputId: Not declared as a constructor", "" };
        java.util.ArrayList<java.lang.String> strList19 = new java.util.ArrayList<java.lang.String>();
        boolean boolean20 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strList19, strArray18);
        com.google.javascript.jscomp.deps.SimpleDependencyInfo simpleDependencyInfo21 = new com.google.javascript.jscomp.deps.SimpleDependencyInfo("this", "BLOCK", (java.util.List<java.lang.String>) strList6, (java.util.List<java.lang.String>) strList19);
        java.lang.String str22 = simpleDependencyInfo21.getName();
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(strArray18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "BLOCK" + "'", str22.equals("BLOCK"));
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        int int0 = com.google.javascript.rhino.Node.FLAG_LOCAL_RESULTS;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 16 + "'", int0 == 16);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        int int1 = com.google.javascript.jscomp.NodeUtil.getInverseOperator(4095);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable3 = jSTypeRegistry1.getEachReferenceTypeWithProperty("goog.global");
        com.google.javascript.rhino.jstype.JSType jSType4 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray5 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType6 = jSTypeRegistry1.createConstructorTypeWithVarArgs(jSType4, jSTypeArray5);
        com.google.javascript.rhino.JSDocInfo jSDocInfo7 = functionType6.getJSDocInfo();
        boolean boolean8 = functionType6.isAllType();
        int int9 = functionType6.getMaxArguments();
        com.google.javascript.rhino.Node node10 = functionType6.getParametersNode();
        try {
            com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.IR.voidNode(node10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(objectTypeIterable3);
        org.junit.Assert.assertNotNull(jSTypeArray5);
        org.junit.Assert.assertNotNull(functionType6);
        org.junit.Assert.assertNull(jSDocInfo7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(node10);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.computeFunctionSideEffects = true;
        boolean boolean3 = compilerOptions0.isRemoveUnusedClassProperties();
        com.google.javascript.jscomp.ErrorHandler errorHandler4 = null;
        compilerOptions0.setErrorHandler(errorHandler4);
        java.util.List<com.google.javascript.jscomp.SourceMap.LocationMapping> locationMappingList6 = compilerOptions0.sourceMapLocationMappings;
        com.google.javascript.jscomp.CheckLevel checkLevel7 = com.google.javascript.jscomp.CheckLevel.ERROR;
        compilerOptions0.setCheckProvides(checkLevel7);
        compilerOptions0.crossModuleCodeMotion = false;
        com.google.javascript.jscomp.CompilerOptions.AliasTransformationHandler aliasTransformationHandler11 = null;
        compilerOptions0.setAliasTransformationHandler(aliasTransformationHandler11);
        com.google.javascript.jscomp.CompilerOptions compilerOptions13 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions13.computeFunctionSideEffects = true;
        boolean boolean16 = compilerOptions13.isRemoveUnusedClassProperties();
        com.google.javascript.jscomp.ErrorHandler errorHandler17 = null;
        compilerOptions13.setErrorHandler(errorHandler17);
        java.util.List<com.google.javascript.jscomp.SourceMap.LocationMapping> locationMappingList19 = compilerOptions13.sourceMapLocationMappings;
        com.google.javascript.jscomp.CheckLevel checkLevel20 = com.google.javascript.jscomp.CheckLevel.ERROR;
        compilerOptions13.setCheckProvides(checkLevel20);
        com.google.javascript.jscomp.CompilerOptions compilerOptions22 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions22.computeFunctionSideEffects = true;
        boolean boolean25 = compilerOptions22.isRemoveUnusedClassProperties();
        com.google.javascript.jscomp.ErrorHandler errorHandler26 = null;
        compilerOptions22.setErrorHandler(errorHandler26);
        java.util.List<com.google.javascript.jscomp.SourceMap.LocationMapping> locationMappingList28 = compilerOptions22.sourceMapLocationMappings;
        com.google.javascript.jscomp.CheckLevel checkLevel29 = com.google.javascript.jscomp.CheckLevel.ERROR;
        compilerOptions22.setCheckProvides(checkLevel29);
        compilerOptions13.reportMissingOverride = checkLevel29;
        compilerOptions0.brokenClosureRequiresLevel = checkLevel29;
        compilerOptions0.setRemoveUnusedLocalVars(false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(locationMappingList6);
        org.junit.Assert.assertTrue("'" + checkLevel7 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel7.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(locationMappingList19);
        org.junit.Assert.assertTrue("'" + checkLevel20 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel20.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(locationMappingList28);
        org.junit.Assert.assertTrue("'" + checkLevel29 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel29.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.ES5_STRICT;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        com.google.javascript.jscomp.SourceAst sourceAst0 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(sourceAst0, "Not declared as a constructor", true);
        com.google.javascript.jscomp.JSModule jSModule4 = compilerInput3.getModule();
        com.google.javascript.jscomp.SourceAst sourceAst5 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput8 = new com.google.javascript.jscomp.CompilerInput(sourceAst5, "JSDocInfo", false);
        com.google.javascript.jscomp.SourceAst sourceAst9 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput12 = new com.google.javascript.jscomp.CompilerInput(sourceAst9, "Not declared as a constructor", true);
        com.google.javascript.rhino.InputId inputId13 = compilerInput12.getInputId();
        com.google.javascript.jscomp.CompilerInput[] compilerInputArray14 = new com.google.javascript.jscomp.CompilerInput[] { compilerInput3, compilerInput8, compilerInput12 };
        java.util.ArrayList<com.google.javascript.jscomp.CompilerInput> compilerInputList15 = new java.util.ArrayList<com.google.javascript.jscomp.CompilerInput>();
        boolean boolean16 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.CompilerInput>) compilerInputList15, compilerInputArray14);
        try {
            com.google.javascript.jscomp.deps.SortedDependencies<com.google.javascript.jscomp.CompilerInput> compilerInputSortedDependencies17 = new com.google.javascript.jscomp.deps.SortedDependencies<com.google.javascript.jscomp.CompilerInput>((java.util.List<com.google.javascript.jscomp.CompilerInput>) compilerInputList15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Expected setCompiler to be called first: Not declared as a constructor");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(jSModule4);
        org.junit.Assert.assertNotNull(inputId13);
        org.junit.Assert.assertNotNull(compilerInputArray14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        java.lang.String[] strArray5 = new java.lang.String[] { "module$hi!", "", "hi!" };
        java.util.ArrayList<java.lang.String> strList6 = new java.util.ArrayList<java.lang.String>();
        boolean boolean7 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strList6, strArray5);
        java.lang.String[] strArray18 = new java.lang.String[] { "Not declared as a constructor", "InputId: Not declared as a constructor", "goog.global", "./", "./", "BLOCK", "Not declared as a constructor", "JSDocInfo", "InputId: Not declared as a constructor", "" };
        java.util.ArrayList<java.lang.String> strList19 = new java.util.ArrayList<java.lang.String>();
        boolean boolean20 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strList19, strArray18);
        com.google.javascript.jscomp.deps.SimpleDependencyInfo simpleDependencyInfo21 = new com.google.javascript.jscomp.deps.SimpleDependencyInfo("this", "BLOCK", (java.util.List<java.lang.String>) strList6, (java.util.List<java.lang.String>) strList19);
        java.lang.Object obj22 = null;
        boolean boolean23 = simpleDependencyInfo21.equals(obj22);
        java.lang.String str24 = simpleDependencyInfo21.getPathRelativeToClosureBase();
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(strArray18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "this" + "'", str24.equals("this"));
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_PROTOTYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_PROTOTYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_PROTOTYPE));
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        java.lang.String str1 = com.google.javascript.rhino.jstype.ObjectType.createDelegateSuffix("BLOCK");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "(BLOCK)" + "'", str1.equals("(BLOCK)"));
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = null;
        com.google.javascript.jscomp.DiagnosticGroups.EXTERNS_VALIDATION = diagnosticGroup0;
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention0 = new com.google.javascript.jscomp.GoogleCodingConvention();
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention1 = new com.google.javascript.jscomp.ClosureCodingConvention((com.google.javascript.jscomp.CodingConvention) googleCodingConvention0);
        com.google.javascript.rhino.Node node2 = null;
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship3 = googleCodingConvention0.getDelegateRelationship(node2);
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.IR.stringKey("");
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.IR.stringKey("");
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.IR.block();
        com.google.javascript.rhino.Node node12 = new com.google.javascript.rhino.Node((int) ' ', node6, node8, node9, 0, (int) (short) -1);
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.IR.stringKey("");
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.IR.stringKey("");
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.IR.block();
        com.google.javascript.rhino.Node node21 = new com.google.javascript.rhino.Node((int) ' ', node15, node17, node18, 0, (int) (short) -1);
        boolean boolean22 = node15.isThrow();
        int int23 = node9.getIndexOfChild(node15);
        com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.IR.stringKey("");
        int int26 = node25.getLineno();
        com.google.javascript.rhino.Node node27 = com.google.javascript.rhino.IR.block();
        java.lang.String str31 = node27.toString(false, false, false);
        com.google.javascript.rhino.Node node32 = com.google.javascript.rhino.IR.block();
        java.lang.String str36 = node32.toString(false, false, false);
        com.google.javascript.rhino.Node node37 = node27.useSourceInfoIfMissingFrom(node32);
        com.google.javascript.rhino.Node node38 = node25.srcrefTree(node27);
        com.google.javascript.rhino.Node node39 = node9.useSourceInfoIfMissingFromForTree(node25);
        boolean boolean40 = node39.isDec();
        try {
            boolean boolean41 = googleCodingConvention0.isVarArgsParameter(node39);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: BLOCK is not a string node");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNull(delegateRelationship3);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
        org.junit.Assert.assertNotNull(node27);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "BLOCK" + "'", str31.equals("BLOCK"));
        org.junit.Assert.assertNotNull(node32);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "BLOCK" + "'", str36.equals("BLOCK"));
        org.junit.Assert.assertNotNull(node37);
        org.junit.Assert.assertNotNull(node38);
        org.junit.Assert.assertNotNull(node39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.SourceFile sourceFile3 = com.google.javascript.jscomp.SourceFile.fromFile("./");
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray4 = new com.google.javascript.jscomp.JSSourceFile[] {};
        com.google.javascript.jscomp.CompilerOptions compilerOptions5 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean6 = compilerOptions5.isExternExportsEnabled();
        com.google.javascript.jscomp.Result result7 = compiler1.compile(sourceFile3, jSSourceFileArray4, compilerOptions5);
        com.google.javascript.jscomp.SourceMap sourceMap8 = compiler1.getSourceMap();
        java.io.PrintStream printStream9 = null;
        com.google.javascript.jscomp.Compiler compiler10 = new com.google.javascript.jscomp.Compiler(printStream9);
        com.google.javascript.jscomp.SourceFile sourceFile12 = com.google.javascript.jscomp.SourceFile.fromFile("./");
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray13 = new com.google.javascript.jscomp.JSSourceFile[] {};
        com.google.javascript.jscomp.CompilerOptions compilerOptions14 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean15 = compilerOptions14.isExternExportsEnabled();
        com.google.javascript.jscomp.Result result16 = compiler10.compile(sourceFile12, jSSourceFileArray13, compilerOptions14);
        com.google.javascript.jscomp.JSModule[] jSModuleArray17 = new com.google.javascript.jscomp.JSModule[] {};
        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList18 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
        boolean boolean19 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList18, jSModuleArray17);
        com.google.javascript.jscomp.JSModule[] jSModuleArray20 = com.google.javascript.jscomp.JSModule.sortJsModules((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList18);
        com.google.javascript.jscomp.JSModule[] jSModuleArray21 = com.google.javascript.jscomp.JSModule.sortJsModules((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList18);
        com.google.javascript.jscomp.CompilerOptions compilerOptions22 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions22.computeFunctionSideEffects = true;
        boolean boolean25 = compilerOptions22.isRemoveUnusedClassProperties();
        boolean boolean26 = compilerOptions22.isExternExportsEnabled();
        compilerOptions22.aliasKeywords = true;
        try {
            com.google.javascript.jscomp.Result result29 = compiler1.compile(jSSourceFileArray13, jSModuleArray21, compilerOptions22);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(sourceFile3);
        org.junit.Assert.assertNotNull(jSSourceFileArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(result7);
        org.junit.Assert.assertNull(sourceMap8);
        org.junit.Assert.assertNotNull(sourceFile12);
        org.junit.Assert.assertNotNull(jSSourceFileArray13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(result16);
        org.junit.Assert.assertNotNull(jSModuleArray17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(jSModuleArray20);
        org.junit.Assert.assertNotNull(jSModuleArray21);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.computeFunctionSideEffects = true;
        java.lang.String str3 = compilerOptions0.renamePrefix;
        com.google.javascript.jscomp.CheckLevel checkLevel4 = compilerOptions0.reportMissingOverride;
        compilerOptions0.lineBreak = false;
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + checkLevel4 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel4.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        int int0 = com.google.javascript.rhino.Node.ORIGINALNAME_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 40 + "'", int0 == 40);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.computeFunctionSideEffects = true;
        boolean boolean3 = compilerOptions0.isRemoveUnusedClassProperties();
        boolean boolean4 = compilerOptions0.isExternExportsEnabled();
        compilerOptions0.aliasKeywords = true;
        compilerOptions0.syntheticBlockStartMarker = "";
        compilerOptions0.recordFunctionInformation = true;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        java.util.Map<java.lang.String, java.lang.Object> strMap1 = null;
        compilerOptions0.setTweakReplacements(strMap1);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.CHECK_REGEXP;
        com.google.javascript.jscomp.DiagnosticGroups.INVALID_CASTS = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticGroups.DUPLICATE_MESSAGE = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticGroups.GLOBAL_THIS = diagnosticGroup0;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.block();
        java.lang.String str4 = node0.toString(false, false, false);
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.IR.block();
        java.lang.String str9 = node5.toString(false, false, false);
        com.google.javascript.rhino.Node node10 = node0.useSourceInfoIfMissingFrom(node5);
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.IR.stringKey("");
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.IR.stringKey("");
        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.IR.block();
        com.google.javascript.rhino.Node node19 = new com.google.javascript.rhino.Node((int) ' ', node13, node15, node16, 0, (int) (short) -1);
        com.google.javascript.rhino.Node node22 = com.google.javascript.rhino.IR.stringKey("");
        com.google.javascript.rhino.Node node24 = com.google.javascript.rhino.IR.stringKey("");
        com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.IR.block();
        com.google.javascript.rhino.Node node28 = new com.google.javascript.rhino.Node((int) ' ', node22, node24, node25, 0, (int) (short) -1);
        boolean boolean29 = node22.isThrow();
        int int30 = node16.getIndexOfChild(node22);
        com.google.javascript.rhino.Node node32 = com.google.javascript.rhino.IR.stringKey("");
        int int33 = node32.getLineno();
        com.google.javascript.rhino.Node node34 = com.google.javascript.rhino.IR.block();
        java.lang.String str38 = node34.toString(false, false, false);
        com.google.javascript.rhino.Node node39 = com.google.javascript.rhino.IR.block();
        java.lang.String str43 = node39.toString(false, false, false);
        com.google.javascript.rhino.Node node44 = node34.useSourceInfoIfMissingFrom(node39);
        com.google.javascript.rhino.Node node45 = node32.srcrefTree(node34);
        com.google.javascript.rhino.Node node46 = node16.useSourceInfoIfMissingFromForTree(node32);
        int int47 = node32.getLineno();
        com.google.javascript.rhino.Node node51 = com.google.javascript.rhino.Node.newString("InputId: Not declared as a constructor", (int) '4', (int) (byte) 100);
        com.google.javascript.rhino.Node node52 = node32.useSourceInfoIfMissingFrom(node51);
        com.google.javascript.rhino.Node[] nodeArray53 = new com.google.javascript.rhino.Node[] { node0, node32 };
        try {
            com.google.javascript.rhino.Node node54 = com.google.javascript.rhino.IR.block(nodeArray53);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "BLOCK" + "'", str4.equals("BLOCK"));
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "BLOCK" + "'", str9.equals("BLOCK"));
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
        org.junit.Assert.assertNotNull(node32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + (-1) + "'", int33 == (-1));
        org.junit.Assert.assertNotNull(node34);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "BLOCK" + "'", str38.equals("BLOCK"));
        org.junit.Assert.assertNotNull(node39);
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "BLOCK" + "'", str43.equals("BLOCK"));
        org.junit.Assert.assertNotNull(node44);
        org.junit.Assert.assertNotNull(node45);
        org.junit.Assert.assertNotNull(node46);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + (-1) + "'", int47 == (-1));
        org.junit.Assert.assertNotNull(node51);
        org.junit.Assert.assertNotNull(node52);
        org.junit.Assert.assertNotNull(nodeArray53);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.IR.stringKey("");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.IR.stringKey("");
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.IR.block();
        com.google.javascript.rhino.Node node8 = new com.google.javascript.rhino.Node((int) ' ', node2, node4, node5, 0, (int) (short) -1);
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.IR.stringKey("");
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.IR.stringKey("");
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.IR.block();
        com.google.javascript.rhino.Node node17 = new com.google.javascript.rhino.Node((int) ' ', node11, node13, node14, 0, (int) (short) -1);
        boolean boolean18 = node11.isThrow();
        int int19 = node5.getIndexOfChild(node11);
        com.google.javascript.rhino.Node node21 = com.google.javascript.rhino.IR.stringKey("");
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable22 = node21.siblings();
        boolean boolean23 = node21.isIn();
        com.google.javascript.rhino.Node node26 = com.google.javascript.rhino.IR.stringKey("");
        com.google.javascript.rhino.Node node28 = com.google.javascript.rhino.IR.stringKey("");
        com.google.javascript.rhino.Node node29 = com.google.javascript.rhino.IR.block();
        com.google.javascript.rhino.Node node32 = new com.google.javascript.rhino.Node((int) ' ', node26, node28, node29, 0, (int) (short) -1);
        com.google.javascript.rhino.Node node35 = com.google.javascript.rhino.IR.stringKey("");
        com.google.javascript.rhino.Node node37 = com.google.javascript.rhino.IR.stringKey("");
        com.google.javascript.rhino.Node node38 = com.google.javascript.rhino.IR.block();
        com.google.javascript.rhino.Node node41 = new com.google.javascript.rhino.Node((int) ' ', node35, node37, node38, 0, (int) (short) -1);
        boolean boolean42 = node35.isThrow();
        int int43 = node29.getIndexOfChild(node35);
        try {
            com.google.javascript.rhino.Node node44 = com.google.javascript.rhino.IR.hook(node5, node21, node29);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertNotNull(nodeIterable22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertNotNull(node37);
        org.junit.Assert.assertNotNull(node38);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + (-1) + "'", int43 == (-1));
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.computeFunctionSideEffects = true;
        boolean boolean3 = compilerOptions0.isRemoveUnusedClassProperties();
        com.google.javascript.jscomp.ErrorHandler errorHandler4 = null;
        compilerOptions0.setErrorHandler(errorHandler4);
        java.util.List<com.google.javascript.jscomp.SourceMap.LocationMapping> locationMappingList6 = compilerOptions0.sourceMapLocationMappings;
        com.google.javascript.jscomp.CheckLevel checkLevel7 = com.google.javascript.jscomp.CheckLevel.ERROR;
        compilerOptions0.setCheckProvides(checkLevel7);
        java.lang.String[] strArray14 = new java.lang.String[] { "module$hi!", "", "hi!" };
        java.util.ArrayList<java.lang.String> strList15 = new java.util.ArrayList<java.lang.String>();
        boolean boolean16 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strList15, strArray14);
        java.lang.String[] strArray27 = new java.lang.String[] { "Not declared as a constructor", "InputId: Not declared as a constructor", "goog.global", "./", "./", "BLOCK", "Not declared as a constructor", "JSDocInfo", "InputId: Not declared as a constructor", "" };
        java.util.ArrayList<java.lang.String> strList28 = new java.util.ArrayList<java.lang.String>();
        boolean boolean29 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strList28, strArray27);
        com.google.javascript.jscomp.deps.SimpleDependencyInfo simpleDependencyInfo30 = new com.google.javascript.jscomp.deps.SimpleDependencyInfo("this", "BLOCK", (java.util.List<java.lang.String>) strList15, (java.util.List<java.lang.String>) strList28);
        compilerOptions0.setManageClosureDependencies((java.util.List<java.lang.String>) strList15);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(locationMappingList6);
        org.junit.Assert.assertTrue("'" + checkLevel7 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel7.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(strArray14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(strArray27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.NodeTraversal.Callback callback2 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal3 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler1, callback2);
        java.lang.String str4 = compiler1.getAstDotGraph();
        com.google.javascript.jscomp.CompilerOptions compilerOptions5 = null;
        try {
            compiler1.initOptions(compilerOptions5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.stringKey("");
        int int2 = node1.getLineno();
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.IR.block();
        java.lang.String str7 = node3.toString(false, false, false);
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.IR.block();
        java.lang.String str12 = node8.toString(false, false, false);
        com.google.javascript.rhino.Node node13 = node3.useSourceInfoIfMissingFrom(node8);
        com.google.javascript.rhino.Node node14 = node1.srcrefTree(node3);
        boolean boolean15 = node14.isSwitch();
        try {
            com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.IR.returnNode(node14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "BLOCK" + "'", str7.equals("BLOCK"));
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "BLOCK" + "'", str12.equals("BLOCK"));
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.IR.stringKey("");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.IR.stringKey("");
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.IR.block();
        com.google.javascript.rhino.Node node8 = new com.google.javascript.rhino.Node((int) ' ', node2, node4, node5, 0, (int) (short) -1);
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.IR.stringKey("");
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.IR.stringKey("");
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.IR.block();
        com.google.javascript.rhino.Node node17 = new com.google.javascript.rhino.Node((int) ' ', node11, node13, node14, 0, (int) (short) -1);
        boolean boolean18 = node11.isThrow();
        int int19 = node5.getIndexOfChild(node11);
        com.google.javascript.rhino.Node node21 = com.google.javascript.rhino.IR.stringKey("");
        int int22 = node21.getLineno();
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.IR.block();
        java.lang.String str27 = node23.toString(false, false, false);
        com.google.javascript.rhino.Node node28 = com.google.javascript.rhino.IR.block();
        java.lang.String str32 = node28.toString(false, false, false);
        com.google.javascript.rhino.Node node33 = node23.useSourceInfoIfMissingFrom(node28);
        com.google.javascript.rhino.Node node34 = node21.srcrefTree(node23);
        com.google.javascript.rhino.Node node35 = node5.useSourceInfoIfMissingFromForTree(node21);
        int int36 = node21.getLineno();
        com.google.javascript.rhino.Node node40 = com.google.javascript.rhino.Node.newString("InputId: Not declared as a constructor", (int) '4', (int) (byte) 100);
        com.google.javascript.rhino.Node node41 = node21.useSourceInfoIfMissingFrom(node40);
        int int42 = node40.getCharno();
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "BLOCK" + "'", str27.equals("BLOCK"));
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "BLOCK" + "'", str32.equals("BLOCK"));
        org.junit.Assert.assertNotNull(node33);
        org.junit.Assert.assertNotNull(node34);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + (-1) + "'", int36 == (-1));
        org.junit.Assert.assertNotNull(node40);
        org.junit.Assert.assertNotNull(node41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 100 + "'", int42 == 100);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.computeFunctionSideEffects = true;
        boolean boolean3 = compilerOptions0.isRemoveUnusedClassProperties();
        com.google.javascript.jscomp.ErrorHandler errorHandler4 = null;
        compilerOptions0.setErrorHandler(errorHandler4);
        compilerOptions0.setColorizeErrorOutput(true);
        compilerOptions0.setCollapseProperties(false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable3 = jSTypeRegistry1.getEachReferenceTypeWithProperty("goog.global");
        com.google.javascript.rhino.jstype.JSType jSType4 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray5 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType6 = jSTypeRegistry1.createConstructorTypeWithVarArgs(jSType4, jSTypeArray5);
        com.google.javascript.rhino.ErrorReporter errorReporter7 = jSTypeRegistry1.getErrorReporter();
        com.google.javascript.rhino.ErrorReporter errorReporter8 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry9 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter8);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable11 = jSTypeRegistry9.getEachReferenceTypeWithProperty("goog.global");
        com.google.javascript.rhino.jstype.JSType jSType12 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray13 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType14 = jSTypeRegistry9.createConstructorTypeWithVarArgs(jSType12, jSTypeArray13);
        com.google.javascript.rhino.ErrorReporter errorReporter15 = jSTypeRegistry9.getErrorReporter();
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.IR.stringKey("");
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.IR.stringKey("");
        com.google.javascript.rhino.Node node21 = null;
        int int22 = node20.getIndexOfChild(node21);
        node18.addChildrenToBack(node20);
        com.google.javascript.rhino.Node node24 = com.google.javascript.rhino.IR.block();
        java.lang.String str28 = node24.toString(false, false, false);
        com.google.javascript.rhino.Node node31 = com.google.javascript.rhino.IR.stringKey("");
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable32 = node31.siblings();
        com.google.javascript.rhino.Node node35 = new com.google.javascript.rhino.Node((int) (short) 100, node31, (int) (short) 1, (int) (short) 10);
        com.google.javascript.rhino.Node node36 = node24.useSourceInfoIfMissingFrom(node35);
        com.google.javascript.rhino.Node node37 = node20.srcref(node24);
        com.google.javascript.rhino.ErrorReporter errorReporter38 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry39 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter38);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable41 = jSTypeRegistry39.getEachReferenceTypeWithProperty("goog.global");
        com.google.javascript.rhino.jstype.JSType jSType42 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray43 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType44 = jSTypeRegistry39.createConstructorTypeWithVarArgs(jSType42, jSTypeArray43);
        com.google.javascript.rhino.JSDocInfo jSDocInfo45 = functionType44.getJSDocInfo();
        boolean boolean46 = functionType44.isAllType();
        com.google.javascript.rhino.ErrorReporter errorReporter47 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry48 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter47);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable50 = jSTypeRegistry48.getEachReferenceTypeWithProperty("goog.global");
        com.google.javascript.rhino.jstype.JSType jSType51 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray52 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType53 = jSTypeRegistry48.createConstructorTypeWithVarArgs(jSType51, jSTypeArray52);
        int int54 = functionType53.getMaxArguments();
        boolean boolean55 = functionType44.isSubtype((com.google.javascript.rhino.jstype.JSType) functionType53);
        com.google.javascript.rhino.jstype.EnumType enumType56 = jSTypeRegistry9.createEnumType("BLOCK", node37, (com.google.javascript.rhino.jstype.JSType) functionType44);
        com.google.javascript.rhino.ErrorReporter errorReporter58 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry59 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter58);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable61 = jSTypeRegistry59.getEachReferenceTypeWithProperty("goog.global");
        com.google.javascript.rhino.jstype.JSType jSType62 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray63 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType64 = jSTypeRegistry59.createConstructorTypeWithVarArgs(jSType62, jSTypeArray63);
        com.google.javascript.rhino.JSDocInfo jSDocInfo65 = functionType64.getJSDocInfo();
        boolean boolean66 = functionType64.isAllType();
        int int67 = functionType64.getMaxArguments();
        boolean boolean68 = functionType64.hasCachedValues();
        try {
            com.google.javascript.rhino.jstype.JSType jSType69 = jSTypeRegistry1.createFromTypeNodes(node37, "module$BLOCK", (com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType>) functionType64);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Unexpected node in type expression: STRING_KEY  1");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(objectTypeIterable3);
        org.junit.Assert.assertNotNull(jSTypeArray5);
        org.junit.Assert.assertNotNull(functionType6);
        org.junit.Assert.assertNull(errorReporter7);
        org.junit.Assert.assertNotNull(objectTypeIterable11);
        org.junit.Assert.assertNotNull(jSTypeArray13);
        org.junit.Assert.assertNotNull(functionType14);
        org.junit.Assert.assertNull(errorReporter15);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "BLOCK" + "'", str28.equals("BLOCK"));
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertNotNull(nodeIterable32);
        org.junit.Assert.assertNotNull(node36);
        org.junit.Assert.assertNotNull(node37);
        org.junit.Assert.assertNotNull(objectTypeIterable41);
        org.junit.Assert.assertNotNull(jSTypeArray43);
        org.junit.Assert.assertNotNull(functionType44);
        org.junit.Assert.assertNull(jSDocInfo45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(objectTypeIterable50);
        org.junit.Assert.assertNotNull(jSTypeArray52);
        org.junit.Assert.assertNotNull(functionType53);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 0 + "'", int54 == 0);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + true + "'", boolean55 == true);
        org.junit.Assert.assertNotNull(enumType56);
        org.junit.Assert.assertNotNull(objectTypeIterable61);
        org.junit.Assert.assertNotNull(jSTypeArray63);
        org.junit.Assert.assertNotNull(functionType64);
        org.junit.Assert.assertNull(jSDocInfo65);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 0 + "'", int67 == 0);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.IR.stringKey("");
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable3 = node2.siblings();
        com.google.javascript.rhino.Node node6 = new com.google.javascript.rhino.Node((int) (short) 100, node2, (int) (short) 1, (int) (short) 10);
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.IR.returnNode();
        java.util.Set<java.lang.String> strSet8 = node7.getDirectives();
        boolean boolean9 = node7.isParamList();
        try {
            com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.IR.regexp(node2, node7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertNotNull(nodeIterable3);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertNull(strSet8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.NodeTraversal.Callback callback2 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal3 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler1, callback2);
        java.lang.String str4 = compiler1.getAstDotGraph();
        try {
            compiler1.parse();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newNumber((double) 35, 0, 47);
        try {
            com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.IR.breakNode(node3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(node3);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.IR.stringKey("");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.IR.stringKey("");
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.IR.block();
        com.google.javascript.rhino.Node node8 = new com.google.javascript.rhino.Node((int) ' ', node2, node4, node5, 0, (int) (short) -1);
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.IR.stringKey("");
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.IR.stringKey("");
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.IR.block();
        com.google.javascript.rhino.Node node17 = new com.google.javascript.rhino.Node((int) ' ', node11, node13, node14, 0, (int) (short) -1);
        boolean boolean18 = node11.isThrow();
        int int19 = node5.getIndexOfChild(node11);
        com.google.javascript.rhino.Node node21 = com.google.javascript.rhino.IR.stringKey("");
        int int22 = node21.getLineno();
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.IR.block();
        java.lang.String str27 = node23.toString(false, false, false);
        com.google.javascript.rhino.Node node28 = com.google.javascript.rhino.IR.block();
        java.lang.String str32 = node28.toString(false, false, false);
        com.google.javascript.rhino.Node node33 = node23.useSourceInfoIfMissingFrom(node28);
        com.google.javascript.rhino.Node node34 = node21.srcrefTree(node23);
        com.google.javascript.rhino.Node node35 = node5.useSourceInfoIfMissingFromForTree(node21);
        int int36 = node21.getLineno();
        com.google.javascript.rhino.Node node38 = com.google.javascript.rhino.IR.stringKey("");
        com.google.javascript.rhino.Node node39 = null;
        int int40 = node38.getIndexOfChild(node39);
        node38.setString("module$hi!");
        boolean boolean43 = node38.isStringKey();
        java.lang.String str44 = node38.getSourceFileName();
        try {
            com.google.javascript.rhino.Node node45 = com.google.javascript.rhino.IR.catchNode(node21, node38);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "BLOCK" + "'", str27.equals("BLOCK"));
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "BLOCK" + "'", str32.equals("BLOCK"));
        org.junit.Assert.assertNotNull(node33);
        org.junit.Assert.assertNotNull(node34);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + (-1) + "'", int36 == (-1));
        org.junit.Assert.assertNotNull(node38);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + (-1) + "'", int40 == (-1));
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertNull(str44);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.NodeTraversal.Callback callback2 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal3 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler1, callback2);
        java.lang.String str4 = compiler1.getAstDotGraph();
        com.google.javascript.jscomp.JSModule jSModule5 = null;
        try {
            java.lang.String str6 = compiler1.toSource(jSModule5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        com.google.javascript.rhino.ErrorReporter errorReporter2 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry3 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter2);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable5 = jSTypeRegistry3.getEachReferenceTypeWithProperty("goog.global");
        com.google.javascript.rhino.jstype.JSType jSType6 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray7 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType8 = jSTypeRegistry3.createConstructorTypeWithVarArgs(jSType6, jSTypeArray7);
        com.google.javascript.rhino.JSDocInfo jSDocInfo9 = functionType8.getJSDocInfo();
        boolean boolean10 = functionType8.isAllType();
        com.google.javascript.rhino.ErrorReporter errorReporter11 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry12 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter11);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable14 = jSTypeRegistry12.getEachReferenceTypeWithProperty("goog.global");
        com.google.javascript.rhino.jstype.JSType jSType15 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray16 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType17 = jSTypeRegistry12.createConstructorTypeWithVarArgs(jSType15, jSTypeArray16);
        int int18 = functionType17.getMaxArguments();
        boolean boolean19 = functionType8.isSubtype((com.google.javascript.rhino.jstype.JSType) functionType17);
        com.google.javascript.rhino.ErrorReporter errorReporter21 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry22 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter21);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable24 = jSTypeRegistry22.getEachReferenceTypeWithProperty("goog.global");
        com.google.javascript.rhino.jstype.JSType jSType25 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray26 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType27 = jSTypeRegistry22.createConstructorTypeWithVarArgs(jSType25, jSTypeArray26);
        com.google.javascript.rhino.JSDocInfo jSDocInfo28 = functionType27.getJSDocInfo();
        boolean boolean29 = functionType27.isAllType();
        int int30 = functionType27.getMaxArguments();
        com.google.javascript.rhino.Node node31 = com.google.javascript.rhino.IR.trueNode();
        java.lang.String str32 = node31.getSourceFileName();
        boolean boolean33 = node31.isOr();
        boolean boolean34 = functionType17.defineInferredProperty("hi!", (com.google.javascript.rhino.jstype.JSType) functionType27, node31);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray36 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType37 = jSTypeRegistry1.createConstructorType((com.google.javascript.rhino.jstype.JSType) functionType27, false, jSTypeArray36);
        com.google.javascript.rhino.ErrorReporter errorReporter38 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry39 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter38);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable41 = jSTypeRegistry39.getEachReferenceTypeWithProperty("goog.global");
        com.google.javascript.rhino.jstype.JSType jSType42 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray43 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType44 = jSTypeRegistry39.createConstructorTypeWithVarArgs(jSType42, jSTypeArray43);
        com.google.javascript.rhino.JSDocInfo jSDocInfo45 = functionType44.getJSDocInfo();
        boolean boolean46 = functionType44.isAllType();
        com.google.javascript.rhino.ErrorReporter errorReporter47 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry48 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter47);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable50 = jSTypeRegistry48.getEachReferenceTypeWithProperty("goog.global");
        com.google.javascript.rhino.jstype.JSType jSType51 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray52 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType53 = jSTypeRegistry48.createConstructorTypeWithVarArgs(jSType51, jSTypeArray52);
        int int54 = functionType53.getMaxArguments();
        boolean boolean55 = functionType44.isSubtype((com.google.javascript.rhino.jstype.JSType) functionType53);
        java.io.PrintStream printStream56 = null;
        com.google.javascript.jscomp.Compiler compiler57 = new com.google.javascript.jscomp.Compiler(printStream56);
        com.google.javascript.jscomp.NodeTraversal.Callback callback58 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal59 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler57, callback58);
        boolean boolean60 = functionType44.equals((java.lang.Object) nodeTraversal59);
        com.google.javascript.rhino.jstype.JSType jSType61 = jSTypeRegistry1.createOptionalNullableType((com.google.javascript.rhino.jstype.JSType) functionType44);
        boolean boolean62 = functionType44.matchesStringContext();
        org.junit.Assert.assertNotNull(objectTypeIterable5);
        org.junit.Assert.assertNotNull(jSTypeArray7);
        org.junit.Assert.assertNotNull(functionType8);
        org.junit.Assert.assertNull(jSDocInfo9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(objectTypeIterable14);
        org.junit.Assert.assertNotNull(jSTypeArray16);
        org.junit.Assert.assertNotNull(functionType17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(objectTypeIterable24);
        org.junit.Assert.assertNotNull(jSTypeArray26);
        org.junit.Assert.assertNotNull(functionType27);
        org.junit.Assert.assertNull(jSDocInfo28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertNull(str32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertNotNull(jSTypeArray36);
        org.junit.Assert.assertNotNull(functionType37);
        org.junit.Assert.assertNotNull(objectTypeIterable41);
        org.junit.Assert.assertNotNull(jSTypeArray43);
        org.junit.Assert.assertNotNull(functionType44);
        org.junit.Assert.assertNull(jSDocInfo45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(objectTypeIterable50);
        org.junit.Assert.assertNotNull(jSTypeArray52);
        org.junit.Assert.assertNotNull(functionType53);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 0 + "'", int54 == 0);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + true + "'", boolean55 == true);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertNotNull(jSType61);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.block();
        java.lang.String str4 = node0.toString(false, false, false);
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.IR.stringKey("");
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable8 = node7.siblings();
        com.google.javascript.rhino.Node node11 = new com.google.javascript.rhino.Node((int) (short) 100, node7, (int) (short) 1, (int) (short) 10);
        com.google.javascript.rhino.Node node12 = node0.useSourceInfoIfMissingFrom(node11);
        boolean boolean13 = node0.isLabel();
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "BLOCK" + "'", str4.equals("BLOCK"));
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertNotNull(nodeIterable8);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.SourceFile sourceFile3 = com.google.javascript.jscomp.SourceFile.fromFile("./");
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray4 = new com.google.javascript.jscomp.JSSourceFile[] {};
        com.google.javascript.jscomp.CompilerOptions compilerOptions5 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean6 = compilerOptions5.isExternExportsEnabled();
        com.google.javascript.jscomp.Result result7 = compiler1.compile(sourceFile3, jSSourceFileArray4, compilerOptions5);
        com.google.javascript.jscomp.SourceMap sourceMap8 = compiler1.getSourceMap();
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter9 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler1);
        boolean boolean10 = compiler1.acceptEcmaScript5();
        compiler1.rebuildInputsFromModules();
        com.google.javascript.jscomp.ErrorManager errorManager12 = null;
        try {
            compiler1.setErrorManager(errorManager12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: the error manager cannot be null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(sourceFile3);
        org.junit.Assert.assertNotNull(jSSourceFileArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(result7);
        org.junit.Assert.assertNull(sourceMap8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable3 = jSTypeRegistry1.getEachReferenceTypeWithProperty("goog.global");
        com.google.javascript.rhino.jstype.JSType jSType4 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray5 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType6 = jSTypeRegistry1.createConstructorTypeWithVarArgs(jSType4, jSTypeArray5);
        jSTypeRegistry1.clearNamedTypes();
        org.junit.Assert.assertNotNull(objectTypeIterable3);
        org.junit.Assert.assertNotNull(jSTypeArray5);
        org.junit.Assert.assertNotNull(functionType6);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.block();
        java.lang.String str4 = node0.toString(false, false, false);
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.IR.stringKey("");
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable8 = node7.siblings();
        com.google.javascript.rhino.Node node11 = new com.google.javascript.rhino.Node((int) (short) 100, node7, (int) (short) 1, (int) (short) 10);
        com.google.javascript.rhino.Node node12 = node0.useSourceInfoIfMissingFrom(node11);
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.IR.stringKey("");
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.IR.stringKey("");
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.IR.block();
        com.google.javascript.rhino.Node node21 = new com.google.javascript.rhino.Node((int) ' ', node15, node17, node18, 0, (int) (short) -1);
        com.google.javascript.rhino.Node node24 = com.google.javascript.rhino.IR.stringKey("");
        com.google.javascript.rhino.Node node26 = com.google.javascript.rhino.IR.stringKey("");
        com.google.javascript.rhino.Node node27 = com.google.javascript.rhino.IR.block();
        com.google.javascript.rhino.Node node30 = new com.google.javascript.rhino.Node((int) ' ', node24, node26, node27, 0, (int) (short) -1);
        boolean boolean31 = node24.isThrow();
        int int32 = node18.getIndexOfChild(node24);
        com.google.javascript.rhino.Node node34 = com.google.javascript.rhino.IR.stringKey("");
        int int35 = node34.getLineno();
        com.google.javascript.rhino.Node node36 = com.google.javascript.rhino.IR.block();
        java.lang.String str40 = node36.toString(false, false, false);
        com.google.javascript.rhino.Node node41 = com.google.javascript.rhino.IR.block();
        java.lang.String str45 = node41.toString(false, false, false);
        com.google.javascript.rhino.Node node46 = node36.useSourceInfoIfMissingFrom(node41);
        com.google.javascript.rhino.Node node47 = node34.srcrefTree(node36);
        com.google.javascript.rhino.Node node48 = node18.useSourceInfoIfMissingFromForTree(node34);
        try {
            com.google.javascript.rhino.Node node49 = com.google.javascript.rhino.IR.sub(node12, node34);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "BLOCK" + "'", str4.equals("BLOCK"));
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertNotNull(nodeIterable8);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertNotNull(node27);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-1) + "'", int32 == (-1));
        org.junit.Assert.assertNotNull(node34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + (-1) + "'", int35 == (-1));
        org.junit.Assert.assertNotNull(node36);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "BLOCK" + "'", str40.equals("BLOCK"));
        org.junit.Assert.assertNotNull(node41);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "BLOCK" + "'", str45.equals("BLOCK"));
        org.junit.Assert.assertNotNull(node46);
        org.junit.Assert.assertNotNull(node47);
        org.junit.Assert.assertNotNull(node48);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable3 = jSTypeRegistry1.getEachReferenceTypeWithProperty("goog.global");
        com.google.javascript.rhino.jstype.JSType jSType4 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray5 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType6 = jSTypeRegistry1.createConstructorTypeWithVarArgs(jSType4, jSTypeArray5);
        com.google.javascript.rhino.ErrorReporter errorReporter7 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry8 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter7);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable10 = jSTypeRegistry8.getEachReferenceTypeWithProperty("goog.global");
        com.google.javascript.rhino.jstype.JSType jSType11 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray12 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType13 = jSTypeRegistry8.createConstructorTypeWithVarArgs(jSType11, jSTypeArray12);
        com.google.javascript.rhino.JSDocInfo jSDocInfo14 = functionType13.getJSDocInfo();
        boolean boolean15 = functionType13.isAllType();
        com.google.javascript.rhino.ErrorReporter errorReporter16 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry17 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter16);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable19 = jSTypeRegistry17.getEachReferenceTypeWithProperty("goog.global");
        com.google.javascript.rhino.jstype.JSType jSType20 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray21 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType22 = jSTypeRegistry17.createConstructorTypeWithVarArgs(jSType20, jSTypeArray21);
        int int23 = functionType22.getMaxArguments();
        boolean boolean24 = functionType13.isSubtype((com.google.javascript.rhino.jstype.JSType) functionType22);
        com.google.javascript.rhino.jstype.JSType jSType25 = functionType13.collapseUnion();
        com.google.javascript.rhino.ErrorReporter errorReporter27 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry28 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter27);
        com.google.javascript.rhino.ErrorReporter errorReporter29 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry30 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter29);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable32 = jSTypeRegistry30.getEachReferenceTypeWithProperty("goog.global");
        com.google.javascript.rhino.jstype.JSType jSType33 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray34 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType35 = jSTypeRegistry30.createConstructorTypeWithVarArgs(jSType33, jSTypeArray34);
        com.google.javascript.rhino.JSDocInfo jSDocInfo36 = functionType35.getJSDocInfo();
        boolean boolean37 = functionType35.isAllType();
        com.google.javascript.rhino.ErrorReporter errorReporter38 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry39 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter38);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable41 = jSTypeRegistry39.getEachReferenceTypeWithProperty("goog.global");
        com.google.javascript.rhino.jstype.JSType jSType42 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray43 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType44 = jSTypeRegistry39.createConstructorTypeWithVarArgs(jSType42, jSTypeArray43);
        int int45 = functionType44.getMaxArguments();
        boolean boolean46 = functionType35.isSubtype((com.google.javascript.rhino.jstype.JSType) functionType44);
        com.google.javascript.rhino.ErrorReporter errorReporter48 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry49 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter48);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable51 = jSTypeRegistry49.getEachReferenceTypeWithProperty("goog.global");
        com.google.javascript.rhino.jstype.JSType jSType52 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray53 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType54 = jSTypeRegistry49.createConstructorTypeWithVarArgs(jSType52, jSTypeArray53);
        com.google.javascript.rhino.JSDocInfo jSDocInfo55 = functionType54.getJSDocInfo();
        boolean boolean56 = functionType54.isAllType();
        int int57 = functionType54.getMaxArguments();
        com.google.javascript.rhino.Node node58 = com.google.javascript.rhino.IR.trueNode();
        java.lang.String str59 = node58.getSourceFileName();
        boolean boolean60 = node58.isOr();
        boolean boolean61 = functionType44.defineInferredProperty("hi!", (com.google.javascript.rhino.jstype.JSType) functionType54, node58);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray63 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType64 = jSTypeRegistry28.createConstructorType((com.google.javascript.rhino.jstype.JSType) functionType54, false, jSTypeArray63);
        com.google.javascript.rhino.jstype.FunctionType functionType65 = jSTypeRegistry1.createFunctionType((com.google.javascript.rhino.jstype.JSType) functionType13, false, jSTypeArray63);
        java.lang.String str66 = functionType13.getDisplayName();
        org.junit.Assert.assertNotNull(objectTypeIterable3);
        org.junit.Assert.assertNotNull(jSTypeArray5);
        org.junit.Assert.assertNotNull(functionType6);
        org.junit.Assert.assertNotNull(objectTypeIterable10);
        org.junit.Assert.assertNotNull(jSTypeArray12);
        org.junit.Assert.assertNotNull(functionType13);
        org.junit.Assert.assertNull(jSDocInfo14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(objectTypeIterable19);
        org.junit.Assert.assertNotNull(jSTypeArray21);
        org.junit.Assert.assertNotNull(functionType22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(jSType25);
        org.junit.Assert.assertNotNull(objectTypeIterable32);
        org.junit.Assert.assertNotNull(jSTypeArray34);
        org.junit.Assert.assertNotNull(functionType35);
        org.junit.Assert.assertNull(jSDocInfo36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(objectTypeIterable41);
        org.junit.Assert.assertNotNull(jSTypeArray43);
        org.junit.Assert.assertNotNull(functionType44);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 0 + "'", int45 == 0);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
        org.junit.Assert.assertNotNull(objectTypeIterable51);
        org.junit.Assert.assertNotNull(jSTypeArray53);
        org.junit.Assert.assertNotNull(functionType54);
        org.junit.Assert.assertNull(jSDocInfo55);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 0 + "'", int57 == 0);
        org.junit.Assert.assertNotNull(node58);
        org.junit.Assert.assertNull(str59);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + true + "'", boolean61 == true);
        org.junit.Assert.assertNotNull(jSTypeArray63);
        org.junit.Assert.assertNotNull(functionType64);
        org.junit.Assert.assertNotNull(functionType65);
        org.junit.Assert.assertNull(str66);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString("goog.global", 53, 0);
        com.google.javascript.jscomp.CompilerOptions compilerOptions5 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions5.computeFunctionSideEffects = true;
        java.lang.String str8 = compilerOptions5.renamePrefix;
        com.google.javascript.jscomp.CheckLevel checkLevel9 = compilerOptions5.reportMissingOverride;
        com.google.javascript.jscomp.DiagnosticType diagnosticType10 = null;
        java.lang.String[] strArray16 = new java.lang.String[] { ".", "./", "hi!", "Not declared as a constructor", "InputId: Not declared as a constructor" };
        try {
            com.google.javascript.jscomp.JSError jSError17 = com.google.javascript.jscomp.JSError.make("function (new:{...}): ?", node4, checkLevel9, diagnosticType10, strArray16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertTrue("'" + checkLevel9 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel9.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(strArray16);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeUnusedPrototypePropertiesInExterns = true;
        compilerOptions0.preferLineBreakAtEndOfFile = true;
        compilerOptions0.setInlineGetters(true);
        compilerOptions0.setComputeFunctionSideEffects(false);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.IR.stringKey("");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.IR.stringKey("");
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.IR.block();
        com.google.javascript.rhino.Node node8 = new com.google.javascript.rhino.Node((int) ' ', node2, node4, node5, 0, (int) (short) -1);
        com.google.javascript.rhino.Node node9 = node5.getFirstChild();
        try {
            com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.IR.var(node5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNull(node9);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable3 = jSTypeRegistry1.getEachReferenceTypeWithProperty("goog.global");
        com.google.javascript.rhino.jstype.JSType jSType4 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray5 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType6 = jSTypeRegistry1.createConstructorTypeWithVarArgs(jSType4, jSTypeArray5);
        com.google.javascript.rhino.JSDocInfo jSDocInfo7 = functionType6.getJSDocInfo();
        boolean boolean8 = functionType6.isAllType();
        com.google.javascript.rhino.ErrorReporter errorReporter9 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry10 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter9);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable12 = jSTypeRegistry10.getEachReferenceTypeWithProperty("goog.global");
        com.google.javascript.rhino.jstype.JSType jSType13 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray14 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType15 = jSTypeRegistry10.createConstructorTypeWithVarArgs(jSType13, jSTypeArray14);
        int int16 = functionType15.getMaxArguments();
        boolean boolean17 = functionType6.isSubtype((com.google.javascript.rhino.jstype.JSType) functionType15);
        com.google.javascript.rhino.ErrorReporter errorReporter19 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry20 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter19);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable22 = jSTypeRegistry20.getEachReferenceTypeWithProperty("goog.global");
        com.google.javascript.rhino.jstype.JSType jSType23 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray24 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType25 = jSTypeRegistry20.createConstructorTypeWithVarArgs(jSType23, jSTypeArray24);
        com.google.javascript.rhino.JSDocInfo jSDocInfo26 = functionType25.getJSDocInfo();
        boolean boolean27 = functionType25.isAllType();
        int int28 = functionType25.getMaxArguments();
        com.google.javascript.rhino.Node node29 = com.google.javascript.rhino.IR.trueNode();
        java.lang.String str30 = node29.getSourceFileName();
        boolean boolean31 = node29.isOr();
        boolean boolean32 = functionType15.defineInferredProperty("hi!", (com.google.javascript.rhino.jstype.JSType) functionType25, node29);
        com.google.javascript.rhino.jstype.ParameterizedType parameterizedType33 = functionType25.toMaybeParameterizedType();
        boolean boolean34 = functionType25.hasAnyTemplateInternal();
        com.google.javascript.rhino.jstype.JSType jSType35 = functionType25.unboxesTo();
        com.google.javascript.rhino.jstype.JSType jSType36 = functionType25.collapseUnion();
        org.junit.Assert.assertNotNull(objectTypeIterable3);
        org.junit.Assert.assertNotNull(jSTypeArray5);
        org.junit.Assert.assertNotNull(functionType6);
        org.junit.Assert.assertNull(jSDocInfo7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(objectTypeIterable12);
        org.junit.Assert.assertNotNull(jSTypeArray14);
        org.junit.Assert.assertNotNull(functionType15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(objectTypeIterable22);
        org.junit.Assert.assertNotNull(jSTypeArray24);
        org.junit.Assert.assertNotNull(functionType25);
        org.junit.Assert.assertNull(jSDocInfo26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNull(str30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNull(parameterizedType33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNull(jSType35);
        org.junit.Assert.assertNotNull(jSType36);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        java.util.List<com.google.javascript.rhino.Node> nodeList0 = null;
        try {
            com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.paramList(nodeList0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.ALL_TYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.ALL_TYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.ALL_TYPE));
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        com.google.javascript.jscomp.ErrorManager errorManager0 = null;
        com.google.javascript.jscomp.deps.JsFileParser jsFileParser1 = new com.google.javascript.jscomp.deps.JsFileParser(errorManager0);
        try {
            com.google.javascript.jscomp.deps.DependencyInfo dependencyInfo4 = jsFileParser1.parseFile("JSDocInfo", "Not declared as a constructor");
            org.junit.Assert.fail("Expected exception of type java.io.FileNotFoundException; message: JSDocInfo (No such file or directory)");
        } catch (java.io.FileNotFoundException e) {
        }
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        com.google.javascript.jscomp.CompilerOptions.TracerMode tracerMode0 = com.google.javascript.jscomp.CompilerOptions.TracerMode.TIMING_ONLY;
        org.junit.Assert.assertTrue("'" + tracerMode0 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TracerMode.TIMING_ONLY + "'", tracerMode0.equals(com.google.javascript.jscomp.CompilerOptions.TracerMode.TIMING_ONLY));
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        com.google.javascript.rhino.JSDocInfo.TypePosition typePosition0 = new com.google.javascript.rhino.JSDocInfo.TypePosition();
        try {
            typePosition0.setPositionInformation(16, (int) (short) 10, 4, 35);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Recorded bad position information\nstart-line: 16\nend-line: 4");
        } catch (java.lang.IllegalStateException e) {
        }
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        com.google.javascript.rhino.Node.SideEffectFlags sideEffectFlags1 = new com.google.javascript.rhino.Node.SideEffectFlags(32);
        sideEffectFlags1.clearSideEffectFlags();
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.GLOBAL_THIS;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.UNKNOWN_TYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.UNKNOWN_TYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.UNKNOWN_TYPE));
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.FUNCTION_FUNCTION_TYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.FUNCTION_FUNCTION_TYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.FUNCTION_FUNCTION_TYPE));
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.NO_RESOLVED_TYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.NO_RESOLVED_TYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.NO_RESOLVED_TYPE));
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.ACCESS_CONTROLS;
        com.google.javascript.jscomp.DiagnosticGroups.INTERNET_EXPLORER_CHECKS = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticGroups.CHECK_USELESS_CODE = diagnosticGroup0;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy0 = com.google.javascript.jscomp.PropertyRenamingPolicy.UNSPECIFIED;
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy0 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.UNSPECIFIED + "'", propertyRenamingPolicy0.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.UNSPECIFIED));
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.falseNode();
        org.junit.Assert.assertNotNull(node0);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.computeFunctionSideEffects = true;
        boolean boolean3 = compilerOptions0.ideMode;
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention4 = new com.google.javascript.jscomp.GoogleCodingConvention();
        compilerOptions0.setCodingConvention((com.google.javascript.jscomp.CodingConvention) googleCodingConvention4);
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.IR.continueNode();
        com.google.javascript.rhino.Node node10 = new com.google.javascript.rhino.Node(10, node7, 35, 0);
        node7.setLength((int) 'a');
        try {
            boolean boolean13 = googleCodingConvention4.isInlinableFunction(node7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(node7);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable3 = jSTypeRegistry1.getEachReferenceTypeWithProperty("goog.global");
        jSTypeRegistry1.clearNamedTypes();
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString("InputId: Not declared as a constructor", (int) '4', (int) (byte) 100);
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.IR.stringKey("");
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable13 = node12.siblings();
        boolean boolean14 = node12.isQualifiedName();
        node12.setString("");
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.IR.stringKey("");
        com.google.javascript.rhino.Node node21 = com.google.javascript.rhino.IR.stringKey("");
        com.google.javascript.rhino.Node node22 = com.google.javascript.rhino.IR.block();
        com.google.javascript.rhino.Node node25 = new com.google.javascript.rhino.Node((int) ' ', node19, node21, node22, 0, (int) (short) -1);
        boolean boolean26 = node19.isThrow();
        boolean boolean27 = node19.isStringKey();
        com.google.javascript.rhino.Node node28 = com.google.javascript.rhino.IR.block();
        com.google.javascript.rhino.Node node29 = node19.useSourceInfoIfMissingFrom(node28);
        com.google.javascript.rhino.Node node30 = node12.copyInformationFromForTree(node29);
        com.google.javascript.rhino.Node node33 = new com.google.javascript.rhino.Node(10, node10, node12, (int) (byte) -1, (int) (byte) 0);
        try {
            com.google.javascript.rhino.jstype.FunctionType functionType34 = jSTypeRegistry1.createInterfaceType("Not declared as a constructor", node10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(objectTypeIterable3);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(nodeIterable13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNotNull(node30);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable3 = jSTypeRegistry1.getEachReferenceTypeWithProperty("goog.global");
        com.google.javascript.rhino.jstype.JSType jSType4 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray5 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType6 = jSTypeRegistry1.createConstructorTypeWithVarArgs(jSType4, jSTypeArray5);
        com.google.javascript.rhino.JSDocInfo jSDocInfo7 = functionType6.getJSDocInfo();
        boolean boolean8 = functionType6.isAllType();
        com.google.javascript.rhino.ErrorReporter errorReporter9 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry10 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter9);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable12 = jSTypeRegistry10.getEachReferenceTypeWithProperty("goog.global");
        com.google.javascript.rhino.jstype.JSType jSType13 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray14 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType15 = jSTypeRegistry10.createConstructorTypeWithVarArgs(jSType13, jSTypeArray14);
        int int16 = functionType15.getMaxArguments();
        boolean boolean17 = functionType6.isSubtype((com.google.javascript.rhino.jstype.JSType) functionType15);
        java.io.PrintStream printStream18 = null;
        com.google.javascript.jscomp.Compiler compiler19 = new com.google.javascript.jscomp.Compiler(printStream18);
        com.google.javascript.jscomp.NodeTraversal.Callback callback20 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal21 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler19, callback20);
        boolean boolean22 = functionType6.equals((java.lang.Object) nodeTraversal21);
        try {
            com.google.javascript.rhino.Node node23 = nodeTraversal21.getScopeRoot();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(objectTypeIterable3);
        org.junit.Assert.assertNotNull(jSTypeArray5);
        org.junit.Assert.assertNotNull(functionType6);
        org.junit.Assert.assertNull(jSDocInfo7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(objectTypeIterable12);
        org.junit.Assert.assertNotNull(jSTypeArray14);
        org.junit.Assert.assertNotNull(functionType15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.computeFunctionSideEffects = true;
        boolean boolean3 = compilerOptions0.isRemoveUnusedClassProperties();
        com.google.javascript.jscomp.ErrorHandler errorHandler4 = null;
        compilerOptions0.setErrorHandler(errorHandler4);
        java.util.List<com.google.javascript.jscomp.SourceMap.LocationMapping> locationMappingList6 = compilerOptions0.sourceMapLocationMappings;
        com.google.javascript.jscomp.CheckLevel checkLevel7 = com.google.javascript.jscomp.CheckLevel.ERROR;
        compilerOptions0.setCheckProvides(checkLevel7);
        com.google.javascript.jscomp.CompilerOptions compilerOptions9 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions9.computeFunctionSideEffects = true;
        boolean boolean12 = compilerOptions9.isRemoveUnusedClassProperties();
        com.google.javascript.jscomp.ErrorHandler errorHandler13 = null;
        compilerOptions9.setErrorHandler(errorHandler13);
        java.util.List<com.google.javascript.jscomp.SourceMap.LocationMapping> locationMappingList15 = compilerOptions9.sourceMapLocationMappings;
        com.google.javascript.jscomp.CheckLevel checkLevel16 = com.google.javascript.jscomp.CheckLevel.ERROR;
        compilerOptions9.setCheckProvides(checkLevel16);
        compilerOptions0.reportMissingOverride = checkLevel16;
        boolean boolean19 = compilerOptions0.jqueryPass;
        com.google.javascript.jscomp.parsing.Config.LanguageMode languageMode21 = com.google.javascript.jscomp.parsing.Config.LanguageMode.ECMASCRIPT3;
        java.lang.String[] strArray25 = new java.lang.String[] { "hi!", "hi!" };
        java.util.LinkedHashSet<java.lang.String> strSet26 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean27 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet26, strArray25);
        com.google.javascript.jscomp.parsing.Config config28 = com.google.javascript.jscomp.parsing.ParserRunner.createConfig(false, languageMode21, true, (java.util.Set<java.lang.String>) strSet26);
        compilerOptions0.setStripNamePrefixes((java.util.Set<java.lang.String>) strSet26);
        byte[] byteArray30 = compilerOptions0.inputVariableMapSerialized;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(locationMappingList6);
        org.junit.Assert.assertTrue("'" + checkLevel7 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel7.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(locationMappingList15);
        org.junit.Assert.assertTrue("'" + checkLevel16 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel16.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + languageMode21 + "' != '" + com.google.javascript.jscomp.parsing.Config.LanguageMode.ECMASCRIPT3 + "'", languageMode21.equals(com.google.javascript.jscomp.parsing.Config.LanguageMode.ECMASCRIPT3));
        org.junit.Assert.assertNotNull(strArray25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertNotNull(config28);
        org.junit.Assert.assertNull(byteArray30);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        com.google.javascript.jscomp.SourceFile sourceFile3 = com.google.javascript.jscomp.SourceFile.fromCode("2019/06/10 13:01", "module$hi!", "BLOCK");
        org.junit.Assert.assertNotNull(sourceFile3);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable3 = jSTypeRegistry1.getEachReferenceTypeWithProperty("goog.global");
        com.google.javascript.rhino.jstype.JSType jSType4 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray5 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType6 = jSTypeRegistry1.createConstructorTypeWithVarArgs(jSType4, jSTypeArray5);
        com.google.javascript.rhino.JSDocInfo jSDocInfo7 = functionType6.getJSDocInfo();
        com.google.javascript.rhino.JSDocInfo jSDocInfo9 = functionType6.getOwnPropertyJSDocInfo("");
        org.junit.Assert.assertNotNull(objectTypeIterable3);
        org.junit.Assert.assertNotNull(jSTypeArray5);
        org.junit.Assert.assertNotNull(functionType6);
        org.junit.Assert.assertNull(jSDocInfo7);
        org.junit.Assert.assertNull(jSDocInfo9);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        com.google.javascript.rhino.JSDocInfo jSDocInfo0 = new com.google.javascript.rhino.JSDocInfo();
        boolean boolean2 = jSDocInfo0.hasDescriptionForParameter("");
        boolean boolean3 = jSDocInfo0.isExterns();
        jSDocInfo0.setDeprecated(false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeUnusedPrototypePropertiesInExterns = true;
        java.util.Map<java.lang.String, java.lang.Object> strMap3 = null;
        compilerOptions0.setTweakReplacements(strMap3);
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy5 = null;
        compilerOptions0.variableRenaming = variableRenamingPolicy5;
        compilerOptions0.setMarkAsCompiled(true);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        com.google.javascript.rhino.JSDocInfo jSDocInfo0 = new com.google.javascript.rhino.JSDocInfo();
        boolean boolean2 = jSDocInfo0.hasDescriptionForParameter("");
        java.lang.String str3 = jSDocInfo0.toString();
        boolean boolean4 = jSDocInfo0.isIdGenerator();
        com.google.common.collect.ImmutableList<java.lang.String> strList5 = jSDocInfo0.getTemplateTypeNames();
        com.google.javascript.rhino.JSDocInfo.Visibility visibility6 = null;
        jSDocInfo0.setVisibility(visibility6);
        boolean boolean8 = jSDocInfo0.containsDeclaration();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "JSDocInfo" + "'", str3.equals("JSDocInfo"));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(strList5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.computeFunctionSideEffects = true;
        boolean boolean3 = compilerOptions0.removeUnusedVars;
        java.lang.String[] strArray15 = new java.lang.String[] { "InputId: Not declared as a constructor", ".", "BLOCK", "InputId: Not declared as a constructor", "Not declared as a constructor", "module$hi!", ".", "JSDocInfo", "module$hi!", ".", "hi!" };
        java.util.LinkedHashSet<java.lang.String> strSet16 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean17 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet16, strArray15);
        compilerOptions0.setIdGenerators((java.util.Set<java.lang.String>) strSet16);
        boolean boolean19 = compilerOptions0.exportTestFunctions;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(strArray15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable3 = jSTypeRegistry1.getEachReferenceTypeWithProperty("goog.global");
        com.google.javascript.rhino.jstype.JSType jSType4 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray5 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType6 = jSTypeRegistry1.createConstructorTypeWithVarArgs(jSType4, jSTypeArray5);
        com.google.javascript.rhino.JSDocInfo jSDocInfo7 = functionType6.getJSDocInfo();
        boolean boolean8 = functionType6.isAllType();
        com.google.javascript.rhino.ErrorReporter errorReporter9 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry10 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter9);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable12 = jSTypeRegistry10.getEachReferenceTypeWithProperty("goog.global");
        com.google.javascript.rhino.jstype.JSType jSType13 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray14 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType15 = jSTypeRegistry10.createConstructorTypeWithVarArgs(jSType13, jSTypeArray14);
        int int16 = functionType15.getMaxArguments();
        boolean boolean17 = functionType6.isSubtype((com.google.javascript.rhino.jstype.JSType) functionType15);
        boolean boolean18 = functionType15.matchesNumberContext();
        org.junit.Assert.assertNotNull(objectTypeIterable3);
        org.junit.Assert.assertNotNull(jSTypeArray5);
        org.junit.Assert.assertNotNull(functionType6);
        org.junit.Assert.assertNull(jSDocInfo7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(objectTypeIterable12);
        org.junit.Assert.assertNotNull(jSTypeArray14);
        org.junit.Assert.assertNotNull(functionType15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable3 = jSTypeRegistry1.getEachReferenceTypeWithProperty("goog.global");
        com.google.javascript.rhino.jstype.JSType jSType4 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray5 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType6 = jSTypeRegistry1.createConstructorTypeWithVarArgs(jSType4, jSTypeArray5);
        com.google.javascript.rhino.JSDocInfo jSDocInfo7 = functionType6.getJSDocInfo();
        boolean boolean8 = functionType6.isAllType();
        com.google.javascript.rhino.ErrorReporter errorReporter9 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry10 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter9);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable12 = jSTypeRegistry10.getEachReferenceTypeWithProperty("goog.global");
        com.google.javascript.rhino.jstype.JSType jSType13 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray14 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType15 = jSTypeRegistry10.createConstructorTypeWithVarArgs(jSType13, jSTypeArray14);
        int int16 = functionType15.getMaxArguments();
        boolean boolean17 = functionType6.isSubtype((com.google.javascript.rhino.jstype.JSType) functionType15);
        com.google.javascript.rhino.ErrorReporter errorReporter19 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry20 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter19);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable22 = jSTypeRegistry20.getEachReferenceTypeWithProperty("goog.global");
        com.google.javascript.rhino.jstype.JSType jSType23 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray24 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType25 = jSTypeRegistry20.createConstructorTypeWithVarArgs(jSType23, jSTypeArray24);
        com.google.javascript.rhino.JSDocInfo jSDocInfo26 = functionType25.getJSDocInfo();
        boolean boolean27 = functionType25.isAllType();
        int int28 = functionType25.getMaxArguments();
        com.google.javascript.rhino.Node node29 = com.google.javascript.rhino.IR.trueNode();
        java.lang.String str30 = node29.getSourceFileName();
        boolean boolean31 = node29.isOr();
        boolean boolean32 = functionType15.defineInferredProperty("hi!", (com.google.javascript.rhino.jstype.JSType) functionType25, node29);
        com.google.javascript.rhino.Node node34 = com.google.javascript.rhino.IR.stringKey("");
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable35 = node34.siblings();
        boolean boolean36 = node34.isQualifiedName();
        node34.setString("");
        node34.removeProp((int) ' ');
        com.google.javascript.rhino.Node node41 = node29.srcrefTree(node34);
        com.google.javascript.rhino.Node node44 = com.google.javascript.rhino.IR.stringKey("");
        com.google.javascript.rhino.Node node46 = com.google.javascript.rhino.IR.stringKey("");
        com.google.javascript.rhino.Node node47 = com.google.javascript.rhino.IR.block();
        com.google.javascript.rhino.Node node50 = new com.google.javascript.rhino.Node((int) ' ', node44, node46, node47, 0, (int) (short) -1);
        try {
            com.google.javascript.rhino.Node node51 = com.google.javascript.rhino.IR.doNode(node41, node44);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(objectTypeIterable3);
        org.junit.Assert.assertNotNull(jSTypeArray5);
        org.junit.Assert.assertNotNull(functionType6);
        org.junit.Assert.assertNull(jSDocInfo7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(objectTypeIterable12);
        org.junit.Assert.assertNotNull(jSTypeArray14);
        org.junit.Assert.assertNotNull(functionType15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(objectTypeIterable22);
        org.junit.Assert.assertNotNull(jSTypeArray24);
        org.junit.Assert.assertNotNull(functionType25);
        org.junit.Assert.assertNull(jSDocInfo26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNull(str30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNotNull(node34);
        org.junit.Assert.assertNotNull(nodeIterable35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(node41);
        org.junit.Assert.assertNotNull(node44);
        org.junit.Assert.assertNotNull(node46);
        org.junit.Assert.assertNotNull(node47);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.computeFunctionSideEffects = true;
        boolean boolean3 = compilerOptions0.removeUnusedVars;
        compilerOptions0.skipAllCompilerPasses();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.NodeTraversal.Callback callback2 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal3 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler1, callback2);
        com.google.javascript.jscomp.Compiler.IntermediateState intermediateState4 = compiler1.getState();
        java.io.PrintStream printStream5 = null;
        com.google.javascript.jscomp.Compiler compiler6 = new com.google.javascript.jscomp.Compiler(printStream5);
        com.google.javascript.jscomp.SourceFile sourceFile8 = com.google.javascript.jscomp.SourceFile.fromFile("./");
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray9 = new com.google.javascript.jscomp.JSSourceFile[] {};
        com.google.javascript.jscomp.CompilerOptions compilerOptions10 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean11 = compilerOptions10.isExternExportsEnabled();
        com.google.javascript.jscomp.Result result12 = compiler6.compile(sourceFile8, jSSourceFileArray9, compilerOptions10);
        com.google.javascript.jscomp.JSModule[] jSModuleArray13 = new com.google.javascript.jscomp.JSModule[] {};
        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList14 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
        boolean boolean15 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList14, jSModuleArray13);
        com.google.javascript.jscomp.JSModule[] jSModuleArray16 = com.google.javascript.jscomp.JSModule.sortJsModules((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList14);
        com.google.javascript.jscomp.CompilerOptions compilerOptions17 = null;
        try {
            compiler1.init(jSSourceFileArray9, jSModuleArray16, compilerOptions17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intermediateState4);
        org.junit.Assert.assertNotNull(sourceFile8);
        org.junit.Assert.assertNotNull(jSSourceFileArray9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(result12);
        org.junit.Assert.assertNotNull(jSModuleArray13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(jSModuleArray16);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        com.google.javascript.rhino.Node node0 = null;
        try {
            com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder1 = node0.new FileLevelJsDocBuilder();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: reflection call to com.google.javascript.rhino.Node$FileLevelJsDocBuilder with null for superclass argument");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        int int0 = com.google.javascript.rhino.Node.SIDE_EFFECTS_FLAGS_MASK;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 31 + "'", int0 == 31);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        com.google.javascript.jscomp.SourceAst sourceAst0 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(sourceAst0, "Not declared as a constructor", true);
        com.google.javascript.rhino.InputId inputId4 = compilerInput3.getInputId();
        java.lang.String str5 = inputId4.toString();
        java.lang.String str6 = inputId4.toString();
        org.junit.Assert.assertNotNull(inputId4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "InputId: Not declared as a constructor" + "'", str5.equals("InputId: Not declared as a constructor"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "InputId: Not declared as a constructor" + "'", str6.equals("InputId: Not declared as a constructor"));
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable3 = jSTypeRegistry1.getEachReferenceTypeWithProperty("goog.global");
        com.google.javascript.rhino.jstype.JSType jSType4 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray5 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType6 = jSTypeRegistry1.createConstructorTypeWithVarArgs(jSType4, jSTypeArray5);
        com.google.javascript.rhino.JSDocInfo jSDocInfo7 = functionType6.getJSDocInfo();
        boolean boolean8 = functionType6.isAllType();
        com.google.javascript.rhino.ErrorReporter errorReporter9 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry10 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter9);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable12 = jSTypeRegistry10.getEachReferenceTypeWithProperty("goog.global");
        com.google.javascript.rhino.jstype.JSType jSType13 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray14 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType15 = jSTypeRegistry10.createConstructorTypeWithVarArgs(jSType13, jSTypeArray14);
        int int16 = functionType15.getMaxArguments();
        boolean boolean17 = functionType6.isSubtype((com.google.javascript.rhino.jstype.JSType) functionType15);
        com.google.javascript.rhino.ErrorReporter errorReporter18 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry19 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter18);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable21 = jSTypeRegistry19.getEachReferenceTypeWithProperty("goog.global");
        com.google.javascript.rhino.jstype.JSType jSType22 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray23 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType24 = jSTypeRegistry19.createConstructorTypeWithVarArgs(jSType22, jSTypeArray23);
        com.google.javascript.rhino.JSDocInfo jSDocInfo25 = functionType24.getJSDocInfo();
        boolean boolean26 = functionType24.isAllType();
        com.google.javascript.rhino.ErrorReporter errorReporter27 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry28 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter27);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable30 = jSTypeRegistry28.getEachReferenceTypeWithProperty("goog.global");
        com.google.javascript.rhino.jstype.JSType jSType31 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray32 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType33 = jSTypeRegistry28.createConstructorTypeWithVarArgs(jSType31, jSTypeArray32);
        int int34 = functionType33.getMaxArguments();
        boolean boolean35 = functionType24.isSubtype((com.google.javascript.rhino.jstype.JSType) functionType33);
        com.google.javascript.rhino.ErrorReporter errorReporter37 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry38 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter37);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable40 = jSTypeRegistry38.getEachReferenceTypeWithProperty("goog.global");
        com.google.javascript.rhino.jstype.JSType jSType41 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray42 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType43 = jSTypeRegistry38.createConstructorTypeWithVarArgs(jSType41, jSTypeArray42);
        com.google.javascript.rhino.JSDocInfo jSDocInfo44 = functionType43.getJSDocInfo();
        boolean boolean45 = functionType43.isAllType();
        int int46 = functionType43.getMaxArguments();
        com.google.javascript.rhino.Node node47 = com.google.javascript.rhino.IR.trueNode();
        java.lang.String str48 = node47.getSourceFileName();
        boolean boolean49 = node47.isOr();
        boolean boolean50 = functionType33.defineInferredProperty("hi!", (com.google.javascript.rhino.jstype.JSType) functionType43, node47);
        com.google.javascript.rhino.jstype.ParameterizedType parameterizedType51 = functionType43.toMaybeParameterizedType();
        boolean boolean52 = functionType43.hasAnyTemplateInternal();
        com.google.javascript.rhino.jstype.JSType.TypePair typePair53 = functionType15.getTypesUnderInequality((com.google.javascript.rhino.jstype.JSType) functionType43);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable54 = functionType15.getAllExtendedInterfaces();
        org.junit.Assert.assertNotNull(objectTypeIterable3);
        org.junit.Assert.assertNotNull(jSTypeArray5);
        org.junit.Assert.assertNotNull(functionType6);
        org.junit.Assert.assertNull(jSDocInfo7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(objectTypeIterable12);
        org.junit.Assert.assertNotNull(jSTypeArray14);
        org.junit.Assert.assertNotNull(functionType15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(objectTypeIterable21);
        org.junit.Assert.assertNotNull(jSTypeArray23);
        org.junit.Assert.assertNotNull(functionType24);
        org.junit.Assert.assertNull(jSDocInfo25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(objectTypeIterable30);
        org.junit.Assert.assertNotNull(jSTypeArray32);
        org.junit.Assert.assertNotNull(functionType33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertNotNull(objectTypeIterable40);
        org.junit.Assert.assertNotNull(jSTypeArray42);
        org.junit.Assert.assertNotNull(functionType43);
        org.junit.Assert.assertNull(jSDocInfo44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 0 + "'", int46 == 0);
        org.junit.Assert.assertNotNull(node47);
        org.junit.Assert.assertNull(str48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + true + "'", boolean50 == true);
        org.junit.Assert.assertNull(parameterizedType51);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertNotNull(typePair53);
        org.junit.Assert.assertNotNull(objectTypeIterable54);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.SourceFile sourceFile3 = com.google.javascript.jscomp.SourceFile.fromFile("./");
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray4 = new com.google.javascript.jscomp.JSSourceFile[] {};
        com.google.javascript.jscomp.CompilerOptions compilerOptions5 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean6 = compilerOptions5.isExternExportsEnabled();
        com.google.javascript.jscomp.Result result7 = compiler1.compile(sourceFile3, jSSourceFileArray4, compilerOptions5);
        com.google.javascript.jscomp.SourceMap sourceMap8 = compiler1.getSourceMap();
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter9 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler1);
        com.google.javascript.jscomp.JSError jSError10 = null;
        try {
            java.lang.String str11 = lightweightMessageFormatter9.formatWarning(jSError10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(sourceFile3);
        org.junit.Assert.assertNotNull(jSSourceFileArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(result7);
        org.junit.Assert.assertNull(sourceMap8);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.computeFunctionSideEffects = true;
        boolean boolean3 = compilerOptions0.isRemoveUnusedClassProperties();
        com.google.javascript.jscomp.ErrorHandler errorHandler4 = null;
        compilerOptions0.setErrorHandler(errorHandler4);
        boolean boolean6 = compilerOptions0.checkSuspiciousCode;
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy7 = compilerOptions0.propertyRenaming;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy7 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.OFF + "'", propertyRenamingPolicy7.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.OFF));
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeUnusedPrototypePropertiesInExterns = true;
        java.util.Map<java.lang.String, java.lang.Object> strMap3 = null;
        compilerOptions0.setTweakReplacements(strMap3);
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy5 = null;
        compilerOptions0.variableRenaming = variableRenamingPolicy5;
        compilerOptions0.computeFunctionSideEffects = false;
        boolean boolean9 = compilerOptions0.extractPrototypeMemberDeclarations;
        boolean boolean10 = compilerOptions0.labelRenaming;
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        com.google.javascript.jscomp.ErrorFormat errorFormat0 = com.google.javascript.jscomp.ErrorFormat.SINGLELINE;
        com.google.javascript.jscomp.SourceExcerptProvider sourceExcerptProvider1 = null;
        try {
            com.google.javascript.jscomp.MessageFormatter messageFormatter3 = errorFormat0.toFormatter(sourceExcerptProvider1, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(errorFormat0);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.CHECK_REGEXP;
        com.google.javascript.jscomp.DiagnosticGroups.INVALID_CASTS = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticGroups.NON_STANDARD_JSDOC = diagnosticGroup0;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeUnusedPrototypePropertiesInExterns = true;
        java.util.Map<java.lang.String, java.lang.Object> strMap3 = null;
        compilerOptions0.setTweakReplacements(strMap3);
        compilerOptions0.setInlineConstantVars(false);
        java.lang.String str7 = compilerOptions0.renamePrefix;
        compilerOptions0.setRemoveUnusedVars(true);
        org.junit.Assert.assertNull(str7);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        com.google.javascript.jscomp.SourceAst sourceAst0 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(sourceAst0, "Not declared as a constructor", true);
        com.google.javascript.rhino.InputId inputId4 = compilerInput3.getInputId();
        java.lang.String str5 = inputId4.toString();
        boolean boolean7 = inputId4.equals((java.lang.Object) (byte) 10);
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean9 = inputId4.equals((java.lang.Object) node8);
        java.lang.String str10 = inputId4.toString();
        org.junit.Assert.assertNotNull(inputId4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "InputId: Not declared as a constructor" + "'", str5.equals("InputId: Not declared as a constructor"));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "InputId: Not declared as a constructor" + "'", str10.equals("InputId: Not declared as a constructor"));
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        com.google.javascript.jscomp.AstValidator.ViolationHandler violationHandler0 = null;
        com.google.javascript.jscomp.AstValidator astValidator1 = new com.google.javascript.jscomp.AstValidator(violationHandler0);
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.IR.stringKey("");
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.IR.stringKey("");
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.IR.block();
        com.google.javascript.rhino.Node node10 = new com.google.javascript.rhino.Node((int) ' ', node4, node6, node7, 0, (int) (short) -1);
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.IR.stringKey("");
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.IR.stringKey("");
        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.IR.block();
        com.google.javascript.rhino.Node node19 = new com.google.javascript.rhino.Node((int) ' ', node13, node15, node16, 0, (int) (short) -1);
        boolean boolean20 = node13.isThrow();
        int int21 = node7.getIndexOfChild(node13);
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.IR.stringKey("");
        int int24 = node23.getLineno();
        com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.IR.block();
        java.lang.String str29 = node25.toString(false, false, false);
        com.google.javascript.rhino.Node node30 = com.google.javascript.rhino.IR.block();
        java.lang.String str34 = node30.toString(false, false, false);
        com.google.javascript.rhino.Node node35 = node25.useSourceInfoIfMissingFrom(node30);
        com.google.javascript.rhino.Node node36 = node23.srcrefTree(node25);
        com.google.javascript.rhino.Node node37 = node7.useSourceInfoIfMissingFromForTree(node23);
        int int38 = node23.getLineno();
        com.google.javascript.rhino.Node node42 = com.google.javascript.rhino.Node.newString("InputId: Not declared as a constructor", (int) '4', (int) (byte) 100);
        com.google.javascript.rhino.Node node43 = node23.useSourceInfoIfMissingFrom(node42);
        try {
            astValidator1.validateScript(node23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "BLOCK" + "'", str29.equals("BLOCK"));
        org.junit.Assert.assertNotNull(node30);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "BLOCK" + "'", str34.equals("BLOCK"));
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertNotNull(node36);
        org.junit.Assert.assertNotNull(node37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + (-1) + "'", int38 == (-1));
        org.junit.Assert.assertNotNull(node42);
        org.junit.Assert.assertNotNull(node43);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        com.google.javascript.rhino.JSDocInfo jSDocInfo0 = new com.google.javascript.rhino.JSDocInfo();
        boolean boolean1 = jSDocInfo0.isExterns();
        java.util.Set<java.lang.String> strSet2 = jSDocInfo0.getParameterNames();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(strSet2);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeUnusedPrototypePropertiesInExterns = true;
        compilerOptions0.moveFunctionDeclarations = true;
        compilerOptions0.setAliasableGlobals("");
        compilerOptions0.setCheckSuspiciousCode(true);
        compilerOptions0.inlineGetters = false;
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable3 = jSTypeRegistry1.getEachReferenceTypeWithProperty("goog.global");
        com.google.javascript.rhino.jstype.JSType jSType4 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray5 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType6 = jSTypeRegistry1.createConstructorTypeWithVarArgs(jSType4, jSTypeArray5);
        com.google.javascript.rhino.JSDocInfo jSDocInfo7 = functionType6.getJSDocInfo();
        boolean boolean8 = functionType6.isAllType();
        int int9 = functionType6.getMaxArguments();
        boolean boolean10 = functionType6.hasCachedValues();
        com.google.javascript.jscomp.SourceAst sourceAst11 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput14 = new com.google.javascript.jscomp.CompilerInput(sourceAst11, "Not declared as a constructor", true);
        com.google.javascript.jscomp.SourceAst sourceAst15 = compilerInput14.getSourceAst();
        boolean boolean16 = functionType6.equals((java.lang.Object) sourceAst15);
        com.google.javascript.rhino.ErrorReporter errorReporter17 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry18 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter17);
        com.google.javascript.rhino.ErrorReporter errorReporter19 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry20 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter19);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable22 = jSTypeRegistry20.getEachReferenceTypeWithProperty("goog.global");
        com.google.javascript.rhino.jstype.JSType jSType23 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray24 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType25 = jSTypeRegistry20.createConstructorTypeWithVarArgs(jSType23, jSTypeArray24);
        com.google.javascript.rhino.JSDocInfo jSDocInfo26 = functionType25.getJSDocInfo();
        boolean boolean27 = functionType25.isAllType();
        com.google.javascript.rhino.ErrorReporter errorReporter28 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry29 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter28);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable31 = jSTypeRegistry29.getEachReferenceTypeWithProperty("goog.global");
        com.google.javascript.rhino.jstype.JSType jSType32 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray33 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType34 = jSTypeRegistry29.createConstructorTypeWithVarArgs(jSType32, jSTypeArray33);
        int int35 = functionType34.getMaxArguments();
        boolean boolean36 = functionType25.isSubtype((com.google.javascript.rhino.jstype.JSType) functionType34);
        com.google.javascript.rhino.ErrorReporter errorReporter38 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry39 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter38);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable41 = jSTypeRegistry39.getEachReferenceTypeWithProperty("goog.global");
        com.google.javascript.rhino.jstype.JSType jSType42 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray43 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType44 = jSTypeRegistry39.createConstructorTypeWithVarArgs(jSType42, jSTypeArray43);
        com.google.javascript.rhino.JSDocInfo jSDocInfo45 = functionType44.getJSDocInfo();
        boolean boolean46 = functionType44.isAllType();
        int int47 = functionType44.getMaxArguments();
        com.google.javascript.rhino.Node node48 = com.google.javascript.rhino.IR.trueNode();
        java.lang.String str49 = node48.getSourceFileName();
        boolean boolean50 = node48.isOr();
        boolean boolean51 = functionType34.defineInferredProperty("hi!", (com.google.javascript.rhino.jstype.JSType) functionType44, node48);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray53 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType54 = jSTypeRegistry18.createConstructorType((com.google.javascript.rhino.jstype.JSType) functionType44, false, jSTypeArray53);
        com.google.javascript.rhino.ErrorReporter errorReporter55 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry56 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter55);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable58 = jSTypeRegistry56.getEachReferenceTypeWithProperty("goog.global");
        com.google.javascript.rhino.jstype.JSType jSType59 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray60 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType61 = jSTypeRegistry56.createConstructorTypeWithVarArgs(jSType59, jSTypeArray60);
        com.google.javascript.rhino.JSDocInfo jSDocInfo62 = functionType61.getJSDocInfo();
        boolean boolean63 = functionType61.isAllType();
        com.google.javascript.rhino.ErrorReporter errorReporter64 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry65 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter64);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable67 = jSTypeRegistry65.getEachReferenceTypeWithProperty("goog.global");
        com.google.javascript.rhino.jstype.JSType jSType68 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray69 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType70 = jSTypeRegistry65.createConstructorTypeWithVarArgs(jSType68, jSTypeArray69);
        int int71 = functionType70.getMaxArguments();
        boolean boolean72 = functionType61.isSubtype((com.google.javascript.rhino.jstype.JSType) functionType70);
        java.io.PrintStream printStream73 = null;
        com.google.javascript.jscomp.Compiler compiler74 = new com.google.javascript.jscomp.Compiler(printStream73);
        com.google.javascript.jscomp.NodeTraversal.Callback callback75 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal76 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler74, callback75);
        boolean boolean77 = functionType61.equals((java.lang.Object) nodeTraversal76);
        com.google.javascript.rhino.jstype.JSType jSType78 = jSTypeRegistry18.createOptionalNullableType((com.google.javascript.rhino.jstype.JSType) functionType61);
        boolean boolean79 = jSType78.isEmptyType();
        com.google.javascript.rhino.jstype.JSType.TypePair typePair80 = functionType6.getTypesUnderShallowEquality(jSType78);
        org.junit.Assert.assertNotNull(objectTypeIterable3);
        org.junit.Assert.assertNotNull(jSTypeArray5);
        org.junit.Assert.assertNotNull(functionType6);
        org.junit.Assert.assertNull(jSDocInfo7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNull(sourceAst15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(objectTypeIterable22);
        org.junit.Assert.assertNotNull(jSTypeArray24);
        org.junit.Assert.assertNotNull(functionType25);
        org.junit.Assert.assertNull(jSDocInfo26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(objectTypeIterable31);
        org.junit.Assert.assertNotNull(jSTypeArray33);
        org.junit.Assert.assertNotNull(functionType34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertNotNull(objectTypeIterable41);
        org.junit.Assert.assertNotNull(jSTypeArray43);
        org.junit.Assert.assertNotNull(functionType44);
        org.junit.Assert.assertNull(jSDocInfo45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 0 + "'", int47 == 0);
        org.junit.Assert.assertNotNull(node48);
        org.junit.Assert.assertNull(str49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + true + "'", boolean51 == true);
        org.junit.Assert.assertNotNull(jSTypeArray53);
        org.junit.Assert.assertNotNull(functionType54);
        org.junit.Assert.assertNotNull(objectTypeIterable58);
        org.junit.Assert.assertNotNull(jSTypeArray60);
        org.junit.Assert.assertNotNull(functionType61);
        org.junit.Assert.assertNull(jSDocInfo62);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertNotNull(objectTypeIterable67);
        org.junit.Assert.assertNotNull(jSTypeArray69);
        org.junit.Assert.assertNotNull(functionType70);
        org.junit.Assert.assertTrue("'" + int71 + "' != '" + 0 + "'", int71 == 0);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + true + "'", boolean72 == true);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
        org.junit.Assert.assertNotNull(jSType78);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
        org.junit.Assert.assertNotNull(typePair80);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        com.google.javascript.rhino.ErrorReporter errorReporter2 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry3 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter2);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable5 = jSTypeRegistry3.getEachReferenceTypeWithProperty("goog.global");
        com.google.javascript.rhino.jstype.JSType jSType6 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray7 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType8 = jSTypeRegistry3.createConstructorTypeWithVarArgs(jSType6, jSTypeArray7);
        com.google.javascript.rhino.JSDocInfo jSDocInfo9 = functionType8.getJSDocInfo();
        boolean boolean10 = functionType8.isAllType();
        com.google.javascript.rhino.ErrorReporter errorReporter11 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry12 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter11);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable14 = jSTypeRegistry12.getEachReferenceTypeWithProperty("goog.global");
        com.google.javascript.rhino.jstype.JSType jSType15 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray16 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType17 = jSTypeRegistry12.createConstructorTypeWithVarArgs(jSType15, jSTypeArray16);
        int int18 = functionType17.getMaxArguments();
        boolean boolean19 = functionType8.isSubtype((com.google.javascript.rhino.jstype.JSType) functionType17);
        com.google.javascript.rhino.ErrorReporter errorReporter21 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry22 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter21);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable24 = jSTypeRegistry22.getEachReferenceTypeWithProperty("goog.global");
        com.google.javascript.rhino.jstype.JSType jSType25 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray26 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType27 = jSTypeRegistry22.createConstructorTypeWithVarArgs(jSType25, jSTypeArray26);
        com.google.javascript.rhino.JSDocInfo jSDocInfo28 = functionType27.getJSDocInfo();
        boolean boolean29 = functionType27.isAllType();
        int int30 = functionType27.getMaxArguments();
        com.google.javascript.rhino.Node node31 = com.google.javascript.rhino.IR.trueNode();
        java.lang.String str32 = node31.getSourceFileName();
        boolean boolean33 = node31.isOr();
        boolean boolean34 = functionType17.defineInferredProperty("hi!", (com.google.javascript.rhino.jstype.JSType) functionType27, node31);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray36 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType37 = jSTypeRegistry1.createConstructorType((com.google.javascript.rhino.jstype.JSType) functionType27, false, jSTypeArray36);
        boolean boolean38 = functionType37.canBeCalled();
        functionType37.clearCachedValues();
        java.lang.String str40 = functionType37.getDisplayName();
        org.junit.Assert.assertNotNull(objectTypeIterable5);
        org.junit.Assert.assertNotNull(jSTypeArray7);
        org.junit.Assert.assertNotNull(functionType8);
        org.junit.Assert.assertNull(jSDocInfo9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(objectTypeIterable14);
        org.junit.Assert.assertNotNull(jSTypeArray16);
        org.junit.Assert.assertNotNull(functionType17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(objectTypeIterable24);
        org.junit.Assert.assertNotNull(jSTypeArray26);
        org.junit.Assert.assertNotNull(functionType27);
        org.junit.Assert.assertNull(jSDocInfo28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertNull(str32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertNotNull(jSTypeArray36);
        org.junit.Assert.assertNotNull(functionType37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertNull(str40);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.block();
        java.lang.String str4 = node0.toString(false, false, false);
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.IR.block();
        java.lang.String str9 = node5.toString(false, false, false);
        com.google.javascript.rhino.Node node10 = node0.useSourceInfoIfMissingFrom(node5);
        java.lang.String str11 = node5.toStringTree();
        boolean boolean12 = com.google.javascript.jscomp.NodeUtil.isSymmetricOperation(node5);
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "BLOCK" + "'", str4.equals("BLOCK"));
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "BLOCK" + "'", str9.equals("BLOCK"));
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "BLOCK\n" + "'", str11.equals("BLOCK\n"));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeUnusedPrototypePropertiesInExterns = true;
        compilerOptions0.setAmbiguateProperties(true);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.stringKey("");
        com.google.javascript.rhino.Node node2 = null;
        int int3 = node1.getIndexOfChild(node2);
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.IR.stringKey("");
        int int6 = node5.getLineno();
        node5.setLineno((-1));
        try {
            com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.IR.var(node1, node5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        com.google.javascript.rhino.Node.SideEffectFlags sideEffectFlags1 = new com.google.javascript.rhino.Node.SideEffectFlags((int) (byte) 1);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        com.google.javascript.jscomp.CustomPassExecutionTime customPassExecutionTime0 = com.google.javascript.jscomp.CustomPassExecutionTime.BEFORE_OPTIMIZATION_LOOP;
        org.junit.Assert.assertTrue("'" + customPassExecutionTime0 + "' != '" + com.google.javascript.jscomp.CustomPassExecutionTime.BEFORE_OPTIMIZATION_LOOP + "'", customPassExecutionTime0.equals(com.google.javascript.jscomp.CustomPassExecutionTime.BEFORE_OPTIMIZATION_LOOP));
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.computeFunctionSideEffects = true;
        java.lang.String str3 = compilerOptions0.renamePrefix;
        boolean boolean4 = compilerOptions0.crossModuleMethodMotion;
        compilerOptions0.setCrossModuleCodeMotion(true);
        compilerOptions0.setInlineProperties(false);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        com.google.javascript.rhino.ErrorReporter errorReporter2 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry3 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter2);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable5 = jSTypeRegistry3.getEachReferenceTypeWithProperty("goog.global");
        com.google.javascript.rhino.jstype.JSType jSType6 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray7 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType8 = jSTypeRegistry3.createConstructorTypeWithVarArgs(jSType6, jSTypeArray7);
        com.google.javascript.rhino.JSDocInfo jSDocInfo9 = functionType8.getJSDocInfo();
        boolean boolean10 = functionType8.isAllType();
        com.google.javascript.rhino.ErrorReporter errorReporter11 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry12 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter11);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable14 = jSTypeRegistry12.getEachReferenceTypeWithProperty("goog.global");
        com.google.javascript.rhino.jstype.JSType jSType15 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray16 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType17 = jSTypeRegistry12.createConstructorTypeWithVarArgs(jSType15, jSTypeArray16);
        int int18 = functionType17.getMaxArguments();
        boolean boolean19 = functionType8.isSubtype((com.google.javascript.rhino.jstype.JSType) functionType17);
        com.google.javascript.rhino.ErrorReporter errorReporter21 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry22 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter21);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable24 = jSTypeRegistry22.getEachReferenceTypeWithProperty("goog.global");
        com.google.javascript.rhino.jstype.JSType jSType25 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray26 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType27 = jSTypeRegistry22.createConstructorTypeWithVarArgs(jSType25, jSTypeArray26);
        com.google.javascript.rhino.JSDocInfo jSDocInfo28 = functionType27.getJSDocInfo();
        boolean boolean29 = functionType27.isAllType();
        int int30 = functionType27.getMaxArguments();
        com.google.javascript.rhino.Node node31 = com.google.javascript.rhino.IR.trueNode();
        java.lang.String str32 = node31.getSourceFileName();
        boolean boolean33 = node31.isOr();
        boolean boolean34 = functionType17.defineInferredProperty("hi!", (com.google.javascript.rhino.jstype.JSType) functionType27, node31);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray36 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType37 = jSTypeRegistry1.createConstructorType((com.google.javascript.rhino.jstype.JSType) functionType27, false, jSTypeArray36);
        boolean boolean38 = functionType37.canBeCalled();
        java.lang.String str39 = functionType37.getDisplayName();
        org.junit.Assert.assertNotNull(objectTypeIterable5);
        org.junit.Assert.assertNotNull(jSTypeArray7);
        org.junit.Assert.assertNotNull(functionType8);
        org.junit.Assert.assertNull(jSDocInfo9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(objectTypeIterable14);
        org.junit.Assert.assertNotNull(jSTypeArray16);
        org.junit.Assert.assertNotNull(functionType17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(objectTypeIterable24);
        org.junit.Assert.assertNotNull(jSTypeArray26);
        org.junit.Assert.assertNotNull(functionType27);
        org.junit.Assert.assertNull(jSDocInfo28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertNull(str32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertNotNull(jSTypeArray36);
        org.junit.Assert.assertNotNull(functionType37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertNull(str39);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_NUMBER_STRING_BOOLEAN;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_NUMBER_STRING_BOOLEAN + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_NUMBER_STRING_BOOLEAN));
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable3 = jSTypeRegistry1.getEachReferenceTypeWithProperty("goog.global");
        com.google.javascript.rhino.jstype.JSType jSType4 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray5 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType6 = jSTypeRegistry1.createConstructorTypeWithVarArgs(jSType4, jSTypeArray5);
        com.google.javascript.rhino.JSDocInfo jSDocInfo7 = functionType6.getJSDocInfo();
        boolean boolean8 = functionType6.isAllType();
        com.google.javascript.rhino.ErrorReporter errorReporter9 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry10 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter9);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable12 = jSTypeRegistry10.getEachReferenceTypeWithProperty("goog.global");
        com.google.javascript.rhino.jstype.JSType jSType13 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray14 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType15 = jSTypeRegistry10.createConstructorTypeWithVarArgs(jSType13, jSTypeArray14);
        int int16 = functionType15.getMaxArguments();
        boolean boolean17 = functionType6.isSubtype((com.google.javascript.rhino.jstype.JSType) functionType15);
        com.google.javascript.rhino.jstype.JSType jSType18 = functionType6.collapseUnion();
        boolean boolean19 = jSType18.isUnionType();
        org.junit.Assert.assertNotNull(objectTypeIterable3);
        org.junit.Assert.assertNotNull(jSTypeArray5);
        org.junit.Assert.assertNotNull(functionType6);
        org.junit.Assert.assertNull(jSDocInfo7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(objectTypeIterable12);
        org.junit.Assert.assertNotNull(jSTypeArray14);
        org.junit.Assert.assertNotNull(functionType15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(jSType18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        int int0 = com.google.javascript.rhino.Node.DECR_FLAG;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.computeFunctionSideEffects = true;
        boolean boolean3 = compilerOptions0.removeUnusedVars;
        compilerOptions0.inlineVariables = false;
        compilerOptions0.setRemoveUnusedClassProperties(true);
        com.google.javascript.jscomp.CheckLevel checkLevel8 = compilerOptions0.aggressiveVarCheck;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + checkLevel8 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel8.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.block();
        boolean boolean1 = node0.isCase();
        boolean boolean2 = node0.isStringKey();
        java.lang.String str3 = node0.getSourceFileName();
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable3 = jSTypeRegistry1.getEachReferenceTypeWithProperty("goog.global");
        com.google.javascript.rhino.jstype.JSType jSType4 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray5 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType6 = jSTypeRegistry1.createConstructorTypeWithVarArgs(jSType4, jSTypeArray5);
        com.google.javascript.rhino.JSDocInfo jSDocInfo7 = functionType6.getJSDocInfo();
        boolean boolean8 = functionType6.isAllType();
        com.google.javascript.rhino.ErrorReporter errorReporter9 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry10 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter9);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable12 = jSTypeRegistry10.getEachReferenceTypeWithProperty("goog.global");
        com.google.javascript.rhino.jstype.JSType jSType13 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray14 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType15 = jSTypeRegistry10.createConstructorTypeWithVarArgs(jSType13, jSTypeArray14);
        int int16 = functionType15.getMaxArguments();
        boolean boolean17 = functionType6.isSubtype((com.google.javascript.rhino.jstype.JSType) functionType15);
        com.google.javascript.rhino.ErrorReporter errorReporter19 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry20 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter19);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable22 = jSTypeRegistry20.getEachReferenceTypeWithProperty("goog.global");
        com.google.javascript.rhino.jstype.JSType jSType23 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray24 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType25 = jSTypeRegistry20.createConstructorTypeWithVarArgs(jSType23, jSTypeArray24);
        com.google.javascript.rhino.JSDocInfo jSDocInfo26 = functionType25.getJSDocInfo();
        boolean boolean27 = functionType25.isAllType();
        int int28 = functionType25.getMaxArguments();
        com.google.javascript.rhino.Node node29 = com.google.javascript.rhino.IR.trueNode();
        java.lang.String str30 = node29.getSourceFileName();
        boolean boolean31 = node29.isOr();
        boolean boolean32 = functionType15.defineInferredProperty("hi!", (com.google.javascript.rhino.jstype.JSType) functionType25, node29);
        com.google.javascript.rhino.Node node34 = com.google.javascript.rhino.IR.stringKey("");
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable35 = node34.siblings();
        boolean boolean36 = node34.isQualifiedName();
        node34.setString("");
        node34.removeProp((int) ' ');
        com.google.javascript.rhino.Node node41 = node29.srcrefTree(node34);
        node34.setOptionalArg(true);
        org.junit.Assert.assertNotNull(objectTypeIterable3);
        org.junit.Assert.assertNotNull(jSTypeArray5);
        org.junit.Assert.assertNotNull(functionType6);
        org.junit.Assert.assertNull(jSDocInfo7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(objectTypeIterable12);
        org.junit.Assert.assertNotNull(jSTypeArray14);
        org.junit.Assert.assertNotNull(functionType15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(objectTypeIterable22);
        org.junit.Assert.assertNotNull(jSTypeArray24);
        org.junit.Assert.assertNotNull(functionType25);
        org.junit.Assert.assertNull(jSDocInfo26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNull(str30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNotNull(node34);
        org.junit.Assert.assertNotNull(nodeIterable35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(node41);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.stringKey("");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.IR.stringKey("");
        com.google.javascript.rhino.Node node4 = null;
        int int5 = node3.getIndexOfChild(node4);
        node1.addChildrenToBack(node3);
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.IR.block();
        java.lang.String str11 = node7.toString(false, false, false);
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.IR.stringKey("");
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable15 = node14.siblings();
        com.google.javascript.rhino.Node node18 = new com.google.javascript.rhino.Node((int) (short) 100, node14, (int) (short) 1, (int) (short) 10);
        com.google.javascript.rhino.Node node19 = node7.useSourceInfoIfMissingFrom(node18);
        com.google.javascript.rhino.Node node20 = node3.srcref(node7);
        java.lang.Appendable appendable21 = null;
        try {
            node3.appendStringTree(appendable21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "BLOCK" + "'", str11.equals("BLOCK"));
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNotNull(nodeIterable15);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNotNull(node20);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.computeFunctionSideEffects = true;
        boolean boolean3 = compilerOptions0.ideMode;
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention4 = new com.google.javascript.jscomp.GoogleCodingConvention();
        compilerOptions0.setCodingConvention((com.google.javascript.jscomp.CodingConvention) googleCodingConvention4);
        com.google.javascript.rhino.Node node7 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode((com.google.javascript.jscomp.CodingConvention) googleCodingConvention4, "InputId: Not declared as a constructor");
        boolean boolean8 = node7.isSetterDef();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.stringKey("");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.IR.stringKey("");
        com.google.javascript.rhino.Node node4 = null;
        int int5 = node3.getIndexOfChild(node4);
        node1.addChildrenToBack(node3);
        boolean boolean7 = node1.isLocalResultCall();
        boolean boolean8 = node1.isGetterDef();
        node1.setType(40);
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable3 = jSTypeRegistry1.getEachReferenceTypeWithProperty("goog.global");
        com.google.javascript.rhino.jstype.JSType jSType4 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray5 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType6 = jSTypeRegistry1.createConstructorTypeWithVarArgs(jSType4, jSTypeArray5);
        com.google.javascript.rhino.ErrorReporter errorReporter7 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry8 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter7);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable10 = jSTypeRegistry8.getEachReferenceTypeWithProperty("goog.global");
        com.google.javascript.rhino.jstype.JSType jSType11 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray12 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType13 = jSTypeRegistry8.createConstructorTypeWithVarArgs(jSType11, jSTypeArray12);
        com.google.javascript.rhino.JSDocInfo jSDocInfo14 = functionType13.getJSDocInfo();
        boolean boolean15 = functionType13.isAllType();
        com.google.javascript.rhino.ErrorReporter errorReporter16 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry17 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter16);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable19 = jSTypeRegistry17.getEachReferenceTypeWithProperty("goog.global");
        com.google.javascript.rhino.jstype.JSType jSType20 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray21 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType22 = jSTypeRegistry17.createConstructorTypeWithVarArgs(jSType20, jSTypeArray21);
        int int23 = functionType22.getMaxArguments();
        boolean boolean24 = functionType13.isSubtype((com.google.javascript.rhino.jstype.JSType) functionType22);
        com.google.javascript.rhino.jstype.JSType jSType25 = functionType13.collapseUnion();
        com.google.javascript.rhino.ErrorReporter errorReporter27 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry28 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter27);
        com.google.javascript.rhino.ErrorReporter errorReporter29 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry30 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter29);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable32 = jSTypeRegistry30.getEachReferenceTypeWithProperty("goog.global");
        com.google.javascript.rhino.jstype.JSType jSType33 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray34 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType35 = jSTypeRegistry30.createConstructorTypeWithVarArgs(jSType33, jSTypeArray34);
        com.google.javascript.rhino.JSDocInfo jSDocInfo36 = functionType35.getJSDocInfo();
        boolean boolean37 = functionType35.isAllType();
        com.google.javascript.rhino.ErrorReporter errorReporter38 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry39 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter38);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable41 = jSTypeRegistry39.getEachReferenceTypeWithProperty("goog.global");
        com.google.javascript.rhino.jstype.JSType jSType42 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray43 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType44 = jSTypeRegistry39.createConstructorTypeWithVarArgs(jSType42, jSTypeArray43);
        int int45 = functionType44.getMaxArguments();
        boolean boolean46 = functionType35.isSubtype((com.google.javascript.rhino.jstype.JSType) functionType44);
        com.google.javascript.rhino.ErrorReporter errorReporter48 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry49 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter48);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable51 = jSTypeRegistry49.getEachReferenceTypeWithProperty("goog.global");
        com.google.javascript.rhino.jstype.JSType jSType52 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray53 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType54 = jSTypeRegistry49.createConstructorTypeWithVarArgs(jSType52, jSTypeArray53);
        com.google.javascript.rhino.JSDocInfo jSDocInfo55 = functionType54.getJSDocInfo();
        boolean boolean56 = functionType54.isAllType();
        int int57 = functionType54.getMaxArguments();
        com.google.javascript.rhino.Node node58 = com.google.javascript.rhino.IR.trueNode();
        java.lang.String str59 = node58.getSourceFileName();
        boolean boolean60 = node58.isOr();
        boolean boolean61 = functionType44.defineInferredProperty("hi!", (com.google.javascript.rhino.jstype.JSType) functionType54, node58);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray63 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType64 = jSTypeRegistry28.createConstructorType((com.google.javascript.rhino.jstype.JSType) functionType54, false, jSTypeArray63);
        com.google.javascript.rhino.jstype.FunctionType functionType65 = jSTypeRegistry1.createFunctionType((com.google.javascript.rhino.jstype.JSType) functionType13, false, jSTypeArray63);
        int int66 = functionType13.getMinArguments();
        org.junit.Assert.assertNotNull(objectTypeIterable3);
        org.junit.Assert.assertNotNull(jSTypeArray5);
        org.junit.Assert.assertNotNull(functionType6);
        org.junit.Assert.assertNotNull(objectTypeIterable10);
        org.junit.Assert.assertNotNull(jSTypeArray12);
        org.junit.Assert.assertNotNull(functionType13);
        org.junit.Assert.assertNull(jSDocInfo14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(objectTypeIterable19);
        org.junit.Assert.assertNotNull(jSTypeArray21);
        org.junit.Assert.assertNotNull(functionType22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(jSType25);
        org.junit.Assert.assertNotNull(objectTypeIterable32);
        org.junit.Assert.assertNotNull(jSTypeArray34);
        org.junit.Assert.assertNotNull(functionType35);
        org.junit.Assert.assertNull(jSDocInfo36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(objectTypeIterable41);
        org.junit.Assert.assertNotNull(jSTypeArray43);
        org.junit.Assert.assertNotNull(functionType44);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 0 + "'", int45 == 0);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
        org.junit.Assert.assertNotNull(objectTypeIterable51);
        org.junit.Assert.assertNotNull(jSTypeArray53);
        org.junit.Assert.assertNotNull(functionType54);
        org.junit.Assert.assertNull(jSDocInfo55);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 0 + "'", int57 == 0);
        org.junit.Assert.assertNotNull(node58);
        org.junit.Assert.assertNull(str59);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + true + "'", boolean61 == true);
        org.junit.Assert.assertNotNull(jSTypeArray63);
        org.junit.Assert.assertNotNull(functionType64);
        org.junit.Assert.assertNotNull(functionType65);
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 0 + "'", int66 == 0);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        com.google.javascript.rhino.ErrorReporter errorReporter2 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry3 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter2);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable5 = jSTypeRegistry3.getEachReferenceTypeWithProperty("goog.global");
        com.google.javascript.rhino.jstype.JSType jSType6 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray7 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType8 = jSTypeRegistry3.createConstructorTypeWithVarArgs(jSType6, jSTypeArray7);
        com.google.javascript.rhino.JSDocInfo jSDocInfo9 = functionType8.getJSDocInfo();
        boolean boolean10 = functionType8.isAllType();
        com.google.javascript.rhino.ErrorReporter errorReporter11 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry12 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter11);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable14 = jSTypeRegistry12.getEachReferenceTypeWithProperty("goog.global");
        com.google.javascript.rhino.jstype.JSType jSType15 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray16 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType17 = jSTypeRegistry12.createConstructorTypeWithVarArgs(jSType15, jSTypeArray16);
        int int18 = functionType17.getMaxArguments();
        boolean boolean19 = functionType8.isSubtype((com.google.javascript.rhino.jstype.JSType) functionType17);
        com.google.javascript.rhino.ErrorReporter errorReporter21 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry22 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter21);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable24 = jSTypeRegistry22.getEachReferenceTypeWithProperty("goog.global");
        com.google.javascript.rhino.jstype.JSType jSType25 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray26 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType27 = jSTypeRegistry22.createConstructorTypeWithVarArgs(jSType25, jSTypeArray26);
        com.google.javascript.rhino.JSDocInfo jSDocInfo28 = functionType27.getJSDocInfo();
        boolean boolean29 = functionType27.isAllType();
        int int30 = functionType27.getMaxArguments();
        com.google.javascript.rhino.Node node31 = com.google.javascript.rhino.IR.trueNode();
        java.lang.String str32 = node31.getSourceFileName();
        boolean boolean33 = node31.isOr();
        boolean boolean34 = functionType17.defineInferredProperty("hi!", (com.google.javascript.rhino.jstype.JSType) functionType27, node31);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray36 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType37 = jSTypeRegistry1.createConstructorType((com.google.javascript.rhino.jstype.JSType) functionType27, false, jSTypeArray36);
        functionType27.clearCachedValues();
        org.junit.Assert.assertNotNull(objectTypeIterable5);
        org.junit.Assert.assertNotNull(jSTypeArray7);
        org.junit.Assert.assertNotNull(functionType8);
        org.junit.Assert.assertNull(jSDocInfo9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(objectTypeIterable14);
        org.junit.Assert.assertNotNull(jSTypeArray16);
        org.junit.Assert.assertNotNull(functionType17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(objectTypeIterable24);
        org.junit.Assert.assertNotNull(jSTypeArray26);
        org.junit.Assert.assertNotNull(functionType27);
        org.junit.Assert.assertNull(jSDocInfo28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertNull(str32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertNotNull(jSTypeArray36);
        org.junit.Assert.assertNotNull(functionType37);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.computeFunctionSideEffects = true;
        boolean boolean3 = compilerOptions0.isRemoveUnusedClassProperties();
        boolean boolean4 = compilerOptions0.isExternExportsEnabled();
        compilerOptions0.markAsCompiled = false;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.IR.stringKey("");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.IR.stringKey("");
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.IR.block();
        com.google.javascript.rhino.Node node8 = new com.google.javascript.rhino.Node((int) ' ', node2, node4, node5, 0, (int) (short) -1);
        boolean boolean9 = node2.isThrow();
        boolean boolean10 = node2.isStringKey();
        com.google.javascript.rhino.Node node11 = node2.getLastChild();
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNull(node11);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.IR.stringKey("");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.IR.stringKey("");
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.IR.block();
        com.google.javascript.rhino.Node node8 = new com.google.javascript.rhino.Node((int) ' ', node2, node4, node5, 0, (int) (short) -1);
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.IR.stringKey("");
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.IR.stringKey("");
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.IR.block();
        com.google.javascript.rhino.Node node17 = new com.google.javascript.rhino.Node((int) ' ', node11, node13, node14, 0, (int) (short) -1);
        boolean boolean18 = node11.isThrow();
        int int19 = node5.getIndexOfChild(node11);
        com.google.javascript.rhino.Node node21 = com.google.javascript.rhino.IR.stringKey("");
        int int22 = node21.getLineno();
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.IR.block();
        java.lang.String str27 = node23.toString(false, false, false);
        com.google.javascript.rhino.Node node28 = com.google.javascript.rhino.IR.block();
        java.lang.String str32 = node28.toString(false, false, false);
        com.google.javascript.rhino.Node node33 = node23.useSourceInfoIfMissingFrom(node28);
        com.google.javascript.rhino.Node node34 = node21.srcrefTree(node23);
        com.google.javascript.rhino.Node node35 = node5.useSourceInfoIfMissingFromForTree(node21);
        com.google.javascript.rhino.Node node36 = com.google.javascript.rhino.IR.returnNode();
        boolean boolean37 = node36.isEmpty();
        int int38 = node36.getSourceOffset();
        boolean boolean39 = node36.isGetProp();
        boolean boolean40 = node35.isEquivalentTo(node36);
        try {
            com.google.javascript.rhino.Node node41 = com.google.javascript.rhino.IR.regexp(node36);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "BLOCK" + "'", str27.equals("BLOCK"));
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "BLOCK" + "'", str32.equals("BLOCK"));
        org.junit.Assert.assertNotNull(node33);
        org.junit.Assert.assertNotNull(node34);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertNotNull(node36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + (-1) + "'", int38 == (-1));
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        java.lang.String[] strArray5 = new java.lang.String[] { "module$hi!", "", "hi!" };
        java.util.ArrayList<java.lang.String> strList6 = new java.util.ArrayList<java.lang.String>();
        boolean boolean7 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strList6, strArray5);
        java.lang.String[] strArray18 = new java.lang.String[] { "Not declared as a constructor", "InputId: Not declared as a constructor", "goog.global", "./", "./", "BLOCK", "Not declared as a constructor", "JSDocInfo", "InputId: Not declared as a constructor", "" };
        java.util.ArrayList<java.lang.String> strList19 = new java.util.ArrayList<java.lang.String>();
        boolean boolean20 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strList19, strArray18);
        com.google.javascript.jscomp.deps.SimpleDependencyInfo simpleDependencyInfo21 = new com.google.javascript.jscomp.deps.SimpleDependencyInfo("this", "BLOCK", (java.util.List<java.lang.String>) strList6, (java.util.List<java.lang.String>) strList19);
        java.lang.Object obj22 = null;
        boolean boolean23 = simpleDependencyInfo21.equals(obj22);
        java.lang.String str24 = simpleDependencyInfo21.getPathRelativeToClosureBase();
        java.lang.String[] strArray30 = new java.lang.String[] { "module$hi!", "", "hi!" };
        java.util.ArrayList<java.lang.String> strList31 = new java.util.ArrayList<java.lang.String>();
        boolean boolean32 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strList31, strArray30);
        java.lang.String[] strArray43 = new java.lang.String[] { "Not declared as a constructor", "InputId: Not declared as a constructor", "goog.global", "./", "./", "BLOCK", "Not declared as a constructor", "JSDocInfo", "InputId: Not declared as a constructor", "" };
        java.util.ArrayList<java.lang.String> strList44 = new java.util.ArrayList<java.lang.String>();
        boolean boolean45 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strList44, strArray43);
        com.google.javascript.jscomp.deps.SimpleDependencyInfo simpleDependencyInfo46 = new com.google.javascript.jscomp.deps.SimpleDependencyInfo("this", "BLOCK", (java.util.List<java.lang.String>) strList31, (java.util.List<java.lang.String>) strList44);
        java.lang.Object obj47 = null;
        boolean boolean48 = simpleDependencyInfo46.equals(obj47);
        java.lang.String str49 = simpleDependencyInfo46.getPathRelativeToClosureBase();
        java.util.List<java.lang.String> strList52 = null;
        java.lang.String[] strArray57 = new java.lang.String[] { "BLOCK", "BLOCK", "hi!", "BLOCK" };
        java.util.ArrayList<java.lang.String> strList58 = new java.util.ArrayList<java.lang.String>();
        boolean boolean59 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strList58, strArray57);
        com.google.javascript.jscomp.deps.SimpleDependencyInfo simpleDependencyInfo60 = new com.google.javascript.jscomp.deps.SimpleDependencyInfo("hi!", "hi!", strList52, (java.util.List<java.lang.String>) strList58);
        java.lang.String str61 = simpleDependencyInfo60.getPathRelativeToClosureBase();
        com.google.javascript.jscomp.deps.SimpleDependencyInfo[] simpleDependencyInfoArray62 = new com.google.javascript.jscomp.deps.SimpleDependencyInfo[] { simpleDependencyInfo21, simpleDependencyInfo46, simpleDependencyInfo60 };
        java.util.ArrayList<com.google.javascript.jscomp.deps.SimpleDependencyInfo> simpleDependencyInfoList63 = new java.util.ArrayList<com.google.javascript.jscomp.deps.SimpleDependencyInfo>();
        boolean boolean64 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.deps.SimpleDependencyInfo>) simpleDependencyInfoList63, simpleDependencyInfoArray62);
        try {
            com.google.javascript.jscomp.deps.SortedDependencies<com.google.javascript.jscomp.deps.SimpleDependencyInfo> simpleDependencyInfoSortedDependencies65 = new com.google.javascript.jscomp.deps.SortedDependencies<com.google.javascript.jscomp.deps.SimpleDependencyInfo>((java.util.List<com.google.javascript.jscomp.deps.SimpleDependencyInfo>) simpleDependencyInfoList63);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(strArray18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "this" + "'", str24.equals("this"));
        org.junit.Assert.assertNotNull(strArray30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNotNull(strArray43);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "this" + "'", str49.equals("this"));
        org.junit.Assert.assertNotNull(strArray57);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + true + "'", boolean59 == true);
        org.junit.Assert.assertTrue("'" + str61 + "' != '" + "hi!" + "'", str61.equals("hi!"));
        org.junit.Assert.assertNotNull(simpleDependencyInfoArray62);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + true + "'", boolean64 == true);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.SourceFile sourceFile3 = com.google.javascript.jscomp.SourceFile.fromFile("./");
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray4 = new com.google.javascript.jscomp.JSSourceFile[] {};
        com.google.javascript.jscomp.CompilerOptions compilerOptions5 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean6 = compilerOptions5.isExternExportsEnabled();
        com.google.javascript.jscomp.Result result7 = compiler1.compile(sourceFile3, jSSourceFileArray4, compilerOptions5);
        com.google.javascript.jscomp.SourceMap sourceMap8 = compiler1.getSourceMap();
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter9 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler1);
        com.google.javascript.jscomp.ErrorManager errorManager10 = compiler1.getErrorManager();
        com.google.javascript.jscomp.JSModule jSModule11 = null;
        try {
            java.lang.String[] strArray12 = compiler1.toSourceArray(jSModule11);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: java.lang.NullPointerException");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(sourceFile3);
        org.junit.Assert.assertNotNull(jSSourceFileArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(result7);
        org.junit.Assert.assertNull(sourceMap8);
        org.junit.Assert.assertNotNull(errorManager10);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        com.google.javascript.jscomp.SourceMap.Format format0 = com.google.javascript.jscomp.SourceMap.Format.V1;
        org.junit.Assert.assertNotNull(format0);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.block();
        boolean boolean1 = node0.isCase();
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.IR.stringKey("");
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable4 = node3.siblings();
        boolean boolean5 = node3.isQualifiedName();
        com.google.javascript.rhino.Node node6 = node3.getLastChild();
        try {
            com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.IR.or(node0, node6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(nodeIterable4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(node6);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        int int0 = com.google.javascript.rhino.Node.QUOTED_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 36 + "'", int0 == 36);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.SourceFile sourceFile3 = com.google.javascript.jscomp.SourceFile.fromFile("./");
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray4 = new com.google.javascript.jscomp.JSSourceFile[] {};
        com.google.javascript.jscomp.CompilerOptions compilerOptions5 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean6 = compilerOptions5.isExternExportsEnabled();
        com.google.javascript.jscomp.Result result7 = compiler1.compile(sourceFile3, jSSourceFileArray4, compilerOptions5);
        com.google.javascript.jscomp.SourceFile sourceFile8 = null;
        try {
            com.google.javascript.rhino.Node node9 = compiler1.parse(sourceFile8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(sourceFile3);
        org.junit.Assert.assertNotNull(jSSourceFileArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(result7);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.IR.stringKey("");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.IR.stringKey("");
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.IR.block();
        com.google.javascript.rhino.Node node8 = new com.google.javascript.rhino.Node((int) ' ', node2, node4, node5, 0, (int) (short) -1);
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.IR.stringKey("");
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.IR.stringKey("");
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.IR.block();
        com.google.javascript.rhino.Node node17 = new com.google.javascript.rhino.Node((int) ' ', node11, node13, node14, 0, (int) (short) -1);
        boolean boolean18 = node11.isThrow();
        int int19 = node5.getIndexOfChild(node11);
        com.google.javascript.rhino.Node node21 = com.google.javascript.rhino.IR.stringKey("");
        int int22 = node21.getLineno();
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.IR.block();
        java.lang.String str27 = node23.toString(false, false, false);
        com.google.javascript.rhino.Node node28 = com.google.javascript.rhino.IR.block();
        java.lang.String str32 = node28.toString(false, false, false);
        com.google.javascript.rhino.Node node33 = node23.useSourceInfoIfMissingFrom(node28);
        com.google.javascript.rhino.Node node34 = node21.srcrefTree(node23);
        com.google.javascript.rhino.Node node35 = node5.useSourceInfoIfMissingFromForTree(node21);
        boolean boolean36 = com.google.javascript.jscomp.NodeUtil.isSymmetricOperation(node35);
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "BLOCK" + "'", str27.equals("BLOCK"));
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "BLOCK" + "'", str32.equals("BLOCK"));
        org.junit.Assert.assertNotNull(node33);
        org.junit.Assert.assertNotNull(node34);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        com.google.javascript.rhino.JSDocInfo jSDocInfo0 = new com.google.javascript.rhino.JSDocInfo();
        java.util.List<com.google.javascript.rhino.JSTypeExpression> jSTypeExpressionList1 = jSDocInfo0.getImplementedInterfaces();
        java.util.Set<java.lang.String> strSet2 = jSDocInfo0.getSuppressions();
        com.google.javascript.rhino.JSDocInfo.Visibility visibility3 = jSDocInfo0.getVisibility();
        com.google.javascript.rhino.JSTypeExpression jSTypeExpression4 = jSDocInfo0.getEnumParameterType();
        com.google.javascript.rhino.JSTypeExpression jSTypeExpression5 = jSDocInfo0.getBaseType();
        java.util.Set<java.lang.String> strSet6 = jSDocInfo0.getSuppressions();
        org.junit.Assert.assertNotNull(jSTypeExpressionList1);
        org.junit.Assert.assertNotNull(strSet2);
        org.junit.Assert.assertNull(visibility3);
        org.junit.Assert.assertNull(jSTypeExpression4);
        org.junit.Assert.assertNull(jSTypeExpression5);
        org.junit.Assert.assertNotNull(strSet6);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.block();
        boolean boolean1 = node0.isCase();
        node0.setIsSyntheticBlock(false);
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.CHECK_USELESS_CODE;
        com.google.javascript.jscomp.DiagnosticGroups.AMBIGUOUS_FUNCTION_DECL = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticGroups.CHECK_REGEXP = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticGroups.FILEOVERVIEW_JSDOC = diagnosticGroup0;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeUnusedPrototypePropertiesInExterns = true;
        java.util.Map<java.lang.String, java.lang.Object> strMap3 = null;
        compilerOptions0.setTweakReplacements(strMap3);
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy5 = null;
        compilerOptions0.variableRenaming = variableRenamingPolicy5;
        compilerOptions0.computeFunctionSideEffects = false;
        boolean boolean9 = compilerOptions0.extractPrototypeMemberDeclarations;
        compilerOptions0.setRemoveAbstractMethods(true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.computeFunctionSideEffects = true;
        boolean boolean3 = compilerOptions0.isRemoveUnusedClassProperties();
        com.google.javascript.jscomp.ErrorHandler errorHandler4 = null;
        compilerOptions0.setErrorHandler(errorHandler4);
        compilerOptions0.optimizeParameters = false;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.FUNCTION_INSTANCE_TYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.FUNCTION_INSTANCE_TYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.FUNCTION_INSTANCE_TYPE));
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.computeFunctionSideEffects = true;
        boolean boolean3 = compilerOptions0.isRemoveUnusedClassProperties();
        com.google.javascript.jscomp.ErrorHandler errorHandler4 = null;
        compilerOptions0.setErrorHandler(errorHandler4);
        java.util.List<com.google.javascript.jscomp.SourceMap.LocationMapping> locationMappingList6 = compilerOptions0.sourceMapLocationMappings;
        com.google.javascript.jscomp.CheckLevel checkLevel7 = com.google.javascript.jscomp.CheckLevel.ERROR;
        compilerOptions0.setCheckProvides(checkLevel7);
        compilerOptions0.crossModuleCodeMotion = false;
        com.google.javascript.jscomp.CompilerOptions.AliasTransformationHandler aliasTransformationHandler11 = null;
        compilerOptions0.setAliasTransformationHandler(aliasTransformationHandler11);
        com.google.javascript.jscomp.CompilerOptions compilerOptions13 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions13.computeFunctionSideEffects = true;
        boolean boolean16 = compilerOptions13.removeUnusedVars;
        java.lang.String[] strArray28 = new java.lang.String[] { "InputId: Not declared as a constructor", ".", "BLOCK", "InputId: Not declared as a constructor", "Not declared as a constructor", "module$hi!", ".", "JSDocInfo", "module$hi!", ".", "hi!" };
        java.util.LinkedHashSet<java.lang.String> strSet29 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean30 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet29, strArray28);
        compilerOptions13.setIdGenerators((java.util.Set<java.lang.String>) strSet29);
        compilerOptions0.stripTypes = strSet29;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(locationMappingList6);
        org.junit.Assert.assertTrue("'" + checkLevel7 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel7.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(strArray28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        java.util.logging.Logger logger0 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager1 = new com.google.javascript.jscomp.LoggerErrorManager(logger0);
        com.google.javascript.jscomp.CompilerOptions compilerOptions2 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions2.computeFunctionSideEffects = true;
        boolean boolean5 = compilerOptions2.isRemoveUnusedClassProperties();
        com.google.javascript.jscomp.ErrorHandler errorHandler6 = null;
        compilerOptions2.setErrorHandler(errorHandler6);
        java.util.List<com.google.javascript.jscomp.SourceMap.LocationMapping> locationMappingList8 = compilerOptions2.sourceMapLocationMappings;
        com.google.javascript.jscomp.CheckLevel checkLevel9 = com.google.javascript.jscomp.CheckLevel.ERROR;
        compilerOptions2.setCheckProvides(checkLevel9);
        com.google.javascript.jscomp.CompilerOptions compilerOptions11 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions11.computeFunctionSideEffects = true;
        boolean boolean14 = compilerOptions11.isRemoveUnusedClassProperties();
        com.google.javascript.jscomp.ErrorHandler errorHandler15 = null;
        compilerOptions11.setErrorHandler(errorHandler15);
        java.util.List<com.google.javascript.jscomp.SourceMap.LocationMapping> locationMappingList17 = compilerOptions11.sourceMapLocationMappings;
        com.google.javascript.jscomp.CheckLevel checkLevel18 = com.google.javascript.jscomp.CheckLevel.ERROR;
        compilerOptions11.setCheckProvides(checkLevel18);
        compilerOptions2.reportMissingOverride = checkLevel18;
        com.google.javascript.jscomp.JSError jSError21 = null;
        try {
            loggerErrorManager1.report(checkLevel18, jSError21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(locationMappingList8);
        org.junit.Assert.assertTrue("'" + checkLevel9 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel9.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(locationMappingList17);
        org.junit.Assert.assertTrue("'" + checkLevel18 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel18.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.IR.stringKey("");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.IR.stringKey("");
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.IR.block();
        com.google.javascript.rhino.Node node8 = new com.google.javascript.rhino.Node((int) ' ', node2, node4, node5, 0, (int) (short) -1);
        boolean boolean9 = node2.isThrow();
        boolean boolean10 = node2.isTry();
        boolean boolean11 = node2.isIn();
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.IR.stringKey("goog.global");
        com.google.javascript.rhino.Node node14 = node2.copyInformationFromForTree(node13);
        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.IR.continueNode();
        com.google.javascript.rhino.Node node19 = new com.google.javascript.rhino.Node(10, node16, 35, 0);
        try {
            com.google.javascript.rhino.Node node20 = node14.removeChildAfter(node16);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: prev is not a child of this node.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNotNull(node16);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        boolean boolean3 = jSTypeRegistry1.hasNamespace("module$hi!");
        com.google.javascript.rhino.ErrorReporter errorReporter5 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry6 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter5);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable8 = jSTypeRegistry6.getEachReferenceTypeWithProperty("goog.global");
        com.google.javascript.rhino.jstype.JSType jSType9 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray10 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType11 = jSTypeRegistry6.createConstructorTypeWithVarArgs(jSType9, jSTypeArray10);
        com.google.javascript.rhino.JSDocInfo jSDocInfo12 = functionType11.getJSDocInfo();
        boolean boolean13 = functionType11.isAllType();
        com.google.javascript.rhino.ErrorReporter errorReporter14 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry15 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter14);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable17 = jSTypeRegistry15.getEachReferenceTypeWithProperty("goog.global");
        com.google.javascript.rhino.jstype.JSType jSType18 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray19 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType20 = jSTypeRegistry15.createConstructorTypeWithVarArgs(jSType18, jSTypeArray19);
        int int21 = functionType20.getMaxArguments();
        boolean boolean22 = functionType11.isSubtype((com.google.javascript.rhino.jstype.JSType) functionType20);
        jSTypeRegistry1.unregisterPropertyOnType("goog.exportProperty", (com.google.javascript.rhino.jstype.JSType) functionType20);
        com.google.javascript.rhino.ErrorReporter errorReporter24 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry25 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter24);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable27 = jSTypeRegistry25.getEachReferenceTypeWithProperty("goog.global");
        com.google.javascript.rhino.jstype.JSType jSType28 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray29 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType30 = jSTypeRegistry25.createConstructorTypeWithVarArgs(jSType28, jSTypeArray29);
        com.google.javascript.rhino.JSDocInfo jSDocInfo31 = functionType30.getJSDocInfo();
        com.google.javascript.rhino.jstype.JSType jSType33 = functionType30.getRestrictedTypeGivenToBooleanOutcome(true);
        com.google.javascript.rhino.jstype.JSType jSType34 = jSTypeRegistry1.createOptionalType(jSType33);
        com.google.javascript.rhino.jstype.JSType jSType35 = null;
        try {
            com.google.javascript.rhino.jstype.JSType jSType36 = jSTypeRegistry1.createDefaultObjectUnion(jSType35);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(objectTypeIterable8);
        org.junit.Assert.assertNotNull(jSTypeArray10);
        org.junit.Assert.assertNotNull(functionType11);
        org.junit.Assert.assertNull(jSDocInfo12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(objectTypeIterable17);
        org.junit.Assert.assertNotNull(jSTypeArray19);
        org.junit.Assert.assertNotNull(functionType20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(objectTypeIterable27);
        org.junit.Assert.assertNotNull(jSTypeArray29);
        org.junit.Assert.assertNotNull(functionType30);
        org.junit.Assert.assertNull(jSDocInfo31);
        org.junit.Assert.assertNotNull(jSType33);
        org.junit.Assert.assertNotNull(jSType34);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.ACCESS_CONTROLS;
        com.google.javascript.jscomp.CheckLevel checkLevel1 = com.google.javascript.jscomp.CheckLevel.ERROR;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard2 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup0, checkLevel1);
        com.google.javascript.jscomp.DiagnosticGroups.CHECK_PROVIDES = diagnosticGroup0;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        com.google.javascript.rhino.ErrorReporter errorReporter2 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry3 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter2);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable5 = jSTypeRegistry3.getEachReferenceTypeWithProperty("goog.global");
        com.google.javascript.rhino.jstype.JSType jSType6 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray7 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType8 = jSTypeRegistry3.createConstructorTypeWithVarArgs(jSType6, jSTypeArray7);
        com.google.javascript.rhino.JSDocInfo jSDocInfo9 = functionType8.getJSDocInfo();
        boolean boolean10 = functionType8.isAllType();
        com.google.javascript.rhino.ErrorReporter errorReporter11 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry12 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter11);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable14 = jSTypeRegistry12.getEachReferenceTypeWithProperty("goog.global");
        com.google.javascript.rhino.jstype.JSType jSType15 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray16 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType17 = jSTypeRegistry12.createConstructorTypeWithVarArgs(jSType15, jSTypeArray16);
        int int18 = functionType17.getMaxArguments();
        boolean boolean19 = functionType8.isSubtype((com.google.javascript.rhino.jstype.JSType) functionType17);
        com.google.javascript.rhino.ErrorReporter errorReporter21 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry22 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter21);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable24 = jSTypeRegistry22.getEachReferenceTypeWithProperty("goog.global");
        com.google.javascript.rhino.jstype.JSType jSType25 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray26 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType27 = jSTypeRegistry22.createConstructorTypeWithVarArgs(jSType25, jSTypeArray26);
        com.google.javascript.rhino.JSDocInfo jSDocInfo28 = functionType27.getJSDocInfo();
        boolean boolean29 = functionType27.isAllType();
        int int30 = functionType27.getMaxArguments();
        com.google.javascript.rhino.Node node31 = com.google.javascript.rhino.IR.trueNode();
        java.lang.String str32 = node31.getSourceFileName();
        boolean boolean33 = node31.isOr();
        boolean boolean34 = functionType17.defineInferredProperty("hi!", (com.google.javascript.rhino.jstype.JSType) functionType27, node31);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray36 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType37 = jSTypeRegistry1.createConstructorType((com.google.javascript.rhino.jstype.JSType) functionType27, false, jSTypeArray36);
        com.google.javascript.rhino.ErrorReporter errorReporter38 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry39 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter38);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable41 = jSTypeRegistry39.getEachReferenceTypeWithProperty("goog.global");
        com.google.javascript.rhino.jstype.JSType jSType42 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray43 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType44 = jSTypeRegistry39.createConstructorTypeWithVarArgs(jSType42, jSTypeArray43);
        com.google.javascript.rhino.JSDocInfo jSDocInfo45 = functionType44.getJSDocInfo();
        boolean boolean46 = functionType44.isAllType();
        com.google.javascript.rhino.ErrorReporter errorReporter47 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry48 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter47);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable50 = jSTypeRegistry48.getEachReferenceTypeWithProperty("goog.global");
        com.google.javascript.rhino.jstype.JSType jSType51 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray52 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType53 = jSTypeRegistry48.createConstructorTypeWithVarArgs(jSType51, jSTypeArray52);
        int int54 = functionType53.getMaxArguments();
        boolean boolean55 = functionType44.isSubtype((com.google.javascript.rhino.jstype.JSType) functionType53);
        java.io.PrintStream printStream56 = null;
        com.google.javascript.jscomp.Compiler compiler57 = new com.google.javascript.jscomp.Compiler(printStream56);
        com.google.javascript.jscomp.NodeTraversal.Callback callback58 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal59 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler57, callback58);
        boolean boolean60 = functionType44.equals((java.lang.Object) nodeTraversal59);
        com.google.javascript.rhino.jstype.JSType jSType61 = jSTypeRegistry1.createOptionalNullableType((com.google.javascript.rhino.jstype.JSType) functionType44);
        com.google.javascript.rhino.ErrorReporter errorReporter62 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry63 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter62);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable65 = jSTypeRegistry63.getEachReferenceTypeWithProperty("goog.global");
        com.google.javascript.rhino.jstype.JSType jSType66 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray67 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType68 = jSTypeRegistry63.createConstructorTypeWithVarArgs(jSType66, jSTypeArray67);
        com.google.javascript.rhino.JSDocInfo jSDocInfo69 = functionType68.getJSDocInfo();
        com.google.javascript.rhino.Node node72 = com.google.javascript.rhino.IR.stringKey("");
        com.google.javascript.rhino.Node node74 = com.google.javascript.rhino.IR.stringKey("");
        com.google.javascript.rhino.Node node75 = com.google.javascript.rhino.IR.block();
        com.google.javascript.rhino.Node node78 = new com.google.javascript.rhino.Node((int) ' ', node72, node74, node75, 0, (int) (short) -1);
        boolean boolean79 = node72.isThrow();
        com.google.javascript.rhino.Node node81 = node72.getAncestor((int) '#');
        com.google.javascript.rhino.jstype.FunctionType functionType82 = jSTypeRegistry1.createFunctionType((com.google.javascript.rhino.jstype.JSType) functionType68, node72);
        boolean boolean83 = functionType68.isString();
        org.junit.Assert.assertNotNull(objectTypeIterable5);
        org.junit.Assert.assertNotNull(jSTypeArray7);
        org.junit.Assert.assertNotNull(functionType8);
        org.junit.Assert.assertNull(jSDocInfo9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(objectTypeIterable14);
        org.junit.Assert.assertNotNull(jSTypeArray16);
        org.junit.Assert.assertNotNull(functionType17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(objectTypeIterable24);
        org.junit.Assert.assertNotNull(jSTypeArray26);
        org.junit.Assert.assertNotNull(functionType27);
        org.junit.Assert.assertNull(jSDocInfo28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertNull(str32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertNotNull(jSTypeArray36);
        org.junit.Assert.assertNotNull(functionType37);
        org.junit.Assert.assertNotNull(objectTypeIterable41);
        org.junit.Assert.assertNotNull(jSTypeArray43);
        org.junit.Assert.assertNotNull(functionType44);
        org.junit.Assert.assertNull(jSDocInfo45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(objectTypeIterable50);
        org.junit.Assert.assertNotNull(jSTypeArray52);
        org.junit.Assert.assertNotNull(functionType53);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 0 + "'", int54 == 0);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + true + "'", boolean55 == true);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertNotNull(jSType61);
        org.junit.Assert.assertNotNull(objectTypeIterable65);
        org.junit.Assert.assertNotNull(jSTypeArray67);
        org.junit.Assert.assertNotNull(functionType68);
        org.junit.Assert.assertNull(jSDocInfo69);
        org.junit.Assert.assertNotNull(node72);
        org.junit.Assert.assertNotNull(node74);
        org.junit.Assert.assertNotNull(node75);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
        org.junit.Assert.assertNull(node81);
        org.junit.Assert.assertNotNull(functionType82);
        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + false + "'", boolean83 == false);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable3 = jSTypeRegistry1.getEachReferenceTypeWithProperty("goog.global");
        com.google.javascript.rhino.jstype.JSType jSType4 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray5 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType6 = jSTypeRegistry1.createConstructorTypeWithVarArgs(jSType4, jSTypeArray5);
        com.google.javascript.rhino.ErrorReporter errorReporter7 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry8 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter7);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable10 = jSTypeRegistry8.getEachReferenceTypeWithProperty("goog.global");
        com.google.javascript.rhino.jstype.JSType jSType11 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray12 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType13 = jSTypeRegistry8.createConstructorTypeWithVarArgs(jSType11, jSTypeArray12);
        com.google.javascript.rhino.ErrorReporter errorReporter14 = jSTypeRegistry8.getErrorReporter();
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.IR.stringKey("");
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.IR.stringKey("");
        com.google.javascript.rhino.Node node20 = null;
        int int21 = node19.getIndexOfChild(node20);
        node17.addChildrenToBack(node19);
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.IR.block();
        java.lang.String str27 = node23.toString(false, false, false);
        com.google.javascript.rhino.Node node30 = com.google.javascript.rhino.IR.stringKey("");
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable31 = node30.siblings();
        com.google.javascript.rhino.Node node34 = new com.google.javascript.rhino.Node((int) (short) 100, node30, (int) (short) 1, (int) (short) 10);
        com.google.javascript.rhino.Node node35 = node23.useSourceInfoIfMissingFrom(node34);
        com.google.javascript.rhino.Node node36 = node19.srcref(node23);
        com.google.javascript.rhino.ErrorReporter errorReporter37 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry38 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter37);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable40 = jSTypeRegistry38.getEachReferenceTypeWithProperty("goog.global");
        com.google.javascript.rhino.jstype.JSType jSType41 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray42 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType43 = jSTypeRegistry38.createConstructorTypeWithVarArgs(jSType41, jSTypeArray42);
        com.google.javascript.rhino.JSDocInfo jSDocInfo44 = functionType43.getJSDocInfo();
        boolean boolean45 = functionType43.isAllType();
        com.google.javascript.rhino.ErrorReporter errorReporter46 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry47 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter46);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable49 = jSTypeRegistry47.getEachReferenceTypeWithProperty("goog.global");
        com.google.javascript.rhino.jstype.JSType jSType50 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray51 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType52 = jSTypeRegistry47.createConstructorTypeWithVarArgs(jSType50, jSTypeArray51);
        int int53 = functionType52.getMaxArguments();
        boolean boolean54 = functionType43.isSubtype((com.google.javascript.rhino.jstype.JSType) functionType52);
        com.google.javascript.rhino.jstype.EnumType enumType55 = jSTypeRegistry8.createEnumType("BLOCK", node36, (com.google.javascript.rhino.jstype.JSType) functionType43);
        com.google.javascript.rhino.Node node57 = enumType55.getPropertyNode("BLOCK");
        com.google.javascript.rhino.ErrorReporter errorReporter58 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry59 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter58);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable61 = jSTypeRegistry59.getEachReferenceTypeWithProperty("goog.global");
        com.google.javascript.rhino.jstype.JSType jSType62 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray63 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType64 = jSTypeRegistry59.createConstructorTypeWithVarArgs(jSType62, jSTypeArray63);
        com.google.javascript.rhino.JSDocInfo jSDocInfo65 = functionType64.getJSDocInfo();
        boolean boolean66 = functionType64.isAllType();
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable67 = functionType64.getImplementedInterfaces();
        boolean boolean68 = jSTypeRegistry1.resetImplicitPrototype((com.google.javascript.rhino.jstype.JSType) enumType55, (com.google.javascript.rhino.jstype.ObjectType) functionType64);
        boolean boolean69 = jSTypeRegistry1.shouldTolerateUndefinedValues();
        org.junit.Assert.assertNotNull(objectTypeIterable3);
        org.junit.Assert.assertNotNull(jSTypeArray5);
        org.junit.Assert.assertNotNull(functionType6);
        org.junit.Assert.assertNotNull(objectTypeIterable10);
        org.junit.Assert.assertNotNull(jSTypeArray12);
        org.junit.Assert.assertNotNull(functionType13);
        org.junit.Assert.assertNull(errorReporter14);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "BLOCK" + "'", str27.equals("BLOCK"));
        org.junit.Assert.assertNotNull(node30);
        org.junit.Assert.assertNotNull(nodeIterable31);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertNotNull(node36);
        org.junit.Assert.assertNotNull(objectTypeIterable40);
        org.junit.Assert.assertNotNull(jSTypeArray42);
        org.junit.Assert.assertNotNull(functionType43);
        org.junit.Assert.assertNull(jSDocInfo44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(objectTypeIterable49);
        org.junit.Assert.assertNotNull(jSTypeArray51);
        org.junit.Assert.assertNotNull(functionType52);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 0 + "'", int53 == 0);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + true + "'", boolean54 == true);
        org.junit.Assert.assertNotNull(enumType55);
        org.junit.Assert.assertNull(node57);
        org.junit.Assert.assertNotNull(objectTypeIterable61);
        org.junit.Assert.assertNotNull(jSTypeArray63);
        org.junit.Assert.assertNotNull(functionType64);
        org.junit.Assert.assertNull(jSDocInfo65);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertNotNull(objectTypeIterable67);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + true + "'", boolean68 == true);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable3 = jSTypeRegistry1.getEachReferenceTypeWithProperty("goog.global");
        com.google.javascript.rhino.jstype.JSType jSType4 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray5 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType6 = jSTypeRegistry1.createConstructorTypeWithVarArgs(jSType4, jSTypeArray5);
        com.google.javascript.rhino.JSDocInfo jSDocInfo7 = functionType6.getJSDocInfo();
        com.google.javascript.rhino.ErrorReporter errorReporter8 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry9 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter8);
        com.google.javascript.rhino.ErrorReporter errorReporter10 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry11 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter10);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable13 = jSTypeRegistry11.getEachReferenceTypeWithProperty("goog.global");
        com.google.javascript.rhino.jstype.JSType jSType14 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray15 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType16 = jSTypeRegistry11.createConstructorTypeWithVarArgs(jSType14, jSTypeArray15);
        com.google.javascript.rhino.JSDocInfo jSDocInfo17 = functionType16.getJSDocInfo();
        boolean boolean18 = functionType16.isAllType();
        com.google.javascript.rhino.ErrorReporter errorReporter19 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry20 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter19);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable22 = jSTypeRegistry20.getEachReferenceTypeWithProperty("goog.global");
        com.google.javascript.rhino.jstype.JSType jSType23 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray24 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType25 = jSTypeRegistry20.createConstructorTypeWithVarArgs(jSType23, jSTypeArray24);
        int int26 = functionType25.getMaxArguments();
        boolean boolean27 = functionType16.isSubtype((com.google.javascript.rhino.jstype.JSType) functionType25);
        com.google.javascript.rhino.ErrorReporter errorReporter29 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry30 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter29);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable32 = jSTypeRegistry30.getEachReferenceTypeWithProperty("goog.global");
        com.google.javascript.rhino.jstype.JSType jSType33 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray34 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType35 = jSTypeRegistry30.createConstructorTypeWithVarArgs(jSType33, jSTypeArray34);
        com.google.javascript.rhino.JSDocInfo jSDocInfo36 = functionType35.getJSDocInfo();
        boolean boolean37 = functionType35.isAllType();
        int int38 = functionType35.getMaxArguments();
        com.google.javascript.rhino.Node node39 = com.google.javascript.rhino.IR.trueNode();
        java.lang.String str40 = node39.getSourceFileName();
        boolean boolean41 = node39.isOr();
        boolean boolean42 = functionType25.defineInferredProperty("hi!", (com.google.javascript.rhino.jstype.JSType) functionType35, node39);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray44 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType45 = jSTypeRegistry9.createConstructorType((com.google.javascript.rhino.jstype.JSType) functionType35, false, jSTypeArray44);
        com.google.javascript.rhino.ErrorReporter errorReporter46 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry47 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter46);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable49 = jSTypeRegistry47.getEachReferenceTypeWithProperty("goog.global");
        com.google.javascript.rhino.jstype.JSType jSType50 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray51 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType52 = jSTypeRegistry47.createConstructorTypeWithVarArgs(jSType50, jSTypeArray51);
        com.google.javascript.rhino.JSDocInfo jSDocInfo53 = functionType52.getJSDocInfo();
        boolean boolean54 = functionType52.isAllType();
        com.google.javascript.rhino.ErrorReporter errorReporter55 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry56 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter55);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable58 = jSTypeRegistry56.getEachReferenceTypeWithProperty("goog.global");
        com.google.javascript.rhino.jstype.JSType jSType59 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray60 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType61 = jSTypeRegistry56.createConstructorTypeWithVarArgs(jSType59, jSTypeArray60);
        int int62 = functionType61.getMaxArguments();
        boolean boolean63 = functionType52.isSubtype((com.google.javascript.rhino.jstype.JSType) functionType61);
        java.io.PrintStream printStream64 = null;
        com.google.javascript.jscomp.Compiler compiler65 = new com.google.javascript.jscomp.Compiler(printStream64);
        com.google.javascript.jscomp.NodeTraversal.Callback callback66 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal67 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler65, callback66);
        boolean boolean68 = functionType52.equals((java.lang.Object) nodeTraversal67);
        com.google.javascript.rhino.jstype.JSType jSType69 = jSTypeRegistry9.createOptionalNullableType((com.google.javascript.rhino.jstype.JSType) functionType52);
        boolean boolean70 = jSType69.isEmptyType();
        boolean boolean71 = functionType6.canAssignTo(jSType69);
        org.junit.Assert.assertNotNull(objectTypeIterable3);
        org.junit.Assert.assertNotNull(jSTypeArray5);
        org.junit.Assert.assertNotNull(functionType6);
        org.junit.Assert.assertNull(jSDocInfo7);
        org.junit.Assert.assertNotNull(objectTypeIterable13);
        org.junit.Assert.assertNotNull(jSTypeArray15);
        org.junit.Assert.assertNotNull(functionType16);
        org.junit.Assert.assertNull(jSDocInfo17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(objectTypeIterable22);
        org.junit.Assert.assertNotNull(jSTypeArray24);
        org.junit.Assert.assertNotNull(functionType25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertNotNull(objectTypeIterable32);
        org.junit.Assert.assertNotNull(jSTypeArray34);
        org.junit.Assert.assertNotNull(functionType35);
        org.junit.Assert.assertNull(jSDocInfo36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 0 + "'", int38 == 0);
        org.junit.Assert.assertNotNull(node39);
        org.junit.Assert.assertNull(str40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertNotNull(jSTypeArray44);
        org.junit.Assert.assertNotNull(functionType45);
        org.junit.Assert.assertNotNull(objectTypeIterable49);
        org.junit.Assert.assertNotNull(jSTypeArray51);
        org.junit.Assert.assertNotNull(functionType52);
        org.junit.Assert.assertNull(jSDocInfo53);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNotNull(objectTypeIterable58);
        org.junit.Assert.assertNotNull(jSTypeArray60);
        org.junit.Assert.assertNotNull(functionType61);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 0 + "'", int62 == 0);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + true + "'", boolean63 == true);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertNotNull(jSType69);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + true + "'", boolean71 == true);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        long long1 = com.google.javascript.rhino.ScriptRuntime.testUint32String("function (new:{...}): ?");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1L) + "'", long1 == (-1L));
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeUnusedPrototypePropertiesInExterns = true;
        java.util.Map<java.lang.String, java.lang.Object> strMap3 = null;
        compilerOptions0.setTweakReplacements(strMap3);
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy5 = null;
        compilerOptions0.variableRenaming = variableRenamingPolicy5;
        compilerOptions0.computeFunctionSideEffects = false;
        compilerOptions0.setInstrumentationTemplate("Not declared as a constructor");
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.NON_STANDARD_JSDOC;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable3 = jSTypeRegistry1.getEachReferenceTypeWithProperty("goog.global");
        com.google.javascript.rhino.jstype.JSType jSType4 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray5 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType6 = jSTypeRegistry1.createConstructorTypeWithVarArgs(jSType4, jSTypeArray5);
        com.google.javascript.rhino.JSDocInfo jSDocInfo7 = functionType6.getJSDocInfo();
        com.google.javascript.rhino.jstype.JSType jSType9 = functionType6.getRestrictedTypeGivenToBooleanOutcome(true);
        com.google.javascript.jscomp.CompilerOptions compilerOptions10 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy11 = null;
        compilerOptions10.setVariableRenaming(variableRenamingPolicy11);
        boolean boolean13 = functionType6.equals((java.lang.Object) compilerOptions10);
        com.google.javascript.jscomp.CompilerOptions compilerOptions14 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel15 = com.google.javascript.jscomp.CheckLevel.ERROR;
        compilerOptions14.reportMissingOverride = checkLevel15;
        compilerOptions10.setCheckMissingGetCssNameLevel(checkLevel15);
        org.junit.Assert.assertNotNull(objectTypeIterable3);
        org.junit.Assert.assertNotNull(jSTypeArray5);
        org.junit.Assert.assertNotNull(functionType6);
        org.junit.Assert.assertNull(jSDocInfo7);
        org.junit.Assert.assertNotNull(jSType9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + checkLevel15 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel15.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.ACCESS_CONTROLS;
        com.google.javascript.jscomp.CheckLevel checkLevel1 = com.google.javascript.jscomp.CheckLevel.ERROR;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard2 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup0, checkLevel1);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup3 = com.google.javascript.jscomp.DiagnosticGroups.ACCESS_CONTROLS;
        com.google.javascript.jscomp.CheckLevel checkLevel4 = com.google.javascript.jscomp.CheckLevel.ERROR;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard5 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup3, checkLevel4);
        boolean boolean6 = diagnosticGroupWarningsGuard2.enables(diagnosticGroup3);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup7 = com.google.javascript.jscomp.DiagnosticGroups.CHECK_TYPES;
        boolean boolean8 = diagnosticGroupWarningsGuard2.enables(diagnosticGroup7);
        com.google.javascript.jscomp.JSError jSError9 = null;
        try {
            com.google.javascript.jscomp.CheckLevel checkLevel10 = diagnosticGroupWarningsGuard2.level(jSError9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(diagnosticGroup0);
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticGroup3);
        org.junit.Assert.assertTrue("'" + checkLevel4 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel4.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(diagnosticGroup7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.IR.stringKey("");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.IR.stringKey("");
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.IR.block();
        com.google.javascript.rhino.Node node8 = new com.google.javascript.rhino.Node((int) ' ', node2, node4, node5, 0, (int) (short) -1);
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.IR.stringKey("");
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.IR.stringKey("");
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.IR.block();
        com.google.javascript.rhino.Node node17 = new com.google.javascript.rhino.Node((int) ' ', node11, node13, node14, 0, (int) (short) -1);
        boolean boolean18 = node11.isThrow();
        int int19 = node5.getIndexOfChild(node11);
        com.google.javascript.rhino.Node node21 = com.google.javascript.rhino.IR.stringKey("");
        int int22 = node21.getLineno();
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.IR.block();
        java.lang.String str27 = node23.toString(false, false, false);
        com.google.javascript.rhino.Node node28 = com.google.javascript.rhino.IR.block();
        java.lang.String str32 = node28.toString(false, false, false);
        com.google.javascript.rhino.Node node33 = node23.useSourceInfoIfMissingFrom(node28);
        com.google.javascript.rhino.Node node34 = node21.srcrefTree(node23);
        com.google.javascript.rhino.Node node35 = node5.useSourceInfoIfMissingFromForTree(node21);
        boolean boolean36 = node35.isString();
        com.google.javascript.rhino.Node node37 = node35.removeFirstChild();
        try {
            boolean boolean38 = node37.isDec();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "BLOCK" + "'", str27.equals("BLOCK"));
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "BLOCK" + "'", str32.equals("BLOCK"));
        org.junit.Assert.assertNotNull(node33);
        org.junit.Assert.assertNotNull(node34);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNull(node37);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        int int0 = com.google.javascript.rhino.Node.DIRECTIVES;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 48 + "'", int0 == 48);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.IR.stringKey("");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.IR.stringKey("");
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.IR.block();
        com.google.javascript.rhino.Node node8 = new com.google.javascript.rhino.Node((int) ' ', node2, node4, node5, 0, (int) (short) -1);
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.IR.stringKey("");
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.IR.stringKey("");
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.IR.block();
        com.google.javascript.rhino.Node node17 = new com.google.javascript.rhino.Node((int) ' ', node11, node13, node14, 0, (int) (short) -1);
        boolean boolean18 = node11.isThrow();
        int int19 = node5.getIndexOfChild(node11);
        try {
            node5.setDouble((double) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: BLOCK is not a string node");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.SourceFile sourceFile3 = com.google.javascript.jscomp.SourceFile.fromFile("./");
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray4 = new com.google.javascript.jscomp.JSSourceFile[] {};
        com.google.javascript.jscomp.CompilerOptions compilerOptions5 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean6 = compilerOptions5.isExternExportsEnabled();
        com.google.javascript.jscomp.Result result7 = compiler1.compile(sourceFile3, jSSourceFileArray4, compilerOptions5);
        com.google.javascript.jscomp.SourceMap sourceMap8 = compiler1.getSourceMap();
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter9 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler1);
        com.google.javascript.jscomp.ErrorManager errorManager10 = compiler1.getErrorManager();
        com.google.javascript.jscomp.JSError[] jSErrorArray11 = compiler1.getWarnings();
        org.junit.Assert.assertNotNull(sourceFile3);
        org.junit.Assert.assertNotNull(jSSourceFileArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(result7);
        org.junit.Assert.assertNull(sourceMap8);
        org.junit.Assert.assertNotNull(errorManager10);
        org.junit.Assert.assertNotNull(jSErrorArray11);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.ACCESS_CONTROLS;
        com.google.javascript.jscomp.DiagnosticGroups.NON_STANDARD_JSDOC = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticGroups.GLOBAL_THIS = diagnosticGroup0;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.computeFunctionSideEffects = true;
        boolean boolean3 = compilerOptions0.removeUnusedVars;
        java.lang.String[] strArray15 = new java.lang.String[] { "InputId: Not declared as a constructor", ".", "BLOCK", "InputId: Not declared as a constructor", "Not declared as a constructor", "module$hi!", ".", "JSDocInfo", "module$hi!", ".", "hi!" };
        java.util.LinkedHashSet<java.lang.String> strSet16 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean17 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet16, strArray15);
        compilerOptions0.setIdGenerators((java.util.Set<java.lang.String>) strSet16);
        compilerOptions0.setReserveRawExports(true);
        compilerOptions0.setRuntimeTypeCheck(false);
        compilerOptions0.setInlineGetters(false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(strArray15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable3 = jSTypeRegistry1.getEachReferenceTypeWithProperty("goog.global");
        com.google.javascript.rhino.jstype.JSType jSType4 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray5 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType6 = jSTypeRegistry1.createConstructorTypeWithVarArgs(jSType4, jSTypeArray5);
        com.google.javascript.rhino.JSDocInfo jSDocInfo7 = functionType6.getJSDocInfo();
        com.google.javascript.rhino.ErrorReporter errorReporter8 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry9 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter8);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable11 = jSTypeRegistry9.getEachReferenceTypeWithProperty("goog.global");
        com.google.javascript.rhino.jstype.JSType jSType12 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray13 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType14 = jSTypeRegistry9.createConstructorTypeWithVarArgs(jSType12, jSTypeArray13);
        com.google.javascript.rhino.JSDocInfo jSDocInfo15 = functionType14.getJSDocInfo();
        boolean boolean16 = functionType14.isAllType();
        com.google.javascript.rhino.ErrorReporter errorReporter17 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry18 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter17);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable20 = jSTypeRegistry18.getEachReferenceTypeWithProperty("goog.global");
        com.google.javascript.rhino.jstype.JSType jSType21 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray22 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType23 = jSTypeRegistry18.createConstructorTypeWithVarArgs(jSType21, jSTypeArray22);
        int int24 = functionType23.getMaxArguments();
        boolean boolean25 = functionType14.isSubtype((com.google.javascript.rhino.jstype.JSType) functionType23);
        boolean boolean26 = functionType6.canTestForEqualityWith((com.google.javascript.rhino.jstype.JSType) functionType23);
        com.google.javascript.rhino.jstype.JSType jSType27 = functionType6.getReturnType();
        com.google.javascript.rhino.ErrorReporter errorReporter28 = null;
        com.google.javascript.rhino.ErrorReporter errorReporter29 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry30 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter29);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable32 = jSTypeRegistry30.getEachReferenceTypeWithProperty("goog.global");
        com.google.javascript.rhino.jstype.JSType jSType33 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray34 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType35 = jSTypeRegistry30.createConstructorTypeWithVarArgs(jSType33, jSTypeArray34);
        com.google.javascript.rhino.JSDocInfo jSDocInfo36 = functionType35.getJSDocInfo();
        boolean boolean37 = functionType35.isAllType();
        com.google.javascript.rhino.ErrorReporter errorReporter38 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry39 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter38);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable41 = jSTypeRegistry39.getEachReferenceTypeWithProperty("goog.global");
        com.google.javascript.rhino.jstype.JSType jSType42 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray43 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType44 = jSTypeRegistry39.createConstructorTypeWithVarArgs(jSType42, jSTypeArray43);
        int int45 = functionType44.getMaxArguments();
        boolean boolean46 = functionType35.isSubtype((com.google.javascript.rhino.jstype.JSType) functionType44);
        com.google.javascript.rhino.ErrorReporter errorReporter48 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry49 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter48);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable51 = jSTypeRegistry49.getEachReferenceTypeWithProperty("goog.global");
        com.google.javascript.rhino.jstype.JSType jSType52 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray53 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType54 = jSTypeRegistry49.createConstructorTypeWithVarArgs(jSType52, jSTypeArray53);
        com.google.javascript.rhino.JSDocInfo jSDocInfo55 = functionType54.getJSDocInfo();
        boolean boolean56 = functionType54.isAllType();
        int int57 = functionType54.getMaxArguments();
        com.google.javascript.rhino.Node node58 = com.google.javascript.rhino.IR.trueNode();
        java.lang.String str59 = node58.getSourceFileName();
        boolean boolean60 = node58.isOr();
        boolean boolean61 = functionType44.defineInferredProperty("hi!", (com.google.javascript.rhino.jstype.JSType) functionType54, node58);
        com.google.javascript.rhino.jstype.ParameterizedType parameterizedType62 = functionType54.toMaybeParameterizedType();
        boolean boolean63 = functionType54.hasAnyTemplateInternal();
        com.google.javascript.rhino.jstype.JSType jSType64 = jSType27.resolve(errorReporter28, (com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType>) functionType54);
        boolean boolean65 = jSType64.isNumber();
        org.junit.Assert.assertNotNull(objectTypeIterable3);
        org.junit.Assert.assertNotNull(jSTypeArray5);
        org.junit.Assert.assertNotNull(functionType6);
        org.junit.Assert.assertNull(jSDocInfo7);
        org.junit.Assert.assertNotNull(objectTypeIterable11);
        org.junit.Assert.assertNotNull(jSTypeArray13);
        org.junit.Assert.assertNotNull(functionType14);
        org.junit.Assert.assertNull(jSDocInfo15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(objectTypeIterable20);
        org.junit.Assert.assertNotNull(jSTypeArray22);
        org.junit.Assert.assertNotNull(functionType23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(jSType27);
        org.junit.Assert.assertNotNull(objectTypeIterable32);
        org.junit.Assert.assertNotNull(jSTypeArray34);
        org.junit.Assert.assertNotNull(functionType35);
        org.junit.Assert.assertNull(jSDocInfo36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(objectTypeIterable41);
        org.junit.Assert.assertNotNull(jSTypeArray43);
        org.junit.Assert.assertNotNull(functionType44);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 0 + "'", int45 == 0);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
        org.junit.Assert.assertNotNull(objectTypeIterable51);
        org.junit.Assert.assertNotNull(jSTypeArray53);
        org.junit.Assert.assertNotNull(functionType54);
        org.junit.Assert.assertNull(jSDocInfo55);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 0 + "'", int57 == 0);
        org.junit.Assert.assertNotNull(node58);
        org.junit.Assert.assertNull(str59);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + true + "'", boolean61 == true);
        org.junit.Assert.assertNull(parameterizedType62);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertNotNull(jSType64);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + true + "'", boolean65 == true);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        com.google.javascript.jscomp.SourceAst sourceAst0 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(sourceAst0, "Not declared as a constructor", true);
        com.google.javascript.rhino.InputId inputId4 = compilerInput3.getInputId();
        java.lang.String str5 = inputId4.toString();
        boolean boolean7 = inputId4.equals((java.lang.Object) (byte) 10);
        java.lang.String str8 = inputId4.toString();
        org.junit.Assert.assertNotNull(inputId4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "InputId: Not declared as a constructor" + "'", str5.equals("InputId: Not declared as a constructor"));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "InputId: Not declared as a constructor" + "'", str8.equals("InputId: Not declared as a constructor"));
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.IR.stringKey("");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.IR.stringKey("");
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.IR.block();
        com.google.javascript.rhino.Node node8 = new com.google.javascript.rhino.Node((int) ' ', node2, node4, node5, 0, (int) (short) -1);
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.IR.stringKey("");
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.IR.stringKey("");
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.IR.block();
        com.google.javascript.rhino.Node node17 = new com.google.javascript.rhino.Node((int) ' ', node11, node13, node14, 0, (int) (short) -1);
        boolean boolean18 = node11.isThrow();
        int int19 = node5.getIndexOfChild(node11);
        com.google.javascript.rhino.Node node21 = com.google.javascript.rhino.IR.stringKey("");
        int int22 = node21.getLineno();
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.IR.block();
        java.lang.String str27 = node23.toString(false, false, false);
        com.google.javascript.rhino.Node node28 = com.google.javascript.rhino.IR.block();
        java.lang.String str32 = node28.toString(false, false, false);
        com.google.javascript.rhino.Node node33 = node23.useSourceInfoIfMissingFrom(node28);
        com.google.javascript.rhino.Node node34 = node21.srcrefTree(node23);
        com.google.javascript.rhino.Node node35 = node5.useSourceInfoIfMissingFromForTree(node21);
        com.google.javascript.rhino.Node node36 = com.google.javascript.rhino.IR.returnNode();
        boolean boolean37 = node36.isEmpty();
        int int38 = node36.getSourceOffset();
        boolean boolean39 = node36.isGetProp();
        boolean boolean40 = node35.isEquivalentTo(node36);
        boolean boolean41 = node35.isExprResult();
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "BLOCK" + "'", str27.equals("BLOCK"));
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "BLOCK" + "'", str32.equals("BLOCK"));
        org.junit.Assert.assertNotNull(node33);
        org.junit.Assert.assertNotNull(node34);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertNotNull(node36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + (-1) + "'", int38 == (-1));
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        com.google.javascript.rhino.JSDocInfo jSDocInfo0 = new com.google.javascript.rhino.JSDocInfo();
        boolean boolean2 = jSDocInfo0.hasDescriptionForParameter("");
        java.lang.String str3 = jSDocInfo0.toString();
        boolean boolean4 = jSDocInfo0.isIdGenerator();
        com.google.common.collect.ImmutableList<java.lang.String> strList5 = jSDocInfo0.getTemplateTypeNames();
        com.google.javascript.rhino.JSDocInfo.Visibility visibility6 = null;
        jSDocInfo0.setVisibility(visibility6);
        com.google.javascript.rhino.JSTypeExpression jSTypeExpression8 = jSDocInfo0.getEnumParameterType();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "JSDocInfo" + "'", str3.equals("JSDocInfo"));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(strList5);
        org.junit.Assert.assertNull(jSTypeExpression8);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.NodeTraversal.Callback callback2 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal3 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler1, callback2);
        com.google.javascript.jscomp.CompilerOptions compilerOptions4 = null;
        try {
            compiler1.initOptions(compilerOptions4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        com.google.javascript.jscomp.CodingConvention codingConvention0 = com.google.javascript.jscomp.CodingConventions.getDefault();
        org.junit.Assert.assertNotNull(codingConvention0);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.computeFunctionSideEffects = true;
        boolean boolean3 = compilerOptions0.ideMode;
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention4 = new com.google.javascript.jscomp.GoogleCodingConvention();
        compilerOptions0.setCodingConvention((com.google.javascript.jscomp.CodingConvention) googleCodingConvention4);
        boolean boolean7 = googleCodingConvention4.isPrivate("2019/06/10 13:01");
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention0 = new com.google.javascript.jscomp.GoogleCodingConvention();
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention1 = new com.google.javascript.jscomp.ClosureCodingConvention((com.google.javascript.jscomp.CodingConvention) googleCodingConvention0);
        java.lang.String str2 = closureCodingConvention1.getGlobalObject();
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.IR.stringKey("");
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.IR.stringKey("");
        com.google.javascript.rhino.Node node7 = null;
        int int8 = node6.getIndexOfChild(node7);
        node4.addChildrenToBack(node6);
        boolean boolean10 = node4.isLocalResultCall();
        boolean boolean11 = node4.isGetterDef();
        java.lang.String str12 = node4.getString();
        try {
            boolean boolean13 = closureCodingConvention1.isInlinableFunction(node4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "goog.global" + "'", str2.equals("goog.global"));
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.SourceFile sourceFile3 = com.google.javascript.jscomp.SourceFile.fromFile("./");
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray4 = new com.google.javascript.jscomp.JSSourceFile[] {};
        com.google.javascript.jscomp.CompilerOptions compilerOptions5 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean6 = compilerOptions5.isExternExportsEnabled();
        com.google.javascript.jscomp.Result result7 = compiler1.compile(sourceFile3, jSSourceFileArray4, compilerOptions5);
        com.google.javascript.jscomp.SourceMap sourceMap8 = compiler1.getSourceMap();
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter9 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler1);
        com.google.javascript.jscomp.JSModule jSModule10 = null;
        try {
            java.lang.String[] strArray11 = compiler1.toSourceArray(jSModule10);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: java.lang.NullPointerException");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(sourceFile3);
        org.junit.Assert.assertNotNull(jSSourceFileArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(result7);
        org.junit.Assert.assertNull(sourceMap8);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        com.google.javascript.jscomp.AnonymousFunctionNamingPolicy anonymousFunctionNamingPolicy0 = com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.MAPPED;
        org.junit.Assert.assertTrue("'" + anonymousFunctionNamingPolicy0 + "' != '" + com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.MAPPED + "'", anonymousFunctionNamingPolicy0.equals(com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.MAPPED));
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        boolean boolean3 = jSTypeRegistry1.hasNamespace("module$hi!");
        com.google.javascript.rhino.ErrorReporter errorReporter5 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry6 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter5);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable8 = jSTypeRegistry6.getEachReferenceTypeWithProperty("goog.global");
        com.google.javascript.rhino.jstype.JSType jSType9 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray10 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType11 = jSTypeRegistry6.createConstructorTypeWithVarArgs(jSType9, jSTypeArray10);
        com.google.javascript.rhino.JSDocInfo jSDocInfo12 = functionType11.getJSDocInfo();
        boolean boolean13 = functionType11.isAllType();
        com.google.javascript.rhino.ErrorReporter errorReporter14 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry15 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter14);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable17 = jSTypeRegistry15.getEachReferenceTypeWithProperty("goog.global");
        com.google.javascript.rhino.jstype.JSType jSType18 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray19 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType20 = jSTypeRegistry15.createConstructorTypeWithVarArgs(jSType18, jSTypeArray19);
        int int21 = functionType20.getMaxArguments();
        boolean boolean22 = functionType11.isSubtype((com.google.javascript.rhino.jstype.JSType) functionType20);
        jSTypeRegistry1.unregisterPropertyOnType("goog.exportProperty", (com.google.javascript.rhino.jstype.JSType) functionType20);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative24 = com.google.javascript.rhino.jstype.JSTypeNative.GLOBAL_THIS;
        try {
            com.google.javascript.rhino.jstype.FunctionType functionType25 = jSTypeRegistry1.getNativeFunctionType(jSTypeNative24);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: com.google.javascript.rhino.jstype.InstanceObjectType cannot be cast to com.google.javascript.rhino.jstype.FunctionType");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(objectTypeIterable8);
        org.junit.Assert.assertNotNull(jSTypeArray10);
        org.junit.Assert.assertNotNull(functionType11);
        org.junit.Assert.assertNull(jSDocInfo12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(objectTypeIterable17);
        org.junit.Assert.assertNotNull(jSTypeArray19);
        org.junit.Assert.assertNotNull(functionType20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + jSTypeNative24 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.GLOBAL_THIS + "'", jSTypeNative24.equals(com.google.javascript.rhino.jstype.JSTypeNative.GLOBAL_THIS));
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        com.google.javascript.rhino.ErrorReporter errorReporter2 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry3 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter2);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable5 = jSTypeRegistry3.getEachReferenceTypeWithProperty("goog.global");
        com.google.javascript.rhino.jstype.JSType jSType6 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray7 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType8 = jSTypeRegistry3.createConstructorTypeWithVarArgs(jSType6, jSTypeArray7);
        com.google.javascript.rhino.JSDocInfo jSDocInfo9 = functionType8.getJSDocInfo();
        boolean boolean10 = functionType8.isAllType();
        com.google.javascript.rhino.ErrorReporter errorReporter11 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry12 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter11);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable14 = jSTypeRegistry12.getEachReferenceTypeWithProperty("goog.global");
        com.google.javascript.rhino.jstype.JSType jSType15 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray16 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType17 = jSTypeRegistry12.createConstructorTypeWithVarArgs(jSType15, jSTypeArray16);
        int int18 = functionType17.getMaxArguments();
        boolean boolean19 = functionType8.isSubtype((com.google.javascript.rhino.jstype.JSType) functionType17);
        com.google.javascript.rhino.ErrorReporter errorReporter21 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry22 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter21);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable24 = jSTypeRegistry22.getEachReferenceTypeWithProperty("goog.global");
        com.google.javascript.rhino.jstype.JSType jSType25 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray26 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType27 = jSTypeRegistry22.createConstructorTypeWithVarArgs(jSType25, jSTypeArray26);
        com.google.javascript.rhino.JSDocInfo jSDocInfo28 = functionType27.getJSDocInfo();
        boolean boolean29 = functionType27.isAllType();
        int int30 = functionType27.getMaxArguments();
        com.google.javascript.rhino.Node node31 = com.google.javascript.rhino.IR.trueNode();
        java.lang.String str32 = node31.getSourceFileName();
        boolean boolean33 = node31.isOr();
        boolean boolean34 = functionType17.defineInferredProperty("hi!", (com.google.javascript.rhino.jstype.JSType) functionType27, node31);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray36 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType37 = jSTypeRegistry1.createConstructorType((com.google.javascript.rhino.jstype.JSType) functionType27, false, jSTypeArray36);
        boolean boolean38 = functionType37.canBeCalled();
        functionType37.clearCachedValues();
        com.google.javascript.rhino.jstype.ObjectType objectType40 = null;
        try {
            functionType37.matchConstraint(objectType40);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(objectTypeIterable5);
        org.junit.Assert.assertNotNull(jSTypeArray7);
        org.junit.Assert.assertNotNull(functionType8);
        org.junit.Assert.assertNull(jSDocInfo9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(objectTypeIterable14);
        org.junit.Assert.assertNotNull(jSTypeArray16);
        org.junit.Assert.assertNotNull(functionType17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(objectTypeIterable24);
        org.junit.Assert.assertNotNull(jSTypeArray26);
        org.junit.Assert.assertNotNull(functionType27);
        org.junit.Assert.assertNull(jSDocInfo28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertNull(str32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertNotNull(jSTypeArray36);
        org.junit.Assert.assertNotNull(functionType37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        com.google.javascript.jscomp.SourceAst sourceAst0 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(sourceAst0, "Not declared as a constructor", true);
        com.google.javascript.jscomp.JSModule jSModule4 = compilerInput3.getModule();
        com.google.javascript.jscomp.JSModule jSModule5 = null;
        compilerInput3.setModule(jSModule5);
        com.google.javascript.jscomp.SourceAst sourceAst7 = compilerInput3.getAst();
        org.junit.Assert.assertNull(jSModule4);
        org.junit.Assert.assertNull(sourceAst7);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable3 = jSTypeRegistry1.getEachReferenceTypeWithProperty("goog.global");
        com.google.javascript.rhino.jstype.JSType jSType4 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray5 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType6 = jSTypeRegistry1.createConstructorTypeWithVarArgs(jSType4, jSTypeArray5);
        com.google.javascript.rhino.JSDocInfo jSDocInfo7 = functionType6.getJSDocInfo();
        boolean boolean8 = functionType6.isAllType();
        com.google.javascript.rhino.ErrorReporter errorReporter9 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry10 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter9);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable12 = jSTypeRegistry10.getEachReferenceTypeWithProperty("goog.global");
        com.google.javascript.rhino.jstype.JSType jSType13 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray14 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType15 = jSTypeRegistry10.createConstructorTypeWithVarArgs(jSType13, jSTypeArray14);
        int int16 = functionType15.getMaxArguments();
        boolean boolean17 = functionType6.isSubtype((com.google.javascript.rhino.jstype.JSType) functionType15);
        com.google.javascript.rhino.ErrorReporter errorReporter19 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry20 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter19);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable22 = jSTypeRegistry20.getEachReferenceTypeWithProperty("goog.global");
        com.google.javascript.rhino.jstype.JSType jSType23 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray24 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType25 = jSTypeRegistry20.createConstructorTypeWithVarArgs(jSType23, jSTypeArray24);
        com.google.javascript.rhino.JSDocInfo jSDocInfo26 = functionType25.getJSDocInfo();
        boolean boolean27 = functionType25.isAllType();
        int int28 = functionType25.getMaxArguments();
        com.google.javascript.rhino.Node node29 = com.google.javascript.rhino.IR.trueNode();
        java.lang.String str30 = node29.getSourceFileName();
        boolean boolean31 = node29.isOr();
        boolean boolean32 = functionType15.defineInferredProperty("hi!", (com.google.javascript.rhino.jstype.JSType) functionType25, node29);
        boolean boolean33 = functionType25.isString();
        org.junit.Assert.assertNotNull(objectTypeIterable3);
        org.junit.Assert.assertNotNull(jSTypeArray5);
        org.junit.Assert.assertNotNull(functionType6);
        org.junit.Assert.assertNull(jSDocInfo7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(objectTypeIterable12);
        org.junit.Assert.assertNotNull(jSTypeArray14);
        org.junit.Assert.assertNotNull(functionType15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(objectTypeIterable22);
        org.junit.Assert.assertNotNull(jSTypeArray24);
        org.junit.Assert.assertNotNull(functionType25);
        org.junit.Assert.assertNull(jSDocInfo26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNull(str30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeUnusedPrototypePropertiesInExterns = true;
        compilerOptions0.preferLineBreakAtEndOfFile = true;
        compilerOptions0.setInlineGetters(true);
        boolean boolean7 = compilerOptions0.closurePass;
        compilerOptions0.setRenamePrefix("BLOCK\n");
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable3 = jSTypeRegistry1.getEachReferenceTypeWithProperty("goog.global");
        com.google.javascript.rhino.jstype.JSType jSType4 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray5 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType6 = jSTypeRegistry1.createConstructorTypeWithVarArgs(jSType4, jSTypeArray5);
        com.google.javascript.rhino.JSDocInfo jSDocInfo7 = functionType6.getJSDocInfo();
        com.google.javascript.rhino.JSDocInfo jSDocInfo9 = functionType6.getOwnPropertyJSDocInfo("Not declared as a constructor");
        org.junit.Assert.assertNotNull(objectTypeIterable3);
        org.junit.Assert.assertNotNull(jSTypeArray5);
        org.junit.Assert.assertNotNull(functionType6);
        org.junit.Assert.assertNull(jSDocInfo7);
        org.junit.Assert.assertNull(jSDocInfo9);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        java.lang.String str0 = com.google.javascript.jscomp.Compiler.getReleaseVersion();
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "Unversioned directory" + "'", str0.equals("Unversioned directory"));
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.CONSTANT_PROPERTY;
        com.google.javascript.jscomp.DiagnosticGroups.CHECK_TYPES = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticGroups.CONST = diagnosticGroup0;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.returnNode();
        java.util.Set<java.lang.String> strSet1 = node0.getDirectives();
        int int2 = node0.getType();
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.IR.block();
        java.lang.String str7 = node3.toString(false, false, false);
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.IR.block();
        java.lang.String str12 = node8.toString(false, false, false);
        com.google.javascript.rhino.Node node13 = node3.useSourceInfoIfMissingFrom(node8);
        com.google.javascript.rhino.Node node14 = node0.useSourceInfoIfMissingFrom(node3);
        com.google.javascript.rhino.ErrorReporter errorReporter15 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry16 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter15);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable18 = jSTypeRegistry16.getEachReferenceTypeWithProperty("goog.global");
        com.google.javascript.rhino.jstype.JSType jSType19 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray20 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType21 = jSTypeRegistry16.createConstructorTypeWithVarArgs(jSType19, jSTypeArray20);
        com.google.javascript.rhino.JSDocInfo jSDocInfo22 = functionType21.getJSDocInfo();
        boolean boolean23 = functionType21.isAllType();
        com.google.javascript.rhino.ErrorReporter errorReporter24 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry25 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter24);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable27 = jSTypeRegistry25.getEachReferenceTypeWithProperty("goog.global");
        com.google.javascript.rhino.jstype.JSType jSType28 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray29 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType30 = jSTypeRegistry25.createConstructorTypeWithVarArgs(jSType28, jSTypeArray29);
        int int31 = functionType30.getMaxArguments();
        boolean boolean32 = functionType21.isSubtype((com.google.javascript.rhino.jstype.JSType) functionType30);
        com.google.javascript.rhino.ErrorReporter errorReporter34 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry35 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter34);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable37 = jSTypeRegistry35.getEachReferenceTypeWithProperty("goog.global");
        com.google.javascript.rhino.jstype.JSType jSType38 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray39 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType40 = jSTypeRegistry35.createConstructorTypeWithVarArgs(jSType38, jSTypeArray39);
        com.google.javascript.rhino.JSDocInfo jSDocInfo41 = functionType40.getJSDocInfo();
        boolean boolean42 = functionType40.isAllType();
        int int43 = functionType40.getMaxArguments();
        com.google.javascript.rhino.Node node44 = com.google.javascript.rhino.IR.trueNode();
        java.lang.String str45 = node44.getSourceFileName();
        boolean boolean46 = node44.isOr();
        boolean boolean47 = functionType30.defineInferredProperty("hi!", (com.google.javascript.rhino.jstype.JSType) functionType40, node44);
        com.google.javascript.rhino.Node node49 = com.google.javascript.rhino.IR.stringKey("");
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable50 = node49.siblings();
        boolean boolean51 = node49.isQualifiedName();
        node49.setString("");
        node49.removeProp((int) ' ');
        com.google.javascript.rhino.Node node56 = node44.srcrefTree(node49);
        try {
            com.google.javascript.rhino.Node node57 = com.google.javascript.rhino.IR.label(node3, node44);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertNull(strSet1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "BLOCK" + "'", str7.equals("BLOCK"));
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "BLOCK" + "'", str12.equals("BLOCK"));
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNotNull(objectTypeIterable18);
        org.junit.Assert.assertNotNull(jSTypeArray20);
        org.junit.Assert.assertNotNull(functionType21);
        org.junit.Assert.assertNull(jSDocInfo22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(objectTypeIterable27);
        org.junit.Assert.assertNotNull(jSTypeArray29);
        org.junit.Assert.assertNotNull(functionType30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNotNull(objectTypeIterable37);
        org.junit.Assert.assertNotNull(jSTypeArray39);
        org.junit.Assert.assertNotNull(functionType40);
        org.junit.Assert.assertNull(jSDocInfo41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
        org.junit.Assert.assertNotNull(node44);
        org.junit.Assert.assertNull(str45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
        org.junit.Assert.assertNotNull(node49);
        org.junit.Assert.assertNotNull(nodeIterable50);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertNotNull(node56);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention0 = new com.google.javascript.jscomp.GoogleCodingConvention();
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention1 = new com.google.javascript.jscomp.ClosureCodingConvention((com.google.javascript.jscomp.CodingConvention) googleCodingConvention0);
        com.google.javascript.rhino.Node node2 = null;
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship3 = googleCodingConvention0.getDelegateRelationship(node2);
        java.lang.String str4 = googleCodingConvention0.getGlobalObject();
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.IR.stringKey("");
        int int7 = node6.getLineno();
        java.util.Map<java.lang.String, java.lang.String> strMap8 = null;
        googleCodingConvention0.checkForCallingConventionDefiningCalls(node6, strMap8);
        node6.setVarArgs(false);
        org.junit.Assert.assertNull(delegateRelationship3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "goog.global" + "'", str4.equals("goog.global"));
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable3 = jSTypeRegistry1.getEachReferenceTypeWithProperty("goog.global");
        com.google.javascript.rhino.jstype.JSType jSType4 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray5 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType6 = jSTypeRegistry1.createConstructorTypeWithVarArgs(jSType4, jSTypeArray5);
        com.google.javascript.rhino.ErrorReporter errorReporter7 = jSTypeRegistry1.getErrorReporter();
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.IR.stringKey("");
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.IR.stringKey("");
        com.google.javascript.rhino.Node node13 = null;
        int int14 = node12.getIndexOfChild(node13);
        node10.addChildrenToBack(node12);
        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.IR.block();
        java.lang.String str20 = node16.toString(false, false, false);
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.IR.stringKey("");
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable24 = node23.siblings();
        com.google.javascript.rhino.Node node27 = new com.google.javascript.rhino.Node((int) (short) 100, node23, (int) (short) 1, (int) (short) 10);
        com.google.javascript.rhino.Node node28 = node16.useSourceInfoIfMissingFrom(node27);
        com.google.javascript.rhino.Node node29 = node12.srcref(node16);
        com.google.javascript.rhino.ErrorReporter errorReporter30 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry31 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter30);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable33 = jSTypeRegistry31.getEachReferenceTypeWithProperty("goog.global");
        com.google.javascript.rhino.jstype.JSType jSType34 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray35 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType36 = jSTypeRegistry31.createConstructorTypeWithVarArgs(jSType34, jSTypeArray35);
        com.google.javascript.rhino.JSDocInfo jSDocInfo37 = functionType36.getJSDocInfo();
        boolean boolean38 = functionType36.isAllType();
        com.google.javascript.rhino.ErrorReporter errorReporter39 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry40 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter39);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable42 = jSTypeRegistry40.getEachReferenceTypeWithProperty("goog.global");
        com.google.javascript.rhino.jstype.JSType jSType43 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray44 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType45 = jSTypeRegistry40.createConstructorTypeWithVarArgs(jSType43, jSTypeArray44);
        int int46 = functionType45.getMaxArguments();
        boolean boolean47 = functionType36.isSubtype((com.google.javascript.rhino.jstype.JSType) functionType45);
        com.google.javascript.rhino.jstype.EnumType enumType48 = jSTypeRegistry1.createEnumType("BLOCK", node29, (com.google.javascript.rhino.jstype.JSType) functionType36);
        com.google.javascript.rhino.ErrorReporter errorReporter49 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry50 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter49);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable52 = jSTypeRegistry50.getEachReferenceTypeWithProperty("goog.global");
        com.google.javascript.rhino.jstype.JSType jSType53 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray54 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType55 = jSTypeRegistry50.createConstructorTypeWithVarArgs(jSType53, jSTypeArray54);
        com.google.javascript.rhino.JSDocInfo jSDocInfo56 = functionType55.getJSDocInfo();
        boolean boolean57 = functionType55.isAllType();
        com.google.javascript.rhino.jstype.JSType jSType58 = jSTypeRegistry1.createOptionalType((com.google.javascript.rhino.jstype.JSType) functionType55);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray59 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.Node node60 = jSTypeRegistry1.createParameters(jSTypeArray59);
        org.junit.Assert.assertNotNull(objectTypeIterable3);
        org.junit.Assert.assertNotNull(jSTypeArray5);
        org.junit.Assert.assertNotNull(functionType6);
        org.junit.Assert.assertNull(errorReporter7);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "BLOCK" + "'", str20.equals("BLOCK"));
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(nodeIterable24);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNotNull(objectTypeIterable33);
        org.junit.Assert.assertNotNull(jSTypeArray35);
        org.junit.Assert.assertNotNull(functionType36);
        org.junit.Assert.assertNull(jSDocInfo37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(objectTypeIterable42);
        org.junit.Assert.assertNotNull(jSTypeArray44);
        org.junit.Assert.assertNotNull(functionType45);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 0 + "'", int46 == 0);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
        org.junit.Assert.assertNotNull(enumType48);
        org.junit.Assert.assertNotNull(objectTypeIterable52);
        org.junit.Assert.assertNotNull(jSTypeArray54);
        org.junit.Assert.assertNotNull(functionType55);
        org.junit.Assert.assertNull(jSDocInfo56);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertNotNull(jSType58);
        org.junit.Assert.assertNotNull(jSTypeArray59);
        org.junit.Assert.assertNotNull(node60);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        com.google.javascript.jscomp.SourceAst sourceAst0 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(sourceAst0, "Not declared as a constructor", true);
        com.google.javascript.rhino.InputId inputId4 = compilerInput3.getInputId();
        java.lang.String str5 = inputId4.toString();
        com.google.javascript.jscomp.CompilerOptions compilerOptions6 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions6.removeUnusedPrototypePropertiesInExterns = true;
        java.util.Map<java.lang.String, java.lang.Object> strMap9 = null;
        compilerOptions6.setTweakReplacements(strMap9);
        com.google.javascript.jscomp.parsing.Config.LanguageMode languageMode12 = com.google.javascript.jscomp.parsing.Config.LanguageMode.ECMASCRIPT3;
        java.lang.String[] strArray16 = new java.lang.String[] { "hi!", "hi!" };
        java.util.LinkedHashSet<java.lang.String> strSet17 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean18 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet17, strArray16);
        com.google.javascript.jscomp.parsing.Config config19 = com.google.javascript.jscomp.parsing.ParserRunner.createConfig(false, languageMode12, true, (java.util.Set<java.lang.String>) strSet17);
        compilerOptions6.stripNameSuffixes = strSet17;
        boolean boolean21 = compilerOptions6.inlineLocalFunctions;
        compilerOptions6.extractPrototypeMemberDeclarations = true;
        boolean boolean24 = inputId4.equals((java.lang.Object) true);
        org.junit.Assert.assertNotNull(inputId4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "InputId: Not declared as a constructor" + "'", str5.equals("InputId: Not declared as a constructor"));
        org.junit.Assert.assertTrue("'" + languageMode12 + "' != '" + com.google.javascript.jscomp.parsing.Config.LanguageMode.ECMASCRIPT3 + "'", languageMode12.equals(com.google.javascript.jscomp.parsing.Config.LanguageMode.ECMASCRIPT3));
        org.junit.Assert.assertNotNull(strArray16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(config19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.computeFunctionSideEffects = true;
        boolean boolean3 = compilerOptions0.isRemoveUnusedClassProperties();
        com.google.javascript.jscomp.ErrorHandler errorHandler4 = null;
        compilerOptions0.setErrorHandler(errorHandler4);
        java.util.List<com.google.javascript.jscomp.SourceMap.LocationMapping> locationMappingList6 = compilerOptions0.sourceMapLocationMappings;
        compilerOptions0.setTweakToStringLiteral(".", "./");
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(locationMappingList6);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        int int0 = com.google.javascript.rhino.Node.SYNTHETIC_BLOCK_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 38 + "'", int0 == 38);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable3 = jSTypeRegistry1.getEachReferenceTypeWithProperty("goog.global");
        com.google.javascript.rhino.jstype.JSType jSType4 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray5 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType6 = jSTypeRegistry1.createConstructorTypeWithVarArgs(jSType4, jSTypeArray5);
        boolean boolean7 = functionType6.hasReferenceName();
        org.junit.Assert.assertNotNull(objectTypeIterable3);
        org.junit.Assert.assertNotNull(jSTypeArray5);
        org.junit.Assert.assertNotNull(functionType6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.computeFunctionSideEffects = true;
        boolean boolean3 = compilerOptions0.isRemoveUnusedClassProperties();
        com.google.javascript.jscomp.ErrorHandler errorHandler4 = null;
        compilerOptions0.setErrorHandler(errorHandler4);
        compilerOptions0.setColorizeErrorOutput(true);
        boolean boolean8 = compilerOptions0.assumeClosuresOnlyCaptureReferences();
        compilerOptions0.aliasAllStrings = false;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.computeFunctionSideEffects = true;
        compilerOptions0.setOptimizeArgumentsArray(true);
        boolean boolean5 = compilerOptions0.exportTestFunctions;
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.computeFunctionSideEffects = true;
        java.lang.String str3 = compilerOptions0.renamePrefix;
        com.google.javascript.jscomp.CheckLevel checkLevel4 = compilerOptions0.reportMissingOverride;
        java.lang.String str5 = compilerOptions0.checkMissingGetCssNameBlacklist;
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + checkLevel4 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel4.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNull(str5);
    }

//    @Test
//    public void test335() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test335");
//        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
//        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable3 = jSTypeRegistry1.getEachReferenceTypeWithProperty("goog.global");
//        com.google.javascript.rhino.jstype.JSType jSType4 = null;
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray5 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.FunctionType functionType6 = jSTypeRegistry1.createConstructorTypeWithVarArgs(jSType4, jSTypeArray5);
//        com.google.javascript.rhino.JSDocInfo jSDocInfo7 = functionType6.getJSDocInfo();
//        boolean boolean8 = functionType6.isAllType();
//        com.google.javascript.rhino.ErrorReporter errorReporter9 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry10 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter9);
//        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable12 = jSTypeRegistry10.getEachReferenceTypeWithProperty("goog.global");
//        com.google.javascript.rhino.jstype.JSType jSType13 = null;
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray14 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.FunctionType functionType15 = jSTypeRegistry10.createConstructorTypeWithVarArgs(jSType13, jSTypeArray14);
//        int int16 = functionType15.getMaxArguments();
//        boolean boolean17 = functionType6.isSubtype((com.google.javascript.rhino.jstype.JSType) functionType15);
//        com.google.javascript.rhino.ErrorReporter errorReporter19 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry20 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter19);
//        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable22 = jSTypeRegistry20.getEachReferenceTypeWithProperty("goog.global");
//        com.google.javascript.rhino.jstype.JSType jSType23 = null;
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray24 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.FunctionType functionType25 = jSTypeRegistry20.createConstructorTypeWithVarArgs(jSType23, jSTypeArray24);
//        com.google.javascript.rhino.JSDocInfo jSDocInfo26 = functionType25.getJSDocInfo();
//        boolean boolean27 = functionType25.isAllType();
//        int int28 = functionType25.getMaxArguments();
//        com.google.javascript.rhino.Node node29 = com.google.javascript.rhino.IR.trueNode();
//        java.lang.String str30 = node29.getSourceFileName();
//        boolean boolean31 = node29.isOr();
//        boolean boolean32 = functionType15.defineInferredProperty("hi!", (com.google.javascript.rhino.jstype.JSType) functionType25, node29);
//        java.lang.String str33 = functionType25.toDebugHashCodeString();
//        org.junit.Assert.assertNotNull(objectTypeIterable3);
//        org.junit.Assert.assertNotNull(jSTypeArray5);
//        org.junit.Assert.assertNotNull(functionType6);
//        org.junit.Assert.assertNull(jSDocInfo7);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertNotNull(objectTypeIterable12);
//        org.junit.Assert.assertNotNull(jSTypeArray14);
//        org.junit.Assert.assertNotNull(functionType15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
//        org.junit.Assert.assertNotNull(objectTypeIterable22);
//        org.junit.Assert.assertNotNull(jSTypeArray24);
//        org.junit.Assert.assertNotNull(functionType25);
//        org.junit.Assert.assertNull(jSDocInfo26);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
//        org.junit.Assert.assertNotNull(node29);
//        org.junit.Assert.assertNull(str30);
//        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
//        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "function (): {1835552301}" + "'", str33.equals("function (): {1835552301}"));
//    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        com.google.javascript.jscomp.SourceAst sourceAst0 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(sourceAst0, "Not declared as a constructor", true);
        com.google.javascript.rhino.InputId inputId4 = compilerInput3.getInputId();
        boolean boolean5 = compilerInput3.isExtern();
        org.junit.Assert.assertNotNull(inputId4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.IR.stringKey("");
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.IR.stringKey("");
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.IR.block();
        com.google.javascript.rhino.Node node9 = new com.google.javascript.rhino.Node((int) ' ', node3, node5, node6, 0, (int) (short) -1);
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.IR.stringKey("");
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.IR.stringKey("");
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.IR.block();
        com.google.javascript.rhino.Node node18 = new com.google.javascript.rhino.Node((int) ' ', node12, node14, node15, 0, (int) (short) -1);
        boolean boolean19 = node12.isThrow();
        int int20 = node6.getIndexOfChild(node12);
        com.google.javascript.rhino.Node node22 = com.google.javascript.rhino.IR.stringKey("");
        int int23 = node22.getLineno();
        com.google.javascript.rhino.Node node24 = com.google.javascript.rhino.IR.block();
        java.lang.String str28 = node24.toString(false, false, false);
        com.google.javascript.rhino.Node node29 = com.google.javascript.rhino.IR.block();
        java.lang.String str33 = node29.toString(false, false, false);
        com.google.javascript.rhino.Node node34 = node24.useSourceInfoIfMissingFrom(node29);
        com.google.javascript.rhino.Node node35 = node22.srcrefTree(node24);
        com.google.javascript.rhino.Node node36 = node6.useSourceInfoIfMissingFromForTree(node22);
        boolean boolean37 = node36.isString();
        com.google.javascript.rhino.Node node38 = node36.removeFirstChild();
        com.google.javascript.rhino.Node node41 = com.google.javascript.rhino.IR.stringKey("");
        com.google.javascript.rhino.Node node43 = com.google.javascript.rhino.IR.stringKey("");
        com.google.javascript.rhino.Node node44 = com.google.javascript.rhino.IR.block();
        com.google.javascript.rhino.Node node47 = new com.google.javascript.rhino.Node((int) ' ', node41, node43, node44, 0, (int) (short) -1);
        com.google.javascript.rhino.Node node49 = com.google.javascript.rhino.IR.stringKey("");
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable50 = node49.siblings();
        boolean boolean51 = node49.isIn();
        boolean boolean52 = node49.isVar();
        java.lang.String str53 = node49.getString();
        com.google.javascript.rhino.Node node54 = null;
        try {
            com.google.javascript.rhino.Node node55 = new com.google.javascript.rhino.Node((int) 'a', node38, node44, node49, node54);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "BLOCK" + "'", str28.equals("BLOCK"));
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "BLOCK" + "'", str33.equals("BLOCK"));
        org.junit.Assert.assertNotNull(node34);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertNotNull(node36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNull(node38);
        org.junit.Assert.assertNotNull(node41);
        org.junit.Assert.assertNotNull(node43);
        org.junit.Assert.assertNotNull(node44);
        org.junit.Assert.assertNotNull(node49);
        org.junit.Assert.assertNotNull(nodeIterable50);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "" + "'", str53.equals(""));
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.NodeTraversal.Callback callback2 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal3 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler1, callback2);
        java.lang.String str4 = compiler1.getAstDotGraph();
        com.google.javascript.jscomp.SourceFile sourceFile6 = com.google.javascript.jscomp.SourceFile.fromFile("./");
        java.lang.String str7 = sourceFile6.getOriginalPath();
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray8 = new com.google.javascript.jscomp.JSSourceFile[] {};
        com.google.javascript.jscomp.CompilerOptions compilerOptions9 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions9.removeUnusedPrototypePropertiesInExterns = true;
        java.util.Map<java.lang.String, java.lang.Object> strMap12 = null;
        compilerOptions9.setTweakReplacements(strMap12);
        compilerOptions9.setInlineConstantVars(false);
        java.lang.String str16 = compilerOptions9.renamePrefix;
        com.google.javascript.jscomp.Result result17 = compiler1.compile(sourceFile6, jSSourceFileArray8, compilerOptions9);
        com.google.javascript.jscomp.SourceExcerptProvider.SourceExcerpt sourceExcerpt18 = null;
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter19 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler1, sourceExcerpt18);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertNotNull(sourceFile6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "." + "'", str7.equals("."));
        org.junit.Assert.assertNotNull(jSSourceFileArray8);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertNotNull(result17);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.IR.stringKey("");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.IR.stringKey("");
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.IR.block();
        com.google.javascript.rhino.Node node8 = new com.google.javascript.rhino.Node((int) ' ', node2, node4, node5, 0, (int) (short) -1);
        boolean boolean9 = node2.isThrow();
        boolean boolean10 = node2.isTry();
        boolean boolean11 = node2.hasMoreThanOneChild();
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        java.util.logging.Logger logger0 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager1 = new com.google.javascript.jscomp.LoggerErrorManager(logger0);
        com.google.javascript.jscomp.CompilerOptions compilerOptions2 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions2.removeUnusedPrototypePropertiesInExterns = true;
        compilerOptions2.setColorizeErrorOutput(true);
        com.google.javascript.jscomp.CompilerOptions compilerOptions7 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions7.computeFunctionSideEffects = true;
        boolean boolean10 = compilerOptions7.isRemoveUnusedClassProperties();
        boolean boolean11 = compilerOptions7.isExternExportsEnabled();
        compilerOptions7.aliasKeywords = true;
        compilerOptions7.rewriteFunctionExpressions = false;
        com.google.javascript.jscomp.CompilerOptions compilerOptions16 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions16.computeFunctionSideEffects = true;
        java.lang.String str19 = compilerOptions16.renamePrefix;
        com.google.javascript.jscomp.CheckLevel checkLevel20 = compilerOptions16.reportMissingOverride;
        compilerOptions7.setCheckMissingReturn(checkLevel20);
        compilerOptions2.brokenClosureRequiresLevel = checkLevel20;
        com.google.javascript.jscomp.CompilerOptions compilerOptions27 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions27.computeFunctionSideEffects = true;
        boolean boolean30 = compilerOptions27.ideMode;
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention31 = new com.google.javascript.jscomp.GoogleCodingConvention();
        compilerOptions27.setCodingConvention((com.google.javascript.jscomp.CodingConvention) googleCodingConvention31);
        com.google.javascript.jscomp.CompilerOptions compilerOptions33 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions33.computeFunctionSideEffects = true;
        boolean boolean36 = compilerOptions33.isRemoveUnusedClassProperties();
        com.google.javascript.jscomp.ErrorHandler errorHandler37 = null;
        compilerOptions33.setErrorHandler(errorHandler37);
        java.util.List<com.google.javascript.jscomp.SourceMap.LocationMapping> locationMappingList39 = compilerOptions33.sourceMapLocationMappings;
        com.google.javascript.jscomp.CheckLevel checkLevel40 = com.google.javascript.jscomp.CheckLevel.ERROR;
        compilerOptions33.setCheckProvides(checkLevel40);
        compilerOptions27.setReportMissingOverride(checkLevel40);
        com.google.javascript.jscomp.DiagnosticType diagnosticType44 = com.google.javascript.jscomp.DiagnosticType.make("JSDocInfo", checkLevel40, "JSDocInfo");
        java.lang.String[] strArray50 = new java.lang.String[] { "./", "goog.global", "BLOCK", "BLOCK\n", "" };
        com.google.javascript.jscomp.JSError jSError51 = com.google.javascript.jscomp.JSError.make("Not declared as a constructor", 4, 0, diagnosticType44, strArray50);
        loggerErrorManager1.println(checkLevel20, jSError51);
        com.google.javascript.jscomp.JSError[] jSErrorArray53 = loggerErrorManager1.getWarnings();
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNull(str19);
        org.junit.Assert.assertTrue("'" + checkLevel20 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel20.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(locationMappingList39);
        org.junit.Assert.assertTrue("'" + checkLevel40 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel40.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticType44);
        org.junit.Assert.assertNotNull(strArray50);
        org.junit.Assert.assertNotNull(jSError51);
        org.junit.Assert.assertNotNull(jSErrorArray53);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.computeFunctionSideEffects = true;
        boolean boolean3 = compilerOptions0.removeUnusedVars;
        java.lang.String[] strArray15 = new java.lang.String[] { "InputId: Not declared as a constructor", ".", "BLOCK", "InputId: Not declared as a constructor", "Not declared as a constructor", "module$hi!", ".", "JSDocInfo", "module$hi!", ".", "hi!" };
        java.util.LinkedHashSet<java.lang.String> strSet16 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean17 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet16, strArray15);
        compilerOptions0.setIdGenerators((java.util.Set<java.lang.String>) strSet16);
        compilerOptions0.setReserveRawExports(true);
        compilerOptions0.exportTestFunctions = false;
        compilerOptions0.crossModuleCodeMotion = true;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(strArray15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.computeFunctionSideEffects = true;
        boolean boolean3 = compilerOptions0.isRemoveUnusedClassProperties();
        com.google.javascript.jscomp.ErrorHandler errorHandler4 = null;
        compilerOptions0.setErrorHandler(errorHandler4);
        java.util.List<com.google.javascript.jscomp.SourceMap.LocationMapping> locationMappingList6 = compilerOptions0.sourceMapLocationMappings;
        com.google.javascript.jscomp.CheckLevel checkLevel7 = com.google.javascript.jscomp.CheckLevel.ERROR;
        compilerOptions0.setCheckProvides(checkLevel7);
        com.google.javascript.jscomp.CompilerOptions compilerOptions9 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions9.computeFunctionSideEffects = true;
        boolean boolean12 = compilerOptions9.isRemoveUnusedClassProperties();
        com.google.javascript.jscomp.ErrorHandler errorHandler13 = null;
        compilerOptions9.setErrorHandler(errorHandler13);
        java.util.List<com.google.javascript.jscomp.SourceMap.LocationMapping> locationMappingList15 = compilerOptions9.sourceMapLocationMappings;
        com.google.javascript.jscomp.CheckLevel checkLevel16 = com.google.javascript.jscomp.CheckLevel.ERROR;
        compilerOptions9.setCheckProvides(checkLevel16);
        compilerOptions0.reportMissingOverride = checkLevel16;
        com.google.javascript.jscomp.CompilerOptions compilerOptions19 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions19.removeUnusedPrototypePropertiesInExterns = true;
        compilerOptions19.setColorizeErrorOutput(true);
        com.google.javascript.jscomp.CompilerOptions compilerOptions24 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions24.computeFunctionSideEffects = true;
        boolean boolean27 = compilerOptions24.isRemoveUnusedClassProperties();
        boolean boolean28 = compilerOptions24.isExternExportsEnabled();
        compilerOptions24.aliasKeywords = true;
        compilerOptions24.rewriteFunctionExpressions = false;
        com.google.javascript.jscomp.CompilerOptions compilerOptions33 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions33.computeFunctionSideEffects = true;
        java.lang.String str36 = compilerOptions33.renamePrefix;
        com.google.javascript.jscomp.CheckLevel checkLevel37 = compilerOptions33.reportMissingOverride;
        compilerOptions24.setCheckMissingReturn(checkLevel37);
        compilerOptions19.brokenClosureRequiresLevel = checkLevel37;
        compilerOptions0.checkGlobalNamesLevel = checkLevel37;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(locationMappingList6);
        org.junit.Assert.assertTrue("'" + checkLevel7 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel7.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(locationMappingList15);
        org.junit.Assert.assertTrue("'" + checkLevel16 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel16.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNull(str36);
        org.junit.Assert.assertTrue("'" + checkLevel37 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel37.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeUnusedPrototypePropertiesInExterns = true;
        byte[] byteArray6 = new byte[] { (byte) 0, (byte) -1, (byte) 10 };
        compilerOptions0.inputPropertyMapSerialized = byteArray6;
        compilerOptions0.setCheckControlStructures(false);
        boolean boolean10 = compilerOptions0.inlineGetters;
        compilerOptions0.convertToDottedProperties = false;
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

//    @Test
//    public void test344() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test344");
//        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
//        com.google.javascript.rhino.ErrorReporter errorReporter2 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry3 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter2);
//        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable5 = jSTypeRegistry3.getEachReferenceTypeWithProperty("goog.global");
//        com.google.javascript.rhino.jstype.JSType jSType6 = null;
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray7 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.FunctionType functionType8 = jSTypeRegistry3.createConstructorTypeWithVarArgs(jSType6, jSTypeArray7);
//        com.google.javascript.rhino.JSDocInfo jSDocInfo9 = functionType8.getJSDocInfo();
//        boolean boolean10 = functionType8.isAllType();
//        com.google.javascript.rhino.ErrorReporter errorReporter11 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry12 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter11);
//        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable14 = jSTypeRegistry12.getEachReferenceTypeWithProperty("goog.global");
//        com.google.javascript.rhino.jstype.JSType jSType15 = null;
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray16 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.FunctionType functionType17 = jSTypeRegistry12.createConstructorTypeWithVarArgs(jSType15, jSTypeArray16);
//        int int18 = functionType17.getMaxArguments();
//        boolean boolean19 = functionType8.isSubtype((com.google.javascript.rhino.jstype.JSType) functionType17);
//        com.google.javascript.rhino.ErrorReporter errorReporter21 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry22 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter21);
//        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable24 = jSTypeRegistry22.getEachReferenceTypeWithProperty("goog.global");
//        com.google.javascript.rhino.jstype.JSType jSType25 = null;
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray26 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.FunctionType functionType27 = jSTypeRegistry22.createConstructorTypeWithVarArgs(jSType25, jSTypeArray26);
//        com.google.javascript.rhino.JSDocInfo jSDocInfo28 = functionType27.getJSDocInfo();
//        boolean boolean29 = functionType27.isAllType();
//        int int30 = functionType27.getMaxArguments();
//        com.google.javascript.rhino.Node node31 = com.google.javascript.rhino.IR.trueNode();
//        java.lang.String str32 = node31.getSourceFileName();
//        boolean boolean33 = node31.isOr();
//        boolean boolean34 = functionType17.defineInferredProperty("hi!", (com.google.javascript.rhino.jstype.JSType) functionType27, node31);
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray36 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.FunctionType functionType37 = jSTypeRegistry1.createConstructorType((com.google.javascript.rhino.jstype.JSType) functionType27, false, jSTypeArray36);
//        com.google.javascript.rhino.ErrorReporter errorReporter38 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry39 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter38);
//        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable41 = jSTypeRegistry39.getEachReferenceTypeWithProperty("goog.global");
//        com.google.javascript.rhino.jstype.JSType jSType42 = null;
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray43 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.FunctionType functionType44 = jSTypeRegistry39.createConstructorTypeWithVarArgs(jSType42, jSTypeArray43);
//        com.google.javascript.rhino.JSDocInfo jSDocInfo45 = functionType44.getJSDocInfo();
//        boolean boolean46 = functionType44.isAllType();
//        com.google.javascript.rhino.ErrorReporter errorReporter47 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry48 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter47);
//        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable50 = jSTypeRegistry48.getEachReferenceTypeWithProperty("goog.global");
//        com.google.javascript.rhino.jstype.JSType jSType51 = null;
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray52 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.FunctionType functionType53 = jSTypeRegistry48.createConstructorTypeWithVarArgs(jSType51, jSTypeArray52);
//        int int54 = functionType53.getMaxArguments();
//        boolean boolean55 = functionType44.isSubtype((com.google.javascript.rhino.jstype.JSType) functionType53);
//        java.io.PrintStream printStream56 = null;
//        com.google.javascript.jscomp.Compiler compiler57 = new com.google.javascript.jscomp.Compiler(printStream56);
//        com.google.javascript.jscomp.NodeTraversal.Callback callback58 = null;
//        com.google.javascript.jscomp.NodeTraversal nodeTraversal59 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler57, callback58);
//        boolean boolean60 = functionType44.equals((java.lang.Object) nodeTraversal59);
//        com.google.javascript.rhino.jstype.JSType jSType61 = jSTypeRegistry1.createOptionalNullableType((com.google.javascript.rhino.jstype.JSType) functionType44);
//        java.lang.String str62 = functionType44.toDebugHashCodeString();
//        org.junit.Assert.assertNotNull(objectTypeIterable5);
//        org.junit.Assert.assertNotNull(jSTypeArray7);
//        org.junit.Assert.assertNotNull(functionType8);
//        org.junit.Assert.assertNull(jSDocInfo9);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertNotNull(objectTypeIterable14);
//        org.junit.Assert.assertNotNull(jSTypeArray16);
//        org.junit.Assert.assertNotNull(functionType17);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
//        org.junit.Assert.assertNotNull(objectTypeIterable24);
//        org.junit.Assert.assertNotNull(jSTypeArray26);
//        org.junit.Assert.assertNotNull(functionType27);
//        org.junit.Assert.assertNull(jSDocInfo28);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
//        org.junit.Assert.assertNotNull(node31);
//        org.junit.Assert.assertNull(str32);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
//        org.junit.Assert.assertNotNull(jSTypeArray36);
//        org.junit.Assert.assertNotNull(functionType37);
//        org.junit.Assert.assertNotNull(objectTypeIterable41);
//        org.junit.Assert.assertNotNull(jSTypeArray43);
//        org.junit.Assert.assertNotNull(functionType44);
//        org.junit.Assert.assertNull(jSDocInfo45);
//        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
//        org.junit.Assert.assertNotNull(objectTypeIterable50);
//        org.junit.Assert.assertNotNull(jSTypeArray52);
//        org.junit.Assert.assertNotNull(functionType53);
//        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 0 + "'", int54 == 0);
//        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + true + "'", boolean55 == true);
//        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
//        org.junit.Assert.assertNotNull(jSType61);
//        org.junit.Assert.assertTrue("'" + str62 + "' != '" + "function (): {631144317}" + "'", str62.equals("function (): {631144317}"));
//    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention0 = new com.google.javascript.jscomp.GoogleCodingConvention();
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention1 = new com.google.javascript.jscomp.ClosureCodingConvention((com.google.javascript.jscomp.CodingConvention) googleCodingConvention0);
        java.lang.String str2 = closureCodingConvention1.getGlobalObject();
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.IR.stringKey("");
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.IR.stringKey("");
        com.google.javascript.rhino.Node node7 = null;
        int int8 = node6.getIndexOfChild(node7);
        node4.addChildrenToBack(node6);
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.IR.block();
        java.lang.String str14 = node10.toString(false, false, false);
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.IR.stringKey("");
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable18 = node17.siblings();
        com.google.javascript.rhino.Node node21 = new com.google.javascript.rhino.Node((int) (short) 100, node17, (int) (short) 1, (int) (short) 10);
        com.google.javascript.rhino.Node node22 = node10.useSourceInfoIfMissingFrom(node21);
        com.google.javascript.rhino.Node node23 = node6.srcref(node10);
        com.google.javascript.jscomp.CodingConvention.Bind bind24 = closureCodingConvention1.describeFunctionBind(node10);
        com.google.javascript.rhino.Node node25 = null;
        boolean boolean26 = closureCodingConvention1.isPrototypeAlias(node25);
        com.google.javascript.rhino.Node node29 = com.google.javascript.rhino.IR.stringKey("");
        com.google.javascript.rhino.Node node31 = com.google.javascript.rhino.IR.stringKey("");
        com.google.javascript.rhino.Node node32 = com.google.javascript.rhino.IR.block();
        com.google.javascript.rhino.Node node35 = new com.google.javascript.rhino.Node((int) ' ', node29, node31, node32, 0, (int) (short) -1);
        boolean boolean36 = node29.isThrow();
        boolean boolean37 = node29.isTry();
        boolean boolean38 = node29.isIn();
        try {
            java.lang.String str39 = closureCodingConvention1.getSingletonGetterClassName(node29);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "goog.global" + "'", str2.equals("goog.global"));
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "BLOCK" + "'", str14.equals("BLOCK"));
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(nodeIterable18);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNull(bind24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertNotNull(node32);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.continueNode();
        com.google.javascript.rhino.Node node4 = new com.google.javascript.rhino.Node(10, node1, 35, 0);
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.IR.block();
        java.lang.String str9 = node5.toString(false, false, false);
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.IR.stringKey("");
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable13 = node12.siblings();
        com.google.javascript.rhino.Node node16 = new com.google.javascript.rhino.Node((int) (short) 100, node12, (int) (short) 1, (int) (short) 10);
        com.google.javascript.rhino.Node node17 = node5.useSourceInfoIfMissingFrom(node16);
        boolean boolean18 = node1.isEquivalentTo(node17);
        com.google.javascript.rhino.InputId inputId19 = com.google.javascript.jscomp.NodeUtil.getInputId(node17);
        com.google.javascript.rhino.Node node20 = null;
        try {
            com.google.javascript.rhino.Node node21 = com.google.javascript.rhino.IR.label(node17, node20);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "BLOCK" + "'", str9.equals("BLOCK"));
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(nodeIterable13);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNull(inputId19);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy0 = com.google.javascript.jscomp.VariableRenamingPolicy.ALL;
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy0 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.ALL + "'", variableRenamingPolicy0.equals(com.google.javascript.jscomp.VariableRenamingPolicy.ALL));
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.SourceFile sourceFile3 = com.google.javascript.jscomp.SourceFile.fromFile("./");
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray4 = new com.google.javascript.jscomp.JSSourceFile[] {};
        com.google.javascript.jscomp.CompilerOptions compilerOptions5 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean6 = compilerOptions5.isExternExportsEnabled();
        com.google.javascript.jscomp.Result result7 = compiler1.compile(sourceFile3, jSSourceFileArray4, compilerOptions5);
        com.google.javascript.jscomp.SourceMap sourceMap8 = compiler1.getSourceMap();
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter9 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler1);
        compiler1.reportCodeChange();
        java.io.PrintStream printStream11 = null;
        com.google.javascript.jscomp.Compiler compiler12 = new com.google.javascript.jscomp.Compiler(printStream11);
        com.google.javascript.jscomp.SourceFile sourceFile14 = com.google.javascript.jscomp.SourceFile.fromFile("./");
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray15 = new com.google.javascript.jscomp.JSSourceFile[] {};
        com.google.javascript.jscomp.CompilerOptions compilerOptions16 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean17 = compilerOptions16.isExternExportsEnabled();
        com.google.javascript.jscomp.Result result18 = compiler12.compile(sourceFile14, jSSourceFileArray15, compilerOptions16);
        java.io.PrintStream printStream19 = null;
        com.google.javascript.jscomp.Compiler compiler20 = new com.google.javascript.jscomp.Compiler(printStream19);
        com.google.javascript.jscomp.NodeTraversal.Callback callback21 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal22 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler20, callback21);
        java.lang.String str23 = compiler20.getAstDotGraph();
        com.google.javascript.jscomp.SourceFile sourceFile25 = com.google.javascript.jscomp.SourceFile.fromFile("./");
        java.lang.String str26 = sourceFile25.getOriginalPath();
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray27 = new com.google.javascript.jscomp.JSSourceFile[] {};
        com.google.javascript.jscomp.CompilerOptions compilerOptions28 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions28.removeUnusedPrototypePropertiesInExterns = true;
        java.util.Map<java.lang.String, java.lang.Object> strMap31 = null;
        compilerOptions28.setTweakReplacements(strMap31);
        compilerOptions28.setInlineConstantVars(false);
        java.lang.String str35 = compilerOptions28.renamePrefix;
        com.google.javascript.jscomp.Result result36 = compiler20.compile(sourceFile25, jSSourceFileArray27, compilerOptions28);
        com.google.javascript.jscomp.CompilerOptions compilerOptions37 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions37.computeFunctionSideEffects = true;
        boolean boolean40 = compilerOptions37.isRemoveUnusedClassProperties();
        com.google.javascript.jscomp.ErrorHandler errorHandler41 = null;
        compilerOptions37.setErrorHandler(errorHandler41);
        com.google.javascript.jscomp.CompilerOptions.AliasTransformationHandler aliasTransformationHandler43 = null;
        compilerOptions37.setAliasTransformationHandler(aliasTransformationHandler43);
        try {
            com.google.javascript.jscomp.Result result45 = compiler1.compile(jSSourceFileArray15, jSSourceFileArray27, compilerOptions37);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(sourceFile3);
        org.junit.Assert.assertNotNull(jSSourceFileArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(result7);
        org.junit.Assert.assertNull(sourceMap8);
        org.junit.Assert.assertNotNull(sourceFile14);
        org.junit.Assert.assertNotNull(jSSourceFileArray15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(result18);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "" + "'", str23.equals(""));
        org.junit.Assert.assertNotNull(sourceFile25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "." + "'", str26.equals("."));
        org.junit.Assert.assertNotNull(jSSourceFileArray27);
        org.junit.Assert.assertNull(str35);
        org.junit.Assert.assertNotNull(result36);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.computeFunctionSideEffects = true;
        boolean boolean3 = compilerOptions0.isRemoveUnusedClassProperties();
        boolean boolean4 = compilerOptions0.isExternExportsEnabled();
        com.google.javascript.jscomp.CompilerOptions compilerOptions5 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions5.removeUnusedPrototypePropertiesInExterns = true;
        byte[] byteArray11 = new byte[] { (byte) 0, (byte) -1, (byte) 10 };
        compilerOptions5.inputPropertyMapSerialized = byteArray11;
        compilerOptions0.setInputVariableMapSerialized(byteArray11);
        com.google.javascript.jscomp.CompilerOptions.Reach reach14 = null;
        try {
            compilerOptions0.setInlineFunctions(reach14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(byteArray11);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.computeFunctionSideEffects = true;
        java.lang.String str3 = compilerOptions0.renamePrefix;
        boolean boolean4 = compilerOptions0.collapseProperties;
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = null;
        com.google.javascript.jscomp.DiagnosticGroups.CHECK_VARIABLES = diagnosticGroup0;
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        com.google.javascript.jscomp.SourceAst sourceAst0 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(sourceAst0, "Not declared as a constructor", true);
        com.google.javascript.jscomp.JSModule jSModule4 = compilerInput3.getModule();
        try {
            java.lang.String str5 = compilerInput3.getPathRelativeToClosureBase();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: null");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNull(jSModule4);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        com.google.javascript.jscomp.SourceAst sourceAst0 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(sourceAst0, "Not declared as a constructor", true);
        com.google.javascript.jscomp.JSModule jSModule4 = compilerInput3.getModule();
        com.google.javascript.jscomp.SourceAst sourceAst5 = compilerInput3.getSourceAst();
        com.google.javascript.jscomp.SourceFile sourceFile8 = com.google.javascript.jscomp.SourceFile.fromCode("goog.global", "JSDocInfo");
        try {
            compilerInput3.setSourceFile(sourceFile8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(jSModule4);
        org.junit.Assert.assertNull(sourceAst5);
        org.junit.Assert.assertNotNull(sourceFile8);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.IR.stringKey("");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.IR.stringKey("");
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.IR.block();
        com.google.javascript.rhino.Node node8 = new com.google.javascript.rhino.Node((int) ' ', node2, node4, node5, 0, (int) (short) -1);
        boolean boolean9 = node2.isThrow();
        boolean boolean10 = node2.isTry();
        boolean boolean11 = node2.isIn();
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.IR.stringKey("");
        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.IR.stringKey("");
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.IR.block();
        com.google.javascript.rhino.Node node20 = new com.google.javascript.rhino.Node((int) ' ', node14, node16, node17, 0, (int) (short) -1);
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.IR.stringKey("");
        com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.IR.stringKey("");
        com.google.javascript.rhino.Node node26 = com.google.javascript.rhino.IR.block();
        com.google.javascript.rhino.Node node29 = new com.google.javascript.rhino.Node((int) ' ', node23, node25, node26, 0, (int) (short) -1);
        boolean boolean30 = node23.isThrow();
        int int31 = node17.getIndexOfChild(node23);
        com.google.javascript.rhino.Node node33 = com.google.javascript.rhino.IR.stringKey("");
        int int34 = node33.getLineno();
        com.google.javascript.rhino.Node node35 = com.google.javascript.rhino.IR.block();
        java.lang.String str39 = node35.toString(false, false, false);
        com.google.javascript.rhino.Node node40 = com.google.javascript.rhino.IR.block();
        java.lang.String str44 = node40.toString(false, false, false);
        com.google.javascript.rhino.Node node45 = node35.useSourceInfoIfMissingFrom(node40);
        com.google.javascript.rhino.Node node46 = node33.srcrefTree(node35);
        com.google.javascript.rhino.Node node47 = node17.useSourceInfoIfMissingFromForTree(node33);
        boolean boolean48 = node47.isDec();
        try {
            com.google.javascript.rhino.Node node49 = node2.removeChildAfter(node47);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: prev is not a child of this node.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + (-1) + "'", int31 == (-1));
        org.junit.Assert.assertNotNull(node33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + (-1) + "'", int34 == (-1));
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "BLOCK" + "'", str39.equals("BLOCK"));
        org.junit.Assert.assertNotNull(node40);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "BLOCK" + "'", str44.equals("BLOCK"));
        org.junit.Assert.assertNotNull(node45);
        org.junit.Assert.assertNotNull(node46);
        org.junit.Assert.assertNotNull(node47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.AMBIGUOUS_FUNCTION_DECL;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.IR.stringKey("");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.IR.stringKey("");
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.IR.block();
        com.google.javascript.rhino.Node node8 = new com.google.javascript.rhino.Node((int) ' ', node2, node4, node5, 0, (int) (short) -1);
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.IR.stringKey("");
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.IR.stringKey("");
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.IR.block();
        com.google.javascript.rhino.Node node17 = new com.google.javascript.rhino.Node((int) ' ', node11, node13, node14, 0, (int) (short) -1);
        boolean boolean18 = node11.isThrow();
        int int19 = node5.getIndexOfChild(node11);
        com.google.javascript.rhino.Node node21 = com.google.javascript.rhino.IR.stringKey("");
        int int22 = node21.getLineno();
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.IR.block();
        java.lang.String str27 = node23.toString(false, false, false);
        com.google.javascript.rhino.Node node28 = com.google.javascript.rhino.IR.block();
        java.lang.String str32 = node28.toString(false, false, false);
        com.google.javascript.rhino.Node node33 = node23.useSourceInfoIfMissingFrom(node28);
        com.google.javascript.rhino.Node node34 = node21.srcrefTree(node23);
        com.google.javascript.rhino.Node node35 = node5.useSourceInfoIfMissingFromForTree(node21);
        boolean boolean36 = node35.isString();
        com.google.javascript.rhino.Node node37 = node35.removeFirstChild();
        com.google.javascript.jscomp.CompilerOptions compilerOptions38 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions38.computeFunctionSideEffects = true;
        boolean boolean41 = compilerOptions38.ideMode;
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention42 = new com.google.javascript.jscomp.GoogleCodingConvention();
        compilerOptions38.setCodingConvention((com.google.javascript.jscomp.CodingConvention) googleCodingConvention42);
        com.google.javascript.rhino.Node node45 = com.google.javascript.rhino.IR.continueNode();
        com.google.javascript.rhino.Node node48 = new com.google.javascript.rhino.Node(10, node45, 35, 0);
        boolean boolean50 = node45.getBooleanProp((-1));
        java.util.Map<java.lang.String, java.lang.String> strMap51 = null;
        googleCodingConvention42.checkForCallingConventionDefiningCalls(node45, strMap51);
        try {
            int int53 = node37.getIndexOfChild(node45);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "BLOCK" + "'", str27.equals("BLOCK"));
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "BLOCK" + "'", str32.equals("BLOCK"));
        org.junit.Assert.assertNotNull(node33);
        org.junit.Assert.assertNotNull(node34);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNull(node37);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(node45);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy1 = null;
        compilerOptions0.setVariableRenaming(variableRenamingPolicy1);
        compilerOptions0.aliasAllStrings = true;
        compilerOptions0.setRemoveAbstractMethods(false);
        compilerOptions0.setCollapseAnonymousFunctions(false);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        com.google.javascript.jscomp.CompilerOptions compilerOptions4 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions4.computeFunctionSideEffects = true;
        boolean boolean7 = compilerOptions4.ideMode;
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention8 = new com.google.javascript.jscomp.GoogleCodingConvention();
        compilerOptions4.setCodingConvention((com.google.javascript.jscomp.CodingConvention) googleCodingConvention8);
        com.google.javascript.jscomp.CompilerOptions compilerOptions10 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions10.computeFunctionSideEffects = true;
        boolean boolean13 = compilerOptions10.isRemoveUnusedClassProperties();
        com.google.javascript.jscomp.ErrorHandler errorHandler14 = null;
        compilerOptions10.setErrorHandler(errorHandler14);
        java.util.List<com.google.javascript.jscomp.SourceMap.LocationMapping> locationMappingList16 = compilerOptions10.sourceMapLocationMappings;
        com.google.javascript.jscomp.CheckLevel checkLevel17 = com.google.javascript.jscomp.CheckLevel.ERROR;
        compilerOptions10.setCheckProvides(checkLevel17);
        compilerOptions4.setReportMissingOverride(checkLevel17);
        com.google.javascript.jscomp.DiagnosticType diagnosticType21 = com.google.javascript.jscomp.DiagnosticType.make("JSDocInfo", checkLevel17, "JSDocInfo");
        java.lang.String[] strArray27 = new java.lang.String[] { "./", "goog.global", "BLOCK", "BLOCK\n", "" };
        com.google.javascript.jscomp.JSError jSError28 = com.google.javascript.jscomp.JSError.make("Not declared as a constructor", 4, 0, diagnosticType21, strArray27);
        com.google.javascript.jscomp.CompilerOptions compilerOptions33 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions33.computeFunctionSideEffects = true;
        boolean boolean36 = compilerOptions33.ideMode;
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention37 = new com.google.javascript.jscomp.GoogleCodingConvention();
        compilerOptions33.setCodingConvention((com.google.javascript.jscomp.CodingConvention) googleCodingConvention37);
        com.google.javascript.jscomp.CompilerOptions compilerOptions39 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions39.computeFunctionSideEffects = true;
        boolean boolean42 = compilerOptions39.isRemoveUnusedClassProperties();
        com.google.javascript.jscomp.ErrorHandler errorHandler43 = null;
        compilerOptions39.setErrorHandler(errorHandler43);
        java.util.List<com.google.javascript.jscomp.SourceMap.LocationMapping> locationMappingList45 = compilerOptions39.sourceMapLocationMappings;
        com.google.javascript.jscomp.CheckLevel checkLevel46 = com.google.javascript.jscomp.CheckLevel.ERROR;
        compilerOptions39.setCheckProvides(checkLevel46);
        compilerOptions33.setReportMissingOverride(checkLevel46);
        com.google.javascript.jscomp.DiagnosticType diagnosticType50 = com.google.javascript.jscomp.DiagnosticType.make("JSDocInfo", checkLevel46, "JSDocInfo");
        java.lang.String[] strArray56 = new java.lang.String[] { "./", "goog.global", "BLOCK", "BLOCK\n", "" };
        com.google.javascript.jscomp.JSError jSError57 = com.google.javascript.jscomp.JSError.make("Not declared as a constructor", 4, 0, diagnosticType50, strArray56);
        com.google.javascript.jscomp.CompilerOptions compilerOptions59 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions59.computeFunctionSideEffects = true;
        boolean boolean62 = compilerOptions59.ideMode;
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention63 = new com.google.javascript.jscomp.GoogleCodingConvention();
        compilerOptions59.setCodingConvention((com.google.javascript.jscomp.CodingConvention) googleCodingConvention63);
        com.google.javascript.jscomp.CompilerOptions compilerOptions65 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions65.computeFunctionSideEffects = true;
        boolean boolean68 = compilerOptions65.isRemoveUnusedClassProperties();
        com.google.javascript.jscomp.ErrorHandler errorHandler69 = null;
        compilerOptions65.setErrorHandler(errorHandler69);
        java.util.List<com.google.javascript.jscomp.SourceMap.LocationMapping> locationMappingList71 = compilerOptions65.sourceMapLocationMappings;
        com.google.javascript.jscomp.CheckLevel checkLevel72 = com.google.javascript.jscomp.CheckLevel.ERROR;
        compilerOptions65.setCheckProvides(checkLevel72);
        compilerOptions59.setReportMissingOverride(checkLevel72);
        com.google.javascript.jscomp.DiagnosticType diagnosticType76 = com.google.javascript.jscomp.DiagnosticType.make("JSDocInfo", checkLevel72, "JSDocInfo");
        com.google.javascript.jscomp.DiagnosticType[] diagnosticTypeArray77 = new com.google.javascript.jscomp.DiagnosticType[] { diagnosticType21, diagnosticType50, diagnosticType76 };
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup78 = new com.google.javascript.jscomp.DiagnosticGroup(diagnosticTypeArray77);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(locationMappingList16);
        org.junit.Assert.assertTrue("'" + checkLevel17 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel17.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticType21);
        org.junit.Assert.assertNotNull(strArray27);
        org.junit.Assert.assertNotNull(jSError28);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(locationMappingList45);
        org.junit.Assert.assertTrue("'" + checkLevel46 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel46.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticType50);
        org.junit.Assert.assertNotNull(strArray56);
        org.junit.Assert.assertNotNull(jSError57);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertNotNull(locationMappingList71);
        org.junit.Assert.assertTrue("'" + checkLevel72 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel72.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticType76);
        org.junit.Assert.assertNotNull(diagnosticTypeArray77);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention0 = new com.google.javascript.jscomp.GoogleCodingConvention();
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention1 = new com.google.javascript.jscomp.ClosureCodingConvention((com.google.javascript.jscomp.CodingConvention) googleCodingConvention0);
        java.lang.String str2 = closureCodingConvention1.getGlobalObject();
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.IR.stringKey("");
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.IR.stringKey("");
        com.google.javascript.rhino.Node node7 = null;
        int int8 = node6.getIndexOfChild(node7);
        node4.addChildrenToBack(node6);
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.IR.block();
        java.lang.String str14 = node10.toString(false, false, false);
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.IR.stringKey("");
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable18 = node17.siblings();
        com.google.javascript.rhino.Node node21 = new com.google.javascript.rhino.Node((int) (short) 100, node17, (int) (short) 1, (int) (short) 10);
        com.google.javascript.rhino.Node node22 = node10.useSourceInfoIfMissingFrom(node21);
        com.google.javascript.rhino.Node node23 = node6.srcref(node10);
        com.google.javascript.jscomp.CodingConvention.Bind bind24 = closureCodingConvention1.describeFunctionBind(node10);
        com.google.javascript.rhino.Node node25 = null;
        boolean boolean26 = closureCodingConvention1.isPrototypeAlias(node25);
        com.google.javascript.rhino.Node node27 = com.google.javascript.rhino.IR.returnNode();
        java.util.Set<java.lang.String> strSet28 = node27.getDirectives();
        boolean boolean29 = node27.isParamList();
        try {
            com.google.javascript.jscomp.CodingConvention.ObjectLiteralCast objectLiteralCast30 = closureCodingConvention1.getObjectLiteralCast(node27);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "goog.global" + "'", str2.equals("goog.global"));
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "BLOCK" + "'", str14.equals("BLOCK"));
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(nodeIterable18);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNull(bind24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(node27);
        org.junit.Assert.assertNull(strSet28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.IR.stringKey("");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.IR.stringKey("");
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.IR.block();
        com.google.javascript.rhino.Node node8 = new com.google.javascript.rhino.Node((int) ' ', node2, node4, node5, 0, (int) (short) -1);
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.IR.stringKey("");
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.IR.stringKey("");
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.IR.block();
        com.google.javascript.rhino.Node node17 = new com.google.javascript.rhino.Node((int) ' ', node11, node13, node14, 0, (int) (short) -1);
        boolean boolean18 = node11.isThrow();
        int int19 = node5.getIndexOfChild(node11);
        com.google.javascript.rhino.Node node21 = com.google.javascript.rhino.IR.stringKey("");
        int int22 = node21.getLineno();
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.IR.block();
        java.lang.String str27 = node23.toString(false, false, false);
        com.google.javascript.rhino.Node node28 = com.google.javascript.rhino.IR.block();
        java.lang.String str32 = node28.toString(false, false, false);
        com.google.javascript.rhino.Node node33 = node23.useSourceInfoIfMissingFrom(node28);
        com.google.javascript.rhino.Node node34 = node21.srcrefTree(node23);
        com.google.javascript.rhino.Node node35 = node5.useSourceInfoIfMissingFromForTree(node21);
        int int36 = node21.getLineno();
        com.google.javascript.rhino.Node node40 = com.google.javascript.rhino.Node.newString("InputId: Not declared as a constructor", (int) '4', (int) (byte) 100);
        com.google.javascript.rhino.Node node41 = node21.useSourceInfoIfMissingFrom(node40);
        boolean boolean42 = com.google.javascript.jscomp.NodeUtil.isSymmetricOperation(node21);
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "BLOCK" + "'", str27.equals("BLOCK"));
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "BLOCK" + "'", str32.equals("BLOCK"));
        org.junit.Assert.assertNotNull(node33);
        org.junit.Assert.assertNotNull(node34);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + (-1) + "'", int36 == (-1));
        org.junit.Assert.assertNotNull(node40);
        org.junit.Assert.assertNotNull(node41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable3 = jSTypeRegistry1.getEachReferenceTypeWithProperty("goog.global");
        com.google.javascript.rhino.jstype.JSType jSType4 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray5 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType6 = jSTypeRegistry1.createConstructorTypeWithVarArgs(jSType4, jSTypeArray5);
        com.google.javascript.rhino.JSDocInfo jSDocInfo7 = functionType6.getJSDocInfo();
        boolean boolean8 = functionType6.isAllType();
        int int9 = functionType6.getMaxArguments();
        boolean boolean10 = functionType6.hasCachedValues();
        com.google.javascript.rhino.ErrorReporter errorReporter11 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry12 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter11);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable14 = jSTypeRegistry12.getEachReferenceTypeWithProperty("goog.global");
        com.google.javascript.rhino.jstype.JSType jSType15 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray16 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType17 = jSTypeRegistry12.createConstructorTypeWithVarArgs(jSType15, jSTypeArray16);
        com.google.javascript.rhino.JSDocInfo jSDocInfo18 = functionType17.getJSDocInfo();
        com.google.javascript.rhino.ErrorReporter errorReporter19 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry20 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter19);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable22 = jSTypeRegistry20.getEachReferenceTypeWithProperty("goog.global");
        com.google.javascript.rhino.jstype.JSType jSType23 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray24 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType25 = jSTypeRegistry20.createConstructorTypeWithVarArgs(jSType23, jSTypeArray24);
        com.google.javascript.rhino.JSDocInfo jSDocInfo26 = functionType25.getJSDocInfo();
        boolean boolean27 = functionType25.isAllType();
        com.google.javascript.rhino.ErrorReporter errorReporter28 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry29 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter28);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable31 = jSTypeRegistry29.getEachReferenceTypeWithProperty("goog.global");
        com.google.javascript.rhino.jstype.JSType jSType32 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray33 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType34 = jSTypeRegistry29.createConstructorTypeWithVarArgs(jSType32, jSTypeArray33);
        int int35 = functionType34.getMaxArguments();
        boolean boolean36 = functionType25.isSubtype((com.google.javascript.rhino.jstype.JSType) functionType34);
        boolean boolean37 = functionType17.canTestForEqualityWith((com.google.javascript.rhino.jstype.JSType) functionType34);
        com.google.javascript.rhino.jstype.JSType.TypePair typePair38 = functionType6.getTypesUnderShallowEquality((com.google.javascript.rhino.jstype.JSType) functionType34);
        org.junit.Assert.assertNotNull(objectTypeIterable3);
        org.junit.Assert.assertNotNull(jSTypeArray5);
        org.junit.Assert.assertNotNull(functionType6);
        org.junit.Assert.assertNull(jSDocInfo7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(objectTypeIterable14);
        org.junit.Assert.assertNotNull(jSTypeArray16);
        org.junit.Assert.assertNotNull(functionType17);
        org.junit.Assert.assertNull(jSDocInfo18);
        org.junit.Assert.assertNotNull(objectTypeIterable22);
        org.junit.Assert.assertNotNull(jSTypeArray24);
        org.junit.Assert.assertNotNull(functionType25);
        org.junit.Assert.assertNull(jSDocInfo26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(objectTypeIterable31);
        org.junit.Assert.assertNotNull(jSTypeArray33);
        org.junit.Assert.assertNotNull(functionType34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertNotNull(typePair38);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        com.google.javascript.rhino.JSDocInfo jSDocInfo0 = new com.google.javascript.rhino.JSDocInfo();
        boolean boolean1 = jSDocInfo0.isExterns();
        boolean boolean2 = jSDocInfo0.hasTypedefType();
        com.google.javascript.rhino.JSTypeExpression jSTypeExpression3 = jSDocInfo0.getEnumParameterType();
        java.lang.String str4 = jSDocInfo0.getSourceName();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(jSTypeExpression3);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.computeFunctionSideEffects = true;
        boolean boolean3 = compilerOptions0.ideMode;
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention4 = new com.google.javascript.jscomp.GoogleCodingConvention();
        compilerOptions0.setCodingConvention((com.google.javascript.jscomp.CodingConvention) googleCodingConvention4);
        com.google.javascript.jscomp.CompilerOptions compilerOptions6 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions6.computeFunctionSideEffects = true;
        boolean boolean9 = compilerOptions6.isRemoveUnusedClassProperties();
        com.google.javascript.jscomp.ErrorHandler errorHandler10 = null;
        compilerOptions6.setErrorHandler(errorHandler10);
        java.util.List<com.google.javascript.jscomp.SourceMap.LocationMapping> locationMappingList12 = compilerOptions6.sourceMapLocationMappings;
        com.google.javascript.jscomp.CheckLevel checkLevel13 = com.google.javascript.jscomp.CheckLevel.ERROR;
        compilerOptions6.setCheckProvides(checkLevel13);
        compilerOptions0.setReportMissingOverride(checkLevel13);
        compilerOptions0.setInlineVariables(false);
        compilerOptions0.setSkipAllPasses(false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(locationMappingList12);
        org.junit.Assert.assertTrue("'" + checkLevel13 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel13.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable3 = jSTypeRegistry1.getEachReferenceTypeWithProperty("goog.global");
        com.google.javascript.rhino.jstype.JSType jSType4 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray5 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType6 = jSTypeRegistry1.createConstructorTypeWithVarArgs(jSType4, jSTypeArray5);
        com.google.javascript.rhino.JSDocInfo jSDocInfo7 = functionType6.getJSDocInfo();
        boolean boolean8 = functionType6.isAllType();
        int int9 = functionType6.getMaxArguments();
        com.google.javascript.rhino.Node node10 = functionType6.getParametersNode();
        com.google.javascript.rhino.Node node12 = functionType6.getPropertyNode("");
        org.junit.Assert.assertNotNull(objectTypeIterable3);
        org.junit.Assert.assertNotNull(jSTypeArray5);
        org.junit.Assert.assertNotNull(functionType6);
        org.junit.Assert.assertNull(jSDocInfo7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNull(node12);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        java.lang.String[] strArray7 = new java.lang.String[] { "module$hi!", "", "hi!" };
        java.util.ArrayList<java.lang.String> strList8 = new java.util.ArrayList<java.lang.String>();
        boolean boolean9 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strList8, strArray7);
        java.lang.String[] strArray20 = new java.lang.String[] { "Not declared as a constructor", "InputId: Not declared as a constructor", "goog.global", "./", "./", "BLOCK", "Not declared as a constructor", "JSDocInfo", "InputId: Not declared as a constructor", "" };
        java.util.ArrayList<java.lang.String> strList21 = new java.util.ArrayList<java.lang.String>();
        boolean boolean22 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strList21, strArray20);
        com.google.javascript.jscomp.deps.SimpleDependencyInfo simpleDependencyInfo23 = new com.google.javascript.jscomp.deps.SimpleDependencyInfo("this", "BLOCK", (java.util.List<java.lang.String>) strList8, (java.util.List<java.lang.String>) strList21);
        com.google.javascript.jscomp.CompilerOptions compilerOptions24 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions24.computeFunctionSideEffects = true;
        boolean boolean27 = compilerOptions24.isRemoveUnusedClassProperties();
        com.google.javascript.jscomp.ErrorHandler errorHandler28 = null;
        compilerOptions24.setErrorHandler(errorHandler28);
        compilerOptions24.setCheckSymbols(false);
        java.util.List<java.lang.String> strList34 = null;
        java.lang.String[] strArray39 = new java.lang.String[] { "BLOCK", "BLOCK", "hi!", "BLOCK" };
        java.util.ArrayList<java.lang.String> strList40 = new java.util.ArrayList<java.lang.String>();
        boolean boolean41 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strList40, strArray39);
        com.google.javascript.jscomp.deps.SimpleDependencyInfo simpleDependencyInfo42 = new com.google.javascript.jscomp.deps.SimpleDependencyInfo("hi!", "hi!", strList34, (java.util.List<java.lang.String>) strList40);
        compilerOptions24.setManageClosureDependencies((java.util.List<java.lang.String>) strList40);
        com.google.javascript.jscomp.deps.SimpleDependencyInfo simpleDependencyInfo44 = new com.google.javascript.jscomp.deps.SimpleDependencyInfo("goog.exportProperty", "function (): {1835552301}", (java.util.List<java.lang.String>) strList8, (java.util.List<java.lang.String>) strList40);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(strArray20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(strArray39);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        com.google.javascript.rhino.Node node1 = com.google.javascript.jscomp.parsing.JsDocInfoParser.parseTypeString("(BLOCK)");
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString("InputId: Not declared as a constructor", (int) '4', (int) (byte) 100);
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.IR.stringKey("");
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable9 = node8.siblings();
        boolean boolean10 = node8.isQualifiedName();
        node8.setString("");
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.IR.stringKey("");
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.IR.stringKey("");
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.IR.block();
        com.google.javascript.rhino.Node node21 = new com.google.javascript.rhino.Node((int) ' ', node15, node17, node18, 0, (int) (short) -1);
        boolean boolean22 = node15.isThrow();
        boolean boolean23 = node15.isStringKey();
        com.google.javascript.rhino.Node node24 = com.google.javascript.rhino.IR.block();
        com.google.javascript.rhino.Node node25 = node15.useSourceInfoIfMissingFrom(node24);
        com.google.javascript.rhino.Node node26 = node8.copyInformationFromForTree(node25);
        com.google.javascript.rhino.Node node29 = new com.google.javascript.rhino.Node(10, node6, node8, (int) (byte) -1, (int) (byte) 0);
        com.google.javascript.rhino.Node node32 = com.google.javascript.rhino.IR.stringKey("");
        com.google.javascript.rhino.Node node34 = com.google.javascript.rhino.IR.stringKey("");
        com.google.javascript.rhino.Node node35 = com.google.javascript.rhino.IR.block();
        com.google.javascript.rhino.Node node38 = new com.google.javascript.rhino.Node((int) ' ', node32, node34, node35, 0, (int) (short) -1);
        boolean boolean39 = node32.isThrow();
        boolean boolean40 = node32.isTry();
        boolean boolean41 = node32.isIn();
        com.google.javascript.rhino.Node node42 = node32.getParent();
        try {
            node1.replaceChild(node8, node42);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: node is not a child");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNotNull(nodeIterable9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertNotNull(node32);
        org.junit.Assert.assertNotNull(node34);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(node42);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable3 = jSTypeRegistry1.getEachReferenceTypeWithProperty("goog.global");
        com.google.javascript.rhino.jstype.JSType jSType4 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray5 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType6 = jSTypeRegistry1.createConstructorTypeWithVarArgs(jSType4, jSTypeArray5);
        com.google.javascript.rhino.ErrorReporter errorReporter7 = jSTypeRegistry1.getErrorReporter();
        com.google.javascript.rhino.ErrorReporter errorReporter8 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry9 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter8);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable11 = jSTypeRegistry9.getEachReferenceTypeWithProperty("goog.global");
        com.google.javascript.rhino.jstype.JSType jSType12 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray13 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType14 = jSTypeRegistry9.createConstructorTypeWithVarArgs(jSType12, jSTypeArray13);
        com.google.javascript.rhino.JSDocInfo jSDocInfo15 = functionType14.getJSDocInfo();
        com.google.javascript.rhino.ErrorReporter errorReporter16 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry17 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter16);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable19 = jSTypeRegistry17.getEachReferenceTypeWithProperty("goog.global");
        com.google.javascript.rhino.jstype.JSType jSType20 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray21 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType22 = jSTypeRegistry17.createConstructorTypeWithVarArgs(jSType20, jSTypeArray21);
        com.google.javascript.rhino.JSDocInfo jSDocInfo23 = functionType22.getJSDocInfo();
        boolean boolean24 = functionType22.isAllType();
        com.google.javascript.rhino.ErrorReporter errorReporter25 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry26 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter25);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable28 = jSTypeRegistry26.getEachReferenceTypeWithProperty("goog.global");
        com.google.javascript.rhino.jstype.JSType jSType29 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray30 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType31 = jSTypeRegistry26.createConstructorTypeWithVarArgs(jSType29, jSTypeArray30);
        int int32 = functionType31.getMaxArguments();
        boolean boolean33 = functionType22.isSubtype((com.google.javascript.rhino.jstype.JSType) functionType31);
        boolean boolean34 = functionType14.canTestForEqualityWith((com.google.javascript.rhino.jstype.JSType) functionType31);
        com.google.javascript.rhino.ErrorReporter errorReporter36 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry37 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter36);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable39 = jSTypeRegistry37.getEachReferenceTypeWithProperty("goog.global");
        com.google.javascript.rhino.jstype.JSType jSType40 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray41 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType42 = jSTypeRegistry37.createConstructorTypeWithVarArgs(jSType40, jSTypeArray41);
        com.google.javascript.rhino.jstype.FunctionType functionType43 = jSTypeRegistry1.createConstructorType((com.google.javascript.rhino.jstype.JSType) functionType14, true, jSTypeArray41);
        com.google.javascript.rhino.ErrorReporter errorReporter44 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry45 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter44);
        com.google.javascript.rhino.ErrorReporter errorReporter46 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry47 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter46);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable49 = jSTypeRegistry47.getEachReferenceTypeWithProperty("goog.global");
        com.google.javascript.rhino.jstype.JSType jSType50 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray51 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType52 = jSTypeRegistry47.createConstructorTypeWithVarArgs(jSType50, jSTypeArray51);
        com.google.javascript.rhino.JSDocInfo jSDocInfo53 = functionType52.getJSDocInfo();
        boolean boolean54 = functionType52.isAllType();
        com.google.javascript.rhino.ErrorReporter errorReporter55 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry56 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter55);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable58 = jSTypeRegistry56.getEachReferenceTypeWithProperty("goog.global");
        com.google.javascript.rhino.jstype.JSType jSType59 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray60 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType61 = jSTypeRegistry56.createConstructorTypeWithVarArgs(jSType59, jSTypeArray60);
        int int62 = functionType61.getMaxArguments();
        boolean boolean63 = functionType52.isSubtype((com.google.javascript.rhino.jstype.JSType) functionType61);
        com.google.javascript.rhino.ErrorReporter errorReporter65 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry66 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter65);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable68 = jSTypeRegistry66.getEachReferenceTypeWithProperty("goog.global");
        com.google.javascript.rhino.jstype.JSType jSType69 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray70 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType71 = jSTypeRegistry66.createConstructorTypeWithVarArgs(jSType69, jSTypeArray70);
        com.google.javascript.rhino.JSDocInfo jSDocInfo72 = functionType71.getJSDocInfo();
        boolean boolean73 = functionType71.isAllType();
        int int74 = functionType71.getMaxArguments();
        com.google.javascript.rhino.Node node75 = com.google.javascript.rhino.IR.trueNode();
        java.lang.String str76 = node75.getSourceFileName();
        boolean boolean77 = node75.isOr();
        boolean boolean78 = functionType61.defineInferredProperty("hi!", (com.google.javascript.rhino.jstype.JSType) functionType71, node75);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray80 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType81 = jSTypeRegistry45.createConstructorType((com.google.javascript.rhino.jstype.JSType) functionType71, false, jSTypeArray80);
        boolean boolean82 = functionType81.canBeCalled();
        java.util.Collection<com.google.javascript.rhino.jstype.FunctionType> functionTypeCollection83 = jSTypeRegistry1.getDirectImplementors((com.google.javascript.rhino.jstype.ObjectType) functionType81);
        org.junit.Assert.assertNotNull(objectTypeIterable3);
        org.junit.Assert.assertNotNull(jSTypeArray5);
        org.junit.Assert.assertNotNull(functionType6);
        org.junit.Assert.assertNull(errorReporter7);
        org.junit.Assert.assertNotNull(objectTypeIterable11);
        org.junit.Assert.assertNotNull(jSTypeArray13);
        org.junit.Assert.assertNotNull(functionType14);
        org.junit.Assert.assertNull(jSDocInfo15);
        org.junit.Assert.assertNotNull(objectTypeIterable19);
        org.junit.Assert.assertNotNull(jSTypeArray21);
        org.junit.Assert.assertNotNull(functionType22);
        org.junit.Assert.assertNull(jSDocInfo23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(objectTypeIterable28);
        org.junit.Assert.assertNotNull(jSTypeArray30);
        org.junit.Assert.assertNotNull(functionType31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertNotNull(objectTypeIterable39);
        org.junit.Assert.assertNotNull(jSTypeArray41);
        org.junit.Assert.assertNotNull(functionType42);
        org.junit.Assert.assertNotNull(functionType43);
        org.junit.Assert.assertNotNull(objectTypeIterable49);
        org.junit.Assert.assertNotNull(jSTypeArray51);
        org.junit.Assert.assertNotNull(functionType52);
        org.junit.Assert.assertNull(jSDocInfo53);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNotNull(objectTypeIterable58);
        org.junit.Assert.assertNotNull(jSTypeArray60);
        org.junit.Assert.assertNotNull(functionType61);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 0 + "'", int62 == 0);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + true + "'", boolean63 == true);
        org.junit.Assert.assertNotNull(objectTypeIterable68);
        org.junit.Assert.assertNotNull(jSTypeArray70);
        org.junit.Assert.assertNotNull(functionType71);
        org.junit.Assert.assertNull(jSDocInfo72);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 0 + "'", int74 == 0);
        org.junit.Assert.assertNotNull(node75);
        org.junit.Assert.assertNull(str76);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + true + "'", boolean78 == true);
        org.junit.Assert.assertNotNull(jSTypeArray80);
        org.junit.Assert.assertNotNull(functionType81);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + true + "'", boolean82 == true);
        org.junit.Assert.assertNotNull(functionTypeCollection83);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.IR.stringKey("");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.IR.stringKey("");
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.IR.block();
        com.google.javascript.rhino.Node node8 = new com.google.javascript.rhino.Node((int) ' ', node2, node4, node5, 0, (int) (short) -1);
        boolean boolean9 = node2.isThrow();
        boolean boolean10 = node2.isTry();
        boolean boolean11 = node2.isIn();
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.IR.stringKey("goog.global");
        com.google.javascript.rhino.Node node14 = node2.copyInformationFromForTree(node13);
        java.lang.Class<?> wildcardClass15 = node2.getClass();
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNotNull(wildcardClass15);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.IR.stringKey("");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.IR.stringKey("");
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.IR.block();
        com.google.javascript.rhino.Node node8 = new com.google.javascript.rhino.Node((int) ' ', node2, node4, node5, 0, (int) (short) -1);
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.IR.stringKey("");
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.IR.stringKey("");
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.IR.block();
        com.google.javascript.rhino.Node node17 = new com.google.javascript.rhino.Node((int) ' ', node11, node13, node14, 0, (int) (short) -1);
        boolean boolean18 = node11.isThrow();
        int int19 = node5.getIndexOfChild(node11);
        com.google.javascript.rhino.Node node21 = com.google.javascript.rhino.IR.stringKey("");
        int int22 = node21.getLineno();
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.IR.block();
        java.lang.String str27 = node23.toString(false, false, false);
        com.google.javascript.rhino.Node node28 = com.google.javascript.rhino.IR.block();
        java.lang.String str32 = node28.toString(false, false, false);
        com.google.javascript.rhino.Node node33 = node23.useSourceInfoIfMissingFrom(node28);
        com.google.javascript.rhino.Node node34 = node21.srcrefTree(node23);
        com.google.javascript.rhino.Node node35 = node5.useSourceInfoIfMissingFromForTree(node21);
        int int36 = node21.getLineno();
        com.google.javascript.rhino.Node node40 = com.google.javascript.rhino.Node.newString("InputId: Not declared as a constructor", (int) '4', (int) (byte) 100);
        com.google.javascript.rhino.Node node41 = node21.useSourceInfoIfMissingFrom(node40);
        boolean boolean42 = node21.isHook();
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "BLOCK" + "'", str27.equals("BLOCK"));
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "BLOCK" + "'", str32.equals("BLOCK"));
        org.junit.Assert.assertNotNull(node33);
        org.junit.Assert.assertNotNull(node34);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + (-1) + "'", int36 == (-1));
        org.junit.Assert.assertNotNull(node40);
        org.junit.Assert.assertNotNull(node41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeUnusedPrototypePropertiesInExterns = true;
        java.util.Map<java.lang.String, java.lang.Object> strMap3 = null;
        compilerOptions0.setTweakReplacements(strMap3);
        compilerOptions0.setInlineConstantVars(false);
        java.lang.String str7 = compilerOptions0.renamePrefix;
        boolean boolean8 = compilerOptions0.preferLineBreakAtEndOfFile;
        compilerOptions0.setExternExports(true);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable3 = jSTypeRegistry1.getEachReferenceTypeWithProperty("goog.global");
        com.google.javascript.rhino.jstype.JSType jSType4 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray5 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType6 = jSTypeRegistry1.createConstructorTypeWithVarArgs(jSType4, jSTypeArray5);
        com.google.javascript.rhino.JSDocInfo jSDocInfo7 = functionType6.getJSDocInfo();
        com.google.javascript.rhino.ErrorReporter errorReporter8 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry9 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter8);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable11 = jSTypeRegistry9.getEachReferenceTypeWithProperty("goog.global");
        com.google.javascript.rhino.jstype.JSType jSType12 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray13 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType14 = jSTypeRegistry9.createConstructorTypeWithVarArgs(jSType12, jSTypeArray13);
        com.google.javascript.rhino.JSDocInfo jSDocInfo15 = functionType14.getJSDocInfo();
        boolean boolean16 = functionType14.isAllType();
        com.google.javascript.rhino.ErrorReporter errorReporter17 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry18 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter17);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable20 = jSTypeRegistry18.getEachReferenceTypeWithProperty("goog.global");
        com.google.javascript.rhino.jstype.JSType jSType21 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray22 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType23 = jSTypeRegistry18.createConstructorTypeWithVarArgs(jSType21, jSTypeArray22);
        int int24 = functionType23.getMaxArguments();
        boolean boolean25 = functionType14.isSubtype((com.google.javascript.rhino.jstype.JSType) functionType23);
        boolean boolean26 = functionType6.canTestForEqualityWith((com.google.javascript.rhino.jstype.JSType) functionType23);
        com.google.javascript.rhino.jstype.JSType jSType27 = functionType6.getReturnType();
        boolean boolean28 = functionType6.isRegexpType();
        com.google.javascript.rhino.jstype.FunctionType functionType29 = functionType6.getOwnerFunction();
        try {
            boolean boolean30 = functionType29.isAllType();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(objectTypeIterable3);
        org.junit.Assert.assertNotNull(jSTypeArray5);
        org.junit.Assert.assertNotNull(functionType6);
        org.junit.Assert.assertNull(jSDocInfo7);
        org.junit.Assert.assertNotNull(objectTypeIterable11);
        org.junit.Assert.assertNotNull(jSTypeArray13);
        org.junit.Assert.assertNotNull(functionType14);
        org.junit.Assert.assertNull(jSDocInfo15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(objectTypeIterable20);
        org.junit.Assert.assertNotNull(jSTypeArray22);
        org.junit.Assert.assertNotNull(functionType23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(jSType27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNull(functionType29);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.IR.stringKey("");
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable3 = node2.siblings();
        com.google.javascript.rhino.Node node6 = new com.google.javascript.rhino.Node((int) (short) 100, node2, (int) (short) 1, (int) (short) 10);
        boolean boolean7 = node2.isBreak();
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.IR.stringKey("");
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.IR.stringKey("");
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.IR.block();
        com.google.javascript.rhino.Node node16 = new com.google.javascript.rhino.Node((int) ' ', node10, node12, node13, 0, (int) (short) -1);
        boolean boolean17 = node10.isThrow();
        boolean boolean18 = node10.isTry();
        boolean boolean19 = node10.isIn();
        com.google.javascript.rhino.Node node22 = com.google.javascript.rhino.IR.stringKey("");
        com.google.javascript.rhino.Node node24 = com.google.javascript.rhino.IR.stringKey("");
        com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.IR.block();
        com.google.javascript.rhino.Node node28 = new com.google.javascript.rhino.Node((int) ' ', node22, node24, node25, 0, (int) (short) -1);
        com.google.javascript.rhino.Node node31 = com.google.javascript.rhino.IR.stringKey("");
        com.google.javascript.rhino.Node node33 = com.google.javascript.rhino.IR.stringKey("");
        com.google.javascript.rhino.Node node34 = com.google.javascript.rhino.IR.block();
        com.google.javascript.rhino.Node node37 = new com.google.javascript.rhino.Node((int) ' ', node31, node33, node34, 0, (int) (short) -1);
        boolean boolean38 = node31.isThrow();
        int int39 = node25.getIndexOfChild(node31);
        com.google.javascript.rhino.Node node41 = com.google.javascript.rhino.IR.stringKey("");
        int int42 = node41.getLineno();
        com.google.javascript.rhino.Node node43 = com.google.javascript.rhino.IR.block();
        java.lang.String str47 = node43.toString(false, false, false);
        com.google.javascript.rhino.Node node48 = com.google.javascript.rhino.IR.block();
        java.lang.String str52 = node48.toString(false, false, false);
        com.google.javascript.rhino.Node node53 = node43.useSourceInfoIfMissingFrom(node48);
        com.google.javascript.rhino.Node node54 = node41.srcrefTree(node43);
        com.google.javascript.rhino.Node node55 = node25.useSourceInfoIfMissingFromForTree(node41);
        int int56 = node41.getLineno();
        com.google.javascript.rhino.Node node60 = com.google.javascript.rhino.Node.newString("InputId: Not declared as a constructor", (int) '4', (int) (byte) 100);
        com.google.javascript.rhino.Node node61 = node41.useSourceInfoIfMissingFrom(node60);
        com.google.javascript.rhino.Node node62 = com.google.javascript.rhino.IR.block();
        java.lang.String str66 = node62.toString(false, false, false);
        java.lang.String str67 = node62.getQualifiedName();
        try {
            com.google.javascript.rhino.Node node68 = com.google.javascript.rhino.IR.forNode(node2, node10, node41, node62);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertNotNull(nodeIterable3);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertNotNull(node33);
        org.junit.Assert.assertNotNull(node34);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + (-1) + "'", int39 == (-1));
        org.junit.Assert.assertNotNull(node41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + (-1) + "'", int42 == (-1));
        org.junit.Assert.assertNotNull(node43);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "BLOCK" + "'", str47.equals("BLOCK"));
        org.junit.Assert.assertNotNull(node48);
        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "BLOCK" + "'", str52.equals("BLOCK"));
        org.junit.Assert.assertNotNull(node53);
        org.junit.Assert.assertNotNull(node54);
        org.junit.Assert.assertNotNull(node55);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + (-1) + "'", int56 == (-1));
        org.junit.Assert.assertNotNull(node60);
        org.junit.Assert.assertNotNull(node61);
        org.junit.Assert.assertNotNull(node62);
        org.junit.Assert.assertTrue("'" + str66 + "' != '" + "BLOCK" + "'", str66.equals("BLOCK"));
        org.junit.Assert.assertNull(str67);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = com.google.javascript.jscomp.CheckLevel.ERROR;
        compilerOptions0.reportMissingOverride = checkLevel1;
        compilerOptions0.removeUnusedPrototypePropertiesInExterns = true;
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention0 = new com.google.javascript.jscomp.GoogleCodingConvention();
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention1 = new com.google.javascript.jscomp.ClosureCodingConvention((com.google.javascript.jscomp.CodingConvention) googleCodingConvention0);
        java.lang.String str2 = closureCodingConvention1.getGlobalObject();
        java.lang.String str3 = closureCodingConvention1.getExportPropertyFunction();
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.IR.block();
        java.lang.String str8 = node4.toString(false, false, false);
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.IR.block();
        java.lang.String str13 = node9.toString(false, false, false);
        com.google.javascript.rhino.Node node14 = node4.useSourceInfoIfMissingFrom(node9);
        boolean boolean15 = node14.isParamList();
        com.google.javascript.jscomp.CodingConvention.Bind bind17 = closureCodingConvention1.describeFunctionBind(node14, true);
        try {
            com.google.javascript.rhino.Node node18 = com.google.javascript.jscomp.NodeUtil.newExpr(node14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "goog.global" + "'", str2.equals("goog.global"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "goog.exportProperty" + "'", str3.equals("goog.exportProperty"));
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "BLOCK" + "'", str8.equals("BLOCK"));
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "BLOCK" + "'", str13.equals("BLOCK"));
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNull(bind17);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        com.google.javascript.jscomp.DiagnosticGroup[] diagnosticGroupArray0 = new com.google.javascript.jscomp.DiagnosticGroup[] {};
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup1 = new com.google.javascript.jscomp.DiagnosticGroup(diagnosticGroupArray0);
        org.junit.Assert.assertNotNull(diagnosticGroupArray0);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy1 = null;
        compilerOptions0.setVariableRenaming(variableRenamingPolicy1);
        boolean boolean3 = compilerOptions0.rewriteFunctionExpressions;
        boolean boolean4 = compilerOptions0.getInferTypes();
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy5 = com.google.javascript.jscomp.PropertyRenamingPolicy.HEURISTIC;
        compilerOptions0.setPropertyRenaming(propertyRenamingPolicy5);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy5 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.HEURISTIC + "'", propertyRenamingPolicy5.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.HEURISTIC));
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        com.google.javascript.jscomp.JSModule[] jSModuleArray0 = new com.google.javascript.jscomp.JSModule[] {};
        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList1 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList1, jSModuleArray0);
        com.google.javascript.jscomp.JSModule[] jSModuleArray3 = com.google.javascript.jscomp.JSModule.sortJsModules((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList1);
        com.google.javascript.jscomp.JSModule[] jSModuleArray4 = com.google.javascript.jscomp.JSModule.sortJsModules((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList1);
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph5 = new com.google.javascript.jscomp.JSModuleGraph(jSModuleArray4);
        java.lang.String[] strArray11 = new java.lang.String[] { "module$hi!", "", "hi!" };
        java.util.ArrayList<java.lang.String> strList12 = new java.util.ArrayList<java.lang.String>();
        boolean boolean13 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strList12, strArray11);
        java.lang.String[] strArray24 = new java.lang.String[] { "Not declared as a constructor", "InputId: Not declared as a constructor", "goog.global", "./", "./", "BLOCK", "Not declared as a constructor", "JSDocInfo", "InputId: Not declared as a constructor", "" };
        java.util.ArrayList<java.lang.String> strList25 = new java.util.ArrayList<java.lang.String>();
        boolean boolean26 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strList25, strArray24);
        com.google.javascript.jscomp.deps.SimpleDependencyInfo simpleDependencyInfo27 = new com.google.javascript.jscomp.deps.SimpleDependencyInfo("this", "BLOCK", (java.util.List<java.lang.String>) strList12, (java.util.List<java.lang.String>) strList25);
        com.google.javascript.jscomp.SourceAst sourceAst28 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput31 = new com.google.javascript.jscomp.CompilerInput(sourceAst28, "Not declared as a constructor", true);
        com.google.javascript.rhino.InputId inputId32 = compilerInput31.getInputId();
        com.google.javascript.jscomp.SourceAst sourceAst33 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput36 = new com.google.javascript.jscomp.CompilerInput(sourceAst33, "JSDocInfo", false);
        com.google.javascript.jscomp.CompilerInput[] compilerInputArray37 = new com.google.javascript.jscomp.CompilerInput[] { compilerInput31, compilerInput36 };
        java.util.ArrayList<com.google.javascript.jscomp.CompilerInput> compilerInputList38 = new java.util.ArrayList<com.google.javascript.jscomp.CompilerInput>();
        boolean boolean39 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.CompilerInput>) compilerInputList38, compilerInputArray37);
        try {
            java.util.List<com.google.javascript.jscomp.CompilerInput> compilerInputList40 = jSModuleGraph5.manageDependencies((java.util.List<java.lang.String>) strList12, (java.util.List<com.google.javascript.jscomp.CompilerInput>) compilerInputList38);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Expected setCompiler to be called first: Not declared as a constructor");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jSModuleArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(jSModuleArray3);
        org.junit.Assert.assertNotNull(jSModuleArray4);
        org.junit.Assert.assertNotNull(strArray11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(strArray24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(inputId32);
        org.junit.Assert.assertNotNull(compilerInputArray37);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        com.google.javascript.jscomp.AstValidator.ViolationHandler violationHandler0 = null;
        com.google.javascript.jscomp.AstValidator astValidator1 = new com.google.javascript.jscomp.AstValidator(violationHandler0);
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention2 = new com.google.javascript.jscomp.GoogleCodingConvention();
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention3 = new com.google.javascript.jscomp.ClosureCodingConvention((com.google.javascript.jscomp.CodingConvention) googleCodingConvention2);
        java.lang.String str4 = closureCodingConvention3.getGlobalObject();
        java.lang.String str5 = closureCodingConvention3.getExportPropertyFunction();
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.IR.block();
        java.lang.String str10 = node6.toString(false, false, false);
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.IR.block();
        java.lang.String str15 = node11.toString(false, false, false);
        com.google.javascript.rhino.Node node16 = node6.useSourceInfoIfMissingFrom(node11);
        boolean boolean17 = node16.isParamList();
        com.google.javascript.jscomp.CodingConvention.Bind bind19 = closureCodingConvention3.describeFunctionBind(node16, false);
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.IR.block();
        boolean boolean21 = node20.isCase();
        com.google.javascript.jscomp.CodingConvention.Bind bind23 = closureCodingConvention3.describeFunctionBind(node20, false);
        try {
            astValidator1.validateScript(node20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "goog.global" + "'", str4.equals("goog.global"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "goog.exportProperty" + "'", str5.equals("goog.exportProperty"));
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "BLOCK" + "'", str10.equals("BLOCK"));
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "BLOCK" + "'", str15.equals("BLOCK"));
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNull(bind19);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNull(bind23);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeUnusedPrototypePropertiesInExterns = true;
        java.util.Map<java.lang.String, java.lang.Object> strMap3 = null;
        compilerOptions0.setTweakReplacements(strMap3);
        com.google.javascript.jscomp.parsing.Config.LanguageMode languageMode6 = com.google.javascript.jscomp.parsing.Config.LanguageMode.ECMASCRIPT3;
        java.lang.String[] strArray10 = new java.lang.String[] { "hi!", "hi!" };
        java.util.LinkedHashSet<java.lang.String> strSet11 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean12 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet11, strArray10);
        com.google.javascript.jscomp.parsing.Config config13 = com.google.javascript.jscomp.parsing.ParserRunner.createConfig(false, languageMode6, true, (java.util.Set<java.lang.String>) strSet11);
        compilerOptions0.stripNameSuffixes = strSet11;
        boolean boolean15 = compilerOptions0.inlineLocalFunctions;
        compilerOptions0.extractPrototypeMemberDeclarations = true;
        byte[] byteArray18 = new byte[] {};
        compilerOptions0.inputPropertyMapSerialized = byteArray18;
        org.junit.Assert.assertTrue("'" + languageMode6 + "' != '" + com.google.javascript.jscomp.parsing.Config.LanguageMode.ECMASCRIPT3 + "'", languageMode6.equals(com.google.javascript.jscomp.parsing.Config.LanguageMode.ECMASCRIPT3));
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(config13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(byteArray18);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.STRING_TYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.STRING_TYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.STRING_TYPE));
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.returnNode();
        java.util.Set<java.lang.String> strSet1 = node0.getDirectives();
        int int2 = node0.getType();
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.IR.block();
        java.lang.String str7 = node3.toString(false, false, false);
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.IR.block();
        java.lang.String str12 = node8.toString(false, false, false);
        com.google.javascript.rhino.Node node13 = node3.useSourceInfoIfMissingFrom(node8);
        com.google.javascript.rhino.Node node14 = node0.useSourceInfoIfMissingFrom(node3);
        boolean boolean15 = node14.isFor();
        try {
            com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.IR.paramList(node14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertNull(strSet1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "BLOCK" + "'", str7.equals("BLOCK"));
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "BLOCK" + "'", str12.equals("BLOCK"));
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_OBJECT_FUNCTION_TYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_OBJECT_FUNCTION_TYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_OBJECT_FUNCTION_TYPE));
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        com.google.javascript.jscomp.SourceAst sourceAst0 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(sourceAst0, "Not declared as a constructor", true);
        com.google.javascript.rhino.InputId inputId4 = compilerInput3.getInputId();
        com.google.javascript.jscomp.SourceFile sourceFile6 = com.google.javascript.jscomp.SourceFile.fromFile("./");
        java.lang.String str7 = sourceFile6.getOriginalPath();
        com.google.javascript.jscomp.JsAst jsAst8 = new com.google.javascript.jscomp.JsAst(sourceFile6);
        java.lang.String str10 = sourceFile6.getLine((int) ' ');
        try {
            compilerInput3.setSourceFile(sourceFile6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(inputId4);
        org.junit.Assert.assertNotNull(sourceFile6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "." + "'", str7.equals("."));
        org.junit.Assert.assertNull(str10);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.computeFunctionSideEffects = true;
        com.google.javascript.jscomp.CheckLevel checkLevel3 = compilerOptions0.checkProvides;
        compilerOptions0.setPreferLineBreakAtEndOfFile(false);
        org.junit.Assert.assertTrue("'" + checkLevel3 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel3.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        com.google.javascript.jscomp.SourceFile sourceFile1 = com.google.javascript.jscomp.SourceFile.fromFile("./");
        java.lang.String str2 = sourceFile1.getOriginalPath();
        try {
            java.lang.String str3 = sourceFile1.getCode();
            org.junit.Assert.fail("Expected exception of type java.io.FileNotFoundException; message: . (Is a directory)");
        } catch (java.io.FileNotFoundException e) {
        }
        org.junit.Assert.assertNotNull(sourceFile1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "." + "'", str2.equals("."));
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        com.google.javascript.jscomp.CompilerOptions compilerOptions4 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions4.computeFunctionSideEffects = true;
        boolean boolean7 = compilerOptions4.ideMode;
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention8 = new com.google.javascript.jscomp.GoogleCodingConvention();
        compilerOptions4.setCodingConvention((com.google.javascript.jscomp.CodingConvention) googleCodingConvention8);
        com.google.javascript.jscomp.CompilerOptions compilerOptions10 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions10.computeFunctionSideEffects = true;
        boolean boolean13 = compilerOptions10.isRemoveUnusedClassProperties();
        com.google.javascript.jscomp.ErrorHandler errorHandler14 = null;
        compilerOptions10.setErrorHandler(errorHandler14);
        java.util.List<com.google.javascript.jscomp.SourceMap.LocationMapping> locationMappingList16 = compilerOptions10.sourceMapLocationMappings;
        com.google.javascript.jscomp.CheckLevel checkLevel17 = com.google.javascript.jscomp.CheckLevel.ERROR;
        compilerOptions10.setCheckProvides(checkLevel17);
        compilerOptions4.setReportMissingOverride(checkLevel17);
        com.google.javascript.jscomp.DiagnosticType diagnosticType21 = com.google.javascript.jscomp.DiagnosticType.make("JSDocInfo", checkLevel17, "JSDocInfo");
        java.lang.String[] strArray27 = new java.lang.String[] { "./", "goog.global", "BLOCK", "BLOCK\n", "" };
        com.google.javascript.jscomp.JSError jSError28 = com.google.javascript.jscomp.JSError.make("Not declared as a constructor", 4, 0, diagnosticType21, strArray27);
        java.lang.String str29 = jSError28.description;
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(locationMappingList16);
        org.junit.Assert.assertTrue("'" + checkLevel17 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel17.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticType21);
        org.junit.Assert.assertNotNull(strArray27);
        org.junit.Assert.assertNotNull(jSError28);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "JSDocInfo" + "'", str29.equals("JSDocInfo"));
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        com.google.javascript.rhino.Node node1 = com.google.javascript.jscomp.parsing.JsDocInfoParser.parseTypeString("JSDocInfo");
        boolean boolean2 = node1.isSyntheticBlock();
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeUnusedPrototypePropertiesInExterns = true;
        byte[] byteArray3 = compilerOptions0.inputVariableMapSerialized;
        compilerOptions0.setOutputJsStringUsage(true);
        org.junit.Assert.assertNull(byteArray3);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        try {
            java.lang.String str2 = com.google.javascript.rhino.ScriptRuntime.escapeString("goog.exportProperty", '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: unexpected quote char:4");
        } catch (java.lang.IllegalStateException e) {
        }
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        com.google.javascript.rhino.JSDocInfo jSDocInfo0 = new com.google.javascript.rhino.JSDocInfo();
        java.util.List<com.google.javascript.rhino.JSTypeExpression> jSTypeExpressionList1 = jSDocInfo0.getImplementedInterfaces();
        java.util.Set<java.lang.String> strSet2 = jSDocInfo0.getSuppressions();
        com.google.javascript.rhino.JSDocInfo.Visibility visibility3 = jSDocInfo0.getVisibility();
        java.lang.String str4 = jSDocInfo0.getReturnDescription();
        java.lang.String str6 = jSDocInfo0.getDescriptionForParameter("function (): {1835552301}");
        org.junit.Assert.assertNotNull(jSTypeExpressionList1);
        org.junit.Assert.assertNotNull(strSet2);
        org.junit.Assert.assertNull(visibility3);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNull(str6);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.STRICT_MODULE_DEP_CHECK;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.stringKey("");
        int int2 = node1.getLineno();
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.IR.block();
        java.lang.String str7 = node3.toString(false, false, false);
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.IR.block();
        java.lang.String str12 = node8.toString(false, false, false);
        com.google.javascript.rhino.Node node13 = node3.useSourceInfoIfMissingFrom(node8);
        com.google.javascript.rhino.Node node14 = node1.srcrefTree(node3);
        node3.setSourceFileForTesting("BLOCK");
        boolean boolean17 = node3.isStringKey();
        try {
            com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.IR.var(node3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "BLOCK" + "'", str7.equals("BLOCK"));
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "BLOCK" + "'", str12.equals("BLOCK"));
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.NO_OBJECT_TYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.NO_OBJECT_TYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.NO_OBJECT_TYPE));
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        com.google.javascript.jscomp.AstValidator.ViolationHandler violationHandler0 = null;
        com.google.javascript.jscomp.AstValidator astValidator1 = new com.google.javascript.jscomp.AstValidator(violationHandler0);
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString("InputId: Not declared as a constructor", (int) '4', (int) (byte) 100);
        try {
            astValidator1.process(node2, node6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertNotNull(node6);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeUnusedPrototypePropertiesInExterns = true;
        java.util.Map<java.lang.String, java.lang.Object> strMap3 = null;
        compilerOptions0.setTweakReplacements(strMap3);
        com.google.javascript.jscomp.parsing.Config.LanguageMode languageMode6 = com.google.javascript.jscomp.parsing.Config.LanguageMode.ECMASCRIPT3;
        java.lang.String[] strArray10 = new java.lang.String[] { "hi!", "hi!" };
        java.util.LinkedHashSet<java.lang.String> strSet11 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean12 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet11, strArray10);
        com.google.javascript.jscomp.parsing.Config config13 = com.google.javascript.jscomp.parsing.ParserRunner.createConfig(false, languageMode6, true, (java.util.Set<java.lang.String>) strSet11);
        compilerOptions0.stripNameSuffixes = strSet11;
        boolean boolean15 = compilerOptions0.inlineLocalFunctions;
        compilerOptions0.setNameReferenceGraphPath("");
        org.junit.Assert.assertTrue("'" + languageMode6 + "' != '" + com.google.javascript.jscomp.parsing.Config.LanguageMode.ECMASCRIPT3 + "'", languageMode6.equals(com.google.javascript.jscomp.parsing.Config.LanguageMode.ECMASCRIPT3));
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(config13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.stringKey("");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.IR.stringKey("");
        com.google.javascript.rhino.Node node4 = null;
        int int5 = node3.getIndexOfChild(node4);
        node1.addChildrenToBack(node3);
        boolean boolean7 = node1.isLocalResultCall();
        boolean boolean8 = node1.isGetterDef();
        java.lang.String str9 = node1.getString();
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.IR.stringKey("");
        int int12 = node11.getLineno();
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.IR.stringKey("");
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.IR.stringKey("");
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.IR.block();
        com.google.javascript.rhino.Node node21 = new com.google.javascript.rhino.Node((int) ' ', node15, node17, node18, 0, (int) (short) -1);
        boolean boolean22 = node15.isThrow();
        boolean boolean23 = node15.isTry();
        boolean boolean24 = node15.isIn();
        com.google.javascript.rhino.Node node25 = node15.getParent();
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention26 = new com.google.javascript.jscomp.GoogleCodingConvention();
        com.google.javascript.rhino.Node node28 = com.google.javascript.rhino.IR.stringKey("");
        com.google.javascript.rhino.Node node30 = com.google.javascript.rhino.IR.stringKey("");
        com.google.javascript.rhino.Node node31 = null;
        int int32 = node30.getIndexOfChild(node31);
        node28.addChildrenToBack(node30);
        java.lang.String str34 = googleCodingConvention26.getSingletonGetterClassName(node28);
        com.google.javascript.rhino.Node node37 = com.google.javascript.rhino.IR.stringKey("");
        com.google.javascript.rhino.Node node39 = com.google.javascript.rhino.IR.stringKey("");
        com.google.javascript.rhino.Node node40 = com.google.javascript.rhino.IR.block();
        com.google.javascript.rhino.Node node43 = new com.google.javascript.rhino.Node((int) ' ', node37, node39, node40, 0, (int) (short) -1);
        boolean boolean44 = node39.isBreak();
        com.google.javascript.rhino.Node[] nodeArray45 = new com.google.javascript.rhino.Node[] { node11, node25, node28, node39 };
        try {
            com.google.javascript.rhino.Node node46 = com.google.javascript.rhino.IR.call(node1, nodeArray45);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertNotNull(node30);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-1) + "'", int32 == (-1));
        org.junit.Assert.assertNull(str34);
        org.junit.Assert.assertNotNull(node37);
        org.junit.Assert.assertNotNull(node39);
        org.junit.Assert.assertNotNull(node40);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(nodeArray45);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.stringKey("");
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable2 = node1.siblings();
        boolean boolean3 = node1.isQualifiedName();
        node1.setString("");
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.IR.stringKey("");
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.IR.stringKey("");
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.IR.block();
        com.google.javascript.rhino.Node node14 = new com.google.javascript.rhino.Node((int) ' ', node8, node10, node11, 0, (int) (short) -1);
        boolean boolean15 = node8.isThrow();
        boolean boolean16 = node8.isStringKey();
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.IR.block();
        com.google.javascript.rhino.Node node18 = node8.useSourceInfoIfMissingFrom(node17);
        com.google.javascript.rhino.Node node19 = node1.copyInformationFromForTree(node18);
        node18.setQuotedString();
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertNotNull(nodeIterable2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNotNull(node19);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        com.google.javascript.jscomp.CustomPassExecutionTime customPassExecutionTime0 = com.google.javascript.jscomp.CustomPassExecutionTime.AFTER_OPTIMIZATION_LOOP;
        org.junit.Assert.assertTrue("'" + customPassExecutionTime0 + "' != '" + com.google.javascript.jscomp.CustomPassExecutionTime.AFTER_OPTIMIZATION_LOOP + "'", customPassExecutionTime0.equals(com.google.javascript.jscomp.CustomPassExecutionTime.AFTER_OPTIMIZATION_LOOP));
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable3 = jSTypeRegistry1.getEachReferenceTypeWithProperty("goog.global");
        com.google.javascript.rhino.jstype.JSType jSType4 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray5 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType6 = jSTypeRegistry1.createConstructorTypeWithVarArgs(jSType4, jSTypeArray5);
        com.google.javascript.rhino.JSDocInfo jSDocInfo7 = functionType6.getJSDocInfo();
        boolean boolean8 = functionType6.isAllType();
        com.google.javascript.rhino.ErrorReporter errorReporter9 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry10 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter9);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable12 = jSTypeRegistry10.getEachReferenceTypeWithProperty("goog.global");
        com.google.javascript.rhino.jstype.JSType jSType13 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray14 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType15 = jSTypeRegistry10.createConstructorTypeWithVarArgs(jSType13, jSTypeArray14);
        int int16 = functionType15.getMaxArguments();
        boolean boolean17 = functionType6.isSubtype((com.google.javascript.rhino.jstype.JSType) functionType15);
        com.google.javascript.rhino.ErrorReporter errorReporter19 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry20 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter19);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable22 = jSTypeRegistry20.getEachReferenceTypeWithProperty("goog.global");
        com.google.javascript.rhino.jstype.JSType jSType23 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray24 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType25 = jSTypeRegistry20.createConstructorTypeWithVarArgs(jSType23, jSTypeArray24);
        com.google.javascript.rhino.JSDocInfo jSDocInfo26 = functionType25.getJSDocInfo();
        boolean boolean27 = functionType25.isAllType();
        int int28 = functionType25.getMaxArguments();
        com.google.javascript.rhino.Node node29 = com.google.javascript.rhino.IR.trueNode();
        java.lang.String str30 = node29.getSourceFileName();
        boolean boolean31 = node29.isOr();
        boolean boolean32 = functionType15.defineInferredProperty("hi!", (com.google.javascript.rhino.jstype.JSType) functionType25, node29);
        com.google.javascript.rhino.jstype.ParameterizedType parameterizedType33 = functionType25.toMaybeParameterizedType();
        boolean boolean34 = functionType25.hasInstanceType();
        org.junit.Assert.assertNotNull(objectTypeIterable3);
        org.junit.Assert.assertNotNull(jSTypeArray5);
        org.junit.Assert.assertNotNull(functionType6);
        org.junit.Assert.assertNull(jSDocInfo7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(objectTypeIterable12);
        org.junit.Assert.assertNotNull(jSTypeArray14);
        org.junit.Assert.assertNotNull(functionType15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(objectTypeIterable22);
        org.junit.Assert.assertNotNull(jSTypeArray24);
        org.junit.Assert.assertNotNull(functionType25);
        org.junit.Assert.assertNull(jSDocInfo26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNull(str30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNull(parameterizedType33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.UNDEFINED_NAMES;
        com.google.javascript.jscomp.DiagnosticGroups.STRICT_MODULE_DEP_CHECK = diagnosticGroup0;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.IR.stringKey("");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.IR.stringKey("");
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.IR.block();
        com.google.javascript.rhino.Node node8 = new com.google.javascript.rhino.Node((int) ' ', node2, node4, node5, 0, (int) (short) -1);
        com.google.javascript.rhino.Node node9 = node5.getFirstChild();
        com.google.javascript.jscomp.SourceFile sourceFile11 = com.google.javascript.jscomp.SourceFile.fromFile("./");
        java.lang.String str12 = sourceFile11.getOriginalPath();
        com.google.javascript.jscomp.JsAst jsAst13 = new com.google.javascript.jscomp.JsAst(sourceFile11);
        try {
            node9.setStaticSourceFile((com.google.javascript.rhino.jstype.StaticSourceFile) sourceFile11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNull(node9);
        org.junit.Assert.assertNotNull(sourceFile11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "." + "'", str12.equals("."));
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.breakNode();
        org.junit.Assert.assertNotNull(node0);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.computeFunctionSideEffects = true;
        com.google.javascript.jscomp.CheckLevel checkLevel3 = compilerOptions0.checkProvides;
        boolean boolean4 = compilerOptions0.rewriteFunctionExpressions;
        org.junit.Assert.assertTrue("'" + checkLevel3 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel3.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.IR.stringKey("");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.IR.stringKey("");
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.IR.block();
        com.google.javascript.rhino.Node node8 = new com.google.javascript.rhino.Node((int) ' ', node2, node4, node5, 0, (int) (short) -1);
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.IR.stringKey("");
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.IR.stringKey("");
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.IR.block();
        com.google.javascript.rhino.Node node17 = new com.google.javascript.rhino.Node((int) ' ', node11, node13, node14, 0, (int) (short) -1);
        boolean boolean18 = node11.isThrow();
        int int19 = node5.getIndexOfChild(node11);
        com.google.javascript.rhino.Node node21 = com.google.javascript.rhino.IR.stringKey("");
        int int22 = node21.getLineno();
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.IR.block();
        java.lang.String str27 = node23.toString(false, false, false);
        com.google.javascript.rhino.Node node28 = com.google.javascript.rhino.IR.block();
        java.lang.String str32 = node28.toString(false, false, false);
        com.google.javascript.rhino.Node node33 = node23.useSourceInfoIfMissingFrom(node28);
        com.google.javascript.rhino.Node node34 = node21.srcrefTree(node23);
        com.google.javascript.rhino.Node node35 = node5.useSourceInfoIfMissingFromForTree(node21);
        com.google.javascript.rhino.Node node39 = com.google.javascript.rhino.Node.newString("goog.global", 53, 0);
        boolean boolean40 = node39.isExprResult();
        try {
            com.google.javascript.rhino.Node node41 = com.google.javascript.rhino.IR.and(node35, node39);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "BLOCK" + "'", str27.equals("BLOCK"));
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "BLOCK" + "'", str32.equals("BLOCK"));
        org.junit.Assert.assertNotNull(node33);
        org.junit.Assert.assertNotNull(node34);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertNotNull(node39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        int int0 = com.google.javascript.rhino.Node.LENGTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 52 + "'", int0 == 52);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.IR.stringKey("");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.IR.stringKey("");
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.IR.block();
        com.google.javascript.rhino.Node node8 = new com.google.javascript.rhino.Node((int) ' ', node2, node4, node5, 0, (int) (short) -1);
        boolean boolean9 = node2.isThrow();
        boolean boolean10 = node2.isStringKey();
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.IR.block();
        com.google.javascript.rhino.Node node12 = node2.useSourceInfoIfMissingFrom(node11);
        boolean boolean13 = node12.isDo();
        try {
            com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.IR.returnNode(node12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable3 = jSTypeRegistry1.getEachReferenceTypeWithProperty("goog.global");
        com.google.javascript.rhino.jstype.JSType jSType4 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray5 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType6 = jSTypeRegistry1.createConstructorTypeWithVarArgs(jSType4, jSTypeArray5);
        com.google.javascript.rhino.ErrorReporter errorReporter7 = jSTypeRegistry1.getErrorReporter();
        com.google.javascript.rhino.ErrorReporter errorReporter8 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry9 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter8);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable11 = jSTypeRegistry9.getEachReferenceTypeWithProperty("goog.global");
        com.google.javascript.rhino.jstype.JSType jSType12 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray13 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType14 = jSTypeRegistry9.createConstructorTypeWithVarArgs(jSType12, jSTypeArray13);
        com.google.javascript.rhino.JSDocInfo jSDocInfo15 = functionType14.getJSDocInfo();
        com.google.javascript.rhino.ErrorReporter errorReporter16 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry17 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter16);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable19 = jSTypeRegistry17.getEachReferenceTypeWithProperty("goog.global");
        com.google.javascript.rhino.jstype.JSType jSType20 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray21 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType22 = jSTypeRegistry17.createConstructorTypeWithVarArgs(jSType20, jSTypeArray21);
        com.google.javascript.rhino.JSDocInfo jSDocInfo23 = functionType22.getJSDocInfo();
        boolean boolean24 = functionType22.isAllType();
        com.google.javascript.rhino.ErrorReporter errorReporter25 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry26 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter25);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable28 = jSTypeRegistry26.getEachReferenceTypeWithProperty("goog.global");
        com.google.javascript.rhino.jstype.JSType jSType29 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray30 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType31 = jSTypeRegistry26.createConstructorTypeWithVarArgs(jSType29, jSTypeArray30);
        int int32 = functionType31.getMaxArguments();
        boolean boolean33 = functionType22.isSubtype((com.google.javascript.rhino.jstype.JSType) functionType31);
        boolean boolean34 = functionType14.canTestForEqualityWith((com.google.javascript.rhino.jstype.JSType) functionType31);
        com.google.javascript.rhino.ErrorReporter errorReporter36 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry37 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter36);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable39 = jSTypeRegistry37.getEachReferenceTypeWithProperty("goog.global");
        com.google.javascript.rhino.jstype.JSType jSType40 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray41 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType42 = jSTypeRegistry37.createConstructorTypeWithVarArgs(jSType40, jSTypeArray41);
        com.google.javascript.rhino.jstype.FunctionType functionType43 = jSTypeRegistry1.createConstructorType((com.google.javascript.rhino.jstype.JSType) functionType14, true, jSTypeArray41);
        com.google.javascript.rhino.jstype.JSType jSType44 = functionType43.restrictByNotNullOrUndefined();
        org.junit.Assert.assertNotNull(objectTypeIterable3);
        org.junit.Assert.assertNotNull(jSTypeArray5);
        org.junit.Assert.assertNotNull(functionType6);
        org.junit.Assert.assertNull(errorReporter7);
        org.junit.Assert.assertNotNull(objectTypeIterable11);
        org.junit.Assert.assertNotNull(jSTypeArray13);
        org.junit.Assert.assertNotNull(functionType14);
        org.junit.Assert.assertNull(jSDocInfo15);
        org.junit.Assert.assertNotNull(objectTypeIterable19);
        org.junit.Assert.assertNotNull(jSTypeArray21);
        org.junit.Assert.assertNotNull(functionType22);
        org.junit.Assert.assertNull(jSDocInfo23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(objectTypeIterable28);
        org.junit.Assert.assertNotNull(jSTypeArray30);
        org.junit.Assert.assertNotNull(functionType31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertNotNull(objectTypeIterable39);
        org.junit.Assert.assertNotNull(jSTypeArray41);
        org.junit.Assert.assertNotNull(functionType42);
        org.junit.Assert.assertNotNull(functionType43);
        org.junit.Assert.assertNotNull(jSType44);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        com.google.javascript.rhino.ErrorReporter errorReporter2 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry3 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter2);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable5 = jSTypeRegistry3.getEachReferenceTypeWithProperty("goog.global");
        com.google.javascript.rhino.jstype.JSType jSType6 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray7 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType8 = jSTypeRegistry3.createConstructorTypeWithVarArgs(jSType6, jSTypeArray7);
        com.google.javascript.rhino.JSDocInfo jSDocInfo9 = functionType8.getJSDocInfo();
        boolean boolean10 = functionType8.isAllType();
        com.google.javascript.rhino.ErrorReporter errorReporter11 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry12 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter11);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable14 = jSTypeRegistry12.getEachReferenceTypeWithProperty("goog.global");
        com.google.javascript.rhino.jstype.JSType jSType15 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray16 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType17 = jSTypeRegistry12.createConstructorTypeWithVarArgs(jSType15, jSTypeArray16);
        int int18 = functionType17.getMaxArguments();
        boolean boolean19 = functionType8.isSubtype((com.google.javascript.rhino.jstype.JSType) functionType17);
        com.google.javascript.rhino.ErrorReporter errorReporter21 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry22 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter21);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable24 = jSTypeRegistry22.getEachReferenceTypeWithProperty("goog.global");
        com.google.javascript.rhino.jstype.JSType jSType25 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray26 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType27 = jSTypeRegistry22.createConstructorTypeWithVarArgs(jSType25, jSTypeArray26);
        com.google.javascript.rhino.JSDocInfo jSDocInfo28 = functionType27.getJSDocInfo();
        boolean boolean29 = functionType27.isAllType();
        int int30 = functionType27.getMaxArguments();
        com.google.javascript.rhino.Node node31 = com.google.javascript.rhino.IR.trueNode();
        java.lang.String str32 = node31.getSourceFileName();
        boolean boolean33 = node31.isOr();
        boolean boolean34 = functionType17.defineInferredProperty("hi!", (com.google.javascript.rhino.jstype.JSType) functionType27, node31);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray36 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType37 = jSTypeRegistry1.createConstructorType((com.google.javascript.rhino.jstype.JSType) functionType27, false, jSTypeArray36);
        com.google.javascript.rhino.ErrorReporter errorReporter38 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry39 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter38);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable41 = jSTypeRegistry39.getEachReferenceTypeWithProperty("goog.global");
        com.google.javascript.rhino.jstype.JSType jSType42 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray43 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType44 = jSTypeRegistry39.createConstructorTypeWithVarArgs(jSType42, jSTypeArray43);
        com.google.javascript.rhino.JSDocInfo jSDocInfo45 = functionType44.getJSDocInfo();
        boolean boolean46 = functionType44.isAllType();
        com.google.javascript.rhino.ErrorReporter errorReporter47 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry48 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter47);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable50 = jSTypeRegistry48.getEachReferenceTypeWithProperty("goog.global");
        com.google.javascript.rhino.jstype.JSType jSType51 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray52 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType53 = jSTypeRegistry48.createConstructorTypeWithVarArgs(jSType51, jSTypeArray52);
        int int54 = functionType53.getMaxArguments();
        boolean boolean55 = functionType44.isSubtype((com.google.javascript.rhino.jstype.JSType) functionType53);
        java.io.PrintStream printStream56 = null;
        com.google.javascript.jscomp.Compiler compiler57 = new com.google.javascript.jscomp.Compiler(printStream56);
        com.google.javascript.jscomp.NodeTraversal.Callback callback58 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal59 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler57, callback58);
        boolean boolean60 = functionType44.equals((java.lang.Object) nodeTraversal59);
        com.google.javascript.rhino.jstype.JSType jSType61 = jSTypeRegistry1.createOptionalNullableType((com.google.javascript.rhino.jstype.JSType) functionType44);
        boolean boolean62 = jSType61.isFunctionType();
        boolean boolean63 = jSType61.isDateType();
        org.junit.Assert.assertNotNull(objectTypeIterable5);
        org.junit.Assert.assertNotNull(jSTypeArray7);
        org.junit.Assert.assertNotNull(functionType8);
        org.junit.Assert.assertNull(jSDocInfo9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(objectTypeIterable14);
        org.junit.Assert.assertNotNull(jSTypeArray16);
        org.junit.Assert.assertNotNull(functionType17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(objectTypeIterable24);
        org.junit.Assert.assertNotNull(jSTypeArray26);
        org.junit.Assert.assertNotNull(functionType27);
        org.junit.Assert.assertNull(jSDocInfo28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertNull(str32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertNotNull(jSTypeArray36);
        org.junit.Assert.assertNotNull(functionType37);
        org.junit.Assert.assertNotNull(objectTypeIterable41);
        org.junit.Assert.assertNotNull(jSTypeArray43);
        org.junit.Assert.assertNotNull(functionType44);
        org.junit.Assert.assertNull(jSDocInfo45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(objectTypeIterable50);
        org.junit.Assert.assertNotNull(jSTypeArray52);
        org.junit.Assert.assertNotNull(functionType53);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 0 + "'", int54 == 0);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + true + "'", boolean55 == true);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertNotNull(jSType61);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        com.google.javascript.jscomp.CompilerOptions compilerOptions4 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions4.computeFunctionSideEffects = true;
        boolean boolean7 = compilerOptions4.ideMode;
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention8 = new com.google.javascript.jscomp.GoogleCodingConvention();
        compilerOptions4.setCodingConvention((com.google.javascript.jscomp.CodingConvention) googleCodingConvention8);
        com.google.javascript.jscomp.CompilerOptions compilerOptions10 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions10.computeFunctionSideEffects = true;
        boolean boolean13 = compilerOptions10.isRemoveUnusedClassProperties();
        com.google.javascript.jscomp.ErrorHandler errorHandler14 = null;
        compilerOptions10.setErrorHandler(errorHandler14);
        java.util.List<com.google.javascript.jscomp.SourceMap.LocationMapping> locationMappingList16 = compilerOptions10.sourceMapLocationMappings;
        com.google.javascript.jscomp.CheckLevel checkLevel17 = com.google.javascript.jscomp.CheckLevel.ERROR;
        compilerOptions10.setCheckProvides(checkLevel17);
        compilerOptions4.setReportMissingOverride(checkLevel17);
        com.google.javascript.jscomp.DiagnosticType diagnosticType21 = com.google.javascript.jscomp.DiagnosticType.make("JSDocInfo", checkLevel17, "JSDocInfo");
        java.lang.String[] strArray27 = new java.lang.String[] { "./", "goog.global", "BLOCK", "BLOCK\n", "" };
        com.google.javascript.jscomp.JSError jSError28 = com.google.javascript.jscomp.JSError.make("Not declared as a constructor", 4, 0, diagnosticType21, strArray27);
        com.google.javascript.jscomp.DiagnosticType diagnosticType29 = null;
        try {
            int int30 = diagnosticType21.compareTo(diagnosticType29);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(locationMappingList16);
        org.junit.Assert.assertTrue("'" + checkLevel17 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel17.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticType21);
        org.junit.Assert.assertNotNull(strArray27);
        org.junit.Assert.assertNotNull(jSError28);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable3 = jSTypeRegistry1.getEachReferenceTypeWithProperty("goog.global");
        com.google.javascript.rhino.jstype.JSType jSType4 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray5 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType6 = jSTypeRegistry1.createConstructorTypeWithVarArgs(jSType4, jSTypeArray5);
        com.google.javascript.rhino.JSDocInfo jSDocInfo7 = functionType6.getJSDocInfo();
        boolean boolean8 = functionType6.isAllType();
        com.google.javascript.rhino.ErrorReporter errorReporter9 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry10 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter9);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable12 = jSTypeRegistry10.getEachReferenceTypeWithProperty("goog.global");
        com.google.javascript.rhino.jstype.JSType jSType13 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray14 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType15 = jSTypeRegistry10.createConstructorTypeWithVarArgs(jSType13, jSTypeArray14);
        int int16 = functionType15.getMaxArguments();
        boolean boolean17 = functionType6.isSubtype((com.google.javascript.rhino.jstype.JSType) functionType15);
        com.google.javascript.rhino.ErrorReporter errorReporter18 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry19 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter18);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable21 = jSTypeRegistry19.getEachReferenceTypeWithProperty("goog.global");
        com.google.javascript.rhino.jstype.JSType jSType22 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray23 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType24 = jSTypeRegistry19.createConstructorTypeWithVarArgs(jSType22, jSTypeArray23);
        com.google.javascript.rhino.JSDocInfo jSDocInfo25 = functionType24.getJSDocInfo();
        boolean boolean26 = functionType24.isAllType();
        com.google.javascript.rhino.ErrorReporter errorReporter27 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry28 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter27);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable30 = jSTypeRegistry28.getEachReferenceTypeWithProperty("goog.global");
        com.google.javascript.rhino.jstype.JSType jSType31 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray32 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType33 = jSTypeRegistry28.createConstructorTypeWithVarArgs(jSType31, jSTypeArray32);
        int int34 = functionType33.getMaxArguments();
        boolean boolean35 = functionType24.isSubtype((com.google.javascript.rhino.jstype.JSType) functionType33);
        com.google.javascript.rhino.ErrorReporter errorReporter37 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry38 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter37);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable40 = jSTypeRegistry38.getEachReferenceTypeWithProperty("goog.global");
        com.google.javascript.rhino.jstype.JSType jSType41 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray42 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType43 = jSTypeRegistry38.createConstructorTypeWithVarArgs(jSType41, jSTypeArray42);
        com.google.javascript.rhino.JSDocInfo jSDocInfo44 = functionType43.getJSDocInfo();
        boolean boolean45 = functionType43.isAllType();
        int int46 = functionType43.getMaxArguments();
        com.google.javascript.rhino.Node node47 = com.google.javascript.rhino.IR.trueNode();
        java.lang.String str48 = node47.getSourceFileName();
        boolean boolean49 = node47.isOr();
        boolean boolean50 = functionType33.defineInferredProperty("hi!", (com.google.javascript.rhino.jstype.JSType) functionType43, node47);
        boolean boolean51 = functionType6.canTestForEqualityWith((com.google.javascript.rhino.jstype.JSType) functionType33);
        java.lang.String str52 = functionType33.getReferenceName();
        boolean boolean53 = functionType33.isOrdinaryFunction();
        org.junit.Assert.assertNotNull(objectTypeIterable3);
        org.junit.Assert.assertNotNull(jSTypeArray5);
        org.junit.Assert.assertNotNull(functionType6);
        org.junit.Assert.assertNull(jSDocInfo7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(objectTypeIterable12);
        org.junit.Assert.assertNotNull(jSTypeArray14);
        org.junit.Assert.assertNotNull(functionType15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(objectTypeIterable21);
        org.junit.Assert.assertNotNull(jSTypeArray23);
        org.junit.Assert.assertNotNull(functionType24);
        org.junit.Assert.assertNull(jSDocInfo25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(objectTypeIterable30);
        org.junit.Assert.assertNotNull(jSTypeArray32);
        org.junit.Assert.assertNotNull(functionType33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertNotNull(objectTypeIterable40);
        org.junit.Assert.assertNotNull(jSTypeArray42);
        org.junit.Assert.assertNotNull(functionType43);
        org.junit.Assert.assertNull(jSDocInfo44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 0 + "'", int46 == 0);
        org.junit.Assert.assertNotNull(node47);
        org.junit.Assert.assertNull(str48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + true + "'", boolean50 == true);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + true + "'", boolean51 == true);
        org.junit.Assert.assertNull(str52);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.computeFunctionSideEffects = true;
        boolean boolean3 = compilerOptions0.isRemoveUnusedClassProperties();
        boolean boolean4 = compilerOptions0.isExternExportsEnabled();
        compilerOptions0.aliasKeywords = true;
        compilerOptions0.rewriteFunctionExpressions = false;
        boolean boolean9 = compilerOptions0.crossModuleMethodMotion;
        com.google.javascript.jscomp.CodingConvention codingConvention10 = compilerOptions0.getCodingConvention();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(codingConvention10);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable3 = jSTypeRegistry1.getEachReferenceTypeWithProperty("goog.global");
        com.google.javascript.rhino.jstype.JSType jSType4 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray5 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType6 = jSTypeRegistry1.createConstructorTypeWithVarArgs(jSType4, jSTypeArray5);
        com.google.javascript.rhino.ErrorReporter errorReporter7 = jSTypeRegistry1.getErrorReporter();
        com.google.javascript.rhino.ErrorReporter errorReporter8 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry9 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter8);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable11 = jSTypeRegistry9.getEachReferenceTypeWithProperty("goog.global");
        com.google.javascript.rhino.jstype.JSType jSType12 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray13 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType14 = jSTypeRegistry9.createConstructorTypeWithVarArgs(jSType12, jSTypeArray13);
        com.google.javascript.rhino.JSDocInfo jSDocInfo15 = functionType14.getJSDocInfo();
        com.google.javascript.rhino.ErrorReporter errorReporter16 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry17 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter16);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable19 = jSTypeRegistry17.getEachReferenceTypeWithProperty("goog.global");
        com.google.javascript.rhino.jstype.JSType jSType20 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray21 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType22 = jSTypeRegistry17.createConstructorTypeWithVarArgs(jSType20, jSTypeArray21);
        com.google.javascript.rhino.JSDocInfo jSDocInfo23 = functionType22.getJSDocInfo();
        boolean boolean24 = functionType22.isAllType();
        com.google.javascript.rhino.ErrorReporter errorReporter25 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry26 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter25);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable28 = jSTypeRegistry26.getEachReferenceTypeWithProperty("goog.global");
        com.google.javascript.rhino.jstype.JSType jSType29 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray30 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType31 = jSTypeRegistry26.createConstructorTypeWithVarArgs(jSType29, jSTypeArray30);
        int int32 = functionType31.getMaxArguments();
        boolean boolean33 = functionType22.isSubtype((com.google.javascript.rhino.jstype.JSType) functionType31);
        boolean boolean34 = functionType14.canTestForEqualityWith((com.google.javascript.rhino.jstype.JSType) functionType31);
        com.google.javascript.rhino.ErrorReporter errorReporter36 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry37 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter36);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable39 = jSTypeRegistry37.getEachReferenceTypeWithProperty("goog.global");
        com.google.javascript.rhino.jstype.JSType jSType40 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray41 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType42 = jSTypeRegistry37.createConstructorTypeWithVarArgs(jSType40, jSTypeArray41);
        com.google.javascript.rhino.jstype.FunctionType functionType43 = jSTypeRegistry1.createConstructorType((com.google.javascript.rhino.jstype.JSType) functionType14, true, jSTypeArray41);
        com.google.javascript.rhino.jstype.FunctionType functionType44 = functionType14.getSuperClassConstructor();
        boolean boolean45 = functionType14.isInstanceType();
        boolean boolean46 = functionType14.matchesObjectContext();
        org.junit.Assert.assertNotNull(objectTypeIterable3);
        org.junit.Assert.assertNotNull(jSTypeArray5);
        org.junit.Assert.assertNotNull(functionType6);
        org.junit.Assert.assertNull(errorReporter7);
        org.junit.Assert.assertNotNull(objectTypeIterable11);
        org.junit.Assert.assertNotNull(jSTypeArray13);
        org.junit.Assert.assertNotNull(functionType14);
        org.junit.Assert.assertNull(jSDocInfo15);
        org.junit.Assert.assertNotNull(objectTypeIterable19);
        org.junit.Assert.assertNotNull(jSTypeArray21);
        org.junit.Assert.assertNotNull(functionType22);
        org.junit.Assert.assertNull(jSDocInfo23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(objectTypeIterable28);
        org.junit.Assert.assertNotNull(jSTypeArray30);
        org.junit.Assert.assertNotNull(functionType31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertNotNull(objectTypeIterable39);
        org.junit.Assert.assertNotNull(jSTypeArray41);
        org.junit.Assert.assertNotNull(functionType42);
        org.junit.Assert.assertNotNull(functionType43);
        org.junit.Assert.assertNull(functionType44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        com.google.javascript.jscomp.SourceAst sourceAst0 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(sourceAst0, "JSDocInfo", false);
        com.google.javascript.jscomp.SourceAst sourceAst4 = compilerInput3.getSourceAst();
        com.google.javascript.jscomp.SourceFile sourceFile6 = com.google.javascript.jscomp.SourceFile.fromFile("./");
        java.lang.String str7 = sourceFile6.getOriginalPath();
        com.google.javascript.jscomp.JsAst jsAst8 = new com.google.javascript.jscomp.JsAst(sourceFile6);
        try {
            compilerInput3.setSourceFile(sourceFile6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(sourceAst4);
        org.junit.Assert.assertNotNull(sourceFile6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "." + "'", str7.equals("."));
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.computeFunctionSideEffects = true;
        boolean boolean3 = compilerOptions0.removeUnusedVars;
        java.lang.String str4 = compilerOptions0.renamePrefix;
        boolean boolean5 = compilerOptions0.removeDeadCode;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.computeFunctionSideEffects = true;
        boolean boolean3 = compilerOptions0.isRemoveUnusedClassProperties();
        com.google.javascript.jscomp.ErrorHandler errorHandler4 = null;
        compilerOptions0.setErrorHandler(errorHandler4);
        java.util.List<com.google.javascript.jscomp.SourceMap.LocationMapping> locationMappingList6 = compilerOptions0.sourceMapLocationMappings;
        com.google.javascript.jscomp.CheckLevel checkLevel7 = com.google.javascript.jscomp.CheckLevel.ERROR;
        compilerOptions0.setCheckProvides(checkLevel7);
        com.google.javascript.jscomp.CompilerOptions compilerOptions9 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions9.computeFunctionSideEffects = true;
        boolean boolean12 = compilerOptions9.isRemoveUnusedClassProperties();
        com.google.javascript.jscomp.ErrorHandler errorHandler13 = null;
        compilerOptions9.setErrorHandler(errorHandler13);
        java.util.List<com.google.javascript.jscomp.SourceMap.LocationMapping> locationMappingList15 = compilerOptions9.sourceMapLocationMappings;
        com.google.javascript.jscomp.CheckLevel checkLevel16 = com.google.javascript.jscomp.CheckLevel.ERROR;
        compilerOptions9.setCheckProvides(checkLevel16);
        compilerOptions0.reportMissingOverride = checkLevel16;
        boolean boolean19 = compilerOptions0.jqueryPass;
        com.google.javascript.jscomp.CheckLevel checkLevel20 = compilerOptions0.reportMissingOverride;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(locationMappingList6);
        org.junit.Assert.assertTrue("'" + checkLevel7 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel7.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(locationMappingList15);
        org.junit.Assert.assertTrue("'" + checkLevel16 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel16.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + checkLevel20 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel20.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.stringKey("");
        int int2 = node1.getLineno();
        node1.setLineno((-1));
        boolean boolean5 = node1.isAssignAdd();
        com.google.javascript.rhino.Node node6 = null;
        try {
            com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.IR.add(node1, node6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        com.google.javascript.rhino.JSDocInfo jSDocInfo0 = new com.google.javascript.rhino.JSDocInfo();
        java.util.List<com.google.javascript.rhino.JSTypeExpression> jSTypeExpressionList1 = jSDocInfo0.getImplementedInterfaces();
        java.util.Set<java.lang.String> strSet2 = jSDocInfo0.getSuppressions();
        boolean boolean3 = jSDocInfo0.isJavaDispatch();
        boolean boolean4 = jSDocInfo0.isInterface();
        boolean boolean5 = jSDocInfo0.isImplicitCast();
        org.junit.Assert.assertNotNull(jSTypeExpressionList1);
        org.junit.Assert.assertNotNull(strSet2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.NodeTraversal.Callback callback2 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal3 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler1, callback2);
        com.google.javascript.jscomp.Compiler.IntermediateState intermediateState4 = compiler1.getState();
        com.google.javascript.jscomp.Scope scope5 = compiler1.getTopScope();
        org.junit.Assert.assertNotNull(intermediateState4);
        org.junit.Assert.assertNull(scope5);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.continueNode();
        com.google.javascript.rhino.Node node4 = new com.google.javascript.rhino.Node(10, node1, 35, 0);
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.IR.block();
        java.lang.String str9 = node5.toString(false, false, false);
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.IR.stringKey("");
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable13 = node12.siblings();
        com.google.javascript.rhino.Node node16 = new com.google.javascript.rhino.Node((int) (short) 100, node12, (int) (short) 1, (int) (short) 10);
        com.google.javascript.rhino.Node node17 = node5.useSourceInfoIfMissingFrom(node16);
        boolean boolean18 = node1.isEquivalentTo(node17);
        boolean boolean19 = node1.isQuotedString();
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "BLOCK" + "'", str9.equals("BLOCK"));
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(nodeIterable13);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        com.google.javascript.rhino.JSDocInfo jSDocInfo0 = new com.google.javascript.rhino.JSDocInfo();
        boolean boolean1 = jSDocInfo0.isImplicitCast();
        boolean boolean2 = jSDocInfo0.isExterns();
        java.util.Collection<java.lang.String> strCollection3 = jSDocInfo0.getReferences();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(strCollection3);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.NUMBER_VALUE_OR_OBJECT_TYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.NUMBER_VALUE_OR_OBJECT_TYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.NUMBER_VALUE_OR_OBJECT_TYPE));
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newString("InputId: Not declared as a constructor");
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.IR.returnNode();
        boolean boolean3 = node2.isDefaultCase();
        try {
            com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.IR.tryFinally(node1, node2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        java.lang.String str1 = com.google.javascript.rhino.jstype.ObjectType.createDelegateSuffix("(BLOCK)");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "((BLOCK))" + "'", str1.equals("((BLOCK))"));
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeUnusedPrototypePropertiesInExterns = true;
        byte[] byteArray6 = new byte[] { (byte) 0, (byte) -1, (byte) 10 };
        compilerOptions0.inputPropertyMapSerialized = byteArray6;
        com.google.javascript.jscomp.CompilerOptions.TweakProcessing tweakProcessing8 = compilerOptions0.getTweakProcessing();
        compilerOptions0.setComputeFunctionSideEffects(false);
        compilerOptions0.setRenamePrefix("DiagnosticGroup<accessControls>(ERROR)");
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertTrue("'" + tweakProcessing8 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TweakProcessing.OFF + "'", tweakProcessing8.equals(com.google.javascript.jscomp.CompilerOptions.TweakProcessing.OFF));
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable3 = jSTypeRegistry1.getEachReferenceTypeWithProperty("goog.global");
        com.google.javascript.rhino.jstype.JSType jSType4 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray5 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType6 = jSTypeRegistry1.createConstructorTypeWithVarArgs(jSType4, jSTypeArray5);
        com.google.javascript.rhino.JSDocInfo jSDocInfo7 = functionType6.getJSDocInfo();
        boolean boolean8 = functionType6.isAllType();
        com.google.javascript.rhino.ErrorReporter errorReporter9 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry10 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter9);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable12 = jSTypeRegistry10.getEachReferenceTypeWithProperty("goog.global");
        com.google.javascript.rhino.jstype.JSType jSType13 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray14 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType15 = jSTypeRegistry10.createConstructorTypeWithVarArgs(jSType13, jSTypeArray14);
        int int16 = functionType15.getMaxArguments();
        boolean boolean17 = functionType6.isSubtype((com.google.javascript.rhino.jstype.JSType) functionType15);
        com.google.javascript.rhino.ErrorReporter errorReporter19 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry20 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter19);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable22 = jSTypeRegistry20.getEachReferenceTypeWithProperty("goog.global");
        com.google.javascript.rhino.jstype.JSType jSType23 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray24 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType25 = jSTypeRegistry20.createConstructorTypeWithVarArgs(jSType23, jSTypeArray24);
        com.google.javascript.rhino.JSDocInfo jSDocInfo26 = functionType25.getJSDocInfo();
        boolean boolean27 = functionType25.isAllType();
        int int28 = functionType25.getMaxArguments();
        com.google.javascript.rhino.Node node29 = com.google.javascript.rhino.IR.trueNode();
        java.lang.String str30 = node29.getSourceFileName();
        boolean boolean31 = node29.isOr();
        boolean boolean32 = functionType15.defineInferredProperty("hi!", (com.google.javascript.rhino.jstype.JSType) functionType25, node29);
        com.google.javascript.rhino.ErrorReporter errorReporter33 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry34 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter33);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable36 = jSTypeRegistry34.getEachReferenceTypeWithProperty("goog.global");
        com.google.javascript.rhino.jstype.JSType jSType37 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray38 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType39 = jSTypeRegistry34.createConstructorTypeWithVarArgs(jSType37, jSTypeArray38);
        com.google.javascript.rhino.JSDocInfo jSDocInfo40 = functionType39.getJSDocInfo();
        boolean boolean41 = functionType39.isAllType();
        int int42 = functionType39.getMaxArguments();
        com.google.javascript.rhino.Node node43 = functionType39.getParametersNode();
        boolean boolean44 = functionType15.differsFrom((com.google.javascript.rhino.jstype.JSType) functionType39);
        com.google.javascript.rhino.ErrorReporter errorReporter45 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry46 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter45);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable48 = jSTypeRegistry46.getEachReferenceTypeWithProperty("goog.global");
        com.google.javascript.rhino.jstype.JSType jSType49 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray50 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType51 = jSTypeRegistry46.createConstructorTypeWithVarArgs(jSType49, jSTypeArray50);
        com.google.javascript.rhino.JSDocInfo jSDocInfo52 = functionType51.getJSDocInfo();
        boolean boolean53 = functionType51.isAllType();
        com.google.javascript.rhino.ErrorReporter errorReporter54 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry55 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter54);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable57 = jSTypeRegistry55.getEachReferenceTypeWithProperty("goog.global");
        com.google.javascript.rhino.jstype.JSType jSType58 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray59 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType60 = jSTypeRegistry55.createConstructorTypeWithVarArgs(jSType58, jSTypeArray59);
        int int61 = functionType60.getMaxArguments();
        boolean boolean62 = functionType51.isSubtype((com.google.javascript.rhino.jstype.JSType) functionType60);
        com.google.javascript.rhino.jstype.JSType jSType63 = functionType51.collapseUnion();
        com.google.javascript.rhino.ErrorReporter errorReporter64 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry65 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter64);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable67 = jSTypeRegistry65.getEachReferenceTypeWithProperty("goog.global");
        com.google.javascript.rhino.jstype.JSType jSType68 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray69 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType70 = jSTypeRegistry65.createConstructorTypeWithVarArgs(jSType68, jSTypeArray69);
        com.google.javascript.rhino.JSDocInfo jSDocInfo71 = functionType70.getJSDocInfo();
        boolean boolean72 = functionType70.isAllType();
        com.google.javascript.rhino.ErrorReporter errorReporter73 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry74 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter73);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable76 = jSTypeRegistry74.getEachReferenceTypeWithProperty("goog.global");
        com.google.javascript.rhino.jstype.JSType jSType77 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray78 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType79 = jSTypeRegistry74.createConstructorTypeWithVarArgs(jSType77, jSTypeArray78);
        int int80 = functionType79.getMaxArguments();
        boolean boolean81 = functionType70.isSubtype((com.google.javascript.rhino.jstype.JSType) functionType79);
        com.google.javascript.rhino.ErrorReporter errorReporter83 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry84 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter83);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable86 = jSTypeRegistry84.getEachReferenceTypeWithProperty("goog.global");
        com.google.javascript.rhino.jstype.JSType jSType87 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray88 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType89 = jSTypeRegistry84.createConstructorTypeWithVarArgs(jSType87, jSTypeArray88);
        com.google.javascript.rhino.JSDocInfo jSDocInfo90 = functionType89.getJSDocInfo();
        boolean boolean91 = functionType89.isAllType();
        int int92 = functionType89.getMaxArguments();
        com.google.javascript.rhino.Node node93 = com.google.javascript.rhino.IR.trueNode();
        java.lang.String str94 = node93.getSourceFileName();
        boolean boolean95 = node93.isOr();
        boolean boolean96 = functionType79.defineInferredProperty("hi!", (com.google.javascript.rhino.jstype.JSType) functionType89, node93);
        boolean boolean97 = functionType51.isSubtype((com.google.javascript.rhino.jstype.JSType) functionType89);
        boolean boolean98 = com.google.javascript.rhino.jstype.JSType.isEquivalent((com.google.javascript.rhino.jstype.JSType) functionType39, (com.google.javascript.rhino.jstype.JSType) functionType89);
        org.junit.Assert.assertNotNull(objectTypeIterable3);
        org.junit.Assert.assertNotNull(jSTypeArray5);
        org.junit.Assert.assertNotNull(functionType6);
        org.junit.Assert.assertNull(jSDocInfo7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(objectTypeIterable12);
        org.junit.Assert.assertNotNull(jSTypeArray14);
        org.junit.Assert.assertNotNull(functionType15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(objectTypeIterable22);
        org.junit.Assert.assertNotNull(jSTypeArray24);
        org.junit.Assert.assertNotNull(functionType25);
        org.junit.Assert.assertNull(jSDocInfo26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNull(str30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNotNull(objectTypeIterable36);
        org.junit.Assert.assertNotNull(jSTypeArray38);
        org.junit.Assert.assertNotNull(functionType39);
        org.junit.Assert.assertNull(jSDocInfo40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
        org.junit.Assert.assertNotNull(node43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
        org.junit.Assert.assertNotNull(objectTypeIterable48);
        org.junit.Assert.assertNotNull(jSTypeArray50);
        org.junit.Assert.assertNotNull(functionType51);
        org.junit.Assert.assertNull(jSDocInfo52);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNotNull(objectTypeIterable57);
        org.junit.Assert.assertNotNull(jSTypeArray59);
        org.junit.Assert.assertNotNull(functionType60);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 0 + "'", int61 == 0);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + true + "'", boolean62 == true);
        org.junit.Assert.assertNotNull(jSType63);
        org.junit.Assert.assertNotNull(objectTypeIterable67);
        org.junit.Assert.assertNotNull(jSTypeArray69);
        org.junit.Assert.assertNotNull(functionType70);
        org.junit.Assert.assertNull(jSDocInfo71);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
        org.junit.Assert.assertNotNull(objectTypeIterable76);
        org.junit.Assert.assertNotNull(jSTypeArray78);
        org.junit.Assert.assertNotNull(functionType79);
        org.junit.Assert.assertTrue("'" + int80 + "' != '" + 0 + "'", int80 == 0);
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + true + "'", boolean81 == true);
        org.junit.Assert.assertNotNull(objectTypeIterable86);
        org.junit.Assert.assertNotNull(jSTypeArray88);
        org.junit.Assert.assertNotNull(functionType89);
        org.junit.Assert.assertNull(jSDocInfo90);
        org.junit.Assert.assertTrue("'" + boolean91 + "' != '" + false + "'", boolean91 == false);
        org.junit.Assert.assertTrue("'" + int92 + "' != '" + 0 + "'", int92 == 0);
        org.junit.Assert.assertNotNull(node93);
        org.junit.Assert.assertNull(str94);
        org.junit.Assert.assertTrue("'" + boolean95 + "' != '" + false + "'", boolean95 == false);
        org.junit.Assert.assertTrue("'" + boolean96 + "' != '" + true + "'", boolean96 == true);
        org.junit.Assert.assertTrue("'" + boolean97 + "' != '" + true + "'", boolean97 == true);
        org.junit.Assert.assertTrue("'" + boolean98 + "' != '" + false + "'", boolean98 == false);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.computeFunctionSideEffects = true;
        boolean boolean3 = compilerOptions0.removeUnusedVars;
        java.lang.String[] strArray15 = new java.lang.String[] { "InputId: Not declared as a constructor", ".", "BLOCK", "InputId: Not declared as a constructor", "Not declared as a constructor", "module$hi!", ".", "JSDocInfo", "module$hi!", ".", "hi!" };
        java.util.LinkedHashSet<java.lang.String> strSet16 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean17 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet16, strArray15);
        compilerOptions0.setIdGenerators((java.util.Set<java.lang.String>) strSet16);
        compilerOptions0.setReserveRawExports(true);
        compilerOptions0.setRuntimeTypeCheck(false);
        compilerOptions0.setCheckSymbols(false);
        compilerOptions0.setLooseTypes(true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(strArray15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable3 = jSTypeRegistry1.getEachReferenceTypeWithProperty("goog.global");
        com.google.javascript.rhino.jstype.JSType jSType4 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray5 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType6 = jSTypeRegistry1.createConstructorTypeWithVarArgs(jSType4, jSTypeArray5);
        com.google.javascript.rhino.JSDocInfo jSDocInfo7 = functionType6.getJSDocInfo();
        boolean boolean8 = functionType6.isAllType();
        com.google.javascript.rhino.ErrorReporter errorReporter9 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry10 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter9);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable12 = jSTypeRegistry10.getEachReferenceTypeWithProperty("goog.global");
        com.google.javascript.rhino.jstype.JSType jSType13 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray14 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType15 = jSTypeRegistry10.createConstructorTypeWithVarArgs(jSType13, jSTypeArray14);
        int int16 = functionType15.getMaxArguments();
        boolean boolean17 = functionType6.isSubtype((com.google.javascript.rhino.jstype.JSType) functionType15);
        com.google.javascript.rhino.ErrorReporter errorReporter18 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry19 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter18);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable21 = jSTypeRegistry19.getEachReferenceTypeWithProperty("goog.global");
        com.google.javascript.rhino.jstype.JSType jSType22 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray23 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType24 = jSTypeRegistry19.createConstructorTypeWithVarArgs(jSType22, jSTypeArray23);
        com.google.javascript.rhino.JSDocInfo jSDocInfo25 = functionType24.getJSDocInfo();
        boolean boolean26 = functionType24.isAllType();
        com.google.javascript.rhino.ErrorReporter errorReporter27 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry28 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter27);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable30 = jSTypeRegistry28.getEachReferenceTypeWithProperty("goog.global");
        com.google.javascript.rhino.jstype.JSType jSType31 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray32 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType33 = jSTypeRegistry28.createConstructorTypeWithVarArgs(jSType31, jSTypeArray32);
        int int34 = functionType33.getMaxArguments();
        boolean boolean35 = functionType24.isSubtype((com.google.javascript.rhino.jstype.JSType) functionType33);
        com.google.javascript.rhino.ErrorReporter errorReporter37 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry38 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter37);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable40 = jSTypeRegistry38.getEachReferenceTypeWithProperty("goog.global");
        com.google.javascript.rhino.jstype.JSType jSType41 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray42 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType43 = jSTypeRegistry38.createConstructorTypeWithVarArgs(jSType41, jSTypeArray42);
        com.google.javascript.rhino.JSDocInfo jSDocInfo44 = functionType43.getJSDocInfo();
        boolean boolean45 = functionType43.isAllType();
        int int46 = functionType43.getMaxArguments();
        com.google.javascript.rhino.Node node47 = com.google.javascript.rhino.IR.trueNode();
        java.lang.String str48 = node47.getSourceFileName();
        boolean boolean49 = node47.isOr();
        boolean boolean50 = functionType33.defineInferredProperty("hi!", (com.google.javascript.rhino.jstype.JSType) functionType43, node47);
        boolean boolean51 = functionType6.canTestForEqualityWith((com.google.javascript.rhino.jstype.JSType) functionType33);
        boolean boolean52 = functionType6.isUnknownType();
        com.google.javascript.rhino.ErrorReporter errorReporter53 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry54 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter53);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable56 = jSTypeRegistry54.getEachReferenceTypeWithProperty("goog.global");
        com.google.javascript.rhino.jstype.JSType jSType57 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray58 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType59 = jSTypeRegistry54.createConstructorTypeWithVarArgs(jSType57, jSTypeArray58);
        com.google.javascript.rhino.JSDocInfo jSDocInfo60 = functionType59.getJSDocInfo();
        boolean boolean61 = functionType59.isAllType();
        com.google.javascript.rhino.ErrorReporter errorReporter62 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry63 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter62);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable65 = jSTypeRegistry63.getEachReferenceTypeWithProperty("goog.global");
        com.google.javascript.rhino.jstype.JSType jSType66 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray67 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType68 = jSTypeRegistry63.createConstructorTypeWithVarArgs(jSType66, jSTypeArray67);
        int int69 = functionType68.getMaxArguments();
        boolean boolean70 = functionType59.isSubtype((com.google.javascript.rhino.jstype.JSType) functionType68);
        com.google.javascript.rhino.ErrorReporter errorReporter72 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry73 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter72);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable75 = jSTypeRegistry73.getEachReferenceTypeWithProperty("goog.global");
        com.google.javascript.rhino.jstype.JSType jSType76 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray77 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType78 = jSTypeRegistry73.createConstructorTypeWithVarArgs(jSType76, jSTypeArray77);
        com.google.javascript.rhino.JSDocInfo jSDocInfo79 = functionType78.getJSDocInfo();
        boolean boolean80 = functionType78.isAllType();
        int int81 = functionType78.getMaxArguments();
        com.google.javascript.rhino.Node node82 = com.google.javascript.rhino.IR.trueNode();
        java.lang.String str83 = node82.getSourceFileName();
        boolean boolean84 = node82.isOr();
        boolean boolean85 = functionType68.defineInferredProperty("hi!", (com.google.javascript.rhino.jstype.JSType) functionType78, node82);
        com.google.javascript.rhino.jstype.JSType jSType86 = functionType6.getLeastSupertype((com.google.javascript.rhino.jstype.JSType) functionType78);
        com.google.javascript.rhino.jstype.FunctionType functionType87 = functionType78.getSuperClassConstructor();
        boolean boolean88 = functionType78.isEnumType();
        org.junit.Assert.assertNotNull(objectTypeIterable3);
        org.junit.Assert.assertNotNull(jSTypeArray5);
        org.junit.Assert.assertNotNull(functionType6);
        org.junit.Assert.assertNull(jSDocInfo7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(objectTypeIterable12);
        org.junit.Assert.assertNotNull(jSTypeArray14);
        org.junit.Assert.assertNotNull(functionType15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(objectTypeIterable21);
        org.junit.Assert.assertNotNull(jSTypeArray23);
        org.junit.Assert.assertNotNull(functionType24);
        org.junit.Assert.assertNull(jSDocInfo25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(objectTypeIterable30);
        org.junit.Assert.assertNotNull(jSTypeArray32);
        org.junit.Assert.assertNotNull(functionType33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertNotNull(objectTypeIterable40);
        org.junit.Assert.assertNotNull(jSTypeArray42);
        org.junit.Assert.assertNotNull(functionType43);
        org.junit.Assert.assertNull(jSDocInfo44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 0 + "'", int46 == 0);
        org.junit.Assert.assertNotNull(node47);
        org.junit.Assert.assertNull(str48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + true + "'", boolean50 == true);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + true + "'", boolean51 == true);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertNotNull(objectTypeIterable56);
        org.junit.Assert.assertNotNull(jSTypeArray58);
        org.junit.Assert.assertNotNull(functionType59);
        org.junit.Assert.assertNull(jSDocInfo60);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertNotNull(objectTypeIterable65);
        org.junit.Assert.assertNotNull(jSTypeArray67);
        org.junit.Assert.assertNotNull(functionType68);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 0 + "'", int69 == 0);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + true + "'", boolean70 == true);
        org.junit.Assert.assertNotNull(objectTypeIterable75);
        org.junit.Assert.assertNotNull(jSTypeArray77);
        org.junit.Assert.assertNotNull(functionType78);
        org.junit.Assert.assertNull(jSDocInfo79);
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + false + "'", boolean80 == false);
        org.junit.Assert.assertTrue("'" + int81 + "' != '" + 0 + "'", int81 == 0);
        org.junit.Assert.assertNotNull(node82);
        org.junit.Assert.assertNull(str83);
        org.junit.Assert.assertTrue("'" + boolean84 + "' != '" + false + "'", boolean84 == false);
        org.junit.Assert.assertTrue("'" + boolean85 + "' != '" + true + "'", boolean85 == true);
        org.junit.Assert.assertNotNull(jSType86);
        org.junit.Assert.assertNull(functionType87);
        org.junit.Assert.assertTrue("'" + boolean88 + "' != '" + false + "'", boolean88 == false);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeUnusedPrototypePropertiesInExterns = true;
        compilerOptions0.setColorizeErrorOutput(true);
        boolean boolean5 = compilerOptions0.ambiguateProperties;
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.IR.stringKey("");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.IR.stringKey("");
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.IR.block();
        com.google.javascript.rhino.Node node8 = new com.google.javascript.rhino.Node((int) ' ', node2, node4, node5, 0, (int) (short) -1);
        boolean boolean9 = node2.isThrow();
        boolean boolean10 = node2.isTry();
        boolean boolean11 = node2.isIn();
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.IR.stringKey("goog.global");
        com.google.javascript.rhino.Node node14 = node2.copyInformationFromForTree(node13);
        try {
            com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.IR.pos(node2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(node14);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.computeFunctionSideEffects = true;
        boolean boolean3 = compilerOptions0.isRemoveUnusedClassProperties();
        com.google.javascript.jscomp.ErrorHandler errorHandler4 = null;
        compilerOptions0.setErrorHandler(errorHandler4);
        boolean boolean6 = compilerOptions0.checkSuspiciousCode;
        boolean boolean7 = compilerOptions0.removeUnusedPrototypeProperties;
        com.google.javascript.jscomp.MessageBundle messageBundle8 = null;
        compilerOptions0.messageBundle = messageBundle8;
        compilerOptions0.setDebugFunctionSideEffectsPath("goog.global");
        compilerOptions0.setPrintInputDelimiter(false);
        boolean boolean14 = compilerOptions0.checkControlStructures;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable3 = jSTypeRegistry1.getEachReferenceTypeWithProperty("goog.global");
        com.google.javascript.rhino.jstype.JSType jSType4 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray5 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType6 = jSTypeRegistry1.createConstructorTypeWithVarArgs(jSType4, jSTypeArray5);
        com.google.javascript.rhino.JSDocInfo jSDocInfo7 = functionType6.getJSDocInfo();
        boolean boolean8 = functionType6.isAllType();
        int int9 = functionType6.getMaxArguments();
        boolean boolean10 = functionType6.hasCachedValues();
        com.google.javascript.jscomp.CompilerOptions compilerOptions11 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions11.computeFunctionSideEffects = true;
        boolean boolean14 = compilerOptions11.isRemoveUnusedClassProperties();
        com.google.javascript.jscomp.ErrorHandler errorHandler15 = null;
        compilerOptions11.setErrorHandler(errorHandler15);
        java.util.List<com.google.javascript.jscomp.SourceMap.LocationMapping> locationMappingList17 = compilerOptions11.sourceMapLocationMappings;
        com.google.javascript.jscomp.CheckLevel checkLevel18 = com.google.javascript.jscomp.CheckLevel.ERROR;
        compilerOptions11.setCheckProvides(checkLevel18);
        boolean boolean20 = functionType6.equals((java.lang.Object) checkLevel18);
        java.util.Set<java.lang.String> strSet21 = functionType6.getPropertyNames();
        org.junit.Assert.assertNotNull(objectTypeIterable3);
        org.junit.Assert.assertNotNull(jSTypeArray5);
        org.junit.Assert.assertNotNull(functionType6);
        org.junit.Assert.assertNull(jSDocInfo7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(locationMappingList17);
        org.junit.Assert.assertTrue("'" + checkLevel18 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel18.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(strSet21);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.stringKey("");
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable2 = node1.siblings();
        boolean boolean3 = node1.isQualifiedName();
        node1.setString("");
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.IR.stringKey("");
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.IR.stringKey("");
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.IR.block();
        com.google.javascript.rhino.Node node14 = new com.google.javascript.rhino.Node((int) ' ', node8, node10, node11, 0, (int) (short) -1);
        boolean boolean15 = node8.isThrow();
        boolean boolean16 = node8.isStringKey();
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.IR.block();
        com.google.javascript.rhino.Node node18 = node8.useSourceInfoIfMissingFrom(node17);
        com.google.javascript.rhino.Node node19 = node1.copyInformationFromForTree(node18);
        com.google.javascript.rhino.InputId inputId20 = com.google.javascript.jscomp.NodeUtil.getInputId(node19);
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertNotNull(nodeIterable2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNull(inputId20);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.stringKey("");
        com.google.javascript.rhino.Node node2 = null;
        int int3 = node1.getIndexOfChild(node2);
        try {
            com.google.javascript.rhino.Node node4 = com.google.javascript.jscomp.NodeUtil.getFunctionParameters(node1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.computeFunctionSideEffects = true;
        boolean boolean3 = compilerOptions0.isRemoveUnusedClassProperties();
        com.google.javascript.jscomp.ErrorHandler errorHandler4 = null;
        compilerOptions0.setErrorHandler(errorHandler4);
        com.google.javascript.jscomp.CompilerOptions.AliasTransformationHandler aliasTransformationHandler6 = null;
        compilerOptions0.setAliasTransformationHandler(aliasTransformationHandler6);
        compilerOptions0.aliasKeywords = false;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        com.google.javascript.rhino.JSDocInfo jSDocInfo0 = new com.google.javascript.rhino.JSDocInfo();
        boolean boolean1 = jSDocInfo0.isExterns();
        java.lang.String str2 = jSDocInfo0.getOriginalCommentString();
        java.util.List<com.google.javascript.rhino.JSTypeExpression> jSTypeExpressionList3 = jSDocInfo0.getExtendedInterfaces();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNotNull(jSTypeExpressionList3);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.ACCESS_CONTROLS;
        com.google.javascript.jscomp.DiagnosticGroups.INTERNET_EXPLORER_CHECKS = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticGroups.CHECK_PROVIDES = diagnosticGroup0;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        com.google.javascript.rhino.jstype.JSTypeRegistry.ResolveMode resolveMode0 = com.google.javascript.rhino.jstype.JSTypeRegistry.ResolveMode.LAZY_NAMES;
        org.junit.Assert.assertTrue("'" + resolveMode0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeRegistry.ResolveMode.LAZY_NAMES + "'", resolveMode0.equals(com.google.javascript.rhino.jstype.JSTypeRegistry.ResolveMode.LAZY_NAMES));
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable3 = jSTypeRegistry1.getEachReferenceTypeWithProperty("goog.global");
        com.google.javascript.rhino.jstype.JSType jSType4 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray5 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType6 = jSTypeRegistry1.createConstructorTypeWithVarArgs(jSType4, jSTypeArray5);
        com.google.javascript.rhino.JSDocInfo jSDocInfo7 = functionType6.getJSDocInfo();
        boolean boolean8 = functionType6.isAllType();
        com.google.javascript.rhino.ErrorReporter errorReporter9 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry10 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter9);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable12 = jSTypeRegistry10.getEachReferenceTypeWithProperty("goog.global");
        com.google.javascript.rhino.jstype.JSType jSType13 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray14 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType15 = jSTypeRegistry10.createConstructorTypeWithVarArgs(jSType13, jSTypeArray14);
        int int16 = functionType15.getMaxArguments();
        boolean boolean17 = functionType6.isSubtype((com.google.javascript.rhino.jstype.JSType) functionType15);
        com.google.javascript.rhino.ErrorReporter errorReporter18 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry19 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter18);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable21 = jSTypeRegistry19.getEachReferenceTypeWithProperty("goog.global");
        com.google.javascript.rhino.jstype.JSType jSType22 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray23 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType24 = jSTypeRegistry19.createConstructorTypeWithVarArgs(jSType22, jSTypeArray23);
        com.google.javascript.rhino.JSDocInfo jSDocInfo25 = functionType24.getJSDocInfo();
        boolean boolean26 = functionType24.isAllType();
        com.google.javascript.rhino.ErrorReporter errorReporter27 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry28 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter27);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable30 = jSTypeRegistry28.getEachReferenceTypeWithProperty("goog.global");
        com.google.javascript.rhino.jstype.JSType jSType31 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray32 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType33 = jSTypeRegistry28.createConstructorTypeWithVarArgs(jSType31, jSTypeArray32);
        int int34 = functionType33.getMaxArguments();
        boolean boolean35 = functionType24.isSubtype((com.google.javascript.rhino.jstype.JSType) functionType33);
        com.google.javascript.rhino.ErrorReporter errorReporter37 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry38 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter37);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable40 = jSTypeRegistry38.getEachReferenceTypeWithProperty("goog.global");
        com.google.javascript.rhino.jstype.JSType jSType41 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray42 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType43 = jSTypeRegistry38.createConstructorTypeWithVarArgs(jSType41, jSTypeArray42);
        com.google.javascript.rhino.JSDocInfo jSDocInfo44 = functionType43.getJSDocInfo();
        boolean boolean45 = functionType43.isAllType();
        int int46 = functionType43.getMaxArguments();
        com.google.javascript.rhino.Node node47 = com.google.javascript.rhino.IR.trueNode();
        java.lang.String str48 = node47.getSourceFileName();
        boolean boolean49 = node47.isOr();
        boolean boolean50 = functionType33.defineInferredProperty("hi!", (com.google.javascript.rhino.jstype.JSType) functionType43, node47);
        boolean boolean51 = functionType6.canTestForEqualityWith((com.google.javascript.rhino.jstype.JSType) functionType33);
        boolean boolean52 = functionType6.isUnknownType();
        com.google.javascript.rhino.ErrorReporter errorReporter53 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry54 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter53);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable56 = jSTypeRegistry54.getEachReferenceTypeWithProperty("goog.global");
        com.google.javascript.rhino.jstype.JSType jSType57 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray58 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType59 = jSTypeRegistry54.createConstructorTypeWithVarArgs(jSType57, jSTypeArray58);
        com.google.javascript.rhino.JSDocInfo jSDocInfo60 = functionType59.getJSDocInfo();
        boolean boolean61 = functionType59.isAllType();
        com.google.javascript.rhino.ErrorReporter errorReporter62 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry63 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter62);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable65 = jSTypeRegistry63.getEachReferenceTypeWithProperty("goog.global");
        com.google.javascript.rhino.jstype.JSType jSType66 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray67 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType68 = jSTypeRegistry63.createConstructorTypeWithVarArgs(jSType66, jSTypeArray67);
        int int69 = functionType68.getMaxArguments();
        boolean boolean70 = functionType59.isSubtype((com.google.javascript.rhino.jstype.JSType) functionType68);
        com.google.javascript.rhino.ErrorReporter errorReporter72 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry73 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter72);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable75 = jSTypeRegistry73.getEachReferenceTypeWithProperty("goog.global");
        com.google.javascript.rhino.jstype.JSType jSType76 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray77 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType78 = jSTypeRegistry73.createConstructorTypeWithVarArgs(jSType76, jSTypeArray77);
        com.google.javascript.rhino.JSDocInfo jSDocInfo79 = functionType78.getJSDocInfo();
        boolean boolean80 = functionType78.isAllType();
        int int81 = functionType78.getMaxArguments();
        com.google.javascript.rhino.Node node82 = com.google.javascript.rhino.IR.trueNode();
        java.lang.String str83 = node82.getSourceFileName();
        boolean boolean84 = node82.isOr();
        boolean boolean85 = functionType68.defineInferredProperty("hi!", (com.google.javascript.rhino.jstype.JSType) functionType78, node82);
        com.google.javascript.rhino.jstype.JSType jSType86 = functionType6.getLeastSupertype((com.google.javascript.rhino.jstype.JSType) functionType78);
        boolean boolean87 = functionType6.hasCachedValues();
        org.junit.Assert.assertNotNull(objectTypeIterable3);
        org.junit.Assert.assertNotNull(jSTypeArray5);
        org.junit.Assert.assertNotNull(functionType6);
        org.junit.Assert.assertNull(jSDocInfo7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(objectTypeIterable12);
        org.junit.Assert.assertNotNull(jSTypeArray14);
        org.junit.Assert.assertNotNull(functionType15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(objectTypeIterable21);
        org.junit.Assert.assertNotNull(jSTypeArray23);
        org.junit.Assert.assertNotNull(functionType24);
        org.junit.Assert.assertNull(jSDocInfo25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(objectTypeIterable30);
        org.junit.Assert.assertNotNull(jSTypeArray32);
        org.junit.Assert.assertNotNull(functionType33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertNotNull(objectTypeIterable40);
        org.junit.Assert.assertNotNull(jSTypeArray42);
        org.junit.Assert.assertNotNull(functionType43);
        org.junit.Assert.assertNull(jSDocInfo44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 0 + "'", int46 == 0);
        org.junit.Assert.assertNotNull(node47);
        org.junit.Assert.assertNull(str48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + true + "'", boolean50 == true);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + true + "'", boolean51 == true);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertNotNull(objectTypeIterable56);
        org.junit.Assert.assertNotNull(jSTypeArray58);
        org.junit.Assert.assertNotNull(functionType59);
        org.junit.Assert.assertNull(jSDocInfo60);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertNotNull(objectTypeIterable65);
        org.junit.Assert.assertNotNull(jSTypeArray67);
        org.junit.Assert.assertNotNull(functionType68);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 0 + "'", int69 == 0);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + true + "'", boolean70 == true);
        org.junit.Assert.assertNotNull(objectTypeIterable75);
        org.junit.Assert.assertNotNull(jSTypeArray77);
        org.junit.Assert.assertNotNull(functionType78);
        org.junit.Assert.assertNull(jSDocInfo79);
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + false + "'", boolean80 == false);
        org.junit.Assert.assertTrue("'" + int81 + "' != '" + 0 + "'", int81 == 0);
        org.junit.Assert.assertNotNull(node82);
        org.junit.Assert.assertNull(str83);
        org.junit.Assert.assertTrue("'" + boolean84 + "' != '" + false + "'", boolean84 == false);
        org.junit.Assert.assertTrue("'" + boolean85 + "' != '" + true + "'", boolean85 == true);
        org.junit.Assert.assertNotNull(jSType86);
        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + true + "'", boolean87 == true);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeUnusedPrototypePropertiesInExterns = true;
        byte[] byteArray6 = new byte[] { (byte) 0, (byte) -1, (byte) 10 };
        compilerOptions0.inputPropertyMapSerialized = byteArray6;
        compilerOptions0.setCheckControlStructures(false);
        boolean boolean10 = compilerOptions0.inlineGetters;
        boolean boolean11 = compilerOptions0.convertToDottedProperties;
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        com.google.javascript.rhino.JSDocInfo jSDocInfo0 = new com.google.javascript.rhino.JSDocInfo();
        boolean boolean2 = jSDocInfo0.hasDescriptionForParameter("");
        java.lang.String str3 = jSDocInfo0.toString();
        boolean boolean4 = jSDocInfo0.isIdGenerator();
        com.google.common.collect.ImmutableList<java.lang.String> strList5 = jSDocInfo0.getTemplateTypeNames();
        com.google.javascript.rhino.JSDocInfo.Visibility visibility6 = null;
        jSDocInfo0.setVisibility(visibility6);
        com.google.javascript.rhino.JSTypeExpression jSTypeExpression9 = jSDocInfo0.getParameterType("module$hi!");
        com.google.javascript.rhino.JSTypeExpression jSTypeExpression10 = jSDocInfo0.getReturnType();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "JSDocInfo" + "'", str3.equals("JSDocInfo"));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(strList5);
        org.junit.Assert.assertNull(jSTypeExpression9);
        org.junit.Assert.assertNull(jSTypeExpression10);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        com.google.javascript.rhino.ErrorReporter errorReporter2 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry3 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter2);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable5 = jSTypeRegistry3.getEachReferenceTypeWithProperty("goog.global");
        com.google.javascript.rhino.jstype.JSType jSType6 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray7 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType8 = jSTypeRegistry3.createConstructorTypeWithVarArgs(jSType6, jSTypeArray7);
        com.google.javascript.rhino.JSDocInfo jSDocInfo9 = functionType8.getJSDocInfo();
        boolean boolean10 = functionType8.isAllType();
        com.google.javascript.rhino.ErrorReporter errorReporter11 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry12 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter11);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable14 = jSTypeRegistry12.getEachReferenceTypeWithProperty("goog.global");
        com.google.javascript.rhino.jstype.JSType jSType15 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray16 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType17 = jSTypeRegistry12.createConstructorTypeWithVarArgs(jSType15, jSTypeArray16);
        int int18 = functionType17.getMaxArguments();
        boolean boolean19 = functionType8.isSubtype((com.google.javascript.rhino.jstype.JSType) functionType17);
        com.google.javascript.rhino.ErrorReporter errorReporter21 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry22 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter21);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable24 = jSTypeRegistry22.getEachReferenceTypeWithProperty("goog.global");
        com.google.javascript.rhino.jstype.JSType jSType25 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray26 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType27 = jSTypeRegistry22.createConstructorTypeWithVarArgs(jSType25, jSTypeArray26);
        com.google.javascript.rhino.JSDocInfo jSDocInfo28 = functionType27.getJSDocInfo();
        boolean boolean29 = functionType27.isAllType();
        int int30 = functionType27.getMaxArguments();
        com.google.javascript.rhino.Node node31 = com.google.javascript.rhino.IR.trueNode();
        java.lang.String str32 = node31.getSourceFileName();
        boolean boolean33 = node31.isOr();
        boolean boolean34 = functionType17.defineInferredProperty("hi!", (com.google.javascript.rhino.jstype.JSType) functionType27, node31);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray36 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType37 = jSTypeRegistry1.createConstructorType((com.google.javascript.rhino.jstype.JSType) functionType27, false, jSTypeArray36);
        com.google.javascript.rhino.ErrorReporter errorReporter38 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry39 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter38);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable41 = jSTypeRegistry39.getEachReferenceTypeWithProperty("goog.global");
        com.google.javascript.rhino.jstype.JSType jSType42 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray43 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType44 = jSTypeRegistry39.createConstructorTypeWithVarArgs(jSType42, jSTypeArray43);
        com.google.javascript.rhino.JSDocInfo jSDocInfo45 = functionType44.getJSDocInfo();
        boolean boolean46 = functionType44.isAllType();
        com.google.javascript.rhino.ErrorReporter errorReporter47 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry48 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter47);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable50 = jSTypeRegistry48.getEachReferenceTypeWithProperty("goog.global");
        com.google.javascript.rhino.jstype.JSType jSType51 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray52 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType53 = jSTypeRegistry48.createConstructorTypeWithVarArgs(jSType51, jSTypeArray52);
        int int54 = functionType53.getMaxArguments();
        boolean boolean55 = functionType44.isSubtype((com.google.javascript.rhino.jstype.JSType) functionType53);
        java.io.PrintStream printStream56 = null;
        com.google.javascript.jscomp.Compiler compiler57 = new com.google.javascript.jscomp.Compiler(printStream56);
        com.google.javascript.jscomp.NodeTraversal.Callback callback58 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal59 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler57, callback58);
        boolean boolean60 = functionType44.equals((java.lang.Object) nodeTraversal59);
        com.google.javascript.rhino.jstype.JSType jSType61 = jSTypeRegistry1.createOptionalNullableType((com.google.javascript.rhino.jstype.JSType) functionType44);
        com.google.javascript.rhino.ErrorReporter errorReporter62 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry63 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter62);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable65 = jSTypeRegistry63.getEachReferenceTypeWithProperty("goog.global");
        com.google.javascript.rhino.jstype.JSType jSType66 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray67 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType68 = jSTypeRegistry63.createConstructorTypeWithVarArgs(jSType66, jSTypeArray67);
        com.google.javascript.rhino.JSDocInfo jSDocInfo69 = functionType68.getJSDocInfo();
        com.google.javascript.rhino.Node node72 = com.google.javascript.rhino.IR.stringKey("");
        com.google.javascript.rhino.Node node74 = com.google.javascript.rhino.IR.stringKey("");
        com.google.javascript.rhino.Node node75 = com.google.javascript.rhino.IR.block();
        com.google.javascript.rhino.Node node78 = new com.google.javascript.rhino.Node((int) ' ', node72, node74, node75, 0, (int) (short) -1);
        boolean boolean79 = node72.isThrow();
        com.google.javascript.rhino.Node node81 = node72.getAncestor((int) '#');
        com.google.javascript.rhino.jstype.FunctionType functionType82 = jSTypeRegistry1.createFunctionType((com.google.javascript.rhino.jstype.JSType) functionType68, node72);
        com.google.javascript.rhino.jstype.JSType jSType83 = null;
        try {
            com.google.javascript.rhino.jstype.JSType jSType84 = functionType82.getGreatestSubtype(jSType83);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(objectTypeIterable5);
        org.junit.Assert.assertNotNull(jSTypeArray7);
        org.junit.Assert.assertNotNull(functionType8);
        org.junit.Assert.assertNull(jSDocInfo9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(objectTypeIterable14);
        org.junit.Assert.assertNotNull(jSTypeArray16);
        org.junit.Assert.assertNotNull(functionType17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(objectTypeIterable24);
        org.junit.Assert.assertNotNull(jSTypeArray26);
        org.junit.Assert.assertNotNull(functionType27);
        org.junit.Assert.assertNull(jSDocInfo28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertNull(str32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertNotNull(jSTypeArray36);
        org.junit.Assert.assertNotNull(functionType37);
        org.junit.Assert.assertNotNull(objectTypeIterable41);
        org.junit.Assert.assertNotNull(jSTypeArray43);
        org.junit.Assert.assertNotNull(functionType44);
        org.junit.Assert.assertNull(jSDocInfo45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(objectTypeIterable50);
        org.junit.Assert.assertNotNull(jSTypeArray52);
        org.junit.Assert.assertNotNull(functionType53);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 0 + "'", int54 == 0);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + true + "'", boolean55 == true);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertNotNull(jSType61);
        org.junit.Assert.assertNotNull(objectTypeIterable65);
        org.junit.Assert.assertNotNull(jSTypeArray67);
        org.junit.Assert.assertNotNull(functionType68);
        org.junit.Assert.assertNull(jSDocInfo69);
        org.junit.Assert.assertNotNull(node72);
        org.junit.Assert.assertNotNull(node74);
        org.junit.Assert.assertNotNull(node75);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
        org.junit.Assert.assertNull(node81);
        org.junit.Assert.assertNotNull(functionType82);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString("InputId: Not declared as a constructor", (int) '4', (int) (byte) 100);
        int int4 = node3.getCharno();
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 100 + "'", int4 == 100);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.stringKey("");
        int int2 = node1.getLineno();
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.IR.block();
        java.lang.String str7 = node3.toString(false, false, false);
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.IR.block();
        java.lang.String str12 = node8.toString(false, false, false);
        com.google.javascript.rhino.Node node13 = node3.useSourceInfoIfMissingFrom(node8);
        com.google.javascript.rhino.Node node14 = node1.srcrefTree(node3);
        boolean boolean15 = node1.isCatch();
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "BLOCK" + "'", str7.equals("BLOCK"));
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "BLOCK" + "'", str12.equals("BLOCK"));
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.stringKey("");
        int int2 = node1.getLineno();
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.IR.block();
        java.lang.String str7 = node3.toString(false, false, false);
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.IR.block();
        java.lang.String str12 = node8.toString(false, false, false);
        com.google.javascript.rhino.Node node13 = node3.useSourceInfoIfMissingFrom(node8);
        com.google.javascript.rhino.Node node14 = node1.srcrefTree(node3);
        boolean boolean15 = node14.isSwitch();
        boolean boolean16 = node14.isSwitch();
        try {
            com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.IR.exprResult(node14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "BLOCK" + "'", str7.equals("BLOCK"));
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "BLOCK" + "'", str12.equals("BLOCK"));
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.returnNode();
        boolean boolean1 = node0.isNew();
        boolean boolean2 = node0.isGetterDef();
        boolean boolean3 = node0.isSwitch();
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        com.google.javascript.jscomp.SourceMap.DetailLevel detailLevel0 = com.google.javascript.jscomp.SourceMap.DetailLevel.ALL;
        com.google.javascript.rhino.Node node1 = null;
        boolean boolean2 = detailLevel0.apply(node1);
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.IR.returnNode();
        java.util.Set<java.lang.String> strSet4 = node3.getDirectives();
        int int5 = node3.getType();
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.IR.block();
        java.lang.String str10 = node6.toString(false, false, false);
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.IR.block();
        java.lang.String str15 = node11.toString(false, false, false);
        com.google.javascript.rhino.Node node16 = node6.useSourceInfoIfMissingFrom(node11);
        com.google.javascript.rhino.Node node17 = node3.useSourceInfoIfMissingFrom(node6);
        boolean boolean18 = node6.isDebugger();
        boolean boolean19 = detailLevel0.apply(node6);
        org.junit.Assert.assertNotNull(detailLevel0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNull(strSet4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "BLOCK" + "'", str10.equals("BLOCK"));
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "BLOCK" + "'", str15.equals("BLOCK"));
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        int int0 = com.google.javascript.rhino.Node.STATIC_SOURCE_FILE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 51 + "'", int0 == 51);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        boolean boolean1 = com.google.javascript.jscomp.NodeUtil.isValidSimpleName("(BLOCK)");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.MISSING_PROPERTIES;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newNumber((double) 35, 0, 47);
        int int4 = node3.getChildCount();
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        com.google.javascript.jscomp.SourceAst sourceAst0 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(sourceAst0, "Not declared as a constructor", true);
        com.google.javascript.rhino.InputId inputId4 = compilerInput3.getInputId();
        java.lang.String str5 = inputId4.toString();
        com.google.javascript.rhino.ErrorReporter errorReporter6 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry7 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter6);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable9 = jSTypeRegistry7.getEachReferenceTypeWithProperty("goog.global");
        com.google.javascript.rhino.jstype.JSType jSType10 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray11 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType12 = jSTypeRegistry7.createConstructorTypeWithVarArgs(jSType10, jSTypeArray11);
        com.google.javascript.rhino.JSDocInfo jSDocInfo13 = functionType12.getJSDocInfo();
        boolean boolean14 = functionType12.isAllType();
        com.google.javascript.rhino.ErrorReporter errorReporter15 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry16 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter15);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable18 = jSTypeRegistry16.getEachReferenceTypeWithProperty("goog.global");
        com.google.javascript.rhino.jstype.JSType jSType19 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray20 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType21 = jSTypeRegistry16.createConstructorTypeWithVarArgs(jSType19, jSTypeArray20);
        int int22 = functionType21.getMaxArguments();
        boolean boolean23 = functionType12.isSubtype((com.google.javascript.rhino.jstype.JSType) functionType21);
        com.google.javascript.rhino.ErrorReporter errorReporter24 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry25 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter24);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable27 = jSTypeRegistry25.getEachReferenceTypeWithProperty("goog.global");
        com.google.javascript.rhino.jstype.JSType jSType28 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray29 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType30 = jSTypeRegistry25.createConstructorTypeWithVarArgs(jSType28, jSTypeArray29);
        com.google.javascript.rhino.JSDocInfo jSDocInfo31 = functionType30.getJSDocInfo();
        boolean boolean32 = functionType30.isAllType();
        com.google.javascript.rhino.ErrorReporter errorReporter33 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry34 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter33);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable36 = jSTypeRegistry34.getEachReferenceTypeWithProperty("goog.global");
        com.google.javascript.rhino.jstype.JSType jSType37 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray38 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType39 = jSTypeRegistry34.createConstructorTypeWithVarArgs(jSType37, jSTypeArray38);
        int int40 = functionType39.getMaxArguments();
        boolean boolean41 = functionType30.isSubtype((com.google.javascript.rhino.jstype.JSType) functionType39);
        com.google.javascript.rhino.ErrorReporter errorReporter43 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry44 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter43);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable46 = jSTypeRegistry44.getEachReferenceTypeWithProperty("goog.global");
        com.google.javascript.rhino.jstype.JSType jSType47 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray48 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType49 = jSTypeRegistry44.createConstructorTypeWithVarArgs(jSType47, jSTypeArray48);
        com.google.javascript.rhino.JSDocInfo jSDocInfo50 = functionType49.getJSDocInfo();
        boolean boolean51 = functionType49.isAllType();
        int int52 = functionType49.getMaxArguments();
        com.google.javascript.rhino.Node node53 = com.google.javascript.rhino.IR.trueNode();
        java.lang.String str54 = node53.getSourceFileName();
        boolean boolean55 = node53.isOr();
        boolean boolean56 = functionType39.defineInferredProperty("hi!", (com.google.javascript.rhino.jstype.JSType) functionType49, node53);
        boolean boolean57 = functionType12.canTestForEqualityWith((com.google.javascript.rhino.jstype.JSType) functionType39);
        boolean boolean58 = inputId4.equals((java.lang.Object) functionType39);
        org.junit.Assert.assertNotNull(inputId4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "InputId: Not declared as a constructor" + "'", str5.equals("InputId: Not declared as a constructor"));
        org.junit.Assert.assertNotNull(objectTypeIterable9);
        org.junit.Assert.assertNotNull(jSTypeArray11);
        org.junit.Assert.assertNotNull(functionType12);
        org.junit.Assert.assertNull(jSDocInfo13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(objectTypeIterable18);
        org.junit.Assert.assertNotNull(jSTypeArray20);
        org.junit.Assert.assertNotNull(functionType21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(objectTypeIterable27);
        org.junit.Assert.assertNotNull(jSTypeArray29);
        org.junit.Assert.assertNotNull(functionType30);
        org.junit.Assert.assertNull(jSDocInfo31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(objectTypeIterable36);
        org.junit.Assert.assertNotNull(jSTypeArray38);
        org.junit.Assert.assertNotNull(functionType39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
        org.junit.Assert.assertNotNull(objectTypeIterable46);
        org.junit.Assert.assertNotNull(jSTypeArray48);
        org.junit.Assert.assertNotNull(functionType49);
        org.junit.Assert.assertNull(jSDocInfo50);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 0 + "'", int52 == 0);
        org.junit.Assert.assertNotNull(node53);
        org.junit.Assert.assertNull(str54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + true + "'", boolean56 == true);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + true + "'", boolean57 == true);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.computeFunctionSideEffects = true;
        boolean boolean3 = compilerOptions0.removeUnusedVars;
        java.lang.String[] strArray15 = new java.lang.String[] { "InputId: Not declared as a constructor", ".", "BLOCK", "InputId: Not declared as a constructor", "Not declared as a constructor", "module$hi!", ".", "JSDocInfo", "module$hi!", ".", "hi!" };
        java.util.LinkedHashSet<java.lang.String> strSet16 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean17 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet16, strArray15);
        compilerOptions0.setIdGenerators((java.util.Set<java.lang.String>) strSet16);
        compilerOptions0.setReserveRawExports(true);
        com.google.javascript.jscomp.CompilerOptions compilerOptions21 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions21.computeFunctionSideEffects = true;
        java.lang.String str24 = compilerOptions21.renamePrefix;
        com.google.javascript.jscomp.CheckLevel checkLevel25 = compilerOptions21.reportMissingOverride;
        boolean boolean26 = compilerOptions21.preferLineBreakAtEndOfFile;
        compilerOptions21.setCommonJSModulePathPrefix("JSDocInfo");
        com.google.javascript.rhino.JSDocInfo jSDocInfo29 = new com.google.javascript.rhino.JSDocInfo();
        java.util.List<com.google.javascript.rhino.JSTypeExpression> jSTypeExpressionList30 = jSDocInfo29.getImplementedInterfaces();
        java.util.Set<java.lang.String> strSet31 = jSDocInfo29.getSuppressions();
        compilerOptions21.setIdGenerators(strSet31);
        compilerOptions0.aliasableStrings = strSet31;
        compilerOptions0.setExportTestFunctions(true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(strArray15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNull(str24);
        org.junit.Assert.assertTrue("'" + checkLevel25 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel25.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(jSTypeExpressionList30);
        org.junit.Assert.assertNotNull(strSet31);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.computeFunctionSideEffects = true;
        java.lang.String str3 = compilerOptions0.renamePrefix;
        boolean boolean4 = compilerOptions0.isRemoveUnusedClassProperties();
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        com.google.javascript.rhino.Node.SideEffectFlags sideEffectFlags1 = new com.google.javascript.rhino.Node.SideEffectFlags(47);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.CHECK_REGEXP;
        com.google.javascript.jscomp.DiagnosticGroups.INVALID_CASTS = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticGroups.DUPLICATE_MESSAGE = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticGroups.UNKNOWN_DEFINES = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticGroups.MISSING_PROPERTIES = diagnosticGroup0;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        com.google.javascript.rhino.Node node0 = null;
        try {
            com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.regexp(node0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = com.google.javascript.jscomp.CheckLevel.ERROR;
        compilerOptions0.reportMissingOverride = checkLevel1;
        compilerOptions0.generateExports = false;
        compilerOptions0.removeUnusedVars = true;
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        int int0 = com.google.javascript.rhino.Node.JSDOC_INFO_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 29 + "'", int0 == 29);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.computeFunctionSideEffects = true;
        boolean boolean3 = compilerOptions0.removeUnusedVars;
        java.lang.String[] strArray15 = new java.lang.String[] { "InputId: Not declared as a constructor", ".", "BLOCK", "InputId: Not declared as a constructor", "Not declared as a constructor", "module$hi!", ".", "JSDocInfo", "module$hi!", ".", "hi!" };
        java.util.LinkedHashSet<java.lang.String> strSet16 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean17 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet16, strArray15);
        compilerOptions0.setIdGenerators((java.util.Set<java.lang.String>) strSet16);
        compilerOptions0.setReserveRawExports(true);
        compilerOptions0.gatherCssNames = true;
        boolean boolean23 = compilerOptions0.closurePass;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(strArray15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.stringKey("");
        com.google.javascript.rhino.Node node2 = null;
        int int3 = node1.getIndexOfChild(node2);
        boolean boolean4 = node1.isCatch();
        node1.setCharno((int) ' ');
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        com.google.javascript.rhino.JSDocInfo jSDocInfo0 = new com.google.javascript.rhino.JSDocInfo();
        java.util.List<com.google.javascript.rhino.JSTypeExpression> jSTypeExpressionList1 = jSDocInfo0.getImplementedInterfaces();
        java.util.Set<java.lang.String> strSet2 = jSDocInfo0.getSuppressions();
        com.google.javascript.rhino.JSDocInfo.Visibility visibility3 = jSDocInfo0.getVisibility();
        com.google.javascript.rhino.JSTypeExpression jSTypeExpression4 = jSDocInfo0.getEnumParameterType();
        java.lang.String str5 = jSDocInfo0.getVersion();
        org.junit.Assert.assertNotNull(jSTypeExpressionList1);
        org.junit.Assert.assertNotNull(strSet2);
        org.junit.Assert.assertNull(visibility3);
        org.junit.Assert.assertNull(jSTypeExpression4);
        org.junit.Assert.assertNull(str5);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.computeFunctionSideEffects = true;
        boolean boolean3 = compilerOptions0.isRemoveUnusedClassProperties();
        com.google.javascript.jscomp.ErrorHandler errorHandler4 = null;
        compilerOptions0.setErrorHandler(errorHandler4);
        boolean boolean6 = compilerOptions0.checkSuspiciousCode;
        boolean boolean7 = compilerOptions0.removeUnusedPrototypeProperties;
        com.google.javascript.jscomp.MessageBundle messageBundle8 = null;
        compilerOptions0.messageBundle = messageBundle8;
        compilerOptions0.setDebugFunctionSideEffectsPath("goog.global");
        compilerOptions0.setPrintInputDelimiter(false);
        com.google.javascript.jscomp.CompilerOptions.LanguageMode languageMode14 = com.google.javascript.jscomp.CompilerOptions.LanguageMode.ECMASCRIPT5;
        compilerOptions0.setLanguageIn(languageMode14);
        java.lang.String str16 = compilerOptions0.checkMissingGetCssNameBlacklist;
        java.lang.Object obj17 = compilerOptions0.clone();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + languageMode14 + "' != '" + com.google.javascript.jscomp.CompilerOptions.LanguageMode.ECMASCRIPT5 + "'", languageMode14.equals(com.google.javascript.jscomp.CompilerOptions.LanguageMode.ECMASCRIPT5));
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertNotNull(obj17);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention0 = new com.google.javascript.jscomp.GoogleCodingConvention();
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention1 = new com.google.javascript.jscomp.ClosureCodingConvention((com.google.javascript.jscomp.CodingConvention) googleCodingConvention0);
        com.google.javascript.rhino.Node node2 = null;
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship3 = googleCodingConvention0.getDelegateRelationship(node2);
        java.lang.String str4 = googleCodingConvention0.getGlobalObject();
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.IR.stringKey("");
        int int7 = node6.getLineno();
        java.util.Map<java.lang.String, java.lang.String> strMap8 = null;
        googleCodingConvention0.checkForCallingConventionDefiningCalls(node6, strMap8);
        boolean boolean12 = googleCodingConvention0.isExported("function (): {631144317}", false);
        org.junit.Assert.assertNull(delegateRelationship3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "goog.global" + "'", str4.equals("goog.global"));
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.ACCESS_CONTROLS;
        com.google.javascript.jscomp.CheckLevel checkLevel1 = com.google.javascript.jscomp.CheckLevel.ERROR;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard2 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup0, checkLevel1);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup3 = com.google.javascript.jscomp.DiagnosticGroups.ACCESS_CONTROLS;
        com.google.javascript.jscomp.CheckLevel checkLevel4 = com.google.javascript.jscomp.CheckLevel.ERROR;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard5 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup3, checkLevel4);
        boolean boolean6 = diagnosticGroupWarningsGuard2.enables(diagnosticGroup3);
        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray7 = new com.google.javascript.jscomp.WarningsGuard[] { diagnosticGroupWarningsGuard2 };
        java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard> warningsGuardList8 = new java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard>();
        boolean boolean9 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList8, warningsGuardArray7);
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard10 = new com.google.javascript.jscomp.ComposeWarningsGuard((java.util.List<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList8);
        java.lang.String str11 = composeWarningsGuard10.toString();
        java.lang.String str12 = composeWarningsGuard10.toString();
        org.junit.Assert.assertNotNull(diagnosticGroup0);
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticGroup3);
        org.junit.Assert.assertTrue("'" + checkLevel4 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel4.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(warningsGuardArray7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "DiagnosticGroup<accessControls>(ERROR)" + "'", str11.equals("DiagnosticGroup<accessControls>(ERROR)"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "DiagnosticGroup<accessControls>(ERROR)" + "'", str12.equals("DiagnosticGroup<accessControls>(ERROR)"));
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.computeFunctionSideEffects = true;
        boolean boolean3 = compilerOptions0.isRemoveUnusedClassProperties();
        com.google.javascript.jscomp.ErrorHandler errorHandler4 = null;
        compilerOptions0.setErrorHandler(errorHandler4);
        com.google.javascript.jscomp.CompilerOptions.AliasTransformationHandler aliasTransformationHandler6 = null;
        compilerOptions0.setAliasTransformationHandler(aliasTransformationHandler6);
        compilerOptions0.setInlineFunctions(true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        com.google.javascript.rhino.JSDocInfo.Visibility visibility0 = com.google.javascript.rhino.JSDocInfo.Visibility.PUBLIC;
        org.junit.Assert.assertTrue("'" + visibility0 + "' != '" + com.google.javascript.rhino.JSDocInfo.Visibility.PUBLIC + "'", visibility0.equals(com.google.javascript.rhino.JSDocInfo.Visibility.PUBLIC));
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.IR.stringKey("");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.IR.stringKey("");
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.IR.block();
        com.google.javascript.rhino.Node node8 = new com.google.javascript.rhino.Node((int) ' ', node2, node4, node5, 0, (int) (short) -1);
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.IR.stringKey("");
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.IR.stringKey("");
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.IR.block();
        com.google.javascript.rhino.Node node17 = new com.google.javascript.rhino.Node((int) ' ', node11, node13, node14, 0, (int) (short) -1);
        boolean boolean18 = node11.isThrow();
        int int19 = node5.getIndexOfChild(node11);
        com.google.javascript.rhino.Node node21 = com.google.javascript.rhino.IR.stringKey("");
        int int22 = node21.getLineno();
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.IR.block();
        java.lang.String str27 = node23.toString(false, false, false);
        com.google.javascript.rhino.Node node28 = com.google.javascript.rhino.IR.block();
        java.lang.String str32 = node28.toString(false, false, false);
        com.google.javascript.rhino.Node node33 = node23.useSourceInfoIfMissingFrom(node28);
        com.google.javascript.rhino.Node node34 = node21.srcrefTree(node23);
        com.google.javascript.rhino.Node node35 = node5.useSourceInfoIfMissingFromForTree(node21);
        node35.setWasEmptyNode(true);
        com.google.javascript.rhino.ErrorReporter errorReporter38 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry39 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter38);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable41 = jSTypeRegistry39.getEachReferenceTypeWithProperty("goog.global");
        com.google.javascript.rhino.jstype.JSType jSType42 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray43 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType44 = jSTypeRegistry39.createConstructorTypeWithVarArgs(jSType42, jSTypeArray43);
        com.google.javascript.rhino.ErrorReporter errorReporter45 = jSTypeRegistry39.getErrorReporter();
        com.google.javascript.rhino.Node node48 = com.google.javascript.rhino.IR.stringKey("");
        com.google.javascript.rhino.Node node50 = com.google.javascript.rhino.IR.stringKey("");
        com.google.javascript.rhino.Node node51 = null;
        int int52 = node50.getIndexOfChild(node51);
        node48.addChildrenToBack(node50);
        com.google.javascript.rhino.Node node54 = com.google.javascript.rhino.IR.block();
        java.lang.String str58 = node54.toString(false, false, false);
        com.google.javascript.rhino.Node node61 = com.google.javascript.rhino.IR.stringKey("");
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable62 = node61.siblings();
        com.google.javascript.rhino.Node node65 = new com.google.javascript.rhino.Node((int) (short) 100, node61, (int) (short) 1, (int) (short) 10);
        com.google.javascript.rhino.Node node66 = node54.useSourceInfoIfMissingFrom(node65);
        com.google.javascript.rhino.Node node67 = node50.srcref(node54);
        com.google.javascript.rhino.ErrorReporter errorReporter68 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry69 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter68);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable71 = jSTypeRegistry69.getEachReferenceTypeWithProperty("goog.global");
        com.google.javascript.rhino.jstype.JSType jSType72 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray73 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType74 = jSTypeRegistry69.createConstructorTypeWithVarArgs(jSType72, jSTypeArray73);
        com.google.javascript.rhino.JSDocInfo jSDocInfo75 = functionType74.getJSDocInfo();
        boolean boolean76 = functionType74.isAllType();
        com.google.javascript.rhino.ErrorReporter errorReporter77 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry78 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter77);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable80 = jSTypeRegistry78.getEachReferenceTypeWithProperty("goog.global");
        com.google.javascript.rhino.jstype.JSType jSType81 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray82 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType83 = jSTypeRegistry78.createConstructorTypeWithVarArgs(jSType81, jSTypeArray82);
        int int84 = functionType83.getMaxArguments();
        boolean boolean85 = functionType74.isSubtype((com.google.javascript.rhino.jstype.JSType) functionType83);
        com.google.javascript.rhino.jstype.EnumType enumType86 = jSTypeRegistry39.createEnumType("BLOCK", node67, (com.google.javascript.rhino.jstype.JSType) functionType74);
        try {
            com.google.javascript.rhino.Node node87 = com.google.javascript.rhino.IR.label(node35, node67);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "BLOCK" + "'", str27.equals("BLOCK"));
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "BLOCK" + "'", str32.equals("BLOCK"));
        org.junit.Assert.assertNotNull(node33);
        org.junit.Assert.assertNotNull(node34);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertNotNull(objectTypeIterable41);
        org.junit.Assert.assertNotNull(jSTypeArray43);
        org.junit.Assert.assertNotNull(functionType44);
        org.junit.Assert.assertNull(errorReporter45);
        org.junit.Assert.assertNotNull(node48);
        org.junit.Assert.assertNotNull(node50);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + (-1) + "'", int52 == (-1));
        org.junit.Assert.assertNotNull(node54);
        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "BLOCK" + "'", str58.equals("BLOCK"));
        org.junit.Assert.assertNotNull(node61);
        org.junit.Assert.assertNotNull(nodeIterable62);
        org.junit.Assert.assertNotNull(node66);
        org.junit.Assert.assertNotNull(node67);
        org.junit.Assert.assertNotNull(objectTypeIterable71);
        org.junit.Assert.assertNotNull(jSTypeArray73);
        org.junit.Assert.assertNotNull(functionType74);
        org.junit.Assert.assertNull(jSDocInfo75);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
        org.junit.Assert.assertNotNull(objectTypeIterable80);
        org.junit.Assert.assertNotNull(jSTypeArray82);
        org.junit.Assert.assertNotNull(functionType83);
        org.junit.Assert.assertTrue("'" + int84 + "' != '" + 0 + "'", int84 == 0);
        org.junit.Assert.assertTrue("'" + boolean85 + "' != '" + true + "'", boolean85 == true);
        org.junit.Assert.assertNotNull(enumType86);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        com.google.javascript.jscomp.SourceFile sourceFile1 = com.google.javascript.jscomp.SourceFile.fromFile("./");
        java.lang.String str2 = sourceFile1.getOriginalPath();
        com.google.javascript.jscomp.JsAst jsAst3 = new com.google.javascript.jscomp.JsAst(sourceFile1);
        com.google.javascript.jscomp.SourceFile sourceFile4 = jsAst3.getSourceFile();
        org.junit.Assert.assertNotNull(sourceFile1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "." + "'", str2.equals("."));
        org.junit.Assert.assertNotNull(sourceFile4);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable3 = jSTypeRegistry1.getEachReferenceTypeWithProperty("goog.global");
        com.google.javascript.rhino.jstype.JSType jSType4 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray5 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType6 = jSTypeRegistry1.createConstructorTypeWithVarArgs(jSType4, jSTypeArray5);
        com.google.javascript.rhino.JSDocInfo jSDocInfo7 = functionType6.getJSDocInfo();
        boolean boolean8 = functionType6.isAllType();
        com.google.javascript.rhino.ErrorReporter errorReporter9 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry10 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter9);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable12 = jSTypeRegistry10.getEachReferenceTypeWithProperty("goog.global");
        com.google.javascript.rhino.jstype.JSType jSType13 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray14 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType15 = jSTypeRegistry10.createConstructorTypeWithVarArgs(jSType13, jSTypeArray14);
        int int16 = functionType15.getMaxArguments();
        boolean boolean17 = functionType6.isSubtype((com.google.javascript.rhino.jstype.JSType) functionType15);
        com.google.javascript.rhino.ErrorReporter errorReporter19 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry20 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter19);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable22 = jSTypeRegistry20.getEachReferenceTypeWithProperty("goog.global");
        com.google.javascript.rhino.jstype.JSType jSType23 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray24 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType25 = jSTypeRegistry20.createConstructorTypeWithVarArgs(jSType23, jSTypeArray24);
        com.google.javascript.rhino.JSDocInfo jSDocInfo26 = functionType25.getJSDocInfo();
        boolean boolean27 = functionType25.isAllType();
        int int28 = functionType25.getMaxArguments();
        com.google.javascript.rhino.Node node29 = com.google.javascript.rhino.IR.trueNode();
        java.lang.String str30 = node29.getSourceFileName();
        boolean boolean31 = node29.isOr();
        boolean boolean32 = functionType15.defineInferredProperty("hi!", (com.google.javascript.rhino.jstype.JSType) functionType25, node29);
        com.google.javascript.rhino.jstype.ParameterizedType parameterizedType33 = functionType25.toMaybeParameterizedType();
        boolean boolean34 = functionType25.hasAnyTemplateInternal();
        com.google.javascript.rhino.jstype.ObjectType objectType36 = functionType25.getTopMostDefiningType("2019/06/10 13:01");
        com.google.common.base.Predicate<com.google.javascript.rhino.jstype.JSType> jSTypePredicate37 = null;
        try {
            boolean boolean38 = objectType36.setValidator(jSTypePredicate37);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(objectTypeIterable3);
        org.junit.Assert.assertNotNull(jSTypeArray5);
        org.junit.Assert.assertNotNull(functionType6);
        org.junit.Assert.assertNull(jSDocInfo7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(objectTypeIterable12);
        org.junit.Assert.assertNotNull(jSTypeArray14);
        org.junit.Assert.assertNotNull(functionType15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(objectTypeIterable22);
        org.junit.Assert.assertNotNull(jSTypeArray24);
        org.junit.Assert.assertNotNull(functionType25);
        org.junit.Assert.assertNull(jSDocInfo26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNull(str30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNull(parameterizedType33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(objectType36);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.continueNode();
        com.google.javascript.rhino.Node node4 = new com.google.javascript.rhino.Node(10, node1, 35, 0);
        com.google.javascript.rhino.jstype.StaticSourceFile staticSourceFile5 = node1.getStaticSourceFile();
        boolean boolean6 = node1.isNoSideEffectsCall();
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertNull(staticSourceFile5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        com.google.javascript.rhino.JSDocInfo.NamePosition namePosition0 = new com.google.javascript.rhino.JSDocInfo.NamePosition();
        int int1 = namePosition0.getEndLine();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        int int0 = com.google.javascript.rhino.Node.FLAG_GLOBAL_STATE_UNMODIFIED;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeUnusedPrototypePropertiesInExterns = true;
        compilerOptions0.moveFunctionDeclarations = true;
        compilerOptions0.setAliasExternals(true);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.computeFunctionSideEffects = true;
        boolean boolean3 = compilerOptions0.ideMode;
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention4 = new com.google.javascript.jscomp.GoogleCodingConvention();
        compilerOptions0.setCodingConvention((com.google.javascript.jscomp.CodingConvention) googleCodingConvention4);
        com.google.javascript.rhino.Node node7 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode((com.google.javascript.jscomp.CodingConvention) googleCodingConvention4, "InputId: Not declared as a constructor");
        boolean boolean9 = googleCodingConvention4.isConstantKey("(BLOCK)");
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        com.google.javascript.rhino.ErrorReporter errorReporter2 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry3 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter2);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable5 = jSTypeRegistry3.getEachReferenceTypeWithProperty("goog.global");
        com.google.javascript.rhino.jstype.JSType jSType6 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray7 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType8 = jSTypeRegistry3.createConstructorTypeWithVarArgs(jSType6, jSTypeArray7);
        com.google.javascript.rhino.JSDocInfo jSDocInfo9 = functionType8.getJSDocInfo();
        boolean boolean10 = functionType8.isAllType();
        com.google.javascript.rhino.ErrorReporter errorReporter11 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry12 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter11);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable14 = jSTypeRegistry12.getEachReferenceTypeWithProperty("goog.global");
        com.google.javascript.rhino.jstype.JSType jSType15 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray16 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType17 = jSTypeRegistry12.createConstructorTypeWithVarArgs(jSType15, jSTypeArray16);
        int int18 = functionType17.getMaxArguments();
        boolean boolean19 = functionType8.isSubtype((com.google.javascript.rhino.jstype.JSType) functionType17);
        com.google.javascript.rhino.ErrorReporter errorReporter21 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry22 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter21);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable24 = jSTypeRegistry22.getEachReferenceTypeWithProperty("goog.global");
        com.google.javascript.rhino.jstype.JSType jSType25 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray26 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType27 = jSTypeRegistry22.createConstructorTypeWithVarArgs(jSType25, jSTypeArray26);
        com.google.javascript.rhino.JSDocInfo jSDocInfo28 = functionType27.getJSDocInfo();
        boolean boolean29 = functionType27.isAllType();
        int int30 = functionType27.getMaxArguments();
        com.google.javascript.rhino.Node node31 = com.google.javascript.rhino.IR.trueNode();
        java.lang.String str32 = node31.getSourceFileName();
        boolean boolean33 = node31.isOr();
        boolean boolean34 = functionType17.defineInferredProperty("hi!", (com.google.javascript.rhino.jstype.JSType) functionType27, node31);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray36 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType37 = jSTypeRegistry1.createConstructorType((com.google.javascript.rhino.jstype.JSType) functionType27, false, jSTypeArray36);
        com.google.javascript.rhino.ErrorReporter errorReporter38 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry39 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter38);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable41 = jSTypeRegistry39.getEachReferenceTypeWithProperty("goog.global");
        com.google.javascript.rhino.jstype.JSType jSType42 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray43 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType44 = jSTypeRegistry39.createConstructorTypeWithVarArgs(jSType42, jSTypeArray43);
        com.google.javascript.rhino.JSDocInfo jSDocInfo45 = functionType44.getJSDocInfo();
        boolean boolean46 = functionType44.isAllType();
        com.google.javascript.rhino.ErrorReporter errorReporter47 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry48 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter47);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable50 = jSTypeRegistry48.getEachReferenceTypeWithProperty("goog.global");
        com.google.javascript.rhino.jstype.JSType jSType51 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray52 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType53 = jSTypeRegistry48.createConstructorTypeWithVarArgs(jSType51, jSTypeArray52);
        int int54 = functionType53.getMaxArguments();
        boolean boolean55 = functionType44.isSubtype((com.google.javascript.rhino.jstype.JSType) functionType53);
        java.io.PrintStream printStream56 = null;
        com.google.javascript.jscomp.Compiler compiler57 = new com.google.javascript.jscomp.Compiler(printStream56);
        com.google.javascript.jscomp.NodeTraversal.Callback callback58 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal59 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler57, callback58);
        boolean boolean60 = functionType44.equals((java.lang.Object) nodeTraversal59);
        com.google.javascript.rhino.jstype.JSType jSType61 = jSTypeRegistry1.createOptionalNullableType((com.google.javascript.rhino.jstype.JSType) functionType44);
        boolean boolean62 = functionType44.isNativeObjectType();
        org.junit.Assert.assertNotNull(objectTypeIterable5);
        org.junit.Assert.assertNotNull(jSTypeArray7);
        org.junit.Assert.assertNotNull(functionType8);
        org.junit.Assert.assertNull(jSDocInfo9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(objectTypeIterable14);
        org.junit.Assert.assertNotNull(jSTypeArray16);
        org.junit.Assert.assertNotNull(functionType17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(objectTypeIterable24);
        org.junit.Assert.assertNotNull(jSTypeArray26);
        org.junit.Assert.assertNotNull(functionType27);
        org.junit.Assert.assertNull(jSDocInfo28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertNull(str32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertNotNull(jSTypeArray36);
        org.junit.Assert.assertNotNull(functionType37);
        org.junit.Assert.assertNotNull(objectTypeIterable41);
        org.junit.Assert.assertNotNull(jSTypeArray43);
        org.junit.Assert.assertNotNull(functionType44);
        org.junit.Assert.assertNull(jSDocInfo45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(objectTypeIterable50);
        org.junit.Assert.assertNotNull(jSTypeArray52);
        org.junit.Assert.assertNotNull(functionType53);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 0 + "'", int54 == 0);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + true + "'", boolean55 == true);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertNotNull(jSType61);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeUnusedPrototypePropertiesInExterns = true;
        java.util.Map<java.lang.String, java.lang.Object> strMap3 = null;
        compilerOptions0.setTweakReplacements(strMap3);
        com.google.javascript.jscomp.parsing.Config.LanguageMode languageMode6 = com.google.javascript.jscomp.parsing.Config.LanguageMode.ECMASCRIPT3;
        java.lang.String[] strArray10 = new java.lang.String[] { "hi!", "hi!" };
        java.util.LinkedHashSet<java.lang.String> strSet11 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean12 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet11, strArray10);
        com.google.javascript.jscomp.parsing.Config config13 = com.google.javascript.jscomp.parsing.ParserRunner.createConfig(false, languageMode6, true, (java.util.Set<java.lang.String>) strSet11);
        compilerOptions0.stripNameSuffixes = strSet11;
        com.google.javascript.jscomp.MessageBundle messageBundle15 = compilerOptions0.messageBundle;
        org.junit.Assert.assertTrue("'" + languageMode6 + "' != '" + com.google.javascript.jscomp.parsing.Config.LanguageMode.ECMASCRIPT3 + "'", languageMode6.equals(com.google.javascript.jscomp.parsing.Config.LanguageMode.ECMASCRIPT3));
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(config13);
        org.junit.Assert.assertNull(messageBundle15);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        com.google.javascript.jscomp.CustomPassExecutionTime customPassExecutionTime0 = com.google.javascript.jscomp.CustomPassExecutionTime.BEFORE_OPTIMIZATIONS;
        org.junit.Assert.assertTrue("'" + customPassExecutionTime0 + "' != '" + com.google.javascript.jscomp.CustomPassExecutionTime.BEFORE_OPTIMIZATIONS + "'", customPassExecutionTime0.equals(com.google.javascript.jscomp.CustomPassExecutionTime.BEFORE_OPTIMIZATIONS));
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable3 = jSTypeRegistry1.getEachReferenceTypeWithProperty("goog.global");
        com.google.javascript.rhino.jstype.JSType jSType4 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray5 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType6 = jSTypeRegistry1.createConstructorTypeWithVarArgs(jSType4, jSTypeArray5);
        com.google.javascript.rhino.JSDocInfo jSDocInfo7 = functionType6.getJSDocInfo();
        boolean boolean8 = functionType6.isAllType();
        com.google.javascript.rhino.ErrorReporter errorReporter9 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry10 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter9);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable12 = jSTypeRegistry10.getEachReferenceTypeWithProperty("goog.global");
        com.google.javascript.rhino.jstype.JSType jSType13 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray14 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType15 = jSTypeRegistry10.createConstructorTypeWithVarArgs(jSType13, jSTypeArray14);
        int int16 = functionType15.getMaxArguments();
        boolean boolean17 = functionType6.isSubtype((com.google.javascript.rhino.jstype.JSType) functionType15);
        com.google.javascript.rhino.ErrorReporter errorReporter18 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry19 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter18);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable21 = jSTypeRegistry19.getEachReferenceTypeWithProperty("goog.global");
        com.google.javascript.rhino.jstype.JSType jSType22 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray23 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType24 = jSTypeRegistry19.createConstructorTypeWithVarArgs(jSType22, jSTypeArray23);
        com.google.javascript.rhino.JSDocInfo jSDocInfo25 = functionType24.getJSDocInfo();
        boolean boolean26 = functionType24.isAllType();
        com.google.javascript.rhino.ErrorReporter errorReporter27 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry28 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter27);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable30 = jSTypeRegistry28.getEachReferenceTypeWithProperty("goog.global");
        com.google.javascript.rhino.jstype.JSType jSType31 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray32 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType33 = jSTypeRegistry28.createConstructorTypeWithVarArgs(jSType31, jSTypeArray32);
        int int34 = functionType33.getMaxArguments();
        boolean boolean35 = functionType24.isSubtype((com.google.javascript.rhino.jstype.JSType) functionType33);
        com.google.javascript.rhino.ErrorReporter errorReporter37 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry38 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter37);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable40 = jSTypeRegistry38.getEachReferenceTypeWithProperty("goog.global");
        com.google.javascript.rhino.jstype.JSType jSType41 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray42 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType43 = jSTypeRegistry38.createConstructorTypeWithVarArgs(jSType41, jSTypeArray42);
        com.google.javascript.rhino.JSDocInfo jSDocInfo44 = functionType43.getJSDocInfo();
        boolean boolean45 = functionType43.isAllType();
        int int46 = functionType43.getMaxArguments();
        com.google.javascript.rhino.Node node47 = com.google.javascript.rhino.IR.trueNode();
        java.lang.String str48 = node47.getSourceFileName();
        boolean boolean49 = node47.isOr();
        boolean boolean50 = functionType33.defineInferredProperty("hi!", (com.google.javascript.rhino.jstype.JSType) functionType43, node47);
        boolean boolean51 = functionType6.canTestForEqualityWith((com.google.javascript.rhino.jstype.JSType) functionType33);
        boolean boolean52 = functionType6.isUnknownType();
        boolean boolean53 = functionType6.isStringValueType();
        boolean boolean54 = functionType6.isNoResolvedType();
        org.junit.Assert.assertNotNull(objectTypeIterable3);
        org.junit.Assert.assertNotNull(jSTypeArray5);
        org.junit.Assert.assertNotNull(functionType6);
        org.junit.Assert.assertNull(jSDocInfo7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(objectTypeIterable12);
        org.junit.Assert.assertNotNull(jSTypeArray14);
        org.junit.Assert.assertNotNull(functionType15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(objectTypeIterable21);
        org.junit.Assert.assertNotNull(jSTypeArray23);
        org.junit.Assert.assertNotNull(functionType24);
        org.junit.Assert.assertNull(jSDocInfo25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(objectTypeIterable30);
        org.junit.Assert.assertNotNull(jSTypeArray32);
        org.junit.Assert.assertNotNull(functionType33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertNotNull(objectTypeIterable40);
        org.junit.Assert.assertNotNull(jSTypeArray42);
        org.junit.Assert.assertNotNull(functionType43);
        org.junit.Assert.assertNull(jSDocInfo44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 0 + "'", int46 == 0);
        org.junit.Assert.assertNotNull(node47);
        org.junit.Assert.assertNull(str48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + true + "'", boolean50 == true);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + true + "'", boolean51 == true);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = com.google.javascript.jscomp.CheckLevel.ERROR;
        compilerOptions0.reportMissingOverride = checkLevel1;
        compilerOptions0.generateExports = false;
        boolean boolean5 = compilerOptions0.isRemoveUnusedClassProperties();
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.IR.stringKey("");
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.IR.stringKey("");
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.IR.block();
        com.google.javascript.rhino.Node node9 = new com.google.javascript.rhino.Node((int) ' ', node3, node5, node6, 0, (int) (short) -1);
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.IR.stringKey("");
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.IR.stringKey("");
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.IR.block();
        com.google.javascript.rhino.Node node18 = new com.google.javascript.rhino.Node((int) ' ', node12, node14, node15, 0, (int) (short) -1);
        boolean boolean19 = node12.isThrow();
        int int20 = node6.getIndexOfChild(node12);
        com.google.javascript.rhino.Node node22 = com.google.javascript.rhino.IR.stringKey("");
        int int23 = node22.getLineno();
        com.google.javascript.rhino.Node node24 = com.google.javascript.rhino.IR.block();
        java.lang.String str28 = node24.toString(false, false, false);
        com.google.javascript.rhino.Node node29 = com.google.javascript.rhino.IR.block();
        java.lang.String str33 = node29.toString(false, false, false);
        com.google.javascript.rhino.Node node34 = node24.useSourceInfoIfMissingFrom(node29);
        com.google.javascript.rhino.Node node35 = node22.srcrefTree(node24);
        com.google.javascript.rhino.Node node36 = node6.useSourceInfoIfMissingFromForTree(node22);
        node22.putIntProp(0, (int) 'a');
        com.google.javascript.rhino.Node node40 = new com.google.javascript.rhino.Node(50, node22);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "BLOCK" + "'", str28.equals("BLOCK"));
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "BLOCK" + "'", str33.equals("BLOCK"));
        org.junit.Assert.assertNotNull(node34);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertNotNull(node36);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.ACCESS_CONTROLS;
        com.google.javascript.jscomp.CheckLevel checkLevel1 = com.google.javascript.jscomp.CheckLevel.ERROR;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard2 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup0, checkLevel1);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup3 = com.google.javascript.jscomp.DiagnosticGroups.ACCESS_CONTROLS;
        com.google.javascript.jscomp.CheckLevel checkLevel4 = com.google.javascript.jscomp.CheckLevel.ERROR;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard5 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup3, checkLevel4);
        boolean boolean6 = diagnosticGroupWarningsGuard2.enables(diagnosticGroup3);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup8 = com.google.javascript.jscomp.DiagnosticGroups.ACCESS_CONTROLS;
        com.google.javascript.jscomp.DiagnosticGroups.INTERNET_EXPLORER_CHECKS = diagnosticGroup8;
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup10 = com.google.javascript.jscomp.DiagnosticGroups.CHECK_REGEXP;
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup11 = com.google.javascript.jscomp.DiagnosticGroups.CHECK_REGEXP;
        com.google.javascript.jscomp.DiagnosticGroups.INVALID_CASTS = diagnosticGroup11;
        com.google.javascript.jscomp.DiagnosticGroups.DUPLICATE_MESSAGE = diagnosticGroup11;
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup14 = com.google.javascript.jscomp.DiagnosticGroups.ACCESS_CONTROLS;
        com.google.javascript.jscomp.DiagnosticGroups.UNDEFINED_NAMES = diagnosticGroup14;
        com.google.javascript.jscomp.DiagnosticGroup[] diagnosticGroupArray16 = new com.google.javascript.jscomp.DiagnosticGroup[] { diagnosticGroup8, diagnosticGroup10, diagnosticGroup11, diagnosticGroup14 };
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup17 = new com.google.javascript.jscomp.DiagnosticGroup("module$hi!", diagnosticGroupArray16);
        boolean boolean18 = diagnosticGroupWarningsGuard2.enables(diagnosticGroup17);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup19 = com.google.javascript.jscomp.DiagnosticGroups.CHECK_REGEXP;
        com.google.javascript.jscomp.DiagnosticGroups.INVALID_CASTS = diagnosticGroup19;
        com.google.javascript.jscomp.DiagnosticGroups.DUPLICATE_MESSAGE = diagnosticGroup19;
        boolean boolean22 = diagnosticGroupWarningsGuard2.enables(diagnosticGroup19);
        com.google.javascript.jscomp.DiagnosticGroups.NON_STANDARD_JSDOC = diagnosticGroup19;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticGroup3);
        org.junit.Assert.assertTrue("'" + checkLevel4 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel4.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(diagnosticGroup8);
        org.junit.Assert.assertNotNull(diagnosticGroup10);
        org.junit.Assert.assertNotNull(diagnosticGroup11);
        org.junit.Assert.assertNotNull(diagnosticGroup14);
        org.junit.Assert.assertNotNull(diagnosticGroupArray16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(diagnosticGroup19);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable3 = jSTypeRegistry1.getEachReferenceTypeWithProperty("goog.global");
        com.google.javascript.rhino.jstype.JSType jSType4 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray5 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType6 = jSTypeRegistry1.createConstructorTypeWithVarArgs(jSType4, jSTypeArray5);
        com.google.javascript.rhino.JSDocInfo jSDocInfo7 = functionType6.getJSDocInfo();
        boolean boolean8 = functionType6.isAllType();
        com.google.javascript.rhino.ErrorReporter errorReporter9 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry10 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter9);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable12 = jSTypeRegistry10.getEachReferenceTypeWithProperty("goog.global");
        com.google.javascript.rhino.jstype.JSType jSType13 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray14 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType15 = jSTypeRegistry10.createConstructorTypeWithVarArgs(jSType13, jSTypeArray14);
        int int16 = functionType15.getMaxArguments();
        boolean boolean17 = functionType6.isSubtype((com.google.javascript.rhino.jstype.JSType) functionType15);
        com.google.javascript.rhino.ErrorReporter errorReporter19 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry20 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter19);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable22 = jSTypeRegistry20.getEachReferenceTypeWithProperty("goog.global");
        com.google.javascript.rhino.jstype.JSType jSType23 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray24 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType25 = jSTypeRegistry20.createConstructorTypeWithVarArgs(jSType23, jSTypeArray24);
        com.google.javascript.rhino.JSDocInfo jSDocInfo26 = functionType25.getJSDocInfo();
        boolean boolean27 = functionType25.isAllType();
        int int28 = functionType25.getMaxArguments();
        com.google.javascript.rhino.Node node29 = com.google.javascript.rhino.IR.trueNode();
        java.lang.String str30 = node29.getSourceFileName();
        boolean boolean31 = node29.isOr();
        boolean boolean32 = functionType15.defineInferredProperty("hi!", (com.google.javascript.rhino.jstype.JSType) functionType25, node29);
        com.google.javascript.rhino.ErrorReporter errorReporter33 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry34 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter33);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable36 = jSTypeRegistry34.getEachReferenceTypeWithProperty("goog.global");
        com.google.javascript.rhino.jstype.JSType jSType37 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray38 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType39 = jSTypeRegistry34.createConstructorTypeWithVarArgs(jSType37, jSTypeArray38);
        com.google.javascript.rhino.JSDocInfo jSDocInfo40 = functionType39.getJSDocInfo();
        boolean boolean41 = functionType39.isAllType();
        int int42 = functionType39.getMaxArguments();
        com.google.javascript.rhino.Node node43 = functionType39.getParametersNode();
        boolean boolean44 = functionType15.differsFrom((com.google.javascript.rhino.jstype.JSType) functionType39);
        boolean boolean45 = functionType15.isRegexpType();
        boolean boolean46 = functionType15.isNumberObjectType();
        org.junit.Assert.assertNotNull(objectTypeIterable3);
        org.junit.Assert.assertNotNull(jSTypeArray5);
        org.junit.Assert.assertNotNull(functionType6);
        org.junit.Assert.assertNull(jSDocInfo7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(objectTypeIterable12);
        org.junit.Assert.assertNotNull(jSTypeArray14);
        org.junit.Assert.assertNotNull(functionType15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(objectTypeIterable22);
        org.junit.Assert.assertNotNull(jSTypeArray24);
        org.junit.Assert.assertNotNull(functionType25);
        org.junit.Assert.assertNull(jSDocInfo26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNull(str30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNotNull(objectTypeIterable36);
        org.junit.Assert.assertNotNull(jSTypeArray38);
        org.junit.Assert.assertNotNull(functionType39);
        org.junit.Assert.assertNull(jSDocInfo40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
        org.junit.Assert.assertNotNull(node43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable3 = jSTypeRegistry1.getEachReferenceTypeWithProperty("goog.global");
        com.google.javascript.rhino.jstype.JSType jSType4 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray5 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType6 = jSTypeRegistry1.createConstructorTypeWithVarArgs(jSType4, jSTypeArray5);
        com.google.javascript.rhino.ErrorReporter errorReporter7 = jSTypeRegistry1.getErrorReporter();
        com.google.javascript.rhino.ErrorReporter errorReporter8 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry9 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter8);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable11 = jSTypeRegistry9.getEachReferenceTypeWithProperty("goog.global");
        com.google.javascript.rhino.jstype.JSType jSType12 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray13 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType14 = jSTypeRegistry9.createConstructorTypeWithVarArgs(jSType12, jSTypeArray13);
        com.google.javascript.rhino.JSDocInfo jSDocInfo15 = functionType14.getJSDocInfo();
        com.google.javascript.rhino.ErrorReporter errorReporter16 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry17 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter16);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable19 = jSTypeRegistry17.getEachReferenceTypeWithProperty("goog.global");
        com.google.javascript.rhino.jstype.JSType jSType20 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray21 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType22 = jSTypeRegistry17.createConstructorTypeWithVarArgs(jSType20, jSTypeArray21);
        com.google.javascript.rhino.JSDocInfo jSDocInfo23 = functionType22.getJSDocInfo();
        boolean boolean24 = functionType22.isAllType();
        com.google.javascript.rhino.ErrorReporter errorReporter25 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry26 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter25);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable28 = jSTypeRegistry26.getEachReferenceTypeWithProperty("goog.global");
        com.google.javascript.rhino.jstype.JSType jSType29 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray30 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType31 = jSTypeRegistry26.createConstructorTypeWithVarArgs(jSType29, jSTypeArray30);
        int int32 = functionType31.getMaxArguments();
        boolean boolean33 = functionType22.isSubtype((com.google.javascript.rhino.jstype.JSType) functionType31);
        boolean boolean34 = functionType14.canTestForEqualityWith((com.google.javascript.rhino.jstype.JSType) functionType31);
        com.google.javascript.rhino.ErrorReporter errorReporter36 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry37 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter36);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable39 = jSTypeRegistry37.getEachReferenceTypeWithProperty("goog.global");
        com.google.javascript.rhino.jstype.JSType jSType40 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray41 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType42 = jSTypeRegistry37.createConstructorTypeWithVarArgs(jSType40, jSTypeArray41);
        com.google.javascript.rhino.jstype.FunctionType functionType43 = jSTypeRegistry1.createConstructorType((com.google.javascript.rhino.jstype.JSType) functionType14, true, jSTypeArray41);
        boolean boolean44 = functionType14.isFunctionPrototypeType();
        org.junit.Assert.assertNotNull(objectTypeIterable3);
        org.junit.Assert.assertNotNull(jSTypeArray5);
        org.junit.Assert.assertNotNull(functionType6);
        org.junit.Assert.assertNull(errorReporter7);
        org.junit.Assert.assertNotNull(objectTypeIterable11);
        org.junit.Assert.assertNotNull(jSTypeArray13);
        org.junit.Assert.assertNotNull(functionType14);
        org.junit.Assert.assertNull(jSDocInfo15);
        org.junit.Assert.assertNotNull(objectTypeIterable19);
        org.junit.Assert.assertNotNull(jSTypeArray21);
        org.junit.Assert.assertNotNull(functionType22);
        org.junit.Assert.assertNull(jSDocInfo23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(objectTypeIterable28);
        org.junit.Assert.assertNotNull(jSTypeArray30);
        org.junit.Assert.assertNotNull(functionType31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertNotNull(objectTypeIterable39);
        org.junit.Assert.assertNotNull(jSTypeArray41);
        org.junit.Assert.assertNotNull(functionType42);
        org.junit.Assert.assertNotNull(functionType43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.NodeTraversal.Callback callback2 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal3 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler1, callback2);
        int int4 = nodeTraversal3.getLineNumber();
        int int5 = nodeTraversal3.getLineNumber();
        com.google.javascript.jscomp.Scope scope6 = nodeTraversal3.getScope();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNull(scope6);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.trueNode();
        java.lang.String str1 = node0.getSourceFileName();
        boolean boolean2 = node0.isOr();
        node0.setLineno(16);
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        int int0 = com.google.javascript.rhino.Node.IS_NAMESPACE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 46 + "'", int0 == 46);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.stringKey("");
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable2 = node1.siblings();
        boolean boolean3 = node1.isIn();
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.IR.returnNode();
        boolean boolean5 = node4.isEmpty();
        int int6 = node4.getSourceOffset();
        boolean boolean7 = node4.isGetProp();
        boolean boolean8 = node4.isAssignAdd();
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.IR.returnNode();
        java.util.Set<java.lang.String> strSet10 = node9.getDirectives();
        int int11 = node9.getType();
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.IR.block();
        java.lang.String str16 = node12.toString(false, false, false);
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.IR.block();
        java.lang.String str21 = node17.toString(false, false, false);
        com.google.javascript.rhino.Node node22 = node12.useSourceInfoIfMissingFrom(node17);
        com.google.javascript.rhino.Node node23 = node9.useSourceInfoIfMissingFrom(node12);
        boolean boolean24 = node23.isRegExp();
        try {
            com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.IR.function(node1, node4, node23);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertNotNull(nodeIterable2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNull(strSet10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 4 + "'", int11 == 4);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "BLOCK" + "'", str16.equals("BLOCK"));
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "BLOCK" + "'", str21.equals("BLOCK"));
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup1 = com.google.javascript.jscomp.DiagnosticGroups.ACCESS_CONTROLS;
        com.google.javascript.jscomp.DiagnosticGroups.INTERNET_EXPLORER_CHECKS = diagnosticGroup1;
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup3 = com.google.javascript.jscomp.DiagnosticGroups.CHECK_REGEXP;
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup4 = com.google.javascript.jscomp.DiagnosticGroups.CHECK_REGEXP;
        com.google.javascript.jscomp.DiagnosticGroups.INVALID_CASTS = diagnosticGroup4;
        com.google.javascript.jscomp.DiagnosticGroups.DUPLICATE_MESSAGE = diagnosticGroup4;
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup7 = com.google.javascript.jscomp.DiagnosticGroups.ACCESS_CONTROLS;
        com.google.javascript.jscomp.DiagnosticGroups.UNDEFINED_NAMES = diagnosticGroup7;
        com.google.javascript.jscomp.DiagnosticGroup[] diagnosticGroupArray9 = new com.google.javascript.jscomp.DiagnosticGroup[] { diagnosticGroup1, diagnosticGroup3, diagnosticGroup4, diagnosticGroup7 };
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup10 = new com.google.javascript.jscomp.DiagnosticGroup("module$hi!", diagnosticGroupArray9);
        java.lang.String str11 = diagnosticGroup10.toString();
        org.junit.Assert.assertNotNull(diagnosticGroup1);
        org.junit.Assert.assertNotNull(diagnosticGroup3);
        org.junit.Assert.assertNotNull(diagnosticGroup4);
        org.junit.Assert.assertNotNull(diagnosticGroup7);
        org.junit.Assert.assertNotNull(diagnosticGroupArray9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "DiagnosticGroup<module$hi!>" + "'", str11.equals("DiagnosticGroup<module$hi!>"));
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        com.google.javascript.rhino.JSDocInfo jSDocInfo0 = new com.google.javascript.rhino.JSDocInfo();
        java.util.List<com.google.javascript.rhino.JSTypeExpression> jSTypeExpressionList1 = jSDocInfo0.getImplementedInterfaces();
        int int2 = jSDocInfo0.getExtendedInterfacesCount();
        boolean boolean4 = jSDocInfo0.hasDescriptionForParameter("2019/06/10 13:01");
        java.lang.String str5 = jSDocInfo0.getDescription();
        org.junit.Assert.assertNotNull(jSTypeExpressionList1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(str5);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.FUNCTION_PROTOTYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.FUNCTION_PROTOTYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.FUNCTION_PROTOTYPE));
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        com.google.javascript.rhino.JSDocInfo jSDocInfo0 = new com.google.javascript.rhino.JSDocInfo();
        boolean boolean1 = jSDocInfo0.isExterns();
        boolean boolean2 = jSDocInfo0.hasTypedefType();
        boolean boolean3 = jSDocInfo0.isNoAlias();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        java.lang.String str1 = com.google.javascript.rhino.ScriptRuntime.escapeString(".");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "." + "'", str1.equals("."));
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        com.google.javascript.jscomp.SourceAst sourceAst0 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(sourceAst0, "JSDocInfo", false);
        try {
            com.google.javascript.jscomp.Region region5 = compilerInput3.getRegion(47);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        com.google.javascript.rhino.JSDocInfo jSDocInfo0 = new com.google.javascript.rhino.JSDocInfo();
        java.util.List<com.google.javascript.rhino.JSTypeExpression> jSTypeExpressionList1 = jSDocInfo0.getImplementedInterfaces();
        java.util.Set<java.lang.String> strSet2 = jSDocInfo0.getSuppressions();
        java.util.Set<java.lang.String> strSet3 = jSDocInfo0.getSuppressions();
        java.util.Set<java.lang.String> strSet4 = jSDocInfo0.getSuppressions();
        com.google.javascript.rhino.JSDocInfo.Visibility visibility5 = null;
        jSDocInfo0.setVisibility(visibility5);
        org.junit.Assert.assertNotNull(jSTypeExpressionList1);
        org.junit.Assert.assertNotNull(strSet2);
        org.junit.Assert.assertNotNull(strSet3);
        org.junit.Assert.assertNotNull(strSet4);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        com.google.javascript.jscomp.SourceFile.Builder builder0 = com.google.javascript.jscomp.SourceFile.builder();
        org.junit.Assert.assertNotNull(builder0);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeUnusedPrototypePropertiesInExterns = true;
        byte[] byteArray6 = new byte[] { (byte) 0, (byte) -1, (byte) 10 };
        compilerOptions0.inputPropertyMapSerialized = byteArray6;
        com.google.javascript.jscomp.CompilerOptions.TweakProcessing tweakProcessing8 = compilerOptions0.getTweakProcessing();
        compilerOptions0.syntheticBlockEndMarker = "(BLOCK)";
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertTrue("'" + tweakProcessing8 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TweakProcessing.OFF + "'", tweakProcessing8.equals(com.google.javascript.jscomp.CompilerOptions.TweakProcessing.OFF));
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable3 = jSTypeRegistry1.getEachReferenceTypeWithProperty("goog.global");
        com.google.javascript.rhino.jstype.JSType jSType4 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray5 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType6 = jSTypeRegistry1.createConstructorTypeWithVarArgs(jSType4, jSTypeArray5);
        com.google.javascript.rhino.JSDocInfo jSDocInfo7 = functionType6.getJSDocInfo();
        boolean boolean8 = functionType6.isAllType();
        com.google.javascript.rhino.ErrorReporter errorReporter9 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry10 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter9);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable12 = jSTypeRegistry10.getEachReferenceTypeWithProperty("goog.global");
        com.google.javascript.rhino.jstype.JSType jSType13 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray14 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType15 = jSTypeRegistry10.createConstructorTypeWithVarArgs(jSType13, jSTypeArray14);
        int int16 = functionType15.getMaxArguments();
        boolean boolean17 = functionType6.isSubtype((com.google.javascript.rhino.jstype.JSType) functionType15);
        com.google.javascript.rhino.ErrorReporter errorReporter18 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry19 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter18);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable21 = jSTypeRegistry19.getEachReferenceTypeWithProperty("goog.global");
        com.google.javascript.rhino.jstype.JSType jSType22 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray23 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType24 = jSTypeRegistry19.createConstructorTypeWithVarArgs(jSType22, jSTypeArray23);
        com.google.javascript.rhino.JSDocInfo jSDocInfo25 = functionType24.getJSDocInfo();
        boolean boolean26 = functionType24.isAllType();
        com.google.javascript.rhino.ErrorReporter errorReporter27 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry28 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter27);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable30 = jSTypeRegistry28.getEachReferenceTypeWithProperty("goog.global");
        com.google.javascript.rhino.jstype.JSType jSType31 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray32 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType33 = jSTypeRegistry28.createConstructorTypeWithVarArgs(jSType31, jSTypeArray32);
        int int34 = functionType33.getMaxArguments();
        boolean boolean35 = functionType24.isSubtype((com.google.javascript.rhino.jstype.JSType) functionType33);
        com.google.javascript.rhino.ErrorReporter errorReporter37 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry38 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter37);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable40 = jSTypeRegistry38.getEachReferenceTypeWithProperty("goog.global");
        com.google.javascript.rhino.jstype.JSType jSType41 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray42 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType43 = jSTypeRegistry38.createConstructorTypeWithVarArgs(jSType41, jSTypeArray42);
        com.google.javascript.rhino.JSDocInfo jSDocInfo44 = functionType43.getJSDocInfo();
        boolean boolean45 = functionType43.isAllType();
        int int46 = functionType43.getMaxArguments();
        com.google.javascript.rhino.Node node47 = com.google.javascript.rhino.IR.trueNode();
        java.lang.String str48 = node47.getSourceFileName();
        boolean boolean49 = node47.isOr();
        boolean boolean50 = functionType33.defineInferredProperty("hi!", (com.google.javascript.rhino.jstype.JSType) functionType43, node47);
        com.google.javascript.rhino.jstype.ParameterizedType parameterizedType51 = functionType43.toMaybeParameterizedType();
        boolean boolean52 = functionType43.hasAnyTemplateInternal();
        com.google.javascript.rhino.jstype.JSType.TypePair typePair53 = functionType15.getTypesUnderInequality((com.google.javascript.rhino.jstype.JSType) functionType43);
        com.google.javascript.rhino.jstype.ParameterizedType parameterizedType54 = functionType15.toMaybeParameterizedType();
        org.junit.Assert.assertNotNull(objectTypeIterable3);
        org.junit.Assert.assertNotNull(jSTypeArray5);
        org.junit.Assert.assertNotNull(functionType6);
        org.junit.Assert.assertNull(jSDocInfo7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(objectTypeIterable12);
        org.junit.Assert.assertNotNull(jSTypeArray14);
        org.junit.Assert.assertNotNull(functionType15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(objectTypeIterable21);
        org.junit.Assert.assertNotNull(jSTypeArray23);
        org.junit.Assert.assertNotNull(functionType24);
        org.junit.Assert.assertNull(jSDocInfo25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(objectTypeIterable30);
        org.junit.Assert.assertNotNull(jSTypeArray32);
        org.junit.Assert.assertNotNull(functionType33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertNotNull(objectTypeIterable40);
        org.junit.Assert.assertNotNull(jSTypeArray42);
        org.junit.Assert.assertNotNull(functionType43);
        org.junit.Assert.assertNull(jSDocInfo44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 0 + "'", int46 == 0);
        org.junit.Assert.assertNotNull(node47);
        org.junit.Assert.assertNull(str48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + true + "'", boolean50 == true);
        org.junit.Assert.assertNull(parameterizedType51);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertNotNull(typePair53);
        org.junit.Assert.assertNull(parameterizedType54);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.computeFunctionSideEffects = true;
        boolean boolean3 = compilerOptions0.ideMode;
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention4 = new com.google.javascript.jscomp.GoogleCodingConvention();
        compilerOptions0.setCodingConvention((com.google.javascript.jscomp.CodingConvention) googleCodingConvention4);
        com.google.javascript.jscomp.CompilerOptions compilerOptions6 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions6.computeFunctionSideEffects = true;
        boolean boolean9 = compilerOptions6.isRemoveUnusedClassProperties();
        com.google.javascript.jscomp.ErrorHandler errorHandler10 = null;
        compilerOptions6.setErrorHandler(errorHandler10);
        java.util.List<com.google.javascript.jscomp.SourceMap.LocationMapping> locationMappingList12 = compilerOptions6.sourceMapLocationMappings;
        com.google.javascript.jscomp.CheckLevel checkLevel13 = com.google.javascript.jscomp.CheckLevel.ERROR;
        compilerOptions6.setCheckProvides(checkLevel13);
        compilerOptions0.setReportMissingOverride(checkLevel13);
        java.util.Set<java.lang.String> strSet16 = null;
        compilerOptions0.stripNameSuffixes = strSet16;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(locationMappingList12);
        org.junit.Assert.assertTrue("'" + checkLevel13 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel13.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeUnusedPrototypePropertiesInExterns = true;
        java.util.Map<java.lang.String, java.lang.Object> strMap3 = null;
        compilerOptions0.setTweakReplacements(strMap3);
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy5 = null;
        compilerOptions0.variableRenaming = variableRenamingPolicy5;
        compilerOptions0.computeFunctionSideEffects = false;
        java.util.Set<java.lang.String> strSet9 = null;
        compilerOptions0.stripTypes = strSet9;
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.IR.stringKey("");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.IR.stringKey("");
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.IR.block();
        com.google.javascript.rhino.Node node8 = new com.google.javascript.rhino.Node((int) ' ', node2, node4, node5, 0, (int) (short) -1);
        boolean boolean9 = node5.isBreak();
        try {
            com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.IR.voidNode(node5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }
}

