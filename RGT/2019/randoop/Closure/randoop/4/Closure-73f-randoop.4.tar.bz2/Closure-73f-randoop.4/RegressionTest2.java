import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest2 {

    public static boolean debug = false;

    @Test
    public void test01() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01");
        com.google.javascript.rhino.EcmaError ecmaError1 = com.google.javascript.rhino.ScriptRuntime.typeError("4");
        java.lang.String str2 = ecmaError1.getName();
        java.lang.String str3 = ecmaError1.lineSource();
        java.lang.String str4 = ecmaError1.toString();
        java.lang.String str5 = ecmaError1.lineSource();
        java.lang.String str6 = ecmaError1.getSourceName();
        int int7 = ecmaError1.lineNumber();
        org.junit.Assert.assertNotNull(ecmaError1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "TypeError" + "'", str2.equals("TypeError"));
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "com.google.javascript.rhino.EcmaError: TypeError: 4" + "'", str4.equals("com.google.javascript.rhino.EcmaError: TypeError: 4"));
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
    }

    @Test
    public void test02() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test02");
        com.google.javascript.rhino.Node node1 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node3 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node5 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node7 = new com.google.javascript.rhino.Node((int) '4');
        node5.addChildrenToBack(node7);
        node1.addChildAfter(node3, node7);
        com.google.javascript.rhino.Node node11 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node((int) '4');
        node11.addChildrenToBack(node13);
        com.google.javascript.rhino.Node node15 = node1.copyInformationFromForTree(node13);
        com.google.javascript.rhino.Node node17 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node18 = node1.copyInformationFromForTree(node17);
        com.google.javascript.rhino.Node node20 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node22 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node24 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node26 = new com.google.javascript.rhino.Node((int) '4');
        node24.addChildrenToBack(node26);
        node20.addChildAfter(node22, node26);
        com.google.javascript.rhino.Node node30 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node32 = new com.google.javascript.rhino.Node((int) '4');
        node30.addChildrenToBack(node32);
        com.google.javascript.rhino.Node node34 = node20.copyInformationFromForTree(node32);
        com.google.javascript.rhino.jstype.JSType jSType35 = null;
        node34.setJSType(jSType35);
        com.google.javascript.rhino.Node node38 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node40 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node42 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node44 = new com.google.javascript.rhino.Node((int) '4');
        node42.addChildrenToBack(node44);
        node38.addChildAfter(node40, node44);
        com.google.javascript.rhino.Node node48 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node50 = new com.google.javascript.rhino.Node((int) '4');
        node48.addChildrenToBack(node50);
        com.google.javascript.rhino.Node node52 = node38.copyInformationFromForTree(node50);
        node17.addChildAfter(node34, node50);
        node17.setSourcePositionForTree(8);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNotNull(node34);
        org.junit.Assert.assertNotNull(node52);
    }

    @Test
    public void test03() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test03");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setLooseTypes(true);
        compilerOptions0.convertToDottedProperties = false;
        com.google.javascript.jscomp.CheckLevel checkLevel5 = compilerOptions0.reportMissingOverride;
        boolean boolean6 = compilerOptions0.aliasAllStrings;
        compilerOptions0.instrumentationTemplate = "hi!";
        boolean boolean9 = compilerOptions0.exportTestFunctions;
        java.util.Map<java.lang.String, com.google.javascript.rhino.Node> strMap10 = compilerOptions0.getDefineReplacements();
        boolean boolean11 = compilerOptions0.flowSensitiveInlineVariables;
        boolean boolean12 = compilerOptions0.ideMode;
        com.google.javascript.jscomp.CompilerOptions compilerOptions13 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions13.setLooseTypes(true);
        boolean boolean16 = compilerOptions13.reserveRawExports;
        compilerOptions13.extractPrototypeMemberDeclarations = false;
        boolean boolean19 = compilerOptions13.disambiguateProperties;
        com.google.javascript.jscomp.CheckLevel checkLevel20 = compilerOptions13.aggressiveVarCheck;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap21 = compilerOptions13.cssRenamingMap;
        com.google.javascript.jscomp.SourceMap.Format format22 = compilerOptions13.sourceMapFormat;
        compilerOptions0.sourceMapFormat = format22;
        compilerOptions0.setChainCalls(false);
        org.junit.Assert.assertTrue("'" + checkLevel5 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel5.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(strMap10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + checkLevel20 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel20.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNull(cssRenamingMap21);
        org.junit.Assert.assertNotNull(format22);
    }

    @Test
    public void test04() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test04");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.flowSensitiveInlineVariables = false;
        compilerOptions0.optimizeCalls = true;
        com.google.javascript.jscomp.CheckLevel checkLevel5 = compilerOptions0.checkGlobalNamesLevel;
        compilerOptions0.nameReferenceReportPath = "DiagnosticGroup<strictModuleDepCheck>";
        org.junit.Assert.assertTrue("'" + checkLevel5 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel5.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test05() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test05");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeUnusedPrototypePropertiesInExterns = false;
        compilerOptions0.removeUnusedLocalVars = false;
        compilerOptions0.skipAllCompilerPasses();
        compilerOptions0.removeUnusedLocalVars = true;
        com.google.javascript.jscomp.CheckLevel checkLevel8 = compilerOptions0.checkShadowVars;
        org.junit.Assert.assertTrue("'" + checkLevel8 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel8.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

//    @Test
//    public void test06() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test06");
//        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.STRICT_MODULE_DEP_CHECK;
//        com.google.javascript.rhino.Node node3 = new com.google.javascript.rhino.Node((int) '4');
//        com.google.javascript.rhino.Node node5 = new com.google.javascript.rhino.Node((int) '4');
//        com.google.javascript.rhino.Node node7 = new com.google.javascript.rhino.Node((int) '4');
//        com.google.javascript.rhino.Node node9 = new com.google.javascript.rhino.Node((int) '4');
//        node7.addChildrenToBack(node9);
//        node3.addChildAfter(node5, node9);
//        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node((int) '4');
//        com.google.javascript.rhino.Node node15 = new com.google.javascript.rhino.Node((int) '4');
//        node13.addChildrenToBack(node15);
//        com.google.javascript.rhino.Node node17 = node3.copyInformationFromForTree(node15);
//        com.google.javascript.jscomp.DiagnosticType diagnosticType18 = com.google.javascript.jscomp.Compiler.MOTION_ITERATIONS_ERROR;
//        java.lang.String str19 = diagnosticType18.toString();
//        java.lang.String[] strArray20 = null;
//        com.google.javascript.jscomp.JSError jSError21 = com.google.javascript.jscomp.JSError.make("", node15, diagnosticType18, strArray20);
//        java.lang.String str22 = jSError21.description;
//        java.lang.String str23 = jSError21.toString();
//        try {
//            boolean boolean24 = diagnosticGroup0.matches(jSError21);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNull(diagnosticGroup0);
//        org.junit.Assert.assertNotNull(node17);
//        org.junit.Assert.assertNotNull(diagnosticType18);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}" + "'", str19.equals("JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}"));
//        org.junit.Assert.assertNotNull(jSError21);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "Exceeded max number of code motion iterations: {0}" + "'", str22.equals("Exceeded max number of code motion iterations: {0}"));
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "JSC_OPTIMIZE_LOOP_ERROR. Exceeded max number of code motion iterations: {0} at (unknown source) line (unknown line) : (unknown column)" + "'", str23.equals("JSC_OPTIMIZE_LOOP_ERROR. Exceeded max number of code motion iterations: {0} at (unknown source) line (unknown line) : (unknown column)"));
//    }

    @Test
    public void test07() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test07");
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention0 = new com.google.javascript.jscomp.DefaultCodingConvention();
        boolean boolean2 = defaultCodingConvention0.isExported("// Input %num%");
        com.google.javascript.rhino.Node node4 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node6 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node8 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node10 = new com.google.javascript.rhino.Node((int) '4');
        node8.addChildrenToBack(node10);
        node4.addChildAfter(node6, node10);
        com.google.javascript.rhino.Node node14 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node16 = new com.google.javascript.rhino.Node((int) '4');
        node14.addChildrenToBack(node16);
        com.google.javascript.rhino.Node node18 = node4.copyInformationFromForTree(node16);
        com.google.javascript.rhino.Node node19 = node4.cloneTree();
        com.google.javascript.rhino.Node node23 = new com.google.javascript.rhino.Node(30, 35, 8);
        com.google.javascript.rhino.Node node24 = node23.getLastChild();
        node19.addChildToFront(node23);
        java.lang.String str26 = defaultCodingConvention0.getSingletonGetterClassName(node23);
        boolean boolean29 = defaultCodingConvention0.isExported("error reporter", false);
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry30 = null;
        com.google.javascript.jscomp.Scope scope31 = null;
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention32 = new com.google.javascript.jscomp.DefaultCodingConvention();
        java.lang.String str33 = defaultCodingConvention32.getDelegateSuperclassName();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry34 = null;
        com.google.javascript.jscomp.Scope scope35 = null;
        com.google.javascript.rhino.jstype.ObjectType[] objectTypeArray36 = new com.google.javascript.rhino.jstype.ObjectType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.ObjectType> objectTypeList37 = new java.util.ArrayList<com.google.javascript.rhino.jstype.ObjectType>();
        boolean boolean38 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.ObjectType>) objectTypeList37, objectTypeArray36);
        defaultCodingConvention32.defineDelegateProxyPrototypeProperties(jSTypeRegistry34, scope35, (java.util.List<com.google.javascript.rhino.jstype.ObjectType>) objectTypeList37);
        defaultCodingConvention0.defineDelegateProxyPrototypeProperties(jSTypeRegistry30, scope31, (java.util.List<com.google.javascript.rhino.jstype.ObjectType>) objectTypeList37);
        com.google.javascript.rhino.Node node42 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node44 = new com.google.javascript.rhino.Node((int) '4');
        node42.addChildrenToBack(node44);
        com.google.javascript.rhino.Node node46 = node42.getLastChild();
        node42.setLineno(7);
        com.google.javascript.rhino.Node node50 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node52 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node54 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node56 = new com.google.javascript.rhino.Node((int) '4');
        node54.addChildrenToBack(node56);
        node50.addChildAfter(node52, node56);
        com.google.javascript.rhino.Node node60 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node62 = new com.google.javascript.rhino.Node((int) '4');
        node60.addChildrenToBack(node62);
        com.google.javascript.rhino.Node node64 = node50.copyInformationFromForTree(node62);
        com.google.javascript.rhino.Node node66 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node67 = node50.copyInformationFromForTree(node66);
        boolean boolean68 = node66.isQualifiedName();
        com.google.javascript.rhino.Node node70 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node72 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node74 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node76 = new com.google.javascript.rhino.Node((int) '4');
        node74.addChildrenToBack(node76);
        node70.addChildAfter(node72, node76);
        com.google.javascript.rhino.Node node80 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node82 = new com.google.javascript.rhino.Node((int) '4');
        node80.addChildrenToBack(node82);
        com.google.javascript.rhino.Node node84 = node70.copyInformationFromForTree(node82);
        node42.addChildAfter(node66, node82);
        java.lang.String str86 = defaultCodingConvention0.getSingletonGetterClassName(node66);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNull(node24);
        org.junit.Assert.assertNull(str26);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNull(str33);
        org.junit.Assert.assertNotNull(objectTypeArray36);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(node46);
        org.junit.Assert.assertNotNull(node64);
        org.junit.Assert.assertNotNull(node67);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertNotNull(node84);
        org.junit.Assert.assertNull(str86);
    }

    @Test
    public void test08() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test08");
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention0 = new com.google.javascript.jscomp.DefaultCodingConvention();
        boolean boolean2 = defaultCodingConvention0.isExported("// Input %num%");
        boolean boolean4 = defaultCodingConvention0.isSuperClassReference("");
        com.google.javascript.rhino.Node node6 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node8 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node10 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node12 = new com.google.javascript.rhino.Node((int) '4');
        node10.addChildrenToBack(node12);
        node6.addChildAfter(node8, node12);
        boolean boolean15 = node8.wasEmptyNode();
        java.lang.String str16 = defaultCodingConvention0.identifyTypeDefAssign(node8);
        boolean boolean19 = defaultCodingConvention0.isExported("Exceeded max number of code motion iterations: {0}", false);
        java.lang.String str20 = defaultCodingConvention0.getGlobalObject();
        java.lang.String str21 = defaultCodingConvention0.getAbstractMethodName();
        boolean boolean24 = defaultCodingConvention0.isExported("33", false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "window" + "'", str20.equals("window"));
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test09() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test09");
        com.google.javascript.rhino.Node node1 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node3 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node5 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node7 = new com.google.javascript.rhino.Node((int) '4');
        node5.addChildrenToBack(node7);
        node1.addChildAfter(node3, node7);
        com.google.javascript.rhino.Node node11 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node((int) '4');
        node11.addChildrenToBack(node13);
        com.google.javascript.rhino.Node node15 = node1.copyInformationFromForTree(node13);
        com.google.javascript.rhino.Node node16 = node15.getLastChild();
        com.google.javascript.rhino.Node node18 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node20 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node22 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node24 = new com.google.javascript.rhino.Node((int) '4');
        node22.addChildrenToBack(node24);
        node18.addChildAfter(node20, node24);
        com.google.javascript.rhino.Node node28 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node30 = new com.google.javascript.rhino.Node((int) '4');
        node28.addChildrenToBack(node30);
        com.google.javascript.rhino.Node node32 = node18.copyInformationFromForTree(node30);
        node15.addChildToBack(node18);
        com.google.javascript.rhino.Node node35 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node37 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node39 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node41 = new com.google.javascript.rhino.Node((int) '4');
        node39.addChildrenToBack(node41);
        node35.addChildAfter(node37, node41);
        com.google.javascript.rhino.Node node45 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node47 = new com.google.javascript.rhino.Node((int) '4');
        node45.addChildrenToBack(node47);
        com.google.javascript.rhino.Node node49 = node35.copyInformationFromForTree(node47);
        com.google.javascript.rhino.jstype.JSType jSType50 = null;
        node49.setJSType(jSType50);
        node15.addChildToFront(node49);
        node15.setIsSyntheticBlock(false);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertNull(node16);
        org.junit.Assert.assertNotNull(node32);
        org.junit.Assert.assertNotNull(node49);
    }

    @Test
    public void test10() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test10");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        java.io.PrintStream printStream2 = null;
        com.google.javascript.jscomp.Compiler compiler3 = new com.google.javascript.jscomp.Compiler(printStream2);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile6 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        java.io.Reader reader7 = jSSourceFile6.getCodeReader();
        com.google.javascript.jscomp.JSModule[] jSModuleArray8 = new com.google.javascript.jscomp.JSModule[] {};
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph9 = new com.google.javascript.jscomp.JSModuleGraph(jSModuleArray8);
        com.google.javascript.jscomp.CompilerOptions compilerOptions10 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions10.setLooseTypes(true);
        boolean boolean13 = compilerOptions10.collapseVariableDeclarations;
        compilerOptions10.moveFunctionDeclarations = false;
        boolean boolean16 = compilerOptions10.decomposeExpressions;
        com.google.javascript.jscomp.CheckLevel checkLevel17 = compilerOptions10.checkMissingGetCssNameLevel;
        com.google.javascript.jscomp.Result result18 = compiler3.compile(jSSourceFile6, jSModuleArray8, compilerOptions10);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile21 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile24 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        java.io.Reader reader25 = jSSourceFile24.getCodeReader();
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray26 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile6, jSSourceFile21, jSSourceFile24 };
        java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList27 = new java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile>();
        boolean boolean28 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList27, jSSourceFileArray26);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile31 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray32 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile31 };
        java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList33 = new java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile>();
        boolean boolean34 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList33, jSSourceFileArray32);
        com.google.javascript.jscomp.CompilerOptions compilerOptions35 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions35.setLooseTypes(true);
        boolean boolean38 = compilerOptions35.reserveRawExports;
        compilerOptions35.extractPrototypeMemberDeclarations = false;
        java.lang.String str41 = compilerOptions35.nameReferenceGraphPath;
        compilerOptions35.setSummaryDetailLevel(0);
        com.google.javascript.jscomp.Result result44 = compiler1.compile((java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList27, (java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList33, compilerOptions35);
        boolean boolean45 = compiler1.hasErrors();
        com.google.javascript.jscomp.Region region48 = compiler1.getSourceRegion("<No stack trace available>", 15);
        org.junit.Assert.assertNotNull(jSSourceFile6);
        org.junit.Assert.assertNotNull(reader7);
        org.junit.Assert.assertNotNull(jSModuleArray8);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + checkLevel17 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel17.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(result18);
        org.junit.Assert.assertNotNull(jSSourceFile21);
        org.junit.Assert.assertNotNull(jSSourceFile24);
        org.junit.Assert.assertNotNull(reader25);
        org.junit.Assert.assertNotNull(jSSourceFileArray26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(jSSourceFile31);
        org.junit.Assert.assertNotNull(jSSourceFileArray32);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNull(str41);
        org.junit.Assert.assertNotNull(result44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
        org.junit.Assert.assertNull(region48);
    }

    @Test
    public void test11() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test11");
        com.google.javascript.jscomp.SourceAst sourceAst0 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(sourceAst0, "", false);
        boolean boolean4 = compilerInput3.isExtern();
        java.lang.String str5 = compilerInput3.getName();
        com.google.javascript.jscomp.JSModule jSModule6 = compilerInput3.getModule();
        try {
            java.lang.String str7 = compilerInput3.getCode();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertNull(jSModule6);
    }

    @Test
    public void test12() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test12");
        com.google.javascript.rhino.Node node1 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node3 = new com.google.javascript.rhino.Node((int) '4');
        node1.addChildrenToBack(node3);
        node1.detachChildren();
        try {
            node1.setDouble((double) 49);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: INSTANCEOF is not a string node");
        } catch (java.lang.UnsupportedOperationException e) {
        }
    }

    @Test
    public void test13() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test13");
        com.google.javascript.rhino.Node.SideEffectFlags sideEffectFlags1 = new com.google.javascript.rhino.Node.SideEffectFlags(30);
        sideEffectFlags1.setReturnsTainted();
        sideEffectFlags1.setThrows();
    }

    @Test
    public void test14() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test14");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        compiler1.disableThreads();
        com.google.javascript.jscomp.PerformanceTracker performanceTracker3 = compiler1.tracker;
        compiler1.disableThreads();
        com.google.javascript.jscomp.PerformanceTracker performanceTracker5 = compiler1.tracker;
        com.google.javascript.rhino.Node node7 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node9 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node11 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node((int) '4');
        node11.addChildrenToBack(node13);
        node7.addChildAfter(node9, node13);
        com.google.javascript.rhino.Node node17 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node19 = new com.google.javascript.rhino.Node((int) '4');
        node17.addChildrenToBack(node19);
        com.google.javascript.rhino.Node node21 = node7.copyInformationFromForTree(node19);
        java.util.Set<java.lang.String> strSet22 = node19.getDirectives();
        com.google.javascript.jscomp.NodeTraversal.Callback callback23 = null;
        try {
            com.google.javascript.jscomp.NodeTraversal.traverse((com.google.javascript.jscomp.AbstractCompiler) compiler1, node19, callback23);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: INTERNAL COMPILER ERROR.\nPlease report this problem.\nnull");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNull(performanceTracker3);
        org.junit.Assert.assertNull(performanceTracker5);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertNull(strSet22);
    }

    @Test
    public void test15() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test15");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile3 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        java.io.Reader reader4 = jSSourceFile3.getCodeReader();
        com.google.javascript.jscomp.SourceFile sourceFile5 = com.google.javascript.jscomp.SourceFile.fromReader("Not declared as a type name", reader4);
        java.io.Reader reader6 = sourceFile5.getCodeReader();
        java.lang.String str7 = sourceFile5.getOriginalPath();
        org.junit.Assert.assertNotNull(jSSourceFile3);
        org.junit.Assert.assertNotNull(reader4);
        org.junit.Assert.assertNotNull(sourceFile5);
        org.junit.Assert.assertNotNull(reader6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Not declared as a type name" + "'", str7.equals("Not declared as a type name"));
    }

    @Test
    public void test16() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test16");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setLooseTypes(true);
        compilerOptions0.convertToDottedProperties = false;
        com.google.javascript.jscomp.CheckLevel checkLevel5 = compilerOptions0.reportMissingOverride;
        boolean boolean6 = compilerOptions0.aliasAllStrings;
        compilerOptions0.instrumentationTemplate = "hi!";
        boolean boolean9 = compilerOptions0.exportTestFunctions;
        com.google.javascript.jscomp.CheckLevel checkLevel10 = compilerOptions0.checkShadowVars;
        boolean boolean11 = compilerOptions0.generatePseudoNames;
        org.junit.Assert.assertTrue("'" + checkLevel5 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel5.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + checkLevel10 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel10.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test17() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test17");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setLooseTypes(true);
        boolean boolean3 = compilerOptions0.reserveRawExports;
        com.google.javascript.jscomp.CheckLevel checkLevel4 = null;
        compilerOptions0.checkUnreachableCode = checkLevel4;
        com.google.javascript.jscomp.MessageBundle messageBundle6 = compilerOptions0.messageBundle;
        java.lang.String str7 = compilerOptions0.sourceMapOutputPath;
        compilerOptions0.aliasKeywords = true;
        boolean boolean10 = compilerOptions0.checkUnusedPropertiesEarly;
        com.google.javascript.jscomp.CheckLevel checkLevel11 = compilerOptions0.checkProvides;
        boolean boolean12 = compilerOptions0.aliasExternals;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(messageBundle6);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + checkLevel11 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel11.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test18() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test18");
        java.io.InputStream inputStream2 = null;
        try {
            com.google.javascript.jscomp.SourceFile sourceFile3 = com.google.javascript.jscomp.SourceFile.fromInputStream("error reporter", "(<No stack trace available>)", inputStream2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test19() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test19");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setLooseTypes(true);
        boolean boolean3 = compilerOptions0.reserveRawExports;
        boolean boolean4 = compilerOptions0.flowSensitiveInlineVariables;
        compilerOptions0.rewriteFunctionExpressions = true;
        java.io.PrintStream printStream7 = null;
        com.google.javascript.jscomp.Compiler compiler8 = new com.google.javascript.jscomp.Compiler(printStream7);
        compiler8.disableThreads();
        com.google.javascript.jscomp.PerformanceTracker performanceTracker10 = compiler8.tracker;
        com.google.javascript.jscomp.NodeTraversal.Callback callback11 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal12 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler8, callback11);
        com.google.javascript.rhino.Node node14 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node16 = new com.google.javascript.rhino.Node((int) '4');
        node14.addChildrenToBack(node16);
        com.google.javascript.jscomp.DiagnosticType diagnosticType20 = com.google.javascript.jscomp.DiagnosticType.warning("hi!", "hi!");
        com.google.javascript.jscomp.DiagnosticType diagnosticType21 = com.google.javascript.jscomp.Compiler.MOTION_ITERATIONS_ERROR;
        int int22 = diagnosticType20.compareTo(diagnosticType21);
        java.lang.String[] strArray23 = com.google.javascript.rhino.ScriptRuntime.emptyStrings;
        com.google.javascript.jscomp.JSError jSError24 = nodeTraversal12.makeError(node16, diagnosticType20, strArray23);
        com.google.javascript.jscomp.CompilerOptions compilerOptions25 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions25.setLooseTypes(true);
        boolean boolean28 = compilerOptions25.collapseVariableDeclarations;
        boolean boolean29 = compilerOptions25.generateExports;
        com.google.javascript.jscomp.SourceMap.DetailLevel detailLevel30 = compilerOptions25.sourceMapDetailLevel;
        com.google.javascript.jscomp.CheckLevel checkLevel31 = null;
        compilerOptions25.brokenClosureRequiresLevel = checkLevel31;
        java.util.Set<java.lang.String> strSet33 = compilerOptions25.aliasableStrings;
        java.lang.RuntimeException runtimeException34 = com.google.javascript.rhino.ScriptRuntime.undefWriteError((java.lang.Object) compilerOptions0, (java.lang.Object) strArray23, (java.lang.Object) compilerOptions25);
        compilerOptions25.checkEs5Strict = false;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(performanceTracker10);
        org.junit.Assert.assertNotNull(diagnosticType20);
        org.junit.Assert.assertNotNull(diagnosticType21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 30 + "'", int22 == 30);
        org.junit.Assert.assertNotNull(strArray23);
        org.junit.Assert.assertNotNull(jSError24);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(detailLevel30);
        org.junit.Assert.assertNotNull(strSet33);
        org.junit.Assert.assertNotNull(runtimeException34);
    }

    @Test
    public void test20() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test20");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        java.util.Collection<com.google.javascript.jscomp.CodingConvention.AssertionFunctionSpec> assertionFunctionSpecCollection1 = closureCodingConvention0.getAssertionFunctions();
        java.lang.String str2 = closureCodingConvention0.getGlobalObject();
        com.google.javascript.rhino.Node node4 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node6 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node8 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node10 = new com.google.javascript.rhino.Node((int) '4');
        node8.addChildrenToBack(node10);
        node4.addChildAfter(node6, node10);
        com.google.javascript.rhino.Node node14 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node16 = new com.google.javascript.rhino.Node((int) '4');
        node14.addChildrenToBack(node16);
        com.google.javascript.rhino.Node node18 = node4.copyInformationFromForTree(node16);
        com.google.javascript.rhino.Node node20 = node4.getAncestor(1);
        boolean boolean21 = closureCodingConvention0.isOptionalParameter(node20);
        java.lang.String str22 = closureCodingConvention0.getAbstractMethodName();
        java.lang.String str23 = closureCodingConvention0.getDelegateSuperclassName();
        boolean boolean25 = closureCodingConvention0.isExported("(language version)");
        boolean boolean27 = closureCodingConvention0.isConstantKey("");
        org.junit.Assert.assertNotNull(assertionFunctionSpecCollection1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "goog.global" + "'", str2.equals("goog.global"));
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNull(node20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "goog.abstractMethod" + "'", str22.equals("goog.abstractMethod"));
        org.junit.Assert.assertNull(str23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
    }

    @Test
    public void test21() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test21");
        com.google.javascript.rhino.Node node1 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node3 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node5 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node7 = new com.google.javascript.rhino.Node((int) '4');
        node5.addChildrenToBack(node7);
        node1.addChildAfter(node3, node7);
        com.google.javascript.rhino.Node node10 = node1.cloneTree();
        boolean boolean11 = node10.isNoSideEffectsCall();
        com.google.javascript.rhino.JSDocInfo jSDocInfo12 = node10.getJSDocInfo();
        node10.setSourcePositionForTree(130);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNull(jSDocInfo12);
    }

    @Test
    public void test22() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test22");
        com.google.javascript.jscomp.CompilerOptions compilerOptions1 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions1.setLooseTypes(true);
        boolean boolean4 = compilerOptions1.collapseVariableDeclarations;
        compilerOptions1.moveFunctionDeclarations = false;
        boolean boolean7 = compilerOptions1.decomposeExpressions;
        boolean boolean8 = compilerOptions1.optimizeParameters;
        java.lang.String str9 = compilerOptions1.inputDelimiter;
        com.google.javascript.jscomp.ErrorFormat errorFormat10 = com.google.javascript.jscomp.ErrorFormat.LEGACY;
        java.lang.RuntimeException runtimeException11 = com.google.javascript.rhino.ScriptRuntime.undefWriteError((java.lang.Object) (short) 100, (java.lang.Object) str9, (java.lang.Object) errorFormat10);
        java.io.PrintStream printStream12 = null;
        com.google.javascript.jscomp.Compiler compiler13 = new com.google.javascript.jscomp.Compiler(printStream12);
        compiler13.disableThreads();
        com.google.javascript.jscomp.PerformanceTracker performanceTracker15 = compiler13.tracker;
        com.google.javascript.jscomp.MessageFormatter messageFormatter17 = errorFormat10.toFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler13, false);
        com.google.javascript.rhino.Node node18 = compiler13.getRoot();
        com.google.javascript.rhino.Node node19 = compiler13.getRoot();
        com.google.javascript.jscomp.ErrorManager errorManager20 = compiler13.getErrorManager();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "// Input %num%" + "'", str9.equals("// Input %num%"));
        org.junit.Assert.assertNotNull(errorFormat10);
        org.junit.Assert.assertNotNull(runtimeException11);
        org.junit.Assert.assertNull(performanceTracker15);
        org.junit.Assert.assertNotNull(messageFormatter17);
        org.junit.Assert.assertNull(node18);
        org.junit.Assert.assertNull(node19);
        org.junit.Assert.assertNotNull(errorManager20);
    }

    @Test
    public void test23() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test23");
        java.util.logging.Logger logger0 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager1 = new com.google.javascript.jscomp.LoggerErrorManager(logger0);
        com.google.javascript.jscomp.CompilerOptions compilerOptions2 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions2.setLooseTypes(true);
        compilerOptions2.convertToDottedProperties = false;
        com.google.javascript.jscomp.CheckLevel checkLevel7 = compilerOptions2.reportUnknownTypes;
        com.google.javascript.rhino.Node node10 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node12 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node14 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node16 = new com.google.javascript.rhino.Node((int) '4');
        node14.addChildrenToBack(node16);
        node10.addChildAfter(node12, node16);
        com.google.javascript.rhino.Node node20 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node22 = new com.google.javascript.rhino.Node((int) '4');
        node20.addChildrenToBack(node22);
        com.google.javascript.rhino.Node node24 = node10.copyInformationFromForTree(node22);
        com.google.javascript.jscomp.DiagnosticType diagnosticType25 = com.google.javascript.jscomp.Compiler.MOTION_ITERATIONS_ERROR;
        java.lang.String str26 = diagnosticType25.toString();
        java.lang.String[] strArray27 = null;
        com.google.javascript.jscomp.JSError jSError28 = com.google.javascript.jscomp.JSError.make("", node22, diagnosticType25, strArray27);
        java.lang.String str29 = jSError28.toString();
        loggerErrorManager1.report(checkLevel7, jSError28);
        int int31 = loggerErrorManager1.getWarningCount();
        org.junit.Assert.assertTrue("'" + checkLevel7 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel7.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertNotNull(diagnosticType25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}" + "'", str26.equals("JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}"));
        org.junit.Assert.assertNotNull(jSError28);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "JSC_OPTIMIZE_LOOP_ERROR. Exceeded max number of code motion iterations: {0} at (unknown source) line (unknown line) : (unknown column)" + "'", str29.equals("JSC_OPTIMIZE_LOOP_ERROR. Exceeded max number of code motion iterations: {0} at (unknown source) line (unknown line) : (unknown column)"));
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
    }

    @Test
    public void test24() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test24");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile4 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        java.io.Reader reader5 = jSSourceFile4.getCodeReader();
        com.google.javascript.jscomp.JSModule[] jSModuleArray6 = new com.google.javascript.jscomp.JSModule[] {};
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph7 = new com.google.javascript.jscomp.JSModuleGraph(jSModuleArray6);
        com.google.javascript.jscomp.CompilerOptions compilerOptions8 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions8.setLooseTypes(true);
        boolean boolean11 = compilerOptions8.collapseVariableDeclarations;
        compilerOptions8.moveFunctionDeclarations = false;
        boolean boolean14 = compilerOptions8.decomposeExpressions;
        com.google.javascript.jscomp.CheckLevel checkLevel15 = compilerOptions8.checkMissingGetCssNameLevel;
        com.google.javascript.jscomp.Result result16 = compiler1.compile(jSSourceFile4, jSModuleArray6, compilerOptions8);
        com.google.javascript.jscomp.Result result17 = compiler1.getResult();
        boolean boolean18 = compiler1.hasErrors();
        com.google.javascript.jscomp.SourceFile.Generator generator20 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile21 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("JSC_OPTIMIZE_LOOP_ERROR. Exceeded max number of code motion iterations: {0} at (unknown source) line (unknown line) : (unknown column)", generator20);
        com.google.javascript.jscomp.SourceFile.Generator generator23 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile24 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("JSC_OPTIMIZE_LOOP_ERROR. Exceeded max number of code motion iterations: {0} at (unknown source) line (unknown line) : (unknown column)", generator23);
        com.google.javascript.jscomp.CompilerOptions compilerOptions25 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions25.setLooseTypes(true);
        boolean boolean28 = compilerOptions25.reserveRawExports;
        compilerOptions25.extractPrototypeMemberDeclarations = false;
        java.lang.String str31 = compilerOptions25.nameReferenceGraphPath;
        compilerOptions25.computeFunctionSideEffects = true;
        com.google.javascript.jscomp.CompilerOptions compilerOptions34 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions34.setLooseTypes(true);
        compilerOptions34.convertToDottedProperties = false;
        com.google.javascript.jscomp.CheckLevel checkLevel39 = compilerOptions34.reportMissingOverride;
        compilerOptions25.brokenClosureRequiresLevel = checkLevel39;
        java.util.Set<java.lang.String> strSet41 = compilerOptions25.stripTypePrefixes;
        compilerOptions25.optimizeReturns = true;
        com.google.javascript.jscomp.Result result44 = compiler1.compile(jSSourceFile21, jSSourceFile24, compilerOptions25);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile46 = com.google.javascript.jscomp.JSSourceFile.fromFile("(): error reporter");
        java.lang.String str47 = jSSourceFile46.toString();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile50 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        java.io.Reader reader51 = jSSourceFile50.getCodeReader();
        com.google.javascript.jscomp.CompilerOptions compilerOptions52 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions52.setLooseTypes(true);
        boolean boolean55 = compilerOptions52.reserveRawExports;
        boolean boolean56 = compilerOptions52.flowSensitiveInlineVariables;
        compilerOptions52.reserveRawExports = true;
        compilerOptions52.inferTypesInGlobalScope = false;
        boolean boolean61 = compilerOptions52.markNoSideEffectCalls;
        com.google.javascript.jscomp.CheckLevel checkLevel62 = compilerOptions52.checkProvides;
        com.google.javascript.jscomp.Result result63 = compiler1.compile(jSSourceFile46, jSSourceFile50, compilerOptions52);
        java.lang.String str64 = compiler1.getAstDotGraph();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile66 = com.google.javascript.jscomp.JSSourceFile.fromFile("JSC_OPTIMIZE_LOOP_ERROR. Exceeded max number of code motion iterations: {0} at (unknown source) line (unknown line) : (unknown column)");
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray67 = new com.google.javascript.jscomp.JSSourceFile[] {};
        com.google.javascript.jscomp.CompilerOptions compilerOptions68 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions68.setLooseTypes(true);
        compilerOptions68.renamePrefix = "hi!";
        compilerOptions68.checkControlStructures = false;
        boolean boolean75 = compilerOptions68.removeTryCatchFinally;
        boolean boolean76 = compilerOptions68.markAsCompiled;
        boolean boolean77 = compilerOptions68.removeTryCatchFinally;
        java.util.Set<java.lang.String> strSet78 = compilerOptions68.stripTypePrefixes;
        com.google.javascript.jscomp.Result result79 = compiler1.compile(jSSourceFile66, jSSourceFileArray67, compilerOptions68);
        org.junit.Assert.assertNotNull(jSSourceFile4);
        org.junit.Assert.assertNotNull(reader5);
        org.junit.Assert.assertNotNull(jSModuleArray6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + checkLevel15 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel15.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(result16);
        org.junit.Assert.assertNotNull(result17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(jSSourceFile21);
        org.junit.Assert.assertNotNull(jSSourceFile24);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNull(str31);
        org.junit.Assert.assertTrue("'" + checkLevel39 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel39.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(strSet41);
        org.junit.Assert.assertNotNull(result44);
        org.junit.Assert.assertNotNull(jSSourceFile46);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "(): error reporter" + "'", str47.equals("(): error reporter"));
        org.junit.Assert.assertNotNull(jSSourceFile50);
        org.junit.Assert.assertNotNull(reader51);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertTrue("'" + checkLevel62 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel62.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(result63);
        org.junit.Assert.assertTrue("'" + str64 + "' != '" + "" + "'", str64.equals(""));
        org.junit.Assert.assertNotNull(jSSourceFile66);
        org.junit.Assert.assertNotNull(jSSourceFileArray67);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
        org.junit.Assert.assertNotNull(strSet78);
        org.junit.Assert.assertNotNull(result79);
    }

    @Test
    public void test25() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test25");
        com.google.javascript.rhino.Node node1 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node3 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node5 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node7 = new com.google.javascript.rhino.Node((int) '4');
        node5.addChildrenToBack(node7);
        node1.addChildAfter(node3, node7);
        com.google.javascript.rhino.Node node11 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node((int) '4');
        node11.addChildrenToBack(node13);
        com.google.javascript.rhino.Node node15 = node1.copyInformationFromForTree(node13);
        com.google.javascript.rhino.Node node17 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node18 = node1.copyInformationFromForTree(node17);
        java.util.Set<java.lang.String> strSet19 = null;
        node18.setDirectives(strSet19);
        boolean boolean21 = node18.wasEmptyNode();
        boolean boolean22 = node18.isSyntheticBlock();
        boolean boolean23 = node18.hasChildren();
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test26() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test26");
        com.google.javascript.rhino.Context context0 = new com.google.javascript.rhino.Context();
        context0.setGeneratingSource(true);
        java.lang.Object obj3 = context0.getDebuggerContextData();
        int int4 = context0.getOptimizationLevel();
        org.junit.Assert.assertNull(obj3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test27() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test27");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setLooseTypes(true);
        boolean boolean3 = compilerOptions0.reserveRawExports;
        compilerOptions0.extractPrototypeMemberDeclarations = false;
        boolean boolean6 = compilerOptions0.generatePseudoNames;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test28() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test28");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile4 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        java.io.Reader reader5 = jSSourceFile4.getCodeReader();
        com.google.javascript.jscomp.JSModule[] jSModuleArray6 = new com.google.javascript.jscomp.JSModule[] {};
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph7 = new com.google.javascript.jscomp.JSModuleGraph(jSModuleArray6);
        com.google.javascript.jscomp.CompilerOptions compilerOptions8 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions8.setLooseTypes(true);
        boolean boolean11 = compilerOptions8.collapseVariableDeclarations;
        compilerOptions8.moveFunctionDeclarations = false;
        boolean boolean14 = compilerOptions8.decomposeExpressions;
        com.google.javascript.jscomp.CheckLevel checkLevel15 = compilerOptions8.checkMissingGetCssNameLevel;
        com.google.javascript.jscomp.Result result16 = compiler1.compile(jSSourceFile4, jSModuleArray6, compilerOptions8);
        int int17 = compiler1.getErrorCount();
        int int18 = compiler1.getWarningCount();
        java.lang.String str21 = compiler1.getSourceLine("window", 30);
        com.google.javascript.rhino.Node node24 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node26 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node28 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node30 = new com.google.javascript.rhino.Node((int) '4');
        node28.addChildrenToBack(node30);
        node24.addChildAfter(node26, node30);
        com.google.javascript.rhino.Node node34 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node36 = new com.google.javascript.rhino.Node((int) '4');
        node34.addChildrenToBack(node36);
        com.google.javascript.rhino.Node node38 = node24.copyInformationFromForTree(node36);
        com.google.javascript.jscomp.DiagnosticType diagnosticType39 = com.google.javascript.jscomp.Compiler.MOTION_ITERATIONS_ERROR;
        java.lang.String str40 = diagnosticType39.toString();
        java.lang.String[] strArray41 = null;
        com.google.javascript.jscomp.JSError jSError42 = com.google.javascript.jscomp.JSError.make("", node36, diagnosticType39, strArray41);
        java.lang.String str43 = jSError42.description;
        java.lang.String str44 = jSError42.sourceName;
        com.google.javascript.jscomp.CheckLevel checkLevel45 = compiler1.getErrorLevel(jSError42);
        com.google.javascript.jscomp.CheckLevel checkLevel46 = jSError42.level;
        org.junit.Assert.assertNotNull(jSSourceFile4);
        org.junit.Assert.assertNotNull(reader5);
        org.junit.Assert.assertNotNull(jSModuleArray6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + checkLevel15 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel15.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(result16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertNotNull(node38);
        org.junit.Assert.assertNotNull(diagnosticType39);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}" + "'", str40.equals("JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}"));
        org.junit.Assert.assertNotNull(jSError42);
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "Exceeded max number of code motion iterations: {0}" + "'", str43.equals("Exceeded max number of code motion iterations: {0}"));
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "" + "'", str44.equals(""));
        org.junit.Assert.assertNull(checkLevel45);
        org.junit.Assert.assertTrue("'" + checkLevel46 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel46.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
    }

    @Test
    public void test29() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test29");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeUnusedPrototypePropertiesInExterns = false;
        java.lang.String[] strArray6 = new java.lang.String[] { "()", "4" };
        java.util.ArrayList<java.lang.String> strList7 = new java.util.ArrayList<java.lang.String>();
        boolean boolean8 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strList7, strArray6);
        compilerOptions0.setReplaceStringsConfiguration("JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}", (java.util.List<java.lang.String>) strList7);
        compilerOptions0.ignoreCajaProperties = false;
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test30() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test30");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setLooseTypes(true);
        compilerOptions0.checkSuspiciousCode = false;
        compilerOptions0.setCollapsePropertiesOnExternTypes(false);
        com.google.javascript.jscomp.CheckLevel checkLevel7 = compilerOptions0.checkMethods;
        boolean boolean8 = compilerOptions0.generateExports;
        compilerOptions0.crossModuleMethodMotion = false;
        org.junit.Assert.assertTrue("'" + checkLevel7 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel7.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test31() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test31");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.flowSensitiveInlineVariables = false;
        compilerOptions0.optimizeCalls = true;
        compilerOptions0.inlineFunctions = true;
        boolean boolean7 = compilerOptions0.tightenTypes;
        boolean boolean8 = compilerOptions0.inlineLocalVariables;
        compilerOptions0.optimizeCalls = false;
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test32() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test32");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.flowSensitiveInlineVariables = false;
        compilerOptions0.optimizeCalls = true;
        compilerOptions0.inlineFunctions = true;
        com.google.javascript.jscomp.CompilerOptions compilerOptions7 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions7.setLooseTypes(true);
        boolean boolean10 = compilerOptions7.collapseVariableDeclarations;
        compilerOptions7.recordFunctionInformation = false;
        compilerOptions7.convertToDottedProperties = false;
        compilerOptions7.collapseVariableDeclarations = false;
        com.google.javascript.jscomp.SourceMap.Format format17 = com.google.javascript.jscomp.SourceMap.Format.EXPERIMENTIAL;
        compilerOptions7.sourceMapFormat = format17;
        compilerOptions0.sourceMapFormat = format17;
        compilerOptions0.aliasExternals = true;
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(format17);
    }

    @Test
    public void test33() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test33");
        com.google.javascript.jscomp.CheckLevel checkLevel1 = null;
        com.google.javascript.jscomp.DiagnosticType diagnosticType3 = com.google.javascript.jscomp.DiagnosticType.make("@IMPLEMENTATION.VERSION@", checkLevel1, "Unknown class name");
        org.junit.Assert.assertNotNull(diagnosticType3);
    }

    @Test
    public void test34() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test34");
        com.google.javascript.jscomp.CompilerOptions compilerOptions1 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions1.setLooseTypes(true);
        boolean boolean4 = compilerOptions1.collapseVariableDeclarations;
        compilerOptions1.moveFunctionDeclarations = false;
        boolean boolean7 = compilerOptions1.decomposeExpressions;
        boolean boolean8 = compilerOptions1.optimizeParameters;
        java.lang.String str9 = compilerOptions1.inputDelimiter;
        com.google.javascript.jscomp.ErrorFormat errorFormat10 = com.google.javascript.jscomp.ErrorFormat.LEGACY;
        java.lang.RuntimeException runtimeException11 = com.google.javascript.rhino.ScriptRuntime.undefWriteError((java.lang.Object) (short) 100, (java.lang.Object) str9, (java.lang.Object) errorFormat10);
        java.io.PrintStream printStream12 = null;
        com.google.javascript.jscomp.Compiler compiler13 = new com.google.javascript.jscomp.Compiler(printStream12);
        compiler13.disableThreads();
        com.google.javascript.jscomp.PerformanceTracker performanceTracker15 = compiler13.tracker;
        com.google.javascript.jscomp.MessageFormatter messageFormatter17 = errorFormat10.toFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler13, false);
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter18 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler13);
        try {
            java.lang.String str21 = compiler13.getSourceLine("", 47);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "// Input %num%" + "'", str9.equals("// Input %num%"));
        org.junit.Assert.assertNotNull(errorFormat10);
        org.junit.Assert.assertNotNull(runtimeException11);
        org.junit.Assert.assertNull(performanceTracker15);
        org.junit.Assert.assertNotNull(messageFormatter17);
    }

    @Test
    public void test35() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test35");
        com.google.javascript.rhino.Node node1 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node3 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node5 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node7 = new com.google.javascript.rhino.Node((int) '4');
        node5.addChildrenToBack(node7);
        node1.addChildAfter(node3, node7);
        com.google.javascript.rhino.Node node11 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node((int) '4');
        node11.addChildrenToBack(node13);
        com.google.javascript.rhino.Node node15 = node1.copyInformationFromForTree(node13);
        com.google.javascript.rhino.Node node17 = node1.getAncestor(1);
        com.google.javascript.rhino.Node node19 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node21 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node23 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node25 = new com.google.javascript.rhino.Node((int) '4');
        node23.addChildrenToBack(node25);
        node19.addChildAfter(node21, node25);
        com.google.javascript.rhino.Node node29 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node31 = new com.google.javascript.rhino.Node((int) '4');
        node29.addChildrenToBack(node31);
        com.google.javascript.rhino.Node node33 = node19.copyInformationFromForTree(node31);
        com.google.javascript.rhino.Node node35 = node19.getAncestor(1);
        node1.addChildToFront(node19);
        node1.setIsSyntheticBlock(true);
        int int39 = node1.getSourcePosition();
        com.google.javascript.rhino.Node node41 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node43 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node45 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node47 = new com.google.javascript.rhino.Node((int) '4');
        node45.addChildrenToBack(node47);
        node41.addChildAfter(node43, node47);
        com.google.javascript.rhino.Node node51 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node53 = new com.google.javascript.rhino.Node((int) '4');
        node51.addChildrenToBack(node53);
        com.google.javascript.rhino.Node node55 = node41.copyInformationFromForTree(node53);
        com.google.javascript.rhino.Node node56 = node55.getLastChild();
        com.google.javascript.rhino.Node node58 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node60 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node62 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node64 = new com.google.javascript.rhino.Node((int) '4');
        node62.addChildrenToBack(node64);
        node58.addChildAfter(node60, node64);
        com.google.javascript.rhino.Node node68 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node70 = new com.google.javascript.rhino.Node((int) '4');
        node68.addChildrenToBack(node70);
        com.google.javascript.rhino.Node node72 = node58.copyInformationFromForTree(node70);
        node55.addChildToBack(node58);
        com.google.javascript.rhino.Node node75 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node77 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node79 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node81 = new com.google.javascript.rhino.Node((int) '4');
        node79.addChildrenToBack(node81);
        node75.addChildAfter(node77, node81);
        com.google.javascript.rhino.Node node85 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node87 = new com.google.javascript.rhino.Node((int) '4');
        node85.addChildrenToBack(node87);
        com.google.javascript.rhino.Node node89 = node75.copyInformationFromForTree(node87);
        com.google.javascript.rhino.jstype.JSType jSType90 = null;
        node89.setJSType(jSType90);
        node55.addChildToFront(node89);
        com.google.javascript.rhino.jstype.JSType jSType93 = node89.getJSType();
        boolean boolean94 = node89.isSyntheticBlock();
        boolean boolean95 = node89.hasOneChild();
        boolean boolean96 = node1.hasChild(node89);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertNull(node17);
        org.junit.Assert.assertNotNull(node33);
        org.junit.Assert.assertNull(node35);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + (-1) + "'", int39 == (-1));
        org.junit.Assert.assertNotNull(node55);
        org.junit.Assert.assertNull(node56);
        org.junit.Assert.assertNotNull(node72);
        org.junit.Assert.assertNotNull(node89);
        org.junit.Assert.assertNull(jSType93);
        org.junit.Assert.assertTrue("'" + boolean94 + "' != '" + false + "'", boolean94 == false);
        org.junit.Assert.assertTrue("'" + boolean95 + "' != '" + false + "'", boolean95 == false);
        org.junit.Assert.assertTrue("'" + boolean96 + "' != '" + false + "'", boolean96 == false);
    }

//    @Test
//    public void test36() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test36");
//        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.STRICT_MODULE_DEP_CHECK;
//        com.google.javascript.jscomp.DiagnosticGroups.MISSING_PROPERTIES = diagnosticGroup0;
//        com.google.javascript.jscomp.DiagnosticGroups.CHECK_TYPES = diagnosticGroup0;
//        com.google.javascript.jscomp.DiagnosticGroups.INTERNET_EXPLORER_CHECKS = diagnosticGroup0;
//        com.google.javascript.jscomp.DiagnosticGroups.ACCESS_CONTROLS = diagnosticGroup0;
//        org.junit.Assert.assertNull(diagnosticGroup0);
//    }

    @Test
    public void test37() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test37");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        java.io.PrintStream printStream2 = null;
        com.google.javascript.jscomp.Compiler compiler3 = new com.google.javascript.jscomp.Compiler(printStream2);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile6 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        java.io.Reader reader7 = jSSourceFile6.getCodeReader();
        com.google.javascript.jscomp.JSModule[] jSModuleArray8 = new com.google.javascript.jscomp.JSModule[] {};
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph9 = new com.google.javascript.jscomp.JSModuleGraph(jSModuleArray8);
        com.google.javascript.jscomp.CompilerOptions compilerOptions10 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions10.setLooseTypes(true);
        boolean boolean13 = compilerOptions10.collapseVariableDeclarations;
        compilerOptions10.moveFunctionDeclarations = false;
        boolean boolean16 = compilerOptions10.decomposeExpressions;
        com.google.javascript.jscomp.CheckLevel checkLevel17 = compilerOptions10.checkMissingGetCssNameLevel;
        com.google.javascript.jscomp.Result result18 = compiler3.compile(jSSourceFile6, jSModuleArray8, compilerOptions10);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile21 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile24 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        java.io.Reader reader25 = jSSourceFile24.getCodeReader();
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray26 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile6, jSSourceFile21, jSSourceFile24 };
        java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList27 = new java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile>();
        boolean boolean28 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList27, jSSourceFileArray26);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile31 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray32 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile31 };
        java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList33 = new java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile>();
        boolean boolean34 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList33, jSSourceFileArray32);
        com.google.javascript.jscomp.CompilerOptions compilerOptions35 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions35.setLooseTypes(true);
        boolean boolean38 = compilerOptions35.reserveRawExports;
        compilerOptions35.extractPrototypeMemberDeclarations = false;
        java.lang.String str41 = compilerOptions35.nameReferenceGraphPath;
        compilerOptions35.setSummaryDetailLevel(0);
        com.google.javascript.jscomp.Result result44 = compiler1.compile((java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList27, (java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList33, compilerOptions35);
        int int45 = compiler1.getWarningCount();
        com.google.javascript.jscomp.PerformanceTracker performanceTracker46 = compiler1.tracker;
        compiler1.rebuildInputsFromModules();
        java.lang.String str50 = compiler1.getSourceLine("TypeError: 4", 38);
        org.junit.Assert.assertNotNull(jSSourceFile6);
        org.junit.Assert.assertNotNull(reader7);
        org.junit.Assert.assertNotNull(jSModuleArray8);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + checkLevel17 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel17.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(result18);
        org.junit.Assert.assertNotNull(jSSourceFile21);
        org.junit.Assert.assertNotNull(jSSourceFile24);
        org.junit.Assert.assertNotNull(reader25);
        org.junit.Assert.assertNotNull(jSSourceFileArray26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(jSSourceFile31);
        org.junit.Assert.assertNotNull(jSSourceFileArray32);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNull(str41);
        org.junit.Assert.assertNotNull(result44);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 0 + "'", int45 == 0);
        org.junit.Assert.assertNull(performanceTracker46);
        org.junit.Assert.assertNull(str50);
    }

    @Test
    public void test38() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test38");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setLooseTypes(true);
        compilerOptions0.convertToDottedProperties = false;
        com.google.javascript.jscomp.CheckLevel checkLevel5 = compilerOptions0.reportMissingOverride;
        boolean boolean6 = compilerOptions0.aliasAllStrings;
        boolean boolean7 = compilerOptions0.flowSensitiveInlineVariables;
        compilerOptions0.removeUnusedVars = true;
        com.google.javascript.jscomp.CheckLevel checkLevel10 = compilerOptions0.checkUndefinedProperties;
        org.junit.Assert.assertTrue("'" + checkLevel5 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel5.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + checkLevel10 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel10.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test39() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test39");
        com.google.javascript.rhino.Node node1 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node3 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node5 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node7 = new com.google.javascript.rhino.Node((int) '4');
        node5.addChildrenToBack(node7);
        node1.addChildAfter(node3, node7);
        node3.setIsSyntheticBlock(true);
        com.google.javascript.rhino.Node node12 = node3.cloneNode();
        node3.setIsSyntheticBlock(true);
        org.junit.Assert.assertNotNull(node12);
    }

    @Test
    public void test40() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test40");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setLooseTypes(true);
        boolean boolean3 = compilerOptions0.reserveRawExports;
        compilerOptions0.extractPrototypeMemberDeclarations = false;
        com.google.javascript.jscomp.CheckLevel checkLevel6 = compilerOptions0.aggressiveVarCheck;
        boolean boolean7 = compilerOptions0.foldConstants;
        com.google.javascript.jscomp.DiagnosticType diagnosticType8 = com.google.javascript.jscomp.Compiler.MOTION_ITERATIONS_ERROR;
        com.google.javascript.jscomp.CheckLevel checkLevel9 = diagnosticType8.defaultLevel;
        compilerOptions0.checkFunctions = checkLevel9;
        boolean boolean11 = compilerOptions0.isExternExportsEnabled();
        compilerOptions0.specializeInitialModule = false;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + checkLevel6 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel6.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(diagnosticType8);
        org.junit.Assert.assertTrue("'" + checkLevel9 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel9.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test41() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test41");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        java.io.PrintStream printStream2 = null;
        com.google.javascript.jscomp.Compiler compiler3 = new com.google.javascript.jscomp.Compiler(printStream2);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile6 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        java.io.Reader reader7 = jSSourceFile6.getCodeReader();
        com.google.javascript.jscomp.JSModule[] jSModuleArray8 = new com.google.javascript.jscomp.JSModule[] {};
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph9 = new com.google.javascript.jscomp.JSModuleGraph(jSModuleArray8);
        com.google.javascript.jscomp.CompilerOptions compilerOptions10 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions10.setLooseTypes(true);
        boolean boolean13 = compilerOptions10.collapseVariableDeclarations;
        compilerOptions10.moveFunctionDeclarations = false;
        boolean boolean16 = compilerOptions10.decomposeExpressions;
        com.google.javascript.jscomp.CheckLevel checkLevel17 = compilerOptions10.checkMissingGetCssNameLevel;
        com.google.javascript.jscomp.Result result18 = compiler3.compile(jSSourceFile6, jSModuleArray8, compilerOptions10);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile21 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile24 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        java.io.Reader reader25 = jSSourceFile24.getCodeReader();
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray26 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile6, jSSourceFile21, jSSourceFile24 };
        java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList27 = new java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile>();
        boolean boolean28 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList27, jSSourceFileArray26);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile31 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray32 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile31 };
        java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList33 = new java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile>();
        boolean boolean34 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList33, jSSourceFileArray32);
        com.google.javascript.jscomp.CompilerOptions compilerOptions35 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions35.setLooseTypes(true);
        boolean boolean38 = compilerOptions35.reserveRawExports;
        compilerOptions35.extractPrototypeMemberDeclarations = false;
        java.lang.String str41 = compilerOptions35.nameReferenceGraphPath;
        compilerOptions35.setSummaryDetailLevel(0);
        com.google.javascript.jscomp.Result result44 = compiler1.compile((java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList27, (java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList33, compilerOptions35);
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter45 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler1);
        com.google.javascript.jscomp.CompilerOptions compilerOptions46 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions46.setLooseTypes(true);
        boolean boolean49 = compilerOptions46.reserveRawExports;
        compilerOptions46.inferTypesInGlobalScope = false;
        java.lang.String str52 = compilerOptions46.debugFunctionSideEffectsPath;
        compiler1.initOptions(compilerOptions46);
        compilerOptions46.setAcceptConstKeyword(true);
        org.junit.Assert.assertNotNull(jSSourceFile6);
        org.junit.Assert.assertNotNull(reader7);
        org.junit.Assert.assertNotNull(jSModuleArray8);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + checkLevel17 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel17.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(result18);
        org.junit.Assert.assertNotNull(jSSourceFile21);
        org.junit.Assert.assertNotNull(jSSourceFile24);
        org.junit.Assert.assertNotNull(reader25);
        org.junit.Assert.assertNotNull(jSSourceFileArray26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(jSSourceFile31);
        org.junit.Assert.assertNotNull(jSSourceFileArray32);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNull(str41);
        org.junit.Assert.assertNotNull(result44);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNull(str52);
    }

    @Test
    public void test42() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test42");
        com.google.javascript.rhino.Node node1 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node3 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node5 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node7 = new com.google.javascript.rhino.Node((int) '4');
        node5.addChildrenToBack(node7);
        node1.addChildAfter(node3, node7);
        com.google.javascript.rhino.Node node11 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node((int) '4');
        node11.addChildrenToBack(node13);
        com.google.javascript.rhino.Node node15 = node1.copyInformationFromForTree(node13);
        com.google.javascript.rhino.Node node17 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node18 = node1.copyInformationFromForTree(node17);
        com.google.javascript.rhino.Node node19 = com.google.javascript.jscomp.NodeUtil.newExpr(node18);
        com.google.javascript.rhino.Node node20 = node18.getParent();
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNotNull(node20);
    }

    @Test
    public void test43() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test43");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setLooseTypes(true);
        boolean boolean3 = compilerOptions0.reserveRawExports;
        compilerOptions0.extractPrototypeMemberDeclarations = false;
        boolean boolean6 = compilerOptions0.disambiguateProperties;
        com.google.javascript.jscomp.CheckLevel checkLevel7 = compilerOptions0.aggressiveVarCheck;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap8 = compilerOptions0.cssRenamingMap;
        java.lang.String str9 = compilerOptions0.renamePrefix;
        boolean boolean10 = compilerOptions0.disambiguateProperties;
        java.lang.String str11 = compilerOptions0.unaliasableGlobals;
        boolean boolean12 = compilerOptions0.instrumentForCoverageOnly;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + checkLevel7 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel7.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNull(cssRenamingMap8);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNull(str11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test44() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test44");
        int int0 = com.google.javascript.rhino.Node.FLAG_GLOBAL_STATE_UNMODIFIED;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test45() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test45");
        com.google.javascript.rhino.Node node1 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node3 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node5 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node7 = new com.google.javascript.rhino.Node((int) '4');
        node5.addChildrenToBack(node7);
        node1.addChildAfter(node3, node7);
        com.google.javascript.rhino.Node node11 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node((int) '4');
        node11.addChildrenToBack(node13);
        com.google.javascript.rhino.Node node15 = node1.copyInformationFromForTree(node13);
        com.google.javascript.rhino.Node node16 = node15.getLastChild();
        com.google.javascript.rhino.Node node18 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node20 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node22 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node24 = new com.google.javascript.rhino.Node((int) '4');
        node22.addChildrenToBack(node24);
        node18.addChildAfter(node20, node24);
        com.google.javascript.rhino.Node node28 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node30 = new com.google.javascript.rhino.Node((int) '4');
        node28.addChildrenToBack(node30);
        com.google.javascript.rhino.Node node32 = node18.copyInformationFromForTree(node30);
        node15.addChildToBack(node18);
        com.google.javascript.rhino.Node node34 = node18.cloneNode();
        java.lang.String str35 = node18.toStringTree();
        boolean boolean36 = node18.hasChildren();
        node18.removeProp(19);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertNull(node16);
        org.junit.Assert.assertNotNull(node32);
        org.junit.Assert.assertNotNull(node34);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "INSTANCEOF\n" + "'", str35.equals("INSTANCEOF\n"));
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
    }

    @Test
    public void test46() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test46");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setLooseTypes(true);
        boolean boolean3 = compilerOptions0.reserveRawExports;
        compilerOptions0.extractPrototypeMemberDeclarations = false;
        com.google.javascript.jscomp.CheckLevel checkLevel6 = compilerOptions0.aggressiveVarCheck;
        boolean boolean7 = compilerOptions0.foldConstants;
        com.google.javascript.jscomp.DiagnosticType diagnosticType8 = com.google.javascript.jscomp.Compiler.MOTION_ITERATIONS_ERROR;
        com.google.javascript.jscomp.CheckLevel checkLevel9 = diagnosticType8.defaultLevel;
        compilerOptions0.checkFunctions = checkLevel9;
        compilerOptions0.inferTypesInGlobalScope = false;
        com.google.javascript.jscomp.CheckLevel checkLevel13 = compilerOptions0.checkMethods;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + checkLevel6 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel6.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(diagnosticType8);
        org.junit.Assert.assertTrue("'" + checkLevel9 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel9.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + checkLevel13 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel13.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test47() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test47");
        com.google.javascript.jscomp.SourceAst sourceAst0 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(sourceAst0, "", false);
        boolean boolean4 = compilerInput3.isExtern();
        java.lang.String str5 = compilerInput3.getName();
        com.google.javascript.jscomp.JSModule jSModule6 = compilerInput3.getModule();
        com.google.javascript.jscomp.JSModule jSModule7 = null;
        compilerInput3.setModule(jSModule7);
        try {
            com.google.javascript.jscomp.SourceFile sourceFile9 = compilerInput3.getSourceFile();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertNull(jSModule6);
    }

    @Test
    public void test48() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test48");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = null;
        com.google.javascript.jscomp.DiagnosticGroups.INVALID_CASTS = diagnosticGroup0;
    }

    @Test
    public void test49() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test49");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile4 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        java.io.Reader reader5 = jSSourceFile4.getCodeReader();
        com.google.javascript.jscomp.JSModule[] jSModuleArray6 = new com.google.javascript.jscomp.JSModule[] {};
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph7 = new com.google.javascript.jscomp.JSModuleGraph(jSModuleArray6);
        com.google.javascript.jscomp.CompilerOptions compilerOptions8 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions8.setLooseTypes(true);
        boolean boolean11 = compilerOptions8.collapseVariableDeclarations;
        compilerOptions8.moveFunctionDeclarations = false;
        boolean boolean14 = compilerOptions8.decomposeExpressions;
        com.google.javascript.jscomp.CheckLevel checkLevel15 = compilerOptions8.checkMissingGetCssNameLevel;
        com.google.javascript.jscomp.Result result16 = compiler1.compile(jSSourceFile4, jSModuleArray6, compilerOptions8);
        com.google.javascript.jscomp.CompilerInput compilerInput17 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile4);
        org.junit.Assert.assertNotNull(jSSourceFile4);
        org.junit.Assert.assertNotNull(reader5);
        org.junit.Assert.assertNotNull(jSModuleArray6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + checkLevel15 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel15.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(result16);
    }

    @Test
    public void test50() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test50");
        com.google.javascript.rhino.Context context0 = new com.google.javascript.rhino.Context();
        context0.setGeneratingSource(true);
        com.google.javascript.jscomp.CompilerOptions.TracerMode tracerMode3 = com.google.javascript.jscomp.CompilerOptions.TracerMode.FAST;
        context0.removeThreadLocal((java.lang.Object) tracerMode3);
        boolean boolean5 = context0.isGeneratingSource();
        com.google.javascript.rhino.Context context6 = new com.google.javascript.rhino.Context();
        context6.setGeneratingSource(true);
        com.google.javascript.jscomp.CompilerOptions.TracerMode tracerMode9 = com.google.javascript.jscomp.CompilerOptions.TracerMode.FAST;
        context6.removeThreadLocal((java.lang.Object) tracerMode9);
        boolean boolean11 = context6.isGeneratingSource();
        java.util.Locale locale12 = context6.getLocale();
        java.util.Locale locale13 = context0.setLocale(locale12);
        com.google.javascript.rhino.Node node15 = new com.google.javascript.rhino.Node((int) (short) 1);
        context0.removeThreadLocal((java.lang.Object) (short) 1);
        java.lang.Object obj17 = null;
        java.lang.Object obj18 = context0.getThreadLocal(obj17);
        org.junit.Assert.assertTrue("'" + tracerMode3 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TracerMode.FAST + "'", tracerMode3.equals(com.google.javascript.jscomp.CompilerOptions.TracerMode.FAST));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + tracerMode9 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TracerMode.FAST + "'", tracerMode9.equals(com.google.javascript.jscomp.CompilerOptions.TracerMode.FAST));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(locale12);
        org.junit.Assert.assertNull(locale13);
        org.junit.Assert.assertNull(obj18);
    }

    @Test
    public void test51() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test51");
        com.google.javascript.rhino.Context context0 = new com.google.javascript.rhino.Context();
        context0.addActivationName("com.google.javascript.rhino.EcmaError: TypeError: 4");
        boolean boolean3 = context0.isGeneratingSource();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test52() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test52");
        com.google.javascript.rhino.Context context0 = new com.google.javascript.rhino.Context();
        com.google.javascript.rhino.ErrorReporter errorReporter1 = context0.getErrorReporter();
        com.google.javascript.jscomp.CompilerOptions compilerOptions2 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions2.setLooseTypes(true);
        compilerOptions2.checkSuspiciousCode = false;
        compilerOptions2.disambiguateProperties = true;
        java.util.Map<java.lang.String, com.google.javascript.rhino.Node> strMap9 = compilerOptions2.getDefineReplacements();
        compilerOptions2.checkDuplicateMessages = false;
        context0.removeThreadLocal((java.lang.Object) compilerOptions2);
        com.google.javascript.rhino.Node node14 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node16 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node18 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node20 = new com.google.javascript.rhino.Node((int) '4');
        node18.addChildrenToBack(node20);
        node14.addChildAfter(node16, node20);
        node16.setIsSyntheticBlock(true);
        com.google.javascript.rhino.Node node25 = node16.cloneNode();
        com.google.javascript.rhino.Node node26 = node25.getNext();
        com.google.javascript.rhino.Node node27 = node25.removeChildren();
        context0.removeThreadLocal((java.lang.Object) node27);
        org.junit.Assert.assertNull(errorReporter1);
        org.junit.Assert.assertNotNull(strMap9);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNull(node26);
        org.junit.Assert.assertNull(node27);
    }

    @Test
    public void test53() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test53");
        com.google.javascript.jscomp.DiagnosticType diagnosticType2 = com.google.javascript.jscomp.DiagnosticType.error("DiagnosticGroup<externsValidation>", "4");
        com.google.javascript.jscomp.CheckLevel checkLevel3 = null;
        diagnosticType2.level = checkLevel3;
        org.junit.Assert.assertNotNull(diagnosticType2);
    }

    @Test
    public void test54() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test54");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        compiler1.disableThreads();
        com.google.javascript.jscomp.PerformanceTracker performanceTracker3 = compiler1.tracker;
        com.google.javascript.jscomp.NodeTraversal.Callback callback4 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal5 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler1, callback4);
        com.google.javascript.rhino.Node node7 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node9 = new com.google.javascript.rhino.Node((int) '4');
        node7.addChildrenToBack(node9);
        com.google.javascript.jscomp.DiagnosticType diagnosticType13 = com.google.javascript.jscomp.DiagnosticType.warning("hi!", "hi!");
        com.google.javascript.jscomp.DiagnosticType diagnosticType14 = com.google.javascript.jscomp.Compiler.MOTION_ITERATIONS_ERROR;
        int int15 = diagnosticType13.compareTo(diagnosticType14);
        java.lang.String[] strArray16 = com.google.javascript.rhino.ScriptRuntime.emptyStrings;
        com.google.javascript.jscomp.JSError jSError17 = nodeTraversal5.makeError(node9, diagnosticType13, strArray16);
        com.google.javascript.rhino.Node node18 = nodeTraversal5.getEnclosingFunction();
        int int19 = nodeTraversal5.getLineNumber();
        com.google.javascript.rhino.Node node20 = null;
        com.google.javascript.jscomp.DiagnosticType diagnosticType23 = com.google.javascript.jscomp.DiagnosticType.warning("hi!", "hi!");
        java.lang.String str24 = diagnosticType23.key;
        java.lang.String str25 = diagnosticType23.toString();
        java.io.PrintStream printStream26 = null;
        com.google.javascript.jscomp.Compiler compiler27 = new com.google.javascript.jscomp.Compiler(printStream26);
        compiler27.disableThreads();
        com.google.javascript.jscomp.PerformanceTracker performanceTracker29 = compiler27.tracker;
        com.google.javascript.jscomp.NodeTraversal.Callback callback30 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal31 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler27, callback30);
        com.google.javascript.rhino.Node node33 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node35 = new com.google.javascript.rhino.Node((int) '4');
        node33.addChildrenToBack(node35);
        com.google.javascript.jscomp.DiagnosticType diagnosticType39 = com.google.javascript.jscomp.DiagnosticType.warning("hi!", "hi!");
        com.google.javascript.jscomp.DiagnosticType diagnosticType40 = com.google.javascript.jscomp.Compiler.MOTION_ITERATIONS_ERROR;
        int int41 = diagnosticType39.compareTo(diagnosticType40);
        java.lang.String[] strArray42 = com.google.javascript.rhino.ScriptRuntime.emptyStrings;
        com.google.javascript.jscomp.JSError jSError43 = nodeTraversal31.makeError(node35, diagnosticType39, strArray42);
        try {
            nodeTraversal5.report(node20, diagnosticType23, strArray42);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(performanceTracker3);
        org.junit.Assert.assertNotNull(diagnosticType13);
        org.junit.Assert.assertNotNull(diagnosticType14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 30 + "'", int15 == 30);
        org.junit.Assert.assertNotNull(strArray16);
        org.junit.Assert.assertNotNull(jSError17);
        org.junit.Assert.assertNull(node18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNotNull(diagnosticType23);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "hi!" + "'", str24.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "hi!: hi!" + "'", str25.equals("hi!: hi!"));
        org.junit.Assert.assertNull(performanceTracker29);
        org.junit.Assert.assertNotNull(diagnosticType39);
        org.junit.Assert.assertNotNull(diagnosticType40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 30 + "'", int41 == 30);
        org.junit.Assert.assertNotNull(strArray42);
        org.junit.Assert.assertNotNull(jSError43);
    }

    @Test
    public void test55() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test55");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setLooseTypes(true);
        boolean boolean3 = compilerOptions0.reserveRawExports;
        compilerOptions0.extractPrototypeMemberDeclarations = false;
        boolean boolean6 = compilerOptions0.disambiguateProperties;
        com.google.javascript.jscomp.CheckLevel checkLevel7 = compilerOptions0.aggressiveVarCheck;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap8 = compilerOptions0.cssRenamingMap;
        com.google.javascript.jscomp.SourceMap.Format format9 = compilerOptions0.sourceMapFormat;
        boolean boolean10 = compilerOptions0.checkSuspiciousCode;
        com.google.javascript.jscomp.CheckLevel checkLevel11 = compilerOptions0.checkRequires;
        compilerOptions0.foldConstants = true;
        compilerOptions0.setPropertyAffinity(false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + checkLevel7 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel7.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNull(cssRenamingMap8);
        org.junit.Assert.assertNotNull(format9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + checkLevel11 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel11.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test56() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test56");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setLooseTypes(true);
        boolean boolean3 = compilerOptions0.collapseVariableDeclarations;
        boolean boolean4 = compilerOptions0.generateExports;
        com.google.javascript.jscomp.SourceMap.DetailLevel detailLevel5 = compilerOptions0.sourceMapDetailLevel;
        compilerOptions0.rewriteFunctionExpressions = true;
        com.google.javascript.jscomp.CheckLevel checkLevel8 = compilerOptions0.checkFunctions;
        compilerOptions0.flowSensitiveInlineVariables = true;
        compilerOptions0.moveFunctionDeclarations = true;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(detailLevel5);
        org.junit.Assert.assertTrue("'" + checkLevel8 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel8.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test57() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test57");
        com.google.javascript.rhino.Context context0 = new com.google.javascript.rhino.Context();
        int int1 = context0.getInstructionObserverThreshold();
        context0.setInstructionObserverThreshold(0);
        com.google.javascript.rhino.ErrorReporter errorReporter4 = null;
        try {
            com.google.javascript.rhino.ErrorReporter errorReporter5 = context0.setErrorReporter(errorReporter4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test58() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test58");
        java.util.logging.Logger logger0 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager1 = new com.google.javascript.jscomp.LoggerErrorManager(logger0);
        com.google.javascript.jscomp.CompilerOptions compilerOptions2 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions2.setLooseTypes(true);
        compilerOptions2.convertToDottedProperties = false;
        com.google.javascript.jscomp.CheckLevel checkLevel7 = compilerOptions2.reportUnknownTypes;
        com.google.javascript.rhino.Node node10 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node12 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node14 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node16 = new com.google.javascript.rhino.Node((int) '4');
        node14.addChildrenToBack(node16);
        node10.addChildAfter(node12, node16);
        com.google.javascript.rhino.Node node20 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node22 = new com.google.javascript.rhino.Node((int) '4');
        node20.addChildrenToBack(node22);
        com.google.javascript.rhino.Node node24 = node10.copyInformationFromForTree(node22);
        com.google.javascript.jscomp.DiagnosticType diagnosticType25 = com.google.javascript.jscomp.Compiler.MOTION_ITERATIONS_ERROR;
        java.lang.String str26 = diagnosticType25.toString();
        java.lang.String[] strArray27 = null;
        com.google.javascript.jscomp.JSError jSError28 = com.google.javascript.jscomp.JSError.make("", node22, diagnosticType25, strArray27);
        java.lang.String str29 = jSError28.toString();
        loggerErrorManager1.report(checkLevel7, jSError28);
        double double31 = loggerErrorManager1.getTypedPercent();
        com.google.javascript.jscomp.JSError[] jSErrorArray32 = loggerErrorManager1.getErrors();
        com.google.javascript.jscomp.Compiler compiler33 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager1);
        org.junit.Assert.assertTrue("'" + checkLevel7 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel7.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertNotNull(diagnosticType25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}" + "'", str26.equals("JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}"));
        org.junit.Assert.assertNotNull(jSError28);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "JSC_OPTIMIZE_LOOP_ERROR. Exceeded max number of code motion iterations: {0} at (unknown source) line (unknown line) : (unknown column)" + "'", str29.equals("JSC_OPTIMIZE_LOOP_ERROR. Exceeded max number of code motion iterations: {0} at (unknown source) line (unknown line) : (unknown column)"));
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
        org.junit.Assert.assertNotNull(jSErrorArray32);
    }

    @Test
    public void test59() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test59");
        com.google.javascript.rhino.Node.SideEffectFlags sideEffectFlags1 = new com.google.javascript.rhino.Node.SideEffectFlags((int) (short) 1);
        sideEffectFlags1.setReturnsTainted();
        sideEffectFlags1.setMutatesThis();
    }

    @Test
    public void test60() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test60");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeUnusedPrototypePropertiesInExterns = false;
        compilerOptions0.removeUnusedLocalVars = false;
        compilerOptions0.ignoreCajaProperties = false;
        compilerOptions0.setRemoveClosureAsserts(false);
        boolean boolean9 = compilerOptions0.rewriteFunctionExpressions;
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test61() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test61");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setLooseTypes(true);
        boolean boolean3 = compilerOptions0.reserveRawExports;
        com.google.javascript.jscomp.CheckLevel checkLevel4 = null;
        compilerOptions0.checkUnreachableCode = checkLevel4;
        com.google.javascript.jscomp.MessageBundle messageBundle6 = compilerOptions0.messageBundle;
        java.lang.String str7 = compilerOptions0.sourceMapOutputPath;
        compilerOptions0.generateExports = true;
        com.google.javascript.jscomp.CompilerOptions compilerOptions10 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions10.setLooseTypes(true);
        boolean boolean13 = compilerOptions10.reserveRawExports;
        compilerOptions10.extractPrototypeMemberDeclarations = false;
        java.lang.String str16 = compilerOptions10.nameReferenceGraphPath;
        compilerOptions10.computeFunctionSideEffects = true;
        com.google.javascript.jscomp.CompilerOptions compilerOptions19 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions19.setLooseTypes(true);
        compilerOptions19.convertToDottedProperties = false;
        com.google.javascript.jscomp.CheckLevel checkLevel24 = compilerOptions19.reportMissingOverride;
        compilerOptions10.brokenClosureRequiresLevel = checkLevel24;
        java.util.Set<java.lang.String> strSet26 = compilerOptions10.stripTypePrefixes;
        compilerOptions0.setIdGenerators(strSet26);
        com.google.javascript.jscomp.CheckLevel checkLevel28 = null;
        compilerOptions0.reportUnknownTypes = checkLevel28;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(messageBundle6);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertTrue("'" + checkLevel24 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel24.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(strSet26);
    }

    @Test
    public void test62() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test62");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setLooseTypes(true);
        compilerOptions0.checkSuspiciousCode = false;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap5 = null;
        compilerOptions0.cssRenamingMap = cssRenamingMap5;
        compilerOptions0.aliasableGlobals = "hi!: hi!";
        compilerOptions0.optimizeCalls = true;
    }

    @Test
    public void test63() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test63");
        com.google.javascript.rhino.Node node1 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node3 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node5 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node7 = new com.google.javascript.rhino.Node((int) '4');
        node5.addChildrenToBack(node7);
        node1.addChildAfter(node3, node7);
        com.google.javascript.rhino.Node node11 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node((int) '4');
        node11.addChildrenToBack(node13);
        com.google.javascript.rhino.Node node15 = node1.copyInformationFromForTree(node13);
        com.google.javascript.rhino.Node node17 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node18 = node1.copyInformationFromForTree(node17);
        java.util.Set<java.lang.String> strSet19 = null;
        node18.setDirectives(strSet19);
        boolean boolean21 = node18.wasEmptyNode();
        boolean boolean22 = node18.isSyntheticBlock();
        com.google.javascript.rhino.Node node24 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node26 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node28 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node30 = new com.google.javascript.rhino.Node((int) '4');
        node28.addChildrenToBack(node30);
        node24.addChildAfter(node26, node30);
        com.google.javascript.rhino.Node node34 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node36 = new com.google.javascript.rhino.Node((int) '4');
        node34.addChildrenToBack(node36);
        com.google.javascript.rhino.Node node38 = node24.copyInformationFromForTree(node36);
        com.google.javascript.rhino.Node node39 = node24.cloneTree();
        com.google.javascript.rhino.Node node43 = new com.google.javascript.rhino.Node(30, 35, 8);
        com.google.javascript.rhino.Node node44 = node43.getLastChild();
        node39.addChildToFront(node43);
        java.lang.String str46 = node18.checkTreeEquals(node39);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(node38);
        org.junit.Assert.assertNotNull(node39);
        org.junit.Assert.assertNull(node44);
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "Node tree inequality:\nTree1:\nINSTANCEOF\n\n\nTree2:\nINSTANCEOF\n    NEW 35\n\n\nSubtree1: INSTANCEOF\n\n\nSubtree2: INSTANCEOF\n    NEW 35\n" + "'", str46.equals("Node tree inequality:\nTree1:\nINSTANCEOF\n\n\nTree2:\nINSTANCEOF\n    NEW 35\n\n\nSubtree1: INSTANCEOF\n\n\nSubtree2: INSTANCEOF\n    NEW 35\n"));
    }

    @Test
    public void test64() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test64");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setLooseTypes(true);
        compilerOptions0.checkSuspiciousCode = false;
        com.google.common.collect.Multimap<com.google.javascript.jscomp.CustomPassExecutionTime, com.google.javascript.jscomp.CompilerPass> customPassExecutionTimeMultimap5 = compilerOptions0.customPasses;
        compilerOptions0.inlineLocalFunctions = false;
        compilerOptions0.closurePass = true;
        compilerOptions0.removeDeadCode = false;
        java.lang.String str12 = compilerOptions0.nameReferenceReportPath;
        org.junit.Assert.assertNull(customPassExecutionTimeMultimap5);
        org.junit.Assert.assertNull(str12);
    }

    @Test
    public void test65() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test65");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setLooseTypes(true);
        compilerOptions0.checkSuspiciousCode = false;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap5 = null;
        compilerOptions0.cssRenamingMap = cssRenamingMap5;
        java.lang.String str7 = compilerOptions0.checkMissingGetCssNameBlacklist;
        org.junit.Assert.assertNull(str7);
    }

    @Test
    public void test66() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test66");
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention0 = new com.google.javascript.jscomp.DefaultCodingConvention();
        boolean boolean2 = defaultCodingConvention0.isExported("// Input %num%");
        boolean boolean4 = defaultCodingConvention0.isSuperClassReference("");
        java.lang.String str5 = defaultCodingConvention0.getAbstractMethodName();
        com.google.javascript.rhino.jstype.ObjectType objectType6 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType7 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType8 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType9 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType10 = null;
        defaultCodingConvention0.applyDelegateRelationship(objectType6, objectType7, objectType8, functionType9, functionType10);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(str5);
    }

    @Test
    public void test67() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test67");
        try {
            com.google.javascript.rhino.EvaluatorException evaluatorException5 = new com.google.javascript.rhino.EvaluatorException("33", "(language version)", (int) (byte) 1, "JSC_OPTIMIZE_LOOP_ERROR. Exceeded max number of code motion iterations: {0} at (unknown source) line (unknown line) : (unknown column)", (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: -1");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test68() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test68");
        com.google.javascript.jscomp.JSModule[] jSModuleArray0 = new com.google.javascript.jscomp.JSModule[] {};
        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList1 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList1, jSModuleArray0);
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph3 = new com.google.javascript.jscomp.JSModuleGraph((java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList1);
        jSModuleGraph3.coalesceDuplicateFiles();
        jSModuleGraph3.coalesceDuplicateFiles();
        com.google.javascript.jscomp.JSModule jSModule6 = null;
        com.google.javascript.jscomp.JSModule jSModule7 = null;
        com.google.javascript.jscomp.JSModule jSModule8 = jSModuleGraph3.getDeepestCommonDependencyInclusive(jSModule6, jSModule7);
        org.junit.Assert.assertNotNull(jSModuleArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(jSModule8);
    }

    @Test
    public void test69() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test69");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        compiler1.disableThreads();
        com.google.javascript.jscomp.PerformanceTracker performanceTracker3 = compiler1.tracker;
        com.google.javascript.jscomp.NodeTraversal.Callback callback4 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal5 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler1, callback4);
        java.io.PrintStream printStream6 = null;
        com.google.javascript.jscomp.Compiler compiler7 = new com.google.javascript.jscomp.Compiler(printStream6);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile10 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        java.io.Reader reader11 = jSSourceFile10.getCodeReader();
        com.google.javascript.jscomp.JSModule[] jSModuleArray12 = new com.google.javascript.jscomp.JSModule[] {};
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph13 = new com.google.javascript.jscomp.JSModuleGraph(jSModuleArray12);
        com.google.javascript.jscomp.CompilerOptions compilerOptions14 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions14.setLooseTypes(true);
        boolean boolean17 = compilerOptions14.collapseVariableDeclarations;
        compilerOptions14.moveFunctionDeclarations = false;
        boolean boolean20 = compilerOptions14.decomposeExpressions;
        com.google.javascript.jscomp.CheckLevel checkLevel21 = compilerOptions14.checkMissingGetCssNameLevel;
        com.google.javascript.jscomp.Result result22 = compiler7.compile(jSSourceFile10, jSModuleArray12, compilerOptions14);
        java.io.PrintStream printStream23 = null;
        com.google.javascript.jscomp.Compiler compiler24 = new com.google.javascript.jscomp.Compiler(printStream23);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile27 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        java.io.Reader reader28 = jSSourceFile27.getCodeReader();
        com.google.javascript.jscomp.JSModule[] jSModuleArray29 = new com.google.javascript.jscomp.JSModule[] {};
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph30 = new com.google.javascript.jscomp.JSModuleGraph(jSModuleArray29);
        com.google.javascript.jscomp.CompilerOptions compilerOptions31 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions31.setLooseTypes(true);
        boolean boolean34 = compilerOptions31.collapseVariableDeclarations;
        compilerOptions31.moveFunctionDeclarations = false;
        boolean boolean37 = compilerOptions31.decomposeExpressions;
        com.google.javascript.jscomp.CheckLevel checkLevel38 = compilerOptions31.checkMissingGetCssNameLevel;
        com.google.javascript.jscomp.Result result39 = compiler24.compile(jSSourceFile27, jSModuleArray29, compilerOptions31);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile42 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        java.io.PrintStream printStream43 = null;
        com.google.javascript.jscomp.Compiler compiler44 = new com.google.javascript.jscomp.Compiler(printStream43);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile47 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        java.io.Reader reader48 = jSSourceFile47.getCodeReader();
        com.google.javascript.jscomp.JSModule[] jSModuleArray49 = new com.google.javascript.jscomp.JSModule[] {};
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph50 = new com.google.javascript.jscomp.JSModuleGraph(jSModuleArray49);
        com.google.javascript.jscomp.CompilerOptions compilerOptions51 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions51.setLooseTypes(true);
        boolean boolean54 = compilerOptions51.collapseVariableDeclarations;
        compilerOptions51.moveFunctionDeclarations = false;
        boolean boolean57 = compilerOptions51.decomposeExpressions;
        com.google.javascript.jscomp.CheckLevel checkLevel58 = compilerOptions51.checkMissingGetCssNameLevel;
        com.google.javascript.jscomp.Result result59 = compiler44.compile(jSSourceFile47, jSModuleArray49, compilerOptions51);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile62 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile65 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        java.io.Reader reader66 = jSSourceFile65.getCodeReader();
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray67 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile10, jSSourceFile27, jSSourceFile42, jSSourceFile47, jSSourceFile62, jSSourceFile65 };
        java.io.PrintStream printStream68 = null;
        com.google.javascript.jscomp.Compiler compiler69 = new com.google.javascript.jscomp.Compiler(printStream68);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile72 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        java.io.Reader reader73 = jSSourceFile72.getCodeReader();
        com.google.javascript.jscomp.JSModule[] jSModuleArray74 = new com.google.javascript.jscomp.JSModule[] {};
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph75 = new com.google.javascript.jscomp.JSModuleGraph(jSModuleArray74);
        com.google.javascript.jscomp.CompilerOptions compilerOptions76 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions76.setLooseTypes(true);
        boolean boolean79 = compilerOptions76.collapseVariableDeclarations;
        compilerOptions76.moveFunctionDeclarations = false;
        boolean boolean82 = compilerOptions76.decomposeExpressions;
        com.google.javascript.jscomp.CheckLevel checkLevel83 = compilerOptions76.checkMissingGetCssNameLevel;
        com.google.javascript.jscomp.Result result84 = compiler69.compile(jSSourceFile72, jSModuleArray74, compilerOptions76);
        com.google.javascript.jscomp.CompilerOptions compilerOptions85 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions85.setLooseTypes(true);
        boolean boolean88 = compilerOptions85.collapseVariableDeclarations;
        compilerOptions85.setManageClosureDependencies(false);
        com.google.javascript.jscomp.Result result91 = compiler1.compile(jSSourceFileArray67, jSModuleArray74, compilerOptions85);
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph92 = new com.google.javascript.jscomp.JSModuleGraph(jSModuleArray74);
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph93 = new com.google.javascript.jscomp.JSModuleGraph(jSModuleArray74);
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph94 = new com.google.javascript.jscomp.JSModuleGraph(jSModuleArray74);
        org.junit.Assert.assertNull(performanceTracker3);
        org.junit.Assert.assertNotNull(jSSourceFile10);
        org.junit.Assert.assertNotNull(reader11);
        org.junit.Assert.assertNotNull(jSModuleArray12);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + checkLevel21 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel21.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(result22);
        org.junit.Assert.assertNotNull(jSSourceFile27);
        org.junit.Assert.assertNotNull(reader28);
        org.junit.Assert.assertNotNull(jSModuleArray29);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + checkLevel38 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel38.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(result39);
        org.junit.Assert.assertNotNull(jSSourceFile42);
        org.junit.Assert.assertNotNull(jSSourceFile47);
        org.junit.Assert.assertNotNull(reader48);
        org.junit.Assert.assertNotNull(jSModuleArray49);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertTrue("'" + checkLevel58 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel58.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(result59);
        org.junit.Assert.assertNotNull(jSSourceFile62);
        org.junit.Assert.assertNotNull(jSSourceFile65);
        org.junit.Assert.assertNotNull(reader66);
        org.junit.Assert.assertNotNull(jSSourceFileArray67);
        org.junit.Assert.assertNotNull(jSSourceFile72);
        org.junit.Assert.assertNotNull(reader73);
        org.junit.Assert.assertNotNull(jSModuleArray74);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
        org.junit.Assert.assertTrue("'" + checkLevel83 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel83.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(result84);
        org.junit.Assert.assertTrue("'" + boolean88 + "' != '" + false + "'", boolean88 == false);
        org.junit.Assert.assertNotNull(result91);
    }

    @Test
    public void test70() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test70");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newString("hi!");
        int int2 = node1.getCharno();
        try {
            node1.setSideEffectFlags(1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: setIsNoSideEffectsCall only supports CALL and NEW nodes, got STRING");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test71() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test71");
        com.google.javascript.rhino.Node node1 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node3 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node5 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node7 = new com.google.javascript.rhino.Node((int) '4');
        node5.addChildrenToBack(node7);
        node1.addChildAfter(node3, node7);
        com.google.javascript.rhino.Node node11 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node((int) '4');
        node11.addChildrenToBack(node13);
        com.google.javascript.rhino.Node node15 = node1.copyInformationFromForTree(node13);
        com.google.javascript.rhino.Node node17 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node18 = node1.copyInformationFromForTree(node17);
        com.google.javascript.rhino.Node node19 = com.google.javascript.jscomp.NodeUtil.newExpr(node18);
        com.google.javascript.rhino.Node node21 = new com.google.javascript.rhino.Node((int) (short) 1);
        com.google.javascript.rhino.Node node23 = new com.google.javascript.rhino.Node((int) (short) 1);
        node21.addChildrenToBack(node23);
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable25 = node21.siblings();
        boolean boolean26 = node18.hasChild(node21);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNotNull(nodeIterable25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test72() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test72");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.EXTERNS_VALIDATION;
        com.google.javascript.jscomp.DiagnosticGroups.NON_STANDARD_JSDOC = diagnosticGroup0;
        com.google.javascript.rhino.Node node4 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node6 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node8 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node10 = new com.google.javascript.rhino.Node((int) '4');
        node8.addChildrenToBack(node10);
        node4.addChildAfter(node6, node10);
        com.google.javascript.rhino.Node node14 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node16 = new com.google.javascript.rhino.Node((int) '4');
        node14.addChildrenToBack(node16);
        com.google.javascript.rhino.Node node18 = node4.copyInformationFromForTree(node16);
        com.google.javascript.jscomp.DiagnosticType diagnosticType19 = com.google.javascript.jscomp.Compiler.MOTION_ITERATIONS_ERROR;
        java.lang.String str20 = diagnosticType19.toString();
        java.lang.String[] strArray21 = null;
        com.google.javascript.jscomp.JSError jSError22 = com.google.javascript.jscomp.JSError.make("", node16, diagnosticType19, strArray21);
        java.lang.String str23 = jSError22.description;
        try {
            boolean boolean24 = diagnosticGroup0.matches(jSError22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(diagnosticGroup0);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNotNull(diagnosticType19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}" + "'", str20.equals("JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}"));
        org.junit.Assert.assertNotNull(jSError22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "Exceeded max number of code motion iterations: {0}" + "'", str23.equals("Exceeded max number of code motion iterations: {0}"));
    }

    @Test
    public void test73() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test73");
        com.google.javascript.rhino.EcmaError ecmaError1 = com.google.javascript.rhino.ScriptRuntime.typeError("4");
        java.lang.String str2 = ecmaError1.getName();
        java.lang.String str3 = ecmaError1.lineSource();
        java.lang.String str4 = ecmaError1.toString();
        java.lang.String str5 = ecmaError1.details();
        org.junit.Assert.assertNotNull(ecmaError1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "TypeError" + "'", str2.equals("TypeError"));
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "com.google.javascript.rhino.EcmaError: TypeError: 4" + "'", str4.equals("com.google.javascript.rhino.EcmaError: TypeError: 4"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "TypeError: 4" + "'", str5.equals("TypeError: 4"));
    }

    @Test
    public void test74() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test74");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setLooseTypes(true);
        boolean boolean3 = compilerOptions0.collapseVariableDeclarations;
        compilerOptions0.recordFunctionInformation = false;
        compilerOptions0.convertToDottedProperties = false;
        compilerOptions0.checkUnusedPropertiesEarly = false;
        compilerOptions0.inlineLocalVariables = true;
        java.lang.Class<?> wildcardClass12 = compilerOptions0.getClass();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(wildcardClass12);
    }

    @Test
    public void test75() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test75");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setLooseTypes(true);
        compilerOptions0.renamePrefix = "hi!";
        compilerOptions0.checkControlStructures = false;
        boolean boolean7 = compilerOptions0.removeTryCatchFinally;
        boolean boolean8 = compilerOptions0.markAsCompiled;
        boolean boolean9 = compilerOptions0.removeTryCatchFinally;
        boolean boolean10 = compilerOptions0.groupVariableDeclarations;
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test76() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test76");
        com.google.javascript.rhino.Node node1 = new com.google.javascript.rhino.Node((int) '4');
        node1.setLineno(36);
        java.lang.Object obj5 = node1.getProp(18);
        org.junit.Assert.assertNull(obj5);
    }

    @Test
    public void test77() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test77");
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention0 = new com.google.javascript.jscomp.DefaultCodingConvention();
        java.lang.String str1 = defaultCodingConvention0.getDelegateSuperclassName();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = null;
        com.google.javascript.jscomp.Scope scope3 = null;
        com.google.javascript.rhino.jstype.ObjectType[] objectTypeArray4 = new com.google.javascript.rhino.jstype.ObjectType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.ObjectType> objectTypeList5 = new java.util.ArrayList<com.google.javascript.rhino.jstype.ObjectType>();
        boolean boolean6 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.ObjectType>) objectTypeList5, objectTypeArray4);
        defaultCodingConvention0.defineDelegateProxyPrototypeProperties(jSTypeRegistry2, scope3, (java.util.List<com.google.javascript.rhino.jstype.ObjectType>) objectTypeList5);
        boolean boolean9 = defaultCodingConvention0.isValidEnumKey("33");
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertNotNull(objectTypeArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test78() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test78");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setLooseTypes(true);
        compilerOptions0.checkSuspiciousCode = false;
        compilerOptions0.disambiguateProperties = true;
        java.util.Map<java.lang.String, com.google.javascript.rhino.Node> strMap7 = compilerOptions0.getDefineReplacements();
        compilerOptions0.inlineVariables = true;
        org.junit.Assert.assertNotNull(strMap7);
    }

    @Test
    public void test79() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test79");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        boolean boolean2 = closureCodingConvention0.isPrivate("// Input %num%");
        java.util.Collection<com.google.javascript.jscomp.CodingConvention.AssertionFunctionSpec> assertionFunctionSpecCollection3 = closureCodingConvention0.getAssertionFunctions();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(assertionFunctionSpecCollection3);
    }

    @Test
    public void test80() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test80");
        com.google.javascript.rhino.Context context0 = new com.google.javascript.rhino.Context();
        context0.setGeneratingSource(true);
        java.lang.Object obj3 = context0.getDebuggerContextData();
        com.google.javascript.rhino.EcmaError ecmaError5 = com.google.javascript.rhino.ScriptRuntime.typeError("4");
        java.lang.String str6 = ecmaError5.getName();
        java.lang.String str7 = ecmaError5.lineSource();
        java.lang.String str8 = ecmaError5.toString();
        java.lang.String str9 = ecmaError5.lineSource();
        ecmaError5.initLineSource("com.google.javascript.rhino.EcmaError: TypeError: 4");
        context0.removeThreadLocal((java.lang.Object) ecmaError5);
        java.lang.Object obj13 = context0.getDebuggerContextData();
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy14 = com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC;
        com.google.javascript.jscomp.CompilerOptions compilerOptions15 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions15.setLooseTypes(true);
        boolean boolean18 = compilerOptions15.reserveRawExports;
        com.google.javascript.jscomp.CheckLevel checkLevel19 = null;
        compilerOptions15.checkGlobalNamesLevel = checkLevel19;
        boolean boolean21 = compilerOptions15.convertToDottedProperties;
        compilerOptions15.inlineAnonymousFunctionExpressions = false;
        context0.putThreadLocal((java.lang.Object) propertyRenamingPolicy14, (java.lang.Object) compilerOptions15);
        context0.setInstructionObserverThreshold(26);
        org.junit.Assert.assertNull(obj3);
        org.junit.Assert.assertNotNull(ecmaError5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "TypeError" + "'", str6.equals("TypeError"));
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "com.google.javascript.rhino.EcmaError: TypeError: 4" + "'", str8.equals("com.google.javascript.rhino.EcmaError: TypeError: 4"));
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertNull(obj13);
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy14 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC + "'", propertyRenamingPolicy14.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test81() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test81");
        long long1 = com.google.javascript.rhino.ScriptRuntime.testUint32String("// Input %num%");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1L) + "'", long1 == (-1L));
    }

    @Test
    public void test82() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test82");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setLooseTypes(true);
        boolean boolean3 = compilerOptions0.reserveRawExports;
        com.google.javascript.jscomp.CheckLevel checkLevel4 = null;
        compilerOptions0.checkGlobalNamesLevel = checkLevel4;
        boolean boolean6 = compilerOptions0.convertToDottedProperties;
        compilerOptions0.setCollapsePropertiesOnExternTypes(true);
        com.google.javascript.jscomp.CompilerOptions.AliasTransformationHandler aliasTransformationHandler9 = compilerOptions0.getAliasTransformationHandler();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(aliasTransformationHandler9);
    }

//    @Test
//    public void test83() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test83");
//        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.STRICT_MODULE_DEP_CHECK;
//        com.google.javascript.jscomp.DiagnosticGroups.MISSING_PROPERTIES = diagnosticGroup0;
//        com.google.javascript.jscomp.DiagnosticGroups.CHECK_TYPES = diagnosticGroup0;
//        com.google.javascript.jscomp.DiagnosticGroups.TWEAKS = diagnosticGroup0;
//        com.google.javascript.jscomp.DiagnosticGroups.CHECK_REGEXP = diagnosticGroup0;
//        org.junit.Assert.assertNull(diagnosticGroup0);
//    }

    @Test
    public void test84() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test84");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setLooseTypes(true);
        boolean boolean3 = compilerOptions0.reserveRawExports;
        boolean boolean4 = compilerOptions0.flowSensitiveInlineVariables;
        compilerOptions0.reserveRawExports = true;
        compilerOptions0.inferTypesInGlobalScope = false;
        boolean boolean9 = compilerOptions0.markNoSideEffectCalls;
        compilerOptions0.aliasableGlobals = "com.google.javascript.rhino.EcmaError: TypeError: 4";
        compilerOptions0.aliasAllStrings = true;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test85() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test85");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setLooseTypes(true);
        boolean boolean3 = compilerOptions0.collapseVariableDeclarations;
        compilerOptions0.moveFunctionDeclarations = false;
        boolean boolean6 = compilerOptions0.decomposeExpressions;
        boolean boolean7 = compilerOptions0.optimizeParameters;
        java.lang.String str8 = compilerOptions0.inputDelimiter;
        java.lang.String[] strArray10 = new java.lang.String[] { "hi!" };
        java.util.LinkedHashSet<java.lang.String> strSet11 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean12 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet11, strArray10);
        compilerOptions0.stripTypes = strSet11;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap14 = null;
        compilerOptions0.cssRenamingMap = cssRenamingMap14;
        java.lang.String str16 = compilerOptions0.reportPath;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "// Input %num%" + "'", str8.equals("// Input %num%"));
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNull(str16);
    }

    @Test
    public void test86() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test86");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setLooseTypes(true);
        com.google.javascript.jscomp.CompilerOptions compilerOptions3 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions3.setLooseTypes(true);
        boolean boolean6 = compilerOptions3.reserveRawExports;
        boolean boolean7 = compilerOptions3.flowSensitiveInlineVariables;
        compilerOptions3.reserveRawExports = true;
        compilerOptions3.inferTypesInGlobalScope = false;
        com.google.javascript.jscomp.CheckLevel checkLevel12 = compilerOptions3.checkMethods;
        compilerOptions3.aliasKeywords = true;
        com.google.javascript.jscomp.CheckLevel checkLevel15 = compilerOptions3.checkGlobalThisLevel;
        compilerOptions0.checkFunctions = checkLevel15;
        boolean boolean17 = compilerOptions0.optimizeReturns;
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + checkLevel12 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel12.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + checkLevel15 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel15.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test87() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test87");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeUnusedPrototypePropertiesInExterns = false;
        boolean boolean3 = compilerOptions0.markAsCompiled;
        compilerOptions0.setDefineToBooleanLiteral("", true);
        boolean boolean7 = compilerOptions0.optimizeReturns;
        compilerOptions0.groupVariableDeclarations = false;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test88() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test88");
        com.google.javascript.jscomp.SourceAst sourceAst0 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(sourceAst0, "", false);
        com.google.javascript.jscomp.CompilerOptions compilerOptions5 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions5.setLooseTypes(true);
        boolean boolean8 = compilerOptions5.collapseVariableDeclarations;
        compilerOptions5.moveFunctionDeclarations = false;
        boolean boolean11 = compilerOptions5.decomposeExpressions;
        boolean boolean12 = compilerOptions5.optimizeParameters;
        java.lang.String str13 = compilerOptions5.inputDelimiter;
        com.google.javascript.jscomp.ErrorFormat errorFormat14 = com.google.javascript.jscomp.ErrorFormat.LEGACY;
        java.lang.RuntimeException runtimeException15 = com.google.javascript.rhino.ScriptRuntime.undefWriteError((java.lang.Object) (short) 100, (java.lang.Object) str13, (java.lang.Object) errorFormat14);
        java.io.PrintStream printStream16 = null;
        com.google.javascript.jscomp.Compiler compiler17 = new com.google.javascript.jscomp.Compiler(printStream16);
        compiler17.disableThreads();
        com.google.javascript.jscomp.PerformanceTracker performanceTracker19 = compiler17.tracker;
        com.google.javascript.jscomp.MessageFormatter messageFormatter21 = errorFormat14.toFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler17, false);
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter22 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler17);
        java.util.logging.Logger logger23 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager24 = new com.google.javascript.jscomp.LoggerErrorManager((com.google.javascript.jscomp.MessageFormatter) lightweightMessageFormatter22, logger23);
        compilerInput3.setErrorManager((com.google.javascript.jscomp.ErrorManager) loggerErrorManager24);
        com.google.javascript.jscomp.CompilerInput compilerInput28 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput3, "Exceeded max number of code motion iterations: {0}", false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "// Input %num%" + "'", str13.equals("// Input %num%"));
        org.junit.Assert.assertNotNull(errorFormat14);
        org.junit.Assert.assertNotNull(runtimeException15);
        org.junit.Assert.assertNull(performanceTracker19);
        org.junit.Assert.assertNotNull(messageFormatter21);
    }

    @Test
    public void test89() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test89");
        com.google.javascript.jscomp.DiagnosticGroup[] diagnosticGroupArray1 = null;
        try {
            com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup2 = new com.google.javascript.jscomp.DiagnosticGroup("JSC_OPTIMIZE_LOOP_ERROR. Exceeded max number of code motion iterations: {0} at (unknown source) line (unknown line) : (unknown column)", diagnosticGroupArray1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test90() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test90");
        com.google.javascript.jscomp.CompilerOptions compilerOptions1 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions1.setLooseTypes(true);
        boolean boolean4 = compilerOptions1.collapseVariableDeclarations;
        compilerOptions1.moveFunctionDeclarations = false;
        boolean boolean7 = compilerOptions1.decomposeExpressions;
        boolean boolean8 = compilerOptions1.optimizeParameters;
        java.lang.String str9 = compilerOptions1.inputDelimiter;
        com.google.javascript.jscomp.ErrorFormat errorFormat10 = com.google.javascript.jscomp.ErrorFormat.LEGACY;
        java.lang.RuntimeException runtimeException11 = com.google.javascript.rhino.ScriptRuntime.undefWriteError((java.lang.Object) (short) 100, (java.lang.Object) str9, (java.lang.Object) errorFormat10);
        java.io.PrintStream printStream12 = null;
        com.google.javascript.jscomp.Compiler compiler13 = new com.google.javascript.jscomp.Compiler(printStream12);
        compiler13.disableThreads();
        com.google.javascript.jscomp.PerformanceTracker performanceTracker15 = compiler13.tracker;
        com.google.javascript.jscomp.MessageFormatter messageFormatter17 = errorFormat10.toFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler13, false);
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter18 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler13);
        lightweightMessageFormatter18.setColorize(false);
        lightweightMessageFormatter18.setColorize(true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "// Input %num%" + "'", str9.equals("// Input %num%"));
        org.junit.Assert.assertNotNull(errorFormat10);
        org.junit.Assert.assertNotNull(runtimeException11);
        org.junit.Assert.assertNull(performanceTracker15);
        org.junit.Assert.assertNotNull(messageFormatter17);
    }
}

