import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.MISSING_PROPERTIES;
        com.google.javascript.jscomp.DiagnosticGroups.DEPRECATED = diagnosticGroup0;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = null;
        com.google.javascript.jscomp.DiagnosticGroups.UNDEFINED_VARIABLES = diagnosticGroup0;
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        com.google.javascript.jscomp.SourceAst sourceAst0 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(sourceAst0, "", false);
        boolean boolean4 = compilerInput3.isExtern();
        java.lang.String str5 = compilerInput3.getName();
        com.google.javascript.jscomp.JSModule jSModule6 = compilerInput3.getModule();
        com.google.javascript.jscomp.CompilerInput compilerInput9 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput3, "<No stack trace available>", false);
        try {
            com.google.javascript.jscomp.SourceFile sourceFile10 = compilerInput9.getSourceFile();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertNull(jSModule6);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setLooseTypes(true);
        boolean boolean3 = compilerOptions0.collapseVariableDeclarations;
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention4 = new com.google.javascript.jscomp.DefaultCodingConvention();
        boolean boolean6 = defaultCodingConvention4.isExported("// Input %num%");
        boolean boolean8 = defaultCodingConvention4.isSuperClassReference("");
        com.google.javascript.rhino.Node node10 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node12 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node14 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node16 = new com.google.javascript.rhino.Node((int) '4');
        node14.addChildrenToBack(node16);
        node10.addChildAfter(node12, node16);
        boolean boolean19 = node12.wasEmptyNode();
        java.lang.String str20 = defaultCodingConvention4.identifyTypeDefAssign(node12);
        boolean boolean23 = defaultCodingConvention4.isExported("Exceeded max number of code motion iterations: {0}", false);
        boolean boolean26 = defaultCodingConvention4.isExported("Not declared as a type name", false);
        compilerOptions0.setCodingConvention((com.google.javascript.jscomp.CodingConvention) defaultCodingConvention4);
        boolean boolean28 = compilerOptions0.smartNameRemoval;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNull(str20);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        java.io.PrintStream printStream2 = null;
        com.google.javascript.jscomp.Compiler compiler3 = new com.google.javascript.jscomp.Compiler(printStream2);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile6 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        java.io.Reader reader7 = jSSourceFile6.getCodeReader();
        com.google.javascript.jscomp.JSModule[] jSModuleArray8 = new com.google.javascript.jscomp.JSModule[] {};
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph9 = new com.google.javascript.jscomp.JSModuleGraph(jSModuleArray8);
        com.google.javascript.jscomp.CompilerOptions compilerOptions10 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions10.setLooseTypes(true);
        boolean boolean13 = compilerOptions10.collapseVariableDeclarations;
        compilerOptions10.moveFunctionDeclarations = false;
        boolean boolean16 = compilerOptions10.decomposeExpressions;
        com.google.javascript.jscomp.CheckLevel checkLevel17 = compilerOptions10.checkMissingGetCssNameLevel;
        com.google.javascript.jscomp.Result result18 = compiler3.compile(jSSourceFile6, jSModuleArray8, compilerOptions10);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile21 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile24 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        java.io.Reader reader25 = jSSourceFile24.getCodeReader();
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray26 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile6, jSSourceFile21, jSSourceFile24 };
        java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList27 = new java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile>();
        boolean boolean28 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList27, jSSourceFileArray26);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile31 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray32 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile31 };
        java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList33 = new java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile>();
        boolean boolean34 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList33, jSSourceFileArray32);
        com.google.javascript.jscomp.CompilerOptions compilerOptions35 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions35.setLooseTypes(true);
        boolean boolean38 = compilerOptions35.reserveRawExports;
        compilerOptions35.extractPrototypeMemberDeclarations = false;
        java.lang.String str41 = compilerOptions35.nameReferenceGraphPath;
        compilerOptions35.setSummaryDetailLevel(0);
        com.google.javascript.jscomp.Result result44 = compiler1.compile((java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList27, (java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList33, compilerOptions35);
        boolean boolean45 = compiler1.hasErrors();
        com.google.javascript.jscomp.JSError[] jSErrorArray46 = compiler1.getErrors();
        org.junit.Assert.assertNotNull(jSSourceFile6);
        org.junit.Assert.assertNotNull(reader7);
        org.junit.Assert.assertNotNull(jSModuleArray8);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + checkLevel17 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel17.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(result18);
        org.junit.Assert.assertNotNull(jSSourceFile21);
        org.junit.Assert.assertNotNull(jSSourceFile24);
        org.junit.Assert.assertNotNull(reader25);
        org.junit.Assert.assertNotNull(jSSourceFileArray26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(jSSourceFile31);
        org.junit.Assert.assertNotNull(jSSourceFileArray32);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNull(str41);
        org.junit.Assert.assertNotNull(result44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
        org.junit.Assert.assertNotNull(jSErrorArray46);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setLooseTypes(true);
        boolean boolean3 = compilerOptions0.reserveRawExports;
        compilerOptions0.smartNameRemoval = false;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newNumber((double) 160);
        org.junit.Assert.assertNotNull(node1);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setLooseTypes(true);
        boolean boolean3 = compilerOptions0.reserveRawExports;
        compilerOptions0.extractPrototypeMemberDeclarations = false;
        java.lang.String str6 = compilerOptions0.nameReferenceGraphPath;
        compilerOptions0.computeFunctionSideEffects = true;
        com.google.javascript.jscomp.CompilerOptions compilerOptions9 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions9.setLooseTypes(true);
        compilerOptions9.convertToDottedProperties = false;
        com.google.javascript.jscomp.CheckLevel checkLevel14 = compilerOptions9.reportMissingOverride;
        compilerOptions0.brokenClosureRequiresLevel = checkLevel14;
        compilerOptions0.coalesceVariableNames = true;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + checkLevel14 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel14.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node3 = new com.google.javascript.rhino.Node((int) (short) 1);
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newString("hi!");
        int int6 = node5.getCharno();
        com.google.javascript.rhino.Node node8 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node10 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node12 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node14 = new com.google.javascript.rhino.Node((int) '4');
        node12.addChildrenToBack(node14);
        node8.addChildAfter(node10, node14);
        com.google.javascript.rhino.Node node18 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node20 = new com.google.javascript.rhino.Node((int) '4');
        node18.addChildrenToBack(node20);
        com.google.javascript.rhino.Node node22 = node8.copyInformationFromForTree(node20);
        com.google.javascript.rhino.Node node23 = node8.cloneTree();
        com.google.javascript.rhino.Node node24 = node8.cloneTree();
        com.google.javascript.rhino.Node node26 = new com.google.javascript.rhino.Node((int) '4');
        node26.setLineno(36);
        com.google.javascript.rhino.Node[] nodeArray29 = new com.google.javascript.rhino.Node[] { node3, node5, node24, node26 };
        com.google.javascript.rhino.Node node32 = new com.google.javascript.rhino.Node(0, nodeArray29, 25, 14);
        com.google.javascript.rhino.Node node34 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node36 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node38 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node40 = new com.google.javascript.rhino.Node((int) '4');
        node38.addChildrenToBack(node40);
        node34.addChildAfter(node36, node40);
        com.google.javascript.rhino.Node node44 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node46 = new com.google.javascript.rhino.Node((int) '4');
        node44.addChildrenToBack(node46);
        com.google.javascript.rhino.Node node48 = node34.copyInformationFromForTree(node46);
        com.google.javascript.rhino.Node node49 = node34.cloneTree();
        com.google.javascript.rhino.Node node50 = node34.cloneTree();
        java.lang.String str51 = closureCodingConvention0.extractClassNameIfRequire(node32, node34);
        boolean boolean53 = closureCodingConvention0.isPrivate("hi!");
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertNotNull(nodeArray29);
        org.junit.Assert.assertNotNull(node48);
        org.junit.Assert.assertNotNull(node49);
        org.junit.Assert.assertNotNull(node50);
        org.junit.Assert.assertNull(str51);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        com.google.javascript.rhino.Context context0 = new com.google.javascript.rhino.Context();
        context0.setGeneratingSource(true);
        java.lang.Object obj3 = context0.getDebuggerContextData();
        com.google.javascript.rhino.EcmaError ecmaError5 = com.google.javascript.rhino.ScriptRuntime.typeError("4");
        java.lang.String str6 = ecmaError5.getName();
        java.lang.String str7 = ecmaError5.lineSource();
        java.lang.String str8 = ecmaError5.toString();
        java.lang.String str9 = ecmaError5.lineSource();
        ecmaError5.initLineSource("com.google.javascript.rhino.EcmaError: TypeError: 4");
        context0.removeThreadLocal((java.lang.Object) ecmaError5);
        java.lang.String str13 = ecmaError5.sourceName();
        java.lang.String str14 = ecmaError5.sourceName();
        org.junit.Assert.assertNull(obj3);
        org.junit.Assert.assertNotNull(ecmaError5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "TypeError" + "'", str6.equals("TypeError"));
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "com.google.javascript.rhino.EcmaError: TypeError: 4" + "'", str8.equals("com.google.javascript.rhino.EcmaError: TypeError: 4"));
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertNull(str14);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        int int0 = com.google.javascript.rhino.Node.LABEL_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 19 + "'", int0 == 19);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setLooseTypes(true);
        compilerOptions0.renamePrefix = "hi!";
        java.lang.String str5 = compilerOptions0.locale;
        boolean boolean6 = compilerOptions0.aliasKeywords;
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.STRICT_MODULE_DEP_CHECK;
        com.google.javascript.jscomp.DiagnosticGroups.MISSING_PROPERTIES = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticGroups.GLOBAL_THIS = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticGroups.MISSING_PROPERTIES = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticGroups.UNKNOWN_DEFINES = diagnosticGroup0;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        com.google.javascript.rhino.EvaluatorException evaluatorException1 = new com.google.javascript.rhino.EvaluatorException("hi!: hi!");
        java.lang.String str2 = evaluatorException1.sourceName();
        java.lang.String str3 = evaluatorException1.lineSource();
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        java.util.Collection<com.google.javascript.jscomp.CodingConvention.AssertionFunctionSpec> assertionFunctionSpecCollection1 = closureCodingConvention0.getAssertionFunctions();
        java.lang.String str2 = closureCodingConvention0.getGlobalObject();
        com.google.javascript.rhino.Node node4 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node6 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node8 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node10 = new com.google.javascript.rhino.Node((int) '4');
        node8.addChildrenToBack(node10);
        node4.addChildAfter(node6, node10);
        com.google.javascript.rhino.Node node14 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node16 = new com.google.javascript.rhino.Node((int) '4');
        node14.addChildrenToBack(node16);
        com.google.javascript.rhino.Node node18 = node4.copyInformationFromForTree(node16);
        com.google.javascript.rhino.Node node20 = node4.getAncestor(1);
        boolean boolean21 = closureCodingConvention0.isOptionalParameter(node20);
        java.io.PrintStream printStream22 = null;
        com.google.javascript.jscomp.Compiler compiler23 = new com.google.javascript.jscomp.Compiler(printStream22);
        compiler23.disableThreads();
        com.google.javascript.jscomp.PerformanceTracker performanceTracker25 = compiler23.tracker;
        com.google.javascript.jscomp.NodeTraversal.Callback callback26 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal27 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler23, callback26);
        com.google.javascript.rhino.Node node29 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node31 = new com.google.javascript.rhino.Node((int) '4');
        node29.addChildrenToBack(node31);
        com.google.javascript.jscomp.DiagnosticType diagnosticType35 = com.google.javascript.jscomp.DiagnosticType.warning("hi!", "hi!");
        com.google.javascript.jscomp.DiagnosticType diagnosticType36 = com.google.javascript.jscomp.Compiler.MOTION_ITERATIONS_ERROR;
        int int37 = diagnosticType35.compareTo(diagnosticType36);
        java.lang.String[] strArray38 = com.google.javascript.rhino.ScriptRuntime.emptyStrings;
        com.google.javascript.jscomp.JSError jSError39 = nodeTraversal27.makeError(node31, diagnosticType35, strArray38);
        com.google.javascript.rhino.Node node41 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node43 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node45 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node47 = new com.google.javascript.rhino.Node((int) '4');
        node45.addChildrenToBack(node47);
        node41.addChildAfter(node43, node47);
        com.google.javascript.rhino.Node node50 = node47.getParent();
        try {
            com.google.javascript.jscomp.CodingConvention.ObjectLiteralCast objectLiteralCast51 = closureCodingConvention0.getObjectLiteralCast(nodeTraversal27, node50);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(assertionFunctionSpecCollection1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "goog.global" + "'", str2.equals("goog.global"));
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNull(node20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNull(performanceTracker25);
        org.junit.Assert.assertNotNull(diagnosticType35);
        org.junit.Assert.assertNotNull(diagnosticType36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 30 + "'", int37 == 30);
        org.junit.Assert.assertNotNull(strArray38);
        org.junit.Assert.assertNotNull(jSError39);
        org.junit.Assert.assertNotNull(node50);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        com.google.javascript.rhino.Node node1 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node3 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node5 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node7 = new com.google.javascript.rhino.Node((int) '4');
        node5.addChildrenToBack(node7);
        node1.addChildAfter(node3, node7);
        node7.setIsSyntheticBlock(false);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        com.google.javascript.jscomp.SourceAst sourceAst0 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(sourceAst0, "", false);
        boolean boolean4 = compilerInput3.isExtern();
        java.lang.String str5 = compilerInput3.getName();
        com.google.javascript.jscomp.JSModule jSModule6 = compilerInput3.getModule();
        com.google.javascript.jscomp.CompilerInput compilerInput9 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput3, "<No stack trace available>", false);
        try {
            com.google.javascript.jscomp.Region region11 = compilerInput9.getRegion((int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertNull(jSModule6);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        com.google.javascript.rhino.Node node1 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node3 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node5 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node7 = new com.google.javascript.rhino.Node((int) '4');
        node5.addChildrenToBack(node7);
        node1.addChildAfter(node3, node7);
        com.google.javascript.rhino.Node node11 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node((int) '4');
        node11.addChildrenToBack(node13);
        com.google.javascript.rhino.Node node15 = node1.copyInformationFromForTree(node13);
        com.google.javascript.rhino.Node node17 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node18 = node1.copyInformationFromForTree(node17);
        com.google.javascript.rhino.Node node19 = com.google.javascript.jscomp.NodeUtil.newExpr(node18);
        int int20 = node19.getType();
        com.google.javascript.rhino.Node node24 = new com.google.javascript.rhino.Node(30, 35, 8);
        com.google.javascript.rhino.Node node25 = node24.getLastSibling();
        node19.addChildrenToBack(node24);
        com.google.javascript.rhino.JSDocInfo jSDocInfo27 = null;
        node24.setJSDocInfo(jSDocInfo27);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 130 + "'", int20 == 130);
        org.junit.Assert.assertNotNull(node25);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setLooseTypes(true);
        boolean boolean3 = compilerOptions0.reserveRawExports;
        com.google.javascript.jscomp.CheckLevel checkLevel4 = null;
        compilerOptions0.checkUnreachableCode = checkLevel4;
        com.google.javascript.jscomp.MessageBundle messageBundle6 = compilerOptions0.messageBundle;
        java.lang.String str7 = compilerOptions0.sourceMapOutputPath;
        compilerOptions0.generateExports = true;
        compilerOptions0.syntheticBlockStartMarker = "window";
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(messageBundle6);
        org.junit.Assert.assertNull(str7);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        com.google.javascript.jscomp.DiagnosticType diagnosticType1 = com.google.javascript.jscomp.Compiler.MOTION_ITERATIONS_ERROR;
        java.lang.String str2 = diagnosticType1.toString();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile4 = com.google.javascript.jscomp.JSSourceFile.fromFile("window");
        com.google.javascript.jscomp.CompilerOptions compilerOptions5 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions5.setLooseTypes(true);
        boolean boolean8 = compilerOptions5.collapseVariableDeclarations;
        compilerOptions5.recordFunctionInformation = false;
        compilerOptions5.optimizeReturns = false;
        com.google.javascript.jscomp.CompilerOptions compilerOptions13 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions13.setLooseTypes(true);
        compilerOptions13.convertToDottedProperties = false;
        com.google.javascript.jscomp.CheckLevel checkLevel18 = compilerOptions13.reportMissingOverride;
        compilerOptions5.aggressiveVarCheck = checkLevel18;
        com.google.javascript.jscomp.DiagnosticType diagnosticType22 = com.google.javascript.jscomp.DiagnosticType.error("window", "");
        try {
            java.lang.String str23 = com.google.javascript.rhino.ScriptRuntime.getMessage4("(// Input %num%)", (java.lang.Object) str2, (java.lang.Object) "window", (java.lang.Object) checkLevel18, (java.lang.Object) diagnosticType22);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property (// Input %num%)");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(diagnosticType1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}" + "'", str2.equals("JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}"));
        org.junit.Assert.assertNotNull(jSSourceFile4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + checkLevel18 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel18.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(diagnosticType22);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setLooseTypes(true);
        compilerOptions0.convertToDottedProperties = false;
        com.google.javascript.jscomp.CheckLevel checkLevel5 = compilerOptions0.reportMissingOverride;
        boolean boolean6 = compilerOptions0.aliasAllStrings;
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention7 = new com.google.javascript.jscomp.DefaultCodingConvention();
        boolean boolean9 = defaultCodingConvention7.isConstant("hi!");
        java.lang.String str10 = defaultCodingConvention7.getExportSymbolFunction();
        com.google.javascript.rhino.Node node12 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node14 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node16 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node18 = new com.google.javascript.rhino.Node((int) '4');
        node16.addChildrenToBack(node18);
        node12.addChildAfter(node14, node18);
        java.util.List<java.lang.String> strList21 = defaultCodingConvention7.identifyTypeDeclarationCall(node12);
        compilerOptions0.setCodingConvention((com.google.javascript.jscomp.CodingConvention) defaultCodingConvention7);
        byte[] byteArray23 = compilerOptions0.inputVariableMapSerialized;
        org.junit.Assert.assertTrue("'" + checkLevel5 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel5.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertNull(strList21);
        org.junit.Assert.assertNull(byteArray23);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeUnusedPrototypePropertiesInExterns = false;
        compilerOptions0.removeUnusedLocalVars = false;
        compilerOptions0.ignoreCajaProperties = false;
        compilerOptions0.setRemoveClosureAsserts(false);
        boolean boolean9 = compilerOptions0.checkSuspiciousCode;
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setLooseTypes(true);
        boolean boolean3 = compilerOptions0.reserveRawExports;
        com.google.javascript.jscomp.CheckLevel checkLevel4 = null;
        compilerOptions0.checkUnreachableCode = checkLevel4;
        com.google.javascript.jscomp.MessageBundle messageBundle6 = compilerOptions0.messageBundle;
        java.lang.String str7 = compilerOptions0.sourceMapOutputPath;
        compilerOptions0.aliasKeywords = true;
        boolean boolean10 = compilerOptions0.checkUnusedPropertiesEarly;
        com.google.javascript.jscomp.CheckLevel checkLevel11 = compilerOptions0.checkProvides;
        boolean boolean12 = compilerOptions0.shouldColorizeErrorOutput();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(messageBundle6);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + checkLevel11 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel11.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile4 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        java.io.Reader reader5 = jSSourceFile4.getCodeReader();
        com.google.javascript.jscomp.JSModule[] jSModuleArray6 = new com.google.javascript.jscomp.JSModule[] {};
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph7 = new com.google.javascript.jscomp.JSModuleGraph(jSModuleArray6);
        com.google.javascript.jscomp.CompilerOptions compilerOptions8 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions8.setLooseTypes(true);
        boolean boolean11 = compilerOptions8.collapseVariableDeclarations;
        compilerOptions8.moveFunctionDeclarations = false;
        boolean boolean14 = compilerOptions8.decomposeExpressions;
        com.google.javascript.jscomp.CheckLevel checkLevel15 = compilerOptions8.checkMissingGetCssNameLevel;
        com.google.javascript.jscomp.Result result16 = compiler1.compile(jSSourceFile4, jSModuleArray6, compilerOptions8);
        com.google.javascript.jscomp.Result result17 = compiler1.getResult();
        com.google.javascript.jscomp.Compiler.IntermediateState intermediateState18 = compiler1.getState();
        boolean boolean19 = compiler1.hasErrors();
        try {
            compiler1.normalize();
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: INTERNAL COMPILER ERROR.\nPlease report this problem.\nnull");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile4);
        org.junit.Assert.assertNotNull(reader5);
        org.junit.Assert.assertNotNull(jSModuleArray6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + checkLevel15 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel15.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(result16);
        org.junit.Assert.assertNotNull(result17);
        org.junit.Assert.assertNotNull(intermediateState18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        com.google.javascript.jscomp.SourceAst sourceAst0 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(sourceAst0, "", false);
        boolean boolean4 = compilerInput3.isExtern();
        java.lang.String str5 = compilerInput3.getName();
        try {
            compilerInput3.clearAst();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setLooseTypes(true);
        boolean boolean3 = compilerOptions0.collapseVariableDeclarations;
        boolean boolean4 = compilerOptions0.generateExports;
        boolean boolean5 = compilerOptions0.optimizeArgumentsArray;
        compilerOptions0.setSummaryDetailLevel((int) 'a');
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setLooseTypes(true);
        boolean boolean3 = compilerOptions0.collapseVariableDeclarations;
        compilerOptions0.recordFunctionInformation = false;
        compilerOptions0.convertToDottedProperties = false;
        compilerOptions0.collapseVariableDeclarations = false;
        compilerOptions0.inlineGetters = false;
        compilerOptions0.prettyPrint = true;
        compilerOptions0.setNameAnonymousFunctionsOnly(false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        java.io.InputStream inputStream2 = null;
        try {
            com.google.javascript.jscomp.SourceFile sourceFile3 = com.google.javascript.jscomp.SourceFile.fromInputStream("false", "JSC_OPTIMIZE_LOOP_ERROR. Exceeded max number of code motion iterations: {0} at (unknown source) line (unknown line) : (unknown column)", inputStream2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setLooseTypes(true);
        boolean boolean3 = compilerOptions0.reserveRawExports;
        com.google.javascript.jscomp.CheckLevel checkLevel4 = null;
        compilerOptions0.checkUnreachableCode = checkLevel4;
        boolean boolean6 = compilerOptions0.devirtualizePrototypeMethods;
        compilerOptions0.gatherCssNames = false;
        compilerOptions0.enableRuntimeTypeCheck("()");
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        com.google.javascript.jscomp.DiagnosticType diagnosticType2 = com.google.javascript.jscomp.DiagnosticType.warning("hi!", "hi!");
        com.google.javascript.jscomp.DiagnosticType diagnosticType3 = com.google.javascript.jscomp.Compiler.MOTION_ITERATIONS_ERROR;
        int int4 = diagnosticType2.compareTo(diagnosticType3);
        com.google.javascript.jscomp.CheckLevel checkLevel5 = diagnosticType2.defaultLevel;
        java.text.MessageFormat messageFormat6 = diagnosticType2.format;
        org.junit.Assert.assertNotNull(diagnosticType2);
        org.junit.Assert.assertNotNull(diagnosticType3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 30 + "'", int4 == 30);
        org.junit.Assert.assertTrue("'" + checkLevel5 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel5.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
        org.junit.Assert.assertNotNull(messageFormat6);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setLooseTypes(true);
        boolean boolean3 = compilerOptions0.collapseVariableDeclarations;
        compilerOptions0.moveFunctionDeclarations = false;
        com.google.javascript.jscomp.CompilerOptions.TweakProcessing tweakProcessing6 = compilerOptions0.getTweakProcessing();
        boolean boolean7 = tweakProcessing6.isOn();
        boolean boolean8 = tweakProcessing6.shouldStrip();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + tweakProcessing6 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TweakProcessing.OFF + "'", tweakProcessing6.equals(com.google.javascript.jscomp.CompilerOptions.TweakProcessing.OFF));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setLooseTypes(true);
        boolean boolean3 = compilerOptions0.reserveRawExports;
        com.google.javascript.jscomp.CheckLevel checkLevel4 = null;
        compilerOptions0.checkUnreachableCode = checkLevel4;
        com.google.javascript.jscomp.MessageBundle messageBundle6 = compilerOptions0.messageBundle;
        compilerOptions0.checkDuplicateMessages = false;
        compilerOptions0.aliasExternals = true;
        compilerOptions0.aliasAllStrings = false;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy13 = com.google.javascript.jscomp.VariableRenamingPolicy.LOCAL;
        compilerOptions0.variableRenaming = variableRenamingPolicy13;
        com.google.javascript.jscomp.DiagnosticType diagnosticType17 = com.google.javascript.jscomp.DiagnosticType.warning("hi!", "hi!");
        com.google.javascript.jscomp.CheckLevel checkLevel18 = diagnosticType17.defaultLevel;
        compilerOptions0.checkProvides = checkLevel18;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(messageBundle6);
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy13 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.LOCAL + "'", variableRenamingPolicy13.equals(com.google.javascript.jscomp.VariableRenamingPolicy.LOCAL));
        org.junit.Assert.assertNotNull(diagnosticType17);
        org.junit.Assert.assertTrue("'" + checkLevel18 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel18.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setLooseTypes(true);
        boolean boolean3 = compilerOptions0.reserveRawExports;
        compilerOptions0.extractPrototypeMemberDeclarations = false;
        compilerOptions0.checkMissingGetCssNameBlacklist = "4";
        compilerOptions0.locale = "error reporter";
        compilerOptions0.crossModuleMethodMotion = false;
        com.google.javascript.jscomp.ErrorFormat errorFormat12 = null;
        compilerOptions0.errorFormat = errorFormat12;
        compilerOptions0.setPropertyAffinity(false);
        compilerOptions0.setDefineToDoubleLiteral("(<No stack trace available>)", (double) (short) -1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        try {
            com.google.javascript.rhino.Context.reportError("<No stack trace available>", "INSTANCEOF\n", 20, "Named type with empty name component", (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type com.google.javascript.rhino.EvaluatorException; message: <No stack trace available> (INSTANCEOF\n#20)");
        } catch (com.google.javascript.rhino.EvaluatorException e) {
        }
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.PerformanceTracker performanceTracker2 = null;
        compiler1.tracker = performanceTracker2;
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        java.io.PrintStream printStream2 = null;
        com.google.javascript.jscomp.Compiler compiler3 = new com.google.javascript.jscomp.Compiler(printStream2);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile6 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        java.io.Reader reader7 = jSSourceFile6.getCodeReader();
        com.google.javascript.jscomp.JSModule[] jSModuleArray8 = new com.google.javascript.jscomp.JSModule[] {};
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph9 = new com.google.javascript.jscomp.JSModuleGraph(jSModuleArray8);
        com.google.javascript.jscomp.CompilerOptions compilerOptions10 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions10.setLooseTypes(true);
        boolean boolean13 = compilerOptions10.collapseVariableDeclarations;
        compilerOptions10.moveFunctionDeclarations = false;
        boolean boolean16 = compilerOptions10.decomposeExpressions;
        com.google.javascript.jscomp.CheckLevel checkLevel17 = compilerOptions10.checkMissingGetCssNameLevel;
        com.google.javascript.jscomp.Result result18 = compiler3.compile(jSSourceFile6, jSModuleArray8, compilerOptions10);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile21 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile24 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        java.io.Reader reader25 = jSSourceFile24.getCodeReader();
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray26 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile6, jSSourceFile21, jSSourceFile24 };
        java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList27 = new java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile>();
        boolean boolean28 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList27, jSSourceFileArray26);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile31 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray32 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile31 };
        java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList33 = new java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile>();
        boolean boolean34 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList33, jSSourceFileArray32);
        com.google.javascript.jscomp.CompilerOptions compilerOptions35 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions35.setLooseTypes(true);
        boolean boolean38 = compilerOptions35.reserveRawExports;
        compilerOptions35.extractPrototypeMemberDeclarations = false;
        java.lang.String str41 = compilerOptions35.nameReferenceGraphPath;
        compilerOptions35.setSummaryDetailLevel(0);
        com.google.javascript.jscomp.Result result44 = compiler1.compile((java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList27, (java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList33, compilerOptions35);
        int int45 = compiler1.getWarningCount();
        com.google.javascript.jscomp.PerformanceTracker performanceTracker46 = compiler1.tracker;
        boolean boolean47 = compiler1.isTypeCheckingEnabled();
        java.lang.String str48 = compiler1.getAstDotGraph();
        com.google.javascript.jscomp.Compiler.CodeBuilder codeBuilder49 = null;
        com.google.javascript.rhino.Node node52 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node54 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node56 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node58 = new com.google.javascript.rhino.Node((int) '4');
        node56.addChildrenToBack(node58);
        node52.addChildAfter(node54, node58);
        com.google.javascript.rhino.Node node61 = node52.cloneTree();
        try {
            compiler1.toSource(codeBuilder49, 45, node61);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: java.lang.Error: Unknown type 52\nINSTANCEOF\n");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile6);
        org.junit.Assert.assertNotNull(reader7);
        org.junit.Assert.assertNotNull(jSModuleArray8);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + checkLevel17 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel17.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(result18);
        org.junit.Assert.assertNotNull(jSSourceFile21);
        org.junit.Assert.assertNotNull(jSSourceFile24);
        org.junit.Assert.assertNotNull(reader25);
        org.junit.Assert.assertNotNull(jSSourceFileArray26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(jSSourceFile31);
        org.junit.Assert.assertNotNull(jSSourceFileArray32);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNull(str41);
        org.junit.Assert.assertNotNull(result44);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 0 + "'", int45 == 0);
        org.junit.Assert.assertNull(performanceTracker46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "" + "'", str48.equals(""));
        org.junit.Assert.assertNotNull(node61);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setLooseTypes(true);
        boolean boolean3 = compilerOptions0.collapseVariableDeclarations;
        compilerOptions0.recordFunctionInformation = false;
        compilerOptions0.convertToDottedProperties = false;
        compilerOptions0.collapseVariableDeclarations = false;
        compilerOptions0.inlineGetters = false;
        compilerOptions0.syntheticBlockStartMarker = "TypeError: 4";
        compilerOptions0.ambiguateProperties = false;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        com.google.javascript.rhino.Node node2 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node4 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node6 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node8 = new com.google.javascript.rhino.Node((int) '4');
        node6.addChildrenToBack(node8);
        node2.addChildAfter(node4, node8);
        com.google.javascript.rhino.Node node12 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node14 = new com.google.javascript.rhino.Node((int) '4');
        node12.addChildrenToBack(node14);
        com.google.javascript.rhino.Node node16 = node2.copyInformationFromForTree(node14);
        com.google.javascript.jscomp.DiagnosticType diagnosticType17 = com.google.javascript.jscomp.Compiler.MOTION_ITERATIONS_ERROR;
        java.lang.String str18 = diagnosticType17.toString();
        java.lang.String[] strArray19 = null;
        com.google.javascript.jscomp.JSError jSError20 = com.google.javascript.jscomp.JSError.make("", node14, diagnosticType17, strArray19);
        int int21 = jSError20.getCharno();
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertNotNull(diagnosticType17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}" + "'", str18.equals("JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}"));
        org.junit.Assert.assertNotNull(jSError20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        com.google.javascript.rhino.Context context0 = new com.google.javascript.rhino.Context();
        context0.setGeneratingSource(true);
        java.lang.Object obj3 = context0.getDebuggerContextData();
        boolean boolean5 = context0.isActivationNeeded("(<No stack trace available>)");
        org.junit.Assert.assertNull(obj3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        int int0 = com.google.javascript.rhino.Node.USES_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 11 + "'", int0 == 11);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        com.google.javascript.rhino.EcmaError ecmaError1 = com.google.javascript.rhino.ScriptRuntime.typeError("");
        ecmaError1.initSourceName("");
        ecmaError1.initLineSource("Exceeded max number of code motion iterations: {0}");
        org.junit.Assert.assertNotNull(ecmaError1);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setLooseTypes(true);
        boolean boolean3 = compilerOptions0.collapseVariableDeclarations;
        com.google.javascript.jscomp.CheckLevel checkLevel4 = null;
        compilerOptions0.checkMethods = checkLevel4;
        compilerOptions0.flowSensitiveInlineVariables = true;
        boolean boolean8 = compilerOptions0.checkDuplicateMessages;
        boolean boolean9 = compilerOptions0.deadAssignmentElimination;
        boolean boolean10 = compilerOptions0.flowSensitiveInlineVariables;
        compilerOptions0.crossModuleCodeMotion = true;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setLooseTypes(true);
        compilerOptions0.convertToDottedProperties = false;
        com.google.javascript.jscomp.CheckLevel checkLevel5 = compilerOptions0.reportMissingOverride;
        boolean boolean6 = compilerOptions0.aliasAllStrings;
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention7 = new com.google.javascript.jscomp.DefaultCodingConvention();
        boolean boolean9 = defaultCodingConvention7.isConstant("hi!");
        java.lang.String str10 = defaultCodingConvention7.getExportSymbolFunction();
        com.google.javascript.rhino.Node node12 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node14 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node16 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node18 = new com.google.javascript.rhino.Node((int) '4');
        node16.addChildrenToBack(node18);
        node12.addChildAfter(node14, node18);
        java.util.List<java.lang.String> strList21 = defaultCodingConvention7.identifyTypeDeclarationCall(node12);
        compilerOptions0.setCodingConvention((com.google.javascript.jscomp.CodingConvention) defaultCodingConvention7);
        com.google.javascript.jscomp.CheckLevel checkLevel23 = compilerOptions0.checkFunctions;
        org.junit.Assert.assertTrue("'" + checkLevel5 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel5.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertNull(strList21);
        org.junit.Assert.assertTrue("'" + checkLevel23 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel23.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        com.google.javascript.rhino.Node node1 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node3 = new com.google.javascript.rhino.Node((int) '4');
        node1.addChildrenToBack(node3);
        com.google.javascript.rhino.Node node5 = node1.getLastChild();
        node1.setLineno(7);
        com.google.javascript.rhino.Node node9 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node11 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node15 = new com.google.javascript.rhino.Node((int) '4');
        node13.addChildrenToBack(node15);
        node9.addChildAfter(node11, node15);
        com.google.javascript.rhino.Node node19 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node21 = new com.google.javascript.rhino.Node((int) '4');
        node19.addChildrenToBack(node21);
        com.google.javascript.rhino.Node node23 = node9.copyInformationFromForTree(node21);
        com.google.javascript.rhino.Node node25 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node26 = node9.copyInformationFromForTree(node25);
        boolean boolean27 = node25.isQualifiedName();
        com.google.javascript.rhino.Node node29 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node31 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node33 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node35 = new com.google.javascript.rhino.Node((int) '4');
        node33.addChildrenToBack(node35);
        node29.addChildAfter(node31, node35);
        com.google.javascript.rhino.Node node39 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node41 = new com.google.javascript.rhino.Node((int) '4');
        node39.addChildrenToBack(node41);
        com.google.javascript.rhino.Node node43 = node29.copyInformationFromForTree(node41);
        node1.addChildAfter(node25, node41);
        com.google.javascript.rhino.Node node46 = new com.google.javascript.rhino.Node(23);
        com.google.javascript.rhino.Node node50 = new com.google.javascript.rhino.Node(30, 35, 8);
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable51 = node50.siblings();
        com.google.javascript.rhino.JSDocInfo jSDocInfo52 = node50.getJSDocInfo();
        com.google.javascript.rhino.Node node53 = node50.getNext();
        try {
            node41.addChildAfter(node46, node53);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(node43);
        org.junit.Assert.assertNotNull(nodeIterable51);
        org.junit.Assert.assertNull(jSDocInfo52);
        org.junit.Assert.assertNull(node53);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        com.google.javascript.jscomp.SourceAst sourceAst0 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(sourceAst0, "", false);
        com.google.javascript.jscomp.JSModule jSModule4 = compilerInput3.getModule();
        try {
            java.util.Collection<java.lang.String> strCollection5 = compilerInput3.getProvides();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Expected setErrorManager to be called first");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(jSModule4);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        com.google.javascript.rhino.Node node1 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node3 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node5 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node7 = new com.google.javascript.rhino.Node((int) '4');
        node5.addChildrenToBack(node7);
        node1.addChildAfter(node3, node7);
        com.google.javascript.rhino.Node node11 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node((int) '4');
        node11.addChildrenToBack(node13);
        com.google.javascript.rhino.Node node15 = node1.copyInformationFromForTree(node13);
        com.google.javascript.rhino.Node node17 = node1.getAncestor(1);
        com.google.javascript.rhino.Node node19 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node21 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node23 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node25 = new com.google.javascript.rhino.Node((int) '4');
        node23.addChildrenToBack(node25);
        node19.addChildAfter(node21, node25);
        com.google.javascript.rhino.Node node29 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node31 = new com.google.javascript.rhino.Node((int) '4');
        node29.addChildrenToBack(node31);
        com.google.javascript.rhino.Node node33 = node19.copyInformationFromForTree(node31);
        com.google.javascript.rhino.Node node35 = node19.getAncestor(1);
        node1.addChildToFront(node19);
        com.google.javascript.rhino.Node node37 = node1.getNext();
        com.google.javascript.rhino.Node node38 = node1.cloneTree();
        com.google.javascript.rhino.Node node40 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node42 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node44 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node46 = new com.google.javascript.rhino.Node((int) '4');
        node44.addChildrenToBack(node46);
        node40.addChildAfter(node42, node46);
        com.google.javascript.rhino.Node node50 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node52 = new com.google.javascript.rhino.Node((int) '4');
        node50.addChildrenToBack(node52);
        com.google.javascript.rhino.Node node54 = node40.copyInformationFromForTree(node52);
        com.google.javascript.rhino.Node node56 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node57 = node40.copyInformationFromForTree(node56);
        com.google.javascript.rhino.Node node58 = com.google.javascript.jscomp.NodeUtil.newExpr(node57);
        com.google.javascript.rhino.Node node59 = node1.copyInformationFrom(node58);
        try {
            java.lang.String str60 = node58.getString();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: EXPR_RESULT is not a string node");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertNull(node17);
        org.junit.Assert.assertNotNull(node33);
        org.junit.Assert.assertNull(node35);
        org.junit.Assert.assertNull(node37);
        org.junit.Assert.assertNotNull(node38);
        org.junit.Assert.assertNotNull(node54);
        org.junit.Assert.assertNotNull(node57);
        org.junit.Assert.assertNotNull(node58);
        org.junit.Assert.assertNotNull(node59);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setLooseTypes(true);
        boolean boolean3 = compilerOptions0.reserveRawExports;
        com.google.javascript.jscomp.CheckLevel checkLevel4 = null;
        compilerOptions0.checkUnreachableCode = checkLevel4;
        com.google.javascript.jscomp.MessageBundle messageBundle6 = compilerOptions0.messageBundle;
        java.lang.String str7 = compilerOptions0.sourceMapOutputPath;
        compilerOptions0.inlineConstantVars = false;
        com.google.javascript.jscomp.CheckLevel checkLevel10 = compilerOptions0.checkProvides;
        boolean boolean11 = compilerOptions0.aliasAllStrings;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(messageBundle6);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + checkLevel10 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel10.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        java.lang.String str1 = closureCodingConvention0.getGlobalObject();
        java.io.PrintStream printStream2 = null;
        com.google.javascript.jscomp.Compiler compiler3 = new com.google.javascript.jscomp.Compiler(printStream2);
        compiler3.disableThreads();
        com.google.javascript.jscomp.PerformanceTracker performanceTracker5 = compiler3.tracker;
        com.google.javascript.jscomp.NodeTraversal.Callback callback6 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal7 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler3, callback6);
        com.google.javascript.rhino.Node node9 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node11 = new com.google.javascript.rhino.Node((int) '4');
        node9.addChildrenToBack(node11);
        com.google.javascript.jscomp.DiagnosticType diagnosticType15 = com.google.javascript.jscomp.DiagnosticType.warning("hi!", "hi!");
        com.google.javascript.jscomp.DiagnosticType diagnosticType16 = com.google.javascript.jscomp.Compiler.MOTION_ITERATIONS_ERROR;
        int int17 = diagnosticType15.compareTo(diagnosticType16);
        java.lang.String[] strArray18 = com.google.javascript.rhino.ScriptRuntime.emptyStrings;
        com.google.javascript.jscomp.JSError jSError19 = nodeTraversal7.makeError(node11, diagnosticType15, strArray18);
        com.google.javascript.jscomp.Scope scope20 = nodeTraversal7.getScope();
        com.google.javascript.rhino.Node node22 = new com.google.javascript.rhino.Node(23);
        try {
            com.google.javascript.jscomp.CodingConvention.ObjectLiteralCast objectLiteralCast23 = closureCodingConvention0.getObjectLiteralCast(nodeTraversal7, node22);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "goog.global" + "'", str1.equals("goog.global"));
        org.junit.Assert.assertNull(performanceTracker5);
        org.junit.Assert.assertNotNull(diagnosticType15);
        org.junit.Assert.assertNotNull(diagnosticType16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 30 + "'", int17 == 30);
        org.junit.Assert.assertNotNull(strArray18);
        org.junit.Assert.assertNotNull(jSError19);
        org.junit.Assert.assertNull(scope20);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setLooseTypes(true);
        boolean boolean3 = compilerOptions0.reserveRawExports;
        boolean boolean4 = compilerOptions0.flowSensitiveInlineVariables;
        compilerOptions0.reserveRawExports = true;
        compilerOptions0.inferTypesInGlobalScope = false;
        compilerOptions0.setProcessObjectPropertyString(false);
        compilerOptions0.jsOutputFile = "hi!";
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        java.util.List<com.google.javascript.jscomp.JSModule> jSModuleList0 = null;
        try {
            com.google.javascript.jscomp.JSModuleGraph jSModuleGraph1 = new com.google.javascript.jscomp.JSModuleGraph(jSModuleList0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setLooseTypes(true);
        boolean boolean3 = compilerOptions0.reserveRawExports;
        compilerOptions0.extractPrototypeMemberDeclarations = false;
        java.lang.String str6 = compilerOptions0.nameReferenceGraphPath;
        compilerOptions0.computeFunctionSideEffects = true;
        com.google.javascript.jscomp.CompilerOptions compilerOptions9 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions9.setLooseTypes(true);
        compilerOptions9.convertToDottedProperties = false;
        com.google.javascript.jscomp.CheckLevel checkLevel14 = compilerOptions9.reportMissingOverride;
        compilerOptions0.brokenClosureRequiresLevel = checkLevel14;
        java.util.Set<java.lang.String> strSet16 = compilerOptions0.stripTypePrefixes;
        boolean boolean17 = compilerOptions0.generatePseudoNames;
        boolean boolean18 = compilerOptions0.inlineLocalVariables;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + checkLevel14 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel14.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(strSet16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setLooseTypes(true);
        boolean boolean3 = compilerOptions0.collapseVariableDeclarations;
        com.google.javascript.jscomp.CheckLevel checkLevel4 = null;
        compilerOptions0.checkMethods = checkLevel4;
        compilerOptions0.flowSensitiveInlineVariables = true;
        boolean boolean8 = compilerOptions0.checkDuplicateMessages;
        boolean boolean9 = compilerOptions0.deadAssignmentElimination;
        compilerOptions0.inlineVariables = true;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setLooseTypes(true);
        boolean boolean3 = compilerOptions0.reserveRawExports;
        boolean boolean4 = compilerOptions0.flowSensitiveInlineVariables;
        compilerOptions0.reserveRawExports = true;
        compilerOptions0.inferTypesInGlobalScope = false;
        com.google.javascript.jscomp.CheckLevel checkLevel9 = compilerOptions0.checkMethods;
        compilerOptions0.aliasKeywords = true;
        com.google.javascript.jscomp.CheckLevel checkLevel12 = compilerOptions0.checkGlobalThisLevel;
        boolean boolean13 = compilerOptions0.aliasKeywords;
        com.google.javascript.jscomp.CheckLevel checkLevel14 = compilerOptions0.checkFunctions;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + checkLevel9 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel9.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + checkLevel12 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel12.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + checkLevel14 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel14.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setLooseTypes(true);
        boolean boolean3 = compilerOptions0.reserveRawExports;
        compilerOptions0.extractPrototypeMemberDeclarations = false;
        compilerOptions0.checkMissingGetCssNameBlacklist = "4";
        compilerOptions0.locale = "error reporter";
        compilerOptions0.crossModuleMethodMotion = false;
        com.google.javascript.jscomp.ErrorFormat errorFormat12 = null;
        compilerOptions0.errorFormat = errorFormat12;
        compilerOptions0.setPropertyAffinity(false);
        boolean boolean16 = compilerOptions0.checkUnusedPropertiesEarly;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeUnusedPrototypePropertiesInExterns = false;
        boolean boolean3 = compilerOptions0.markAsCompiled;
        compilerOptions0.setDefineToBooleanLiteral("", true);
        compilerOptions0.rewriteFunctionExpressions = false;
        java.lang.String str9 = compilerOptions0.syntheticBlockStartMarker;
        compilerOptions0.allowLegacyJsMessages = false;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(str9);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        int int0 = com.google.javascript.rhino.Node.SYNTHETIC_BLOCK_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 37 + "'", int0 == 37);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setLooseTypes(true);
        compilerOptions0.checkSuspiciousCode = false;
        com.google.common.collect.Multimap<com.google.javascript.jscomp.CustomPassExecutionTime, com.google.javascript.jscomp.CompilerPass> customPassExecutionTimeMultimap5 = compilerOptions0.customPasses;
        compilerOptions0.rewriteFunctionExpressions = true;
        compilerOptions0.optimizeCalls = false;
        compilerOptions0.collapseVariableDeclarations = true;
        org.junit.Assert.assertNull(customPassExecutionTimeMultimap5);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        com.google.javascript.rhino.Context context0 = new com.google.javascript.rhino.Context();
        context0.setGeneratingSource(true);
        java.lang.Object obj3 = context0.getDebuggerContextData();
        com.google.javascript.rhino.EcmaError ecmaError5 = com.google.javascript.rhino.ScriptRuntime.typeError("4");
        java.lang.String str6 = ecmaError5.getName();
        java.lang.String str7 = ecmaError5.lineSource();
        java.lang.String str8 = ecmaError5.toString();
        java.lang.String str9 = ecmaError5.lineSource();
        ecmaError5.initLineSource("com.google.javascript.rhino.EcmaError: TypeError: 4");
        context0.removeThreadLocal((java.lang.Object) ecmaError5);
        java.lang.String str13 = ecmaError5.details();
        org.junit.Assert.assertNull(obj3);
        org.junit.Assert.assertNotNull(ecmaError5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "TypeError" + "'", str6.equals("TypeError"));
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "com.google.javascript.rhino.EcmaError: TypeError: 4" + "'", str8.equals("com.google.javascript.rhino.EcmaError: TypeError: 4"));
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "TypeError: 4" + "'", str13.equals("TypeError: 4"));
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setLooseTypes(true);
        boolean boolean3 = compilerOptions0.reserveRawExports;
        boolean boolean4 = compilerOptions0.flowSensitiveInlineVariables;
        compilerOptions0.reserveRawExports = true;
        compilerOptions0.inferTypesInGlobalScope = false;
        boolean boolean9 = compilerOptions0.markNoSideEffectCalls;
        com.google.javascript.jscomp.CheckLevel checkLevel10 = compilerOptions0.checkProvides;
        com.google.javascript.jscomp.CodingConvention codingConvention11 = compilerOptions0.getCodingConvention();
        compilerOptions0.prettyPrint = true;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + checkLevel10 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel10.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNull(codingConvention11);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setLooseTypes(true);
        compilerOptions0.checkSuspiciousCode = false;
        compilerOptions0.disambiguateProperties = true;
        java.util.Map<java.lang.String, com.google.javascript.rhino.Node> strMap7 = compilerOptions0.getDefineReplacements();
        compilerOptions0.checkDuplicateMessages = false;
        boolean boolean10 = compilerOptions0.checkEs5Strict;
        org.junit.Assert.assertNotNull(strMap7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = null;
        com.google.javascript.jscomp.DiagnosticGroups.CONSTANT_PROPERTY = diagnosticGroup0;
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        compiler1.disableThreads();
        com.google.javascript.jscomp.PerformanceTracker performanceTracker3 = compiler1.tracker;
        com.google.javascript.jscomp.NodeTraversal.Callback callback4 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal5 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler1, callback4);
        com.google.javascript.jscomp.Compiler compiler6 = nodeTraversal5.getCompiler();
        com.google.javascript.jscomp.SourceExcerptProvider.SourceExcerpt sourceExcerpt7 = null;
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter8 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler6, sourceExcerpt7);
        compiler6.disableThreads();
        try {
            compiler6.check();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(performanceTracker3);
        org.junit.Assert.assertNotNull(compiler6);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setLooseTypes(true);
        compilerOptions0.convertToDottedProperties = false;
        boolean boolean5 = compilerOptions0.removeTryCatchFinally;
        compilerOptions0.aliasStringsBlacklist = "()";
        java.lang.String str8 = compilerOptions0.aliasStringsBlacklist;
        boolean boolean9 = compilerOptions0.instrumentForCoverage;
        com.google.javascript.jscomp.MessageBundle messageBundle10 = compilerOptions0.messageBundle;
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "()" + "'", str8.equals("()"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(messageBundle10);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        try {
            java.lang.String str2 = com.google.javascript.rhino.ScriptRuntime.escapeString("(4)", '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: FAILED ASSERTION");
        } catch (java.lang.IllegalStateException e) {
        }
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        java.lang.String str1 = com.google.javascript.rhino.ScriptRuntime.escapeString("hi!: hi!");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "hi!: hi!" + "'", str1.equals("hi!: hi!"));
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node2 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node4 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node6 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node8 = new com.google.javascript.rhino.Node((int) '4');
        node6.addChildrenToBack(node8);
        node2.addChildAfter(node4, node8);
        com.google.javascript.rhino.Node node12 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node14 = new com.google.javascript.rhino.Node((int) '4');
        node12.addChildrenToBack(node14);
        com.google.javascript.rhino.Node node16 = node2.copyInformationFromForTree(node14);
        com.google.javascript.rhino.Node node17 = node16.getLastChild();
        com.google.javascript.rhino.Node node19 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node21 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node23 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node25 = new com.google.javascript.rhino.Node((int) '4');
        node23.addChildrenToBack(node25);
        node19.addChildAfter(node21, node25);
        com.google.javascript.rhino.Node node29 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node31 = new com.google.javascript.rhino.Node((int) '4');
        node29.addChildrenToBack(node31);
        com.google.javascript.rhino.Node node33 = node19.copyInformationFromForTree(node31);
        node16.addChildToBack(node19);
        com.google.javascript.rhino.Node node35 = node19.cloneNode();
        boolean boolean36 = closureCodingConvention0.isVarArgsParameter(node19);
        com.google.javascript.rhino.Node node38 = com.google.javascript.rhino.Node.newString("hi!");
        int int39 = node38.getCharno();
        com.google.javascript.rhino.Node node41 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node43 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node45 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node47 = new com.google.javascript.rhino.Node((int) '4');
        node45.addChildrenToBack(node47);
        node41.addChildAfter(node43, node47);
        com.google.javascript.rhino.Node node51 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node53 = new com.google.javascript.rhino.Node((int) '4');
        node51.addChildrenToBack(node53);
        com.google.javascript.rhino.Node node55 = node41.copyInformationFromForTree(node53);
        com.google.javascript.rhino.Node node56 = node41.cloneTree();
        com.google.javascript.rhino.Node node58 = new com.google.javascript.rhino.Node((int) '4');
        node56.addChildrenToBack(node58);
        java.lang.String str60 = closureCodingConvention0.extractClassNameIfRequire(node38, node58);
        java.util.Collection<com.google.javascript.jscomp.CodingConvention.AssertionFunctionSpec> assertionFunctionSpecCollection61 = closureCodingConvention0.getAssertionFunctions();
        java.lang.String str62 = closureCodingConvention0.getDelegateSuperclassName();
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertNull(node17);
        org.junit.Assert.assertNotNull(node33);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(node38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + (-1) + "'", int39 == (-1));
        org.junit.Assert.assertNotNull(node55);
        org.junit.Assert.assertNotNull(node56);
        org.junit.Assert.assertNull(str60);
        org.junit.Assert.assertNotNull(assertionFunctionSpecCollection61);
        org.junit.Assert.assertNull(str62);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.STRICT_MODULE_DEP_CHECK;
        com.google.javascript.jscomp.DiagnosticGroups.MISSING_PROPERTIES = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticGroups.STRICT_MODULE_DEP_CHECK = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticGroups.CHECK_REGEXP = diagnosticGroup0;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        int int0 = com.google.javascript.rhino.Context.VERSION_1_3;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 130 + "'", int0 == 130);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setLooseTypes(true);
        boolean boolean3 = compilerOptions0.reserveRawExports;
        compilerOptions0.extractPrototypeMemberDeclarations = false;
        java.lang.String str6 = compilerOptions0.nameReferenceGraphPath;
        compilerOptions0.computeFunctionSideEffects = true;
        boolean boolean9 = compilerOptions0.inlineLocalFunctions;
        boolean boolean10 = compilerOptions0.coalesceVariableNames;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setLooseTypes(true);
        boolean boolean3 = compilerOptions0.reserveRawExports;
        compilerOptions0.extractPrototypeMemberDeclarations = false;
        java.lang.String str6 = compilerOptions0.nameReferenceGraphPath;
        compilerOptions0.nameReferenceReportPath = "33";
        com.google.javascript.jscomp.CompilerOptions compilerOptions9 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions9.setLooseTypes(true);
        boolean boolean12 = compilerOptions9.reserveRawExports;
        compilerOptions9.extractPrototypeMemberDeclarations = false;
        java.lang.String str15 = compilerOptions9.nameReferenceGraphPath;
        compilerOptions9.computeFunctionSideEffects = true;
        com.google.javascript.jscomp.CompilerOptions compilerOptions18 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions18.setLooseTypes(true);
        compilerOptions18.convertToDottedProperties = false;
        com.google.javascript.jscomp.CheckLevel checkLevel23 = compilerOptions18.reportMissingOverride;
        compilerOptions9.brokenClosureRequiresLevel = checkLevel23;
        java.util.Set<java.lang.String> strSet25 = compilerOptions9.stripTypePrefixes;
        compilerOptions0.stripNameSuffixes = strSet25;
        compilerOptions0.inlineFunctions = false;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNull(str15);
        org.junit.Assert.assertTrue("'" + checkLevel23 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel23.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(strSet25);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        int int0 = com.google.javascript.rhino.Node.VARS_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setLooseTypes(true);
        boolean boolean3 = compilerOptions0.reserveRawExports;
        boolean boolean4 = compilerOptions0.flowSensitiveInlineVariables;
        compilerOptions0.reserveRawExports = true;
        compilerOptions0.inferTypesInGlobalScope = false;
        boolean boolean9 = compilerOptions0.markNoSideEffectCalls;
        compilerOptions0.aliasableGlobals = "com.google.javascript.rhino.EcmaError: TypeError: 4";
        com.google.javascript.jscomp.CompilerOptions compilerOptions12 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions12.setLooseTypes(true);
        compilerOptions12.checkSuspiciousCode = false;
        compilerOptions12.setCollapsePropertiesOnExternTypes(false);
        com.google.javascript.jscomp.CheckLevel checkLevel19 = compilerOptions12.checkMethods;
        compilerOptions0.checkShadowVars = checkLevel19;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + checkLevel19 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel19.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        com.google.javascript.jscomp.CompilerOptions compilerOptions1 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions1.setLooseTypes(true);
        boolean boolean4 = compilerOptions1.collapseVariableDeclarations;
        compilerOptions1.moveFunctionDeclarations = false;
        boolean boolean7 = compilerOptions1.decomposeExpressions;
        boolean boolean8 = compilerOptions1.optimizeParameters;
        java.lang.String str9 = compilerOptions1.inputDelimiter;
        com.google.javascript.jscomp.ErrorFormat errorFormat10 = com.google.javascript.jscomp.ErrorFormat.LEGACY;
        java.lang.RuntimeException runtimeException11 = com.google.javascript.rhino.ScriptRuntime.undefWriteError((java.lang.Object) (short) 100, (java.lang.Object) str9, (java.lang.Object) errorFormat10);
        java.io.PrintStream printStream12 = null;
        com.google.javascript.jscomp.Compiler compiler13 = new com.google.javascript.jscomp.Compiler(printStream12);
        compiler13.disableThreads();
        com.google.javascript.jscomp.PerformanceTracker performanceTracker15 = compiler13.tracker;
        com.google.javascript.jscomp.MessageFormatter messageFormatter17 = errorFormat10.toFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler13, false);
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter18 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler13);
        java.util.logging.Logger logger19 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager20 = new com.google.javascript.jscomp.LoggerErrorManager((com.google.javascript.jscomp.MessageFormatter) lightweightMessageFormatter18, logger19);
        com.google.javascript.jscomp.JSError[] jSErrorArray21 = loggerErrorManager20.getErrors();
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup22 = com.google.javascript.jscomp.DiagnosticGroups.STRICT_MODULE_DEP_CHECK;
        com.google.javascript.jscomp.DiagnosticGroups.MISSING_PROPERTIES = diagnosticGroup22;
        com.google.javascript.jscomp.DiagnosticGroups.STRICT_MODULE_DEP_CHECK = diagnosticGroup22;
        com.google.javascript.jscomp.DiagnosticGroups.INVALID_CASTS = diagnosticGroup22;
        com.google.javascript.jscomp.DiagnosticType diagnosticType28 = com.google.javascript.jscomp.DiagnosticType.warning("hi!", "hi!");
        java.lang.String str29 = diagnosticType28.key;
        boolean boolean30 = diagnosticGroup22.matches(diagnosticType28);
        java.lang.RuntimeException runtimeException31 = com.google.javascript.rhino.ScriptRuntime.undefCallError((java.lang.Object) loggerErrorManager20, (java.lang.Object) diagnosticGroup22);
        java.io.PrintStream printStream32 = null;
        com.google.javascript.jscomp.Compiler compiler33 = new com.google.javascript.jscomp.Compiler(printStream32);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile36 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        java.io.Reader reader37 = jSSourceFile36.getCodeReader();
        com.google.javascript.jscomp.JSModule[] jSModuleArray38 = new com.google.javascript.jscomp.JSModule[] {};
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph39 = new com.google.javascript.jscomp.JSModuleGraph(jSModuleArray38);
        com.google.javascript.jscomp.CompilerOptions compilerOptions40 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions40.setLooseTypes(true);
        boolean boolean43 = compilerOptions40.collapseVariableDeclarations;
        compilerOptions40.moveFunctionDeclarations = false;
        boolean boolean46 = compilerOptions40.decomposeExpressions;
        com.google.javascript.jscomp.CheckLevel checkLevel47 = compilerOptions40.checkMissingGetCssNameLevel;
        com.google.javascript.jscomp.Result result48 = compiler33.compile(jSSourceFile36, jSModuleArray38, compilerOptions40);
        com.google.javascript.jscomp.CheckLevel checkLevel49 = compilerOptions40.reportMissingOverride;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard50 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup22, checkLevel49);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup52 = com.google.javascript.jscomp.DiagnosticGroups.MISSING_PROPERTIES;
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup53 = com.google.javascript.jscomp.DiagnosticGroups.STRICT_MODULE_DEP_CHECK;
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup54 = com.google.javascript.jscomp.DiagnosticGroups.STRICT_MODULE_DEP_CHECK;
        com.google.javascript.jscomp.DiagnosticGroups.TYPE_INVALIDATION = diagnosticGroup54;
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup56 = com.google.javascript.jscomp.DiagnosticGroups.MISSING_PROPERTIES;
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup57 = com.google.javascript.jscomp.DiagnosticGroups.STRICT_MODULE_DEP_CHECK;
        com.google.javascript.jscomp.DiagnosticGroups.MISSING_PROPERTIES = diagnosticGroup57;
        com.google.javascript.jscomp.DiagnosticGroups.STRICT_MODULE_DEP_CHECK = diagnosticGroup57;
        com.google.javascript.jscomp.DiagnosticGroup[] diagnosticGroupArray60 = new com.google.javascript.jscomp.DiagnosticGroup[] { diagnosticGroup52, diagnosticGroup53, diagnosticGroup54, diagnosticGroup56, diagnosticGroup57 };
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup61 = new com.google.javascript.jscomp.DiagnosticGroup("4", diagnosticGroupArray60);
        com.google.javascript.jscomp.DiagnosticGroups.TYPE_INVALIDATION = diagnosticGroup61;
        boolean boolean63 = diagnosticGroupWarningsGuard50.disables(diagnosticGroup61);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "// Input %num%" + "'", str9.equals("// Input %num%"));
        org.junit.Assert.assertNotNull(errorFormat10);
        org.junit.Assert.assertNotNull(runtimeException11);
        org.junit.Assert.assertNull(performanceTracker15);
        org.junit.Assert.assertNotNull(messageFormatter17);
        org.junit.Assert.assertNotNull(jSErrorArray21);
        org.junit.Assert.assertNotNull(diagnosticGroup22);
        org.junit.Assert.assertNotNull(diagnosticType28);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "hi!" + "'", str29.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(runtimeException31);
        org.junit.Assert.assertNotNull(jSSourceFile36);
        org.junit.Assert.assertNotNull(reader37);
        org.junit.Assert.assertNotNull(jSModuleArray38);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + checkLevel47 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel47.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(result48);
        org.junit.Assert.assertTrue("'" + checkLevel49 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel49.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(diagnosticGroup52);
        org.junit.Assert.assertNotNull(diagnosticGroup53);
        org.junit.Assert.assertNotNull(diagnosticGroup54);
        org.junit.Assert.assertNotNull(diagnosticGroup56);
        org.junit.Assert.assertNotNull(diagnosticGroup57);
        org.junit.Assert.assertNotNull(diagnosticGroupArray60);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + true + "'", boolean63 == true);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        com.google.javascript.jscomp.SourceAst sourceAst0 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(sourceAst0, "", false);
        com.google.javascript.jscomp.JSModule jSModule4 = compilerInput3.getModule();
        com.google.javascript.jscomp.JSModule jSModule5 = null;
        compilerInput3.setModule(jSModule5);
        java.io.PrintStream printStream7 = null;
        com.google.javascript.jscomp.Compiler compiler8 = new com.google.javascript.jscomp.Compiler(printStream7);
        java.io.PrintStream printStream9 = null;
        com.google.javascript.jscomp.Compiler compiler10 = new com.google.javascript.jscomp.Compiler(printStream9);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile13 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        java.io.Reader reader14 = jSSourceFile13.getCodeReader();
        com.google.javascript.jscomp.JSModule[] jSModuleArray15 = new com.google.javascript.jscomp.JSModule[] {};
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph16 = new com.google.javascript.jscomp.JSModuleGraph(jSModuleArray15);
        com.google.javascript.jscomp.CompilerOptions compilerOptions17 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions17.setLooseTypes(true);
        boolean boolean20 = compilerOptions17.collapseVariableDeclarations;
        compilerOptions17.moveFunctionDeclarations = false;
        boolean boolean23 = compilerOptions17.decomposeExpressions;
        com.google.javascript.jscomp.CheckLevel checkLevel24 = compilerOptions17.checkMissingGetCssNameLevel;
        com.google.javascript.jscomp.Result result25 = compiler10.compile(jSSourceFile13, jSModuleArray15, compilerOptions17);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile28 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile31 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        java.io.Reader reader32 = jSSourceFile31.getCodeReader();
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray33 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile13, jSSourceFile28, jSSourceFile31 };
        java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList34 = new java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile>();
        boolean boolean35 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList34, jSSourceFileArray33);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile38 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray39 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile38 };
        java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList40 = new java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile>();
        boolean boolean41 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList40, jSSourceFileArray39);
        com.google.javascript.jscomp.CompilerOptions compilerOptions42 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions42.setLooseTypes(true);
        boolean boolean45 = compilerOptions42.reserveRawExports;
        compilerOptions42.extractPrototypeMemberDeclarations = false;
        java.lang.String str48 = compilerOptions42.nameReferenceGraphPath;
        compilerOptions42.setSummaryDetailLevel(0);
        com.google.javascript.jscomp.Result result51 = compiler8.compile((java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList34, (java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList40, compilerOptions42);
        com.google.javascript.jscomp.CodingConvention codingConvention52 = compiler8.getCodingConvention();
        try {
            com.google.javascript.rhino.Node node53 = compilerInput3.getAstRoot((com.google.javascript.jscomp.AbstractCompiler) compiler8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(jSModule4);
        org.junit.Assert.assertNotNull(jSSourceFile13);
        org.junit.Assert.assertNotNull(reader14);
        org.junit.Assert.assertNotNull(jSModuleArray15);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + checkLevel24 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel24.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(result25);
        org.junit.Assert.assertNotNull(jSSourceFile28);
        org.junit.Assert.assertNotNull(jSSourceFile31);
        org.junit.Assert.assertNotNull(reader32);
        org.junit.Assert.assertNotNull(jSSourceFileArray33);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertNotNull(jSSourceFile38);
        org.junit.Assert.assertNotNull(jSSourceFileArray39);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNull(str48);
        org.junit.Assert.assertNotNull(result51);
        org.junit.Assert.assertNotNull(codingConvention52);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setLooseTypes(true);
        boolean boolean3 = compilerOptions0.reserveRawExports;
        compilerOptions0.extractPrototypeMemberDeclarations = false;
        compilerOptions0.checkMissingGetCssNameBlacklist = "4";
        compilerOptions0.locale = "error reporter";
        compilerOptions0.crossModuleMethodMotion = false;
        com.google.javascript.jscomp.ErrorFormat errorFormat12 = null;
        compilerOptions0.errorFormat = errorFormat12;
        compilerOptions0.optimizeReturns = false;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeUnusedPrototypePropertiesInExterns = false;
        boolean boolean3 = compilerOptions0.markAsCompiled;
        compilerOptions0.setDefineToBooleanLiteral("", true);
        compilerOptions0.rewriteFunctionExpressions = false;
        java.lang.String str9 = compilerOptions0.syntheticBlockStartMarker;
        com.google.javascript.jscomp.CompilerOptions compilerOptions11 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions11.setLooseTypes(true);
        boolean boolean14 = compilerOptions11.collapseVariableDeclarations;
        compilerOptions11.moveFunctionDeclarations = false;
        boolean boolean17 = compilerOptions11.decomposeExpressions;
        boolean boolean18 = compilerOptions11.optimizeParameters;
        java.lang.String str19 = compilerOptions11.inputDelimiter;
        com.google.javascript.jscomp.ErrorFormat errorFormat20 = com.google.javascript.jscomp.ErrorFormat.LEGACY;
        java.lang.RuntimeException runtimeException21 = com.google.javascript.rhino.ScriptRuntime.undefWriteError((java.lang.Object) (short) 100, (java.lang.Object) str19, (java.lang.Object) errorFormat20);
        compilerOptions0.errorFormat = errorFormat20;
        com.google.javascript.jscomp.AnonymousFunctionNamingPolicy anonymousFunctionNamingPolicy23 = null;
        compilerOptions0.anonymousFunctionNaming = anonymousFunctionNamingPolicy23;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "// Input %num%" + "'", str19.equals("// Input %num%"));
        org.junit.Assert.assertNotNull(errorFormat20);
        org.junit.Assert.assertNotNull(runtimeException21);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        com.google.javascript.rhino.Context context0 = new com.google.javascript.rhino.Context();
        context0.setGeneratingSource(true);
        com.google.javascript.jscomp.CompilerOptions.TracerMode tracerMode3 = com.google.javascript.jscomp.CompilerOptions.TracerMode.FAST;
        context0.removeThreadLocal((java.lang.Object) tracerMode3);
        context0.setCompileFunctionsWithDynamicScope(true);
        org.junit.Assert.assertTrue("'" + tracerMode3 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TracerMode.FAST + "'", tracerMode3.equals(com.google.javascript.jscomp.CompilerOptions.TracerMode.FAST));
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention0 = new com.google.javascript.jscomp.DefaultCodingConvention();
        boolean boolean2 = defaultCodingConvention0.isConstant("hi!");
        java.lang.String str3 = defaultCodingConvention0.getExportSymbolFunction();
        com.google.javascript.rhino.Node node5 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node7 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node9 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node11 = new com.google.javascript.rhino.Node((int) '4');
        node9.addChildrenToBack(node11);
        node5.addChildAfter(node7, node11);
        java.util.List<java.lang.String> strList14 = defaultCodingConvention0.identifyTypeDeclarationCall(node5);
        com.google.javascript.rhino.jstype.FunctionType functionType15 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType16 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType17 = null;
        defaultCodingConvention0.applySingletonGetter(functionType15, functionType16, objectType17);
        java.lang.String str19 = defaultCodingConvention0.getExportPropertyFunction();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNull(strList14);
        org.junit.Assert.assertNull(str19);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention0 = new com.google.javascript.jscomp.DefaultCodingConvention();
        boolean boolean2 = defaultCodingConvention0.isExported("// Input %num%");
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry3 = null;
        com.google.javascript.jscomp.Scope scope4 = null;
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention5 = new com.google.javascript.jscomp.DefaultCodingConvention();
        java.lang.String str6 = defaultCodingConvention5.getDelegateSuperclassName();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry7 = null;
        com.google.javascript.jscomp.Scope scope8 = null;
        com.google.javascript.rhino.jstype.ObjectType[] objectTypeArray9 = new com.google.javascript.rhino.jstype.ObjectType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.ObjectType> objectTypeList10 = new java.util.ArrayList<com.google.javascript.rhino.jstype.ObjectType>();
        boolean boolean11 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.ObjectType>) objectTypeList10, objectTypeArray9);
        defaultCodingConvention5.defineDelegateProxyPrototypeProperties(jSTypeRegistry7, scope8, (java.util.List<com.google.javascript.rhino.jstype.ObjectType>) objectTypeList10);
        defaultCodingConvention0.defineDelegateProxyPrototypeProperties(jSTypeRegistry3, scope4, (java.util.List<com.google.javascript.rhino.jstype.ObjectType>) objectTypeList10);
        java.io.PrintStream printStream14 = null;
        com.google.javascript.jscomp.Compiler compiler15 = new com.google.javascript.jscomp.Compiler(printStream14);
        compiler15.disableThreads();
        com.google.javascript.jscomp.PerformanceTracker performanceTracker17 = compiler15.tracker;
        com.google.javascript.jscomp.NodeTraversal.Callback callback18 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal19 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler15, callback18);
        com.google.javascript.rhino.Node node21 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node23 = new com.google.javascript.rhino.Node((int) '4');
        node21.addChildrenToBack(node23);
        com.google.javascript.jscomp.DiagnosticType diagnosticType27 = com.google.javascript.jscomp.DiagnosticType.warning("hi!", "hi!");
        com.google.javascript.jscomp.DiagnosticType diagnosticType28 = com.google.javascript.jscomp.Compiler.MOTION_ITERATIONS_ERROR;
        int int29 = diagnosticType27.compareTo(diagnosticType28);
        java.lang.String[] strArray30 = com.google.javascript.rhino.ScriptRuntime.emptyStrings;
        com.google.javascript.jscomp.JSError jSError31 = nodeTraversal19.makeError(node23, diagnosticType27, strArray30);
        java.util.List<java.lang.String> strList32 = defaultCodingConvention0.identifyTypeDeclarationCall(node23);
        boolean boolean33 = node23.isQualifiedName();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNotNull(objectTypeArray9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNull(performanceTracker17);
        org.junit.Assert.assertNotNull(diagnosticType27);
        org.junit.Assert.assertNotNull(diagnosticType28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 30 + "'", int29 == 30);
        org.junit.Assert.assertNotNull(strArray30);
        org.junit.Assert.assertNotNull(jSError31);
        org.junit.Assert.assertNull(strList32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setLooseTypes(true);
        boolean boolean3 = compilerOptions0.reserveRawExports;
        com.google.javascript.jscomp.CheckLevel checkLevel4 = null;
        compilerOptions0.checkUnreachableCode = checkLevel4;
        com.google.javascript.jscomp.MessageBundle messageBundle6 = compilerOptions0.messageBundle;
        compilerOptions0.checkDuplicateMessages = false;
        compilerOptions0.aliasExternals = true;
        compilerOptions0.aliasAllStrings = false;
        com.google.javascript.jscomp.CompilerOptions.TweakProcessing tweakProcessing13 = compilerOptions0.getTweakProcessing();
        compilerOptions0.debugFunctionSideEffectsPath = "(<No stack trace available>)";
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(messageBundle6);
        org.junit.Assert.assertTrue("'" + tweakProcessing13 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TweakProcessing.OFF + "'", tweakProcessing13.equals(com.google.javascript.jscomp.CompilerOptions.TweakProcessing.OFF));
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        int int0 = com.google.javascript.rhino.Node.IS_VAR_ARGS_PARAM;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 44 + "'", int0 == 44);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        com.google.javascript.rhino.EcmaError ecmaError6 = com.google.javascript.rhino.ScriptRuntime.constructError("", "Not declared as a type name", "()", 20, "(// Input %num%)", 4095);
        org.junit.Assert.assertNotNull(ecmaError6);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        com.google.javascript.rhino.Node node2 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node4 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node6 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node8 = new com.google.javascript.rhino.Node((int) '4');
        node6.addChildrenToBack(node8);
        node2.addChildAfter(node4, node8);
        com.google.javascript.rhino.Node node12 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node14 = new com.google.javascript.rhino.Node((int) '4');
        node12.addChildrenToBack(node14);
        com.google.javascript.rhino.Node node16 = node2.copyInformationFromForTree(node14);
        com.google.javascript.jscomp.DiagnosticType diagnosticType17 = com.google.javascript.jscomp.Compiler.MOTION_ITERATIONS_ERROR;
        java.lang.String str18 = diagnosticType17.toString();
        java.lang.String[] strArray19 = null;
        com.google.javascript.jscomp.JSError jSError20 = com.google.javascript.jscomp.JSError.make("", node14, diagnosticType17, strArray19);
        java.lang.String str21 = diagnosticType17.toString();
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertNotNull(diagnosticType17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}" + "'", str18.equals("JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}"));
        org.junit.Assert.assertNotNull(jSError20);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}" + "'", str21.equals("JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}"));
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setLooseTypes(true);
        boolean boolean3 = compilerOptions0.collapseVariableDeclarations;
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention4 = new com.google.javascript.jscomp.DefaultCodingConvention();
        boolean boolean6 = defaultCodingConvention4.isExported("// Input %num%");
        boolean boolean8 = defaultCodingConvention4.isSuperClassReference("");
        com.google.javascript.rhino.Node node10 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node12 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node14 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node16 = new com.google.javascript.rhino.Node((int) '4');
        node14.addChildrenToBack(node16);
        node10.addChildAfter(node12, node16);
        boolean boolean19 = node12.wasEmptyNode();
        java.lang.String str20 = defaultCodingConvention4.identifyTypeDefAssign(node12);
        boolean boolean23 = defaultCodingConvention4.isExported("Exceeded max number of code motion iterations: {0}", false);
        boolean boolean26 = defaultCodingConvention4.isExported("Not declared as a type name", false);
        compilerOptions0.setCodingConvention((com.google.javascript.jscomp.CodingConvention) defaultCodingConvention4);
        boolean boolean28 = compilerOptions0.rewriteFunctionExpressions;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNull(str20);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        com.google.javascript.jscomp.SourceAst sourceAst0 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(sourceAst0, "", false);
        boolean boolean4 = compilerInput3.isExtern();
        java.lang.String str5 = compilerInput3.getName();
        com.google.javascript.jscomp.JSModule jSModule6 = compilerInput3.getModule();
        com.google.javascript.jscomp.CompilerInput compilerInput9 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput3, "<No stack trace available>", false);
        com.google.javascript.jscomp.JSModule jSModule10 = compilerInput3.getModule();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertNull(jSModule6);
        org.junit.Assert.assertNull(jSModule10);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        com.google.javascript.rhino.Node node5 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node7 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node9 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node11 = new com.google.javascript.rhino.Node((int) '4');
        node9.addChildrenToBack(node11);
        node5.addChildAfter(node7, node11);
        com.google.javascript.rhino.Node node15 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node17 = new com.google.javascript.rhino.Node((int) '4');
        node15.addChildrenToBack(node17);
        com.google.javascript.rhino.Node node19 = node5.copyInformationFromForTree(node17);
        com.google.javascript.jscomp.DiagnosticType diagnosticType20 = com.google.javascript.jscomp.Compiler.MOTION_ITERATIONS_ERROR;
        java.lang.String str21 = diagnosticType20.toString();
        java.lang.String[] strArray22 = null;
        com.google.javascript.jscomp.JSError jSError23 = com.google.javascript.jscomp.JSError.make("", node17, diagnosticType20, strArray22);
        java.lang.String[] strArray26 = new java.lang.String[] { "(// Input %num%)", "()" };
        com.google.javascript.jscomp.JSError jSError27 = com.google.javascript.jscomp.JSError.make("Named type with empty name component", 3, 17, diagnosticType20, strArray26);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNotNull(diagnosticType20);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}" + "'", str21.equals("JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}"));
        org.junit.Assert.assertNotNull(jSError23);
        org.junit.Assert.assertNotNull(strArray26);
        org.junit.Assert.assertNotNull(jSError27);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        compiler1.disableThreads();
        com.google.javascript.jscomp.PerformanceTracker performanceTracker3 = compiler1.tracker;
        com.google.javascript.jscomp.NodeTraversal.Callback callback4 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal5 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler1, callback4);
        java.io.PrintStream printStream6 = null;
        com.google.javascript.jscomp.Compiler compiler7 = new com.google.javascript.jscomp.Compiler(printStream6);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile10 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        java.io.Reader reader11 = jSSourceFile10.getCodeReader();
        com.google.javascript.jscomp.JSModule[] jSModuleArray12 = new com.google.javascript.jscomp.JSModule[] {};
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph13 = new com.google.javascript.jscomp.JSModuleGraph(jSModuleArray12);
        com.google.javascript.jscomp.CompilerOptions compilerOptions14 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions14.setLooseTypes(true);
        boolean boolean17 = compilerOptions14.collapseVariableDeclarations;
        compilerOptions14.moveFunctionDeclarations = false;
        boolean boolean20 = compilerOptions14.decomposeExpressions;
        com.google.javascript.jscomp.CheckLevel checkLevel21 = compilerOptions14.checkMissingGetCssNameLevel;
        com.google.javascript.jscomp.Result result22 = compiler7.compile(jSSourceFile10, jSModuleArray12, compilerOptions14);
        java.io.PrintStream printStream23 = null;
        com.google.javascript.jscomp.Compiler compiler24 = new com.google.javascript.jscomp.Compiler(printStream23);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile27 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        java.io.Reader reader28 = jSSourceFile27.getCodeReader();
        com.google.javascript.jscomp.JSModule[] jSModuleArray29 = new com.google.javascript.jscomp.JSModule[] {};
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph30 = new com.google.javascript.jscomp.JSModuleGraph(jSModuleArray29);
        com.google.javascript.jscomp.CompilerOptions compilerOptions31 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions31.setLooseTypes(true);
        boolean boolean34 = compilerOptions31.collapseVariableDeclarations;
        compilerOptions31.moveFunctionDeclarations = false;
        boolean boolean37 = compilerOptions31.decomposeExpressions;
        com.google.javascript.jscomp.CheckLevel checkLevel38 = compilerOptions31.checkMissingGetCssNameLevel;
        com.google.javascript.jscomp.Result result39 = compiler24.compile(jSSourceFile27, jSModuleArray29, compilerOptions31);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile42 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        java.io.PrintStream printStream43 = null;
        com.google.javascript.jscomp.Compiler compiler44 = new com.google.javascript.jscomp.Compiler(printStream43);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile47 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        java.io.Reader reader48 = jSSourceFile47.getCodeReader();
        com.google.javascript.jscomp.JSModule[] jSModuleArray49 = new com.google.javascript.jscomp.JSModule[] {};
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph50 = new com.google.javascript.jscomp.JSModuleGraph(jSModuleArray49);
        com.google.javascript.jscomp.CompilerOptions compilerOptions51 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions51.setLooseTypes(true);
        boolean boolean54 = compilerOptions51.collapseVariableDeclarations;
        compilerOptions51.moveFunctionDeclarations = false;
        boolean boolean57 = compilerOptions51.decomposeExpressions;
        com.google.javascript.jscomp.CheckLevel checkLevel58 = compilerOptions51.checkMissingGetCssNameLevel;
        com.google.javascript.jscomp.Result result59 = compiler44.compile(jSSourceFile47, jSModuleArray49, compilerOptions51);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile62 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile65 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        java.io.Reader reader66 = jSSourceFile65.getCodeReader();
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray67 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile10, jSSourceFile27, jSSourceFile42, jSSourceFile47, jSSourceFile62, jSSourceFile65 };
        java.io.PrintStream printStream68 = null;
        com.google.javascript.jscomp.Compiler compiler69 = new com.google.javascript.jscomp.Compiler(printStream68);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile72 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        java.io.Reader reader73 = jSSourceFile72.getCodeReader();
        com.google.javascript.jscomp.JSModule[] jSModuleArray74 = new com.google.javascript.jscomp.JSModule[] {};
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph75 = new com.google.javascript.jscomp.JSModuleGraph(jSModuleArray74);
        com.google.javascript.jscomp.CompilerOptions compilerOptions76 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions76.setLooseTypes(true);
        boolean boolean79 = compilerOptions76.collapseVariableDeclarations;
        compilerOptions76.moveFunctionDeclarations = false;
        boolean boolean82 = compilerOptions76.decomposeExpressions;
        com.google.javascript.jscomp.CheckLevel checkLevel83 = compilerOptions76.checkMissingGetCssNameLevel;
        com.google.javascript.jscomp.Result result84 = compiler69.compile(jSSourceFile72, jSModuleArray74, compilerOptions76);
        com.google.javascript.jscomp.CompilerOptions compilerOptions85 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions85.setLooseTypes(true);
        boolean boolean88 = compilerOptions85.collapseVariableDeclarations;
        compilerOptions85.setManageClosureDependencies(false);
        com.google.javascript.jscomp.Result result91 = compiler1.compile(jSSourceFileArray67, jSModuleArray74, compilerOptions85);
        java.lang.String str92 = compilerOptions85.checkMissingGetCssNameBlacklist;
        org.junit.Assert.assertNull(performanceTracker3);
        org.junit.Assert.assertNotNull(jSSourceFile10);
        org.junit.Assert.assertNotNull(reader11);
        org.junit.Assert.assertNotNull(jSModuleArray12);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + checkLevel21 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel21.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(result22);
        org.junit.Assert.assertNotNull(jSSourceFile27);
        org.junit.Assert.assertNotNull(reader28);
        org.junit.Assert.assertNotNull(jSModuleArray29);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + checkLevel38 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel38.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(result39);
        org.junit.Assert.assertNotNull(jSSourceFile42);
        org.junit.Assert.assertNotNull(jSSourceFile47);
        org.junit.Assert.assertNotNull(reader48);
        org.junit.Assert.assertNotNull(jSModuleArray49);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertTrue("'" + checkLevel58 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel58.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(result59);
        org.junit.Assert.assertNotNull(jSSourceFile62);
        org.junit.Assert.assertNotNull(jSSourceFile65);
        org.junit.Assert.assertNotNull(reader66);
        org.junit.Assert.assertNotNull(jSSourceFileArray67);
        org.junit.Assert.assertNotNull(jSSourceFile72);
        org.junit.Assert.assertNotNull(reader73);
        org.junit.Assert.assertNotNull(jSModuleArray74);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
        org.junit.Assert.assertTrue("'" + checkLevel83 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel83.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(result84);
        org.junit.Assert.assertTrue("'" + boolean88 + "' != '" + false + "'", boolean88 == false);
        org.junit.Assert.assertNotNull(result91);
        org.junit.Assert.assertNull(str92);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        com.google.javascript.jscomp.DiagnosticType[] diagnosticTypeArray0 = new com.google.javascript.jscomp.DiagnosticType[] {};
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup1 = new com.google.javascript.jscomp.DiagnosticGroup(diagnosticTypeArray0);
        com.google.javascript.jscomp.DiagnosticGroups.MISSING_PROPERTIES = diagnosticGroup1;
        com.google.javascript.jscomp.DiagnosticGroups.CHECK_VARIABLES = diagnosticGroup1;
        org.junit.Assert.assertNotNull(diagnosticTypeArray0);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.STRICT_MODULE_DEP_CHECK;
        com.google.javascript.jscomp.DiagnosticGroups.MISSING_PROPERTIES = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticGroups.STRICT_MODULE_DEP_CHECK = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticGroups.INVALID_CASTS = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticType diagnosticType6 = com.google.javascript.jscomp.DiagnosticType.warning("hi!", "hi!");
        java.lang.String str7 = diagnosticType6.key;
        boolean boolean8 = diagnosticGroup0.matches(diagnosticType6);
        java.lang.String str9 = diagnosticType6.toString();
        org.junit.Assert.assertNotNull(diagnosticGroup0);
        org.junit.Assert.assertNotNull(diagnosticType6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "hi!" + "'", str7.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "hi!: hi!" + "'", str9.equals("hi!: hi!"));
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        boolean boolean2 = closureCodingConvention0.isPrivate("// Input %num%");
        com.google.javascript.rhino.Node node4 = new com.google.javascript.rhino.Node(23);
        com.google.javascript.rhino.Node node8 = new com.google.javascript.rhino.Node(30, 35, 8);
        com.google.javascript.rhino.Node node9 = node8.getLastChild();
        java.lang.String str10 = closureCodingConvention0.extractClassNameIfProvide(node4, node8);
        int int11 = node4.getType();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(node9);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 23 + "'", int11 == 23);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        java.io.PrintStream printStream2 = null;
        com.google.javascript.jscomp.Compiler compiler3 = new com.google.javascript.jscomp.Compiler(printStream2);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile6 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        java.io.Reader reader7 = jSSourceFile6.getCodeReader();
        com.google.javascript.jscomp.JSModule[] jSModuleArray8 = new com.google.javascript.jscomp.JSModule[] {};
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph9 = new com.google.javascript.jscomp.JSModuleGraph(jSModuleArray8);
        com.google.javascript.jscomp.CompilerOptions compilerOptions10 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions10.setLooseTypes(true);
        boolean boolean13 = compilerOptions10.collapseVariableDeclarations;
        compilerOptions10.moveFunctionDeclarations = false;
        boolean boolean16 = compilerOptions10.decomposeExpressions;
        com.google.javascript.jscomp.CheckLevel checkLevel17 = compilerOptions10.checkMissingGetCssNameLevel;
        com.google.javascript.jscomp.Result result18 = compiler3.compile(jSSourceFile6, jSModuleArray8, compilerOptions10);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile21 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile24 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        java.io.Reader reader25 = jSSourceFile24.getCodeReader();
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray26 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile6, jSSourceFile21, jSSourceFile24 };
        java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList27 = new java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile>();
        boolean boolean28 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList27, jSSourceFileArray26);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile31 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray32 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile31 };
        java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList33 = new java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile>();
        boolean boolean34 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList33, jSSourceFileArray32);
        com.google.javascript.jscomp.CompilerOptions compilerOptions35 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions35.setLooseTypes(true);
        boolean boolean38 = compilerOptions35.reserveRawExports;
        compilerOptions35.extractPrototypeMemberDeclarations = false;
        java.lang.String str41 = compilerOptions35.nameReferenceGraphPath;
        compilerOptions35.setSummaryDetailLevel(0);
        com.google.javascript.jscomp.Result result44 = compiler1.compile((java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList27, (java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList33, compilerOptions35);
        boolean boolean45 = compilerOptions35.labelRenaming;
        boolean boolean46 = compilerOptions35.prettyPrint;
        java.lang.Object obj47 = compilerOptions35.clone();
        org.junit.Assert.assertNotNull(jSSourceFile6);
        org.junit.Assert.assertNotNull(reader7);
        org.junit.Assert.assertNotNull(jSModuleArray8);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + checkLevel17 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel17.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(result18);
        org.junit.Assert.assertNotNull(jSSourceFile21);
        org.junit.Assert.assertNotNull(jSSourceFile24);
        org.junit.Assert.assertNotNull(reader25);
        org.junit.Assert.assertNotNull(jSSourceFileArray26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(jSSourceFile31);
        org.junit.Assert.assertNotNull(jSSourceFileArray32);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNull(str41);
        org.junit.Assert.assertNotNull(result44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(obj47);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention0 = new com.google.javascript.jscomp.DefaultCodingConvention();
        boolean boolean2 = defaultCodingConvention0.isExported("// Input %num%");
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry3 = null;
        com.google.javascript.jscomp.Scope scope4 = null;
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention5 = new com.google.javascript.jscomp.DefaultCodingConvention();
        java.lang.String str6 = defaultCodingConvention5.getDelegateSuperclassName();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry7 = null;
        com.google.javascript.jscomp.Scope scope8 = null;
        com.google.javascript.rhino.jstype.ObjectType[] objectTypeArray9 = new com.google.javascript.rhino.jstype.ObjectType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.ObjectType> objectTypeList10 = new java.util.ArrayList<com.google.javascript.rhino.jstype.ObjectType>();
        boolean boolean11 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.ObjectType>) objectTypeList10, objectTypeArray9);
        defaultCodingConvention5.defineDelegateProxyPrototypeProperties(jSTypeRegistry7, scope8, (java.util.List<com.google.javascript.rhino.jstype.ObjectType>) objectTypeList10);
        defaultCodingConvention0.defineDelegateProxyPrototypeProperties(jSTypeRegistry3, scope4, (java.util.List<com.google.javascript.rhino.jstype.ObjectType>) objectTypeList10);
        java.io.PrintStream printStream14 = null;
        com.google.javascript.jscomp.Compiler compiler15 = new com.google.javascript.jscomp.Compiler(printStream14);
        compiler15.disableThreads();
        com.google.javascript.jscomp.PerformanceTracker performanceTracker17 = compiler15.tracker;
        com.google.javascript.jscomp.NodeTraversal.Callback callback18 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal19 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler15, callback18);
        com.google.javascript.rhino.Node node21 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node23 = new com.google.javascript.rhino.Node((int) '4');
        node21.addChildrenToBack(node23);
        com.google.javascript.jscomp.DiagnosticType diagnosticType27 = com.google.javascript.jscomp.DiagnosticType.warning("hi!", "hi!");
        com.google.javascript.jscomp.DiagnosticType diagnosticType28 = com.google.javascript.jscomp.Compiler.MOTION_ITERATIONS_ERROR;
        int int29 = diagnosticType27.compareTo(diagnosticType28);
        java.lang.String[] strArray30 = com.google.javascript.rhino.ScriptRuntime.emptyStrings;
        com.google.javascript.jscomp.JSError jSError31 = nodeTraversal19.makeError(node23, diagnosticType27, strArray30);
        java.util.List<java.lang.String> strList32 = defaultCodingConvention0.identifyTypeDeclarationCall(node23);
        com.google.javascript.rhino.Node node34 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node36 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node38 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node40 = new com.google.javascript.rhino.Node((int) '4');
        node38.addChildrenToBack(node40);
        node34.addChildAfter(node36, node40);
        com.google.javascript.rhino.Node node44 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node46 = new com.google.javascript.rhino.Node((int) '4');
        node44.addChildrenToBack(node46);
        com.google.javascript.rhino.Node node48 = node34.copyInformationFromForTree(node46);
        com.google.javascript.jscomp.CodingConvention.SubclassRelationship subclassRelationship49 = defaultCodingConvention0.getClassesDefinedByCall(node48);
        com.google.javascript.rhino.JSDocInfo jSDocInfo50 = null;
        node48.setJSDocInfo(jSDocInfo50);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNotNull(objectTypeArray9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNull(performanceTracker17);
        org.junit.Assert.assertNotNull(diagnosticType27);
        org.junit.Assert.assertNotNull(diagnosticType28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 30 + "'", int29 == 30);
        org.junit.Assert.assertNotNull(strArray30);
        org.junit.Assert.assertNotNull(jSError31);
        org.junit.Assert.assertNull(strList32);
        org.junit.Assert.assertNotNull(node48);
        org.junit.Assert.assertNull(subclassRelationship49);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        boolean boolean2 = closureCodingConvention0.isPrivate("// Input %num%");
        com.google.javascript.rhino.Node node4 = new com.google.javascript.rhino.Node(23);
        com.google.javascript.rhino.Node node8 = new com.google.javascript.rhino.Node(30, 35, 8);
        com.google.javascript.rhino.Node node9 = node8.getLastChild();
        java.lang.String str10 = closureCodingConvention0.extractClassNameIfProvide(node4, node8);
        try {
            int int12 = node4.getExistingIntProp(19);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: FAILED ASSERTION");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(node9);
        org.junit.Assert.assertNull(str10);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        com.google.javascript.rhino.Node node1 = new com.google.javascript.rhino.Node(23);
        int int2 = node1.getCharno();
        boolean boolean3 = node1.isOptionalArg();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        try {
            com.google.javascript.rhino.EcmaError ecmaError2 = com.google.javascript.rhino.ScriptRuntime.typeError1("4", "error reporter");
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property 4");
        } catch (java.lang.RuntimeException e) {
        }
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        com.google.javascript.jscomp.SourceAst sourceAst0 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(sourceAst0, "", false);
        com.google.javascript.jscomp.JSModule jSModule4 = compilerInput3.getModule();
        com.google.javascript.jscomp.CompilerInput compilerInput7 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput3, "JSC_OPTIMIZE_LOOP_ERROR. Exceeded max number of code motion iterations: {0} at (unknown source) line (unknown line) : (unknown column)", false);
        java.io.PrintStream printStream8 = null;
        com.google.javascript.jscomp.Compiler compiler9 = new com.google.javascript.jscomp.Compiler(printStream8);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile12 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile15 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        java.io.Reader reader16 = jSSourceFile15.getCodeReader();
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray17 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile12, jSSourceFile15 };
        java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList18 = new java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile>();
        boolean boolean19 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList18, jSSourceFileArray17);
        com.google.javascript.jscomp.JSModule[] jSModuleArray20 = new com.google.javascript.jscomp.JSModule[] {};
        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList21 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
        boolean boolean22 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList21, jSModuleArray20);
        com.google.javascript.jscomp.CompilerOptions compilerOptions23 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions23.setLooseTypes(true);
        boolean boolean26 = compilerOptions23.reserveRawExports;
        compilerOptions23.extractPrototypeMemberDeclarations = false;
        java.lang.String str29 = compilerOptions23.nameReferenceGraphPath;
        compilerOptions23.computeFunctionSideEffects = true;
        com.google.javascript.jscomp.CompilerOptions compilerOptions32 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions32.setLooseTypes(true);
        compilerOptions32.convertToDottedProperties = false;
        com.google.javascript.jscomp.CheckLevel checkLevel37 = compilerOptions32.reportMissingOverride;
        compilerOptions23.brokenClosureRequiresLevel = checkLevel37;
        java.util.Set<java.lang.String> strSet39 = compilerOptions23.stripTypePrefixes;
        compilerOptions23.deadAssignmentElimination = false;
        compiler9.initModules((java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList18, (java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList21, compilerOptions23);
        compiler9.reportCodeChange();
        try {
            com.google.javascript.rhino.Node node44 = compilerInput7.getAstRoot((com.google.javascript.jscomp.AbstractCompiler) compiler9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(jSModule4);
        org.junit.Assert.assertNotNull(jSSourceFile12);
        org.junit.Assert.assertNotNull(jSSourceFile15);
        org.junit.Assert.assertNotNull(reader16);
        org.junit.Assert.assertNotNull(jSSourceFileArray17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(jSModuleArray20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNull(str29);
        org.junit.Assert.assertTrue("'" + checkLevel37 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel37.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(strSet39);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.CHECK_VARIABLES;
        com.google.javascript.jscomp.DiagnosticGroups.NON_STANDARD_JSDOC = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticGroups.CONSTANT_PROPERTY = diagnosticGroup0;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setLooseTypes(true);
        compilerOptions0.renamePrefix = "hi!";
        java.lang.String str5 = compilerOptions0.locale;
        compilerOptions0.checkMissingGetCssNameBlacklist = "language version";
        org.junit.Assert.assertNull(str5);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setLooseTypes(true);
        boolean boolean3 = compilerOptions0.collapseVariableDeclarations;
        compilerOptions0.moveFunctionDeclarations = false;
        boolean boolean6 = compilerOptions0.decomposeExpressions;
        boolean boolean7 = compilerOptions0.optimizeParameters;
        java.lang.String str8 = compilerOptions0.inputDelimiter;
        java.lang.String[] strArray10 = new java.lang.String[] { "hi!" };
        java.util.LinkedHashSet<java.lang.String> strSet11 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean12 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet11, strArray10);
        compilerOptions0.stripTypes = strSet11;
        boolean boolean14 = compilerOptions0.inlineLocalVariables;
        com.google.javascript.jscomp.CheckLevel checkLevel15 = compilerOptions0.checkGlobalThisLevel;
        com.google.javascript.jscomp.CompilerOptions compilerOptions16 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions16.setLooseTypes(true);
        compilerOptions16.checkSuspiciousCode = false;
        com.google.javascript.jscomp.CheckLevel checkLevel21 = compilerOptions16.checkRequires;
        compilerOptions0.reportMissingOverride = checkLevel21;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "// Input %num%" + "'", str8.equals("// Input %num%"));
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + checkLevel15 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel15.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + checkLevel21 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel21.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setLooseTypes(true);
        boolean boolean3 = compilerOptions0.reserveRawExports;
        com.google.javascript.jscomp.CheckLevel checkLevel4 = null;
        compilerOptions0.checkUnreachableCode = checkLevel4;
        com.google.javascript.jscomp.MessageBundle messageBundle6 = compilerOptions0.messageBundle;
        java.lang.String str7 = compilerOptions0.sourceMapOutputPath;
        compilerOptions0.inlineConstantVars = false;
        com.google.javascript.jscomp.CompilerOptions compilerOptions10 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions10.setLooseTypes(true);
        boolean boolean13 = compilerOptions10.reserveRawExports;
        com.google.javascript.jscomp.CheckLevel checkLevel14 = null;
        compilerOptions10.checkUnreachableCode = checkLevel14;
        com.google.javascript.jscomp.MessageBundle messageBundle16 = compilerOptions10.messageBundle;
        compilerOptions10.checkDuplicateMessages = false;
        compilerOptions10.aliasExternals = true;
        compilerOptions10.aliasAllStrings = false;
        com.google.javascript.jscomp.CompilerOptions.TweakProcessing tweakProcessing23 = compilerOptions10.getTweakProcessing();
        compilerOptions0.setTweakProcessing(tweakProcessing23);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(messageBundle6);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNull(messageBundle16);
        org.junit.Assert.assertTrue("'" + tweakProcessing23 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TweakProcessing.OFF + "'", tweakProcessing23.equals(com.google.javascript.jscomp.CompilerOptions.TweakProcessing.OFF));
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        java.lang.String str1 = com.google.javascript.rhino.jstype.ObjectType.createDelegateSuffix("INSTANCEOF\n");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "(INSTANCEOF\n)" + "'", str1.equals("(INSTANCEOF\n)"));
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = null;
        com.google.javascript.jscomp.DiagnosticGroups.STRICT_MODULE_DEP_CHECK = diagnosticGroup0;
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        compiler1.disableThreads();
        com.google.javascript.jscomp.PerformanceTracker performanceTracker3 = compiler1.tracker;
        com.google.javascript.jscomp.NodeTraversal.Callback callback4 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal5 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler1, callback4);
        java.io.PrintStream printStream6 = null;
        com.google.javascript.jscomp.Compiler compiler7 = new com.google.javascript.jscomp.Compiler(printStream6);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile10 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        java.io.Reader reader11 = jSSourceFile10.getCodeReader();
        com.google.javascript.jscomp.JSModule[] jSModuleArray12 = new com.google.javascript.jscomp.JSModule[] {};
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph13 = new com.google.javascript.jscomp.JSModuleGraph(jSModuleArray12);
        com.google.javascript.jscomp.CompilerOptions compilerOptions14 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions14.setLooseTypes(true);
        boolean boolean17 = compilerOptions14.collapseVariableDeclarations;
        compilerOptions14.moveFunctionDeclarations = false;
        boolean boolean20 = compilerOptions14.decomposeExpressions;
        com.google.javascript.jscomp.CheckLevel checkLevel21 = compilerOptions14.checkMissingGetCssNameLevel;
        com.google.javascript.jscomp.Result result22 = compiler7.compile(jSSourceFile10, jSModuleArray12, compilerOptions14);
        java.io.PrintStream printStream23 = null;
        com.google.javascript.jscomp.Compiler compiler24 = new com.google.javascript.jscomp.Compiler(printStream23);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile27 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        java.io.Reader reader28 = jSSourceFile27.getCodeReader();
        com.google.javascript.jscomp.JSModule[] jSModuleArray29 = new com.google.javascript.jscomp.JSModule[] {};
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph30 = new com.google.javascript.jscomp.JSModuleGraph(jSModuleArray29);
        com.google.javascript.jscomp.CompilerOptions compilerOptions31 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions31.setLooseTypes(true);
        boolean boolean34 = compilerOptions31.collapseVariableDeclarations;
        compilerOptions31.moveFunctionDeclarations = false;
        boolean boolean37 = compilerOptions31.decomposeExpressions;
        com.google.javascript.jscomp.CheckLevel checkLevel38 = compilerOptions31.checkMissingGetCssNameLevel;
        com.google.javascript.jscomp.Result result39 = compiler24.compile(jSSourceFile27, jSModuleArray29, compilerOptions31);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile42 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        java.io.PrintStream printStream43 = null;
        com.google.javascript.jscomp.Compiler compiler44 = new com.google.javascript.jscomp.Compiler(printStream43);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile47 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        java.io.Reader reader48 = jSSourceFile47.getCodeReader();
        com.google.javascript.jscomp.JSModule[] jSModuleArray49 = new com.google.javascript.jscomp.JSModule[] {};
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph50 = new com.google.javascript.jscomp.JSModuleGraph(jSModuleArray49);
        com.google.javascript.jscomp.CompilerOptions compilerOptions51 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions51.setLooseTypes(true);
        boolean boolean54 = compilerOptions51.collapseVariableDeclarations;
        compilerOptions51.moveFunctionDeclarations = false;
        boolean boolean57 = compilerOptions51.decomposeExpressions;
        com.google.javascript.jscomp.CheckLevel checkLevel58 = compilerOptions51.checkMissingGetCssNameLevel;
        com.google.javascript.jscomp.Result result59 = compiler44.compile(jSSourceFile47, jSModuleArray49, compilerOptions51);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile62 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile65 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        java.io.Reader reader66 = jSSourceFile65.getCodeReader();
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray67 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile10, jSSourceFile27, jSSourceFile42, jSSourceFile47, jSSourceFile62, jSSourceFile65 };
        java.io.PrintStream printStream68 = null;
        com.google.javascript.jscomp.Compiler compiler69 = new com.google.javascript.jscomp.Compiler(printStream68);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile72 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        java.io.Reader reader73 = jSSourceFile72.getCodeReader();
        com.google.javascript.jscomp.JSModule[] jSModuleArray74 = new com.google.javascript.jscomp.JSModule[] {};
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph75 = new com.google.javascript.jscomp.JSModuleGraph(jSModuleArray74);
        com.google.javascript.jscomp.CompilerOptions compilerOptions76 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions76.setLooseTypes(true);
        boolean boolean79 = compilerOptions76.collapseVariableDeclarations;
        compilerOptions76.moveFunctionDeclarations = false;
        boolean boolean82 = compilerOptions76.decomposeExpressions;
        com.google.javascript.jscomp.CheckLevel checkLevel83 = compilerOptions76.checkMissingGetCssNameLevel;
        com.google.javascript.jscomp.Result result84 = compiler69.compile(jSSourceFile72, jSModuleArray74, compilerOptions76);
        com.google.javascript.jscomp.CompilerOptions compilerOptions85 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions85.setLooseTypes(true);
        boolean boolean88 = compilerOptions85.collapseVariableDeclarations;
        compilerOptions85.setManageClosureDependencies(false);
        com.google.javascript.jscomp.Result result91 = compiler1.compile(jSSourceFileArray67, jSModuleArray74, compilerOptions85);
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph92 = new com.google.javascript.jscomp.JSModuleGraph(jSModuleArray74);
        java.util.Collection<com.google.javascript.jscomp.JSModule> jSModuleCollection93 = null;
        try {
            com.google.javascript.jscomp.JSModule jSModule94 = jSModuleGraph92.getDeepestCommonDependencyInclusive(jSModuleCollection93);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(performanceTracker3);
        org.junit.Assert.assertNotNull(jSSourceFile10);
        org.junit.Assert.assertNotNull(reader11);
        org.junit.Assert.assertNotNull(jSModuleArray12);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + checkLevel21 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel21.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(result22);
        org.junit.Assert.assertNotNull(jSSourceFile27);
        org.junit.Assert.assertNotNull(reader28);
        org.junit.Assert.assertNotNull(jSModuleArray29);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + checkLevel38 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel38.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(result39);
        org.junit.Assert.assertNotNull(jSSourceFile42);
        org.junit.Assert.assertNotNull(jSSourceFile47);
        org.junit.Assert.assertNotNull(reader48);
        org.junit.Assert.assertNotNull(jSModuleArray49);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertTrue("'" + checkLevel58 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel58.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(result59);
        org.junit.Assert.assertNotNull(jSSourceFile62);
        org.junit.Assert.assertNotNull(jSSourceFile65);
        org.junit.Assert.assertNotNull(reader66);
        org.junit.Assert.assertNotNull(jSSourceFileArray67);
        org.junit.Assert.assertNotNull(jSSourceFile72);
        org.junit.Assert.assertNotNull(reader73);
        org.junit.Assert.assertNotNull(jSModuleArray74);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
        org.junit.Assert.assertTrue("'" + checkLevel83 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel83.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(result84);
        org.junit.Assert.assertTrue("'" + boolean88 + "' != '" + false + "'", boolean88 == false);
        org.junit.Assert.assertNotNull(result91);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setLooseTypes(true);
        boolean boolean3 = compilerOptions0.reserveRawExports;
        com.google.javascript.jscomp.CheckLevel checkLevel4 = null;
        compilerOptions0.checkGlobalNamesLevel = checkLevel4;
        boolean boolean6 = compilerOptions0.convertToDottedProperties;
        compilerOptions0.removeUnusedVars = false;
        boolean boolean9 = compilerOptions0.checkEs5Strict;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile4 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        java.io.Reader reader5 = jSSourceFile4.getCodeReader();
        com.google.javascript.jscomp.JSModule[] jSModuleArray6 = new com.google.javascript.jscomp.JSModule[] {};
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph7 = new com.google.javascript.jscomp.JSModuleGraph(jSModuleArray6);
        com.google.javascript.jscomp.CompilerOptions compilerOptions8 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions8.setLooseTypes(true);
        boolean boolean11 = compilerOptions8.collapseVariableDeclarations;
        compilerOptions8.moveFunctionDeclarations = false;
        boolean boolean14 = compilerOptions8.decomposeExpressions;
        com.google.javascript.jscomp.CheckLevel checkLevel15 = compilerOptions8.checkMissingGetCssNameLevel;
        com.google.javascript.jscomp.Result result16 = compiler1.compile(jSSourceFile4, jSModuleArray6, compilerOptions8);
        com.google.javascript.jscomp.Result result17 = compiler1.getResult();
        com.google.javascript.jscomp.Compiler.IntermediateState intermediateState18 = compiler1.getState();
        boolean boolean19 = compiler1.hasErrors();
        com.google.javascript.jscomp.ErrorManager errorManager20 = compiler1.getErrorManager();
        org.junit.Assert.assertNotNull(jSSourceFile4);
        org.junit.Assert.assertNotNull(reader5);
        org.junit.Assert.assertNotNull(jSModuleArray6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + checkLevel15 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel15.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(result16);
        org.junit.Assert.assertNotNull(result17);
        org.junit.Assert.assertNotNull(intermediateState18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(errorManager20);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        java.io.PrintStream printStream2 = null;
        com.google.javascript.jscomp.Compiler compiler3 = new com.google.javascript.jscomp.Compiler(printStream2);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile6 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        java.io.Reader reader7 = jSSourceFile6.getCodeReader();
        com.google.javascript.jscomp.JSModule[] jSModuleArray8 = new com.google.javascript.jscomp.JSModule[] {};
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph9 = new com.google.javascript.jscomp.JSModuleGraph(jSModuleArray8);
        com.google.javascript.jscomp.CompilerOptions compilerOptions10 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions10.setLooseTypes(true);
        boolean boolean13 = compilerOptions10.collapseVariableDeclarations;
        compilerOptions10.moveFunctionDeclarations = false;
        boolean boolean16 = compilerOptions10.decomposeExpressions;
        com.google.javascript.jscomp.CheckLevel checkLevel17 = compilerOptions10.checkMissingGetCssNameLevel;
        com.google.javascript.jscomp.Result result18 = compiler3.compile(jSSourceFile6, jSModuleArray8, compilerOptions10);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile21 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile24 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        java.io.Reader reader25 = jSSourceFile24.getCodeReader();
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray26 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile6, jSSourceFile21, jSSourceFile24 };
        java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList27 = new java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile>();
        boolean boolean28 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList27, jSSourceFileArray26);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile31 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray32 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile31 };
        java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList33 = new java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile>();
        boolean boolean34 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList33, jSSourceFileArray32);
        com.google.javascript.jscomp.CompilerOptions compilerOptions35 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions35.setLooseTypes(true);
        boolean boolean38 = compilerOptions35.reserveRawExports;
        compilerOptions35.extractPrototypeMemberDeclarations = false;
        java.lang.String str41 = compilerOptions35.nameReferenceGraphPath;
        compilerOptions35.setSummaryDetailLevel(0);
        com.google.javascript.jscomp.Result result44 = compiler1.compile((java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList27, (java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList33, compilerOptions35);
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter45 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler1);
        try {
            compiler1.normalize();
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: INTERNAL COMPILER ERROR.\nPlease report this problem.\nnull");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile6);
        org.junit.Assert.assertNotNull(reader7);
        org.junit.Assert.assertNotNull(jSModuleArray8);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + checkLevel17 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel17.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(result18);
        org.junit.Assert.assertNotNull(jSSourceFile21);
        org.junit.Assert.assertNotNull(jSSourceFile24);
        org.junit.Assert.assertNotNull(reader25);
        org.junit.Assert.assertNotNull(jSSourceFileArray26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(jSSourceFile31);
        org.junit.Assert.assertNotNull(jSSourceFileArray32);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNull(str41);
        org.junit.Assert.assertNotNull(result44);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setLooseTypes(true);
        compilerOptions0.checkSuspiciousCode = false;
        compilerOptions0.disambiguateProperties = true;
        boolean boolean7 = compilerOptions0.printInputDelimiter;
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        compiler1.disableThreads();
        java.io.PrintStream printStream3 = null;
        com.google.javascript.jscomp.Compiler compiler4 = new com.google.javascript.jscomp.Compiler(printStream3);
        java.io.PrintStream printStream5 = null;
        com.google.javascript.jscomp.Compiler compiler6 = new com.google.javascript.jscomp.Compiler(printStream5);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile9 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        java.io.Reader reader10 = jSSourceFile9.getCodeReader();
        com.google.javascript.jscomp.JSModule[] jSModuleArray11 = new com.google.javascript.jscomp.JSModule[] {};
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph12 = new com.google.javascript.jscomp.JSModuleGraph(jSModuleArray11);
        com.google.javascript.jscomp.CompilerOptions compilerOptions13 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions13.setLooseTypes(true);
        boolean boolean16 = compilerOptions13.collapseVariableDeclarations;
        compilerOptions13.moveFunctionDeclarations = false;
        boolean boolean19 = compilerOptions13.decomposeExpressions;
        com.google.javascript.jscomp.CheckLevel checkLevel20 = compilerOptions13.checkMissingGetCssNameLevel;
        com.google.javascript.jscomp.Result result21 = compiler6.compile(jSSourceFile9, jSModuleArray11, compilerOptions13);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile24 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile27 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        java.io.Reader reader28 = jSSourceFile27.getCodeReader();
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray29 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile9, jSSourceFile24, jSSourceFile27 };
        java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList30 = new java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile>();
        boolean boolean31 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList30, jSSourceFileArray29);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile34 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray35 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile34 };
        java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList36 = new java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile>();
        boolean boolean37 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList36, jSSourceFileArray35);
        com.google.javascript.jscomp.CompilerOptions compilerOptions38 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions38.setLooseTypes(true);
        boolean boolean41 = compilerOptions38.reserveRawExports;
        compilerOptions38.extractPrototypeMemberDeclarations = false;
        java.lang.String str44 = compilerOptions38.nameReferenceGraphPath;
        compilerOptions38.setSummaryDetailLevel(0);
        com.google.javascript.jscomp.Result result47 = compiler4.compile((java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList30, (java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList36, compilerOptions38);
        java.io.PrintStream printStream48 = null;
        com.google.javascript.jscomp.Compiler compiler49 = new com.google.javascript.jscomp.Compiler(printStream48);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile52 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile55 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        java.io.Reader reader56 = jSSourceFile55.getCodeReader();
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray57 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile52, jSSourceFile55 };
        java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList58 = new java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile>();
        boolean boolean59 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList58, jSSourceFileArray57);
        com.google.javascript.jscomp.JSModule[] jSModuleArray60 = new com.google.javascript.jscomp.JSModule[] {};
        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList61 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
        boolean boolean62 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList61, jSModuleArray60);
        com.google.javascript.jscomp.CompilerOptions compilerOptions63 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions63.setLooseTypes(true);
        boolean boolean66 = compilerOptions63.reserveRawExports;
        compilerOptions63.extractPrototypeMemberDeclarations = false;
        java.lang.String str69 = compilerOptions63.nameReferenceGraphPath;
        compilerOptions63.computeFunctionSideEffects = true;
        com.google.javascript.jscomp.CompilerOptions compilerOptions72 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions72.setLooseTypes(true);
        compilerOptions72.convertToDottedProperties = false;
        com.google.javascript.jscomp.CheckLevel checkLevel77 = compilerOptions72.reportMissingOverride;
        compilerOptions63.brokenClosureRequiresLevel = checkLevel77;
        java.util.Set<java.lang.String> strSet79 = compilerOptions63.stripTypePrefixes;
        compilerOptions63.deadAssignmentElimination = false;
        compiler49.initModules((java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList58, (java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList61, compilerOptions63);
        com.google.javascript.jscomp.CompilerOptions compilerOptions83 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions83.setLooseTypes(true);
        compilerOptions83.renamePrefix = "hi!";
        com.google.javascript.jscomp.Result result88 = compiler1.compileModules((java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList36, (java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList61, compilerOptions83);
        org.junit.Assert.assertNotNull(jSSourceFile9);
        org.junit.Assert.assertNotNull(reader10);
        org.junit.Assert.assertNotNull(jSModuleArray11);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + checkLevel20 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel20.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(result21);
        org.junit.Assert.assertNotNull(jSSourceFile24);
        org.junit.Assert.assertNotNull(jSSourceFile27);
        org.junit.Assert.assertNotNull(reader28);
        org.junit.Assert.assertNotNull(jSSourceFileArray29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertNotNull(jSSourceFile34);
        org.junit.Assert.assertNotNull(jSSourceFileArray35);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNull(str44);
        org.junit.Assert.assertNotNull(result47);
        org.junit.Assert.assertNotNull(jSSourceFile52);
        org.junit.Assert.assertNotNull(jSSourceFile55);
        org.junit.Assert.assertNotNull(reader56);
        org.junit.Assert.assertNotNull(jSSourceFileArray57);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + true + "'", boolean59 == true);
        org.junit.Assert.assertNotNull(jSModuleArray60);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertNull(str69);
        org.junit.Assert.assertTrue("'" + checkLevel77 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel77.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(strSet79);
        org.junit.Assert.assertNotNull(result88);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setLooseTypes(true);
        compilerOptions0.convertToDottedProperties = false;
        com.google.javascript.jscomp.CheckLevel checkLevel5 = compilerOptions0.reportMissingOverride;
        boolean boolean6 = compilerOptions0.aliasAllStrings;
        compilerOptions0.removeUnusedPrototypePropertiesInExterns = false;
        compilerOptions0.reportPath = "DiagnosticGroup<externsValidation>";
        org.junit.Assert.assertTrue("'" + checkLevel5 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel5.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        com.google.javascript.jscomp.SourceAst sourceAst0 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(sourceAst0, "", false);
        boolean boolean4 = compilerInput3.isExtern();
        try {
            com.google.javascript.jscomp.CompilerInput compilerInput5 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        com.google.javascript.jscomp.SourceAst sourceAst0 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(sourceAst0, "", false);
        boolean boolean4 = compilerInput3.isExtern();
        java.lang.String str5 = compilerInput3.getName();
        com.google.javascript.jscomp.JSModule jSModule6 = compilerInput3.getModule();
        com.google.javascript.jscomp.CompilerInput compilerInput9 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput3, "<No stack trace available>", false);
        try {
            java.util.Collection<java.lang.String> strCollection10 = compilerInput9.getRequires();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Expected setErrorManager to be called first");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertNull(jSModule6);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.CHECK_VARIABLES;
        com.google.javascript.jscomp.DiagnosticGroups.NON_STANDARD_JSDOC = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticGroups.UNKNOWN_DEFINES = diagnosticGroup0;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile4 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        java.io.Reader reader5 = jSSourceFile4.getCodeReader();
        com.google.javascript.jscomp.JSModule[] jSModuleArray6 = new com.google.javascript.jscomp.JSModule[] {};
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph7 = new com.google.javascript.jscomp.JSModuleGraph(jSModuleArray6);
        com.google.javascript.jscomp.CompilerOptions compilerOptions8 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions8.setLooseTypes(true);
        boolean boolean11 = compilerOptions8.collapseVariableDeclarations;
        compilerOptions8.moveFunctionDeclarations = false;
        boolean boolean14 = compilerOptions8.decomposeExpressions;
        com.google.javascript.jscomp.CheckLevel checkLevel15 = compilerOptions8.checkMissingGetCssNameLevel;
        com.google.javascript.jscomp.Result result16 = compiler1.compile(jSSourceFile4, jSModuleArray6, compilerOptions8);
        com.google.javascript.jscomp.Result result17 = compiler1.getResult();
        boolean boolean18 = compiler1.hasErrors();
        com.google.javascript.jscomp.SourceFile.Generator generator20 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile21 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("JSC_OPTIMIZE_LOOP_ERROR. Exceeded max number of code motion iterations: {0} at (unknown source) line (unknown line) : (unknown column)", generator20);
        com.google.javascript.jscomp.SourceFile.Generator generator23 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile24 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("JSC_OPTIMIZE_LOOP_ERROR. Exceeded max number of code motion iterations: {0} at (unknown source) line (unknown line) : (unknown column)", generator23);
        com.google.javascript.jscomp.CompilerOptions compilerOptions25 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions25.setLooseTypes(true);
        boolean boolean28 = compilerOptions25.reserveRawExports;
        compilerOptions25.extractPrototypeMemberDeclarations = false;
        java.lang.String str31 = compilerOptions25.nameReferenceGraphPath;
        compilerOptions25.computeFunctionSideEffects = true;
        com.google.javascript.jscomp.CompilerOptions compilerOptions34 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions34.setLooseTypes(true);
        compilerOptions34.convertToDottedProperties = false;
        com.google.javascript.jscomp.CheckLevel checkLevel39 = compilerOptions34.reportMissingOverride;
        compilerOptions25.brokenClosureRequiresLevel = checkLevel39;
        java.util.Set<java.lang.String> strSet41 = compilerOptions25.stripTypePrefixes;
        compilerOptions25.optimizeReturns = true;
        com.google.javascript.jscomp.Result result44 = compiler1.compile(jSSourceFile21, jSSourceFile24, compilerOptions25);
        compilerOptions25.enableRuntimeTypeCheck("Not declared as a type name");
        compilerOptions25.setProcessObjectPropertyString(false);
        compilerOptions25.setColorizeErrorOutput(true);
        org.junit.Assert.assertNotNull(jSSourceFile4);
        org.junit.Assert.assertNotNull(reader5);
        org.junit.Assert.assertNotNull(jSModuleArray6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + checkLevel15 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel15.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(result16);
        org.junit.Assert.assertNotNull(result17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(jSSourceFile21);
        org.junit.Assert.assertNotNull(jSSourceFile24);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNull(str31);
        org.junit.Assert.assertTrue("'" + checkLevel39 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel39.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(strSet41);
        org.junit.Assert.assertNotNull(result44);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setLooseTypes(true);
        compilerOptions0.renamePrefix = "hi!";
        compilerOptions0.checkControlStructures = false;
        boolean boolean7 = compilerOptions0.removeTryCatchFinally;
        boolean boolean8 = compilerOptions0.markAsCompiled;
        compilerOptions0.instrumentationTemplate = "(language version)";
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.CHECK_VARIABLES;
        com.google.javascript.jscomp.DiagnosticGroups.NON_STANDARD_JSDOC = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticGroups.EXTERNS_VALIDATION = diagnosticGroup0;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention0 = new com.google.javascript.jscomp.DefaultCodingConvention();
        java.lang.String str1 = defaultCodingConvention0.getDelegateSuperclassName();
        boolean boolean3 = defaultCodingConvention0.isExported("JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}");
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setLooseTypes(true);
        boolean boolean3 = compilerOptions0.collapseVariableDeclarations;
        compilerOptions0.recordFunctionInformation = false;
        compilerOptions0.convertToDottedProperties = false;
        compilerOptions0.checkUnusedPropertiesEarly = false;
        boolean boolean10 = compilerOptions0.crossModuleMethodMotion;
        compilerOptions0.convertToDottedProperties = false;
        com.google.javascript.jscomp.CheckLevel checkLevel13 = compilerOptions0.checkUndefinedProperties;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + checkLevel13 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel13.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        com.google.javascript.rhino.Context context0 = null;
        try {
            com.google.javascript.rhino.ScriptRuntime.storeUint32Result(context0, (long) 9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.flowSensitiveInlineVariables = false;
        compilerOptions0.optimizeCalls = true;
        compilerOptions0.inlineFunctions = true;
        boolean boolean7 = compilerOptions0.tightenTypes;
        java.util.Set<java.lang.String> strSet8 = compilerOptions0.stripNamePrefixes;
        compilerOptions0.setTweakToStringLiteral("TypeError", "(<No stack trace available>)");
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(strSet8);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setLooseTypes(true);
        boolean boolean3 = compilerOptions0.collapseVariableDeclarations;
        compilerOptions0.aliasExternals = true;
        com.google.javascript.jscomp.CheckLevel checkLevel6 = compilerOptions0.checkMissingGetCssNameLevel;
        boolean boolean7 = compilerOptions0.devirtualizePrototypeMethods;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + checkLevel6 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel6.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setLooseTypes(true);
        compilerOptions0.checkSuspiciousCode = false;
        com.google.common.collect.Multimap<com.google.javascript.jscomp.CustomPassExecutionTime, com.google.javascript.jscomp.CompilerPass> customPassExecutionTimeMultimap5 = compilerOptions0.customPasses;
        compilerOptions0.rewriteFunctionExpressions = true;
        compilerOptions0.optimizeCalls = false;
        com.google.common.collect.Multimap<com.google.javascript.jscomp.CustomPassExecutionTime, com.google.javascript.jscomp.CompilerPass> customPassExecutionTimeMultimap10 = null;
        compilerOptions0.customPasses = customPassExecutionTimeMultimap10;
        org.junit.Assert.assertNull(customPassExecutionTimeMultimap5);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        java.lang.String str1 = closureCodingConvention0.getGlobalObject();
        java.io.PrintStream printStream2 = null;
        com.google.javascript.jscomp.Compiler compiler3 = new com.google.javascript.jscomp.Compiler(printStream2);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile6 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        java.io.Reader reader7 = jSSourceFile6.getCodeReader();
        com.google.javascript.jscomp.JSModule[] jSModuleArray8 = new com.google.javascript.jscomp.JSModule[] {};
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph9 = new com.google.javascript.jscomp.JSModuleGraph(jSModuleArray8);
        com.google.javascript.jscomp.CompilerOptions compilerOptions10 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions10.setLooseTypes(true);
        boolean boolean13 = compilerOptions10.collapseVariableDeclarations;
        compilerOptions10.moveFunctionDeclarations = false;
        boolean boolean16 = compilerOptions10.decomposeExpressions;
        com.google.javascript.jscomp.CheckLevel checkLevel17 = compilerOptions10.checkMissingGetCssNameLevel;
        com.google.javascript.jscomp.Result result18 = compiler3.compile(jSSourceFile6, jSModuleArray8, compilerOptions10);
        int int19 = compiler3.getErrorCount();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry20 = compiler3.getTypeRegistry();
        com.google.javascript.jscomp.Scope scope21 = null;
        com.google.javascript.rhino.jstype.ObjectType[] objectTypeArray22 = new com.google.javascript.rhino.jstype.ObjectType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.ObjectType> objectTypeList23 = new java.util.ArrayList<com.google.javascript.rhino.jstype.ObjectType>();
        boolean boolean24 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.ObjectType>) objectTypeList23, objectTypeArray22);
        closureCodingConvention0.defineDelegateProxyPrototypeProperties(jSTypeRegistry20, scope21, (java.util.List<com.google.javascript.rhino.jstype.ObjectType>) objectTypeList23);
        java.io.PrintStream printStream26 = null;
        com.google.javascript.jscomp.Compiler compiler27 = new com.google.javascript.jscomp.Compiler(printStream26);
        compiler27.disableThreads();
        com.google.javascript.jscomp.PerformanceTracker performanceTracker29 = compiler27.tracker;
        com.google.javascript.jscomp.NodeTraversal.Callback callback30 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal31 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler27, callback30);
        com.google.javascript.jscomp.Compiler compiler32 = nodeTraversal31.getCompiler();
        com.google.javascript.rhino.Node node34 = com.google.javascript.rhino.Node.newString("hi!");
        int int35 = node34.getCharno();
        node34.setType(40);
        try {
            com.google.javascript.jscomp.CodingConvention.ObjectLiteralCast objectLiteralCast38 = closureCodingConvention0.getObjectLiteralCast(nodeTraversal31, node34);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "goog.global" + "'", str1.equals("goog.global"));
        org.junit.Assert.assertNotNull(jSSourceFile6);
        org.junit.Assert.assertNotNull(reader7);
        org.junit.Assert.assertNotNull(jSModuleArray8);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + checkLevel17 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel17.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(result18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertNotNull(jSTypeRegistry20);
        org.junit.Assert.assertNotNull(objectTypeArray22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNull(performanceTracker29);
        org.junit.Assert.assertNotNull(compiler32);
        org.junit.Assert.assertNotNull(node34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + (-1) + "'", int35 == (-1));
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node2 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node4 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node6 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node8 = new com.google.javascript.rhino.Node((int) '4');
        node6.addChildrenToBack(node8);
        node2.addChildAfter(node4, node8);
        com.google.javascript.rhino.Node node12 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node14 = new com.google.javascript.rhino.Node((int) '4');
        node12.addChildrenToBack(node14);
        com.google.javascript.rhino.Node node16 = node2.copyInformationFromForTree(node14);
        com.google.javascript.rhino.Node node17 = node16.getLastChild();
        com.google.javascript.rhino.Node node19 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node21 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node23 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node25 = new com.google.javascript.rhino.Node((int) '4');
        node23.addChildrenToBack(node25);
        node19.addChildAfter(node21, node25);
        com.google.javascript.rhino.Node node29 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node31 = new com.google.javascript.rhino.Node((int) '4');
        node29.addChildrenToBack(node31);
        com.google.javascript.rhino.Node node33 = node19.copyInformationFromForTree(node31);
        node16.addChildToBack(node19);
        com.google.javascript.rhino.Node node35 = node19.cloneNode();
        boolean boolean36 = closureCodingConvention0.isVarArgsParameter(node19);
        com.google.javascript.rhino.Node node38 = com.google.javascript.rhino.Node.newString("hi!");
        int int39 = node38.getCharno();
        com.google.javascript.rhino.Node node41 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node43 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node45 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node47 = new com.google.javascript.rhino.Node((int) '4');
        node45.addChildrenToBack(node47);
        node41.addChildAfter(node43, node47);
        com.google.javascript.rhino.Node node51 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node53 = new com.google.javascript.rhino.Node((int) '4');
        node51.addChildrenToBack(node53);
        com.google.javascript.rhino.Node node55 = node41.copyInformationFromForTree(node53);
        com.google.javascript.rhino.Node node56 = node41.cloneTree();
        com.google.javascript.rhino.Node node58 = new com.google.javascript.rhino.Node((int) '4');
        node56.addChildrenToBack(node58);
        java.lang.String str60 = closureCodingConvention0.extractClassNameIfRequire(node38, node58);
        java.util.Collection<com.google.javascript.jscomp.CodingConvention.AssertionFunctionSpec> assertionFunctionSpecCollection61 = closureCodingConvention0.getAssertionFunctions();
        com.google.javascript.rhino.jstype.FunctionType functionType62 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType63 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType64 = null;
        closureCodingConvention0.applySubclassRelationship(functionType62, functionType63, subclassType64);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertNull(node17);
        org.junit.Assert.assertNotNull(node33);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(node38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + (-1) + "'", int39 == (-1));
        org.junit.Assert.assertNotNull(node55);
        org.junit.Assert.assertNotNull(node56);
        org.junit.Assert.assertNull(str60);
        org.junit.Assert.assertNotNull(assertionFunctionSpecCollection61);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        java.io.PrintStream printStream2 = null;
        com.google.javascript.jscomp.Compiler compiler3 = new com.google.javascript.jscomp.Compiler(printStream2);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile6 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        java.io.Reader reader7 = jSSourceFile6.getCodeReader();
        com.google.javascript.jscomp.JSModule[] jSModuleArray8 = new com.google.javascript.jscomp.JSModule[] {};
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph9 = new com.google.javascript.jscomp.JSModuleGraph(jSModuleArray8);
        com.google.javascript.jscomp.CompilerOptions compilerOptions10 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions10.setLooseTypes(true);
        boolean boolean13 = compilerOptions10.collapseVariableDeclarations;
        compilerOptions10.moveFunctionDeclarations = false;
        boolean boolean16 = compilerOptions10.decomposeExpressions;
        com.google.javascript.jscomp.CheckLevel checkLevel17 = compilerOptions10.checkMissingGetCssNameLevel;
        com.google.javascript.jscomp.Result result18 = compiler3.compile(jSSourceFile6, jSModuleArray8, compilerOptions10);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile21 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile24 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        java.io.Reader reader25 = jSSourceFile24.getCodeReader();
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray26 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile6, jSSourceFile21, jSSourceFile24 };
        java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList27 = new java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile>();
        boolean boolean28 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList27, jSSourceFileArray26);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile31 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray32 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile31 };
        java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList33 = new java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile>();
        boolean boolean34 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList33, jSSourceFileArray32);
        com.google.javascript.jscomp.CompilerOptions compilerOptions35 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions35.setLooseTypes(true);
        boolean boolean38 = compilerOptions35.reserveRawExports;
        compilerOptions35.extractPrototypeMemberDeclarations = false;
        java.lang.String str41 = compilerOptions35.nameReferenceGraphPath;
        compilerOptions35.setSummaryDetailLevel(0);
        com.google.javascript.jscomp.Result result44 = compiler1.compile((java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList27, (java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList33, compilerOptions35);
        com.google.javascript.jscomp.CodingConvention codingConvention45 = compiler1.getCodingConvention();
        com.google.javascript.jscomp.Compiler.IntermediateState intermediateState46 = compiler1.getState();
        org.junit.Assert.assertNotNull(jSSourceFile6);
        org.junit.Assert.assertNotNull(reader7);
        org.junit.Assert.assertNotNull(jSModuleArray8);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + checkLevel17 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel17.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(result18);
        org.junit.Assert.assertNotNull(jSSourceFile21);
        org.junit.Assert.assertNotNull(jSSourceFile24);
        org.junit.Assert.assertNotNull(reader25);
        org.junit.Assert.assertNotNull(jSSourceFileArray26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(jSSourceFile31);
        org.junit.Assert.assertNotNull(jSSourceFileArray32);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNull(str41);
        org.junit.Assert.assertNotNull(result44);
        org.junit.Assert.assertNotNull(codingConvention45);
        org.junit.Assert.assertNotNull(intermediateState46);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        com.google.javascript.rhino.EvaluatorException evaluatorException3 = new com.google.javascript.rhino.EvaluatorException("(4)", "JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}", (int) (short) -1);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node3 = new com.google.javascript.rhino.Node((int) (short) 1);
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newString("hi!");
        int int6 = node5.getCharno();
        com.google.javascript.rhino.Node node8 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node10 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node12 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node14 = new com.google.javascript.rhino.Node((int) '4');
        node12.addChildrenToBack(node14);
        node8.addChildAfter(node10, node14);
        com.google.javascript.rhino.Node node18 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node20 = new com.google.javascript.rhino.Node((int) '4');
        node18.addChildrenToBack(node20);
        com.google.javascript.rhino.Node node22 = node8.copyInformationFromForTree(node20);
        com.google.javascript.rhino.Node node23 = node8.cloneTree();
        com.google.javascript.rhino.Node node24 = node8.cloneTree();
        com.google.javascript.rhino.Node node26 = new com.google.javascript.rhino.Node((int) '4');
        node26.setLineno(36);
        com.google.javascript.rhino.Node[] nodeArray29 = new com.google.javascript.rhino.Node[] { node3, node5, node24, node26 };
        com.google.javascript.rhino.Node node32 = new com.google.javascript.rhino.Node(0, nodeArray29, 25, 14);
        com.google.javascript.rhino.Node node34 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node36 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node38 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node40 = new com.google.javascript.rhino.Node((int) '4');
        node38.addChildrenToBack(node40);
        node34.addChildAfter(node36, node40);
        com.google.javascript.rhino.Node node44 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node46 = new com.google.javascript.rhino.Node((int) '4');
        node44.addChildrenToBack(node46);
        com.google.javascript.rhino.Node node48 = node34.copyInformationFromForTree(node46);
        com.google.javascript.rhino.Node node49 = node34.cloneTree();
        com.google.javascript.rhino.Node node50 = node34.cloneTree();
        java.lang.String str51 = closureCodingConvention0.extractClassNameIfRequire(node32, node34);
        int int52 = node34.getType();
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertNotNull(nodeArray29);
        org.junit.Assert.assertNotNull(node48);
        org.junit.Assert.assertNotNull(node49);
        org.junit.Assert.assertNotNull(node50);
        org.junit.Assert.assertNull(str51);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 52 + "'", int52 == 52);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        com.google.javascript.rhino.Context context0 = new com.google.javascript.rhino.Context();
        context0.setGeneratingSource(true);
        boolean boolean3 = context0.isGeneratingDebug();
        com.google.javascript.jscomp.CompilerOptions compilerOptions4 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions4.setLooseTypes(true);
        boolean boolean7 = compilerOptions4.reserveRawExports;
        com.google.javascript.jscomp.CheckLevel checkLevel8 = null;
        compilerOptions4.checkUnreachableCode = checkLevel8;
        com.google.javascript.jscomp.MessageBundle messageBundle10 = compilerOptions4.messageBundle;
        java.lang.String str11 = compilerOptions4.sourceMapOutputPath;
        compilerOptions4.generateExports = true;
        context0.seal((java.lang.Object) compilerOptions4);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(messageBundle10);
        org.junit.Assert.assertNull(str11);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        com.google.javascript.rhino.Node node1 = new com.google.javascript.rhino.Node((int) '4');
        node1.setLineno(36);
        try {
            node1.setSideEffectFlags(39);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: setIsNoSideEffectsCall only supports CALL and NEW nodes, got INSTANCEOF");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        com.google.javascript.jscomp.SourceAst sourceAst0 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(sourceAst0, "", false);
        com.google.javascript.jscomp.JSModule jSModule4 = compilerInput3.getModule();
        com.google.javascript.jscomp.CompilerInput compilerInput7 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput3, "JSC_OPTIMIZE_LOOP_ERROR. Exceeded max number of code motion iterations: {0} at (unknown source) line (unknown line) : (unknown column)", false);
        try {
            com.google.javascript.jscomp.CompilerInput compilerInput9 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput3, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(jSModule4);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setLooseTypes(true);
        boolean boolean3 = compilerOptions0.reserveRawExports;
        com.google.javascript.jscomp.CheckLevel checkLevel4 = null;
        compilerOptions0.checkUnreachableCode = checkLevel4;
        boolean boolean6 = compilerOptions0.devirtualizePrototypeMethods;
        compilerOptions0.setColorizeErrorOutput(true);
        compilerOptions0.setTweakToNumberLiteral("language version", (int) (byte) 10);
        boolean boolean12 = compilerOptions0.removeDeadCode;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention0 = new com.google.javascript.jscomp.DefaultCodingConvention();
        boolean boolean2 = defaultCodingConvention0.isConstant("hi!");
        boolean boolean4 = defaultCodingConvention0.isExported("()");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setLooseTypes(true);
        boolean boolean3 = compilerOptions0.reserveRawExports;
        compilerOptions0.extractPrototypeMemberDeclarations = false;
        compilerOptions0.checkMissingGetCssNameBlacklist = "4";
        boolean boolean8 = compilerOptions0.rewriteFunctionExpressions;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.TWEAKS;
        com.google.javascript.jscomp.DiagnosticGroups.INVALID_CASTS = diagnosticGroup0;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setLooseTypes(true);
        boolean boolean3 = compilerOptions0.collapseVariableDeclarations;
        compilerOptions0.moveFunctionDeclarations = false;
        boolean boolean6 = compilerOptions0.decomposeExpressions;
        compilerOptions0.setDefineToDoubleLiteral("(<No stack trace available>)", (double) 14);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        com.google.javascript.rhino.Node node1 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node3 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node5 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node7 = new com.google.javascript.rhino.Node((int) '4');
        node5.addChildrenToBack(node7);
        node1.addChildAfter(node3, node7);
        com.google.javascript.rhino.Node node11 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node((int) '4');
        node11.addChildrenToBack(node13);
        com.google.javascript.rhino.Node node15 = node1.copyInformationFromForTree(node13);
        com.google.javascript.rhino.Node node16 = node15.getLastChild();
        com.google.javascript.rhino.Node node18 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node20 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node22 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node24 = new com.google.javascript.rhino.Node((int) '4');
        node22.addChildrenToBack(node24);
        node18.addChildAfter(node20, node24);
        com.google.javascript.rhino.Node node28 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node30 = new com.google.javascript.rhino.Node((int) '4');
        node28.addChildrenToBack(node30);
        com.google.javascript.rhino.Node node32 = node18.copyInformationFromForTree(node30);
        node15.addChildToBack(node18);
        com.google.javascript.rhino.Node node35 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node37 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node39 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node41 = new com.google.javascript.rhino.Node((int) '4');
        node39.addChildrenToBack(node41);
        node35.addChildAfter(node37, node41);
        com.google.javascript.rhino.Node node45 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node47 = new com.google.javascript.rhino.Node((int) '4');
        node45.addChildrenToBack(node47);
        com.google.javascript.rhino.Node node49 = node35.copyInformationFromForTree(node47);
        com.google.javascript.rhino.jstype.JSType jSType50 = null;
        node49.setJSType(jSType50);
        node15.addChildToFront(node49);
        com.google.javascript.rhino.jstype.JSType jSType53 = node49.getJSType();
        boolean boolean54 = node49.isSyntheticBlock();
        boolean boolean55 = node49.hasOneChild();
        com.google.javascript.rhino.Node node57 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node59 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node61 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node63 = new com.google.javascript.rhino.Node((int) '4');
        node61.addChildrenToBack(node63);
        node57.addChildAfter(node59, node63);
        com.google.javascript.rhino.Node node67 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node69 = new com.google.javascript.rhino.Node((int) '4');
        node67.addChildrenToBack(node69);
        com.google.javascript.rhino.Node node71 = node57.copyInformationFromForTree(node69);
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable72 = node71.siblings();
        try {
            node49.removeChild(node71);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertNull(node16);
        org.junit.Assert.assertNotNull(node32);
        org.junit.Assert.assertNotNull(node49);
        org.junit.Assert.assertNull(jSType53);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNotNull(node71);
        org.junit.Assert.assertNotNull(nodeIterable72);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setLooseTypes(true);
        boolean boolean3 = compilerOptions0.reserveRawExports;
        boolean boolean4 = compilerOptions0.flowSensitiveInlineVariables;
        compilerOptions0.rewriteFunctionExpressions = true;
        java.lang.String str7 = compilerOptions0.unaliasableGlobals;
        boolean boolean8 = compilerOptions0.collapseProperties;
        java.lang.String[] strArray27 = new java.lang.String[] { "33", "JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}", "JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}", "TypeError", "com.google.javascript.rhino.EcmaError: TypeError: 4", "language version", "(// Input %num%)", "33", "com.google.javascript.rhino.EcmaError: TypeError: 4", "", "4", "hi!: hi!", "error reporter", "hi!: hi!", "(// Input %num%)", "Exceeded max number of code motion iterations: {0}", "hi!" };
        java.util.ArrayList<java.lang.String> strList28 = new java.util.ArrayList<java.lang.String>();
        boolean boolean29 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strList28, strArray27);
        compilerOptions0.setReplaceStringsConfiguration("Not declared as a type name", (java.util.List<java.lang.String>) strList28);
        com.google.javascript.jscomp.CompilerOptions.TracerMode tracerMode31 = com.google.javascript.jscomp.CompilerOptions.TracerMode.FAST;
        compilerOptions0.tracer = tracerMode31;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(strArray27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + tracerMode31 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TracerMode.FAST + "'", tracerMode31.equals(com.google.javascript.jscomp.CompilerOptions.TracerMode.FAST));
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        com.google.javascript.jscomp.CompilerOptions compilerOptions1 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions1.setLooseTypes(true);
        boolean boolean4 = compilerOptions1.collapseVariableDeclarations;
        compilerOptions1.moveFunctionDeclarations = false;
        boolean boolean7 = compilerOptions1.decomposeExpressions;
        boolean boolean8 = compilerOptions1.optimizeParameters;
        java.lang.String str9 = compilerOptions1.inputDelimiter;
        com.google.javascript.jscomp.ErrorFormat errorFormat10 = com.google.javascript.jscomp.ErrorFormat.LEGACY;
        java.lang.RuntimeException runtimeException11 = com.google.javascript.rhino.ScriptRuntime.undefWriteError((java.lang.Object) (short) 100, (java.lang.Object) str9, (java.lang.Object) errorFormat10);
        java.io.PrintStream printStream12 = null;
        com.google.javascript.jscomp.Compiler compiler13 = new com.google.javascript.jscomp.Compiler(printStream12);
        compiler13.disableThreads();
        com.google.javascript.jscomp.PerformanceTracker performanceTracker15 = compiler13.tracker;
        com.google.javascript.jscomp.MessageFormatter messageFormatter17 = errorFormat10.toFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler13, false);
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter18 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler13);
        try {
            boolean boolean19 = compiler13.hasErrors();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "// Input %num%" + "'", str9.equals("// Input %num%"));
        org.junit.Assert.assertNotNull(errorFormat10);
        org.junit.Assert.assertNotNull(runtimeException11);
        org.junit.Assert.assertNull(performanceTracker15);
        org.junit.Assert.assertNotNull(messageFormatter17);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setLooseTypes(true);
        compilerOptions0.checkSuspiciousCode = false;
        compilerOptions0.setCollapsePropertiesOnExternTypes(false);
        compilerOptions0.disableRuntimeTypeCheck();
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap8 = compilerOptions0.cssRenamingMap;
        compilerOptions0.markAsCompiled = false;
        org.junit.Assert.assertNull(cssRenamingMap8);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setLooseTypes(true);
        boolean boolean3 = compilerOptions0.reserveRawExports;
        compilerOptions0.extractPrototypeMemberDeclarations = false;
        com.google.javascript.jscomp.CheckLevel checkLevel6 = compilerOptions0.aggressiveVarCheck;
        boolean boolean7 = compilerOptions0.foldConstants;
        java.lang.String str8 = compilerOptions0.nameReferenceReportPath;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + checkLevel6 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel6.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(str8);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setLooseTypes(true);
        boolean boolean3 = compilerOptions0.collapseVariableDeclarations;
        boolean boolean4 = compilerOptions0.aliasKeywords;
        boolean boolean5 = compilerOptions0.generatePseudoNames;
        compilerOptions0.decomposeExpressions = true;
        com.google.javascript.jscomp.CompilerOptions compilerOptions8 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions8.setLooseTypes(true);
        boolean boolean11 = compilerOptions8.collapseVariableDeclarations;
        compilerOptions8.moveFunctionDeclarations = false;
        boolean boolean14 = compilerOptions8.decomposeExpressions;
        boolean boolean15 = compilerOptions8.optimizeParameters;
        java.lang.String str16 = compilerOptions8.inputDelimiter;
        java.lang.String[] strArray18 = new java.lang.String[] { "hi!" };
        java.util.LinkedHashSet<java.lang.String> strSet19 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean20 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet19, strArray18);
        compilerOptions8.stripTypes = strSet19;
        boolean boolean22 = compilerOptions8.inlineLocalVariables;
        com.google.javascript.jscomp.CompilerOptions.AliasTransformationHandler aliasTransformationHandler23 = compilerOptions8.getAliasTransformationHandler();
        compilerOptions0.setAliasTransformationHandler(aliasTransformationHandler23);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "// Input %num%" + "'", str16.equals("// Input %num%"));
        org.junit.Assert.assertNotNull(strArray18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(aliasTransformationHandler23);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.STRICT_MODULE_DEP_CHECK;
        com.google.javascript.jscomp.DiagnosticGroups.MISSING_PROPERTIES = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticGroups.CHECK_TYPES = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticGroups.CHECK_TYPES = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticGroups.CHECK_REGEXP = diagnosticGroup0;
        org.junit.Assert.assertNull(diagnosticGroup0);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        com.google.javascript.rhino.Node node2 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node4 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node6 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node8 = new com.google.javascript.rhino.Node((int) '4');
        node6.addChildrenToBack(node8);
        node2.addChildAfter(node4, node8);
        com.google.javascript.rhino.Node node12 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node14 = new com.google.javascript.rhino.Node((int) '4');
        node12.addChildrenToBack(node14);
        com.google.javascript.rhino.Node node16 = node2.copyInformationFromForTree(node14);
        com.google.javascript.jscomp.DiagnosticType diagnosticType17 = com.google.javascript.jscomp.Compiler.MOTION_ITERATIONS_ERROR;
        java.lang.String str18 = diagnosticType17.toString();
        java.lang.String[] strArray19 = null;
        com.google.javascript.jscomp.JSError jSError20 = com.google.javascript.jscomp.JSError.make("", node14, diagnosticType17, strArray19);
        java.lang.Object obj22 = null;
        node14.putProp(0, obj22);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertNotNull(diagnosticType17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}" + "'", str18.equals("JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}"));
        org.junit.Assert.assertNotNull(jSError20);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.STRICT_MODULE_DEP_CHECK;
        com.google.javascript.jscomp.DiagnosticGroups.MISSING_PROPERTIES = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticGroups.CHECK_TYPES = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticGroups.TWEAKS = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticGroups.STRICT_MODULE_DEP_CHECK = diagnosticGroup0;
        org.junit.Assert.assertNull(diagnosticGroup0);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        try {
            java.lang.String str1 = com.google.javascript.rhino.ScriptRuntime.getMessage0("INSTANCEOF\n");
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property INSTANCEOF\n");
        } catch (java.lang.RuntimeException e) {
        }
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setLooseTypes(true);
        boolean boolean3 = compilerOptions0.collapseVariableDeclarations;
        compilerOptions0.aliasExternals = true;
        compilerOptions0.checkMissingGetCssNameBlacklist = "(4)";
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        com.google.javascript.rhino.EcmaError ecmaError1 = com.google.javascript.rhino.ScriptRuntime.typeError("4");
        java.lang.String str2 = ecmaError1.getName();
        int int3 = ecmaError1.columnNumber();
        java.lang.String str4 = ecmaError1.details();
        org.junit.Assert.assertNotNull(ecmaError1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "TypeError" + "'", str2.equals("TypeError"));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "TypeError: 4" + "'", str4.equals("TypeError: 4"));
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        try {
            com.google.javascript.rhino.EcmaError ecmaError1 = com.google.javascript.rhino.ScriptRuntime.typeError0("DiagnosticGroup<externsValidation>");
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property DiagnosticGroup<externsValidation>");
        } catch (java.lang.RuntimeException e) {
        }
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        com.google.javascript.jscomp.CompilerOptions compilerOptions3 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions3.setLooseTypes(true);
        boolean boolean6 = compilerOptions3.collapseVariableDeclarations;
        compilerOptions3.recordFunctionInformation = false;
        compilerOptions3.optimizeReturns = false;
        com.google.javascript.jscomp.CompilerOptions compilerOptions11 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions11.setLooseTypes(true);
        compilerOptions11.convertToDottedProperties = false;
        com.google.javascript.jscomp.CheckLevel checkLevel16 = compilerOptions11.reportMissingOverride;
        compilerOptions3.aggressiveVarCheck = checkLevel16;
        com.google.javascript.jscomp.DiagnosticType diagnosticType20 = com.google.javascript.jscomp.DiagnosticType.disabled("Not declared as a type name", "DiagnosticGroup<externsValidation>");
        java.io.PrintStream printStream21 = null;
        com.google.javascript.jscomp.Compiler compiler22 = new com.google.javascript.jscomp.Compiler(printStream21);
        compiler22.disableThreads();
        com.google.javascript.jscomp.PerformanceTracker performanceTracker24 = compiler22.tracker;
        com.google.javascript.jscomp.NodeTraversal.Callback callback25 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal26 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler22, callback25);
        com.google.javascript.rhino.Node node28 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node30 = new com.google.javascript.rhino.Node((int) '4');
        node28.addChildrenToBack(node30);
        com.google.javascript.jscomp.DiagnosticType diagnosticType34 = com.google.javascript.jscomp.DiagnosticType.warning("hi!", "hi!");
        com.google.javascript.jscomp.DiagnosticType diagnosticType35 = com.google.javascript.jscomp.Compiler.MOTION_ITERATIONS_ERROR;
        int int36 = diagnosticType34.compareTo(diagnosticType35);
        java.lang.String[] strArray37 = com.google.javascript.rhino.ScriptRuntime.emptyStrings;
        com.google.javascript.jscomp.JSError jSError38 = nodeTraversal26.makeError(node30, diagnosticType34, strArray37);
        com.google.javascript.jscomp.JSError jSError39 = com.google.javascript.jscomp.JSError.make("com.google.javascript.rhino.EcmaError: TypeError: 4", (-1), 29, checkLevel16, diagnosticType20, strArray37);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + checkLevel16 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel16.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(diagnosticType20);
        org.junit.Assert.assertNull(performanceTracker24);
        org.junit.Assert.assertNotNull(diagnosticType34);
        org.junit.Assert.assertNotNull(diagnosticType35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 30 + "'", int36 == 30);
        org.junit.Assert.assertNotNull(strArray37);
        org.junit.Assert.assertNotNull(jSError38);
        org.junit.Assert.assertNotNull(jSError39);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        int int0 = com.google.javascript.rhino.Node.MEMBER_TYPE_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 32 + "'", int0 == 32);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setLooseTypes(true);
        boolean boolean3 = compilerOptions0.reserveRawExports;
        compilerOptions0.extractPrototypeMemberDeclarations = false;
        java.lang.String str6 = compilerOptions0.nameReferenceGraphPath;
        compilerOptions0.nameReferenceReportPath = "33";
        com.google.javascript.jscomp.CompilerOptions compilerOptions9 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions9.setLooseTypes(true);
        boolean boolean12 = compilerOptions9.reserveRawExports;
        compilerOptions9.extractPrototypeMemberDeclarations = false;
        java.lang.String str15 = compilerOptions9.nameReferenceGraphPath;
        compilerOptions9.computeFunctionSideEffects = true;
        com.google.javascript.jscomp.CompilerOptions compilerOptions18 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions18.setLooseTypes(true);
        compilerOptions18.convertToDottedProperties = false;
        com.google.javascript.jscomp.CheckLevel checkLevel23 = compilerOptions18.reportMissingOverride;
        compilerOptions9.brokenClosureRequiresLevel = checkLevel23;
        java.util.Set<java.lang.String> strSet25 = compilerOptions9.stripTypePrefixes;
        compilerOptions0.stripNameSuffixes = strSet25;
        java.util.Set<java.lang.String> strSet27 = compilerOptions0.aliasableStrings;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNull(str15);
        org.junit.Assert.assertTrue("'" + checkLevel23 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel23.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(strSet25);
        org.junit.Assert.assertNotNull(strSet27);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        com.google.javascript.rhino.Context context0 = new com.google.javascript.rhino.Context();
        com.google.javascript.rhino.ErrorReporter errorReporter1 = context0.getErrorReporter();
        com.google.javascript.rhino.Context context2 = com.google.javascript.rhino.Context.enter(context0);
        context2.setGeneratingSource(true);
        org.junit.Assert.assertNull(errorReporter1);
        org.junit.Assert.assertNotNull(context2);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setLooseTypes(true);
        compilerOptions0.checkSuspiciousCode = false;
        boolean boolean5 = compilerOptions0.convertToDottedProperties;
        compilerOptions0.recordFunctionInformation = false;
        com.google.javascript.jscomp.CodingConvention codingConvention8 = compilerOptions0.getCodingConvention();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(codingConvention8);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.common.collect.Multimap<com.google.javascript.jscomp.CustomPassExecutionTime, com.google.javascript.jscomp.CompilerPass> customPassExecutionTimeMultimap1 = compilerOptions0.customPasses;
        boolean boolean2 = compilerOptions0.exportTestFunctions;
        org.junit.Assert.assertNull(customPassExecutionTimeMultimap1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        com.google.javascript.rhino.Node node3 = new com.google.javascript.rhino.Node((int) (byte) 0, (int) '#', (int) (byte) -1);
        boolean boolean4 = node3.isLocalResultCall();
        boolean boolean5 = node3.isVarArgs();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeUnusedPrototypePropertiesInExterns = false;
        compilerOptions0.removeUnusedLocalVars = false;
        compilerOptions0.ignoreCajaProperties = false;
        com.google.javascript.jscomp.CodingConvention codingConvention7 = compilerOptions0.getCodingConvention();
        com.google.javascript.rhino.Context context8 = new com.google.javascript.rhino.Context();
        context8.setCompileFunctionsWithDynamicScope(false);
        java.util.Locale locale11 = context8.getLocale();
        com.google.javascript.rhino.Context context12 = new com.google.javascript.rhino.Context();
        context12.setCompileFunctionsWithDynamicScope(false);
        java.util.Locale locale15 = context12.getLocale();
        com.google.javascript.jscomp.CompilerOptions compilerOptions16 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions16.setLooseTypes(true);
        boolean boolean19 = compilerOptions16.collapseVariableDeclarations;
        boolean boolean20 = compilerOptions16.generateExports;
        com.google.javascript.jscomp.SourceMap.DetailLevel detailLevel21 = compilerOptions16.sourceMapDetailLevel;
        com.google.javascript.jscomp.CheckLevel checkLevel22 = null;
        compilerOptions16.brokenClosureRequiresLevel = checkLevel22;
        java.util.Set<java.lang.String> strSet24 = compilerOptions16.aliasableStrings;
        context8.putThreadLocal((java.lang.Object) locale15, (java.lang.Object) strSet24);
        compilerOptions0.stripNamePrefixes = strSet24;
        org.junit.Assert.assertNull(codingConvention7);
        org.junit.Assert.assertNotNull(locale11);
        org.junit.Assert.assertNotNull(locale15);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(detailLevel21);
        org.junit.Assert.assertNotNull(strSet24);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        compiler1.disableThreads();
        com.google.javascript.jscomp.PerformanceTracker performanceTracker3 = compiler1.tracker;
        com.google.javascript.jscomp.NodeTraversal.Callback callback4 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal5 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler1, callback4);
        com.google.javascript.rhino.Node node7 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node9 = new com.google.javascript.rhino.Node((int) '4');
        node7.addChildrenToBack(node9);
        com.google.javascript.jscomp.DiagnosticType diagnosticType13 = com.google.javascript.jscomp.DiagnosticType.warning("hi!", "hi!");
        com.google.javascript.jscomp.DiagnosticType diagnosticType14 = com.google.javascript.jscomp.Compiler.MOTION_ITERATIONS_ERROR;
        int int15 = diagnosticType13.compareTo(diagnosticType14);
        java.lang.String[] strArray16 = com.google.javascript.rhino.ScriptRuntime.emptyStrings;
        com.google.javascript.jscomp.JSError jSError17 = nodeTraversal5.makeError(node9, diagnosticType13, strArray16);
        com.google.javascript.rhino.Node node19 = new com.google.javascript.rhino.Node((int) (short) 1);
        com.google.javascript.rhino.Node node21 = new com.google.javascript.rhino.Node((int) (short) 1);
        node19.addChildrenToBack(node21);
        boolean boolean23 = node21.isSyntheticBlock();
        try {
            nodeTraversal5.traverse(node21);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: INTERNAL COMPILER ERROR.\nPlease report this problem.\nnull");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNull(performanceTracker3);
        org.junit.Assert.assertNotNull(diagnosticType13);
        org.junit.Assert.assertNotNull(diagnosticType14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 30 + "'", int15 == 30);
        org.junit.Assert.assertNotNull(strArray16);
        org.junit.Assert.assertNotNull(jSError17);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.common.collect.Multimap<com.google.javascript.jscomp.CustomPassExecutionTime, com.google.javascript.jscomp.CompilerPass> customPassExecutionTimeMultimap1 = compilerOptions0.customPasses;
        com.google.javascript.jscomp.CheckLevel checkLevel2 = compilerOptions0.checkGlobalNamesLevel;
        boolean boolean3 = compilerOptions0.isExternExportsEnabled();
        com.google.javascript.jscomp.CompilerOptions compilerOptions4 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions4.setLooseTypes(true);
        boolean boolean7 = compilerOptions4.reserveRawExports;
        compilerOptions4.extractPrototypeMemberDeclarations = false;
        boolean boolean10 = compilerOptions4.disambiguateProperties;
        com.google.javascript.jscomp.CheckLevel checkLevel11 = compilerOptions4.aggressiveVarCheck;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap12 = compilerOptions4.cssRenamingMap;
        com.google.javascript.jscomp.SourceMap.Format format13 = compilerOptions4.sourceMapFormat;
        boolean boolean14 = compilerOptions4.checkSuspiciousCode;
        com.google.javascript.jscomp.CheckLevel checkLevel15 = compilerOptions4.checkRequires;
        compilerOptions0.checkMethods = checkLevel15;
        com.google.javascript.jscomp.CompilerOptions.TweakProcessing tweakProcessing17 = compilerOptions0.getTweakProcessing();
        org.junit.Assert.assertNull(customPassExecutionTimeMultimap1);
        org.junit.Assert.assertTrue("'" + checkLevel2 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel2.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + checkLevel11 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel11.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNull(cssRenamingMap12);
        org.junit.Assert.assertNotNull(format13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + checkLevel15 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel15.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + tweakProcessing17 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TweakProcessing.OFF + "'", tweakProcessing17.equals(com.google.javascript.jscomp.CompilerOptions.TweakProcessing.OFF));
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeUnusedPrototypePropertiesInExterns = false;
        boolean boolean3 = compilerOptions0.markAsCompiled;
        compilerOptions0.setDefineToBooleanLiteral("", true);
        compilerOptions0.rewriteFunctionExpressions = true;
        com.google.javascript.rhino.Node node10 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node12 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node14 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node16 = new com.google.javascript.rhino.Node((int) '4');
        node14.addChildrenToBack(node16);
        node10.addChildAfter(node12, node16);
        boolean boolean19 = node12.wasEmptyNode();
        com.google.javascript.jscomp.CompilerOptions compilerOptions20 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions20.setLooseTypes(true);
        boolean boolean23 = compilerOptions20.reserveRawExports;
        compilerOptions20.extractPrototypeMemberDeclarations = false;
        java.lang.String str26 = compilerOptions20.nameReferenceGraphPath;
        compilerOptions20.nameReferenceReportPath = "33";
        com.google.javascript.jscomp.CompilerOptions compilerOptions29 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions29.setLooseTypes(true);
        boolean boolean32 = compilerOptions29.reserveRawExports;
        compilerOptions29.extractPrototypeMemberDeclarations = false;
        java.lang.String str35 = compilerOptions29.nameReferenceGraphPath;
        compilerOptions29.computeFunctionSideEffects = true;
        com.google.javascript.jscomp.CompilerOptions compilerOptions38 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions38.setLooseTypes(true);
        compilerOptions38.convertToDottedProperties = false;
        com.google.javascript.jscomp.CheckLevel checkLevel43 = compilerOptions38.reportMissingOverride;
        compilerOptions29.brokenClosureRequiresLevel = checkLevel43;
        java.util.Set<java.lang.String> strSet45 = compilerOptions29.stripTypePrefixes;
        compilerOptions20.stripNameSuffixes = strSet45;
        node12.setDirectives(strSet45);
        compilerOptions0.stripTypePrefixes = strSet45;
        com.google.javascript.jscomp.CheckLevel checkLevel49 = compilerOptions0.checkRequires;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNull(str26);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNull(str35);
        org.junit.Assert.assertTrue("'" + checkLevel43 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel43.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(strSet45);
        org.junit.Assert.assertTrue("'" + checkLevel49 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel49.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        int int0 = com.google.javascript.rhino.Node.CASES_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 13 + "'", int0 == 13);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.TWEAKS;
        com.google.javascript.jscomp.DiagnosticGroups.TWEAKS = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticType diagnosticType2 = com.google.javascript.jscomp.Compiler.MOTION_ITERATIONS_ERROR;
        com.google.javascript.jscomp.CheckLevel checkLevel3 = diagnosticType2.defaultLevel;
        try {
            boolean boolean4 = diagnosticGroup0.matches(diagnosticType2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(diagnosticGroup0);
        org.junit.Assert.assertNotNull(diagnosticType2);
        org.junit.Assert.assertTrue("'" + checkLevel3 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel3.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.EXTERNS_VALIDATION;
        java.lang.String str1 = diagnosticGroup0.toString();
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = null;
        com.google.javascript.jscomp.DiagnosticGroups.EXTERNS_VALIDATION = diagnosticGroup0;
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setLooseTypes(true);
        boolean boolean3 = compilerOptions0.reserveRawExports;
        compilerOptions0.extractPrototypeMemberDeclarations = false;
        java.lang.String str6 = compilerOptions0.nameReferenceGraphPath;
        compilerOptions0.computeFunctionSideEffects = true;
        boolean boolean9 = compilerOptions0.inlineLocalFunctions;
        boolean boolean10 = compilerOptions0.aliasAllStrings;
        compilerOptions0.setGenerateExports(false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = null;
        com.google.javascript.jscomp.DiagnosticGroups.UNKNOWN_DEFINES = diagnosticGroup0;
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromCode("hi!", "hi!");
        java.lang.String str3 = sourceFile2.toString();
        java.lang.String str5 = sourceFile2.getLine(34);
        java.io.Reader reader6 = sourceFile2.getCodeReader();
        java.io.Reader reader7 = sourceFile2.getCodeReader();
        org.junit.Assert.assertNotNull(sourceFile2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "hi!" + "'", str3.equals("hi!"));
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertNotNull(reader6);
        org.junit.Assert.assertNotNull(reader7);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.flowSensitiveInlineVariables = false;
        compilerOptions0.setDefineToBooleanLiteral("// Input %num%", false);
        com.google.javascript.rhino.Node node7 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node9 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node11 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node((int) '4');
        node11.addChildrenToBack(node13);
        node7.addChildAfter(node9, node13);
        com.google.javascript.rhino.Node node17 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node19 = new com.google.javascript.rhino.Node((int) '4');
        node17.addChildrenToBack(node19);
        com.google.javascript.rhino.Node node21 = node7.copyInformationFromForTree(node19);
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable22 = node21.siblings();
        java.lang.RuntimeException runtimeException23 = com.google.javascript.rhino.ScriptRuntime.notFunctionError((java.lang.Object) compilerOptions0, (java.lang.Object) node21);
        int int24 = node21.getSideEffectFlags();
        boolean boolean25 = node21.isOnlyModifiesThisCall();
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertNotNull(nodeIterable22);
        org.junit.Assert.assertNotNull(runtimeException23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        com.google.javascript.rhino.Node node1 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node3 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node5 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node7 = new com.google.javascript.rhino.Node((int) '4');
        node5.addChildrenToBack(node7);
        node1.addChildAfter(node3, node7);
        com.google.javascript.rhino.Node node11 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node((int) '4');
        node11.addChildrenToBack(node13);
        com.google.javascript.rhino.Node node15 = node1.copyInformationFromForTree(node13);
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable16 = node15.siblings();
        boolean boolean17 = node15.hasSideEffects();
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertNotNull(nodeIterable16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        com.google.javascript.rhino.Node node3 = new com.google.javascript.rhino.Node((int) (short) 1);
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newString("hi!");
        int int6 = node5.getCharno();
        com.google.javascript.rhino.Node node8 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node10 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node12 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node14 = new com.google.javascript.rhino.Node((int) '4');
        node12.addChildrenToBack(node14);
        node8.addChildAfter(node10, node14);
        com.google.javascript.rhino.Node node18 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node20 = new com.google.javascript.rhino.Node((int) '4');
        node18.addChildrenToBack(node20);
        com.google.javascript.rhino.Node node22 = node8.copyInformationFromForTree(node20);
        com.google.javascript.rhino.Node node23 = node8.cloneTree();
        com.google.javascript.rhino.Node node24 = node8.cloneTree();
        com.google.javascript.rhino.Node node26 = new com.google.javascript.rhino.Node((int) '4');
        node26.setLineno(36);
        com.google.javascript.rhino.Node[] nodeArray29 = new com.google.javascript.rhino.Node[] { node3, node5, node24, node26 };
        com.google.javascript.rhino.Node node32 = new com.google.javascript.rhino.Node(0, nodeArray29, 25, 14);
        try {
            com.google.javascript.rhino.Node node35 = new com.google.javascript.rhino.Node(8, nodeArray29, 150, 37);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: duplicate child");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertNotNull(nodeArray29);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention0 = new com.google.javascript.jscomp.DefaultCodingConvention();
        boolean boolean2 = defaultCodingConvention0.isExported("// Input %num%");
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry3 = null;
        com.google.javascript.jscomp.Scope scope4 = null;
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention5 = new com.google.javascript.jscomp.DefaultCodingConvention();
        java.lang.String str6 = defaultCodingConvention5.getDelegateSuperclassName();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry7 = null;
        com.google.javascript.jscomp.Scope scope8 = null;
        com.google.javascript.rhino.jstype.ObjectType[] objectTypeArray9 = new com.google.javascript.rhino.jstype.ObjectType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.ObjectType> objectTypeList10 = new java.util.ArrayList<com.google.javascript.rhino.jstype.ObjectType>();
        boolean boolean11 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.ObjectType>) objectTypeList10, objectTypeArray9);
        defaultCodingConvention5.defineDelegateProxyPrototypeProperties(jSTypeRegistry7, scope8, (java.util.List<com.google.javascript.rhino.jstype.ObjectType>) objectTypeList10);
        defaultCodingConvention0.defineDelegateProxyPrototypeProperties(jSTypeRegistry3, scope4, (java.util.List<com.google.javascript.rhino.jstype.ObjectType>) objectTypeList10);
        java.io.PrintStream printStream14 = null;
        com.google.javascript.jscomp.Compiler compiler15 = new com.google.javascript.jscomp.Compiler(printStream14);
        compiler15.disableThreads();
        com.google.javascript.jscomp.PerformanceTracker performanceTracker17 = compiler15.tracker;
        com.google.javascript.jscomp.NodeTraversal.Callback callback18 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal19 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler15, callback18);
        com.google.javascript.rhino.Node node21 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node23 = new com.google.javascript.rhino.Node((int) '4');
        node21.addChildrenToBack(node23);
        com.google.javascript.jscomp.DiagnosticType diagnosticType27 = com.google.javascript.jscomp.DiagnosticType.warning("hi!", "hi!");
        com.google.javascript.jscomp.DiagnosticType diagnosticType28 = com.google.javascript.jscomp.Compiler.MOTION_ITERATIONS_ERROR;
        int int29 = diagnosticType27.compareTo(diagnosticType28);
        java.lang.String[] strArray30 = com.google.javascript.rhino.ScriptRuntime.emptyStrings;
        com.google.javascript.jscomp.JSError jSError31 = nodeTraversal19.makeError(node23, diagnosticType27, strArray30);
        java.util.List<java.lang.String> strList32 = defaultCodingConvention0.identifyTypeDeclarationCall(node23);
        com.google.javascript.rhino.Node node34 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node36 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node38 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node40 = new com.google.javascript.rhino.Node((int) '4');
        node38.addChildrenToBack(node40);
        node34.addChildAfter(node36, node40);
        com.google.javascript.rhino.Node node44 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node46 = new com.google.javascript.rhino.Node((int) '4');
        node44.addChildrenToBack(node46);
        com.google.javascript.rhino.Node node48 = node34.copyInformationFromForTree(node46);
        com.google.javascript.jscomp.CodingConvention.SubclassRelationship subclassRelationship49 = defaultCodingConvention0.getClassesDefinedByCall(node48);
        node48.addSuppression("DiagnosticGroup<strictModuleDepCheck>");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNotNull(objectTypeArray9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNull(performanceTracker17);
        org.junit.Assert.assertNotNull(diagnosticType27);
        org.junit.Assert.assertNotNull(diagnosticType28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 30 + "'", int29 == 30);
        org.junit.Assert.assertNotNull(strArray30);
        org.junit.Assert.assertNotNull(jSError31);
        org.junit.Assert.assertNull(strList32);
        org.junit.Assert.assertNotNull(node48);
        org.junit.Assert.assertNull(subclassRelationship49);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention0 = new com.google.javascript.jscomp.DefaultCodingConvention();
        boolean boolean2 = defaultCodingConvention0.isExported("// Input %num%");
        boolean boolean4 = defaultCodingConvention0.isSuperClassReference("");
        com.google.javascript.rhino.Node node6 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node8 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node10 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node12 = new com.google.javascript.rhino.Node((int) '4');
        node10.addChildrenToBack(node12);
        node6.addChildAfter(node8, node12);
        boolean boolean15 = node8.wasEmptyNode();
        java.lang.String str16 = defaultCodingConvention0.identifyTypeDefAssign(node8);
        boolean boolean19 = defaultCodingConvention0.isExported("Exceeded max number of code motion iterations: {0}", false);
        java.lang.String str20 = defaultCodingConvention0.getGlobalObject();
        java.util.Collection<com.google.javascript.jscomp.CodingConvention.AssertionFunctionSpec> assertionFunctionSpecCollection21 = defaultCodingConvention0.getAssertionFunctions();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "window" + "'", str20.equals("window"));
        org.junit.Assert.assertNotNull(assertionFunctionSpecCollection21);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention0 = new com.google.javascript.jscomp.DefaultCodingConvention();
        boolean boolean2 = defaultCodingConvention0.isExported("// Input %num%");
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry3 = null;
        com.google.javascript.jscomp.Scope scope4 = null;
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention5 = new com.google.javascript.jscomp.DefaultCodingConvention();
        java.lang.String str6 = defaultCodingConvention5.getDelegateSuperclassName();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry7 = null;
        com.google.javascript.jscomp.Scope scope8 = null;
        com.google.javascript.rhino.jstype.ObjectType[] objectTypeArray9 = new com.google.javascript.rhino.jstype.ObjectType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.ObjectType> objectTypeList10 = new java.util.ArrayList<com.google.javascript.rhino.jstype.ObjectType>();
        boolean boolean11 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.ObjectType>) objectTypeList10, objectTypeArray9);
        defaultCodingConvention5.defineDelegateProxyPrototypeProperties(jSTypeRegistry7, scope8, (java.util.List<com.google.javascript.rhino.jstype.ObjectType>) objectTypeList10);
        defaultCodingConvention0.defineDelegateProxyPrototypeProperties(jSTypeRegistry3, scope4, (java.util.List<com.google.javascript.rhino.jstype.ObjectType>) objectTypeList10);
        java.io.PrintStream printStream14 = null;
        com.google.javascript.jscomp.Compiler compiler15 = new com.google.javascript.jscomp.Compiler(printStream14);
        compiler15.disableThreads();
        com.google.javascript.jscomp.PerformanceTracker performanceTracker17 = compiler15.tracker;
        com.google.javascript.jscomp.NodeTraversal.Callback callback18 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal19 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler15, callback18);
        com.google.javascript.rhino.Node node21 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node23 = new com.google.javascript.rhino.Node((int) '4');
        node21.addChildrenToBack(node23);
        com.google.javascript.jscomp.DiagnosticType diagnosticType27 = com.google.javascript.jscomp.DiagnosticType.warning("hi!", "hi!");
        com.google.javascript.jscomp.DiagnosticType diagnosticType28 = com.google.javascript.jscomp.Compiler.MOTION_ITERATIONS_ERROR;
        int int29 = diagnosticType27.compareTo(diagnosticType28);
        java.lang.String[] strArray30 = com.google.javascript.rhino.ScriptRuntime.emptyStrings;
        com.google.javascript.jscomp.JSError jSError31 = nodeTraversal19.makeError(node23, diagnosticType27, strArray30);
        java.util.List<java.lang.String> strList32 = defaultCodingConvention0.identifyTypeDeclarationCall(node23);
        com.google.javascript.rhino.Node node34 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node36 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node38 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node40 = new com.google.javascript.rhino.Node((int) '4');
        node38.addChildrenToBack(node40);
        node34.addChildAfter(node36, node40);
        com.google.javascript.rhino.Node node44 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node46 = new com.google.javascript.rhino.Node((int) '4');
        node44.addChildrenToBack(node46);
        com.google.javascript.rhino.Node node48 = node34.copyInformationFromForTree(node46);
        com.google.javascript.jscomp.CodingConvention.SubclassRelationship subclassRelationship49 = defaultCodingConvention0.getClassesDefinedByCall(node48);
        int int50 = node48.getChildCount();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNotNull(objectTypeArray9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNull(performanceTracker17);
        org.junit.Assert.assertNotNull(diagnosticType27);
        org.junit.Assert.assertNotNull(diagnosticType28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 30 + "'", int29 == 30);
        org.junit.Assert.assertNotNull(strArray30);
        org.junit.Assert.assertNotNull(jSError31);
        org.junit.Assert.assertNull(strList32);
        org.junit.Assert.assertNotNull(node48);
        org.junit.Assert.assertNull(subclassRelationship49);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 0 + "'", int50 == 0);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention0 = new com.google.javascript.jscomp.DefaultCodingConvention();
        boolean boolean2 = defaultCodingConvention0.isConstant("hi!");
        java.lang.String str3 = defaultCodingConvention0.getExportPropertyFunction();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newNumber(0.0d);
        org.junit.Assert.assertNotNull(node1);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        com.google.javascript.jscomp.DiagnosticType diagnosticType2 = com.google.javascript.jscomp.DiagnosticType.warning("hi!", "hi!");
        java.lang.String str3 = diagnosticType2.key;
        java.lang.String str4 = diagnosticType2.toString();
        java.text.MessageFormat messageFormat5 = diagnosticType2.format;
        java.lang.String str6 = diagnosticType2.key;
        org.junit.Assert.assertNotNull(diagnosticType2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "hi!" + "'", str3.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "hi!: hi!" + "'", str4.equals("hi!: hi!"));
        org.junit.Assert.assertNotNull(messageFormat5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        compiler1.disableThreads();
        com.google.javascript.jscomp.PerformanceTracker performanceTracker3 = compiler1.tracker;
        com.google.javascript.jscomp.NodeTraversal.Callback callback4 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal5 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler1, callback4);
        com.google.javascript.rhino.Node node7 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node9 = new com.google.javascript.rhino.Node((int) '4');
        node7.addChildrenToBack(node9);
        com.google.javascript.jscomp.DiagnosticType diagnosticType13 = com.google.javascript.jscomp.DiagnosticType.warning("hi!", "hi!");
        com.google.javascript.jscomp.DiagnosticType diagnosticType14 = com.google.javascript.jscomp.Compiler.MOTION_ITERATIONS_ERROR;
        int int15 = diagnosticType13.compareTo(diagnosticType14);
        java.lang.String[] strArray16 = com.google.javascript.rhino.ScriptRuntime.emptyStrings;
        com.google.javascript.jscomp.JSError jSError17 = nodeTraversal5.makeError(node9, diagnosticType13, strArray16);
        com.google.javascript.rhino.Node node18 = nodeTraversal5.getEnclosingFunction();
        boolean boolean19 = nodeTraversal5.hasScope();
        try {
            com.google.javascript.jscomp.CompilerInput compilerInput20 = nodeTraversal5.getInput();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(performanceTracker3);
        org.junit.Assert.assertNotNull(diagnosticType13);
        org.junit.Assert.assertNotNull(diagnosticType14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 30 + "'", int15 == 30);
        org.junit.Assert.assertNotNull(strArray16);
        org.junit.Assert.assertNotNull(jSError17);
        org.junit.Assert.assertNull(node18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention1 = new com.google.javascript.jscomp.DefaultCodingConvention();
        com.google.javascript.rhino.Node node3 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node5 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node7 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node9 = new com.google.javascript.rhino.Node((int) '4');
        node7.addChildrenToBack(node9);
        node3.addChildAfter(node5, node9);
        com.google.javascript.rhino.Node node12 = node3.getFirstChild();
        node3.putIntProp(45, 4095);
        com.google.javascript.jscomp.CodingConvention.SubclassRelationship subclassRelationship16 = defaultCodingConvention1.getClassesDefinedByCall(node3);
        com.google.javascript.rhino.Node node18 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node20 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node22 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node24 = new com.google.javascript.rhino.Node((int) '4');
        node22.addChildrenToBack(node24);
        node18.addChildAfter(node20, node24);
        com.google.javascript.rhino.Node node28 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node30 = new com.google.javascript.rhino.Node((int) '4');
        node28.addChildrenToBack(node30);
        com.google.javascript.rhino.Node node32 = node18.copyInformationFromForTree(node30);
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable33 = node32.siblings();
        com.google.javascript.rhino.Node node35 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node37 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node39 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node41 = new com.google.javascript.rhino.Node((int) '4');
        node39.addChildrenToBack(node41);
        node35.addChildAfter(node37, node41);
        com.google.javascript.rhino.Node node45 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node47 = new com.google.javascript.rhino.Node((int) '4');
        node45.addChildrenToBack(node47);
        com.google.javascript.rhino.Node node49 = node35.copyInformationFromForTree(node47);
        com.google.javascript.rhino.Node node51 = node35.getAncestor(1);
        com.google.javascript.rhino.Node node53 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node55 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node57 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node59 = new com.google.javascript.rhino.Node((int) '4');
        node57.addChildrenToBack(node59);
        node53.addChildAfter(node55, node59);
        com.google.javascript.rhino.Node node63 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node65 = new com.google.javascript.rhino.Node((int) '4');
        node63.addChildrenToBack(node65);
        com.google.javascript.rhino.Node node67 = node53.copyInformationFromForTree(node65);
        com.google.javascript.rhino.Node node69 = node53.getAncestor(1);
        node35.addChildToFront(node53);
        com.google.javascript.rhino.Node node71 = node35.getNext();
        com.google.javascript.rhino.Node node72 = node35.cloneTree();
        boolean boolean73 = node72.isQuotedString();
        com.google.javascript.rhino.Node node76 = new com.google.javascript.rhino.Node(3, node3, node32, node72, 27, 42);
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable77 = node76.siblings();
        org.junit.Assert.assertNull(node12);
        org.junit.Assert.assertNull(subclassRelationship16);
        org.junit.Assert.assertNotNull(node32);
        org.junit.Assert.assertNotNull(nodeIterable33);
        org.junit.Assert.assertNotNull(node49);
        org.junit.Assert.assertNull(node51);
        org.junit.Assert.assertNotNull(node67);
        org.junit.Assert.assertNull(node69);
        org.junit.Assert.assertNull(node71);
        org.junit.Assert.assertNotNull(node72);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
        org.junit.Assert.assertNotNull(nodeIterable77);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setLooseTypes(true);
        boolean boolean3 = compilerOptions0.reserveRawExports;
        compilerOptions0.extractPrototypeMemberDeclarations = false;
        boolean boolean6 = compilerOptions0.disambiguateProperties;
        com.google.javascript.jscomp.CheckLevel checkLevel7 = compilerOptions0.aggressiveVarCheck;
        compilerOptions0.labelRenaming = false;
        com.google.javascript.jscomp.CompilerOptions compilerOptions10 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions10.setLooseTypes(true);
        boolean boolean13 = compilerOptions10.reserveRawExports;
        boolean boolean14 = compilerOptions10.flowSensitiveInlineVariables;
        compilerOptions10.reserveRawExports = true;
        com.google.javascript.jscomp.CompilerOptions compilerOptions17 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions17.setLooseTypes(true);
        boolean boolean20 = compilerOptions17.reserveRawExports;
        compilerOptions17.extractPrototypeMemberDeclarations = false;
        com.google.javascript.jscomp.CheckLevel checkLevel23 = compilerOptions17.aggressiveVarCheck;
        compilerOptions10.checkProvides = checkLevel23;
        compilerOptions0.brokenClosureRequiresLevel = checkLevel23;
        boolean boolean26 = compilerOptions0.checkEs5Strict;
        com.google.javascript.jscomp.CompilerOptions compilerOptions27 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions27.setLooseTypes(true);
        boolean boolean30 = compilerOptions27.reserveRawExports;
        com.google.javascript.jscomp.CheckLevel checkLevel31 = null;
        compilerOptions27.checkUnreachableCode = checkLevel31;
        boolean boolean33 = compilerOptions27.devirtualizePrototypeMethods;
        compilerOptions27.setColorizeErrorOutput(true);
        compilerOptions27.setTweakToNumberLiteral("language version", (int) (byte) 10);
        compilerOptions27.checkControlStructures = false;
        com.google.javascript.jscomp.CompilerOptions compilerOptions41 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions41.setLooseTypes(true);
        boolean boolean44 = compilerOptions41.collapseVariableDeclarations;
        boolean boolean45 = compilerOptions41.generateExports;
        com.google.javascript.jscomp.SourceMap.DetailLevel detailLevel46 = compilerOptions41.sourceMapDetailLevel;
        com.google.javascript.jscomp.CheckLevel checkLevel47 = null;
        compilerOptions41.brokenClosureRequiresLevel = checkLevel47;
        java.util.Set<java.lang.String> strSet49 = compilerOptions41.aliasableStrings;
        byte[] byteArray55 = new byte[] { (byte) 0, (byte) 1, (byte) 10, (byte) 10, (byte) 1 };
        compilerOptions41.inputVariableMapSerialized = byteArray55;
        compilerOptions27.inputVariableMapSerialized = byteArray55;
        compilerOptions0.inputPropertyMapSerialized = byteArray55;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + checkLevel7 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel7.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + checkLevel23 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel23.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(detailLevel46);
        org.junit.Assert.assertNotNull(strSet49);
        org.junit.Assert.assertNotNull(byteArray55);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        com.google.javascript.rhino.Node.SideEffectFlags sideEffectFlags1 = new com.google.javascript.rhino.Node.SideEffectFlags(30);
        sideEffectFlags1.setMutatesGlobalState();
        sideEffectFlags1.setMutatesArguments();
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention0 = new com.google.javascript.jscomp.DefaultCodingConvention();
        boolean boolean2 = defaultCodingConvention0.isExported("// Input %num%");
        boolean boolean4 = defaultCodingConvention0.isSuperClassReference("");
        com.google.javascript.rhino.Node node6 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node8 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node10 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node12 = new com.google.javascript.rhino.Node((int) '4');
        node10.addChildrenToBack(node12);
        node6.addChildAfter(node8, node12);
        boolean boolean15 = node8.wasEmptyNode();
        java.lang.String str16 = defaultCodingConvention0.identifyTypeDefAssign(node8);
        boolean boolean19 = defaultCodingConvention0.isExported("Exceeded max number of code motion iterations: {0}", false);
        boolean boolean22 = defaultCodingConvention0.isExported("Not declared as a type name", false);
        com.google.javascript.rhino.Node node24 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node26 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node28 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node30 = new com.google.javascript.rhino.Node((int) '4');
        node28.addChildrenToBack(node30);
        node24.addChildAfter(node26, node30);
        com.google.javascript.rhino.Node node34 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node36 = new com.google.javascript.rhino.Node((int) '4');
        node34.addChildrenToBack(node36);
        com.google.javascript.rhino.Node node38 = node24.copyInformationFromForTree(node36);
        com.google.javascript.rhino.Node node40 = node24.getAncestor(1);
        com.google.javascript.rhino.Node node42 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node44 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node46 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node48 = new com.google.javascript.rhino.Node((int) '4');
        node46.addChildrenToBack(node48);
        node42.addChildAfter(node44, node48);
        com.google.javascript.rhino.Node node52 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node54 = new com.google.javascript.rhino.Node((int) '4');
        node52.addChildrenToBack(node54);
        com.google.javascript.rhino.Node node56 = node42.copyInformationFromForTree(node54);
        com.google.javascript.rhino.Node node58 = node42.getAncestor(1);
        node24.addChildToFront(node42);
        node24.setIsSyntheticBlock(true);
        com.google.javascript.jscomp.CodingConvention.SubclassRelationship subclassRelationship62 = defaultCodingConvention0.getClassesDefinedByCall(node24);
        try {
            com.google.javascript.rhino.Node node63 = node24.detachFromParent();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(node38);
        org.junit.Assert.assertNull(node40);
        org.junit.Assert.assertNotNull(node56);
        org.junit.Assert.assertNull(node58);
        org.junit.Assert.assertNull(subclassRelationship62);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setLooseTypes(true);
        boolean boolean3 = compilerOptions0.reserveRawExports;
        compilerOptions0.extractPrototypeMemberDeclarations = false;
        boolean boolean6 = compilerOptions0.exportTestFunctions;
        com.google.javascript.jscomp.CompilerOptions compilerOptions7 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions7.flowSensitiveInlineVariables = false;
        compilerOptions7.optimizeCalls = true;
        compilerOptions7.inlineFunctions = true;
        com.google.javascript.jscomp.CompilerOptions compilerOptions14 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions14.setLooseTypes(true);
        boolean boolean17 = compilerOptions14.collapseVariableDeclarations;
        compilerOptions14.recordFunctionInformation = false;
        compilerOptions14.convertToDottedProperties = false;
        compilerOptions14.collapseVariableDeclarations = false;
        com.google.javascript.jscomp.SourceMap.Format format24 = com.google.javascript.jscomp.SourceMap.Format.EXPERIMENTIAL;
        compilerOptions14.sourceMapFormat = format24;
        compilerOptions7.sourceMapFormat = format24;
        compilerOptions0.sourceMapFormat = format24;
        boolean boolean28 = compilerOptions0.checkSymbols;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(format24);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        com.google.javascript.rhino.Context context0 = new com.google.javascript.rhino.Context();
        context0.setGeneratingSource(true);
        java.lang.Object obj3 = context0.getDebuggerContextData();
        com.google.javascript.rhino.EcmaError ecmaError5 = com.google.javascript.rhino.ScriptRuntime.typeError("4");
        java.lang.String str6 = ecmaError5.getName();
        java.lang.String str7 = ecmaError5.lineSource();
        java.lang.String str8 = ecmaError5.toString();
        java.lang.String str9 = ecmaError5.lineSource();
        ecmaError5.initLineSource("com.google.javascript.rhino.EcmaError: TypeError: 4");
        context0.removeThreadLocal((java.lang.Object) ecmaError5);
        ecmaError5.initSourceName("33");
        org.junit.Assert.assertNull(obj3);
        org.junit.Assert.assertNotNull(ecmaError5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "TypeError" + "'", str6.equals("TypeError"));
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "com.google.javascript.rhino.EcmaError: TypeError: 4" + "'", str8.equals("com.google.javascript.rhino.EcmaError: TypeError: 4"));
        org.junit.Assert.assertNull(str9);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        java.util.List<com.google.javascript.rhino.Node> nodeList1 = null;
        com.google.javascript.rhino.Node node3 = new com.google.javascript.rhino.Node((int) '4');
        node3.setLineno(36);
        com.google.javascript.rhino.Node node6 = node3.cloneTree();
        try {
            com.google.javascript.rhino.Node node9 = com.google.javascript.jscomp.NodeUtil.newFunctionNode("(language version)", nodeList1, node6, (-2), (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node6);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        com.google.javascript.rhino.Node node2 = new com.google.javascript.rhino.Node((int) (short) 1);
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString("hi!");
        int int5 = node4.getCharno();
        com.google.javascript.rhino.Node node7 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node9 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node11 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node((int) '4');
        node11.addChildrenToBack(node13);
        node7.addChildAfter(node9, node13);
        com.google.javascript.rhino.Node node17 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node19 = new com.google.javascript.rhino.Node((int) '4');
        node17.addChildrenToBack(node19);
        com.google.javascript.rhino.Node node21 = node7.copyInformationFromForTree(node19);
        com.google.javascript.rhino.Node node22 = node7.cloneTree();
        com.google.javascript.rhino.Node node23 = node7.cloneTree();
        com.google.javascript.rhino.Node node25 = new com.google.javascript.rhino.Node((int) '4');
        node25.setLineno(36);
        com.google.javascript.rhino.Node[] nodeArray28 = new com.google.javascript.rhino.Node[] { node2, node4, node23, node25 };
        com.google.javascript.rhino.Node node31 = new com.google.javascript.rhino.Node(0, nodeArray28, 25, 14);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder32 = node31.new FileLevelJsDocBuilder();
        fileLevelJsDocBuilder32.append("// Input %num%");
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(nodeArray28);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        com.google.javascript.rhino.Context context0 = new com.google.javascript.rhino.Context();
        context0.setCompileFunctionsWithDynamicScope(false);
        java.util.Locale locale3 = context0.getLocale();
        boolean boolean5 = context0.isActivationNeeded("Not declared as a type name");
        com.google.javascript.rhino.ScriptRuntime.storeUint32Result(context0, 1L);
        int int8 = context0.getInstructionObserverThreshold();
        org.junit.Assert.assertNotNull(locale3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        com.google.javascript.rhino.Node node2 = new com.google.javascript.rhino.Node((int) '4');
        node2.setLineno(36);
        com.google.javascript.rhino.Node node5 = node2.getParent();
        int int6 = node2.getChildCount();
        com.google.javascript.jscomp.DiagnosticType diagnosticType9 = com.google.javascript.jscomp.DiagnosticType.warning("hi!", "hi!");
        java.lang.String str10 = diagnosticType9.key;
        java.lang.String str11 = diagnosticType9.toString();
        java.io.PrintStream printStream12 = null;
        com.google.javascript.jscomp.Compiler compiler13 = new com.google.javascript.jscomp.Compiler(printStream12);
        compiler13.disableThreads();
        com.google.javascript.jscomp.PerformanceTracker performanceTracker15 = compiler13.tracker;
        com.google.javascript.jscomp.NodeTraversal.Callback callback16 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal17 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler13, callback16);
        com.google.javascript.rhino.Node node19 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node21 = new com.google.javascript.rhino.Node((int) '4');
        node19.addChildrenToBack(node21);
        com.google.javascript.jscomp.DiagnosticType diagnosticType25 = com.google.javascript.jscomp.DiagnosticType.warning("hi!", "hi!");
        com.google.javascript.jscomp.DiagnosticType diagnosticType26 = com.google.javascript.jscomp.Compiler.MOTION_ITERATIONS_ERROR;
        int int27 = diagnosticType25.compareTo(diagnosticType26);
        java.lang.String[] strArray28 = com.google.javascript.rhino.ScriptRuntime.emptyStrings;
        com.google.javascript.jscomp.JSError jSError29 = nodeTraversal17.makeError(node21, diagnosticType25, strArray28);
        com.google.javascript.jscomp.JSError jSError30 = com.google.javascript.jscomp.JSError.make("language version", node2, diagnosticType9, strArray28);
        com.google.javascript.jscomp.CompilerOptions compilerOptions31 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions31.setLooseTypes(true);
        boolean boolean34 = compilerOptions31.reserveRawExports;
        compilerOptions31.extractPrototypeMemberDeclarations = false;
        com.google.javascript.jscomp.CheckLevel checkLevel37 = compilerOptions31.aggressiveVarCheck;
        boolean boolean38 = compilerOptions31.foldConstants;
        com.google.javascript.jscomp.DiagnosticType diagnosticType39 = com.google.javascript.jscomp.Compiler.MOTION_ITERATIONS_ERROR;
        com.google.javascript.jscomp.CheckLevel checkLevel40 = diagnosticType39.defaultLevel;
        compilerOptions31.checkFunctions = checkLevel40;
        diagnosticType9.level = checkLevel40;
        org.junit.Assert.assertNull(node5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(diagnosticType9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "hi!" + "'", str10.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "hi!: hi!" + "'", str11.equals("hi!: hi!"));
        org.junit.Assert.assertNull(performanceTracker15);
        org.junit.Assert.assertNotNull(diagnosticType25);
        org.junit.Assert.assertNotNull(diagnosticType26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 30 + "'", int27 == 30);
        org.junit.Assert.assertNotNull(strArray28);
        org.junit.Assert.assertNotNull(jSError29);
        org.junit.Assert.assertNotNull(jSError30);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + checkLevel37 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel37.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(diagnosticType39);
        org.junit.Assert.assertTrue("'" + checkLevel40 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel40.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setLooseTypes(true);
        boolean boolean3 = compilerOptions0.collapseVariableDeclarations;
        compilerOptions0.setManageClosureDependencies(false);
        compilerOptions0.extractPrototypeMemberDeclarations = true;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setProcessObjectPropertyString(false);
        compilerOptions0.markNoSideEffectCalls = false;
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setLooseTypes(true);
        boolean boolean3 = compilerOptions0.reserveRawExports;
        boolean boolean4 = compilerOptions0.flowSensitiveInlineVariables;
        compilerOptions0.reserveRawExports = true;
        compilerOptions0.inferTypesInGlobalScope = false;
        compilerOptions0.generatePseudoNames = true;
        boolean boolean11 = compilerOptions0.inlineLocalFunctions;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        com.google.javascript.rhino.Context context0 = new com.google.javascript.rhino.Context();
        context0.setGeneratingSource(true);
        boolean boolean3 = context0.isGeneratingDebug();
        context0.setInstructionObserverThreshold(140);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.STRICT_MODULE_DEP_CHECK;
        com.google.javascript.jscomp.DiagnosticGroups.TYPE_INVALIDATION = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticGroups.GLOBAL_THIS = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticGroups.INTERNET_EXPLORER_CHECKS = diagnosticGroup0;
        org.junit.Assert.assertNull(diagnosticGroup0);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setLooseTypes(true);
        boolean boolean3 = compilerOptions0.collapseVariableDeclarations;
        compilerOptions0.moveFunctionDeclarations = false;
        boolean boolean6 = compilerOptions0.decomposeExpressions;
        compilerOptions0.recordFunctionInformation = true;
        com.google.javascript.jscomp.CompilerOptions.TweakProcessing tweakProcessing9 = compilerOptions0.getTweakProcessing();
        compilerOptions0.setGenerateExports(true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + tweakProcessing9 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TweakProcessing.OFF + "'", tweakProcessing9.equals(com.google.javascript.jscomp.CompilerOptions.TweakProcessing.OFF));
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setLooseTypes(true);
        boolean boolean3 = compilerOptions0.reserveRawExports;
        com.google.javascript.jscomp.CheckLevel checkLevel4 = null;
        compilerOptions0.checkUnreachableCode = checkLevel4;
        com.google.javascript.jscomp.MessageBundle messageBundle6 = compilerOptions0.messageBundle;
        java.lang.String str7 = compilerOptions0.sourceMapOutputPath;
        compilerOptions0.aliasKeywords = true;
        boolean boolean10 = compilerOptions0.generateExports;
        com.google.javascript.jscomp.CheckLevel checkLevel11 = com.google.javascript.jscomp.CheckLevel.WARNING;
        compilerOptions0.reportUnknownTypes = checkLevel11;
        boolean boolean13 = compilerOptions0.checkTypedPropertyCalls;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(messageBundle6);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + checkLevel11 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel11.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setLooseTypes(true);
        boolean boolean3 = compilerOptions0.reserveRawExports;
        compilerOptions0.extractPrototypeMemberDeclarations = false;
        java.lang.String str6 = compilerOptions0.nameReferenceGraphPath;
        compilerOptions0.nameReferenceReportPath = "33";
        com.google.javascript.jscomp.CompilerOptions compilerOptions9 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions9.setLooseTypes(true);
        boolean boolean12 = compilerOptions9.reserveRawExports;
        compilerOptions9.extractPrototypeMemberDeclarations = false;
        java.lang.String str15 = compilerOptions9.nameReferenceGraphPath;
        compilerOptions9.computeFunctionSideEffects = true;
        com.google.javascript.jscomp.CompilerOptions compilerOptions18 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions18.setLooseTypes(true);
        compilerOptions18.convertToDottedProperties = false;
        com.google.javascript.jscomp.CheckLevel checkLevel23 = compilerOptions18.reportMissingOverride;
        compilerOptions9.brokenClosureRequiresLevel = checkLevel23;
        java.util.Set<java.lang.String> strSet25 = compilerOptions9.stripTypePrefixes;
        compilerOptions0.stripNameSuffixes = strSet25;
        boolean boolean27 = compilerOptions0.disambiguateProperties;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNull(str15);
        org.junit.Assert.assertTrue("'" + checkLevel23 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel23.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(strSet25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        com.google.javascript.jscomp.SourceAst sourceAst0 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(sourceAst0, "", false);
        com.google.javascript.jscomp.JSModule jSModule4 = null;
        compilerInput3.setModule(jSModule4);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.STRICT_MODULE_DEP_CHECK;
        com.google.javascript.jscomp.DiagnosticGroups.MISSING_PROPERTIES = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticGroups.CHECK_TYPES = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticGroups.UNDEFINED_VARIABLES = diagnosticGroup0;
        org.junit.Assert.assertNull(diagnosticGroup0);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setLooseTypes(true);
        compilerOptions0.renamePrefix = "hi!";
        compilerOptions0.checkControlStructures = false;
        boolean boolean7 = compilerOptions0.removeTryCatchFinally;
        boolean boolean8 = compilerOptions0.markAsCompiled;
        boolean boolean9 = compilerOptions0.removeTryCatchFinally;
        boolean boolean10 = compilerOptions0.shouldColorizeErrorOutput();
        compilerOptions0.setManageClosureDependencies(false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        com.google.javascript.rhino.Context context0 = new com.google.javascript.rhino.Context();
        context0.setGeneratingSource(true);
        com.google.javascript.jscomp.CompilerOptions.TracerMode tracerMode3 = com.google.javascript.jscomp.CompilerOptions.TracerMode.FAST;
        context0.removeThreadLocal((java.lang.Object) tracerMode3);
        boolean boolean5 = context0.isGeneratingSource();
        com.google.javascript.rhino.Context context6 = new com.google.javascript.rhino.Context();
        context6.setGeneratingSource(true);
        com.google.javascript.jscomp.CompilerOptions.TracerMode tracerMode9 = com.google.javascript.jscomp.CompilerOptions.TracerMode.FAST;
        context6.removeThreadLocal((java.lang.Object) tracerMode9);
        boolean boolean11 = context6.isGeneratingSource();
        java.util.Locale locale12 = context6.getLocale();
        java.util.Locale locale13 = context0.setLocale(locale12);
        int int14 = context0.getLanguageVersion();
        org.junit.Assert.assertTrue("'" + tracerMode3 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TracerMode.FAST + "'", tracerMode3.equals(com.google.javascript.jscomp.CompilerOptions.TracerMode.FAST));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + tracerMode9 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TracerMode.FAST + "'", tracerMode9.equals(com.google.javascript.jscomp.CompilerOptions.TracerMode.FAST));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(locale12);
        org.junit.Assert.assertNull(locale13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setLooseTypes(true);
        compilerOptions0.sourceMapOutputPath = "DiagnosticGroup<externsValidation>";
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        java.io.InputStream inputStream1 = null;
        try {
            com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromInputStream("33", inputStream1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        com.google.javascript.rhino.Node node2 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node4 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node6 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node8 = new com.google.javascript.rhino.Node((int) '4');
        node6.addChildrenToBack(node8);
        node2.addChildAfter(node4, node8);
        com.google.javascript.rhino.Node node11 = node8.getParent();
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node15 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node17 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node19 = new com.google.javascript.rhino.Node((int) '4');
        node17.addChildrenToBack(node19);
        node13.addChildAfter(node15, node19);
        com.google.javascript.rhino.Node node23 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node25 = new com.google.javascript.rhino.Node((int) '4');
        node23.addChildrenToBack(node25);
        com.google.javascript.rhino.Node node27 = node13.copyInformationFromForTree(node25);
        com.google.javascript.rhino.Node node28 = node27.getLastChild();
        com.google.javascript.rhino.Node node30 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node32 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node34 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node36 = new com.google.javascript.rhino.Node((int) '4');
        node34.addChildrenToBack(node36);
        node30.addChildAfter(node32, node36);
        com.google.javascript.rhino.Node node40 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node42 = new com.google.javascript.rhino.Node((int) '4');
        node40.addChildrenToBack(node42);
        com.google.javascript.rhino.Node node44 = node30.copyInformationFromForTree(node42);
        node27.addChildToBack(node30);
        com.google.javascript.rhino.Node node46 = null;
        try {
            com.google.javascript.rhino.Node node47 = new com.google.javascript.rhino.Node(49, node8, node30, node46);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertNotNull(node27);
        org.junit.Assert.assertNull(node28);
        org.junit.Assert.assertNotNull(node44);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        com.google.javascript.jscomp.CompilerOptions compilerOptions1 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions1.setLooseTypes(true);
        boolean boolean4 = compilerOptions1.reserveRawExports;
        com.google.javascript.jscomp.CheckLevel checkLevel5 = null;
        compilerOptions1.checkUnreachableCode = checkLevel5;
        com.google.javascript.jscomp.CheckLevel checkLevel7 = compilerOptions1.reportUnknownTypes;
        java.util.Set<java.lang.String> strSet8 = compilerOptions1.stripTypePrefixes;
        try {
            java.lang.String str9 = com.google.javascript.rhino.ScriptRuntime.getMessage1("error reporter", (java.lang.Object) compilerOptions1);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property error reporter");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + checkLevel7 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel7.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(strSet8);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setLooseTypes(true);
        boolean boolean3 = compilerOptions0.reserveRawExports;
        compilerOptions0.extractPrototypeMemberDeclarations = false;
        boolean boolean6 = compilerOptions0.disambiguateProperties;
        compilerOptions0.setDefineToDoubleLiteral("Not declared as a type name", 100.0d);
        compilerOptions0.lineBreak = true;
        com.google.javascript.jscomp.CompilerOptions compilerOptions12 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions12.flowSensitiveInlineVariables = false;
        compilerOptions12.optimizeCalls = true;
        compilerOptions12.setPropertyAffinity(true);
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy19 = null;
        compilerOptions12.propertyRenaming = propertyRenamingPolicy19;
        com.google.javascript.jscomp.CheckLevel checkLevel21 = compilerOptions12.reportUnknownTypes;
        compilerOptions0.reportUnknownTypes = checkLevel21;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + checkLevel21 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel21.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setLooseTypes(true);
        boolean boolean3 = compilerOptions0.reserveRawExports;
        boolean boolean4 = compilerOptions0.flowSensitiveInlineVariables;
        compilerOptions0.reserveRawExports = true;
        compilerOptions0.inferTypesInGlobalScope = false;
        compilerOptions0.setProcessObjectPropertyString(false);
        boolean boolean11 = compilerOptions0.disambiguateProperties;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setLooseTypes(true);
        compilerOptions0.checkSuspiciousCode = false;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap5 = null;
        compilerOptions0.cssRenamingMap = cssRenamingMap5;
        compilerOptions0.aliasableGlobals = "hi!: hi!";
        boolean boolean9 = compilerOptions0.removeTryCatchFinally;
        com.google.javascript.jscomp.CheckLevel checkLevel10 = compilerOptions0.checkMissingGetCssNameLevel;
        compilerOptions0.setLooseTypes(false);
        compilerOptions0.computeFunctionSideEffects = true;
        compilerOptions0.reportPath = "DiagnosticGroup<strictModuleDepCheck>";
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + checkLevel10 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel10.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        try {
            com.google.javascript.rhino.Context.checkLanguageVersion((int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Bad language version: 10");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray0 = new com.google.javascript.jscomp.WarningsGuard[] {};
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard1 = new com.google.javascript.jscomp.ComposeWarningsGuard(warningsGuardArray0);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup2 = com.google.javascript.jscomp.DiagnosticGroups.STRICT_MODULE_DEP_CHECK;
        com.google.javascript.jscomp.DiagnosticGroups.MISSING_PROPERTIES = diagnosticGroup2;
        com.google.javascript.jscomp.DiagnosticGroups.CHECK_TYPES = diagnosticGroup2;
        com.google.javascript.jscomp.DiagnosticGroups.TWEAKS = diagnosticGroup2;
        try {
            boolean boolean6 = composeWarningsGuard1.disables(diagnosticGroup2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(warningsGuardArray0);
        org.junit.Assert.assertNull(diagnosticGroup2);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        com.google.javascript.rhino.Context context0 = new com.google.javascript.rhino.Context();
        context0.setGeneratingSource(true);
        com.google.javascript.jscomp.CompilerOptions.TracerMode tracerMode3 = com.google.javascript.jscomp.CompilerOptions.TracerMode.FAST;
        context0.removeThreadLocal((java.lang.Object) tracerMode3);
        boolean boolean5 = context0.isGeneratingSource();
        java.lang.String str6 = context0.getImplementationVersion();
        org.junit.Assert.assertTrue("'" + tracerMode3 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TracerMode.FAST + "'", tracerMode3.equals(com.google.javascript.jscomp.CompilerOptions.TracerMode.FAST));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "@IMPLEMENTATION.VERSION@" + "'", str6.equals("@IMPLEMENTATION.VERSION@"));
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setLooseTypes(true);
        boolean boolean3 = compilerOptions0.collapseVariableDeclarations;
        compilerOptions0.moveFunctionDeclarations = false;
        boolean boolean6 = compilerOptions0.decomposeExpressions;
        boolean boolean7 = compilerOptions0.optimizeParameters;
        java.lang.String str8 = compilerOptions0.inputDelimiter;
        java.lang.String[] strArray10 = new java.lang.String[] { "hi!" };
        java.util.LinkedHashSet<java.lang.String> strSet11 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean12 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet11, strArray10);
        compilerOptions0.stripTypes = strSet11;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy14 = compilerOptions0.variableRenaming;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "// Input %num%" + "'", str8.equals("// Input %num%"));
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy14 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.OFF + "'", variableRenamingPolicy14.equals(com.google.javascript.jscomp.VariableRenamingPolicy.OFF));
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        com.google.javascript.jscomp.SourceMap.Format format0 = com.google.javascript.jscomp.SourceMap.Format.LEGACY;
        org.junit.Assert.assertNotNull(format0);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setLooseTypes(true);
        boolean boolean3 = compilerOptions0.collapseVariableDeclarations;
        compilerOptions0.recordFunctionInformation = false;
        compilerOptions0.optimizeReturns = false;
        com.google.javascript.jscomp.CompilerOptions compilerOptions8 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions8.setLooseTypes(true);
        compilerOptions8.convertToDottedProperties = false;
        com.google.javascript.jscomp.CheckLevel checkLevel13 = compilerOptions8.reportMissingOverride;
        compilerOptions0.aggressiveVarCheck = checkLevel13;
        com.google.javascript.jscomp.CheckLevel checkLevel15 = compilerOptions0.checkRequires;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + checkLevel13 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel13.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + checkLevel15 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel15.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setLooseTypes(true);
        boolean boolean3 = compilerOptions0.collapseVariableDeclarations;
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention4 = new com.google.javascript.jscomp.DefaultCodingConvention();
        boolean boolean6 = defaultCodingConvention4.isExported("// Input %num%");
        boolean boolean8 = defaultCodingConvention4.isSuperClassReference("");
        com.google.javascript.rhino.Node node10 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node12 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node14 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node16 = new com.google.javascript.rhino.Node((int) '4');
        node14.addChildrenToBack(node16);
        node10.addChildAfter(node12, node16);
        boolean boolean19 = node12.wasEmptyNode();
        java.lang.String str20 = defaultCodingConvention4.identifyTypeDefAssign(node12);
        boolean boolean23 = defaultCodingConvention4.isExported("Exceeded max number of code motion iterations: {0}", false);
        boolean boolean26 = defaultCodingConvention4.isExported("Not declared as a type name", false);
        compilerOptions0.setCodingConvention((com.google.javascript.jscomp.CodingConvention) defaultCodingConvention4);
        com.google.javascript.rhino.Node node29 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node31 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node33 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node35 = new com.google.javascript.rhino.Node((int) '4');
        node33.addChildrenToBack(node35);
        node29.addChildAfter(node31, node35);
        com.google.javascript.rhino.Node node39 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node41 = new com.google.javascript.rhino.Node((int) '4');
        node39.addChildrenToBack(node41);
        com.google.javascript.rhino.Node node43 = node29.copyInformationFromForTree(node41);
        com.google.javascript.rhino.Node node45 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node46 = node29.copyInformationFromForTree(node45);
        java.util.Set<java.lang.String> strSet47 = node46.getDirectives();
        com.google.javascript.jscomp.CodingConvention.SubclassRelationship subclassRelationship48 = defaultCodingConvention4.getClassesDefinedByCall(node46);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNull(str20);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(node43);
        org.junit.Assert.assertNotNull(node46);
        org.junit.Assert.assertNull(strSet47);
        org.junit.Assert.assertNull(subclassRelationship48);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setLooseTypes(true);
        boolean boolean3 = compilerOptions0.reserveRawExports;
        com.google.javascript.jscomp.CheckLevel checkLevel4 = null;
        compilerOptions0.checkUnreachableCode = checkLevel4;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy6 = null;
        compilerOptions0.variableRenaming = variableRenamingPolicy6;
        java.lang.Class<?> wildcardClass8 = compilerOptions0.getClass();
        compilerOptions0.setGenerateExports(true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(wildcardClass8);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        com.google.javascript.rhino.EvaluatorException evaluatorException1 = new com.google.javascript.rhino.EvaluatorException("// Input %num%");
        try {
            evaluatorException1.initLineNumber(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test214");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setLooseTypes(true);
        com.google.javascript.jscomp.CompilerOptions compilerOptions3 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions3.setLooseTypes(true);
        compilerOptions3.convertToDottedProperties = false;
        com.google.javascript.jscomp.CheckLevel checkLevel8 = compilerOptions3.reportMissingOverride;
        com.google.javascript.jscomp.CodingConvention codingConvention9 = compilerOptions3.getCodingConvention();
        boolean boolean10 = compilerOptions3.devirtualizePrototypeMethods;
        compilerOptions3.removeDeadCode = true;
        com.google.javascript.jscomp.CheckLevel checkLevel13 = compilerOptions3.checkMissingReturn;
        compilerOptions0.checkShadowVars = checkLevel13;
        org.junit.Assert.assertTrue("'" + checkLevel8 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel8.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNull(codingConvention9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + checkLevel13 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel13.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test215");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setLooseTypes(true);
        boolean boolean3 = compilerOptions0.collapseVariableDeclarations;
        compilerOptions0.moveFunctionDeclarations = false;
        boolean boolean6 = compilerOptions0.decomposeExpressions;
        boolean boolean7 = compilerOptions0.optimizeParameters;
        java.lang.String str8 = compilerOptions0.inputDelimiter;
        java.lang.String[] strArray10 = new java.lang.String[] { "hi!" };
        java.util.LinkedHashSet<java.lang.String> strSet11 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean12 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet11, strArray10);
        compilerOptions0.stripTypes = strSet11;
        boolean boolean14 = compilerOptions0.inlineLocalVariables;
        boolean boolean15 = compilerOptions0.removeEmptyFunctions;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "// Input %num%" + "'", str8.equals("// Input %num%"));
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setLooseTypes(true);
        boolean boolean3 = compilerOptions0.reserveRawExports;
        boolean boolean4 = compilerOptions0.flowSensitiveInlineVariables;
        boolean boolean5 = compilerOptions0.ambiguateProperties;
        boolean boolean6 = compilerOptions0.checkSymbols;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test217");
        com.google.javascript.jscomp.JSModule[] jSModuleArray0 = new com.google.javascript.jscomp.JSModule[] {};
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph1 = new com.google.javascript.jscomp.JSModuleGraph(jSModuleArray0);
        com.google.javascript.jscomp.JSModule jSModule2 = null;
        com.google.javascript.jscomp.JSModule jSModule3 = null;
        com.google.javascript.jscomp.JSModule jSModule4 = jSModuleGraph1.getDeepestCommonDependencyInclusive(jSModule2, jSModule3);
        com.google.javascript.jscomp.JSModule jSModule5 = null;
        com.google.javascript.jscomp.JSModule jSModule6 = null;
        com.google.javascript.jscomp.JSModule jSModule7 = jSModuleGraph1.getDeepestCommonDependencyInclusive(jSModule5, jSModule6);
        com.google.javascript.jscomp.JSModule jSModule8 = null;
        com.google.javascript.jscomp.JSModule jSModule9 = null;
        com.google.javascript.jscomp.JSModule jSModule10 = jSModuleGraph1.getDeepestCommonDependencyInclusive(jSModule8, jSModule9);
        org.junit.Assert.assertNotNull(jSModuleArray0);
        org.junit.Assert.assertNull(jSModule4);
        org.junit.Assert.assertNull(jSModule7);
        org.junit.Assert.assertNull(jSModule10);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test218");
        int int0 = com.google.javascript.rhino.Node.LOCAL_BLOCK_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + (-3) + "'", int0 == (-3));
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test219");
        com.google.javascript.jscomp.SourceAst sourceAst0 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(sourceAst0, "", false);
        boolean boolean4 = compilerInput3.isExtern();
        java.lang.String str5 = compilerInput3.getName();
        try {
            java.lang.String str6 = compilerInput3.getCode();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test220");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile4 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        java.io.Reader reader5 = jSSourceFile4.getCodeReader();
        com.google.javascript.jscomp.JSModule[] jSModuleArray6 = new com.google.javascript.jscomp.JSModule[] {};
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph7 = new com.google.javascript.jscomp.JSModuleGraph(jSModuleArray6);
        com.google.javascript.jscomp.CompilerOptions compilerOptions8 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions8.setLooseTypes(true);
        boolean boolean11 = compilerOptions8.collapseVariableDeclarations;
        compilerOptions8.moveFunctionDeclarations = false;
        boolean boolean14 = compilerOptions8.decomposeExpressions;
        com.google.javascript.jscomp.CheckLevel checkLevel15 = compilerOptions8.checkMissingGetCssNameLevel;
        com.google.javascript.jscomp.Result result16 = compiler1.compile(jSSourceFile4, jSModuleArray6, compilerOptions8);
        com.google.javascript.jscomp.CompilerOptions.AliasTransformationHandler aliasTransformationHandler17 = null;
        compilerOptions8.setAliasTransformationHandler(aliasTransformationHandler17);
        compilerOptions8.setNameAnonymousFunctionsOnly(false);
        org.junit.Assert.assertNotNull(jSSourceFile4);
        org.junit.Assert.assertNotNull(reader5);
        org.junit.Assert.assertNotNull(jSModuleArray6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + checkLevel15 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel15.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(result16);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        compiler1.disableThreads();
        com.google.javascript.jscomp.PerformanceTracker performanceTracker3 = compiler1.tracker;
        compiler1.disableThreads();
        try {
            com.google.javascript.jscomp.JSError[] jSErrorArray5 = compiler1.getMessages();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(performanceTracker3);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        com.google.javascript.jscomp.JSModule[] jSModuleArray0 = new com.google.javascript.jscomp.JSModule[] {};
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph1 = new com.google.javascript.jscomp.JSModuleGraph(jSModuleArray0);
        com.google.javascript.jscomp.JSModule jSModule2 = null;
        com.google.javascript.jscomp.JSModule jSModule3 = null;
        com.google.javascript.jscomp.JSModule jSModule4 = jSModuleGraph1.getDeepestCommonDependencyInclusive(jSModule2, jSModule3);
        com.google.javascript.jscomp.JSModule jSModule5 = null;
        com.google.javascript.jscomp.JSModule jSModule6 = null;
        com.google.javascript.jscomp.JSModule jSModule7 = jSModuleGraph1.getDeepestCommonDependencyInclusive(jSModule5, jSModule6);
        jSModuleGraph1.coalesceDuplicateFiles();
        com.google.javascript.jscomp.JSModule jSModule9 = null;
        com.google.javascript.jscomp.JSModule jSModule10 = null;
        com.google.javascript.jscomp.JSModule jSModule11 = jSModuleGraph1.getDeepestCommonDependencyInclusive(jSModule9, jSModule10);
        org.junit.Assert.assertNotNull(jSModuleArray0);
        org.junit.Assert.assertNull(jSModule4);
        org.junit.Assert.assertNull(jSModule7);
        org.junit.Assert.assertNull(jSModule11);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test223");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setLooseTypes(true);
        boolean boolean3 = compilerOptions0.collapseVariableDeclarations;
        compilerOptions0.recordFunctionInformation = false;
        compilerOptions0.convertToDottedProperties = false;
        compilerOptions0.collapseVariableDeclarations = false;
        compilerOptions0.disableRuntimeTypeCheck();
        byte[] byteArray13 = new byte[] { (byte) 10, (byte) 10 };
        compilerOptions0.inputPropertyMapSerialized = byteArray13;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(byteArray13);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test224");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setLooseTypes(true);
        boolean boolean3 = compilerOptions0.collapseVariableDeclarations;
        java.lang.String str4 = compilerOptions0.syntheticBlockStartMarker;
        java.lang.String str5 = compilerOptions0.aliasStringsBlacklist;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test225");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setLooseTypes(true);
        boolean boolean3 = compilerOptions0.collapseVariableDeclarations;
        compilerOptions0.recordFunctionInformation = false;
        compilerOptions0.convertToDottedProperties = false;
        compilerOptions0.checkUnusedPropertiesEarly = false;
        boolean boolean10 = compilerOptions0.crossModuleMethodMotion;
        compilerOptions0.checkTypedPropertyCalls = false;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test226");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setLooseTypes(true);
        compilerOptions0.checkSuspiciousCode = false;
        compilerOptions0.setCollapsePropertiesOnExternTypes(false);
        com.google.javascript.jscomp.CheckLevel checkLevel7 = compilerOptions0.checkMethods;
        compilerOptions0.removeUnusedVars = false;
        java.lang.String str10 = compilerOptions0.instrumentationTemplate;
        org.junit.Assert.assertTrue("'" + checkLevel7 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel7.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNull(str10);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test227");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setLooseTypes(true);
        boolean boolean3 = compilerOptions0.reserveRawExports;
        boolean boolean4 = compilerOptions0.flowSensitiveInlineVariables;
        compilerOptions0.checkTypedPropertyCalls = false;
        boolean boolean7 = compilerOptions0.rewriteFunctionExpressions;
        compilerOptions0.optimizeArgumentsArray = false;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test228");
        com.google.javascript.rhino.Node node1 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node3 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node5 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node7 = new com.google.javascript.rhino.Node((int) '4');
        node5.addChildrenToBack(node7);
        node1.addChildAfter(node3, node7);
        boolean boolean10 = node3.isSyntheticBlock();
        int int11 = node3.getCharno();
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test229");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setLooseTypes(true);
        boolean boolean3 = compilerOptions0.reserveRawExports;
        com.google.javascript.jscomp.CheckLevel checkLevel4 = null;
        compilerOptions0.checkUnreachableCode = checkLevel4;
        com.google.javascript.jscomp.CheckLevel checkLevel6 = compilerOptions0.reportUnknownTypes;
        java.util.Set<java.lang.String> strSet7 = null;
        compilerOptions0.stripNameSuffixes = strSet7;
        compilerOptions0.lineLengthThreshold(6);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + checkLevel6 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel6.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test230");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setLooseTypes(true);
        boolean boolean3 = compilerOptions0.reserveRawExports;
        compilerOptions0.extractPrototypeMemberDeclarations = false;
        compilerOptions0.checkMissingGetCssNameBlacklist = "4";
        compilerOptions0.setTweakToStringLiteral("", "com.google.javascript.rhino.EcmaError: TypeError: 4");
        java.util.Set<java.lang.String> strSet11 = compilerOptions0.stripNameSuffixes;
        java.util.Map<java.lang.String, com.google.javascript.rhino.Node> strMap12 = compilerOptions0.getDefineReplacements();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(strSet11);
        org.junit.Assert.assertNotNull(strMap12);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test231");
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention0 = new com.google.javascript.jscomp.DefaultCodingConvention();
        boolean boolean2 = defaultCodingConvention0.isExported("// Input %num%");
        boolean boolean4 = defaultCodingConvention0.isSuperClassReference("");
        com.google.javascript.rhino.Node node6 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node8 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node10 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node12 = new com.google.javascript.rhino.Node((int) '4');
        node10.addChildrenToBack(node12);
        node6.addChildAfter(node8, node12);
        boolean boolean15 = node8.wasEmptyNode();
        java.lang.String str16 = defaultCodingConvention0.identifyTypeDefAssign(node8);
        boolean boolean19 = defaultCodingConvention0.isExported("Exceeded max number of code motion iterations: {0}", false);
        java.lang.String str20 = defaultCodingConvention0.getGlobalObject();
        java.lang.String str21 = defaultCodingConvention0.getDelegateSuperclassName();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "window" + "'", str20.equals("window"));
        org.junit.Assert.assertNull(str21);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test232");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setLooseTypes(true);
        boolean boolean3 = compilerOptions0.reserveRawExports;
        com.google.javascript.jscomp.CheckLevel checkLevel4 = null;
        compilerOptions0.checkUnreachableCode = checkLevel4;
        boolean boolean6 = compilerOptions0.devirtualizePrototypeMethods;
        compilerOptions0.setColorizeErrorOutput(true);
        compilerOptions0.setTweakToNumberLiteral("language version", (int) (byte) 10);
        java.lang.Object obj12 = compilerOptions0.clone();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(obj12);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test233");
        java.lang.Object[] objArray0 = com.google.javascript.rhino.ScriptRuntime.emptyArgs;
        org.junit.Assert.assertNotNull(objArray0);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test234");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        java.io.PrintStream printStream2 = null;
        com.google.javascript.jscomp.Compiler compiler3 = new com.google.javascript.jscomp.Compiler(printStream2);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile6 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        java.io.Reader reader7 = jSSourceFile6.getCodeReader();
        com.google.javascript.jscomp.JSModule[] jSModuleArray8 = new com.google.javascript.jscomp.JSModule[] {};
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph9 = new com.google.javascript.jscomp.JSModuleGraph(jSModuleArray8);
        com.google.javascript.jscomp.CompilerOptions compilerOptions10 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions10.setLooseTypes(true);
        boolean boolean13 = compilerOptions10.collapseVariableDeclarations;
        compilerOptions10.moveFunctionDeclarations = false;
        boolean boolean16 = compilerOptions10.decomposeExpressions;
        com.google.javascript.jscomp.CheckLevel checkLevel17 = compilerOptions10.checkMissingGetCssNameLevel;
        com.google.javascript.jscomp.Result result18 = compiler3.compile(jSSourceFile6, jSModuleArray8, compilerOptions10);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile21 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile24 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        java.io.Reader reader25 = jSSourceFile24.getCodeReader();
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray26 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile6, jSSourceFile21, jSSourceFile24 };
        java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList27 = new java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile>();
        boolean boolean28 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList27, jSSourceFileArray26);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile31 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray32 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile31 };
        java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList33 = new java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile>();
        boolean boolean34 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList33, jSSourceFileArray32);
        com.google.javascript.jscomp.CompilerOptions compilerOptions35 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions35.setLooseTypes(true);
        boolean boolean38 = compilerOptions35.reserveRawExports;
        compilerOptions35.extractPrototypeMemberDeclarations = false;
        java.lang.String str41 = compilerOptions35.nameReferenceGraphPath;
        compilerOptions35.setSummaryDetailLevel(0);
        com.google.javascript.jscomp.Result result44 = compiler1.compile((java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList27, (java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList33, compilerOptions35);
        int int45 = compiler1.getWarningCount();
        com.google.javascript.jscomp.PerformanceTracker performanceTracker46 = compiler1.tracker;
        boolean boolean47 = compiler1.isTypeCheckingEnabled();
        com.google.javascript.jscomp.ErrorManager errorManager48 = compiler1.getErrorManager();
        org.junit.Assert.assertNotNull(jSSourceFile6);
        org.junit.Assert.assertNotNull(reader7);
        org.junit.Assert.assertNotNull(jSModuleArray8);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + checkLevel17 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel17.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(result18);
        org.junit.Assert.assertNotNull(jSSourceFile21);
        org.junit.Assert.assertNotNull(jSSourceFile24);
        org.junit.Assert.assertNotNull(reader25);
        org.junit.Assert.assertNotNull(jSSourceFileArray26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(jSSourceFile31);
        org.junit.Assert.assertNotNull(jSSourceFileArray32);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNull(str41);
        org.junit.Assert.assertNotNull(result44);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 0 + "'", int45 == 0);
        org.junit.Assert.assertNull(performanceTracker46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(errorManager48);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test235");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setLooseTypes(true);
        boolean boolean3 = compilerOptions0.reserveRawExports;
        com.google.javascript.jscomp.CheckLevel checkLevel4 = null;
        compilerOptions0.checkUnreachableCode = checkLevel4;
        com.google.javascript.jscomp.MessageBundle messageBundle6 = compilerOptions0.messageBundle;
        java.lang.String str7 = compilerOptions0.sourceMapOutputPath;
        compilerOptions0.inlineConstantVars = false;
        com.google.javascript.jscomp.CompilerOptions compilerOptions10 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions10.setLooseTypes(true);
        boolean boolean13 = compilerOptions10.collapseVariableDeclarations;
        compilerOptions10.moveFunctionDeclarations = false;
        boolean boolean16 = compilerOptions10.decomposeExpressions;
        boolean boolean17 = compilerOptions10.optimizeParameters;
        java.lang.String str18 = compilerOptions10.inputDelimiter;
        java.lang.String[] strArray20 = new java.lang.String[] { "hi!" };
        java.util.LinkedHashSet<java.lang.String> strSet21 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean22 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet21, strArray20);
        compilerOptions10.stripTypes = strSet21;
        compilerOptions0.setIdGenerators((java.util.Set<java.lang.String>) strSet21);
        boolean boolean25 = compilerOptions0.optimizeCalls;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(messageBundle6);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "// Input %num%" + "'", str18.equals("// Input %num%"));
        org.junit.Assert.assertNotNull(strArray20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test236");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile4 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        java.io.Reader reader5 = jSSourceFile4.getCodeReader();
        com.google.javascript.jscomp.JSModule[] jSModuleArray6 = new com.google.javascript.jscomp.JSModule[] {};
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph7 = new com.google.javascript.jscomp.JSModuleGraph(jSModuleArray6);
        com.google.javascript.jscomp.CompilerOptions compilerOptions8 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions8.setLooseTypes(true);
        boolean boolean11 = compilerOptions8.collapseVariableDeclarations;
        compilerOptions8.moveFunctionDeclarations = false;
        boolean boolean14 = compilerOptions8.decomposeExpressions;
        com.google.javascript.jscomp.CheckLevel checkLevel15 = compilerOptions8.checkMissingGetCssNameLevel;
        com.google.javascript.jscomp.Result result16 = compiler1.compile(jSSourceFile4, jSModuleArray6, compilerOptions8);
        com.google.javascript.jscomp.Result result17 = compiler1.getResult();
        boolean boolean18 = compiler1.hasErrors();
        com.google.javascript.jscomp.SourceFile.Generator generator20 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile21 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("JSC_OPTIMIZE_LOOP_ERROR. Exceeded max number of code motion iterations: {0} at (unknown source) line (unknown line) : (unknown column)", generator20);
        com.google.javascript.jscomp.SourceFile.Generator generator23 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile24 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("JSC_OPTIMIZE_LOOP_ERROR. Exceeded max number of code motion iterations: {0} at (unknown source) line (unknown line) : (unknown column)", generator23);
        com.google.javascript.jscomp.CompilerOptions compilerOptions25 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions25.setLooseTypes(true);
        boolean boolean28 = compilerOptions25.reserveRawExports;
        compilerOptions25.extractPrototypeMemberDeclarations = false;
        java.lang.String str31 = compilerOptions25.nameReferenceGraphPath;
        compilerOptions25.computeFunctionSideEffects = true;
        com.google.javascript.jscomp.CompilerOptions compilerOptions34 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions34.setLooseTypes(true);
        compilerOptions34.convertToDottedProperties = false;
        com.google.javascript.jscomp.CheckLevel checkLevel39 = compilerOptions34.reportMissingOverride;
        compilerOptions25.brokenClosureRequiresLevel = checkLevel39;
        java.util.Set<java.lang.String> strSet41 = compilerOptions25.stripTypePrefixes;
        compilerOptions25.optimizeReturns = true;
        com.google.javascript.jscomp.Result result44 = compiler1.compile(jSSourceFile21, jSSourceFile24, compilerOptions25);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile46 = com.google.javascript.jscomp.JSSourceFile.fromFile("(): error reporter");
        java.lang.String str47 = jSSourceFile46.toString();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile50 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        java.io.Reader reader51 = jSSourceFile50.getCodeReader();
        com.google.javascript.jscomp.CompilerOptions compilerOptions52 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions52.setLooseTypes(true);
        boolean boolean55 = compilerOptions52.reserveRawExports;
        boolean boolean56 = compilerOptions52.flowSensitiveInlineVariables;
        compilerOptions52.reserveRawExports = true;
        compilerOptions52.inferTypesInGlobalScope = false;
        boolean boolean61 = compilerOptions52.markNoSideEffectCalls;
        com.google.javascript.jscomp.CheckLevel checkLevel62 = compilerOptions52.checkProvides;
        com.google.javascript.jscomp.Result result63 = compiler1.compile(jSSourceFile46, jSSourceFile50, compilerOptions52);
        java.lang.String str64 = jSSourceFile50.toString();
        org.junit.Assert.assertNotNull(jSSourceFile4);
        org.junit.Assert.assertNotNull(reader5);
        org.junit.Assert.assertNotNull(jSModuleArray6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + checkLevel15 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel15.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(result16);
        org.junit.Assert.assertNotNull(result17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(jSSourceFile21);
        org.junit.Assert.assertNotNull(jSSourceFile24);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNull(str31);
        org.junit.Assert.assertTrue("'" + checkLevel39 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel39.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(strSet41);
        org.junit.Assert.assertNotNull(result44);
        org.junit.Assert.assertNotNull(jSSourceFile46);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "(): error reporter" + "'", str47.equals("(): error reporter"));
        org.junit.Assert.assertNotNull(jSSourceFile50);
        org.junit.Assert.assertNotNull(reader51);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertTrue("'" + checkLevel62 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel62.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(result63);
        org.junit.Assert.assertTrue("'" + str64 + "' != '" + "hi!" + "'", str64.equals("hi!"));
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test237");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        compiler1.disableThreads();
        com.google.javascript.jscomp.PerformanceTracker performanceTracker3 = compiler1.tracker;
        com.google.javascript.jscomp.ErrorManager errorManager4 = compiler1.getErrorManager();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile5 = null;
        com.google.javascript.jscomp.JSModule[] jSModuleArray6 = new com.google.javascript.jscomp.JSModule[] {};
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph7 = new com.google.javascript.jscomp.JSModuleGraph(jSModuleArray6);
        java.io.PrintStream printStream8 = null;
        com.google.javascript.jscomp.Compiler compiler9 = new com.google.javascript.jscomp.Compiler(printStream8);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile12 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        java.io.Reader reader13 = jSSourceFile12.getCodeReader();
        com.google.javascript.jscomp.JSModule[] jSModuleArray14 = new com.google.javascript.jscomp.JSModule[] {};
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph15 = new com.google.javascript.jscomp.JSModuleGraph(jSModuleArray14);
        com.google.javascript.jscomp.CompilerOptions compilerOptions16 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions16.setLooseTypes(true);
        boolean boolean19 = compilerOptions16.collapseVariableDeclarations;
        compilerOptions16.moveFunctionDeclarations = false;
        boolean boolean22 = compilerOptions16.decomposeExpressions;
        com.google.javascript.jscomp.CheckLevel checkLevel23 = compilerOptions16.checkMissingGetCssNameLevel;
        com.google.javascript.jscomp.Result result24 = compiler9.compile(jSSourceFile12, jSModuleArray14, compilerOptions16);
        try {
            com.google.javascript.jscomp.Result result25 = compiler1.compile(jSSourceFile5, jSModuleArray6, compilerOptions16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(performanceTracker3);
        org.junit.Assert.assertNotNull(errorManager4);
        org.junit.Assert.assertNotNull(jSModuleArray6);
        org.junit.Assert.assertNotNull(jSSourceFile12);
        org.junit.Assert.assertNotNull(reader13);
        org.junit.Assert.assertNotNull(jSModuleArray14);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + checkLevel23 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel23.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(result24);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test238");
        com.google.javascript.jscomp.SourceAst sourceAst0 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(sourceAst0, "", false);
        boolean boolean4 = compilerInput3.isExtern();
        java.lang.String str5 = compilerInput3.getName();
        com.google.javascript.jscomp.JSModule jSModule6 = compilerInput3.getModule();
        com.google.javascript.jscomp.AbstractCompiler abstractCompiler7 = null;
        try {
            com.google.javascript.rhino.Node node8 = compilerInput3.getAstRoot(abstractCompiler7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertNull(jSModule6);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test239");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setLooseTypes(true);
        boolean boolean3 = compilerOptions0.reserveRawExports;
        com.google.javascript.jscomp.CheckLevel checkLevel4 = null;
        compilerOptions0.checkUnreachableCode = checkLevel4;
        com.google.javascript.jscomp.MessageBundle messageBundle6 = compilerOptions0.messageBundle;
        java.lang.String str7 = compilerOptions0.sourceMapOutputPath;
        compilerOptions0.aliasKeywords = true;
        boolean boolean10 = compilerOptions0.checkUnusedPropertiesEarly;
        com.google.javascript.jscomp.CheckLevel checkLevel11 = compilerOptions0.checkProvides;
        compilerOptions0.deadAssignmentElimination = false;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(messageBundle6);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + checkLevel11 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel11.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test240");
        com.google.javascript.rhino.Context context0 = new com.google.javascript.rhino.Context();
        com.google.javascript.rhino.ErrorReporter errorReporter1 = context0.getErrorReporter();
        com.google.javascript.jscomp.CompilerOptions compilerOptions2 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions2.setLooseTypes(true);
        compilerOptions2.checkSuspiciousCode = false;
        compilerOptions2.disambiguateProperties = true;
        java.util.Map<java.lang.String, com.google.javascript.rhino.Node> strMap9 = compilerOptions2.getDefineReplacements();
        compilerOptions2.checkDuplicateMessages = false;
        context0.removeThreadLocal((java.lang.Object) compilerOptions2);
        boolean boolean14 = context0.isActivationNeeded("TypeError: 4");
        org.junit.Assert.assertNull(errorReporter1);
        org.junit.Assert.assertNotNull(strMap9);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test241");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node3 = new com.google.javascript.rhino.Node((int) (short) 1);
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newString("hi!");
        int int6 = node5.getCharno();
        com.google.javascript.rhino.Node node8 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node10 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node12 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node14 = new com.google.javascript.rhino.Node((int) '4');
        node12.addChildrenToBack(node14);
        node8.addChildAfter(node10, node14);
        com.google.javascript.rhino.Node node18 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node20 = new com.google.javascript.rhino.Node((int) '4');
        node18.addChildrenToBack(node20);
        com.google.javascript.rhino.Node node22 = node8.copyInformationFromForTree(node20);
        com.google.javascript.rhino.Node node23 = node8.cloneTree();
        com.google.javascript.rhino.Node node24 = node8.cloneTree();
        com.google.javascript.rhino.Node node26 = new com.google.javascript.rhino.Node((int) '4');
        node26.setLineno(36);
        com.google.javascript.rhino.Node[] nodeArray29 = new com.google.javascript.rhino.Node[] { node3, node5, node24, node26 };
        com.google.javascript.rhino.Node node32 = new com.google.javascript.rhino.Node(0, nodeArray29, 25, 14);
        com.google.javascript.rhino.Node node34 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node36 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node38 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node40 = new com.google.javascript.rhino.Node((int) '4');
        node38.addChildrenToBack(node40);
        node34.addChildAfter(node36, node40);
        com.google.javascript.rhino.Node node44 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node46 = new com.google.javascript.rhino.Node((int) '4');
        node44.addChildrenToBack(node46);
        com.google.javascript.rhino.Node node48 = node34.copyInformationFromForTree(node46);
        com.google.javascript.rhino.Node node49 = node34.cloneTree();
        com.google.javascript.rhino.Node node50 = node34.cloneTree();
        java.lang.String str51 = closureCodingConvention0.extractClassNameIfRequire(node32, node34);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder52 = node34.getJsDocBuilderForNode();
        fileLevelJsDocBuilder52.append("TypeError");
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertNotNull(nodeArray29);
        org.junit.Assert.assertNotNull(node48);
        org.junit.Assert.assertNotNull(node49);
        org.junit.Assert.assertNotNull(node50);
        org.junit.Assert.assertNull(str51);
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder52);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test242");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setLooseTypes(true);
        boolean boolean3 = compilerOptions0.collapseVariableDeclarations;
        boolean boolean4 = compilerOptions0.aliasKeywords;
        boolean boolean5 = compilerOptions0.disambiguateProperties;
        compilerOptions0.printInputDelimiter = true;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test243");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setLooseTypes(true);
        compilerOptions0.convertToDottedProperties = false;
        com.google.javascript.jscomp.CheckLevel checkLevel5 = compilerOptions0.reportUnknownTypes;
        boolean boolean6 = compilerOptions0.optimizeReturns;
        compilerOptions0.convertToDottedProperties = true;
        com.google.javascript.jscomp.CompilerOptions compilerOptions9 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions9.setLooseTypes(true);
        boolean boolean12 = compilerOptions9.collapseVariableDeclarations;
        compilerOptions9.moveFunctionDeclarations = false;
        boolean boolean15 = compilerOptions9.decomposeExpressions;
        com.google.javascript.jscomp.CheckLevel checkLevel16 = compilerOptions9.checkMissingGetCssNameLevel;
        compilerOptions0.checkFunctions = checkLevel16;
        org.junit.Assert.assertTrue("'" + checkLevel5 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel5.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + checkLevel16 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel16.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test244");
        com.google.javascript.rhino.Node node1 = new com.google.javascript.rhino.Node(100);
        try {
            int int3 = node1.getExistingIntProp(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: FAILED ASSERTION");
        } catch (java.lang.IllegalStateException e) {
        }
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test245");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.CHECK_VARIABLES;
        com.google.javascript.jscomp.DiagnosticGroups.NON_STANDARD_JSDOC = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticGroups.MISSING_PROPERTIES = diagnosticGroup0;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test246");
        com.google.javascript.jscomp.CompilerOptions compilerOptions1 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions1.setLooseTypes(true);
        boolean boolean4 = compilerOptions1.collapseVariableDeclarations;
        compilerOptions1.moveFunctionDeclarations = false;
        boolean boolean7 = compilerOptions1.decomposeExpressions;
        boolean boolean8 = compilerOptions1.optimizeParameters;
        java.lang.String str9 = compilerOptions1.inputDelimiter;
        com.google.javascript.jscomp.ErrorFormat errorFormat10 = com.google.javascript.jscomp.ErrorFormat.LEGACY;
        java.lang.RuntimeException runtimeException11 = com.google.javascript.rhino.ScriptRuntime.undefWriteError((java.lang.Object) (short) 100, (java.lang.Object) str9, (java.lang.Object) errorFormat10);
        java.io.PrintStream printStream12 = null;
        com.google.javascript.jscomp.Compiler compiler13 = new com.google.javascript.jscomp.Compiler(printStream12);
        compiler13.disableThreads();
        com.google.javascript.jscomp.PerformanceTracker performanceTracker15 = compiler13.tracker;
        com.google.javascript.jscomp.MessageFormatter messageFormatter17 = errorFormat10.toFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler13, false);
        com.google.javascript.rhino.Node node18 = compiler13.getRoot();
        com.google.javascript.jscomp.SourceMap sourceMap19 = compiler13.getSourceMap();
        com.google.javascript.jscomp.PerformanceTracker performanceTracker20 = compiler13.tracker;
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "// Input %num%" + "'", str9.equals("// Input %num%"));
        org.junit.Assert.assertNotNull(errorFormat10);
        org.junit.Assert.assertNotNull(runtimeException11);
        org.junit.Assert.assertNull(performanceTracker15);
        org.junit.Assert.assertNotNull(messageFormatter17);
        org.junit.Assert.assertNull(node18);
        org.junit.Assert.assertNull(sourceMap19);
        org.junit.Assert.assertNull(performanceTracker20);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test247");
        com.google.javascript.jscomp.CompilerOptions compilerOptions1 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions1.setLooseTypes(true);
        compilerOptions1.checkSuspiciousCode = false;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap6 = null;
        compilerOptions1.cssRenamingMap = cssRenamingMap6;
        compilerOptions1.aliasableGlobals = "hi!: hi!";
        com.google.javascript.jscomp.CompilerOptions.TracerMode tracerMode10 = compilerOptions1.tracer;
        boolean boolean11 = compilerOptions1.inlineFunctions;
        com.google.javascript.jscomp.CheckLevel checkLevel12 = compilerOptions1.checkMissingGetCssNameLevel;
        com.google.javascript.jscomp.CompilerOptions compilerOptions13 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions13.setLooseTypes(true);
        compilerOptions13.checkSuspiciousCode = false;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap18 = null;
        compilerOptions13.cssRenamingMap = cssRenamingMap18;
        compilerOptions13.aliasableGlobals = "hi!: hi!";
        com.google.javascript.jscomp.CompilerOptions.TracerMode tracerMode22 = compilerOptions13.tracer;
        boolean boolean23 = compilerOptions13.inlineFunctions;
        com.google.javascript.jscomp.CheckLevel checkLevel24 = compilerOptions13.checkMissingGetCssNameLevel;
        compilerOptions1.checkMissingReturn = checkLevel24;
        try {
            java.lang.String str26 = com.google.javascript.rhino.ScriptRuntime.getMessage1("// Input %num%", (java.lang.Object) checkLevel24);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property // Input %num%");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertTrue("'" + tracerMode10 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TracerMode.OFF + "'", tracerMode10.equals(com.google.javascript.jscomp.CompilerOptions.TracerMode.OFF));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + checkLevel12 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel12.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + tracerMode22 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TracerMode.OFF + "'", tracerMode22.equals(com.google.javascript.jscomp.CompilerOptions.TracerMode.OFF));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + checkLevel24 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel24.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test248");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setLooseTypes(true);
        boolean boolean3 = compilerOptions0.reserveRawExports;
        com.google.javascript.jscomp.CheckLevel checkLevel4 = null;
        compilerOptions0.checkUnreachableCode = checkLevel4;
        com.google.javascript.jscomp.MessageBundle messageBundle6 = compilerOptions0.messageBundle;
        java.lang.String str7 = compilerOptions0.sourceMapOutputPath;
        compilerOptions0.enableExternExports(true);
        boolean boolean10 = compilerOptions0.markNoSideEffectCalls;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(messageBundle6);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test249");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.ACCESS_CONTROLS;
        com.google.javascript.jscomp.DiagnosticGroups.MISSING_PROPERTIES = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticGroups.CHECK_REGEXP = diagnosticGroup0;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test250");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setLooseTypes(true);
        boolean boolean3 = compilerOptions0.reserveRawExports;
        com.google.javascript.jscomp.CheckLevel checkLevel4 = null;
        compilerOptions0.checkUnreachableCode = checkLevel4;
        com.google.javascript.jscomp.CheckLevel checkLevel6 = compilerOptions0.reportUnknownTypes;
        java.util.Set<java.lang.String> strSet7 = compilerOptions0.stripTypePrefixes;
        boolean boolean8 = compilerOptions0.inferTypesInGlobalScope;
        boolean boolean9 = compilerOptions0.inlineLocalVariables;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + checkLevel6 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel6.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(strSet7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test251");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setLooseTypes(true);
        boolean boolean3 = compilerOptions0.reserveRawExports;
        compilerOptions0.extractPrototypeMemberDeclarations = false;
        boolean boolean6 = compilerOptions0.disambiguateProperties;
        compilerOptions0.setDefineToDoubleLiteral("Not declared as a type name", 100.0d);
        compilerOptions0.foldConstants = false;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test252");
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention0 = new com.google.javascript.jscomp.DefaultCodingConvention();
        boolean boolean2 = defaultCodingConvention0.isExported("// Input %num%");
        boolean boolean4 = defaultCodingConvention0.isConstantKey("()");
        java.io.PrintStream printStream5 = null;
        com.google.javascript.jscomp.Compiler compiler6 = new com.google.javascript.jscomp.Compiler(printStream5);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile9 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        java.io.Reader reader10 = jSSourceFile9.getCodeReader();
        com.google.javascript.jscomp.JSModule[] jSModuleArray11 = new com.google.javascript.jscomp.JSModule[] {};
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph12 = new com.google.javascript.jscomp.JSModuleGraph(jSModuleArray11);
        com.google.javascript.jscomp.CompilerOptions compilerOptions13 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions13.setLooseTypes(true);
        boolean boolean16 = compilerOptions13.collapseVariableDeclarations;
        compilerOptions13.moveFunctionDeclarations = false;
        boolean boolean19 = compilerOptions13.decomposeExpressions;
        com.google.javascript.jscomp.CheckLevel checkLevel20 = compilerOptions13.checkMissingGetCssNameLevel;
        com.google.javascript.jscomp.Result result21 = compiler6.compile(jSSourceFile9, jSModuleArray11, compilerOptions13);
        int int22 = compiler6.getErrorCount();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry23 = compiler6.getTypeRegistry();
        com.google.javascript.jscomp.Scope scope24 = null;
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention25 = new com.google.javascript.jscomp.DefaultCodingConvention();
        boolean boolean27 = defaultCodingConvention25.isExported("// Input %num%");
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry28 = null;
        com.google.javascript.jscomp.Scope scope29 = null;
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention30 = new com.google.javascript.jscomp.DefaultCodingConvention();
        java.lang.String str31 = defaultCodingConvention30.getDelegateSuperclassName();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry32 = null;
        com.google.javascript.jscomp.Scope scope33 = null;
        com.google.javascript.rhino.jstype.ObjectType[] objectTypeArray34 = new com.google.javascript.rhino.jstype.ObjectType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.ObjectType> objectTypeList35 = new java.util.ArrayList<com.google.javascript.rhino.jstype.ObjectType>();
        boolean boolean36 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.ObjectType>) objectTypeList35, objectTypeArray34);
        defaultCodingConvention30.defineDelegateProxyPrototypeProperties(jSTypeRegistry32, scope33, (java.util.List<com.google.javascript.rhino.jstype.ObjectType>) objectTypeList35);
        defaultCodingConvention25.defineDelegateProxyPrototypeProperties(jSTypeRegistry28, scope29, (java.util.List<com.google.javascript.rhino.jstype.ObjectType>) objectTypeList35);
        defaultCodingConvention0.defineDelegateProxyPrototypeProperties(jSTypeRegistry23, scope24, (java.util.List<com.google.javascript.rhino.jstype.ObjectType>) objectTypeList35);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(jSSourceFile9);
        org.junit.Assert.assertNotNull(reader10);
        org.junit.Assert.assertNotNull(jSModuleArray11);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + checkLevel20 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel20.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(result21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertNotNull(jSTypeRegistry23);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNull(str31);
        org.junit.Assert.assertNotNull(objectTypeArray34);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test253");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString(27, "DiagnosticGroup<strictModuleDepCheck>", 21, 32);
        org.junit.Assert.assertNotNull(node4);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test254");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setLooseTypes(true);
        boolean boolean3 = compilerOptions0.reserveRawExports;
        compilerOptions0.extractPrototypeMemberDeclarations = false;
        compilerOptions0.checkMissingGetCssNameBlacklist = "4";
        compilerOptions0.locale = "error reporter";
        compilerOptions0.crossModuleMethodMotion = false;
        boolean boolean12 = compilerOptions0.optimizeReturns;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test255");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setLooseTypes(true);
        boolean boolean3 = compilerOptions0.collapseVariableDeclarations;
        compilerOptions0.moveFunctionDeclarations = false;
        boolean boolean6 = compilerOptions0.decomposeExpressions;
        boolean boolean7 = compilerOptions0.optimizeParameters;
        java.lang.String str8 = compilerOptions0.inputDelimiter;
        java.lang.String[] strArray10 = new java.lang.String[] { "hi!" };
        java.util.LinkedHashSet<java.lang.String> strSet11 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean12 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet11, strArray10);
        compilerOptions0.stripTypes = strSet11;
        java.lang.String str14 = compilerOptions0.nameReferenceGraphPath;
        com.google.javascript.jscomp.CheckLevel checkLevel15 = compilerOptions0.checkRequires;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "// Input %num%" + "'", str8.equals("// Input %num%"));
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertTrue("'" + checkLevel15 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel15.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test256");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.flowSensitiveInlineVariables = false;
        compilerOptions0.setDefineToBooleanLiteral("// Input %num%", false);
        com.google.javascript.rhino.Node node7 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node9 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node11 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node((int) '4');
        node11.addChildrenToBack(node13);
        node7.addChildAfter(node9, node13);
        com.google.javascript.rhino.Node node17 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node19 = new com.google.javascript.rhino.Node((int) '4');
        node17.addChildrenToBack(node19);
        com.google.javascript.rhino.Node node21 = node7.copyInformationFromForTree(node19);
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable22 = node21.siblings();
        java.lang.RuntimeException runtimeException23 = com.google.javascript.rhino.ScriptRuntime.notFunctionError((java.lang.Object) compilerOptions0, (java.lang.Object) node21);
        int int24 = node21.getLineno();
        com.google.javascript.rhino.Node node25 = node21.getParent();
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertNotNull(nodeIterable22);
        org.junit.Assert.assertNotNull(runtimeException23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertNull(node25);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test257");
        com.google.javascript.rhino.Context context0 = new com.google.javascript.rhino.Context();
        com.google.javascript.rhino.ErrorReporter errorReporter1 = context0.getErrorReporter();
        com.google.javascript.jscomp.CompilerOptions compilerOptions2 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions2.setLooseTypes(true);
        compilerOptions2.checkSuspiciousCode = false;
        compilerOptions2.disambiguateProperties = true;
        java.util.Map<java.lang.String, com.google.javascript.rhino.Node> strMap9 = compilerOptions2.getDefineReplacements();
        compilerOptions2.checkDuplicateMessages = false;
        context0.removeThreadLocal((java.lang.Object) compilerOptions2);
        com.google.javascript.jscomp.CompilerOptions compilerOptions13 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions13.setLooseTypes(true);
        boolean boolean16 = compilerOptions13.reserveRawExports;
        boolean boolean17 = compilerOptions13.flowSensitiveInlineVariables;
        compilerOptions13.reserveRawExports = true;
        com.google.javascript.jscomp.AnonymousFunctionNamingPolicy anonymousFunctionNamingPolicy20 = com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF;
        compilerOptions13.anonymousFunctionNaming = anonymousFunctionNamingPolicy20;
        char[] charArray22 = anonymousFunctionNamingPolicy20.getReservedCharacters();
        compilerOptions2.anonymousFunctionNaming = anonymousFunctionNamingPolicy20;
        org.junit.Assert.assertNull(errorReporter1);
        org.junit.Assert.assertNotNull(strMap9);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + anonymousFunctionNamingPolicy20 + "' != '" + com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF + "'", anonymousFunctionNamingPolicy20.equals(com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF));
        org.junit.Assert.assertNull(charArray22);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test258");
        com.google.javascript.rhino.EcmaError ecmaError1 = com.google.javascript.rhino.ScriptRuntime.typeError("4");
        java.lang.String str2 = ecmaError1.getName();
        java.lang.String str3 = ecmaError1.lineSource();
        ecmaError1.initColumnNumber(110);
        java.io.FilenameFilter filenameFilter6 = null;
        java.lang.String str7 = ecmaError1.getScriptStackTrace(filenameFilter6);
        org.junit.Assert.assertNotNull(ecmaError1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "TypeError" + "'", str2.equals("TypeError"));
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "<No stack trace available>" + "'", str7.equals("<No stack trace available>"));
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test259");
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention0 = new com.google.javascript.jscomp.DefaultCodingConvention();
        boolean boolean2 = defaultCodingConvention0.isExported("// Input %num%");
        com.google.javascript.rhino.Node node4 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node6 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node8 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node10 = new com.google.javascript.rhino.Node((int) '4');
        node8.addChildrenToBack(node10);
        node4.addChildAfter(node6, node10);
        com.google.javascript.rhino.Node node14 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node16 = new com.google.javascript.rhino.Node((int) '4');
        node14.addChildrenToBack(node16);
        com.google.javascript.rhino.Node node18 = node4.copyInformationFromForTree(node16);
        com.google.javascript.rhino.Node node19 = node4.cloneTree();
        com.google.javascript.rhino.Node node23 = new com.google.javascript.rhino.Node(30, 35, 8);
        com.google.javascript.rhino.Node node24 = node23.getLastChild();
        node19.addChildToFront(node23);
        java.lang.String str26 = defaultCodingConvention0.getSingletonGetterClassName(node23);
        com.google.javascript.rhino.Node node28 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node30 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node32 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node34 = new com.google.javascript.rhino.Node((int) '4');
        node32.addChildrenToBack(node34);
        node28.addChildAfter(node30, node34);
        node30.setIsSyntheticBlock(true);
        boolean boolean39 = defaultCodingConvention0.isPropertyTestFunction(node30);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNull(node24);
        org.junit.Assert.assertNull(str26);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test260");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        compiler1.disableThreads();
        com.google.javascript.jscomp.PerformanceTracker performanceTracker3 = compiler1.tracker;
        com.google.javascript.jscomp.NodeTraversal.Callback callback4 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal5 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler1, callback4);
        java.lang.String str6 = compiler1.getAstDotGraph();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile7 = null;
        java.io.PrintStream printStream8 = null;
        com.google.javascript.jscomp.Compiler compiler9 = new com.google.javascript.jscomp.Compiler(printStream8);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile11 = com.google.javascript.jscomp.JSSourceFile.fromFile("(): error reporter");
        com.google.javascript.rhino.Node node12 = compiler9.parse(jSSourceFile11);
        com.google.javascript.jscomp.CompilerOptions compilerOptions13 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions13.removeUnusedPrototypePropertiesInExterns = false;
        compilerOptions13.removeUnusedLocalVars = false;
        compilerOptions13.ignoreCajaProperties = false;
        com.google.javascript.jscomp.CodingConvention codingConvention20 = compilerOptions13.getCodingConvention();
        compilerOptions13.optimizeParameters = true;
        try {
            com.google.javascript.jscomp.Result result23 = compiler1.compile(jSSourceFile7, jSSourceFile11, compilerOptions13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(performanceTracker3);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertNotNull(jSSourceFile11);
        org.junit.Assert.assertNull(node12);
        org.junit.Assert.assertNull(codingConvention20);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test261");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeUnusedPrototypePropertiesInExterns = false;
        boolean boolean3 = compilerOptions0.markAsCompiled;
        compilerOptions0.setDefineToBooleanLiteral("", true);
        boolean boolean7 = compilerOptions0.optimizeReturns;
        compilerOptions0.enableExternExports(true);
        compilerOptions0.aliasableGlobals = "(language version)";
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test262");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setLooseTypes(true);
        boolean boolean3 = compilerOptions0.reserveRawExports;
        com.google.javascript.jscomp.CheckLevel checkLevel4 = null;
        compilerOptions0.checkUnreachableCode = checkLevel4;
        com.google.javascript.jscomp.MessageBundle messageBundle6 = compilerOptions0.messageBundle;
        java.lang.String str7 = compilerOptions0.sourceMapOutputPath;
        compilerOptions0.aliasKeywords = true;
        boolean boolean10 = compilerOptions0.generateExports;
        com.google.common.collect.Multimap<com.google.javascript.jscomp.CustomPassExecutionTime, com.google.javascript.jscomp.CompilerPass> customPassExecutionTimeMultimap11 = null;
        compilerOptions0.customPasses = customPassExecutionTimeMultimap11;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(messageBundle6);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test263");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setLooseTypes(true);
        compilerOptions0.renamePrefix = "hi!";
        compilerOptions0.checkControlStructures = false;
        boolean boolean7 = compilerOptions0.foldConstants;
        boolean boolean8 = compilerOptions0.checkTypedPropertyCalls;
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test264");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeUnusedPrototypePropertiesInExterns = false;
        boolean boolean3 = compilerOptions0.markAsCompiled;
        compilerOptions0.setDefineToBooleanLiteral("", true);
        compilerOptions0.rewriteFunctionExpressions = false;
        java.lang.String str9 = compilerOptions0.syntheticBlockStartMarker;
        com.google.javascript.jscomp.CompilerOptions compilerOptions11 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions11.setLooseTypes(true);
        boolean boolean14 = compilerOptions11.collapseVariableDeclarations;
        compilerOptions11.moveFunctionDeclarations = false;
        boolean boolean17 = compilerOptions11.decomposeExpressions;
        boolean boolean18 = compilerOptions11.optimizeParameters;
        java.lang.String str19 = compilerOptions11.inputDelimiter;
        com.google.javascript.jscomp.ErrorFormat errorFormat20 = com.google.javascript.jscomp.ErrorFormat.LEGACY;
        java.lang.RuntimeException runtimeException21 = com.google.javascript.rhino.ScriptRuntime.undefWriteError((java.lang.Object) (short) 100, (java.lang.Object) str19, (java.lang.Object) errorFormat20);
        compilerOptions0.errorFormat = errorFormat20;
        boolean boolean23 = compilerOptions0.allowLegacyJsMessages;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "// Input %num%" + "'", str19.equals("// Input %num%"));
        org.junit.Assert.assertNotNull(errorFormat20);
        org.junit.Assert.assertNotNull(runtimeException21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

//    @Test
//    public void test265() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test265");
//        try {
//            com.google.javascript.rhino.Context.reportError("JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}");
//            org.junit.Assert.fail("Expected exception of type com.google.javascript.rhino.EvaluatorException; message: JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}");
//        } catch (com.google.javascript.rhino.EvaluatorException e) {
//        }
//    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test266");
        com.google.javascript.jscomp.SourceAst sourceAst0 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(sourceAst0, "", false);
        boolean boolean4 = compilerInput3.isExtern();
        java.lang.String str5 = compilerInput3.getName();
        com.google.javascript.jscomp.JSModule jSModule6 = compilerInput3.getModule();
        com.google.javascript.jscomp.CompilerInput compilerInput9 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput3, "<No stack trace available>", false);
        com.google.javascript.jscomp.SourceAst sourceAst10 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput13 = new com.google.javascript.jscomp.CompilerInput(sourceAst10, "", false);
        boolean boolean14 = compilerInput13.isExtern();
        java.lang.String str15 = compilerInput13.getName();
        com.google.javascript.jscomp.JSModule jSModule16 = compilerInput13.getModule();
        com.google.javascript.jscomp.CompilerInput compilerInput19 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput13, "<No stack trace available>", false);
        com.google.javascript.jscomp.SourceAst sourceAst20 = compilerInput19.getSourceAst();
        java.util.logging.Logger logger21 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager22 = new com.google.javascript.jscomp.LoggerErrorManager(logger21);
        com.google.javascript.jscomp.CompilerOptions compilerOptions23 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions23.setLooseTypes(true);
        compilerOptions23.convertToDottedProperties = false;
        com.google.javascript.jscomp.CheckLevel checkLevel28 = compilerOptions23.reportMissingOverride;
        com.google.javascript.rhino.Node node31 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node33 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node35 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node37 = new com.google.javascript.rhino.Node((int) '4');
        node35.addChildrenToBack(node37);
        node31.addChildAfter(node33, node37);
        com.google.javascript.rhino.Node node41 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node43 = new com.google.javascript.rhino.Node((int) '4');
        node41.addChildrenToBack(node43);
        com.google.javascript.rhino.Node node45 = node31.copyInformationFromForTree(node43);
        com.google.javascript.jscomp.DiagnosticType diagnosticType46 = com.google.javascript.jscomp.Compiler.MOTION_ITERATIONS_ERROR;
        java.lang.String str47 = diagnosticType46.toString();
        java.lang.String[] strArray48 = null;
        com.google.javascript.jscomp.JSError jSError49 = com.google.javascript.jscomp.JSError.make("", node43, diagnosticType46, strArray48);
        java.lang.String str50 = jSError49.toString();
        loggerErrorManager22.println(checkLevel28, jSError49);
        int int52 = loggerErrorManager22.getWarningCount();
        int int53 = loggerErrorManager22.getWarningCount();
        compilerInput19.setErrorManager((com.google.javascript.jscomp.ErrorManager) loggerErrorManager22);
        com.google.javascript.jscomp.SourceAst sourceAst55 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput58 = new com.google.javascript.jscomp.CompilerInput(sourceAst55, "", false);
        com.google.javascript.jscomp.SourceAst sourceAst59 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput62 = new com.google.javascript.jscomp.CompilerInput(sourceAst59, "", false);
        boolean boolean63 = compilerInput62.isExtern();
        java.lang.String str64 = compilerInput62.getName();
        com.google.javascript.jscomp.SourceAst sourceAst65 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput68 = new com.google.javascript.jscomp.CompilerInput(sourceAst65, "", false);
        boolean boolean69 = compilerInput68.isExtern();
        java.lang.String str70 = compilerInput68.getName();
        boolean boolean71 = compilerInput68.isExtern();
        com.google.javascript.jscomp.SourceAst sourceAst72 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput75 = new com.google.javascript.jscomp.CompilerInput(sourceAst72, "", false);
        boolean boolean76 = compilerInput75.isExtern();
        java.lang.String str77 = compilerInput75.getName();
        com.google.javascript.jscomp.JSModule jSModule78 = compilerInput75.getModule();
        com.google.javascript.jscomp.deps.DependencyInfo[] dependencyInfoArray79 = new com.google.javascript.jscomp.deps.DependencyInfo[] { compilerInput3, compilerInput19, compilerInput58, compilerInput62, compilerInput68, compilerInput75 };
        java.util.ArrayList<com.google.javascript.jscomp.deps.DependencyInfo> dependencyInfoList80 = new java.util.ArrayList<com.google.javascript.jscomp.deps.DependencyInfo>();
        boolean boolean81 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.deps.DependencyInfo>) dependencyInfoList80, dependencyInfoArray79);
        try {
            com.google.javascript.jscomp.deps.SortedDependencies<com.google.javascript.jscomp.deps.DependencyInfo> dependencyInfoSortedDependencies82 = new com.google.javascript.jscomp.deps.SortedDependencies<com.google.javascript.jscomp.deps.DependencyInfo>((java.util.List<com.google.javascript.jscomp.deps.DependencyInfo>) dependencyInfoList80);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Expected setErrorManager to be called first");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertNull(jSModule6);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
        org.junit.Assert.assertNull(jSModule16);
        org.junit.Assert.assertNotNull(sourceAst20);
        org.junit.Assert.assertTrue("'" + checkLevel28 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel28.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(node45);
        org.junit.Assert.assertNotNull(diagnosticType46);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}" + "'", str47.equals("JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}"));
        org.junit.Assert.assertNotNull(jSError49);
        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "JSC_OPTIMIZE_LOOP_ERROR. Exceeded max number of code motion iterations: {0} at (unknown source) line (unknown line) : (unknown column)" + "'", str50.equals("JSC_OPTIMIZE_LOOP_ERROR. Exceeded max number of code motion iterations: {0} at (unknown source) line (unknown line) : (unknown column)"));
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 0 + "'", int52 == 0);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 0 + "'", int53 == 0);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertTrue("'" + str64 + "' != '" + "" + "'", str64.equals(""));
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
        org.junit.Assert.assertTrue("'" + str70 + "' != '" + "" + "'", str70.equals(""));
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
        org.junit.Assert.assertTrue("'" + str77 + "' != '" + "" + "'", str77.equals(""));
        org.junit.Assert.assertNull(jSModule78);
        org.junit.Assert.assertNotNull(dependencyInfoArray79);
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + true + "'", boolean81 == true);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test267");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile4 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        java.io.Reader reader5 = jSSourceFile4.getCodeReader();
        com.google.javascript.jscomp.JSModule[] jSModuleArray6 = new com.google.javascript.jscomp.JSModule[] {};
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph7 = new com.google.javascript.jscomp.JSModuleGraph(jSModuleArray6);
        com.google.javascript.jscomp.CompilerOptions compilerOptions8 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions8.setLooseTypes(true);
        boolean boolean11 = compilerOptions8.collapseVariableDeclarations;
        compilerOptions8.moveFunctionDeclarations = false;
        boolean boolean14 = compilerOptions8.decomposeExpressions;
        com.google.javascript.jscomp.CheckLevel checkLevel15 = compilerOptions8.checkMissingGetCssNameLevel;
        com.google.javascript.jscomp.Result result16 = compiler1.compile(jSSourceFile4, jSModuleArray6, compilerOptions8);
        com.google.javascript.jscomp.CompilerOptions.AliasTransformationHandler aliasTransformationHandler17 = null;
        compilerOptions8.setAliasTransformationHandler(aliasTransformationHandler17);
        boolean boolean19 = compilerOptions8.gatherCssNames;
        org.junit.Assert.assertNotNull(jSSourceFile4);
        org.junit.Assert.assertNotNull(reader5);
        org.junit.Assert.assertNotNull(jSModuleArray6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + checkLevel15 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel15.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(result16);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test268");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        compiler1.disableThreads();
        com.google.javascript.jscomp.PerformanceTracker performanceTracker3 = compiler1.tracker;
        com.google.javascript.jscomp.NodeTraversal.Callback callback4 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal5 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler1, callback4);
        com.google.javascript.jscomp.Compiler compiler6 = nodeTraversal5.getCompiler();
        com.google.javascript.rhino.Node node7 = nodeTraversal5.getCurrentNode();
        com.google.javascript.rhino.Node node9 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node11 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node15 = new com.google.javascript.rhino.Node((int) '4');
        node13.addChildrenToBack(node15);
        node9.addChildAfter(node11, node15);
        com.google.javascript.rhino.Node node19 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node21 = new com.google.javascript.rhino.Node((int) '4');
        node19.addChildrenToBack(node21);
        com.google.javascript.rhino.Node node23 = node9.copyInformationFromForTree(node21);
        com.google.javascript.rhino.Node node24 = node9.cloneTree();
        com.google.javascript.rhino.Node node28 = new com.google.javascript.rhino.Node(30, 35, 8);
        com.google.javascript.rhino.Node node29 = node28.getLastChild();
        node24.addChildToFront(node28);
        com.google.javascript.jscomp.DiagnosticType diagnosticType31 = com.google.javascript.jscomp.Compiler.MOTION_ITERATIONS_ERROR;
        java.io.PrintStream printStream32 = null;
        com.google.javascript.jscomp.Compiler compiler33 = new com.google.javascript.jscomp.Compiler(printStream32);
        compiler33.disableThreads();
        com.google.javascript.jscomp.PerformanceTracker performanceTracker35 = compiler33.tracker;
        com.google.javascript.jscomp.NodeTraversal.Callback callback36 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal37 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler33, callback36);
        com.google.javascript.rhino.Node node39 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node41 = new com.google.javascript.rhino.Node((int) '4');
        node39.addChildrenToBack(node41);
        com.google.javascript.jscomp.DiagnosticType diagnosticType45 = com.google.javascript.jscomp.DiagnosticType.warning("hi!", "hi!");
        com.google.javascript.jscomp.DiagnosticType diagnosticType46 = com.google.javascript.jscomp.Compiler.MOTION_ITERATIONS_ERROR;
        int int47 = diagnosticType45.compareTo(diagnosticType46);
        java.lang.String[] strArray48 = com.google.javascript.rhino.ScriptRuntime.emptyStrings;
        com.google.javascript.jscomp.JSError jSError49 = nodeTraversal37.makeError(node41, diagnosticType45, strArray48);
        try {
            nodeTraversal5.report(node28, diagnosticType31, strArray48);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(performanceTracker3);
        org.junit.Assert.assertNotNull(compiler6);
        org.junit.Assert.assertNull(node7);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertNull(node29);
        org.junit.Assert.assertNotNull(diagnosticType31);
        org.junit.Assert.assertNull(performanceTracker35);
        org.junit.Assert.assertNotNull(diagnosticType45);
        org.junit.Assert.assertNotNull(diagnosticType46);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 30 + "'", int47 == 30);
        org.junit.Assert.assertNotNull(strArray48);
        org.junit.Assert.assertNotNull(jSError49);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test269");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setLooseTypes(true);
        boolean boolean3 = compilerOptions0.reserveRawExports;
        compilerOptions0.extractPrototypeMemberDeclarations = false;
        compilerOptions0.checkMissingGetCssNameBlacklist = "4";
        compilerOptions0.locale = "error reporter";
        compilerOptions0.checkTypedPropertyCalls = true;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test270");
        java.lang.String str0 = com.google.javascript.rhino.jstype.JSType.UNKNOWN_NAME;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "Unknown class name" + "'", str0.equals("Unknown class name"));
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test271");
        com.google.javascript.rhino.Node node1 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node3 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node5 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node7 = new com.google.javascript.rhino.Node((int) '4');
        node5.addChildrenToBack(node7);
        node1.addChildAfter(node3, node7);
        boolean boolean10 = node3.wasEmptyNode();
        com.google.javascript.jscomp.CompilerOptions compilerOptions11 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions11.setLooseTypes(true);
        boolean boolean14 = compilerOptions11.reserveRawExports;
        compilerOptions11.extractPrototypeMemberDeclarations = false;
        java.lang.String str17 = compilerOptions11.nameReferenceGraphPath;
        compilerOptions11.nameReferenceReportPath = "33";
        com.google.javascript.jscomp.CompilerOptions compilerOptions20 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions20.setLooseTypes(true);
        boolean boolean23 = compilerOptions20.reserveRawExports;
        compilerOptions20.extractPrototypeMemberDeclarations = false;
        java.lang.String str26 = compilerOptions20.nameReferenceGraphPath;
        compilerOptions20.computeFunctionSideEffects = true;
        com.google.javascript.jscomp.CompilerOptions compilerOptions29 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions29.setLooseTypes(true);
        compilerOptions29.convertToDottedProperties = false;
        com.google.javascript.jscomp.CheckLevel checkLevel34 = compilerOptions29.reportMissingOverride;
        compilerOptions20.brokenClosureRequiresLevel = checkLevel34;
        java.util.Set<java.lang.String> strSet36 = compilerOptions20.stripTypePrefixes;
        compilerOptions11.stripNameSuffixes = strSet36;
        node3.setDirectives(strSet36);
        node3.putBooleanProp(0, true);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNull(str26);
        org.junit.Assert.assertTrue("'" + checkLevel34 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel34.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(strSet36);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test272");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setLooseTypes(true);
        compilerOptions0.convertToDottedProperties = false;
        com.google.javascript.jscomp.CheckLevel checkLevel5 = compilerOptions0.reportMissingOverride;
        boolean boolean6 = compilerOptions0.aliasAllStrings;
        compilerOptions0.ignoreCajaProperties = true;
        org.junit.Assert.assertTrue("'" + checkLevel5 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel5.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test273");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setLooseTypes(true);
        boolean boolean3 = compilerOptions0.reserveRawExports;
        com.google.javascript.jscomp.CheckLevel checkLevel4 = null;
        compilerOptions0.checkUnreachableCode = checkLevel4;
        com.google.javascript.jscomp.MessageBundle messageBundle6 = compilerOptions0.messageBundle;
        java.lang.String str7 = compilerOptions0.sourceMapOutputPath;
        compilerOptions0.inlineConstantVars = false;
        com.google.javascript.jscomp.CompilerOptions compilerOptions10 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions10.setLooseTypes(true);
        boolean boolean13 = compilerOptions10.collapseVariableDeclarations;
        compilerOptions10.moveFunctionDeclarations = false;
        boolean boolean16 = compilerOptions10.decomposeExpressions;
        boolean boolean17 = compilerOptions10.optimizeParameters;
        java.lang.String str18 = compilerOptions10.inputDelimiter;
        java.lang.String[] strArray20 = new java.lang.String[] { "hi!" };
        java.util.LinkedHashSet<java.lang.String> strSet21 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean22 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet21, strArray20);
        compilerOptions10.stripTypes = strSet21;
        compilerOptions0.setIdGenerators((java.util.Set<java.lang.String>) strSet21);
        com.google.javascript.jscomp.CheckLevel checkLevel25 = compilerOptions0.reportUnknownTypes;
        boolean boolean26 = compilerOptions0.crossModuleMethodMotion;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(messageBundle6);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "// Input %num%" + "'", str18.equals("// Input %num%"));
        org.junit.Assert.assertNotNull(strArray20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + checkLevel25 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel25.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test274");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        compiler1.disableThreads();
        com.google.javascript.jscomp.PerformanceTracker performanceTracker3 = compiler1.tracker;
        com.google.javascript.jscomp.NodeTraversal.Callback callback4 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal5 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler1, callback4);
        com.google.javascript.rhino.Node node7 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node9 = new com.google.javascript.rhino.Node((int) '4');
        node7.addChildrenToBack(node9);
        com.google.javascript.jscomp.DiagnosticType diagnosticType13 = com.google.javascript.jscomp.DiagnosticType.warning("hi!", "hi!");
        com.google.javascript.jscomp.DiagnosticType diagnosticType14 = com.google.javascript.jscomp.Compiler.MOTION_ITERATIONS_ERROR;
        int int15 = diagnosticType13.compareTo(diagnosticType14);
        java.lang.String[] strArray16 = com.google.javascript.rhino.ScriptRuntime.emptyStrings;
        com.google.javascript.jscomp.JSError jSError17 = nodeTraversal5.makeError(node9, diagnosticType13, strArray16);
        java.lang.RuntimeException runtimeException19 = com.google.javascript.rhino.ScriptRuntime.undefCallError((java.lang.Object) nodeTraversal5, (java.lang.Object) (byte) 1);
        int int20 = nodeTraversal5.getLineNumber();
        com.google.javascript.jscomp.Scope scope21 = nodeTraversal5.getScope();
        int int22 = nodeTraversal5.getLineNumber();
        org.junit.Assert.assertNull(performanceTracker3);
        org.junit.Assert.assertNotNull(diagnosticType13);
        org.junit.Assert.assertNotNull(diagnosticType14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 30 + "'", int15 == 30);
        org.junit.Assert.assertNotNull(strArray16);
        org.junit.Assert.assertNotNull(jSError17);
        org.junit.Assert.assertNotNull(runtimeException19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNull(scope21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test275");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setLooseTypes(true);
        boolean boolean3 = compilerOptions0.collapseVariableDeclarations;
        boolean boolean4 = compilerOptions0.generateExports;
        compilerOptions0.checkMissingGetCssNameBlacklist = "// Input %num%";
        com.google.javascript.jscomp.CheckLevel checkLevel7 = compilerOptions0.checkMissingReturn;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + checkLevel7 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel7.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test276");
        com.google.javascript.rhino.Node node1 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node3 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node5 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node7 = new com.google.javascript.rhino.Node((int) '4');
        node5.addChildrenToBack(node7);
        node1.addChildAfter(node3, node7);
        com.google.javascript.rhino.Node node11 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node((int) '4');
        node11.addChildrenToBack(node13);
        com.google.javascript.rhino.Node node15 = node1.copyInformationFromForTree(node13);
        com.google.javascript.rhino.Node node17 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node18 = node1.copyInformationFromForTree(node17);
        com.google.javascript.rhino.JSDocInfo jSDocInfo19 = null;
        node17.setJSDocInfo(jSDocInfo19);
        com.google.javascript.rhino.Node node22 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node24 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node26 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node28 = new com.google.javascript.rhino.Node((int) '4');
        node26.addChildrenToBack(node28);
        node22.addChildAfter(node24, node28);
        com.google.javascript.rhino.Node node32 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node34 = new com.google.javascript.rhino.Node((int) '4');
        node32.addChildrenToBack(node34);
        com.google.javascript.rhino.Node node36 = node22.copyInformationFromForTree(node34);
        com.google.javascript.rhino.Node node38 = node22.getAncestor(1);
        com.google.javascript.rhino.Node node40 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node42 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node44 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node46 = new com.google.javascript.rhino.Node((int) '4');
        node44.addChildrenToBack(node46);
        node40.addChildAfter(node42, node46);
        com.google.javascript.rhino.Node node50 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node52 = new com.google.javascript.rhino.Node((int) '4');
        node50.addChildrenToBack(node52);
        com.google.javascript.rhino.Node node54 = node40.copyInformationFromForTree(node52);
        com.google.javascript.rhino.Node node56 = node40.getAncestor(1);
        node22.addChildToFront(node40);
        node22.setIsSyntheticBlock(true);
        node17.addChildrenToBack(node22);
        boolean boolean61 = node17.hasOneChild();
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNotNull(node36);
        org.junit.Assert.assertNull(node38);
        org.junit.Assert.assertNotNull(node54);
        org.junit.Assert.assertNull(node56);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + true + "'", boolean61 == true);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test277");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setLooseTypes(true);
        compilerOptions0.checkSuspiciousCode = false;
        compilerOptions0.disambiguateProperties = true;
        java.util.Map<java.lang.String, com.google.javascript.rhino.Node> strMap7 = compilerOptions0.getDefineReplacements();
        boolean boolean8 = compilerOptions0.inlineLocalFunctions;
        org.junit.Assert.assertNotNull(strMap7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test278");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setLooseTypes(true);
        boolean boolean3 = compilerOptions0.reserveRawExports;
        compilerOptions0.extractPrototypeMemberDeclarations = false;
        compilerOptions0.checkMissingGetCssNameBlacklist = "4";
        compilerOptions0.setTweakToStringLiteral("", "com.google.javascript.rhino.EcmaError: TypeError: 4");
        compilerOptions0.appNameStr = "Named type with empty name component";
        boolean boolean13 = compilerOptions0.instrumentForCoverageOnly;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test279");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setLooseTypes(true);
        boolean boolean3 = compilerOptions0.reserveRawExports;
        compilerOptions0.extractPrototypeMemberDeclarations = false;
        java.lang.String str6 = compilerOptions0.nameReferenceGraphPath;
        boolean boolean7 = compilerOptions0.markNoSideEffectCalls;
        com.google.javascript.jscomp.ErrorFormat errorFormat8 = compilerOptions0.errorFormat;
        compilerOptions0.setRemoveAbstractMethods(false);
        compilerOptions0.setNameAnonymousFunctionsOnly(false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(errorFormat8);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test280");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        compiler1.disableThreads();
        com.google.javascript.jscomp.PerformanceTracker performanceTracker3 = compiler1.tracker;
        com.google.javascript.jscomp.NodeTraversal.Callback callback4 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal5 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler1, callback4);
        com.google.javascript.rhino.Node node7 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node9 = new com.google.javascript.rhino.Node((int) '4');
        node7.addChildrenToBack(node9);
        com.google.javascript.jscomp.DiagnosticType diagnosticType13 = com.google.javascript.jscomp.DiagnosticType.warning("hi!", "hi!");
        com.google.javascript.jscomp.DiagnosticType diagnosticType14 = com.google.javascript.jscomp.Compiler.MOTION_ITERATIONS_ERROR;
        int int15 = diagnosticType13.compareTo(diagnosticType14);
        java.lang.String[] strArray16 = com.google.javascript.rhino.ScriptRuntime.emptyStrings;
        com.google.javascript.jscomp.JSError jSError17 = nodeTraversal5.makeError(node9, diagnosticType13, strArray16);
        java.lang.RuntimeException runtimeException19 = com.google.javascript.rhino.ScriptRuntime.undefCallError((java.lang.Object) nodeTraversal5, (java.lang.Object) (byte) 1);
        com.google.javascript.jscomp.Compiler compiler20 = nodeTraversal5.getCompiler();
        com.google.javascript.rhino.Node node23 = new com.google.javascript.rhino.Node((int) (short) 1);
        com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.Node.newString("hi!");
        int int26 = node25.getCharno();
        com.google.javascript.rhino.Node node28 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node30 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node32 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node34 = new com.google.javascript.rhino.Node((int) '4');
        node32.addChildrenToBack(node34);
        node28.addChildAfter(node30, node34);
        com.google.javascript.rhino.Node node38 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node40 = new com.google.javascript.rhino.Node((int) '4');
        node38.addChildrenToBack(node40);
        com.google.javascript.rhino.Node node42 = node28.copyInformationFromForTree(node40);
        com.google.javascript.rhino.Node node43 = node28.cloneTree();
        com.google.javascript.rhino.Node node44 = node28.cloneTree();
        com.google.javascript.rhino.Node node46 = new com.google.javascript.rhino.Node((int) '4');
        node46.setLineno(36);
        com.google.javascript.rhino.Node[] nodeArray49 = new com.google.javascript.rhino.Node[] { node23, node25, node44, node46 };
        com.google.javascript.rhino.Node node52 = new com.google.javascript.rhino.Node(0, nodeArray49, 25, 14);
        try {
            nodeTraversal5.traverseRoots(nodeArray49);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: INTERNAL COMPILER ERROR.\nPlease report this problem.\nnull");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNull(performanceTracker3);
        org.junit.Assert.assertNotNull(diagnosticType13);
        org.junit.Assert.assertNotNull(diagnosticType14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 30 + "'", int15 == 30);
        org.junit.Assert.assertNotNull(strArray16);
        org.junit.Assert.assertNotNull(jSError17);
        org.junit.Assert.assertNotNull(runtimeException19);
        org.junit.Assert.assertNotNull(compiler20);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
        org.junit.Assert.assertNotNull(node42);
        org.junit.Assert.assertNotNull(node43);
        org.junit.Assert.assertNotNull(node44);
        org.junit.Assert.assertNotNull(nodeArray49);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test281");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeUnusedPrototypePropertiesInExterns = false;
        boolean boolean3 = compilerOptions0.markAsCompiled;
        compilerOptions0.setDefineToBooleanLiteral("", true);
        boolean boolean7 = compilerOptions0.optimizeReturns;
        java.lang.String str8 = compilerOptions0.syntheticBlockStartMarker;
        boolean boolean9 = compilerOptions0.checkSuspiciousCode;
        byte[] byteArray10 = compilerOptions0.inputVariableMapSerialized;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(byteArray10);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test282");
        com.google.javascript.jscomp.mozilla.rhino.ast.AstRoot astRoot0 = null;
        com.google.javascript.jscomp.parsing.Config config3 = com.google.javascript.jscomp.parsing.ParserRunner.createConfig(false);
        com.google.javascript.jscomp.mozilla.rhino.ErrorReporter errorReporter4 = null;
        try {
            com.google.javascript.rhino.Node node5 = com.google.javascript.jscomp.parsing.IRFactory.transformTree(astRoot0, "", config3, errorReporter4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(config3);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test283");
        com.google.javascript.rhino.Node node1 = null;
        com.google.javascript.rhino.Node node5 = new com.google.javascript.rhino.Node(30, 35, 8);
        com.google.javascript.rhino.Node node6 = node5.getLastChild();
        try {
            com.google.javascript.rhino.Node node7 = new com.google.javascript.rhino.Node(4095, node1, node6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(node6);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test284");
        com.google.javascript.rhino.Node node2 = new com.google.javascript.rhino.Node((int) '4');
        node2.setLineno(36);
        com.google.javascript.rhino.Node node5 = node2.getParent();
        int int6 = node2.getChildCount();
        com.google.javascript.jscomp.DiagnosticType diagnosticType9 = com.google.javascript.jscomp.DiagnosticType.warning("hi!", "hi!");
        java.lang.String str10 = diagnosticType9.key;
        java.lang.String str11 = diagnosticType9.toString();
        java.io.PrintStream printStream12 = null;
        com.google.javascript.jscomp.Compiler compiler13 = new com.google.javascript.jscomp.Compiler(printStream12);
        compiler13.disableThreads();
        com.google.javascript.jscomp.PerformanceTracker performanceTracker15 = compiler13.tracker;
        com.google.javascript.jscomp.NodeTraversal.Callback callback16 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal17 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler13, callback16);
        com.google.javascript.rhino.Node node19 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node21 = new com.google.javascript.rhino.Node((int) '4');
        node19.addChildrenToBack(node21);
        com.google.javascript.jscomp.DiagnosticType diagnosticType25 = com.google.javascript.jscomp.DiagnosticType.warning("hi!", "hi!");
        com.google.javascript.jscomp.DiagnosticType diagnosticType26 = com.google.javascript.jscomp.Compiler.MOTION_ITERATIONS_ERROR;
        int int27 = diagnosticType25.compareTo(diagnosticType26);
        java.lang.String[] strArray28 = com.google.javascript.rhino.ScriptRuntime.emptyStrings;
        com.google.javascript.jscomp.JSError jSError29 = nodeTraversal17.makeError(node21, diagnosticType25, strArray28);
        com.google.javascript.jscomp.JSError jSError30 = com.google.javascript.jscomp.JSError.make("language version", node2, diagnosticType9, strArray28);
        com.google.javascript.rhino.Node node32 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node34 = new com.google.javascript.rhino.Node((int) '4');
        node32.addChildrenToBack(node34);
        com.google.javascript.rhino.Node node36 = node32.getLastChild();
        node32.setLineno(7);
        com.google.javascript.rhino.Node node40 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node42 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node44 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node46 = new com.google.javascript.rhino.Node((int) '4');
        node44.addChildrenToBack(node46);
        node40.addChildAfter(node42, node46);
        com.google.javascript.rhino.Node node50 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node52 = new com.google.javascript.rhino.Node((int) '4');
        node50.addChildrenToBack(node52);
        com.google.javascript.rhino.Node node54 = node40.copyInformationFromForTree(node52);
        com.google.javascript.rhino.Node node56 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node57 = node40.copyInformationFromForTree(node56);
        boolean boolean58 = node56.isQualifiedName();
        com.google.javascript.rhino.Node node60 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node62 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node64 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node66 = new com.google.javascript.rhino.Node((int) '4');
        node64.addChildrenToBack(node66);
        node60.addChildAfter(node62, node66);
        com.google.javascript.rhino.Node node70 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node72 = new com.google.javascript.rhino.Node((int) '4');
        node70.addChildrenToBack(node72);
        com.google.javascript.rhino.Node node74 = node60.copyInformationFromForTree(node72);
        node32.addChildAfter(node56, node72);
        try {
            node2.removeChild(node72);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(node5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(diagnosticType9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "hi!" + "'", str10.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "hi!: hi!" + "'", str11.equals("hi!: hi!"));
        org.junit.Assert.assertNull(performanceTracker15);
        org.junit.Assert.assertNotNull(diagnosticType25);
        org.junit.Assert.assertNotNull(diagnosticType26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 30 + "'", int27 == 30);
        org.junit.Assert.assertNotNull(strArray28);
        org.junit.Assert.assertNotNull(jSError29);
        org.junit.Assert.assertNotNull(jSError30);
        org.junit.Assert.assertNotNull(node36);
        org.junit.Assert.assertNotNull(node54);
        org.junit.Assert.assertNotNull(node57);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(node74);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test285");
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention0 = new com.google.javascript.jscomp.DefaultCodingConvention();
        boolean boolean2 = defaultCodingConvention0.isExported("// Input %num%");
        boolean boolean4 = defaultCodingConvention0.isSuperClassReference("");
        com.google.javascript.rhino.Node node6 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node8 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node10 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node12 = new com.google.javascript.rhino.Node((int) '4');
        node10.addChildrenToBack(node12);
        node6.addChildAfter(node8, node12);
        boolean boolean15 = node8.wasEmptyNode();
        java.lang.String str16 = defaultCodingConvention0.identifyTypeDefAssign(node8);
        boolean boolean19 = defaultCodingConvention0.isExported("Exceeded max number of code motion iterations: {0}", false);
        java.lang.String str20 = defaultCodingConvention0.getGlobalObject();
        java.lang.String str21 = defaultCodingConvention0.getAbstractMethodName();
        com.google.javascript.rhino.Node node23 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node25 = new com.google.javascript.rhino.Node((int) '4');
        node23.addChildrenToBack(node25);
        com.google.javascript.rhino.Node node27 = node23.getParent();
        java.util.List<java.lang.String> strList28 = defaultCodingConvention0.identifyTypeDeclarationCall(node23);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "window" + "'", str20.equals("window"));
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertNull(node27);
        org.junit.Assert.assertNull(strList28);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test286");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.flowSensitiveInlineVariables = false;
        compilerOptions0.setDefineToBooleanLiteral("// Input %num%", false);
        com.google.javascript.rhino.Node node7 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node9 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node11 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node((int) '4');
        node11.addChildrenToBack(node13);
        node7.addChildAfter(node9, node13);
        com.google.javascript.rhino.Node node17 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node19 = new com.google.javascript.rhino.Node((int) '4');
        node17.addChildrenToBack(node19);
        com.google.javascript.rhino.Node node21 = node7.copyInformationFromForTree(node19);
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable22 = node21.siblings();
        java.lang.RuntimeException runtimeException23 = com.google.javascript.rhino.ScriptRuntime.notFunctionError((java.lang.Object) compilerOptions0, (java.lang.Object) node21);
        compilerOptions0.setOutputCharset("@IMPLEMENTATION.VERSION@");
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertNotNull(nodeIterable22);
        org.junit.Assert.assertNotNull(runtimeException23);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test287");
        com.google.javascript.jscomp.SourceFile.Generator generator1 = null;
        com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromGenerator("Not declared as a type name", generator1);
        org.junit.Assert.assertNotNull(sourceFile2);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test288");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.flowSensitiveInlineVariables = false;
        compilerOptions0.setDefineToBooleanLiteral("// Input %num%", false);
        com.google.javascript.jscomp.MessageBundle messageBundle6 = compilerOptions0.messageBundle;
        boolean boolean7 = compilerOptions0.removeUnusedLocalVars;
        org.junit.Assert.assertNull(messageBundle6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test289");
        java.util.logging.Logger logger0 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager1 = new com.google.javascript.jscomp.LoggerErrorManager(logger0);
        int int2 = loggerErrorManager1.getErrorCount();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test290");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setLooseTypes(true);
        boolean boolean3 = compilerOptions0.reserveRawExports;
        com.google.javascript.jscomp.CheckLevel checkLevel4 = null;
        compilerOptions0.checkUnreachableCode = checkLevel4;
        boolean boolean6 = compilerOptions0.devirtualizePrototypeMethods;
        compilerOptions0.setColorizeErrorOutput(true);
        compilerOptions0.setTweakToNumberLiteral("language version", (int) (byte) 10);
        compilerOptions0.checkControlStructures = false;
        com.google.javascript.jscomp.CompilerOptions compilerOptions14 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions14.setLooseTypes(true);
        boolean boolean17 = compilerOptions14.collapseVariableDeclarations;
        boolean boolean18 = compilerOptions14.generateExports;
        com.google.javascript.jscomp.SourceMap.DetailLevel detailLevel19 = compilerOptions14.sourceMapDetailLevel;
        com.google.javascript.jscomp.CheckLevel checkLevel20 = null;
        compilerOptions14.brokenClosureRequiresLevel = checkLevel20;
        java.util.Set<java.lang.String> strSet22 = compilerOptions14.aliasableStrings;
        byte[] byteArray28 = new byte[] { (byte) 0, (byte) 1, (byte) 10, (byte) 10, (byte) 1 };
        compilerOptions14.inputVariableMapSerialized = byteArray28;
        compilerOptions0.inputVariableMapSerialized = byteArray28;
        compilerOptions0.reserveRawExports = false;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(detailLevel19);
        org.junit.Assert.assertNotNull(strSet22);
        org.junit.Assert.assertNotNull(byteArray28);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test291");
        long long1 = com.google.javascript.rhino.ScriptRuntime.testUint32String("Not declared as a type name");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1L) + "'", long1 == (-1L));
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test292");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setLooseTypes(true);
        compilerOptions0.checkSuspiciousCode = false;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap5 = null;
        compilerOptions0.cssRenamingMap = cssRenamingMap5;
        compilerOptions0.aliasableGlobals = "hi!: hi!";
        boolean boolean9 = compilerOptions0.removeTryCatchFinally;
        com.google.javascript.jscomp.CheckLevel checkLevel10 = compilerOptions0.checkMissingGetCssNameLevel;
        compilerOptions0.setLooseTypes(false);
        boolean boolean13 = compilerOptions0.checkControlStructures;
        boolean boolean14 = compilerOptions0.allowLegacyJsMessages;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy15 = com.google.javascript.jscomp.VariableRenamingPolicy.LOCAL;
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy16 = com.google.javascript.jscomp.PropertyRenamingPolicy.UNSPECIFIED;
        compilerOptions0.setRenamingPolicy(variableRenamingPolicy15, propertyRenamingPolicy16);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + checkLevel10 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel10.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy15 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.LOCAL + "'", variableRenamingPolicy15.equals(com.google.javascript.jscomp.VariableRenamingPolicy.LOCAL));
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy16 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.UNSPECIFIED + "'", propertyRenamingPolicy16.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.UNSPECIFIED));
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test293");
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention0 = new com.google.javascript.jscomp.DefaultCodingConvention();
        boolean boolean2 = defaultCodingConvention0.isExported("// Input %num%");
        boolean boolean4 = defaultCodingConvention0.isSuperClassReference("");
        com.google.javascript.rhino.Node node6 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node8 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node10 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node12 = new com.google.javascript.rhino.Node((int) '4');
        node10.addChildrenToBack(node12);
        node6.addChildAfter(node8, node12);
        boolean boolean15 = node8.wasEmptyNode();
        java.lang.String str16 = defaultCodingConvention0.identifyTypeDefAssign(node8);
        com.google.javascript.rhino.Node node18 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node20 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node22 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node24 = new com.google.javascript.rhino.Node((int) '4');
        node22.addChildrenToBack(node24);
        node18.addChildAfter(node20, node24);
        com.google.javascript.rhino.Node node30 = new com.google.javascript.rhino.Node(30, 35, 8);
        com.google.javascript.rhino.Node node31 = node30.getLastSibling();
        try {
            java.lang.String str32 = defaultCodingConvention0.extractClassNameIfRequire(node18, node31);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: only implemented in GoogleCodingConvention");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertNotNull(node31);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test294");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setLooseTypes(true);
        boolean boolean3 = compilerOptions0.reserveRawExports;
        com.google.javascript.jscomp.CheckLevel checkLevel4 = null;
        compilerOptions0.checkUnreachableCode = checkLevel4;
        boolean boolean6 = compilerOptions0.devirtualizePrototypeMethods;
        compilerOptions0.setColorizeErrorOutput(true);
        compilerOptions0.setTweakToNumberLiteral("language version", (int) (byte) 10);
        compilerOptions0.gatherCssNames = false;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test295");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setLooseTypes(true);
        boolean boolean3 = compilerOptions0.reserveRawExports;
        compilerOptions0.extractPrototypeMemberDeclarations = false;
        java.lang.String str6 = compilerOptions0.nameReferenceGraphPath;
        compilerOptions0.computeFunctionSideEffects = true;
        com.google.javascript.jscomp.CompilerOptions compilerOptions9 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions9.setLooseTypes(true);
        compilerOptions9.convertToDottedProperties = false;
        com.google.javascript.jscomp.CheckLevel checkLevel14 = compilerOptions9.reportMissingOverride;
        compilerOptions0.brokenClosureRequiresLevel = checkLevel14;
        com.google.javascript.jscomp.CompilerOptions.TracerMode tracerMode16 = compilerOptions0.tracer;
        boolean boolean17 = compilerOptions0.groupVariableDeclarations;
        compilerOptions0.setTweakToDoubleLiteral("error reporter", (double) 130);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + checkLevel14 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel14.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + tracerMode16 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TracerMode.OFF + "'", tracerMode16.equals(com.google.javascript.jscomp.CompilerOptions.TracerMode.OFF));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test296");
        com.google.javascript.jscomp.SourceAst sourceAst0 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(sourceAst0, "", false);
        boolean boolean4 = compilerInput3.isExtern();
        java.lang.String str5 = compilerInput3.getName();
        com.google.javascript.jscomp.JSModule jSModule6 = compilerInput3.getModule();
        com.google.javascript.jscomp.CompilerInput compilerInput9 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput3, "<No stack trace available>", false);
        com.google.javascript.jscomp.SourceAst sourceAst10 = compilerInput9.getSourceAst();
        try {
            com.google.javascript.jscomp.SourceFile sourceFile11 = compilerInput9.getSourceFile();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertNull(jSModule6);
        org.junit.Assert.assertNotNull(sourceAst10);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test297");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setLooseTypes(true);
        boolean boolean3 = compilerOptions0.collapseVariableDeclarations;
        boolean boolean4 = compilerOptions0.generateExports;
        com.google.javascript.jscomp.SourceMap.DetailLevel detailLevel5 = compilerOptions0.sourceMapDetailLevel;
        com.google.javascript.jscomp.CheckLevel checkLevel6 = null;
        compilerOptions0.brokenClosureRequiresLevel = checkLevel6;
        boolean boolean8 = compilerOptions0.inlineFunctions;
        java.util.Set<java.lang.String> strSet9 = compilerOptions0.stripTypes;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(detailLevel5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(strSet9);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test298");
        com.google.javascript.rhino.Node node2 = new com.google.javascript.rhino.Node((int) (short) 1);
        com.google.javascript.rhino.Node node4 = new com.google.javascript.rhino.Node((int) (short) 1);
        node2.addChildrenToBack(node4);
        try {
            com.google.javascript.rhino.Node node6 = new com.google.javascript.rhino.Node((int) (short) 10, node4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: new child has existing parent");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test299");
        com.google.javascript.jscomp.CheckLevel checkLevel0 = com.google.javascript.jscomp.CheckLevel.ERROR;
        org.junit.Assert.assertTrue("'" + checkLevel0 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel0.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test300");
        com.google.javascript.jscomp.SourceAst sourceAst0 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(sourceAst0, "", false);
        boolean boolean4 = compilerInput3.isExtern();
        java.lang.String str5 = compilerInput3.getName();
        java.util.logging.Logger logger6 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager7 = new com.google.javascript.jscomp.LoggerErrorManager(logger6);
        com.google.javascript.jscomp.CompilerOptions compilerOptions8 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions8.setLooseTypes(true);
        compilerOptions8.convertToDottedProperties = false;
        com.google.javascript.jscomp.CheckLevel checkLevel13 = compilerOptions8.reportUnknownTypes;
        com.google.javascript.rhino.Node node16 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node18 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node20 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node22 = new com.google.javascript.rhino.Node((int) '4');
        node20.addChildrenToBack(node22);
        node16.addChildAfter(node18, node22);
        com.google.javascript.rhino.Node node26 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node28 = new com.google.javascript.rhino.Node((int) '4');
        node26.addChildrenToBack(node28);
        com.google.javascript.rhino.Node node30 = node16.copyInformationFromForTree(node28);
        com.google.javascript.jscomp.DiagnosticType diagnosticType31 = com.google.javascript.jscomp.Compiler.MOTION_ITERATIONS_ERROR;
        java.lang.String str32 = diagnosticType31.toString();
        java.lang.String[] strArray33 = null;
        com.google.javascript.jscomp.JSError jSError34 = com.google.javascript.jscomp.JSError.make("", node28, diagnosticType31, strArray33);
        java.lang.String str35 = jSError34.toString();
        loggerErrorManager7.report(checkLevel13, jSError34);
        double double37 = loggerErrorManager7.getTypedPercent();
        compilerInput3.setErrorManager((com.google.javascript.jscomp.ErrorManager) loggerErrorManager7);
        try {
            java.lang.String str39 = compilerInput3.getCode();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + checkLevel13 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel13.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(node30);
        org.junit.Assert.assertNotNull(diagnosticType31);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}" + "'", str32.equals("JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}"));
        org.junit.Assert.assertNotNull(jSError34);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "JSC_OPTIMIZE_LOOP_ERROR. Exceeded max number of code motion iterations: {0} at (unknown source) line (unknown line) : (unknown column)" + "'", str35.equals("JSC_OPTIMIZE_LOOP_ERROR. Exceeded max number of code motion iterations: {0} at (unknown source) line (unknown line) : (unknown column)"));
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.0d + "'", double37 == 0.0d);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test301");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setLooseTypes(true);
        boolean boolean3 = compilerOptions0.collapseVariableDeclarations;
        compilerOptions0.moveFunctionDeclarations = false;
        boolean boolean6 = compilerOptions0.decomposeExpressions;
        boolean boolean7 = compilerOptions0.optimizeParameters;
        java.lang.String str8 = compilerOptions0.inputDelimiter;
        java.lang.String str9 = compilerOptions0.debugFunctionSideEffectsPath;
        compilerOptions0.removeDeadCode = false;
        com.google.javascript.jscomp.CodingConvention codingConvention12 = compilerOptions0.getCodingConvention();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "// Input %num%" + "'", str8.equals("// Input %num%"));
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertNull(codingConvention12);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test302");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile4 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        java.io.Reader reader5 = jSSourceFile4.getCodeReader();
        com.google.javascript.jscomp.JSModule[] jSModuleArray6 = new com.google.javascript.jscomp.JSModule[] {};
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph7 = new com.google.javascript.jscomp.JSModuleGraph(jSModuleArray6);
        com.google.javascript.jscomp.CompilerOptions compilerOptions8 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions8.setLooseTypes(true);
        boolean boolean11 = compilerOptions8.collapseVariableDeclarations;
        compilerOptions8.moveFunctionDeclarations = false;
        boolean boolean14 = compilerOptions8.decomposeExpressions;
        com.google.javascript.jscomp.CheckLevel checkLevel15 = compilerOptions8.checkMissingGetCssNameLevel;
        com.google.javascript.jscomp.Result result16 = compiler1.compile(jSSourceFile4, jSModuleArray6, compilerOptions8);
        com.google.javascript.jscomp.Result result17 = compiler1.getResult();
        com.google.javascript.jscomp.Compiler.IntermediateState intermediateState18 = compiler1.getState();
        boolean boolean19 = compiler1.hasErrors();
        int int20 = compiler1.getWarningCount();
        org.junit.Assert.assertNotNull(jSSourceFile4);
        org.junit.Assert.assertNotNull(reader5);
        org.junit.Assert.assertNotNull(jSModuleArray6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + checkLevel15 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel15.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(result16);
        org.junit.Assert.assertNotNull(result17);
        org.junit.Assert.assertNotNull(intermediateState18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test303");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newString("hi!");
        int int2 = node1.getCharno();
        node1.setType(40);
        com.google.javascript.rhino.Node node5 = node1.removeChildren();
        java.lang.String str6 = node1.toStringTree();
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertNull(node5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "STRING hi!\n" + "'", str6.equals("STRING hi!\n"));
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test304");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.flowSensitiveInlineVariables = false;
        java.lang.String str3 = compilerOptions0.inputDelimiter;
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "// Input %num%" + "'", str3.equals("// Input %num%"));
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test305");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setLooseTypes(true);
        boolean boolean3 = compilerOptions0.reserveRawExports;
        boolean boolean4 = compilerOptions0.flowSensitiveInlineVariables;
        boolean boolean5 = compilerOptions0.ambiguateProperties;
        com.google.javascript.jscomp.CompilerOptions compilerOptions6 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions6.setLooseTypes(true);
        compilerOptions6.checkSuspiciousCode = false;
        com.google.javascript.jscomp.CheckLevel checkLevel11 = compilerOptions6.checkRequires;
        compilerOptions0.checkMissingReturn = checkLevel11;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + checkLevel11 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel11.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test306");
        com.google.javascript.rhino.Context context0 = new com.google.javascript.rhino.Context();
        context0.setGeneratingSource(true);
        java.util.Locale locale3 = context0.getLocale();
        org.junit.Assert.assertNotNull(locale3);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test307");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        compiler1.disableThreads();
        com.google.javascript.jscomp.PerformanceTracker performanceTracker3 = compiler1.tracker;
        com.google.javascript.jscomp.NodeTraversal.Callback callback4 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal5 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler1, callback4);
        com.google.javascript.rhino.Node node7 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node9 = new com.google.javascript.rhino.Node((int) '4');
        node7.addChildrenToBack(node9);
        com.google.javascript.jscomp.DiagnosticType diagnosticType13 = com.google.javascript.jscomp.DiagnosticType.warning("hi!", "hi!");
        com.google.javascript.jscomp.DiagnosticType diagnosticType14 = com.google.javascript.jscomp.Compiler.MOTION_ITERATIONS_ERROR;
        int int15 = diagnosticType13.compareTo(diagnosticType14);
        java.lang.String[] strArray16 = com.google.javascript.rhino.ScriptRuntime.emptyStrings;
        com.google.javascript.jscomp.JSError jSError17 = nodeTraversal5.makeError(node9, diagnosticType13, strArray16);
        java.lang.RuntimeException runtimeException19 = com.google.javascript.rhino.ScriptRuntime.undefCallError((java.lang.Object) nodeTraversal5, (java.lang.Object) (byte) 1);
        com.google.javascript.rhino.Node[] nodeArray20 = new com.google.javascript.rhino.Node[] {};
        nodeTraversal5.traverseRoots(nodeArray20);
        com.google.javascript.jscomp.Compiler compiler22 = nodeTraversal5.getCompiler();
        org.junit.Assert.assertNull(performanceTracker3);
        org.junit.Assert.assertNotNull(diagnosticType13);
        org.junit.Assert.assertNotNull(diagnosticType14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 30 + "'", int15 == 30);
        org.junit.Assert.assertNotNull(strArray16);
        org.junit.Assert.assertNotNull(jSError17);
        org.junit.Assert.assertNotNull(runtimeException19);
        org.junit.Assert.assertNotNull(nodeArray20);
        org.junit.Assert.assertNotNull(compiler22);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test308");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        java.io.PrintStream printStream2 = null;
        com.google.javascript.jscomp.Compiler compiler3 = new com.google.javascript.jscomp.Compiler(printStream2);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile6 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        java.io.Reader reader7 = jSSourceFile6.getCodeReader();
        com.google.javascript.jscomp.JSModule[] jSModuleArray8 = new com.google.javascript.jscomp.JSModule[] {};
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph9 = new com.google.javascript.jscomp.JSModuleGraph(jSModuleArray8);
        com.google.javascript.jscomp.CompilerOptions compilerOptions10 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions10.setLooseTypes(true);
        boolean boolean13 = compilerOptions10.collapseVariableDeclarations;
        compilerOptions10.moveFunctionDeclarations = false;
        boolean boolean16 = compilerOptions10.decomposeExpressions;
        com.google.javascript.jscomp.CheckLevel checkLevel17 = compilerOptions10.checkMissingGetCssNameLevel;
        com.google.javascript.jscomp.Result result18 = compiler3.compile(jSSourceFile6, jSModuleArray8, compilerOptions10);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile21 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile24 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        java.io.Reader reader25 = jSSourceFile24.getCodeReader();
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray26 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile6, jSSourceFile21, jSSourceFile24 };
        java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList27 = new java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile>();
        boolean boolean28 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList27, jSSourceFileArray26);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile31 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray32 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile31 };
        java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList33 = new java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile>();
        boolean boolean34 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList33, jSSourceFileArray32);
        com.google.javascript.jscomp.CompilerOptions compilerOptions35 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions35.setLooseTypes(true);
        boolean boolean38 = compilerOptions35.reserveRawExports;
        compilerOptions35.extractPrototypeMemberDeclarations = false;
        java.lang.String str41 = compilerOptions35.nameReferenceGraphPath;
        compilerOptions35.setSummaryDetailLevel(0);
        com.google.javascript.jscomp.Result result44 = compiler1.compile((java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList27, (java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList33, compilerOptions35);
        boolean boolean45 = compilerOptions35.labelRenaming;
        boolean boolean46 = compilerOptions35.prettyPrint;
        com.google.javascript.jscomp.CompilerOptions compilerOptions47 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions47.setLooseTypes(true);
        boolean boolean50 = compilerOptions47.reserveRawExports;
        com.google.javascript.jscomp.CheckLevel checkLevel51 = null;
        compilerOptions47.checkUnreachableCode = checkLevel51;
        boolean boolean53 = compilerOptions47.devirtualizePrototypeMethods;
        compilerOptions47.setColorizeErrorOutput(true);
        compilerOptions47.setTweakToNumberLiteral("language version", (int) (byte) 10);
        com.google.javascript.jscomp.SourceMap.DetailLevel detailLevel59 = compilerOptions47.sourceMapDetailLevel;
        compilerOptions35.sourceMapDetailLevel = detailLevel59;
        compilerOptions35.setRemoveClosureAsserts(false);
        org.junit.Assert.assertNotNull(jSSourceFile6);
        org.junit.Assert.assertNotNull(reader7);
        org.junit.Assert.assertNotNull(jSModuleArray8);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + checkLevel17 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel17.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(result18);
        org.junit.Assert.assertNotNull(jSSourceFile21);
        org.junit.Assert.assertNotNull(jSSourceFile24);
        org.junit.Assert.assertNotNull(reader25);
        org.junit.Assert.assertNotNull(jSSourceFileArray26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(jSSourceFile31);
        org.junit.Assert.assertNotNull(jSSourceFileArray32);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNull(str41);
        org.junit.Assert.assertNotNull(result44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNotNull(detailLevel59);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test309");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setLooseTypes(true);
        boolean boolean3 = compilerOptions0.collapseVariableDeclarations;
        boolean boolean4 = compilerOptions0.generateExports;
        com.google.javascript.jscomp.SourceMap.DetailLevel detailLevel5 = compilerOptions0.sourceMapDetailLevel;
        compilerOptions0.rewriteFunctionExpressions = true;
        com.google.javascript.jscomp.CheckLevel checkLevel8 = compilerOptions0.checkFunctions;
        compilerOptions0.flowSensitiveInlineVariables = true;
        com.google.javascript.jscomp.CompilerOptions compilerOptions11 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions11.setLooseTypes(true);
        boolean boolean14 = compilerOptions11.collapseVariableDeclarations;
        boolean boolean15 = compilerOptions11.generateExports;
        com.google.javascript.jscomp.SourceMap.DetailLevel detailLevel16 = compilerOptions11.sourceMapDetailLevel;
        compilerOptions0.sourceMapDetailLevel = detailLevel16;
        com.google.common.collect.Multimap<com.google.javascript.jscomp.CustomPassExecutionTime, com.google.javascript.jscomp.CompilerPass> customPassExecutionTimeMultimap18 = null;
        compilerOptions0.customPasses = customPassExecutionTimeMultimap18;
        boolean boolean20 = compilerOptions0.generateExports;
        compilerOptions0.setGenerateExports(false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(detailLevel5);
        org.junit.Assert.assertTrue("'" + checkLevel8 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel8.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(detailLevel16);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test310");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setLooseTypes(true);
        compilerOptions0.checkSuspiciousCode = false;
        compilerOptions0.disambiguateProperties = true;
        java.util.Map<java.lang.String, com.google.javascript.rhino.Node> strMap7 = compilerOptions0.getDefineReplacements();
        compilerOptions0.checkDuplicateMessages = false;
        compilerOptions0.extractPrototypeMemberDeclarations = true;
        compilerOptions0.inlineFunctions = true;
        boolean boolean14 = compilerOptions0.labelRenaming;
        boolean boolean15 = compilerOptions0.markAsCompiled;
        org.junit.Assert.assertNotNull(strMap7);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test311");
        try {
            java.lang.String str2 = com.google.javascript.rhino.ScriptRuntime.escapeString("error reporter", 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: FAILED ASSERTION");
        } catch (java.lang.IllegalStateException e) {
        }
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test312");
        java.util.logging.Logger logger0 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager1 = new com.google.javascript.jscomp.LoggerErrorManager(logger0);
        com.google.javascript.jscomp.CompilerOptions compilerOptions2 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions2.setLooseTypes(true);
        compilerOptions2.convertToDottedProperties = false;
        com.google.javascript.jscomp.CheckLevel checkLevel7 = compilerOptions2.reportMissingOverride;
        com.google.javascript.rhino.Node node10 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node12 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node14 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node16 = new com.google.javascript.rhino.Node((int) '4');
        node14.addChildrenToBack(node16);
        node10.addChildAfter(node12, node16);
        com.google.javascript.rhino.Node node20 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node22 = new com.google.javascript.rhino.Node((int) '4');
        node20.addChildrenToBack(node22);
        com.google.javascript.rhino.Node node24 = node10.copyInformationFromForTree(node22);
        com.google.javascript.jscomp.DiagnosticType diagnosticType25 = com.google.javascript.jscomp.Compiler.MOTION_ITERATIONS_ERROR;
        java.lang.String str26 = diagnosticType25.toString();
        java.lang.String[] strArray27 = null;
        com.google.javascript.jscomp.JSError jSError28 = com.google.javascript.jscomp.JSError.make("", node22, diagnosticType25, strArray27);
        java.lang.String str29 = jSError28.toString();
        loggerErrorManager1.println(checkLevel7, jSError28);
        int int31 = loggerErrorManager1.getWarningCount();
        int int32 = loggerErrorManager1.getWarningCount();
        com.google.javascript.jscomp.Compiler compiler33 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager1);
        java.io.PrintStream printStream34 = null;
        com.google.javascript.jscomp.Compiler compiler35 = new com.google.javascript.jscomp.Compiler(printStream34);
        compiler35.disableThreads();
        com.google.javascript.jscomp.PerformanceTracker performanceTracker37 = compiler35.tracker;
        com.google.javascript.jscomp.NodeTraversal.Callback callback38 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal39 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler35, callback38);
        com.google.javascript.jscomp.Compiler compiler40 = nodeTraversal39.getCompiler();
        com.google.javascript.jscomp.SourceExcerptProvider.SourceExcerpt sourceExcerpt41 = null;
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter42 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler40, sourceExcerpt41);
        com.google.javascript.jscomp.Compiler.IntermediateState intermediateState43 = compiler40.getState();
        compiler33.setState(intermediateState43);
        org.junit.Assert.assertTrue("'" + checkLevel7 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel7.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertNotNull(diagnosticType25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}" + "'", str26.equals("JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}"));
        org.junit.Assert.assertNotNull(jSError28);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "JSC_OPTIMIZE_LOOP_ERROR. Exceeded max number of code motion iterations: {0} at (unknown source) line (unknown line) : (unknown column)" + "'", str29.equals("JSC_OPTIMIZE_LOOP_ERROR. Exceeded max number of code motion iterations: {0} at (unknown source) line (unknown line) : (unknown column)"));
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertNull(performanceTracker37);
        org.junit.Assert.assertNotNull(compiler40);
        org.junit.Assert.assertNotNull(intermediateState43);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test313");
        com.google.javascript.rhino.Node node3 = new com.google.javascript.rhino.Node(30, 35, 8);
        com.google.javascript.rhino.Node node4 = node3.getLastSibling();
        com.google.javascript.rhino.Node node5 = node4.removeChildren();
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNull(node5);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test314");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setLooseTypes(true);
        boolean boolean3 = compilerOptions0.collapseVariableDeclarations;
        compilerOptions0.aliasExternals = true;
        com.google.javascript.jscomp.CheckLevel checkLevel6 = compilerOptions0.checkMissingGetCssNameLevel;
        com.google.javascript.jscomp.SourceMap.DetailLevel detailLevel7 = compilerOptions0.sourceMapDetailLevel;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + checkLevel6 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel6.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(detailLevel7);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test315");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setLooseTypes(true);
        compilerOptions0.convertToDottedProperties = false;
        boolean boolean5 = compilerOptions0.removeTryCatchFinally;
        compilerOptions0.aliasStringsBlacklist = "()";
        boolean boolean8 = compilerOptions0.tightenTypes;
        boolean boolean9 = compilerOptions0.checkEs5Strict;
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test316");
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention0 = new com.google.javascript.jscomp.DefaultCodingConvention();
        boolean boolean2 = defaultCodingConvention0.isExported("// Input %num%");
        com.google.javascript.rhino.Node node4 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node6 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node8 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node10 = new com.google.javascript.rhino.Node((int) '4');
        node8.addChildrenToBack(node10);
        node4.addChildAfter(node6, node10);
        com.google.javascript.rhino.Node node14 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node16 = new com.google.javascript.rhino.Node((int) '4');
        node14.addChildrenToBack(node16);
        com.google.javascript.rhino.Node node18 = node4.copyInformationFromForTree(node16);
        com.google.javascript.rhino.Node node19 = node4.cloneTree();
        com.google.javascript.rhino.Node node23 = new com.google.javascript.rhino.Node(30, 35, 8);
        com.google.javascript.rhino.Node node24 = node23.getLastChild();
        node19.addChildToFront(node23);
        java.lang.String str26 = defaultCodingConvention0.getSingletonGetterClassName(node23);
        boolean boolean29 = defaultCodingConvention0.isExported("error reporter", false);
        java.io.PrintStream printStream30 = null;
        com.google.javascript.jscomp.Compiler compiler31 = new com.google.javascript.jscomp.Compiler(printStream30);
        compiler31.disableThreads();
        com.google.javascript.jscomp.PerformanceTracker performanceTracker33 = compiler31.tracker;
        com.google.javascript.jscomp.NodeTraversal.Callback callback34 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal35 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler31, callback34);
        com.google.javascript.rhino.Node node37 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node39 = new com.google.javascript.rhino.Node((int) '4');
        node37.addChildrenToBack(node39);
        com.google.javascript.jscomp.DiagnosticType diagnosticType43 = com.google.javascript.jscomp.DiagnosticType.warning("hi!", "hi!");
        com.google.javascript.jscomp.DiagnosticType diagnosticType44 = com.google.javascript.jscomp.Compiler.MOTION_ITERATIONS_ERROR;
        int int45 = diagnosticType43.compareTo(diagnosticType44);
        java.lang.String[] strArray46 = com.google.javascript.rhino.ScriptRuntime.emptyStrings;
        com.google.javascript.jscomp.JSError jSError47 = nodeTraversal35.makeError(node39, diagnosticType43, strArray46);
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship48 = defaultCodingConvention0.getDelegateRelationship(node39);
        int int49 = node39.getType();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNull(node24);
        org.junit.Assert.assertNull(str26);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNull(performanceTracker33);
        org.junit.Assert.assertNotNull(diagnosticType43);
        org.junit.Assert.assertNotNull(diagnosticType44);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 30 + "'", int45 == 30);
        org.junit.Assert.assertNotNull(strArray46);
        org.junit.Assert.assertNotNull(jSError47);
        org.junit.Assert.assertNull(delegateRelationship48);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 52 + "'", int49 == 52);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test317");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setLooseTypes(true);
        compilerOptions0.checkSuspiciousCode = false;
        com.google.common.collect.Multimap<com.google.javascript.jscomp.CustomPassExecutionTime, com.google.javascript.jscomp.CompilerPass> customPassExecutionTimeMultimap5 = compilerOptions0.customPasses;
        compilerOptions0.inlineLocalFunctions = false;
        compilerOptions0.closurePass = true;
        boolean boolean10 = compilerOptions0.foldConstants;
        org.junit.Assert.assertNull(customPassExecutionTimeMultimap5);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test318");
        com.google.javascript.rhino.Node.SideEffectFlags sideEffectFlags1 = new com.google.javascript.rhino.Node.SideEffectFlags(30);
        boolean boolean2 = sideEffectFlags1.areAllFlagsSet();
        sideEffectFlags1.setMutatesGlobalState();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test319");
        try {
            com.google.javascript.rhino.Context.checkOptimizationLevel((int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Optimization level outside [-1..9]: 10");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test320");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setLooseTypes(true);
        boolean boolean3 = compilerOptions0.reserveRawExports;
        com.google.javascript.jscomp.CheckLevel checkLevel4 = null;
        compilerOptions0.checkUnreachableCode = checkLevel4;
        com.google.javascript.jscomp.CheckLevel checkLevel6 = compilerOptions0.reportUnknownTypes;
        java.util.Set<java.lang.String> strSet7 = compilerOptions0.stripTypePrefixes;
        boolean boolean8 = compilerOptions0.inferTypesInGlobalScope;
        com.google.javascript.jscomp.SourceMap.Format format9 = compilerOptions0.sourceMapFormat;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + checkLevel6 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel6.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(strSet7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(format9);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test321");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.AMBIGUOUS_FUNCTION_DECL;
        com.google.javascript.jscomp.DiagnosticGroups.TWEAKS = diagnosticGroup0;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test322");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setLooseTypes(true);
        compilerOptions0.renamePrefix = "hi!";
        java.lang.String str5 = compilerOptions0.locale;
        compilerOptions0.setNameAnonymousFunctionsOnly(false);
        boolean boolean8 = compilerOptions0.decomposeExpressions;
        java.lang.String str9 = compilerOptions0.syntheticBlockStartMarker;
        com.google.javascript.jscomp.CompilerOptions.TracerMode tracerMode10 = compilerOptions0.tracer;
        com.google.javascript.jscomp.DefaultPassConfig defaultPassConfig11 = new com.google.javascript.jscomp.DefaultPassConfig(compilerOptions0);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertTrue("'" + tracerMode10 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TracerMode.OFF + "'", tracerMode10.equals(com.google.javascript.jscomp.CompilerOptions.TracerMode.OFF));
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test323");
        com.google.javascript.rhino.Node node1 = new com.google.javascript.rhino.Node(100);
        try {
            node1.setSideEffectFlags(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: setIsNoSideEffectsCall only supports CALL and NEW nodes, got OR");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test324");
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention0 = new com.google.javascript.jscomp.DefaultCodingConvention();
        boolean boolean2 = defaultCodingConvention0.isExported("// Input %num%");
        com.google.javascript.rhino.Node node4 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node6 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node8 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node10 = new com.google.javascript.rhino.Node((int) '4');
        node8.addChildrenToBack(node10);
        node4.addChildAfter(node6, node10);
        com.google.javascript.rhino.Node node14 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node16 = new com.google.javascript.rhino.Node((int) '4');
        node14.addChildrenToBack(node16);
        com.google.javascript.rhino.Node node18 = node4.copyInformationFromForTree(node16);
        com.google.javascript.rhino.Node node19 = node4.cloneTree();
        com.google.javascript.rhino.Node node23 = new com.google.javascript.rhino.Node(30, 35, 8);
        com.google.javascript.rhino.Node node24 = node23.getLastChild();
        node19.addChildToFront(node23);
        java.lang.String str26 = defaultCodingConvention0.getSingletonGetterClassName(node23);
        boolean boolean27 = node23.isOptionalArg();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNull(node24);
        org.junit.Assert.assertNull(str26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test325");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setLooseTypes(true);
        boolean boolean3 = compilerOptions0.collapseVariableDeclarations;
        boolean boolean4 = compilerOptions0.generateExports;
        com.google.javascript.jscomp.SourceMap.DetailLevel detailLevel5 = compilerOptions0.sourceMapDetailLevel;
        compilerOptions0.rewriteFunctionExpressions = true;
        com.google.javascript.jscomp.CheckLevel checkLevel8 = compilerOptions0.checkFunctions;
        compilerOptions0.flowSensitiveInlineVariables = true;
        java.lang.String str11 = compilerOptions0.jsOutputFile;
        compilerOptions0.specializeInitialModule = true;
        java.lang.String str14 = compilerOptions0.unaliasableGlobals;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(detailLevel5);
        org.junit.Assert.assertTrue("'" + checkLevel8 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel8.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertNull(str14);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test326");
        com.google.javascript.rhino.Context context0 = new com.google.javascript.rhino.Context();
        context0.setGeneratingSource(true);
        boolean boolean3 = context0.isGeneratingDebug();
        com.google.javascript.jscomp.SourceAst sourceAst4 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput7 = new com.google.javascript.jscomp.CompilerInput(sourceAst4, "", false);
        boolean boolean8 = compilerInput7.isExtern();
        java.lang.Object obj9 = context0.getThreadLocal((java.lang.Object) boolean8);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNull(obj9);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test327");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setLooseTypes(true);
        compilerOptions0.convertToDottedProperties = false;
        boolean boolean5 = compilerOptions0.removeTryCatchFinally;
        compilerOptions0.aliasStringsBlacklist = "()";
        java.lang.String str8 = compilerOptions0.aliasStringsBlacklist;
        compilerOptions0.syntheticBlockStartMarker = "33";
        boolean boolean11 = compilerOptions0.extractPrototypeMemberDeclarations;
        boolean boolean12 = compilerOptions0.groupVariableDeclarations;
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "()" + "'", str8.equals("()"));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test328");
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention1 = new com.google.javascript.jscomp.DefaultCodingConvention();
        com.google.javascript.rhino.Node node3 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node5 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node7 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node9 = new com.google.javascript.rhino.Node((int) '4');
        node7.addChildrenToBack(node9);
        node3.addChildAfter(node5, node9);
        com.google.javascript.rhino.Node node12 = node3.getFirstChild();
        node3.putIntProp(45, 4095);
        com.google.javascript.jscomp.CodingConvention.SubclassRelationship subclassRelationship16 = defaultCodingConvention1.getClassesDefinedByCall(node3);
        com.google.javascript.rhino.Node node18 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node20 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node22 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node24 = new com.google.javascript.rhino.Node((int) '4');
        node22.addChildrenToBack(node24);
        node18.addChildAfter(node20, node24);
        com.google.javascript.rhino.Node node28 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node30 = new com.google.javascript.rhino.Node((int) '4');
        node28.addChildrenToBack(node30);
        com.google.javascript.rhino.Node node32 = node18.copyInformationFromForTree(node30);
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable33 = node32.siblings();
        com.google.javascript.rhino.Node node35 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node37 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node39 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node41 = new com.google.javascript.rhino.Node((int) '4');
        node39.addChildrenToBack(node41);
        node35.addChildAfter(node37, node41);
        com.google.javascript.rhino.Node node45 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node47 = new com.google.javascript.rhino.Node((int) '4');
        node45.addChildrenToBack(node47);
        com.google.javascript.rhino.Node node49 = node35.copyInformationFromForTree(node47);
        com.google.javascript.rhino.Node node51 = node35.getAncestor(1);
        com.google.javascript.rhino.Node node53 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node55 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node57 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node59 = new com.google.javascript.rhino.Node((int) '4');
        node57.addChildrenToBack(node59);
        node53.addChildAfter(node55, node59);
        com.google.javascript.rhino.Node node63 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node65 = new com.google.javascript.rhino.Node((int) '4');
        node63.addChildrenToBack(node65);
        com.google.javascript.rhino.Node node67 = node53.copyInformationFromForTree(node65);
        com.google.javascript.rhino.Node node69 = node53.getAncestor(1);
        node35.addChildToFront(node53);
        com.google.javascript.rhino.Node node71 = node35.getNext();
        com.google.javascript.rhino.Node node72 = node35.cloneTree();
        boolean boolean73 = node72.isQuotedString();
        com.google.javascript.rhino.Node node76 = new com.google.javascript.rhino.Node(3, node3, node32, node72, 27, 42);
        node72.putBooleanProp(9, false);
        boolean boolean80 = node72.isUnscopedQualifiedName();
        org.junit.Assert.assertNull(node12);
        org.junit.Assert.assertNull(subclassRelationship16);
        org.junit.Assert.assertNotNull(node32);
        org.junit.Assert.assertNotNull(nodeIterable33);
        org.junit.Assert.assertNotNull(node49);
        org.junit.Assert.assertNull(node51);
        org.junit.Assert.assertNotNull(node67);
        org.junit.Assert.assertNull(node69);
        org.junit.Assert.assertNull(node71);
        org.junit.Assert.assertNotNull(node72);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + false + "'", boolean80 == false);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test329");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString(34, "", 4095, (int) '#');
        node4.detachChildren();
        org.junit.Assert.assertNotNull(node4);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test330");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        java.lang.String str1 = closureCodingConvention0.getGlobalObject();
        java.io.PrintStream printStream2 = null;
        com.google.javascript.jscomp.Compiler compiler3 = new com.google.javascript.jscomp.Compiler(printStream2);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile6 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        java.io.Reader reader7 = jSSourceFile6.getCodeReader();
        com.google.javascript.jscomp.JSModule[] jSModuleArray8 = new com.google.javascript.jscomp.JSModule[] {};
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph9 = new com.google.javascript.jscomp.JSModuleGraph(jSModuleArray8);
        com.google.javascript.jscomp.CompilerOptions compilerOptions10 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions10.setLooseTypes(true);
        boolean boolean13 = compilerOptions10.collapseVariableDeclarations;
        compilerOptions10.moveFunctionDeclarations = false;
        boolean boolean16 = compilerOptions10.decomposeExpressions;
        com.google.javascript.jscomp.CheckLevel checkLevel17 = compilerOptions10.checkMissingGetCssNameLevel;
        com.google.javascript.jscomp.Result result18 = compiler3.compile(jSSourceFile6, jSModuleArray8, compilerOptions10);
        int int19 = compiler3.getErrorCount();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry20 = compiler3.getTypeRegistry();
        com.google.javascript.jscomp.Scope scope21 = null;
        com.google.javascript.rhino.jstype.ObjectType[] objectTypeArray22 = new com.google.javascript.rhino.jstype.ObjectType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.ObjectType> objectTypeList23 = new java.util.ArrayList<com.google.javascript.rhino.jstype.ObjectType>();
        boolean boolean24 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.ObjectType>) objectTypeList23, objectTypeArray22);
        closureCodingConvention0.defineDelegateProxyPrototypeProperties(jSTypeRegistry20, scope21, (java.util.List<com.google.javascript.rhino.jstype.ObjectType>) objectTypeList23);
        com.google.javascript.rhino.jstype.ObjectType objectType26 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType27 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType28 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType29 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType30 = null;
        closureCodingConvention0.applyDelegateRelationship(objectType26, objectType27, objectType28, functionType29, functionType30);
        com.google.javascript.rhino.Node node33 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node35 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node37 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node39 = new com.google.javascript.rhino.Node((int) '4');
        node37.addChildrenToBack(node39);
        node33.addChildAfter(node35, node39);
        com.google.javascript.rhino.Node node43 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node45 = new com.google.javascript.rhino.Node((int) '4');
        node43.addChildrenToBack(node45);
        com.google.javascript.rhino.Node node47 = node33.copyInformationFromForTree(node45);
        com.google.javascript.rhino.Node node49 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node50 = node33.copyInformationFromForTree(node49);
        java.util.Set<java.lang.String> strSet51 = node50.getDirectives();
        com.google.javascript.rhino.Node node53 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node55 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node57 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node59 = new com.google.javascript.rhino.Node((int) '4');
        node57.addChildrenToBack(node59);
        node53.addChildAfter(node55, node59);
        com.google.javascript.rhino.Node node63 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node65 = new com.google.javascript.rhino.Node((int) '4');
        node63.addChildrenToBack(node65);
        com.google.javascript.rhino.Node node67 = node53.copyInformationFromForTree(node65);
        com.google.javascript.rhino.Node node68 = node53.cloneTree();
        com.google.javascript.rhino.Node node72 = new com.google.javascript.rhino.Node(30, 35, 8);
        com.google.javascript.rhino.Node node73 = node72.getLastChild();
        node68.addChildToFront(node72);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder75 = node72.getJsDocBuilderForNode();
        java.lang.String str76 = closureCodingConvention0.extractClassNameIfRequire(node50, node72);
        java.lang.String str77 = closureCodingConvention0.getGlobalObject();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "goog.global" + "'", str1.equals("goog.global"));
        org.junit.Assert.assertNotNull(jSSourceFile6);
        org.junit.Assert.assertNotNull(reader7);
        org.junit.Assert.assertNotNull(jSModuleArray8);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + checkLevel17 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel17.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(result18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertNotNull(jSTypeRegistry20);
        org.junit.Assert.assertNotNull(objectTypeArray22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(node47);
        org.junit.Assert.assertNotNull(node50);
        org.junit.Assert.assertNull(strSet51);
        org.junit.Assert.assertNotNull(node67);
        org.junit.Assert.assertNotNull(node68);
        org.junit.Assert.assertNull(node73);
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder75);
        org.junit.Assert.assertNull(str76);
        org.junit.Assert.assertTrue("'" + str77 + "' != '" + "goog.global" + "'", str77.equals("goog.global"));
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test331");
        com.google.javascript.rhino.Node.SideEffectFlags sideEffectFlags1 = new com.google.javascript.rhino.Node.SideEffectFlags(30);
        sideEffectFlags1.setMutatesGlobalState();
        sideEffectFlags1.setReturnsTainted();
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test332");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setLooseTypes(true);
        boolean boolean3 = compilerOptions0.reserveRawExports;
        com.google.javascript.jscomp.CheckLevel checkLevel4 = null;
        compilerOptions0.checkUnreachableCode = checkLevel4;
        com.google.javascript.jscomp.MessageBundle messageBundle6 = compilerOptions0.messageBundle;
        java.lang.String str7 = compilerOptions0.sourceMapOutputPath;
        compilerOptions0.generateExports = true;
        com.google.javascript.jscomp.CompilerOptions compilerOptions10 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions10.setLooseTypes(true);
        boolean boolean13 = compilerOptions10.reserveRawExports;
        compilerOptions10.extractPrototypeMemberDeclarations = false;
        boolean boolean16 = compilerOptions10.disambiguateProperties;
        com.google.javascript.jscomp.CheckLevel checkLevel17 = compilerOptions10.aggressiveVarCheck;
        compilerOptions0.checkProvides = checkLevel17;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(messageBundle6);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + checkLevel17 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel17.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test333");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setLooseTypes(true);
        boolean boolean3 = compilerOptions0.collapseVariableDeclarations;
        boolean boolean4 = compilerOptions0.generateExports;
        boolean boolean5 = compilerOptions0.checkTypes;
        compilerOptions0.setRemoveClosureAsserts(false);
        com.google.javascript.jscomp.CheckLevel checkLevel8 = compilerOptions0.reportUnknownTypes;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + checkLevel8 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel8.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test334");
        com.google.javascript.rhino.Node node2 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node4 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node6 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node8 = new com.google.javascript.rhino.Node((int) '4');
        node6.addChildrenToBack(node8);
        node2.addChildAfter(node4, node8);
        com.google.javascript.rhino.Node node12 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node14 = new com.google.javascript.rhino.Node((int) '4');
        node12.addChildrenToBack(node14);
        com.google.javascript.rhino.Node node16 = node2.copyInformationFromForTree(node14);
        com.google.javascript.rhino.Node node18 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node19 = node2.copyInformationFromForTree(node18);
        com.google.javascript.rhino.Node node20 = com.google.javascript.jscomp.NodeUtil.newExpr(node19);
        int int21 = node20.getType();
        com.google.javascript.rhino.Node node25 = new com.google.javascript.rhino.Node(30, 35, 8);
        com.google.javascript.rhino.Node node26 = node25.getLastSibling();
        node20.addChildrenToBack(node25);
        com.google.javascript.rhino.JSDocInfo jSDocInfo28 = node20.getJSDocInfo();
        com.google.javascript.rhino.Node node30 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node32 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node34 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node36 = new com.google.javascript.rhino.Node((int) '4');
        node34.addChildrenToBack(node36);
        node30.addChildAfter(node32, node36);
        com.google.javascript.rhino.Node node40 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node42 = new com.google.javascript.rhino.Node((int) '4');
        node40.addChildrenToBack(node42);
        com.google.javascript.rhino.Node node44 = node30.copyInformationFromForTree(node42);
        com.google.javascript.rhino.Node node46 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node47 = node30.copyInformationFromForTree(node46);
        com.google.javascript.rhino.JSDocInfo jSDocInfo48 = null;
        node46.setJSDocInfo(jSDocInfo48);
        com.google.javascript.rhino.Node node51 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node53 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node55 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node57 = new com.google.javascript.rhino.Node((int) '4');
        node55.addChildrenToBack(node57);
        node51.addChildAfter(node53, node57);
        com.google.javascript.rhino.Node node61 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node63 = new com.google.javascript.rhino.Node((int) '4');
        node61.addChildrenToBack(node63);
        com.google.javascript.rhino.Node node65 = node51.copyInformationFromForTree(node63);
        com.google.javascript.rhino.Node node67 = node51.getAncestor(1);
        com.google.javascript.rhino.Node node69 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node71 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node73 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node75 = new com.google.javascript.rhino.Node((int) '4');
        node73.addChildrenToBack(node75);
        node69.addChildAfter(node71, node75);
        com.google.javascript.rhino.Node node79 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node81 = new com.google.javascript.rhino.Node((int) '4');
        node79.addChildrenToBack(node81);
        com.google.javascript.rhino.Node node83 = node69.copyInformationFromForTree(node81);
        com.google.javascript.rhino.Node node85 = node69.getAncestor(1);
        node51.addChildToFront(node69);
        node51.setIsSyntheticBlock(true);
        node46.addChildrenToBack(node51);
        java.util.Set<java.lang.String> strSet90 = node51.getDirectives();
        com.google.javascript.rhino.Node node92 = new com.google.javascript.rhino.Node((int) '4');
        node92.setLineno(36);
        try {
            com.google.javascript.rhino.Node node95 = new com.google.javascript.rhino.Node(17, node20, node51, node92);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 130 + "'", int21 == 130);
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertNull(jSDocInfo28);
        org.junit.Assert.assertNotNull(node44);
        org.junit.Assert.assertNotNull(node47);
        org.junit.Assert.assertNotNull(node65);
        org.junit.Assert.assertNull(node67);
        org.junit.Assert.assertNotNull(node83);
        org.junit.Assert.assertNull(node85);
        org.junit.Assert.assertNull(strSet90);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test335");
        com.google.javascript.rhino.Node node1 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node3 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node5 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node7 = new com.google.javascript.rhino.Node((int) '4');
        node5.addChildrenToBack(node7);
        node1.addChildAfter(node3, node7);
        com.google.javascript.rhino.Node node10 = node1.cloneTree();
        com.google.javascript.rhino.Node node12 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node14 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node16 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node18 = new com.google.javascript.rhino.Node((int) '4');
        node16.addChildrenToBack(node18);
        node12.addChildAfter(node14, node18);
        com.google.javascript.rhino.Node node22 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node24 = new com.google.javascript.rhino.Node((int) '4');
        node22.addChildrenToBack(node24);
        com.google.javascript.rhino.Node node26 = node12.copyInformationFromForTree(node24);
        com.google.javascript.rhino.Node node27 = node12.cloneTree();
        com.google.javascript.rhino.Node node31 = new com.google.javascript.rhino.Node(30, 35, 8);
        com.google.javascript.rhino.Node node32 = node31.getLastChild();
        node27.addChildToFront(node31);
        node1.addChildToFront(node27);
        java.lang.Appendable appendable35 = null;
        try {
            node1.appendStringTree(appendable35);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertNotNull(node27);
        org.junit.Assert.assertNull(node32);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test336");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        compiler1.disableThreads();
        com.google.javascript.jscomp.PerformanceTracker performanceTracker3 = compiler1.tracker;
        com.google.javascript.jscomp.NodeTraversal.Callback callback4 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal5 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler1, callback4);
        java.io.PrintStream printStream6 = null;
        com.google.javascript.jscomp.Compiler compiler7 = new com.google.javascript.jscomp.Compiler(printStream6);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile10 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        java.io.Reader reader11 = jSSourceFile10.getCodeReader();
        com.google.javascript.jscomp.JSModule[] jSModuleArray12 = new com.google.javascript.jscomp.JSModule[] {};
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph13 = new com.google.javascript.jscomp.JSModuleGraph(jSModuleArray12);
        com.google.javascript.jscomp.CompilerOptions compilerOptions14 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions14.setLooseTypes(true);
        boolean boolean17 = compilerOptions14.collapseVariableDeclarations;
        compilerOptions14.moveFunctionDeclarations = false;
        boolean boolean20 = compilerOptions14.decomposeExpressions;
        com.google.javascript.jscomp.CheckLevel checkLevel21 = compilerOptions14.checkMissingGetCssNameLevel;
        com.google.javascript.jscomp.Result result22 = compiler7.compile(jSSourceFile10, jSModuleArray12, compilerOptions14);
        java.io.PrintStream printStream23 = null;
        com.google.javascript.jscomp.Compiler compiler24 = new com.google.javascript.jscomp.Compiler(printStream23);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile27 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        java.io.Reader reader28 = jSSourceFile27.getCodeReader();
        com.google.javascript.jscomp.JSModule[] jSModuleArray29 = new com.google.javascript.jscomp.JSModule[] {};
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph30 = new com.google.javascript.jscomp.JSModuleGraph(jSModuleArray29);
        com.google.javascript.jscomp.CompilerOptions compilerOptions31 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions31.setLooseTypes(true);
        boolean boolean34 = compilerOptions31.collapseVariableDeclarations;
        compilerOptions31.moveFunctionDeclarations = false;
        boolean boolean37 = compilerOptions31.decomposeExpressions;
        com.google.javascript.jscomp.CheckLevel checkLevel38 = compilerOptions31.checkMissingGetCssNameLevel;
        com.google.javascript.jscomp.Result result39 = compiler24.compile(jSSourceFile27, jSModuleArray29, compilerOptions31);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile42 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        java.io.PrintStream printStream43 = null;
        com.google.javascript.jscomp.Compiler compiler44 = new com.google.javascript.jscomp.Compiler(printStream43);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile47 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        java.io.Reader reader48 = jSSourceFile47.getCodeReader();
        com.google.javascript.jscomp.JSModule[] jSModuleArray49 = new com.google.javascript.jscomp.JSModule[] {};
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph50 = new com.google.javascript.jscomp.JSModuleGraph(jSModuleArray49);
        com.google.javascript.jscomp.CompilerOptions compilerOptions51 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions51.setLooseTypes(true);
        boolean boolean54 = compilerOptions51.collapseVariableDeclarations;
        compilerOptions51.moveFunctionDeclarations = false;
        boolean boolean57 = compilerOptions51.decomposeExpressions;
        com.google.javascript.jscomp.CheckLevel checkLevel58 = compilerOptions51.checkMissingGetCssNameLevel;
        com.google.javascript.jscomp.Result result59 = compiler44.compile(jSSourceFile47, jSModuleArray49, compilerOptions51);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile62 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile65 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        java.io.Reader reader66 = jSSourceFile65.getCodeReader();
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray67 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile10, jSSourceFile27, jSSourceFile42, jSSourceFile47, jSSourceFile62, jSSourceFile65 };
        java.io.PrintStream printStream68 = null;
        com.google.javascript.jscomp.Compiler compiler69 = new com.google.javascript.jscomp.Compiler(printStream68);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile72 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        java.io.Reader reader73 = jSSourceFile72.getCodeReader();
        com.google.javascript.jscomp.JSModule[] jSModuleArray74 = new com.google.javascript.jscomp.JSModule[] {};
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph75 = new com.google.javascript.jscomp.JSModuleGraph(jSModuleArray74);
        com.google.javascript.jscomp.CompilerOptions compilerOptions76 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions76.setLooseTypes(true);
        boolean boolean79 = compilerOptions76.collapseVariableDeclarations;
        compilerOptions76.moveFunctionDeclarations = false;
        boolean boolean82 = compilerOptions76.decomposeExpressions;
        com.google.javascript.jscomp.CheckLevel checkLevel83 = compilerOptions76.checkMissingGetCssNameLevel;
        com.google.javascript.jscomp.Result result84 = compiler69.compile(jSSourceFile72, jSModuleArray74, compilerOptions76);
        com.google.javascript.jscomp.CompilerOptions compilerOptions85 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions85.setLooseTypes(true);
        boolean boolean88 = compilerOptions85.collapseVariableDeclarations;
        compilerOptions85.setManageClosureDependencies(false);
        com.google.javascript.jscomp.Result result91 = compiler1.compile(jSSourceFileArray67, jSModuleArray74, compilerOptions85);
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph92 = new com.google.javascript.jscomp.JSModuleGraph(jSModuleArray74);
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph93 = new com.google.javascript.jscomp.JSModuleGraph(jSModuleArray74);
        jSModuleGraph93.coalesceDuplicateFiles();
        org.junit.Assert.assertNull(performanceTracker3);
        org.junit.Assert.assertNotNull(jSSourceFile10);
        org.junit.Assert.assertNotNull(reader11);
        org.junit.Assert.assertNotNull(jSModuleArray12);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + checkLevel21 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel21.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(result22);
        org.junit.Assert.assertNotNull(jSSourceFile27);
        org.junit.Assert.assertNotNull(reader28);
        org.junit.Assert.assertNotNull(jSModuleArray29);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + checkLevel38 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel38.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(result39);
        org.junit.Assert.assertNotNull(jSSourceFile42);
        org.junit.Assert.assertNotNull(jSSourceFile47);
        org.junit.Assert.assertNotNull(reader48);
        org.junit.Assert.assertNotNull(jSModuleArray49);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertTrue("'" + checkLevel58 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel58.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(result59);
        org.junit.Assert.assertNotNull(jSSourceFile62);
        org.junit.Assert.assertNotNull(jSSourceFile65);
        org.junit.Assert.assertNotNull(reader66);
        org.junit.Assert.assertNotNull(jSSourceFileArray67);
        org.junit.Assert.assertNotNull(jSSourceFile72);
        org.junit.Assert.assertNotNull(reader73);
        org.junit.Assert.assertNotNull(jSModuleArray74);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
        org.junit.Assert.assertTrue("'" + checkLevel83 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel83.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(result84);
        org.junit.Assert.assertTrue("'" + boolean88 + "' != '" + false + "'", boolean88 == false);
        org.junit.Assert.assertNotNull(result91);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test337");
        com.google.javascript.rhino.Node node1 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node3 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node5 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node7 = new com.google.javascript.rhino.Node((int) '4');
        node5.addChildrenToBack(node7);
        node1.addChildAfter(node3, node7);
        int int10 = node1.getSideEffectFlags();
        try {
            com.google.javascript.rhino.Node node11 = node1.detachFromParent();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test338");
        com.google.javascript.rhino.Context context0 = new com.google.javascript.rhino.Context();
        context0.setGeneratingSource(true);
        com.google.javascript.jscomp.CompilerOptions.TracerMode tracerMode3 = com.google.javascript.jscomp.CompilerOptions.TracerMode.FAST;
        context0.removeThreadLocal((java.lang.Object) tracerMode3);
        boolean boolean5 = context0.isGeneratingSource();
        java.util.Locale locale6 = context0.getLocale();
        java.lang.String str7 = context0.getImplementationVersion();
        org.junit.Assert.assertTrue("'" + tracerMode3 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TracerMode.FAST + "'", tracerMode3.equals(com.google.javascript.jscomp.CompilerOptions.TracerMode.FAST));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(locale6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "@IMPLEMENTATION.VERSION@" + "'", str7.equals("@IMPLEMENTATION.VERSION@"));
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test339");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile4 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile7 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        java.io.Reader reader8 = jSSourceFile7.getCodeReader();
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray9 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile4, jSSourceFile7 };
        java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList10 = new java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile>();
        boolean boolean11 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList10, jSSourceFileArray9);
        com.google.javascript.jscomp.JSModule[] jSModuleArray12 = new com.google.javascript.jscomp.JSModule[] {};
        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList13 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
        boolean boolean14 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList13, jSModuleArray12);
        com.google.javascript.jscomp.CompilerOptions compilerOptions15 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions15.setLooseTypes(true);
        boolean boolean18 = compilerOptions15.reserveRawExports;
        compilerOptions15.extractPrototypeMemberDeclarations = false;
        java.lang.String str21 = compilerOptions15.nameReferenceGraphPath;
        compilerOptions15.computeFunctionSideEffects = true;
        com.google.javascript.jscomp.CompilerOptions compilerOptions24 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions24.setLooseTypes(true);
        compilerOptions24.convertToDottedProperties = false;
        com.google.javascript.jscomp.CheckLevel checkLevel29 = compilerOptions24.reportMissingOverride;
        compilerOptions15.brokenClosureRequiresLevel = checkLevel29;
        java.util.Set<java.lang.String> strSet31 = compilerOptions15.stripTypePrefixes;
        compilerOptions15.deadAssignmentElimination = false;
        compiler1.initModules((java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList10, (java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList13, compilerOptions15);
        compiler1.disableThreads();
        com.google.javascript.jscomp.JSModule jSModule36 = null;
        try {
            java.lang.String[] strArray37 = compiler1.toSourceArray(jSModule36);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: java.lang.NullPointerException");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile4);
        org.junit.Assert.assertNotNull(jSSourceFile7);
        org.junit.Assert.assertNotNull(reader8);
        org.junit.Assert.assertNotNull(jSSourceFileArray9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(jSModuleArray12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertTrue("'" + checkLevel29 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel29.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(strSet31);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test340");
        com.google.javascript.rhino.Node node1 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node3 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node5 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node7 = new com.google.javascript.rhino.Node((int) '4');
        node5.addChildrenToBack(node7);
        node1.addChildAfter(node3, node7);
        com.google.javascript.rhino.Node node11 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node((int) '4');
        node11.addChildrenToBack(node13);
        com.google.javascript.rhino.Node node15 = node1.copyInformationFromForTree(node13);
        com.google.javascript.rhino.Node node17 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node18 = node1.copyInformationFromForTree(node17);
        com.google.javascript.rhino.Node node19 = com.google.javascript.jscomp.NodeUtil.newExpr(node18);
        com.google.javascript.rhino.jstype.JSType jSType20 = node19.getJSType();
        boolean boolean21 = node19.isQuotedString();
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNull(jSType20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test341");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setLooseTypes(true);
        boolean boolean3 = compilerOptions0.reserveRawExports;
        compilerOptions0.extractPrototypeMemberDeclarations = false;
        com.google.javascript.jscomp.CheckLevel checkLevel6 = compilerOptions0.aggressiveVarCheck;
        boolean boolean7 = compilerOptions0.foldConstants;
        java.lang.String str8 = compilerOptions0.instrumentationTemplate;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + checkLevel6 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel6.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(str8);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test342");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        compiler1.disableThreads();
        com.google.javascript.jscomp.PerformanceTracker performanceTracker3 = compiler1.tracker;
        com.google.javascript.jscomp.NodeTraversal.Callback callback4 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal5 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler1, callback4);
        com.google.javascript.rhino.Node node7 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node9 = new com.google.javascript.rhino.Node((int) '4');
        node7.addChildrenToBack(node9);
        com.google.javascript.jscomp.DiagnosticType diagnosticType13 = com.google.javascript.jscomp.DiagnosticType.warning("hi!", "hi!");
        com.google.javascript.jscomp.DiagnosticType diagnosticType14 = com.google.javascript.jscomp.Compiler.MOTION_ITERATIONS_ERROR;
        int int15 = diagnosticType13.compareTo(diagnosticType14);
        java.lang.String[] strArray16 = com.google.javascript.rhino.ScriptRuntime.emptyStrings;
        com.google.javascript.jscomp.JSError jSError17 = nodeTraversal5.makeError(node9, diagnosticType13, strArray16);
        com.google.javascript.rhino.Node node18 = nodeTraversal5.getEnclosingFunction();
        com.google.javascript.rhino.Node node21 = com.google.javascript.rhino.Node.newString(39, "hi!");
        try {
            nodeTraversal5.traverse(node21);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: INTERNAL COMPILER ERROR.\nPlease report this problem.\nnull");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNull(performanceTracker3);
        org.junit.Assert.assertNotNull(diagnosticType13);
        org.junit.Assert.assertNotNull(diagnosticType14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 30 + "'", int15 == 30);
        org.junit.Assert.assertNotNull(strArray16);
        org.junit.Assert.assertNotNull(jSError17);
        org.junit.Assert.assertNull(node18);
        org.junit.Assert.assertNotNull(node21);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test343");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile4 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        java.io.Reader reader5 = jSSourceFile4.getCodeReader();
        com.google.javascript.jscomp.JSModule[] jSModuleArray6 = new com.google.javascript.jscomp.JSModule[] {};
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph7 = new com.google.javascript.jscomp.JSModuleGraph(jSModuleArray6);
        com.google.javascript.jscomp.CompilerOptions compilerOptions8 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions8.setLooseTypes(true);
        boolean boolean11 = compilerOptions8.collapseVariableDeclarations;
        compilerOptions8.moveFunctionDeclarations = false;
        boolean boolean14 = compilerOptions8.decomposeExpressions;
        com.google.javascript.jscomp.CheckLevel checkLevel15 = compilerOptions8.checkMissingGetCssNameLevel;
        com.google.javascript.jscomp.Result result16 = compiler1.compile(jSSourceFile4, jSModuleArray6, compilerOptions8);
        com.google.javascript.jscomp.Result result17 = compiler1.getResult();
        boolean boolean18 = compiler1.hasErrors();
        com.google.javascript.jscomp.SourceFile.Generator generator20 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile21 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("JSC_OPTIMIZE_LOOP_ERROR. Exceeded max number of code motion iterations: {0} at (unknown source) line (unknown line) : (unknown column)", generator20);
        com.google.javascript.jscomp.SourceFile.Generator generator23 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile24 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("JSC_OPTIMIZE_LOOP_ERROR. Exceeded max number of code motion iterations: {0} at (unknown source) line (unknown line) : (unknown column)", generator23);
        com.google.javascript.jscomp.CompilerOptions compilerOptions25 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions25.setLooseTypes(true);
        boolean boolean28 = compilerOptions25.reserveRawExports;
        compilerOptions25.extractPrototypeMemberDeclarations = false;
        java.lang.String str31 = compilerOptions25.nameReferenceGraphPath;
        compilerOptions25.computeFunctionSideEffects = true;
        com.google.javascript.jscomp.CompilerOptions compilerOptions34 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions34.setLooseTypes(true);
        compilerOptions34.convertToDottedProperties = false;
        com.google.javascript.jscomp.CheckLevel checkLevel39 = compilerOptions34.reportMissingOverride;
        compilerOptions25.brokenClosureRequiresLevel = checkLevel39;
        java.util.Set<java.lang.String> strSet41 = compilerOptions25.stripTypePrefixes;
        compilerOptions25.optimizeReturns = true;
        com.google.javascript.jscomp.Result result44 = compiler1.compile(jSSourceFile21, jSSourceFile24, compilerOptions25);
        compilerOptions25.enableRuntimeTypeCheck("Not declared as a type name");
        com.google.javascript.jscomp.CompilerOptions.TweakProcessing tweakProcessing47 = compilerOptions25.getTweakProcessing();
        org.junit.Assert.assertNotNull(jSSourceFile4);
        org.junit.Assert.assertNotNull(reader5);
        org.junit.Assert.assertNotNull(jSModuleArray6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + checkLevel15 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel15.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(result16);
        org.junit.Assert.assertNotNull(result17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(jSSourceFile21);
        org.junit.Assert.assertNotNull(jSSourceFile24);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNull(str31);
        org.junit.Assert.assertTrue("'" + checkLevel39 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel39.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(strSet41);
        org.junit.Assert.assertNotNull(result44);
        org.junit.Assert.assertTrue("'" + tweakProcessing47 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TweakProcessing.OFF + "'", tweakProcessing47.equals(com.google.javascript.jscomp.CompilerOptions.TweakProcessing.OFF));
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test344");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        java.io.PrintStream printStream2 = null;
        com.google.javascript.jscomp.Compiler compiler3 = new com.google.javascript.jscomp.Compiler(printStream2);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile6 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        java.io.Reader reader7 = jSSourceFile6.getCodeReader();
        com.google.javascript.jscomp.JSModule[] jSModuleArray8 = new com.google.javascript.jscomp.JSModule[] {};
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph9 = new com.google.javascript.jscomp.JSModuleGraph(jSModuleArray8);
        com.google.javascript.jscomp.CompilerOptions compilerOptions10 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions10.setLooseTypes(true);
        boolean boolean13 = compilerOptions10.collapseVariableDeclarations;
        compilerOptions10.moveFunctionDeclarations = false;
        boolean boolean16 = compilerOptions10.decomposeExpressions;
        com.google.javascript.jscomp.CheckLevel checkLevel17 = compilerOptions10.checkMissingGetCssNameLevel;
        com.google.javascript.jscomp.Result result18 = compiler3.compile(jSSourceFile6, jSModuleArray8, compilerOptions10);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile21 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile24 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        java.io.Reader reader25 = jSSourceFile24.getCodeReader();
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray26 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile6, jSSourceFile21, jSSourceFile24 };
        java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList27 = new java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile>();
        boolean boolean28 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList27, jSSourceFileArray26);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile31 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray32 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile31 };
        java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList33 = new java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile>();
        boolean boolean34 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList33, jSSourceFileArray32);
        com.google.javascript.jscomp.CompilerOptions compilerOptions35 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions35.setLooseTypes(true);
        boolean boolean38 = compilerOptions35.reserveRawExports;
        compilerOptions35.extractPrototypeMemberDeclarations = false;
        java.lang.String str41 = compilerOptions35.nameReferenceGraphPath;
        compilerOptions35.setSummaryDetailLevel(0);
        com.google.javascript.jscomp.Result result44 = compiler1.compile((java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList27, (java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList33, compilerOptions35);
        int int45 = compiler1.getWarningCount();
        com.google.javascript.jscomp.PerformanceTracker performanceTracker46 = compiler1.tracker;
        com.google.javascript.jscomp.SourceMap sourceMap47 = compiler1.getSourceMap();
        com.google.javascript.jscomp.SourceFile.Generator generator49 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile50 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("hi!: hi!", generator49);
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray51 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile50 };
        com.google.javascript.jscomp.JSModule[] jSModuleArray52 = new com.google.javascript.jscomp.JSModule[] {};
        com.google.javascript.jscomp.CompilerOptions compilerOptions53 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions53.setLooseTypes(true);
        boolean boolean56 = compilerOptions53.reserveRawExports;
        boolean boolean57 = compilerOptions53.flowSensitiveInlineVariables;
        boolean boolean58 = compilerOptions53.ambiguateProperties;
        boolean boolean59 = compilerOptions53.specializeInitialModule;
        compiler1.init(jSSourceFileArray51, jSModuleArray52, compilerOptions53);
        org.junit.Assert.assertNotNull(jSSourceFile6);
        org.junit.Assert.assertNotNull(reader7);
        org.junit.Assert.assertNotNull(jSModuleArray8);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + checkLevel17 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel17.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(result18);
        org.junit.Assert.assertNotNull(jSSourceFile21);
        org.junit.Assert.assertNotNull(jSSourceFile24);
        org.junit.Assert.assertNotNull(reader25);
        org.junit.Assert.assertNotNull(jSSourceFileArray26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(jSSourceFile31);
        org.junit.Assert.assertNotNull(jSSourceFileArray32);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNull(str41);
        org.junit.Assert.assertNotNull(result44);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 0 + "'", int45 == 0);
        org.junit.Assert.assertNull(performanceTracker46);
        org.junit.Assert.assertNull(sourceMap47);
        org.junit.Assert.assertNotNull(jSSourceFile50);
        org.junit.Assert.assertNotNull(jSSourceFileArray51);
        org.junit.Assert.assertNotNull(jSModuleArray52);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test345");
        com.google.javascript.rhino.Node node1 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node3 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node5 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node7 = new com.google.javascript.rhino.Node((int) '4');
        node5.addChildrenToBack(node7);
        node1.addChildAfter(node3, node7);
        com.google.javascript.rhino.Node node11 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node((int) '4');
        node11.addChildrenToBack(node13);
        com.google.javascript.rhino.Node node15 = node1.copyInformationFromForTree(node13);
        com.google.javascript.rhino.Node node16 = node15.getLastChild();
        com.google.javascript.rhino.Node node18 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node20 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node22 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node24 = new com.google.javascript.rhino.Node((int) '4');
        node22.addChildrenToBack(node24);
        node18.addChildAfter(node20, node24);
        com.google.javascript.rhino.Node node28 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node30 = new com.google.javascript.rhino.Node((int) '4');
        node28.addChildrenToBack(node30);
        com.google.javascript.rhino.Node node32 = node18.copyInformationFromForTree(node30);
        node15.addChildToBack(node18);
        com.google.javascript.rhino.Node node34 = node18.cloneNode();
        java.util.Collection<com.google.javascript.rhino.Node> nodeCollection35 = com.google.javascript.jscomp.NodeUtil.getVarsDeclaredInBranch(node18);
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable36 = node18.children();
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertNull(node16);
        org.junit.Assert.assertNotNull(node32);
        org.junit.Assert.assertNotNull(node34);
        org.junit.Assert.assertNotNull(nodeCollection35);
        org.junit.Assert.assertNotNull(nodeIterable36);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test346");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setLooseTypes(true);
        boolean boolean3 = compilerOptions0.collapseVariableDeclarations;
        compilerOptions0.recordFunctionInformation = false;
        compilerOptions0.optimizeReturns = false;
        compilerOptions0.setAcceptConstKeyword(false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test347");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setLooseTypes(true);
        compilerOptions0.convertToDottedProperties = false;
        boolean boolean5 = compilerOptions0.removeTryCatchFinally;
        compilerOptions0.aliasStringsBlacklist = "()";
        java.lang.String str8 = compilerOptions0.aliasStringsBlacklist;
        boolean boolean9 = compilerOptions0.removeDeadCode;
        compilerOptions0.setDefineToNumberLiteral("", 1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "()" + "'", str8.equals("()"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test348");
        com.google.javascript.rhino.EcmaError ecmaError2 = com.google.javascript.rhino.ScriptRuntime.constructError("(): error reporter", "goog.global");
        java.lang.Throwable[] throwableArray3 = ecmaError2.getSuppressed();
        org.junit.Assert.assertNotNull(ecmaError2);
        org.junit.Assert.assertNotNull(throwableArray3);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test349");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setLooseTypes(true);
        boolean boolean3 = compilerOptions0.reserveRawExports;
        compilerOptions0.extractPrototypeMemberDeclarations = false;
        boolean boolean6 = compilerOptions0.disambiguateProperties;
        compilerOptions0.setDefineToDoubleLiteral("Not declared as a type name", 100.0d);
        compilerOptions0.enableExternExports(true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test350");
        com.google.javascript.rhino.Node node1 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node3 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node5 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node7 = new com.google.javascript.rhino.Node((int) '4');
        node5.addChildrenToBack(node7);
        node1.addChildAfter(node3, node7);
        com.google.javascript.rhino.Node node11 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node((int) '4');
        node11.addChildrenToBack(node13);
        com.google.javascript.rhino.Node node15 = node1.copyInformationFromForTree(node13);
        node1.setWasEmptyNode(false);
        org.junit.Assert.assertNotNull(node15);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test351");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile4 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile7 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        java.io.Reader reader8 = jSSourceFile7.getCodeReader();
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray9 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile4, jSSourceFile7 };
        java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList10 = new java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile>();
        boolean boolean11 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList10, jSSourceFileArray9);
        com.google.javascript.jscomp.JSModule[] jSModuleArray12 = new com.google.javascript.jscomp.JSModule[] {};
        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList13 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
        boolean boolean14 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList13, jSModuleArray12);
        com.google.javascript.jscomp.CompilerOptions compilerOptions15 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions15.setLooseTypes(true);
        boolean boolean18 = compilerOptions15.reserveRawExports;
        compilerOptions15.extractPrototypeMemberDeclarations = false;
        java.lang.String str21 = compilerOptions15.nameReferenceGraphPath;
        compilerOptions15.computeFunctionSideEffects = true;
        com.google.javascript.jscomp.CompilerOptions compilerOptions24 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions24.setLooseTypes(true);
        compilerOptions24.convertToDottedProperties = false;
        com.google.javascript.jscomp.CheckLevel checkLevel29 = compilerOptions24.reportMissingOverride;
        compilerOptions15.brokenClosureRequiresLevel = checkLevel29;
        java.util.Set<java.lang.String> strSet31 = compilerOptions15.stripTypePrefixes;
        compilerOptions15.deadAssignmentElimination = false;
        compiler1.initModules((java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList10, (java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList13, compilerOptions15);
        compilerOptions15.flowSensitiveInlineVariables = true;
        org.junit.Assert.assertNotNull(jSSourceFile4);
        org.junit.Assert.assertNotNull(jSSourceFile7);
        org.junit.Assert.assertNotNull(reader8);
        org.junit.Assert.assertNotNull(jSSourceFileArray9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(jSModuleArray12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertTrue("'" + checkLevel29 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel29.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(strSet31);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test352");
        com.google.javascript.jscomp.SourceFile sourceFile0 = null;
        try {
            com.google.javascript.jscomp.JsAst jsAst1 = new com.google.javascript.jscomp.JsAst(sourceFile0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test353");
        com.google.javascript.rhino.EcmaError ecmaError1 = com.google.javascript.rhino.ScriptRuntime.typeError("4");
        java.lang.String str2 = ecmaError1.getName();
        java.lang.String str3 = ecmaError1.lineSource();
        java.lang.String str4 = ecmaError1.toString();
        com.google.javascript.rhino.EcmaError ecmaError6 = com.google.javascript.rhino.ScriptRuntime.typeError("4");
        java.lang.String str7 = ecmaError6.getName();
        java.lang.String str8 = ecmaError6.lineSource();
        java.lang.String str9 = ecmaError6.toString();
        java.lang.String str10 = ecmaError6.lineSource();
        ecmaError1.addSuppressed((java.lang.Throwable) ecmaError6);
        java.lang.String str12 = ecmaError1.details();
        java.lang.String str13 = ecmaError1.lineSource();
        org.junit.Assert.assertNotNull(ecmaError1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "TypeError" + "'", str2.equals("TypeError"));
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "com.google.javascript.rhino.EcmaError: TypeError: 4" + "'", str4.equals("com.google.javascript.rhino.EcmaError: TypeError: 4"));
        org.junit.Assert.assertNotNull(ecmaError6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "TypeError" + "'", str7.equals("TypeError"));
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "com.google.javascript.rhino.EcmaError: TypeError: 4" + "'", str9.equals("com.google.javascript.rhino.EcmaError: TypeError: 4"));
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "TypeError: 4" + "'", str12.equals("TypeError: 4"));
        org.junit.Assert.assertNull(str13);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test354");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setLooseTypes(true);
        boolean boolean3 = compilerOptions0.reserveRawExports;
        boolean boolean4 = compilerOptions0.flowSensitiveInlineVariables;
        compilerOptions0.reserveRawExports = true;
        com.google.javascript.jscomp.AnonymousFunctionNamingPolicy anonymousFunctionNamingPolicy7 = com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF;
        compilerOptions0.anonymousFunctionNaming = anonymousFunctionNamingPolicy7;
        com.google.javascript.jscomp.CompilerOptions compilerOptions9 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions9.setLooseTypes(true);
        com.google.javascript.jscomp.CompilerOptions.AliasTransformationHandler aliasTransformationHandler12 = compilerOptions9.getAliasTransformationHandler();
        compilerOptions0.setAliasTransformationHandler(aliasTransformationHandler12);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + anonymousFunctionNamingPolicy7 + "' != '" + com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF + "'", anonymousFunctionNamingPolicy7.equals(com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF));
        org.junit.Assert.assertNotNull(aliasTransformationHandler12);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test355");
        com.google.javascript.jscomp.SourceFile sourceFile1 = com.google.javascript.jscomp.SourceFile.fromFile("hi!: hi!");
        org.junit.Assert.assertNotNull(sourceFile1);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test356");
        com.google.javascript.rhino.EcmaError ecmaError1 = com.google.javascript.rhino.ScriptRuntime.typeError("4");
        java.lang.String str2 = ecmaError1.details();
        java.lang.String str3 = ecmaError1.sourceName();
        ecmaError1.initSourceName("false");
        java.io.FilenameFilter filenameFilter6 = null;
        java.lang.String str7 = ecmaError1.getScriptStackTrace(filenameFilter6);
        java.lang.String str8 = ecmaError1.getName();
        org.junit.Assert.assertNotNull(ecmaError1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "TypeError: 4" + "'", str2.equals("TypeError: 4"));
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "<No stack trace available>" + "'", str7.equals("<No stack trace available>"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "TypeError" + "'", str8.equals("TypeError"));
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test357");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        compiler1.disableThreads();
        com.google.javascript.jscomp.PerformanceTracker performanceTracker3 = compiler1.tracker;
        com.google.javascript.jscomp.NodeTraversal.Callback callback4 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal5 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler1, callback4);
        java.io.PrintStream printStream6 = null;
        com.google.javascript.jscomp.Compiler compiler7 = new com.google.javascript.jscomp.Compiler(printStream6);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile10 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        java.io.Reader reader11 = jSSourceFile10.getCodeReader();
        com.google.javascript.jscomp.JSModule[] jSModuleArray12 = new com.google.javascript.jscomp.JSModule[] {};
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph13 = new com.google.javascript.jscomp.JSModuleGraph(jSModuleArray12);
        com.google.javascript.jscomp.CompilerOptions compilerOptions14 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions14.setLooseTypes(true);
        boolean boolean17 = compilerOptions14.collapseVariableDeclarations;
        compilerOptions14.moveFunctionDeclarations = false;
        boolean boolean20 = compilerOptions14.decomposeExpressions;
        com.google.javascript.jscomp.CheckLevel checkLevel21 = compilerOptions14.checkMissingGetCssNameLevel;
        com.google.javascript.jscomp.Result result22 = compiler7.compile(jSSourceFile10, jSModuleArray12, compilerOptions14);
        java.io.PrintStream printStream23 = null;
        com.google.javascript.jscomp.Compiler compiler24 = new com.google.javascript.jscomp.Compiler(printStream23);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile27 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        java.io.Reader reader28 = jSSourceFile27.getCodeReader();
        com.google.javascript.jscomp.JSModule[] jSModuleArray29 = new com.google.javascript.jscomp.JSModule[] {};
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph30 = new com.google.javascript.jscomp.JSModuleGraph(jSModuleArray29);
        com.google.javascript.jscomp.CompilerOptions compilerOptions31 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions31.setLooseTypes(true);
        boolean boolean34 = compilerOptions31.collapseVariableDeclarations;
        compilerOptions31.moveFunctionDeclarations = false;
        boolean boolean37 = compilerOptions31.decomposeExpressions;
        com.google.javascript.jscomp.CheckLevel checkLevel38 = compilerOptions31.checkMissingGetCssNameLevel;
        com.google.javascript.jscomp.Result result39 = compiler24.compile(jSSourceFile27, jSModuleArray29, compilerOptions31);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile42 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        java.io.PrintStream printStream43 = null;
        com.google.javascript.jscomp.Compiler compiler44 = new com.google.javascript.jscomp.Compiler(printStream43);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile47 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        java.io.Reader reader48 = jSSourceFile47.getCodeReader();
        com.google.javascript.jscomp.JSModule[] jSModuleArray49 = new com.google.javascript.jscomp.JSModule[] {};
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph50 = new com.google.javascript.jscomp.JSModuleGraph(jSModuleArray49);
        com.google.javascript.jscomp.CompilerOptions compilerOptions51 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions51.setLooseTypes(true);
        boolean boolean54 = compilerOptions51.collapseVariableDeclarations;
        compilerOptions51.moveFunctionDeclarations = false;
        boolean boolean57 = compilerOptions51.decomposeExpressions;
        com.google.javascript.jscomp.CheckLevel checkLevel58 = compilerOptions51.checkMissingGetCssNameLevel;
        com.google.javascript.jscomp.Result result59 = compiler44.compile(jSSourceFile47, jSModuleArray49, compilerOptions51);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile62 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile65 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        java.io.Reader reader66 = jSSourceFile65.getCodeReader();
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray67 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile10, jSSourceFile27, jSSourceFile42, jSSourceFile47, jSSourceFile62, jSSourceFile65 };
        java.io.PrintStream printStream68 = null;
        com.google.javascript.jscomp.Compiler compiler69 = new com.google.javascript.jscomp.Compiler(printStream68);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile72 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        java.io.Reader reader73 = jSSourceFile72.getCodeReader();
        com.google.javascript.jscomp.JSModule[] jSModuleArray74 = new com.google.javascript.jscomp.JSModule[] {};
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph75 = new com.google.javascript.jscomp.JSModuleGraph(jSModuleArray74);
        com.google.javascript.jscomp.CompilerOptions compilerOptions76 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions76.setLooseTypes(true);
        boolean boolean79 = compilerOptions76.collapseVariableDeclarations;
        compilerOptions76.moveFunctionDeclarations = false;
        boolean boolean82 = compilerOptions76.decomposeExpressions;
        com.google.javascript.jscomp.CheckLevel checkLevel83 = compilerOptions76.checkMissingGetCssNameLevel;
        com.google.javascript.jscomp.Result result84 = compiler69.compile(jSSourceFile72, jSModuleArray74, compilerOptions76);
        com.google.javascript.jscomp.CompilerOptions compilerOptions85 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions85.setLooseTypes(true);
        boolean boolean88 = compilerOptions85.collapseVariableDeclarations;
        compilerOptions85.setManageClosureDependencies(false);
        com.google.javascript.jscomp.Result result91 = compiler1.compile(jSSourceFileArray67, jSModuleArray74, compilerOptions85);
        com.google.javascript.jscomp.CodingConvention codingConvention92 = compiler1.getCodingConvention();
        compiler1.disableThreads();
        com.google.javascript.jscomp.PerformanceTracker performanceTracker94 = null;
        compiler1.tracker = performanceTracker94;
        java.lang.String str98 = compiler1.getSourceLine("error reporter", 0);
        org.junit.Assert.assertNull(performanceTracker3);
        org.junit.Assert.assertNotNull(jSSourceFile10);
        org.junit.Assert.assertNotNull(reader11);
        org.junit.Assert.assertNotNull(jSModuleArray12);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + checkLevel21 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel21.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(result22);
        org.junit.Assert.assertNotNull(jSSourceFile27);
        org.junit.Assert.assertNotNull(reader28);
        org.junit.Assert.assertNotNull(jSModuleArray29);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + checkLevel38 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel38.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(result39);
        org.junit.Assert.assertNotNull(jSSourceFile42);
        org.junit.Assert.assertNotNull(jSSourceFile47);
        org.junit.Assert.assertNotNull(reader48);
        org.junit.Assert.assertNotNull(jSModuleArray49);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertTrue("'" + checkLevel58 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel58.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(result59);
        org.junit.Assert.assertNotNull(jSSourceFile62);
        org.junit.Assert.assertNotNull(jSSourceFile65);
        org.junit.Assert.assertNotNull(reader66);
        org.junit.Assert.assertNotNull(jSSourceFileArray67);
        org.junit.Assert.assertNotNull(jSSourceFile72);
        org.junit.Assert.assertNotNull(reader73);
        org.junit.Assert.assertNotNull(jSModuleArray74);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
        org.junit.Assert.assertTrue("'" + checkLevel83 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel83.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(result84);
        org.junit.Assert.assertTrue("'" + boolean88 + "' != '" + false + "'", boolean88 == false);
        org.junit.Assert.assertNotNull(result91);
        org.junit.Assert.assertNotNull(codingConvention92);
        org.junit.Assert.assertNull(str98);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test358");
        com.google.javascript.rhino.Node node2 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node4 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node6 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node8 = new com.google.javascript.rhino.Node((int) '4');
        node6.addChildrenToBack(node8);
        node2.addChildAfter(node4, node8);
        com.google.javascript.rhino.Node node12 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node14 = new com.google.javascript.rhino.Node((int) '4');
        node12.addChildrenToBack(node14);
        com.google.javascript.rhino.Node node16 = node2.copyInformationFromForTree(node14);
        com.google.javascript.rhino.Node node17 = node16.getLastChild();
        com.google.javascript.rhino.Node node19 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node21 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node23 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node25 = new com.google.javascript.rhino.Node((int) '4');
        node23.addChildrenToBack(node25);
        node19.addChildAfter(node21, node25);
        com.google.javascript.rhino.Node node29 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node31 = new com.google.javascript.rhino.Node((int) '4');
        node29.addChildrenToBack(node31);
        com.google.javascript.rhino.Node node33 = node19.copyInformationFromForTree(node31);
        node16.addChildToBack(node19);
        com.google.javascript.rhino.Node node37 = new com.google.javascript.rhino.Node((int) (short) 0, node16, 36, 0);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertNull(node17);
        org.junit.Assert.assertNotNull(node33);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test359");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile4 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        java.io.Reader reader5 = jSSourceFile4.getCodeReader();
        com.google.javascript.jscomp.JSModule[] jSModuleArray6 = new com.google.javascript.jscomp.JSModule[] {};
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph7 = new com.google.javascript.jscomp.JSModuleGraph(jSModuleArray6);
        com.google.javascript.jscomp.CompilerOptions compilerOptions8 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions8.setLooseTypes(true);
        boolean boolean11 = compilerOptions8.collapseVariableDeclarations;
        compilerOptions8.moveFunctionDeclarations = false;
        boolean boolean14 = compilerOptions8.decomposeExpressions;
        com.google.javascript.jscomp.CheckLevel checkLevel15 = compilerOptions8.checkMissingGetCssNameLevel;
        com.google.javascript.jscomp.Result result16 = compiler1.compile(jSSourceFile4, jSModuleArray6, compilerOptions8);
        int int17 = compiler1.getWarningCount();
        com.google.javascript.jscomp.PerformanceTracker performanceTracker18 = null;
        compiler1.tracker = performanceTracker18;
        com.google.javascript.jscomp.CompilerOptions compilerOptions20 = null;
        com.google.javascript.jscomp.DefaultPassConfig defaultPassConfig21 = new com.google.javascript.jscomp.DefaultPassConfig(compilerOptions20);
        try {
            compiler1.setPassConfig((com.google.javascript.jscomp.PassConfig) defaultPassConfig21);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: this.passes has already been assigned");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile4);
        org.junit.Assert.assertNotNull(reader5);
        org.junit.Assert.assertNotNull(jSModuleArray6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + checkLevel15 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel15.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(result16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test360");
        com.google.javascript.jscomp.DiagnosticType[] diagnosticTypeArray0 = new com.google.javascript.jscomp.DiagnosticType[] {};
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup1 = new com.google.javascript.jscomp.DiagnosticGroup(diagnosticTypeArray0);
        com.google.javascript.jscomp.DiagnosticGroups.INVALID_CASTS = diagnosticGroup1;
        org.junit.Assert.assertNotNull(diagnosticTypeArray0);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test361");
        com.google.javascript.rhino.Node node1 = new com.google.javascript.rhino.Node((int) (short) 1);
        com.google.javascript.rhino.Node node3 = new com.google.javascript.rhino.Node((int) (short) 1);
        node1.addChildrenToBack(node3);
        node3.detachChildren();
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test362");
        com.google.javascript.rhino.Node node1 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node3 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node5 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node7 = new com.google.javascript.rhino.Node((int) '4');
        node5.addChildrenToBack(node7);
        node1.addChildAfter(node3, node7);
        com.google.javascript.rhino.Node node11 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node((int) '4');
        node11.addChildrenToBack(node13);
        com.google.javascript.rhino.Node node15 = node1.copyInformationFromForTree(node13);
        com.google.javascript.rhino.Node node17 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node18 = node1.copyInformationFromForTree(node17);
        com.google.javascript.rhino.Node node20 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node22 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node24 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node26 = new com.google.javascript.rhino.Node((int) '4');
        node24.addChildrenToBack(node26);
        node20.addChildAfter(node22, node26);
        com.google.javascript.rhino.Node node30 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node32 = new com.google.javascript.rhino.Node((int) '4');
        node30.addChildrenToBack(node32);
        com.google.javascript.rhino.Node node34 = node20.copyInformationFromForTree(node32);
        com.google.javascript.rhino.jstype.JSType jSType35 = null;
        node34.setJSType(jSType35);
        com.google.javascript.rhino.Node node38 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node40 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node42 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node44 = new com.google.javascript.rhino.Node((int) '4');
        node42.addChildrenToBack(node44);
        node38.addChildAfter(node40, node44);
        com.google.javascript.rhino.Node node48 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node50 = new com.google.javascript.rhino.Node((int) '4');
        node48.addChildrenToBack(node50);
        com.google.javascript.rhino.Node node52 = node38.copyInformationFromForTree(node50);
        node17.addChildAfter(node34, node50);
        com.google.javascript.rhino.Node node54 = node17.cloneNode();
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNotNull(node34);
        org.junit.Assert.assertNotNull(node52);
        org.junit.Assert.assertNotNull(node54);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test363");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        java.io.PrintStream printStream2 = null;
        com.google.javascript.jscomp.Compiler compiler3 = new com.google.javascript.jscomp.Compiler(printStream2);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile6 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        java.io.Reader reader7 = jSSourceFile6.getCodeReader();
        com.google.javascript.jscomp.JSModule[] jSModuleArray8 = new com.google.javascript.jscomp.JSModule[] {};
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph9 = new com.google.javascript.jscomp.JSModuleGraph(jSModuleArray8);
        com.google.javascript.jscomp.CompilerOptions compilerOptions10 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions10.setLooseTypes(true);
        boolean boolean13 = compilerOptions10.collapseVariableDeclarations;
        compilerOptions10.moveFunctionDeclarations = false;
        boolean boolean16 = compilerOptions10.decomposeExpressions;
        com.google.javascript.jscomp.CheckLevel checkLevel17 = compilerOptions10.checkMissingGetCssNameLevel;
        com.google.javascript.jscomp.Result result18 = compiler3.compile(jSSourceFile6, jSModuleArray8, compilerOptions10);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile21 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile24 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        java.io.Reader reader25 = jSSourceFile24.getCodeReader();
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray26 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile6, jSSourceFile21, jSSourceFile24 };
        java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList27 = new java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile>();
        boolean boolean28 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList27, jSSourceFileArray26);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile31 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray32 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile31 };
        java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList33 = new java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile>();
        boolean boolean34 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList33, jSSourceFileArray32);
        com.google.javascript.jscomp.CompilerOptions compilerOptions35 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions35.setLooseTypes(true);
        boolean boolean38 = compilerOptions35.reserveRawExports;
        compilerOptions35.extractPrototypeMemberDeclarations = false;
        java.lang.String str41 = compilerOptions35.nameReferenceGraphPath;
        compilerOptions35.setSummaryDetailLevel(0);
        com.google.javascript.jscomp.Result result44 = compiler1.compile((java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList27, (java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList33, compilerOptions35);
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter45 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler1);
        com.google.javascript.jscomp.CompilerOptions compilerOptions46 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions46.setLooseTypes(true);
        boolean boolean49 = compilerOptions46.reserveRawExports;
        compilerOptions46.inferTypesInGlobalScope = false;
        java.lang.String str52 = compilerOptions46.debugFunctionSideEffectsPath;
        compiler1.initOptions(compilerOptions46);
        boolean boolean54 = compilerOptions46.aliasExternals;
        org.junit.Assert.assertNotNull(jSSourceFile6);
        org.junit.Assert.assertNotNull(reader7);
        org.junit.Assert.assertNotNull(jSModuleArray8);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + checkLevel17 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel17.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(result18);
        org.junit.Assert.assertNotNull(jSSourceFile21);
        org.junit.Assert.assertNotNull(jSSourceFile24);
        org.junit.Assert.assertNotNull(reader25);
        org.junit.Assert.assertNotNull(jSSourceFileArray26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(jSSourceFile31);
        org.junit.Assert.assertNotNull(jSSourceFileArray32);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNull(str41);
        org.junit.Assert.assertNotNull(result44);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNull(str52);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test364");
        com.google.javascript.jscomp.CompilerOptions compilerOptions1 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions1.setLooseTypes(true);
        boolean boolean4 = compilerOptions1.collapseVariableDeclarations;
        compilerOptions1.moveFunctionDeclarations = false;
        boolean boolean7 = compilerOptions1.decomposeExpressions;
        boolean boolean8 = compilerOptions1.optimizeParameters;
        java.lang.String str9 = compilerOptions1.inputDelimiter;
        com.google.javascript.jscomp.ErrorFormat errorFormat10 = com.google.javascript.jscomp.ErrorFormat.LEGACY;
        java.lang.RuntimeException runtimeException11 = com.google.javascript.rhino.ScriptRuntime.undefWriteError((java.lang.Object) (short) 100, (java.lang.Object) str9, (java.lang.Object) errorFormat10);
        java.io.PrintStream printStream12 = null;
        com.google.javascript.jscomp.Compiler compiler13 = new com.google.javascript.jscomp.Compiler(printStream12);
        compiler13.disableThreads();
        com.google.javascript.jscomp.PerformanceTracker performanceTracker15 = compiler13.tracker;
        com.google.javascript.jscomp.MessageFormatter messageFormatter17 = errorFormat10.toFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler13, false);
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter18 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler13);
        java.util.logging.Logger logger19 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager20 = new com.google.javascript.jscomp.LoggerErrorManager((com.google.javascript.jscomp.MessageFormatter) lightweightMessageFormatter18, logger19);
        com.google.javascript.jscomp.JSError[] jSErrorArray21 = loggerErrorManager20.getErrors();
        com.google.javascript.jscomp.Compiler compiler22 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager20);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "// Input %num%" + "'", str9.equals("// Input %num%"));
        org.junit.Assert.assertNotNull(errorFormat10);
        org.junit.Assert.assertNotNull(runtimeException11);
        org.junit.Assert.assertNull(performanceTracker15);
        org.junit.Assert.assertNotNull(messageFormatter17);
        org.junit.Assert.assertNotNull(jSErrorArray21);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test365");
        com.google.javascript.rhino.Context context0 = new com.google.javascript.rhino.Context();
        com.google.javascript.rhino.ErrorReporter errorReporter1 = context0.getErrorReporter();
        com.google.javascript.rhino.Context context2 = com.google.javascript.rhino.Context.enter(context0);
        java.lang.Class<?> wildcardClass3 = context0.getClass();
        com.google.javascript.rhino.Node node5 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node7 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node9 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node11 = new com.google.javascript.rhino.Node((int) '4');
        node9.addChildrenToBack(node11);
        node5.addChildAfter(node7, node11);
        com.google.javascript.rhino.Node node15 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node17 = new com.google.javascript.rhino.Node((int) '4');
        node15.addChildrenToBack(node17);
        com.google.javascript.rhino.Node node19 = node5.copyInformationFromForTree(node17);
        com.google.javascript.rhino.Node node20 = node5.cloneTree();
        com.google.javascript.rhino.Node node22 = new com.google.javascript.rhino.Node((int) '4');
        node20.addChildrenToBack(node22);
        context0.seal((java.lang.Object) node20);
        try {
            int int26 = node20.getExistingIntProp(46);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: FAILED ASSERTION");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNull(errorReporter1);
        org.junit.Assert.assertNotNull(context2);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNotNull(node20);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test366");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setLooseTypes(true);
        boolean boolean3 = compilerOptions0.reserveRawExports;
        com.google.javascript.jscomp.CheckLevel checkLevel4 = null;
        compilerOptions0.checkUnreachableCode = checkLevel4;
        com.google.javascript.jscomp.MessageBundle messageBundle6 = compilerOptions0.messageBundle;
        java.lang.String str7 = compilerOptions0.sourceMapOutputPath;
        compilerOptions0.inlineGetters = true;
        boolean boolean10 = compilerOptions0.allowLegacyJsMessages;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(messageBundle6);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test367");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setLooseTypes(true);
        boolean boolean3 = compilerOptions0.reserveRawExports;
        compilerOptions0.extractPrototypeMemberDeclarations = false;
        com.google.javascript.jscomp.CheckLevel checkLevel6 = compilerOptions0.aggressiveVarCheck;
        boolean boolean7 = compilerOptions0.foldConstants;
        com.google.javascript.jscomp.DiagnosticType diagnosticType8 = com.google.javascript.jscomp.Compiler.MOTION_ITERATIONS_ERROR;
        com.google.javascript.jscomp.CheckLevel checkLevel9 = diagnosticType8.defaultLevel;
        compilerOptions0.checkFunctions = checkLevel9;
        boolean boolean11 = compilerOptions0.removeDeadCode;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + checkLevel6 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel6.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(diagnosticType8);
        org.junit.Assert.assertTrue("'" + checkLevel9 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel9.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test368");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setLooseTypes(true);
        compilerOptions0.convertToDottedProperties = false;
        com.google.javascript.jscomp.CheckLevel checkLevel5 = compilerOptions0.reportMissingOverride;
        boolean boolean6 = compilerOptions0.aliasAllStrings;
        compilerOptions0.instrumentationTemplate = "hi!";
        boolean boolean9 = compilerOptions0.exportTestFunctions;
        java.util.Map<java.lang.String, com.google.javascript.rhino.Node> strMap10 = compilerOptions0.getDefineReplacements();
        boolean boolean11 = compilerOptions0.flowSensitiveInlineVariables;
        boolean boolean12 = compilerOptions0.inlineAnonymousFunctionExpressions;
        org.junit.Assert.assertTrue("'" + checkLevel5 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel5.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(strMap10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test369");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setLooseTypes(true);
        boolean boolean3 = compilerOptions0.collapseVariableDeclarations;
        compilerOptions0.moveFunctionDeclarations = false;
        boolean boolean6 = compilerOptions0.decomposeExpressions;
        boolean boolean7 = compilerOptions0.optimizeParameters;
        java.lang.String str8 = compilerOptions0.inputDelimiter;
        java.lang.String[] strArray10 = new java.lang.String[] { "hi!" };
        java.util.LinkedHashSet<java.lang.String> strSet11 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean12 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet11, strArray10);
        compilerOptions0.stripTypes = strSet11;
        compilerOptions0.markNoSideEffectCalls = false;
        boolean boolean16 = compilerOptions0.aliasExternals;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "// Input %num%" + "'", str8.equals("// Input %num%"));
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test370");
        com.google.javascript.rhino.Context context0 = new com.google.javascript.rhino.Context();
        com.google.javascript.rhino.ErrorReporter errorReporter1 = context0.getErrorReporter();
        com.google.javascript.rhino.Context context2 = com.google.javascript.rhino.Context.enter(context0);
        com.google.javascript.rhino.Node node4 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node6 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node8 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node10 = new com.google.javascript.rhino.Node((int) '4');
        node8.addChildrenToBack(node10);
        node4.addChildAfter(node6, node10);
        com.google.javascript.rhino.Node node14 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node16 = new com.google.javascript.rhino.Node((int) '4');
        node14.addChildrenToBack(node16);
        com.google.javascript.rhino.Node node18 = node4.copyInformationFromForTree(node16);
        com.google.javascript.rhino.Node node20 = node4.getAncestor(1);
        com.google.javascript.rhino.Node node22 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node24 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node26 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node28 = new com.google.javascript.rhino.Node((int) '4');
        node26.addChildrenToBack(node28);
        node22.addChildAfter(node24, node28);
        com.google.javascript.rhino.Node node32 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node34 = new com.google.javascript.rhino.Node((int) '4');
        node32.addChildrenToBack(node34);
        com.google.javascript.rhino.Node node36 = node22.copyInformationFromForTree(node34);
        com.google.javascript.rhino.Node node38 = node22.getAncestor(1);
        node4.addChildToFront(node22);
        java.lang.Object obj40 = context2.getThreadLocal((java.lang.Object) node22);
        org.junit.Assert.assertNull(errorReporter1);
        org.junit.Assert.assertNotNull(context2);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNull(node20);
        org.junit.Assert.assertNotNull(node36);
        org.junit.Assert.assertNull(node38);
        org.junit.Assert.assertNull(obj40);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test371");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setLooseTypes(true);
        boolean boolean3 = compilerOptions0.reserveRawExports;
        compilerOptions0.extractPrototypeMemberDeclarations = false;
        boolean boolean6 = compilerOptions0.disambiguateProperties;
        com.google.javascript.jscomp.CheckLevel checkLevel7 = compilerOptions0.checkFunctions;
        com.google.javascript.jscomp.CompilerOptions compilerOptions8 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions8.setLooseTypes(true);
        boolean boolean11 = compilerOptions8.reserveRawExports;
        compilerOptions8.extractPrototypeMemberDeclarations = false;
        boolean boolean14 = compilerOptions8.disambiguateProperties;
        boolean boolean15 = compilerOptions8.rewriteFunctionExpressions;
        java.lang.String str16 = compilerOptions8.appNameStr;
        com.google.javascript.jscomp.CheckLevel checkLevel17 = compilerOptions8.aggressiveVarCheck;
        compilerOptions0.brokenClosureRequiresLevel = checkLevel17;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + checkLevel7 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel7.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
        org.junit.Assert.assertTrue("'" + checkLevel17 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel17.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test372");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setLooseTypes(true);
        boolean boolean3 = compilerOptions0.reserveRawExports;
        compilerOptions0.extractPrototypeMemberDeclarations = false;
        compilerOptions0.checkMissingGetCssNameBlacklist = "4";
        compilerOptions0.extractPrototypeMemberDeclarations = false;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test373");
        com.google.javascript.rhino.Node node1 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node3 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node5 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node7 = new com.google.javascript.rhino.Node((int) '4');
        node5.addChildrenToBack(node7);
        node1.addChildAfter(node3, node7);
        com.google.javascript.rhino.Node node10 = node1.cloneTree();
        boolean boolean11 = node1.isUnscopedQualifiedName();
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test374");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setLooseTypes(true);
        boolean boolean3 = compilerOptions0.reserveRawExports;
        com.google.javascript.jscomp.CheckLevel checkLevel4 = null;
        compilerOptions0.checkUnreachableCode = checkLevel4;
        com.google.javascript.jscomp.CheckLevel checkLevel6 = compilerOptions0.reportUnknownTypes;
        java.util.Set<java.lang.String> strSet7 = compilerOptions0.stripTypePrefixes;
        compilerOptions0.reportPath = "DiagnosticGroup<externsValidation>";
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + checkLevel6 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel6.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(strSet7);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test375");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeUnusedPrototypePropertiesInExterns = false;
        compilerOptions0.removeUnusedLocalVars = false;
        compilerOptions0.ignoreCajaProperties = false;
        compilerOptions0.lineLengthThreshold((int) ' ');
        boolean boolean9 = compilerOptions0.disambiguateProperties;
        compilerOptions0.setChainCalls(true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test376");
        com.google.javascript.rhino.EcmaError ecmaError1 = com.google.javascript.rhino.ScriptRuntime.typeError("4");
        java.lang.String str2 = ecmaError1.getName();
        java.lang.String str3 = ecmaError1.lineSource();
        java.lang.String str4 = ecmaError1.toString();
        java.lang.String str5 = ecmaError1.lineSource();
        ecmaError1.initLineSource("com.google.javascript.rhino.EcmaError: TypeError: 4");
        java.lang.String str8 = ecmaError1.lineSource();
        int int9 = ecmaError1.getLineNumber();
        java.io.FilenameFilter filenameFilter10 = null;
        java.lang.String str11 = ecmaError1.getScriptStackTrace(filenameFilter10);
        org.junit.Assert.assertNotNull(ecmaError1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "TypeError" + "'", str2.equals("TypeError"));
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "com.google.javascript.rhino.EcmaError: TypeError: 4" + "'", str4.equals("com.google.javascript.rhino.EcmaError: TypeError: 4"));
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "com.google.javascript.rhino.EcmaError: TypeError: 4" + "'", str8.equals("com.google.javascript.rhino.EcmaError: TypeError: 4"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "<No stack trace available>" + "'", str11.equals("<No stack trace available>"));
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test377");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        compiler1.disableThreads();
        com.google.javascript.jscomp.PerformanceTracker performanceTracker3 = compiler1.tracker;
        com.google.javascript.jscomp.NodeTraversal.Callback callback4 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal5 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler1, callback4);
        com.google.javascript.rhino.Node node7 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node9 = new com.google.javascript.rhino.Node((int) '4');
        node7.addChildrenToBack(node9);
        com.google.javascript.jscomp.DiagnosticType diagnosticType13 = com.google.javascript.jscomp.DiagnosticType.warning("hi!", "hi!");
        com.google.javascript.jscomp.DiagnosticType diagnosticType14 = com.google.javascript.jscomp.Compiler.MOTION_ITERATIONS_ERROR;
        int int15 = diagnosticType13.compareTo(diagnosticType14);
        java.lang.String[] strArray16 = com.google.javascript.rhino.ScriptRuntime.emptyStrings;
        com.google.javascript.jscomp.JSError jSError17 = nodeTraversal5.makeError(node9, diagnosticType13, strArray16);
        java.lang.String str18 = nodeTraversal5.getSourceName();
        org.junit.Assert.assertNull(performanceTracker3);
        org.junit.Assert.assertNotNull(diagnosticType13);
        org.junit.Assert.assertNotNull(diagnosticType14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 30 + "'", int15 == 30);
        org.junit.Assert.assertNotNull(strArray16);
        org.junit.Assert.assertNotNull(jSError17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "" + "'", str18.equals(""));
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test378");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setLooseTypes(true);
        boolean boolean3 = compilerOptions0.reserveRawExports;
        boolean boolean4 = compilerOptions0.flowSensitiveInlineVariables;
        compilerOptions0.rewriteFunctionExpressions = true;
        java.lang.String str7 = compilerOptions0.unaliasableGlobals;
        boolean boolean8 = compilerOptions0.collapseProperties;
        java.lang.String[] strArray27 = new java.lang.String[] { "33", "JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}", "JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}", "TypeError", "com.google.javascript.rhino.EcmaError: TypeError: 4", "language version", "(// Input %num%)", "33", "com.google.javascript.rhino.EcmaError: TypeError: 4", "", "4", "hi!: hi!", "error reporter", "hi!: hi!", "(// Input %num%)", "Exceeded max number of code motion iterations: {0}", "hi!" };
        java.util.ArrayList<java.lang.String> strList28 = new java.util.ArrayList<java.lang.String>();
        boolean boolean29 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strList28, strArray27);
        compilerOptions0.setReplaceStringsConfiguration("Not declared as a type name", (java.util.List<java.lang.String>) strList28);
        compilerOptions0.crossModuleMethodMotion = false;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(strArray27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test379");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setLooseTypes(true);
        boolean boolean3 = compilerOptions0.reserveRawExports;
        compilerOptions0.extractPrototypeMemberDeclarations = false;
        java.lang.String str6 = compilerOptions0.nameReferenceGraphPath;
        compilerOptions0.computeFunctionSideEffects = true;
        boolean boolean9 = compilerOptions0.inlineLocalFunctions;
        boolean boolean10 = compilerOptions0.aliasAllStrings;
        java.lang.String str11 = compilerOptions0.checkMissingGetCssNameBlacklist;
        boolean boolean12 = compilerOptions0.optimizeParameters;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNull(str11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test380");
        com.google.javascript.rhino.Node node1 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node3 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node5 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node7 = new com.google.javascript.rhino.Node((int) '4');
        node5.addChildrenToBack(node7);
        node1.addChildAfter(node3, node7);
        com.google.javascript.rhino.Node node10 = node7.getParent();
        try {
            node10.setSideEffectFlags(45);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: setIsNoSideEffectsCall only supports CALL and NEW nodes, got INSTANCEOF");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node10);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test381");
        com.google.javascript.jscomp.DiagnosticType diagnosticType2 = com.google.javascript.jscomp.DiagnosticType.error("()", "JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}");
        java.text.MessageFormat messageFormat3 = diagnosticType2.format;
        java.lang.String[] strArray4 = com.google.javascript.rhino.ScriptRuntime.emptyStrings;
        com.google.javascript.jscomp.JSError jSError5 = com.google.javascript.jscomp.JSError.make(diagnosticType2, strArray4);
        org.junit.Assert.assertNotNull(diagnosticType2);
        org.junit.Assert.assertNotNull(messageFormat3);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(jSError5);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test382");
        com.google.javascript.rhino.Context context0 = com.google.javascript.rhino.Context.enter();
        org.junit.Assert.assertNotNull(context0);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test383");
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention0 = new com.google.javascript.jscomp.DefaultCodingConvention();
        boolean boolean2 = defaultCodingConvention0.isConstant("hi!");
        java.lang.String str3 = defaultCodingConvention0.getGlobalObject();
        java.lang.String str4 = defaultCodingConvention0.getAbstractMethodName();
        com.google.javascript.rhino.Node node8 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode((com.google.javascript.jscomp.CodingConvention) defaultCodingConvention0, "JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}", 6, 49);
        com.google.javascript.jscomp.CompilerOptions compilerOptions9 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions9.setLooseTypes(true);
        boolean boolean12 = compilerOptions9.reserveRawExports;
        com.google.javascript.jscomp.CheckLevel checkLevel13 = null;
        compilerOptions9.checkUnreachableCode = checkLevel13;
        com.google.javascript.jscomp.MessageBundle messageBundle15 = compilerOptions9.messageBundle;
        java.lang.String str16 = compilerOptions9.sourceMapOutputPath;
        compilerOptions9.inlineConstantVars = false;
        com.google.javascript.jscomp.CompilerOptions compilerOptions19 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions19.setLooseTypes(true);
        boolean boolean22 = compilerOptions19.collapseVariableDeclarations;
        compilerOptions19.moveFunctionDeclarations = false;
        boolean boolean25 = compilerOptions19.decomposeExpressions;
        boolean boolean26 = compilerOptions19.optimizeParameters;
        java.lang.String str27 = compilerOptions19.inputDelimiter;
        java.lang.String[] strArray29 = new java.lang.String[] { "hi!" };
        java.util.LinkedHashSet<java.lang.String> strSet30 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean31 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet30, strArray29);
        compilerOptions19.stripTypes = strSet30;
        compilerOptions9.setIdGenerators((java.util.Set<java.lang.String>) strSet30);
        node8.setDirectives((java.util.Set<java.lang.String>) strSet30);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "window" + "'", str3.equals("window"));
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNull(messageBundle15);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "// Input %num%" + "'", str27.equals("// Input %num%"));
        org.junit.Assert.assertNotNull(strArray29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test384");
        com.google.javascript.rhino.EcmaError ecmaError2 = com.google.javascript.rhino.ScriptRuntime.constructError("()", "error reporter");
        ecmaError2.initSourceName("(language version)");
        org.junit.Assert.assertNotNull(ecmaError2);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test385");
        com.google.javascript.jscomp.mozilla.rhino.ast.AstRoot astRoot0 = null;
        com.google.javascript.jscomp.parsing.Config.LanguageMode languageMode3 = com.google.javascript.jscomp.parsing.Config.LanguageMode.ECMASCRIPT5;
        com.google.javascript.jscomp.parsing.Config config5 = com.google.javascript.jscomp.parsing.ParserRunner.createConfig(false, languageMode3, false);
        com.google.javascript.jscomp.mozilla.rhino.ErrorReporter errorReporter6 = null;
        try {
            com.google.javascript.rhino.Node node7 = com.google.javascript.jscomp.parsing.IRFactory.transformTree(astRoot0, "Not declared as a type name", config5, errorReporter6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + languageMode3 + "' != '" + com.google.javascript.jscomp.parsing.Config.LanguageMode.ECMASCRIPT5 + "'", languageMode3.equals(com.google.javascript.jscomp.parsing.Config.LanguageMode.ECMASCRIPT5));
        org.junit.Assert.assertNotNull(config5);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test386");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setLooseTypes(true);
        compilerOptions0.convertToDottedProperties = false;
        com.google.javascript.jscomp.CheckLevel checkLevel5 = compilerOptions0.reportMissingOverride;
        com.google.javascript.jscomp.CodingConvention codingConvention6 = compilerOptions0.getCodingConvention();
        boolean boolean7 = compilerOptions0.devirtualizePrototypeMethods;
        compilerOptions0.removeDeadCode = true;
        com.google.javascript.jscomp.CheckLevel checkLevel10 = compilerOptions0.checkMissingReturn;
        java.lang.Class<?> wildcardClass11 = checkLevel10.getClass();
        org.junit.Assert.assertTrue("'" + checkLevel5 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel5.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNull(codingConvention6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + checkLevel10 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel10.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(wildcardClass11);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test387");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setLooseTypes(true);
        boolean boolean3 = compilerOptions0.reserveRawExports;
        compilerOptions0.extractPrototypeMemberDeclarations = false;
        boolean boolean6 = compilerOptions0.disambiguateProperties;
        com.google.javascript.jscomp.CheckLevel checkLevel7 = compilerOptions0.aggressiveVarCheck;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap8 = compilerOptions0.cssRenamingMap;
        com.google.javascript.jscomp.SourceMap.Format format9 = compilerOptions0.sourceMapFormat;
        com.google.javascript.jscomp.CheckLevel checkLevel10 = compilerOptions0.aggressiveVarCheck;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + checkLevel7 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel7.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNull(cssRenamingMap8);
        org.junit.Assert.assertNotNull(format9);
        org.junit.Assert.assertTrue("'" + checkLevel10 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel10.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test388");
        com.google.javascript.rhino.Context context0 = new com.google.javascript.rhino.Context();
        context0.setGeneratingSource(true);
        com.google.javascript.jscomp.CompilerOptions.TracerMode tracerMode3 = com.google.javascript.jscomp.CompilerOptions.TracerMode.FAST;
        context0.removeThreadLocal((java.lang.Object) tracerMode3);
        boolean boolean5 = context0.isGeneratingSource();
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        try {
            context0.addPropertyChangeListener(propertyChangeListener6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + tracerMode3 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TracerMode.FAST + "'", tracerMode3.equals(com.google.javascript.jscomp.CompilerOptions.TracerMode.FAST));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test389");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setLooseTypes(true);
        boolean boolean3 = compilerOptions0.collapseVariableDeclarations;
        compilerOptions0.recordFunctionInformation = false;
        compilerOptions0.convertToDottedProperties = false;
        compilerOptions0.collapseVariableDeclarations = false;
        compilerOptions0.inlineGetters = false;
        compilerOptions0.syntheticBlockStartMarker = "TypeError: 4";
        java.lang.String str14 = compilerOptions0.aliasableGlobals;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(str14);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test390");
        com.google.javascript.jscomp.CompilerOptions compilerOptions1 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions1.setLooseTypes(true);
        boolean boolean4 = compilerOptions1.collapseVariableDeclarations;
        compilerOptions1.moveFunctionDeclarations = false;
        boolean boolean7 = compilerOptions1.decomposeExpressions;
        boolean boolean8 = compilerOptions1.optimizeParameters;
        java.lang.String str9 = compilerOptions1.inputDelimiter;
        com.google.javascript.jscomp.ErrorFormat errorFormat10 = com.google.javascript.jscomp.ErrorFormat.LEGACY;
        java.lang.RuntimeException runtimeException11 = com.google.javascript.rhino.ScriptRuntime.undefWriteError((java.lang.Object) (short) 100, (java.lang.Object) str9, (java.lang.Object) errorFormat10);
        java.io.PrintStream printStream12 = null;
        com.google.javascript.jscomp.Compiler compiler13 = new com.google.javascript.jscomp.Compiler(printStream12);
        compiler13.disableThreads();
        com.google.javascript.jscomp.PerformanceTracker performanceTracker15 = compiler13.tracker;
        com.google.javascript.jscomp.MessageFormatter messageFormatter17 = errorFormat10.toFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler13, false);
        com.google.javascript.jscomp.Compiler.IntermediateState intermediateState18 = compiler13.getState();
        try {
            boolean boolean19 = compiler13.isTypeCheckingEnabled();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "// Input %num%" + "'", str9.equals("// Input %num%"));
        org.junit.Assert.assertNotNull(errorFormat10);
        org.junit.Assert.assertNotNull(runtimeException11);
        org.junit.Assert.assertNull(performanceTracker15);
        org.junit.Assert.assertNotNull(messageFormatter17);
        org.junit.Assert.assertNotNull(intermediateState18);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test391");
        com.google.javascript.rhino.Node node3 = new com.google.javascript.rhino.Node(30, 35, 8);
        com.google.javascript.rhino.Node node4 = node3.getLastChild();
        try {
            boolean boolean5 = node4.isSyntheticBlock();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(node4);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test392");
        java.util.logging.Logger logger0 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager1 = new com.google.javascript.jscomp.LoggerErrorManager(logger0);
        com.google.javascript.jscomp.CompilerOptions compilerOptions2 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions2.setLooseTypes(true);
        compilerOptions2.convertToDottedProperties = false;
        com.google.javascript.jscomp.CheckLevel checkLevel7 = compilerOptions2.reportUnknownTypes;
        com.google.javascript.rhino.Node node10 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node12 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node14 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node16 = new com.google.javascript.rhino.Node((int) '4');
        node14.addChildrenToBack(node16);
        node10.addChildAfter(node12, node16);
        com.google.javascript.rhino.Node node20 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node22 = new com.google.javascript.rhino.Node((int) '4');
        node20.addChildrenToBack(node22);
        com.google.javascript.rhino.Node node24 = node10.copyInformationFromForTree(node22);
        com.google.javascript.jscomp.DiagnosticType diagnosticType25 = com.google.javascript.jscomp.Compiler.MOTION_ITERATIONS_ERROR;
        java.lang.String str26 = diagnosticType25.toString();
        java.lang.String[] strArray27 = null;
        com.google.javascript.jscomp.JSError jSError28 = com.google.javascript.jscomp.JSError.make("", node22, diagnosticType25, strArray27);
        java.lang.String str29 = jSError28.toString();
        loggerErrorManager1.report(checkLevel7, jSError28);
        double double31 = loggerErrorManager1.getTypedPercent();
        com.google.javascript.jscomp.JSError[] jSErrorArray32 = loggerErrorManager1.getErrors();
        int int33 = loggerErrorManager1.getWarningCount();
        org.junit.Assert.assertTrue("'" + checkLevel7 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel7.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertNotNull(diagnosticType25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}" + "'", str26.equals("JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}"));
        org.junit.Assert.assertNotNull(jSError28);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "JSC_OPTIMIZE_LOOP_ERROR. Exceeded max number of code motion iterations: {0} at (unknown source) line (unknown line) : (unknown column)" + "'", str29.equals("JSC_OPTIMIZE_LOOP_ERROR. Exceeded max number of code motion iterations: {0} at (unknown source) line (unknown line) : (unknown column)"));
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
        org.junit.Assert.assertNotNull(jSErrorArray32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test393");
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy0 = com.google.javascript.jscomp.PropertyRenamingPolicy.ALL_UNQUOTED;
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy0 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.ALL_UNQUOTED + "'", propertyRenamingPolicy0.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.ALL_UNQUOTED));
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test394");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        java.io.PrintStream printStream2 = null;
        com.google.javascript.jscomp.Compiler compiler3 = new com.google.javascript.jscomp.Compiler(printStream2);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile6 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        java.io.Reader reader7 = jSSourceFile6.getCodeReader();
        com.google.javascript.jscomp.JSModule[] jSModuleArray8 = new com.google.javascript.jscomp.JSModule[] {};
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph9 = new com.google.javascript.jscomp.JSModuleGraph(jSModuleArray8);
        com.google.javascript.jscomp.CompilerOptions compilerOptions10 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions10.setLooseTypes(true);
        boolean boolean13 = compilerOptions10.collapseVariableDeclarations;
        compilerOptions10.moveFunctionDeclarations = false;
        boolean boolean16 = compilerOptions10.decomposeExpressions;
        com.google.javascript.jscomp.CheckLevel checkLevel17 = compilerOptions10.checkMissingGetCssNameLevel;
        com.google.javascript.jscomp.Result result18 = compiler3.compile(jSSourceFile6, jSModuleArray8, compilerOptions10);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile21 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile24 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        java.io.Reader reader25 = jSSourceFile24.getCodeReader();
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray26 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile6, jSSourceFile21, jSSourceFile24 };
        java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList27 = new java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile>();
        boolean boolean28 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList27, jSSourceFileArray26);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile31 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray32 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile31 };
        java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList33 = new java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile>();
        boolean boolean34 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList33, jSSourceFileArray32);
        com.google.javascript.jscomp.CompilerOptions compilerOptions35 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions35.setLooseTypes(true);
        boolean boolean38 = compilerOptions35.reserveRawExports;
        compilerOptions35.extractPrototypeMemberDeclarations = false;
        java.lang.String str41 = compilerOptions35.nameReferenceGraphPath;
        compilerOptions35.setSummaryDetailLevel(0);
        com.google.javascript.jscomp.Result result44 = compiler1.compile((java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList27, (java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList33, compilerOptions35);
        int int45 = compiler1.getWarningCount();
        com.google.javascript.jscomp.PerformanceTracker performanceTracker46 = compiler1.tracker;
        try {
            compiler1.optimize();
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: INTERNAL COMPILER ERROR.\nPlease report this problem.\nnull");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile6);
        org.junit.Assert.assertNotNull(reader7);
        org.junit.Assert.assertNotNull(jSModuleArray8);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + checkLevel17 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel17.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(result18);
        org.junit.Assert.assertNotNull(jSSourceFile21);
        org.junit.Assert.assertNotNull(jSSourceFile24);
        org.junit.Assert.assertNotNull(reader25);
        org.junit.Assert.assertNotNull(jSSourceFileArray26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(jSSourceFile31);
        org.junit.Assert.assertNotNull(jSSourceFileArray32);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNull(str41);
        org.junit.Assert.assertNotNull(result44);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 0 + "'", int45 == 0);
        org.junit.Assert.assertNull(performanceTracker46);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test395");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setLooseTypes(true);
        compilerOptions0.convertToDottedProperties = false;
        com.google.javascript.jscomp.CheckLevel checkLevel5 = compilerOptions0.reportMissingOverride;
        boolean boolean6 = compilerOptions0.aliasAllStrings;
        boolean boolean7 = compilerOptions0.flowSensitiveInlineVariables;
        boolean boolean8 = compilerOptions0.crossModuleCodeMotion;
        compilerOptions0.setChainCalls(true);
        compilerOptions0.setChainCalls(true);
        org.junit.Assert.assertTrue("'" + checkLevel5 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel5.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test396");
        java.lang.String str0 = com.google.javascript.rhino.jstype.JSType.NOT_A_CLASS;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "Not declared as a constructor" + "'", str0.equals("Not declared as a constructor"));
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test397");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile4 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        java.io.Reader reader5 = jSSourceFile4.getCodeReader();
        com.google.javascript.jscomp.JSModule[] jSModuleArray6 = new com.google.javascript.jscomp.JSModule[] {};
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph7 = new com.google.javascript.jscomp.JSModuleGraph(jSModuleArray6);
        com.google.javascript.jscomp.CompilerOptions compilerOptions8 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions8.setLooseTypes(true);
        boolean boolean11 = compilerOptions8.collapseVariableDeclarations;
        compilerOptions8.moveFunctionDeclarations = false;
        boolean boolean14 = compilerOptions8.decomposeExpressions;
        com.google.javascript.jscomp.CheckLevel checkLevel15 = compilerOptions8.checkMissingGetCssNameLevel;
        com.google.javascript.jscomp.Result result16 = compiler1.compile(jSSourceFile4, jSModuleArray6, compilerOptions8);
        com.google.javascript.jscomp.Result result17 = compiler1.getResult();
        boolean boolean18 = compiler1.hasErrors();
        com.google.javascript.jscomp.CodingConvention codingConvention19 = compiler1.getCodingConvention();
        org.junit.Assert.assertNotNull(jSSourceFile4);
        org.junit.Assert.assertNotNull(reader5);
        org.junit.Assert.assertNotNull(jSModuleArray6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + checkLevel15 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel15.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(result16);
        org.junit.Assert.assertNotNull(result17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(codingConvention19);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test398");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setLooseTypes(true);
        boolean boolean3 = compilerOptions0.collapseVariableDeclarations;
        boolean boolean4 = compilerOptions0.generateExports;
        com.google.javascript.jscomp.SourceMap.DetailLevel detailLevel5 = compilerOptions0.sourceMapDetailLevel;
        compilerOptions0.nameReferenceReportPath = "goog.abstractMethod";
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(detailLevel5);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test399");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile4 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        java.io.Reader reader5 = jSSourceFile4.getCodeReader();
        com.google.javascript.jscomp.JSModule[] jSModuleArray6 = new com.google.javascript.jscomp.JSModule[] {};
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph7 = new com.google.javascript.jscomp.JSModuleGraph(jSModuleArray6);
        com.google.javascript.jscomp.CompilerOptions compilerOptions8 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions8.setLooseTypes(true);
        boolean boolean11 = compilerOptions8.collapseVariableDeclarations;
        compilerOptions8.moveFunctionDeclarations = false;
        boolean boolean14 = compilerOptions8.decomposeExpressions;
        com.google.javascript.jscomp.CheckLevel checkLevel15 = compilerOptions8.checkMissingGetCssNameLevel;
        com.google.javascript.jscomp.Result result16 = compiler1.compile(jSSourceFile4, jSModuleArray6, compilerOptions8);
        int int17 = compiler1.getErrorCount();
        try {
            compiler1.processDefines();
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: INTERNAL COMPILER ERROR.\nPlease report this problem.\nnull");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile4);
        org.junit.Assert.assertNotNull(reader5);
        org.junit.Assert.assertNotNull(jSModuleArray6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + checkLevel15 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel15.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(result16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test400");
        com.google.javascript.jscomp.SourceAst sourceAst0 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(sourceAst0, "", false);
        try {
            com.google.javascript.jscomp.Region region5 = compilerInput3.getRegion(6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test401");
        com.google.javascript.jscomp.CompilerOptions compilerOptions1 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions1.setLooseTypes(true);
        boolean boolean4 = compilerOptions1.collapseVariableDeclarations;
        compilerOptions1.moveFunctionDeclarations = false;
        boolean boolean7 = compilerOptions1.decomposeExpressions;
        boolean boolean8 = compilerOptions1.optimizeParameters;
        java.lang.String str9 = compilerOptions1.inputDelimiter;
        com.google.javascript.jscomp.ErrorFormat errorFormat10 = com.google.javascript.jscomp.ErrorFormat.LEGACY;
        java.lang.RuntimeException runtimeException11 = com.google.javascript.rhino.ScriptRuntime.undefWriteError((java.lang.Object) (short) 100, (java.lang.Object) str9, (java.lang.Object) errorFormat10);
        java.io.PrintStream printStream12 = null;
        com.google.javascript.jscomp.Compiler compiler13 = new com.google.javascript.jscomp.Compiler(printStream12);
        compiler13.disableThreads();
        com.google.javascript.jscomp.PerformanceTracker performanceTracker15 = compiler13.tracker;
        com.google.javascript.jscomp.MessageFormatter messageFormatter17 = errorFormat10.toFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler13, false);
        com.google.javascript.jscomp.Compiler.IntermediateState intermediateState18 = compiler13.getState();
        com.google.javascript.jscomp.CompilerOptions compilerOptions19 = null;
        try {
            compiler13.initOptions(compilerOptions19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "// Input %num%" + "'", str9.equals("// Input %num%"));
        org.junit.Assert.assertNotNull(errorFormat10);
        org.junit.Assert.assertNotNull(runtimeException11);
        org.junit.Assert.assertNull(performanceTracker15);
        org.junit.Assert.assertNotNull(messageFormatter17);
        org.junit.Assert.assertNotNull(intermediateState18);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test402");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setLooseTypes(true);
        boolean boolean3 = compilerOptions0.reserveRawExports;
        boolean boolean4 = compilerOptions0.flowSensitiveInlineVariables;
        compilerOptions0.reserveRawExports = true;
        compilerOptions0.inferTypesInGlobalScope = false;
        com.google.javascript.jscomp.CheckLevel checkLevel9 = compilerOptions0.checkMethods;
        compilerOptions0.locale = "";
        boolean boolean12 = compilerOptions0.checkEs5Strict;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + checkLevel9 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel9.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test403");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setLooseTypes(true);
        boolean boolean3 = compilerOptions0.reserveRawExports;
        boolean boolean4 = compilerOptions0.flowSensitiveInlineVariables;
        compilerOptions0.rewriteFunctionExpressions = true;
        java.io.PrintStream printStream7 = null;
        com.google.javascript.jscomp.Compiler compiler8 = new com.google.javascript.jscomp.Compiler(printStream7);
        compiler8.disableThreads();
        com.google.javascript.jscomp.PerformanceTracker performanceTracker10 = compiler8.tracker;
        com.google.javascript.jscomp.NodeTraversal.Callback callback11 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal12 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler8, callback11);
        com.google.javascript.rhino.Node node14 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node16 = new com.google.javascript.rhino.Node((int) '4');
        node14.addChildrenToBack(node16);
        com.google.javascript.jscomp.DiagnosticType diagnosticType20 = com.google.javascript.jscomp.DiagnosticType.warning("hi!", "hi!");
        com.google.javascript.jscomp.DiagnosticType diagnosticType21 = com.google.javascript.jscomp.Compiler.MOTION_ITERATIONS_ERROR;
        int int22 = diagnosticType20.compareTo(diagnosticType21);
        java.lang.String[] strArray23 = com.google.javascript.rhino.ScriptRuntime.emptyStrings;
        com.google.javascript.jscomp.JSError jSError24 = nodeTraversal12.makeError(node16, diagnosticType20, strArray23);
        com.google.javascript.jscomp.CompilerOptions compilerOptions25 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions25.setLooseTypes(true);
        boolean boolean28 = compilerOptions25.collapseVariableDeclarations;
        boolean boolean29 = compilerOptions25.generateExports;
        com.google.javascript.jscomp.SourceMap.DetailLevel detailLevel30 = compilerOptions25.sourceMapDetailLevel;
        com.google.javascript.jscomp.CheckLevel checkLevel31 = null;
        compilerOptions25.brokenClosureRequiresLevel = checkLevel31;
        java.util.Set<java.lang.String> strSet33 = compilerOptions25.aliasableStrings;
        java.lang.RuntimeException runtimeException34 = com.google.javascript.rhino.ScriptRuntime.undefWriteError((java.lang.Object) compilerOptions0, (java.lang.Object) strArray23, (java.lang.Object) compilerOptions25);
        boolean boolean35 = compilerOptions25.checkTypedPropertyCalls;
        boolean boolean36 = compilerOptions25.collapseProperties;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(performanceTracker10);
        org.junit.Assert.assertNotNull(diagnosticType20);
        org.junit.Assert.assertNotNull(diagnosticType21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 30 + "'", int22 == 30);
        org.junit.Assert.assertNotNull(strArray23);
        org.junit.Assert.assertNotNull(jSError24);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(detailLevel30);
        org.junit.Assert.assertNotNull(strSet33);
        org.junit.Assert.assertNotNull(runtimeException34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test404");
        boolean boolean1 = com.google.javascript.rhino.Context.isValidLanguageVersion(22);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test405");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node2 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node4 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node6 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node8 = new com.google.javascript.rhino.Node((int) '4');
        node6.addChildrenToBack(node8);
        node2.addChildAfter(node4, node8);
        com.google.javascript.rhino.Node node12 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node14 = new com.google.javascript.rhino.Node((int) '4');
        node12.addChildrenToBack(node14);
        com.google.javascript.rhino.Node node16 = node2.copyInformationFromForTree(node14);
        com.google.javascript.rhino.Node node17 = node16.getLastChild();
        com.google.javascript.rhino.Node node19 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node21 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node23 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node25 = new com.google.javascript.rhino.Node((int) '4');
        node23.addChildrenToBack(node25);
        node19.addChildAfter(node21, node25);
        com.google.javascript.rhino.Node node29 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node31 = new com.google.javascript.rhino.Node((int) '4');
        node29.addChildrenToBack(node31);
        com.google.javascript.rhino.Node node33 = node19.copyInformationFromForTree(node31);
        node16.addChildToBack(node19);
        com.google.javascript.rhino.Node node35 = node19.cloneNode();
        boolean boolean36 = closureCodingConvention0.isVarArgsParameter(node19);
        com.google.javascript.rhino.jstype.FunctionType functionType37 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType38 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType39 = null;
        closureCodingConvention0.applySubclassRelationship(functionType37, functionType38, subclassType39);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertNull(node17);
        org.junit.Assert.assertNotNull(node33);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test406");
        com.google.javascript.jscomp.SourceFile.Generator generator1 = null;
        com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromGenerator("4", generator1);
        java.lang.String str3 = sourceFile2.toString();
        org.junit.Assert.assertNotNull(sourceFile2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "4" + "'", str3.equals("4"));
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test407");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setLooseTypes(true);
        compilerOptions0.checkSuspiciousCode = false;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap5 = null;
        compilerOptions0.cssRenamingMap = cssRenamingMap5;
        com.google.javascript.jscomp.CompilerOptions compilerOptions7 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions7.setLooseTypes(true);
        boolean boolean10 = compilerOptions7.collapseVariableDeclarations;
        boolean boolean11 = compilerOptions7.generateExports;
        com.google.javascript.jscomp.SourceMap.DetailLevel detailLevel12 = compilerOptions7.sourceMapDetailLevel;
        compilerOptions7.rewriteFunctionExpressions = true;
        com.google.javascript.jscomp.CheckLevel checkLevel15 = compilerOptions7.checkFunctions;
        compilerOptions7.flowSensitiveInlineVariables = true;
        java.lang.String str18 = compilerOptions7.jsOutputFile;
        com.google.javascript.jscomp.CheckLevel checkLevel19 = compilerOptions7.checkRequires;
        compilerOptions0.reportMissingOverride = checkLevel19;
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(detailLevel12);
        org.junit.Assert.assertTrue("'" + checkLevel15 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel15.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "" + "'", str18.equals(""));
        org.junit.Assert.assertTrue("'" + checkLevel19 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel19.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test408");
        com.google.javascript.rhino.EvaluatorException evaluatorException3 = new com.google.javascript.rhino.EvaluatorException("", "Exceeded max number of code motion iterations: {0}", (int) '#');
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test409");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        compiler1.disableThreads();
        com.google.javascript.jscomp.PerformanceTracker performanceTracker3 = compiler1.tracker;
        com.google.javascript.jscomp.NodeTraversal.Callback callback4 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal5 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler1, callback4);
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter6 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler1);
        lightweightMessageFormatter6.setColorize(false);
        org.junit.Assert.assertNull(performanceTracker3);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test410");
        com.google.javascript.rhino.Node node4 = new com.google.javascript.rhino.Node(30, 35, 8);
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable5 = node4.siblings();
        com.google.javascript.rhino.JSDocInfo jSDocInfo6 = node4.getJSDocInfo();
        com.google.javascript.rhino.Node[] nodeArray7 = new com.google.javascript.rhino.Node[] { node4 };
        com.google.javascript.rhino.Node node10 = new com.google.javascript.rhino.Node(4, nodeArray7, (int) ' ', 140);
        org.junit.Assert.assertNotNull(nodeIterable5);
        org.junit.Assert.assertNull(jSDocInfo6);
        org.junit.Assert.assertNotNull(nodeArray7);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test411");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setLooseTypes(true);
        boolean boolean3 = compilerOptions0.reserveRawExports;
        boolean boolean4 = compilerOptions0.flowSensitiveInlineVariables;
        compilerOptions0.rewriteFunctionExpressions = true;
        java.lang.String str7 = compilerOptions0.unaliasableGlobals;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy8 = compilerOptions0.variableRenaming;
        com.google.javascript.rhino.Node node11 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node15 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node17 = new com.google.javascript.rhino.Node((int) '4');
        node15.addChildrenToBack(node17);
        node11.addChildAfter(node13, node17);
        com.google.javascript.rhino.Node node21 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node23 = new com.google.javascript.rhino.Node((int) '4');
        node21.addChildrenToBack(node23);
        com.google.javascript.rhino.Node node25 = node11.copyInformationFromForTree(node23);
        com.google.javascript.jscomp.DiagnosticType diagnosticType26 = com.google.javascript.jscomp.Compiler.MOTION_ITERATIONS_ERROR;
        java.lang.String str27 = diagnosticType26.toString();
        java.lang.String[] strArray28 = null;
        com.google.javascript.jscomp.JSError jSError29 = com.google.javascript.jscomp.JSError.make("", node23, diagnosticType26, strArray28);
        java.lang.String str30 = jSError29.description;
        java.lang.RuntimeException runtimeException31 = com.google.javascript.rhino.ScriptRuntime.undefReadError((java.lang.Object) compilerOptions0, (java.lang.Object) str30);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy8 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.OFF + "'", variableRenamingPolicy8.equals(com.google.javascript.jscomp.VariableRenamingPolicy.OFF));
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNotNull(diagnosticType26);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}" + "'", str27.equals("JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}"));
        org.junit.Assert.assertNotNull(jSError29);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "Exceeded max number of code motion iterations: {0}" + "'", str30.equals("Exceeded max number of code motion iterations: {0}"));
        org.junit.Assert.assertNotNull(runtimeException31);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test412");
        com.google.javascript.rhino.Node node1 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node3 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node5 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node7 = new com.google.javascript.rhino.Node((int) '4');
        node5.addChildrenToBack(node7);
        node1.addChildAfter(node3, node7);
        com.google.javascript.rhino.Node node11 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node((int) '4');
        node11.addChildrenToBack(node13);
        com.google.javascript.rhino.Node node15 = node1.copyInformationFromForTree(node13);
        com.google.javascript.rhino.Node node17 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node18 = node1.copyInformationFromForTree(node17);
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention19 = new com.google.javascript.jscomp.DefaultCodingConvention();
        boolean boolean21 = defaultCodingConvention19.isExported("// Input %num%");
        boolean boolean23 = defaultCodingConvention19.isSuperClassReference("");
        com.google.javascript.rhino.Node node25 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node27 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node29 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node31 = new com.google.javascript.rhino.Node((int) '4');
        node29.addChildrenToBack(node31);
        node25.addChildAfter(node27, node31);
        boolean boolean34 = node27.wasEmptyNode();
        java.lang.String str35 = defaultCodingConvention19.identifyTypeDefAssign(node27);
        com.google.javascript.rhino.Node node36 = node17.clonePropsFrom(node27);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNull(str35);
        org.junit.Assert.assertNotNull(node36);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test413");
        com.google.javascript.jscomp.SourceAst sourceAst0 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(sourceAst0, "", false);
        com.google.javascript.jscomp.JSModule jSModule4 = compilerInput3.getModule();
        com.google.javascript.jscomp.CompilerInput compilerInput7 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput3, "JSC_OPTIMIZE_LOOP_ERROR. Exceeded max number of code motion iterations: {0} at (unknown source) line (unknown line) : (unknown column)", false);
        try {
            java.util.Collection<java.lang.String> strCollection8 = compilerInput7.getRequires();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Expected setErrorManager to be called first");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(jSModule4);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test414");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeUnusedPrototypePropertiesInExterns = false;
        compilerOptions0.removeUnusedLocalVars = false;
        compilerOptions0.ignoreCajaProperties = false;
        com.google.javascript.jscomp.CodingConvention codingConvention7 = compilerOptions0.getCodingConvention();
        compilerOptions0.setChainCalls(false);
        com.google.javascript.jscomp.SourceMap.Format format10 = null;
        compilerOptions0.sourceMapFormat = format10;
        org.junit.Assert.assertNull(codingConvention7);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test415");
        com.google.javascript.jscomp.SourceAst sourceAst0 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(sourceAst0, "", false);
        boolean boolean4 = compilerInput3.isExtern();
        java.lang.String str5 = compilerInput3.getName();
        com.google.javascript.jscomp.JSModule jSModule6 = compilerInput3.getModule();
        com.google.javascript.jscomp.CompilerInput compilerInput9 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput3, "<No stack trace available>", false);
        com.google.javascript.jscomp.SourceAst sourceAst10 = compilerInput9.getSourceAst();
        java.util.logging.Logger logger11 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager12 = new com.google.javascript.jscomp.LoggerErrorManager(logger11);
        com.google.javascript.jscomp.CompilerOptions compilerOptions13 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions13.setLooseTypes(true);
        compilerOptions13.convertToDottedProperties = false;
        com.google.javascript.jscomp.CheckLevel checkLevel18 = compilerOptions13.reportMissingOverride;
        com.google.javascript.rhino.Node node21 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node23 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node25 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node27 = new com.google.javascript.rhino.Node((int) '4');
        node25.addChildrenToBack(node27);
        node21.addChildAfter(node23, node27);
        com.google.javascript.rhino.Node node31 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node33 = new com.google.javascript.rhino.Node((int) '4');
        node31.addChildrenToBack(node33);
        com.google.javascript.rhino.Node node35 = node21.copyInformationFromForTree(node33);
        com.google.javascript.jscomp.DiagnosticType diagnosticType36 = com.google.javascript.jscomp.Compiler.MOTION_ITERATIONS_ERROR;
        java.lang.String str37 = diagnosticType36.toString();
        java.lang.String[] strArray38 = null;
        com.google.javascript.jscomp.JSError jSError39 = com.google.javascript.jscomp.JSError.make("", node33, diagnosticType36, strArray38);
        java.lang.String str40 = jSError39.toString();
        loggerErrorManager12.println(checkLevel18, jSError39);
        int int42 = loggerErrorManager12.getWarningCount();
        int int43 = loggerErrorManager12.getWarningCount();
        compilerInput9.setErrorManager((com.google.javascript.jscomp.ErrorManager) loggerErrorManager12);
        try {
            java.lang.String str45 = compilerInput9.getCode();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertNull(jSModule6);
        org.junit.Assert.assertNotNull(sourceAst10);
        org.junit.Assert.assertTrue("'" + checkLevel18 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel18.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertNotNull(diagnosticType36);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}" + "'", str37.equals("JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}"));
        org.junit.Assert.assertNotNull(jSError39);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "JSC_OPTIMIZE_LOOP_ERROR. Exceeded max number of code motion iterations: {0} at (unknown source) line (unknown line) : (unknown column)" + "'", str40.equals("JSC_OPTIMIZE_LOOP_ERROR. Exceeded max number of code motion iterations: {0} at (unknown source) line (unknown line) : (unknown column)"));
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test416");
        com.google.javascript.jscomp.SourceAst sourceAst0 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(sourceAst0, "", false);
        boolean boolean4 = compilerInput3.isExtern();
        try {
            compilerInput3.clearAst();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test417");
        com.google.javascript.rhino.EcmaError ecmaError1 = com.google.javascript.rhino.ScriptRuntime.typeError("(<No stack trace available>)");
        java.lang.String str2 = ecmaError1.details();
        org.junit.Assert.assertNotNull(ecmaError1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "TypeError: (<No stack trace available>)" + "'", str2.equals("TypeError: (<No stack trace available>)"));
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test418");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile4 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        java.io.Reader reader5 = jSSourceFile4.getCodeReader();
        com.google.javascript.jscomp.JSModule[] jSModuleArray6 = new com.google.javascript.jscomp.JSModule[] {};
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph7 = new com.google.javascript.jscomp.JSModuleGraph(jSModuleArray6);
        com.google.javascript.jscomp.CompilerOptions compilerOptions8 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions8.setLooseTypes(true);
        boolean boolean11 = compilerOptions8.collapseVariableDeclarations;
        compilerOptions8.moveFunctionDeclarations = false;
        boolean boolean14 = compilerOptions8.decomposeExpressions;
        com.google.javascript.jscomp.CheckLevel checkLevel15 = compilerOptions8.checkMissingGetCssNameLevel;
        com.google.javascript.jscomp.Result result16 = compiler1.compile(jSSourceFile4, jSModuleArray6, compilerOptions8);
        com.google.javascript.jscomp.Result result17 = compiler1.getResult();
        boolean boolean18 = compiler1.hasErrors();
        com.google.javascript.jscomp.SourceFile.Generator generator20 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile21 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("JSC_OPTIMIZE_LOOP_ERROR. Exceeded max number of code motion iterations: {0} at (unknown source) line (unknown line) : (unknown column)", generator20);
        com.google.javascript.jscomp.SourceFile.Generator generator23 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile24 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("JSC_OPTIMIZE_LOOP_ERROR. Exceeded max number of code motion iterations: {0} at (unknown source) line (unknown line) : (unknown column)", generator23);
        com.google.javascript.jscomp.CompilerOptions compilerOptions25 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions25.setLooseTypes(true);
        boolean boolean28 = compilerOptions25.reserveRawExports;
        compilerOptions25.extractPrototypeMemberDeclarations = false;
        java.lang.String str31 = compilerOptions25.nameReferenceGraphPath;
        compilerOptions25.computeFunctionSideEffects = true;
        com.google.javascript.jscomp.CompilerOptions compilerOptions34 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions34.setLooseTypes(true);
        compilerOptions34.convertToDottedProperties = false;
        com.google.javascript.jscomp.CheckLevel checkLevel39 = compilerOptions34.reportMissingOverride;
        compilerOptions25.brokenClosureRequiresLevel = checkLevel39;
        java.util.Set<java.lang.String> strSet41 = compilerOptions25.stripTypePrefixes;
        compilerOptions25.optimizeReturns = true;
        com.google.javascript.jscomp.Result result44 = compiler1.compile(jSSourceFile21, jSSourceFile24, compilerOptions25);
        boolean boolean45 = compilerOptions25.removeUnusedPrototypeProperties;
        org.junit.Assert.assertNotNull(jSSourceFile4);
        org.junit.Assert.assertNotNull(reader5);
        org.junit.Assert.assertNotNull(jSModuleArray6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + checkLevel15 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel15.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(result16);
        org.junit.Assert.assertNotNull(result17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(jSSourceFile21);
        org.junit.Assert.assertNotNull(jSSourceFile24);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNull(str31);
        org.junit.Assert.assertTrue("'" + checkLevel39 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel39.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(strSet41);
        org.junit.Assert.assertNotNull(result44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test419");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setLooseTypes(true);
        compilerOptions0.checkSuspiciousCode = false;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap5 = null;
        compilerOptions0.cssRenamingMap = cssRenamingMap5;
        compilerOptions0.aliasableGlobals = "hi!: hi!";
        boolean boolean9 = compilerOptions0.removeTryCatchFinally;
        com.google.javascript.jscomp.CheckLevel checkLevel10 = compilerOptions0.checkMissingGetCssNameLevel;
        compilerOptions0.setLooseTypes(false);
        compilerOptions0.disambiguateProperties = false;
        com.google.javascript.jscomp.CompilerOptions compilerOptions15 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions15.setLooseTypes(true);
        boolean boolean18 = compilerOptions15.collapseVariableDeclarations;
        compilerOptions15.moveFunctionDeclarations = false;
        boolean boolean21 = compilerOptions15.decomposeExpressions;
        compilerOptions15.syntheticBlockEndMarker = "Exceeded max number of code motion iterations: {0}";
        com.google.javascript.jscomp.CheckLevel checkLevel24 = compilerOptions15.checkUnreachableCode;
        compilerOptions0.checkUndefinedProperties = checkLevel24;
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + checkLevel10 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel10.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + checkLevel24 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel24.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test420");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        boolean boolean2 = closureCodingConvention0.isPrivate("// Input %num%");
        boolean boolean4 = closureCodingConvention0.isConstant("(<No stack trace available>)");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test421");
        com.google.javascript.jscomp.CompilerOptions compilerOptions1 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions1.setLooseTypes(true);
        boolean boolean4 = compilerOptions1.collapseVariableDeclarations;
        compilerOptions1.moveFunctionDeclarations = false;
        boolean boolean7 = compilerOptions1.decomposeExpressions;
        boolean boolean8 = compilerOptions1.optimizeParameters;
        java.lang.String str9 = compilerOptions1.inputDelimiter;
        com.google.javascript.jscomp.ErrorFormat errorFormat10 = com.google.javascript.jscomp.ErrorFormat.LEGACY;
        java.lang.RuntimeException runtimeException11 = com.google.javascript.rhino.ScriptRuntime.undefWriteError((java.lang.Object) (short) 100, (java.lang.Object) str9, (java.lang.Object) errorFormat10);
        java.io.PrintStream printStream12 = null;
        com.google.javascript.jscomp.Compiler compiler13 = new com.google.javascript.jscomp.Compiler(printStream12);
        java.io.PrintStream printStream14 = null;
        com.google.javascript.jscomp.Compiler compiler15 = new com.google.javascript.jscomp.Compiler(printStream14);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile18 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        java.io.Reader reader19 = jSSourceFile18.getCodeReader();
        com.google.javascript.jscomp.JSModule[] jSModuleArray20 = new com.google.javascript.jscomp.JSModule[] {};
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph21 = new com.google.javascript.jscomp.JSModuleGraph(jSModuleArray20);
        com.google.javascript.jscomp.CompilerOptions compilerOptions22 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions22.setLooseTypes(true);
        boolean boolean25 = compilerOptions22.collapseVariableDeclarations;
        compilerOptions22.moveFunctionDeclarations = false;
        boolean boolean28 = compilerOptions22.decomposeExpressions;
        com.google.javascript.jscomp.CheckLevel checkLevel29 = compilerOptions22.checkMissingGetCssNameLevel;
        com.google.javascript.jscomp.Result result30 = compiler15.compile(jSSourceFile18, jSModuleArray20, compilerOptions22);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile33 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile36 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        java.io.Reader reader37 = jSSourceFile36.getCodeReader();
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray38 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile18, jSSourceFile33, jSSourceFile36 };
        java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList39 = new java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile>();
        boolean boolean40 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList39, jSSourceFileArray38);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile43 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray44 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile43 };
        java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList45 = new java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile>();
        boolean boolean46 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList45, jSSourceFileArray44);
        com.google.javascript.jscomp.CompilerOptions compilerOptions47 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions47.setLooseTypes(true);
        boolean boolean50 = compilerOptions47.reserveRawExports;
        compilerOptions47.extractPrototypeMemberDeclarations = false;
        java.lang.String str53 = compilerOptions47.nameReferenceGraphPath;
        compilerOptions47.setSummaryDetailLevel(0);
        com.google.javascript.jscomp.Result result56 = compiler13.compile((java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList39, (java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList45, compilerOptions47);
        boolean boolean57 = compiler13.hasErrors();
        com.google.javascript.jscomp.MessageFormatter messageFormatter59 = errorFormat10.toFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler13, true);
        try {
            compiler13.normalize();
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: INTERNAL COMPILER ERROR.\nPlease report this problem.\nnull");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "// Input %num%" + "'", str9.equals("// Input %num%"));
        org.junit.Assert.assertNotNull(errorFormat10);
        org.junit.Assert.assertNotNull(runtimeException11);
        org.junit.Assert.assertNotNull(jSSourceFile18);
        org.junit.Assert.assertNotNull(reader19);
        org.junit.Assert.assertNotNull(jSModuleArray20);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + checkLevel29 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel29.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(result30);
        org.junit.Assert.assertNotNull(jSSourceFile33);
        org.junit.Assert.assertNotNull(jSSourceFile36);
        org.junit.Assert.assertNotNull(reader37);
        org.junit.Assert.assertNotNull(jSSourceFileArray38);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertNotNull(jSSourceFile43);
        org.junit.Assert.assertNotNull(jSSourceFileArray44);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNull(str53);
        org.junit.Assert.assertNotNull(result56);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + true + "'", boolean57 == true);
        org.junit.Assert.assertNotNull(messageFormatter59);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test422");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.TWEAKS;
        com.google.javascript.jscomp.DiagnosticGroups.TWEAKS = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticGroups.INVALID_CASTS = diagnosticGroup0;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test423");
        com.google.javascript.jscomp.CompilerOptions compilerOptions1 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions1.setLooseTypes(true);
        boolean boolean4 = compilerOptions1.collapseVariableDeclarations;
        compilerOptions1.moveFunctionDeclarations = false;
        boolean boolean7 = compilerOptions1.decomposeExpressions;
        boolean boolean8 = compilerOptions1.optimizeParameters;
        java.lang.String str9 = compilerOptions1.inputDelimiter;
        com.google.javascript.jscomp.ErrorFormat errorFormat10 = com.google.javascript.jscomp.ErrorFormat.LEGACY;
        java.lang.RuntimeException runtimeException11 = com.google.javascript.rhino.ScriptRuntime.undefWriteError((java.lang.Object) (short) 100, (java.lang.Object) str9, (java.lang.Object) errorFormat10);
        com.google.javascript.rhino.EcmaError ecmaError13 = com.google.javascript.rhino.ScriptRuntime.typeError("4");
        java.lang.String str14 = ecmaError13.getName();
        java.lang.String str15 = ecmaError13.lineSource();
        java.lang.String str16 = ecmaError13.toString();
        java.lang.String str17 = ecmaError13.lineSource();
        ecmaError13.initLineSource("com.google.javascript.rhino.EcmaError: TypeError: 4");
        java.lang.String str20 = ecmaError13.lineSource();
        runtimeException11.addSuppressed((java.lang.Throwable) ecmaError13);
        try {
            ecmaError13.initLineSource("language version");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "// Input %num%" + "'", str9.equals("// Input %num%"));
        org.junit.Assert.assertNotNull(errorFormat10);
        org.junit.Assert.assertNotNull(runtimeException11);
        org.junit.Assert.assertNotNull(ecmaError13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "TypeError" + "'", str14.equals("TypeError"));
        org.junit.Assert.assertNull(str15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "com.google.javascript.rhino.EcmaError: TypeError: 4" + "'", str16.equals("com.google.javascript.rhino.EcmaError: TypeError: 4"));
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "com.google.javascript.rhino.EcmaError: TypeError: 4" + "'", str20.equals("com.google.javascript.rhino.EcmaError: TypeError: 4"));
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test424");
        int int0 = com.google.javascript.rhino.Node.DIRECTIVES;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 47 + "'", int0 == 47);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test425");
        com.google.javascript.jscomp.CompilerOptions compilerOptions1 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions1.setLooseTypes(true);
        compilerOptions1.checkSuspiciousCode = false;
        compilerOptions1.setCollapsePropertiesOnExternTypes(false);
        com.google.javascript.jscomp.CheckLevel checkLevel8 = compilerOptions1.checkMethods;
        try {
            java.lang.String str9 = com.google.javascript.rhino.ScriptRuntime.getMessage1("null", (java.lang.Object) compilerOptions1);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property null");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertTrue("'" + checkLevel8 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel8.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test426");
        try {
            com.google.javascript.rhino.EcmaError ecmaError3 = com.google.javascript.rhino.ScriptRuntime.typeError2("", "", "INSTANCEOF\n");
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property ");
        } catch (java.lang.RuntimeException e) {
        }
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test427");
        com.google.javascript.rhino.EcmaError ecmaError1 = com.google.javascript.rhino.ScriptRuntime.typeError("4");
        java.lang.String str2 = ecmaError1.getName();
        java.lang.String str3 = ecmaError1.lineSource();
        java.lang.String str4 = ecmaError1.toString();
        java.lang.String str5 = ecmaError1.lineSource();
        java.lang.String str6 = ecmaError1.getSourceName();
        java.lang.String str7 = ecmaError1.getSourceName();
        org.junit.Assert.assertNotNull(ecmaError1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "TypeError" + "'", str2.equals("TypeError"));
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "com.google.javascript.rhino.EcmaError: TypeError: 4" + "'", str4.equals("com.google.javascript.rhino.EcmaError: TypeError: 4"));
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNull(str7);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test428");
        try {
            java.lang.String str2 = com.google.javascript.rhino.ScriptRuntime.escapeString("hi!", '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: FAILED ASSERTION");
        } catch (java.lang.IllegalStateException e) {
        }
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test429");
        com.google.javascript.jscomp.SourceAst sourceAst0 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(sourceAst0, "", false);
        com.google.javascript.jscomp.JSModule jSModule4 = compilerInput3.getModule();
        com.google.javascript.jscomp.CompilerInput compilerInput7 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput3, "JSC_OPTIMIZE_LOOP_ERROR. Exceeded max number of code motion iterations: {0} at (unknown source) line (unknown line) : (unknown column)", false);
        try {
            java.lang.String str9 = compilerInput7.getLine(33);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(jSModule4);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test430");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile4 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        java.io.Reader reader5 = jSSourceFile4.getCodeReader();
        com.google.javascript.jscomp.JSModule[] jSModuleArray6 = new com.google.javascript.jscomp.JSModule[] {};
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph7 = new com.google.javascript.jscomp.JSModuleGraph(jSModuleArray6);
        com.google.javascript.jscomp.CompilerOptions compilerOptions8 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions8.setLooseTypes(true);
        boolean boolean11 = compilerOptions8.collapseVariableDeclarations;
        compilerOptions8.moveFunctionDeclarations = false;
        boolean boolean14 = compilerOptions8.decomposeExpressions;
        com.google.javascript.jscomp.CheckLevel checkLevel15 = compilerOptions8.checkMissingGetCssNameLevel;
        com.google.javascript.jscomp.Result result16 = compiler1.compile(jSSourceFile4, jSModuleArray6, compilerOptions8);
        com.google.javascript.jscomp.Result result17 = compiler1.getResult();
        boolean boolean18 = compiler1.hasErrors();
        com.google.javascript.jscomp.SourceFile.Generator generator20 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile21 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("JSC_OPTIMIZE_LOOP_ERROR. Exceeded max number of code motion iterations: {0} at (unknown source) line (unknown line) : (unknown column)", generator20);
        com.google.javascript.jscomp.SourceFile.Generator generator23 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile24 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("JSC_OPTIMIZE_LOOP_ERROR. Exceeded max number of code motion iterations: {0} at (unknown source) line (unknown line) : (unknown column)", generator23);
        com.google.javascript.jscomp.CompilerOptions compilerOptions25 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions25.setLooseTypes(true);
        boolean boolean28 = compilerOptions25.reserveRawExports;
        compilerOptions25.extractPrototypeMemberDeclarations = false;
        java.lang.String str31 = compilerOptions25.nameReferenceGraphPath;
        compilerOptions25.computeFunctionSideEffects = true;
        com.google.javascript.jscomp.CompilerOptions compilerOptions34 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions34.setLooseTypes(true);
        compilerOptions34.convertToDottedProperties = false;
        com.google.javascript.jscomp.CheckLevel checkLevel39 = compilerOptions34.reportMissingOverride;
        compilerOptions25.brokenClosureRequiresLevel = checkLevel39;
        java.util.Set<java.lang.String> strSet41 = compilerOptions25.stripTypePrefixes;
        compilerOptions25.optimizeReturns = true;
        com.google.javascript.jscomp.Result result44 = compiler1.compile(jSSourceFile21, jSSourceFile24, compilerOptions25);
        com.google.javascript.jscomp.CompilerOptions.TweakProcessing tweakProcessing45 = compilerOptions25.getTweakProcessing();
        org.junit.Assert.assertNotNull(jSSourceFile4);
        org.junit.Assert.assertNotNull(reader5);
        org.junit.Assert.assertNotNull(jSModuleArray6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + checkLevel15 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel15.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(result16);
        org.junit.Assert.assertNotNull(result17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(jSSourceFile21);
        org.junit.Assert.assertNotNull(jSSourceFile24);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNull(str31);
        org.junit.Assert.assertTrue("'" + checkLevel39 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel39.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(strSet41);
        org.junit.Assert.assertNotNull(result44);
        org.junit.Assert.assertTrue("'" + tweakProcessing45 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TweakProcessing.OFF + "'", tweakProcessing45.equals(com.google.javascript.jscomp.CompilerOptions.TweakProcessing.OFF));
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test431");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.STRICT_MODULE_DEP_CHECK;
        com.google.javascript.jscomp.DiagnosticGroups.MISSING_PROPERTIES = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticGroups.STRICT_MODULE_DEP_CHECK = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticGroups.INVALID_CASTS = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticGroups.CHECK_REGEXP = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticGroups.EXTERNS_VALIDATION = diagnosticGroup0;
        org.junit.Assert.assertNull(diagnosticGroup0);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test432");
        com.google.javascript.jscomp.DiagnosticType diagnosticType2 = com.google.javascript.jscomp.DiagnosticType.error("DiagnosticGroup<externsValidation>", "4");
        com.google.javascript.jscomp.DiagnosticType diagnosticType5 = com.google.javascript.jscomp.DiagnosticType.warning("hi!", "hi!");
        java.lang.String str6 = diagnosticType5.key;
        java.lang.String str7 = diagnosticType5.toString();
        int int8 = diagnosticType2.compareTo(diagnosticType5);
        org.junit.Assert.assertNotNull(diagnosticType2);
        org.junit.Assert.assertNotNull(diagnosticType5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "hi!: hi!" + "'", str7.equals("hi!: hi!"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-36) + "'", int8 == (-36));
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test433");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setLooseTypes(true);
        compilerOptions0.convertToDottedProperties = false;
        com.google.javascript.jscomp.CheckLevel checkLevel5 = compilerOptions0.reportUnknownTypes;
        boolean boolean6 = compilerOptions0.optimizeReturns;
        compilerOptions0.convertToDottedProperties = true;
        compilerOptions0.checkSymbols = true;
        compilerOptions0.gatherCssNames = true;
        org.junit.Assert.assertTrue("'" + checkLevel5 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel5.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test434");
        com.google.javascript.rhino.Context context0 = new com.google.javascript.rhino.Context();
        context0.setGeneratingSource(true);
        boolean boolean3 = context0.isGeneratingDebug();
        boolean boolean4 = context0.isGeneratingSource();
        long long5 = com.google.javascript.rhino.ScriptRuntime.lastUint32Result(context0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test435");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setLooseTypes(true);
        boolean boolean3 = compilerOptions0.collapseVariableDeclarations;
        compilerOptions0.moveFunctionDeclarations = false;
        boolean boolean6 = compilerOptions0.decomposeExpressions;
        boolean boolean7 = compilerOptions0.optimizeParameters;
        java.lang.String str8 = compilerOptions0.inputDelimiter;
        java.lang.String[] strArray10 = new java.lang.String[] { "hi!" };
        java.util.LinkedHashSet<java.lang.String> strSet11 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean12 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet11, strArray10);
        compilerOptions0.stripTypes = strSet11;
        boolean boolean14 = compilerOptions0.inlineLocalVariables;
        com.google.javascript.jscomp.CompilerOptions.AliasTransformationHandler aliasTransformationHandler15 = compilerOptions0.getAliasTransformationHandler();
        com.google.javascript.jscomp.CheckLevel checkLevel16 = compilerOptions0.checkMissingGetCssNameLevel;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "// Input %num%" + "'", str8.equals("// Input %num%"));
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(aliasTransformationHandler15);
        org.junit.Assert.assertTrue("'" + checkLevel16 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel16.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test436");
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention0 = new com.google.javascript.jscomp.DefaultCodingConvention();
        boolean boolean2 = defaultCodingConvention0.isExported("// Input %num%");
        boolean boolean4 = defaultCodingConvention0.isSuperClassReference("");
        com.google.javascript.rhino.Node node6 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node8 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node10 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node12 = new com.google.javascript.rhino.Node((int) '4');
        node10.addChildrenToBack(node12);
        node6.addChildAfter(node8, node12);
        boolean boolean15 = node8.wasEmptyNode();
        java.lang.String str16 = defaultCodingConvention0.identifyTypeDefAssign(node8);
        boolean boolean19 = defaultCodingConvention0.isExported("Exceeded max number of code motion iterations: {0}", false);
        boolean boolean21 = defaultCodingConvention0.isSuperClassReference("TypeError: 4");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention22 = new com.google.javascript.jscomp.ClosureCodingConvention();
        boolean boolean24 = closureCodingConvention22.isPrivate("// Input %num%");
        com.google.javascript.jscomp.CompilerOptions compilerOptions25 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions25.flowSensitiveInlineVariables = false;
        compilerOptions25.setDefineToBooleanLiteral("// Input %num%", false);
        com.google.javascript.rhino.Node node32 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node34 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node36 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node38 = new com.google.javascript.rhino.Node((int) '4');
        node36.addChildrenToBack(node38);
        node32.addChildAfter(node34, node38);
        com.google.javascript.rhino.Node node42 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node44 = new com.google.javascript.rhino.Node((int) '4');
        node42.addChildrenToBack(node44);
        com.google.javascript.rhino.Node node46 = node32.copyInformationFromForTree(node44);
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable47 = node46.siblings();
        java.lang.RuntimeException runtimeException48 = com.google.javascript.rhino.ScriptRuntime.notFunctionError((java.lang.Object) compilerOptions25, (java.lang.Object) node46);
        boolean boolean49 = closureCodingConvention22.isVarArgsParameter(node46);
        com.google.javascript.rhino.Node node50 = null;
        try {
            java.lang.String str51 = defaultCodingConvention0.extractClassNameIfProvide(node46, node50);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: only implemented in GoogleCodingConvention");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(node46);
        org.junit.Assert.assertNotNull(nodeIterable47);
        org.junit.Assert.assertNotNull(runtimeException48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test437");
        com.google.javascript.rhino.Node node1 = new com.google.javascript.rhino.Node(43);
        boolean boolean2 = node1.hasOneChild();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test438");
        com.google.javascript.rhino.EcmaError ecmaError2 = com.google.javascript.rhino.ScriptRuntime.constructError("goog.global", "hi!: hi!");
        org.junit.Assert.assertNotNull(ecmaError2);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test439");
        com.google.javascript.rhino.Context context0 = new com.google.javascript.rhino.Context();
        context0.setGeneratingSource(true);
        java.lang.Object obj3 = context0.getDebuggerContextData();
        boolean boolean4 = context0.isGeneratingSource();
        boolean boolean6 = context0.isActivationNeeded("Not declared as a constructor");
        org.junit.Assert.assertNull(obj3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test440");
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention0 = new com.google.javascript.jscomp.DefaultCodingConvention();
        boolean boolean2 = defaultCodingConvention0.isExported("// Input %num%");
        com.google.javascript.rhino.Node node4 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node6 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node8 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node10 = new com.google.javascript.rhino.Node((int) '4');
        node8.addChildrenToBack(node10);
        node4.addChildAfter(node6, node10);
        com.google.javascript.rhino.Node node14 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node16 = new com.google.javascript.rhino.Node((int) '4');
        node14.addChildrenToBack(node16);
        com.google.javascript.rhino.Node node18 = node4.copyInformationFromForTree(node16);
        com.google.javascript.rhino.Node node19 = node4.cloneTree();
        com.google.javascript.rhino.Node node23 = new com.google.javascript.rhino.Node(30, 35, 8);
        com.google.javascript.rhino.Node node24 = node23.getLastChild();
        node19.addChildToFront(node23);
        java.lang.String str26 = defaultCodingConvention0.getSingletonGetterClassName(node23);
        boolean boolean29 = defaultCodingConvention0.isExported("error reporter", false);
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry30 = null;
        com.google.javascript.jscomp.Scope scope31 = null;
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention32 = new com.google.javascript.jscomp.DefaultCodingConvention();
        java.lang.String str33 = defaultCodingConvention32.getDelegateSuperclassName();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry34 = null;
        com.google.javascript.jscomp.Scope scope35 = null;
        com.google.javascript.rhino.jstype.ObjectType[] objectTypeArray36 = new com.google.javascript.rhino.jstype.ObjectType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.ObjectType> objectTypeList37 = new java.util.ArrayList<com.google.javascript.rhino.jstype.ObjectType>();
        boolean boolean38 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.ObjectType>) objectTypeList37, objectTypeArray36);
        defaultCodingConvention32.defineDelegateProxyPrototypeProperties(jSTypeRegistry34, scope35, (java.util.List<com.google.javascript.rhino.jstype.ObjectType>) objectTypeList37);
        defaultCodingConvention0.defineDelegateProxyPrototypeProperties(jSTypeRegistry30, scope31, (java.util.List<com.google.javascript.rhino.jstype.ObjectType>) objectTypeList37);
        com.google.javascript.rhino.Node node41 = null;
        java.lang.String str42 = defaultCodingConvention0.identifyTypeDefAssign(node41);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNull(node24);
        org.junit.Assert.assertNull(str26);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNull(str33);
        org.junit.Assert.assertNotNull(objectTypeArray36);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNull(str42);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test441");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setLooseTypes(true);
        boolean boolean3 = compilerOptions0.reserveRawExports;
        compilerOptions0.extractPrototypeMemberDeclarations = false;
        boolean boolean6 = compilerOptions0.disambiguateProperties;
        com.google.javascript.jscomp.CheckLevel checkLevel7 = compilerOptions0.aggressiveVarCheck;
        compilerOptions0.setColorizeErrorOutput(true);
        compilerOptions0.appNameStr = "JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}";
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + checkLevel7 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel7.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test442");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromCode("(language version)", "JSC_OPTIMIZE_LOOP_ERROR. Exceeded max number of code motion iterations: {0} at (unknown source) line (unknown line) : (unknown column)");
        com.google.javascript.jscomp.CompilerInput compilerInput4 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2, false);
        java.lang.String str5 = compilerInput4.getName();
        org.junit.Assert.assertNotNull(jSSourceFile2);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "(language version)" + "'", str5.equals("(language version)"));
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test443");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newNumber((double) 150, 120, 29);
        try {
            node3.setString("(language version)");
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: NUMBER 150.0 120 is not a string node");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(node3);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test444");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        try {
            compiler1.check();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test445");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        java.lang.String str1 = closureCodingConvention0.getGlobalObject();
        java.io.PrintStream printStream2 = null;
        com.google.javascript.jscomp.Compiler compiler3 = new com.google.javascript.jscomp.Compiler(printStream2);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile6 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        java.io.Reader reader7 = jSSourceFile6.getCodeReader();
        com.google.javascript.jscomp.JSModule[] jSModuleArray8 = new com.google.javascript.jscomp.JSModule[] {};
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph9 = new com.google.javascript.jscomp.JSModuleGraph(jSModuleArray8);
        com.google.javascript.jscomp.CompilerOptions compilerOptions10 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions10.setLooseTypes(true);
        boolean boolean13 = compilerOptions10.collapseVariableDeclarations;
        compilerOptions10.moveFunctionDeclarations = false;
        boolean boolean16 = compilerOptions10.decomposeExpressions;
        com.google.javascript.jscomp.CheckLevel checkLevel17 = compilerOptions10.checkMissingGetCssNameLevel;
        com.google.javascript.jscomp.Result result18 = compiler3.compile(jSSourceFile6, jSModuleArray8, compilerOptions10);
        int int19 = compiler3.getErrorCount();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry20 = compiler3.getTypeRegistry();
        com.google.javascript.jscomp.Scope scope21 = null;
        com.google.javascript.rhino.jstype.ObjectType[] objectTypeArray22 = new com.google.javascript.rhino.jstype.ObjectType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.ObjectType> objectTypeList23 = new java.util.ArrayList<com.google.javascript.rhino.jstype.ObjectType>();
        boolean boolean24 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.ObjectType>) objectTypeList23, objectTypeArray22);
        closureCodingConvention0.defineDelegateProxyPrototypeProperties(jSTypeRegistry20, scope21, (java.util.List<com.google.javascript.rhino.jstype.ObjectType>) objectTypeList23);
        com.google.javascript.rhino.Node node27 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node29 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node31 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node33 = new com.google.javascript.rhino.Node((int) '4');
        node31.addChildrenToBack(node33);
        node27.addChildAfter(node29, node33);
        com.google.javascript.rhino.Node node37 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node39 = new com.google.javascript.rhino.Node((int) '4');
        node37.addChildrenToBack(node39);
        com.google.javascript.rhino.Node node41 = node27.copyInformationFromForTree(node39);
        com.google.javascript.rhino.Node node42 = node27.cloneTree();
        com.google.javascript.rhino.Node node43 = node27.cloneTree();
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention44 = new com.google.javascript.jscomp.DefaultCodingConvention();
        com.google.javascript.rhino.Node node46 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node48 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node50 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node52 = new com.google.javascript.rhino.Node((int) '4');
        node50.addChildrenToBack(node52);
        node46.addChildAfter(node48, node52);
        com.google.javascript.rhino.Node node55 = node46.getFirstChild();
        node46.putIntProp(45, 4095);
        com.google.javascript.jscomp.CodingConvention.SubclassRelationship subclassRelationship59 = defaultCodingConvention44.getClassesDefinedByCall(node46);
        java.lang.String str60 = closureCodingConvention0.extractClassNameIfProvide(node43, node46);
        com.google.javascript.rhino.Node node61 = node46.getLastChild();
        try {
            int int62 = node61.getSideEffectFlags();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "goog.global" + "'", str1.equals("goog.global"));
        org.junit.Assert.assertNotNull(jSSourceFile6);
        org.junit.Assert.assertNotNull(reader7);
        org.junit.Assert.assertNotNull(jSModuleArray8);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + checkLevel17 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel17.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(result18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertNotNull(jSTypeRegistry20);
        org.junit.Assert.assertNotNull(objectTypeArray22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(node41);
        org.junit.Assert.assertNotNull(node42);
        org.junit.Assert.assertNotNull(node43);
        org.junit.Assert.assertNull(node55);
        org.junit.Assert.assertNull(subclassRelationship59);
        org.junit.Assert.assertNull(str60);
        org.junit.Assert.assertNull(node61);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test446");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newString("hi!");
        int int2 = node1.getCharno();
        boolean boolean3 = node1.isNoSideEffectsCall();
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable4 = node1.siblings();
        com.google.javascript.rhino.Node node5 = node1.getParent();
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(nodeIterable4);
        org.junit.Assert.assertNull(node5);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test447");
        com.google.javascript.rhino.EcmaError ecmaError1 = com.google.javascript.rhino.ScriptRuntime.typeError("4");
        java.lang.String str2 = ecmaError1.details();
        java.lang.String str3 = ecmaError1.sourceName();
        ecmaError1.initSourceName("false");
        java.lang.String str6 = ecmaError1.getSourceName();
        try {
            ecmaError1.initSourceName("Not declared as a constructor");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(ecmaError1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "TypeError: 4" + "'", str2.equals("TypeError: 4"));
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "false" + "'", str6.equals("false"));
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test448");
        com.google.javascript.rhino.Node node1 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node3 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node5 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node7 = new com.google.javascript.rhino.Node((int) '4');
        node5.addChildrenToBack(node7);
        node1.addChildAfter(node3, node7);
        com.google.javascript.rhino.Node node11 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node((int) '4');
        node11.addChildrenToBack(node13);
        com.google.javascript.rhino.Node node15 = node1.copyInformationFromForTree(node13);
        int int16 = node15.getChildCount();
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test449");
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention0 = new com.google.javascript.jscomp.DefaultCodingConvention();
        boolean boolean2 = defaultCodingConvention0.isExported("// Input %num%");
        com.google.javascript.rhino.Node node4 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node6 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node8 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node10 = new com.google.javascript.rhino.Node((int) '4');
        node8.addChildrenToBack(node10);
        node4.addChildAfter(node6, node10);
        com.google.javascript.rhino.Node node14 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node16 = new com.google.javascript.rhino.Node((int) '4');
        node14.addChildrenToBack(node16);
        com.google.javascript.rhino.Node node18 = node4.copyInformationFromForTree(node16);
        com.google.javascript.rhino.Node node19 = node4.cloneTree();
        com.google.javascript.rhino.Node node23 = new com.google.javascript.rhino.Node(30, 35, 8);
        com.google.javascript.rhino.Node node24 = node23.getLastChild();
        node19.addChildToFront(node23);
        java.lang.String str26 = defaultCodingConvention0.getSingletonGetterClassName(node23);
        int int27 = node23.getType();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNull(node24);
        org.junit.Assert.assertNull(str26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 30 + "'", int27 == 30);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test450");
        com.google.javascript.rhino.Context context0 = new com.google.javascript.rhino.Context();
        context0.setGeneratingSource(true);
        com.google.javascript.jscomp.CompilerOptions.TracerMode tracerMode3 = com.google.javascript.jscomp.CompilerOptions.TracerMode.FAST;
        context0.removeThreadLocal((java.lang.Object) tracerMode3);
        boolean boolean5 = context0.isGeneratingSource();
        java.util.Locale locale6 = context0.getLocale();
        boolean boolean7 = context0.isGeneratingDebug();
        org.junit.Assert.assertTrue("'" + tracerMode3 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TracerMode.FAST + "'", tracerMode3.equals(com.google.javascript.jscomp.CompilerOptions.TracerMode.FAST));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(locale6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test451");
        com.google.javascript.rhino.Node node1 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node3 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node5 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node7 = new com.google.javascript.rhino.Node((int) '4');
        node5.addChildrenToBack(node7);
        node1.addChildAfter(node3, node7);
        node3.setIsSyntheticBlock(true);
        node3.addSuppression("(INSTANCEOF\n)");
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test452");
        com.google.javascript.rhino.Node node1 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node3 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node5 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node7 = new com.google.javascript.rhino.Node((int) '4');
        node5.addChildrenToBack(node7);
        node1.addChildAfter(node3, node7);
        com.google.javascript.rhino.Node node11 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node((int) '4');
        node11.addChildrenToBack(node13);
        com.google.javascript.rhino.Node node15 = node1.copyInformationFromForTree(node13);
        com.google.javascript.rhino.Node node16 = node1.cloneTree();
        com.google.javascript.rhino.Node node20 = new com.google.javascript.rhino.Node(30, 35, 8);
        com.google.javascript.rhino.Node node21 = node20.getLastChild();
        node16.addChildToFront(node20);
        com.google.javascript.rhino.Node.AncestorIterable ancestorIterable23 = node16.getAncestors();
        java.util.Iterator<com.google.javascript.rhino.Node> nodeItor24 = ancestorIterable23.iterator();
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertNull(node21);
        org.junit.Assert.assertNotNull(ancestorIterable23);
        org.junit.Assert.assertNotNull(nodeItor24);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test453");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setLooseTypes(true);
        boolean boolean3 = compilerOptions0.reserveRawExports;
        compilerOptions0.extractPrototypeMemberDeclarations = false;
        compilerOptions0.checkMissingGetCssNameBlacklist = "4";
        compilerOptions0.setTweakToStringLiteral("", "com.google.javascript.rhino.EcmaError: TypeError: 4");
        compilerOptions0.appNameStr = "Named type with empty name component";
        compilerOptions0.setNameAnonymousFunctionsOnly(false);
        compilerOptions0.setTweakToNumberLiteral("language version", 48);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test454");
        com.google.javascript.rhino.Node.SideEffectFlags sideEffectFlags1 = new com.google.javascript.rhino.Node.SideEffectFlags(30);
        sideEffectFlags1.setMutatesGlobalState();
        sideEffectFlags1.setAllFlags();
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test455");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile4 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        java.io.Reader reader5 = jSSourceFile4.getCodeReader();
        com.google.javascript.jscomp.JSModule[] jSModuleArray6 = new com.google.javascript.jscomp.JSModule[] {};
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph7 = new com.google.javascript.jscomp.JSModuleGraph(jSModuleArray6);
        com.google.javascript.jscomp.CompilerOptions compilerOptions8 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions8.setLooseTypes(true);
        boolean boolean11 = compilerOptions8.collapseVariableDeclarations;
        compilerOptions8.moveFunctionDeclarations = false;
        boolean boolean14 = compilerOptions8.decomposeExpressions;
        com.google.javascript.jscomp.CheckLevel checkLevel15 = compilerOptions8.checkMissingGetCssNameLevel;
        com.google.javascript.jscomp.Result result16 = compiler1.compile(jSSourceFile4, jSModuleArray6, compilerOptions8);
        com.google.javascript.jscomp.Result result17 = compiler1.getResult();
        boolean boolean18 = compiler1.hasErrors();
        com.google.javascript.jscomp.SourceFile.Generator generator20 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile21 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("JSC_OPTIMIZE_LOOP_ERROR. Exceeded max number of code motion iterations: {0} at (unknown source) line (unknown line) : (unknown column)", generator20);
        com.google.javascript.jscomp.SourceFile.Generator generator23 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile24 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("JSC_OPTIMIZE_LOOP_ERROR. Exceeded max number of code motion iterations: {0} at (unknown source) line (unknown line) : (unknown column)", generator23);
        com.google.javascript.jscomp.CompilerOptions compilerOptions25 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions25.setLooseTypes(true);
        boolean boolean28 = compilerOptions25.reserveRawExports;
        compilerOptions25.extractPrototypeMemberDeclarations = false;
        java.lang.String str31 = compilerOptions25.nameReferenceGraphPath;
        compilerOptions25.computeFunctionSideEffects = true;
        com.google.javascript.jscomp.CompilerOptions compilerOptions34 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions34.setLooseTypes(true);
        compilerOptions34.convertToDottedProperties = false;
        com.google.javascript.jscomp.CheckLevel checkLevel39 = compilerOptions34.reportMissingOverride;
        compilerOptions25.brokenClosureRequiresLevel = checkLevel39;
        java.util.Set<java.lang.String> strSet41 = compilerOptions25.stripTypePrefixes;
        compilerOptions25.optimizeReturns = true;
        com.google.javascript.jscomp.Result result44 = compiler1.compile(jSSourceFile21, jSSourceFile24, compilerOptions25);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile46 = com.google.javascript.jscomp.JSSourceFile.fromFile("(): error reporter");
        java.lang.String str47 = jSSourceFile46.toString();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile50 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        java.io.Reader reader51 = jSSourceFile50.getCodeReader();
        com.google.javascript.jscomp.CompilerOptions compilerOptions52 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions52.setLooseTypes(true);
        boolean boolean55 = compilerOptions52.reserveRawExports;
        boolean boolean56 = compilerOptions52.flowSensitiveInlineVariables;
        compilerOptions52.reserveRawExports = true;
        compilerOptions52.inferTypesInGlobalScope = false;
        boolean boolean61 = compilerOptions52.markNoSideEffectCalls;
        com.google.javascript.jscomp.CheckLevel checkLevel62 = compilerOptions52.checkProvides;
        com.google.javascript.jscomp.Result result63 = compiler1.compile(jSSourceFile46, jSSourceFile50, compilerOptions52);
        com.google.javascript.jscomp.PerformanceTracker performanceTracker64 = null;
        compiler1.tracker = performanceTracker64;
        org.junit.Assert.assertNotNull(jSSourceFile4);
        org.junit.Assert.assertNotNull(reader5);
        org.junit.Assert.assertNotNull(jSModuleArray6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + checkLevel15 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel15.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(result16);
        org.junit.Assert.assertNotNull(result17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(jSSourceFile21);
        org.junit.Assert.assertNotNull(jSSourceFile24);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNull(str31);
        org.junit.Assert.assertTrue("'" + checkLevel39 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel39.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(strSet41);
        org.junit.Assert.assertNotNull(result44);
        org.junit.Assert.assertNotNull(jSSourceFile46);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "(): error reporter" + "'", str47.equals("(): error reporter"));
        org.junit.Assert.assertNotNull(jSSourceFile50);
        org.junit.Assert.assertNotNull(reader51);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertTrue("'" + checkLevel62 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel62.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(result63);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test456");
        com.google.javascript.rhino.EcmaError ecmaError1 = com.google.javascript.rhino.ScriptRuntime.typeError("4");
        java.lang.String str2 = ecmaError1.getName();
        java.lang.Throwable[] throwableArray3 = ecmaError1.getSuppressed();
        java.lang.String str4 = ecmaError1.details();
        com.google.javascript.rhino.EcmaError ecmaError6 = com.google.javascript.rhino.ScriptRuntime.typeError("4");
        java.lang.String str7 = ecmaError6.getName();
        java.lang.String str8 = ecmaError6.lineSource();
        java.lang.String str9 = ecmaError6.toString();
        java.lang.String str10 = ecmaError6.lineSource();
        ecmaError6.initLineSource("com.google.javascript.rhino.EcmaError: TypeError: 4");
        ecmaError1.addSuppressed((java.lang.Throwable) ecmaError6);
        org.junit.Assert.assertNotNull(ecmaError1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "TypeError" + "'", str2.equals("TypeError"));
        org.junit.Assert.assertNotNull(throwableArray3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "TypeError: 4" + "'", str4.equals("TypeError: 4"));
        org.junit.Assert.assertNotNull(ecmaError6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "TypeError" + "'", str7.equals("TypeError"));
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "com.google.javascript.rhino.EcmaError: TypeError: 4" + "'", str9.equals("com.google.javascript.rhino.EcmaError: TypeError: 4"));
        org.junit.Assert.assertNull(str10);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test457");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setLooseTypes(true);
        compilerOptions0.checkSuspiciousCode = false;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap5 = null;
        compilerOptions0.cssRenamingMap = cssRenamingMap5;
        compilerOptions0.aliasableGlobals = "hi!: hi!";
        com.google.javascript.jscomp.CompilerOptions.TracerMode tracerMode9 = compilerOptions0.tracer;
        com.google.javascript.jscomp.CompilerOptions compilerOptions10 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions10.setLooseTypes(true);
        boolean boolean13 = compilerOptions10.reserveRawExports;
        compilerOptions10.extractPrototypeMemberDeclarations = false;
        compilerOptions10.checkMissingGetCssNameBlacklist = "4";
        compilerOptions10.setTweakToStringLiteral("", "com.google.javascript.rhino.EcmaError: TypeError: 4");
        java.util.Set<java.lang.String> strSet21 = compilerOptions10.stripNameSuffixes;
        compilerOptions0.setIdGenerators(strSet21);
        boolean boolean23 = compilerOptions0.deadAssignmentElimination;
        org.junit.Assert.assertTrue("'" + tracerMode9 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TracerMode.OFF + "'", tracerMode9.equals(com.google.javascript.jscomp.CompilerOptions.TracerMode.OFF));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(strSet21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test458");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        java.io.PrintStream printStream2 = null;
        com.google.javascript.jscomp.Compiler compiler3 = new com.google.javascript.jscomp.Compiler(printStream2);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile6 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        java.io.Reader reader7 = jSSourceFile6.getCodeReader();
        com.google.javascript.jscomp.JSModule[] jSModuleArray8 = new com.google.javascript.jscomp.JSModule[] {};
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph9 = new com.google.javascript.jscomp.JSModuleGraph(jSModuleArray8);
        com.google.javascript.jscomp.CompilerOptions compilerOptions10 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions10.setLooseTypes(true);
        boolean boolean13 = compilerOptions10.collapseVariableDeclarations;
        compilerOptions10.moveFunctionDeclarations = false;
        boolean boolean16 = compilerOptions10.decomposeExpressions;
        com.google.javascript.jscomp.CheckLevel checkLevel17 = compilerOptions10.checkMissingGetCssNameLevel;
        com.google.javascript.jscomp.Result result18 = compiler3.compile(jSSourceFile6, jSModuleArray8, compilerOptions10);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile21 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile24 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        java.io.Reader reader25 = jSSourceFile24.getCodeReader();
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray26 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile6, jSSourceFile21, jSSourceFile24 };
        java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList27 = new java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile>();
        boolean boolean28 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList27, jSSourceFileArray26);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile31 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray32 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile31 };
        java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList33 = new java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile>();
        boolean boolean34 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList33, jSSourceFileArray32);
        com.google.javascript.jscomp.CompilerOptions compilerOptions35 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions35.setLooseTypes(true);
        boolean boolean38 = compilerOptions35.reserveRawExports;
        compilerOptions35.extractPrototypeMemberDeclarations = false;
        java.lang.String str41 = compilerOptions35.nameReferenceGraphPath;
        compilerOptions35.setSummaryDetailLevel(0);
        com.google.javascript.jscomp.Result result44 = compiler1.compile((java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList27, (java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList33, compilerOptions35);
        java.lang.String str45 = compilerOptions35.reportPath;
        org.junit.Assert.assertNotNull(jSSourceFile6);
        org.junit.Assert.assertNotNull(reader7);
        org.junit.Assert.assertNotNull(jSModuleArray8);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + checkLevel17 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel17.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(result18);
        org.junit.Assert.assertNotNull(jSSourceFile21);
        org.junit.Assert.assertNotNull(jSSourceFile24);
        org.junit.Assert.assertNotNull(reader25);
        org.junit.Assert.assertNotNull(jSSourceFileArray26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(jSSourceFile31);
        org.junit.Assert.assertNotNull(jSSourceFileArray32);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNull(str41);
        org.junit.Assert.assertNotNull(result44);
        org.junit.Assert.assertNull(str45);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test459");
        com.google.javascript.jscomp.DiagnosticType diagnosticType2 = com.google.javascript.jscomp.DiagnosticType.disabled("JSC_OPTIMIZE_LOOP_ERROR. Exceeded max number of code motion iterations: {0} at (unknown source) line (unknown line) : (unknown column)", "INSTANCEOF\n");
        org.junit.Assert.assertNotNull(diagnosticType2);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test460");
        com.google.javascript.jscomp.MessageFormatter messageFormatter0 = null;
        java.util.logging.Logger logger1 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager2 = new com.google.javascript.jscomp.LoggerErrorManager(messageFormatter0, logger1);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test461");
        com.google.javascript.jscomp.Compiler.CodeBuilder codeBuilder0 = new com.google.javascript.jscomp.Compiler.CodeBuilder();
        java.lang.String str1 = codeBuilder0.toString();
        int int2 = codeBuilder0.getLength();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test462");
        com.google.javascript.rhino.Node node1 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node3 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node5 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node7 = new com.google.javascript.rhino.Node((int) '4');
        node5.addChildrenToBack(node7);
        node1.addChildAfter(node3, node7);
        com.google.javascript.rhino.Node node11 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node((int) '4');
        node11.addChildrenToBack(node13);
        com.google.javascript.rhino.Node node15 = node1.copyInformationFromForTree(node13);
        com.google.javascript.rhino.Node node17 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node18 = node1.copyInformationFromForTree(node17);
        com.google.javascript.rhino.Node node20 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node22 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node24 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node26 = new com.google.javascript.rhino.Node((int) '4');
        node24.addChildrenToBack(node26);
        node20.addChildAfter(node22, node26);
        com.google.javascript.rhino.Node node30 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node32 = new com.google.javascript.rhino.Node((int) '4');
        node30.addChildrenToBack(node32);
        com.google.javascript.rhino.Node node34 = node20.copyInformationFromForTree(node32);
        com.google.javascript.rhino.jstype.JSType jSType35 = null;
        node34.setJSType(jSType35);
        com.google.javascript.rhino.Node node38 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node40 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node42 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node44 = new com.google.javascript.rhino.Node((int) '4');
        node42.addChildrenToBack(node44);
        node38.addChildAfter(node40, node44);
        com.google.javascript.rhino.Node node48 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node50 = new com.google.javascript.rhino.Node((int) '4');
        node48.addChildrenToBack(node50);
        com.google.javascript.rhino.Node node52 = node38.copyInformationFromForTree(node50);
        node17.addChildAfter(node34, node50);
        boolean boolean54 = node34.hasSideEffects();
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNotNull(node34);
        org.junit.Assert.assertNotNull(node52);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test463");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setLooseTypes(true);
        boolean boolean3 = compilerOptions0.reserveRawExports;
        compilerOptions0.extractPrototypeMemberDeclarations = false;
        boolean boolean6 = compilerOptions0.disambiguateProperties;
        com.google.javascript.jscomp.CheckLevel checkLevel7 = compilerOptions0.aggressiveVarCheck;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap8 = compilerOptions0.cssRenamingMap;
        compilerOptions0.setManageClosureDependencies(true);
        boolean boolean11 = compilerOptions0.inlineVariables;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + checkLevel7 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel7.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNull(cssRenamingMap8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test464");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setLooseTypes(true);
        compilerOptions0.checkSuspiciousCode = false;
        com.google.common.collect.Multimap<com.google.javascript.jscomp.CustomPassExecutionTime, com.google.javascript.jscomp.CompilerPass> customPassExecutionTimeMultimap5 = compilerOptions0.customPasses;
        compilerOptions0.setDefineToDoubleLiteral("Named type with empty name component", (double) (short) 10);
        boolean boolean9 = compilerOptions0.generateExports;
        boolean boolean10 = compilerOptions0.collapseProperties;
        org.junit.Assert.assertNull(customPassExecutionTimeMultimap5);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test465");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newString("hi!");
        int int2 = node1.getCharno();
        boolean boolean3 = node1.isNoSideEffectsCall();
        java.lang.String str4 = node1.getString();
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "hi!" + "'", str4.equals("hi!"));
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test466");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.flowSensitiveInlineVariables = false;
        compilerOptions0.setDefineToBooleanLiteral("// Input %num%", false);
        com.google.javascript.rhino.Node node7 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node9 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node11 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node((int) '4');
        node11.addChildrenToBack(node13);
        node7.addChildAfter(node9, node13);
        com.google.javascript.rhino.Node node17 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node19 = new com.google.javascript.rhino.Node((int) '4');
        node17.addChildrenToBack(node19);
        com.google.javascript.rhino.Node node21 = node7.copyInformationFromForTree(node19);
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable22 = node21.siblings();
        java.lang.RuntimeException runtimeException23 = com.google.javascript.rhino.ScriptRuntime.notFunctionError((java.lang.Object) compilerOptions0, (java.lang.Object) node21);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder24 = node21.getJsDocBuilderForNode();
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertNotNull(nodeIterable22);
        org.junit.Assert.assertNotNull(runtimeException23);
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder24);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test467");
        com.google.javascript.rhino.Node node1 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node3 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node5 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node7 = new com.google.javascript.rhino.Node((int) '4');
        node5.addChildrenToBack(node7);
        node1.addChildAfter(node3, node7);
        com.google.javascript.rhino.Node node10 = node7.getParent();
        com.google.javascript.rhino.jstype.JSType jSType11 = null;
        node10.setJSType(jSType11);
        boolean boolean13 = node10.isOptionalArg();
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test468");
        com.google.javascript.jscomp.SourceAst sourceAst0 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(sourceAst0, "", false);
        com.google.javascript.jscomp.JSModule jSModule4 = compilerInput3.getModule();
        com.google.javascript.jscomp.JSModule jSModule5 = null;
        compilerInput3.setModule(jSModule5);
        try {
            java.lang.String str8 = compilerInput3.getLine(4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(jSModule4);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test469");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setLooseTypes(true);
        boolean boolean3 = compilerOptions0.reserveRawExports;
        compilerOptions0.extractPrototypeMemberDeclarations = false;
        java.lang.String str6 = compilerOptions0.nameReferenceGraphPath;
        boolean boolean7 = compilerOptions0.markNoSideEffectCalls;
        com.google.javascript.jscomp.ErrorFormat errorFormat8 = compilerOptions0.errorFormat;
        compilerOptions0.setAcceptConstKeyword(false);
        java.util.Set<java.lang.String> strSet11 = compilerOptions0.stripTypes;
        compilerOptions0.flowSensitiveInlineVariables = false;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(errorFormat8);
        org.junit.Assert.assertNotNull(strSet11);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test470");
        com.google.javascript.rhino.Context context0 = new com.google.javascript.rhino.Context();
        context0.setGeneratingSource(true);
        boolean boolean3 = context0.isGeneratingDebug();
        java.lang.String str4 = context0.getImplementationVersion();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "@IMPLEMENTATION.VERSION@" + "'", str4.equals("@IMPLEMENTATION.VERSION@"));
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test471");
        java.util.logging.Logger logger0 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager1 = new com.google.javascript.jscomp.LoggerErrorManager(logger0);
        com.google.javascript.jscomp.CompilerOptions compilerOptions2 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions2.setLooseTypes(true);
        compilerOptions2.convertToDottedProperties = false;
        com.google.javascript.jscomp.CheckLevel checkLevel7 = compilerOptions2.reportMissingOverride;
        com.google.javascript.rhino.Node node10 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node12 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node14 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node16 = new com.google.javascript.rhino.Node((int) '4');
        node14.addChildrenToBack(node16);
        node10.addChildAfter(node12, node16);
        com.google.javascript.rhino.Node node20 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node22 = new com.google.javascript.rhino.Node((int) '4');
        node20.addChildrenToBack(node22);
        com.google.javascript.rhino.Node node24 = node10.copyInformationFromForTree(node22);
        com.google.javascript.jscomp.DiagnosticType diagnosticType25 = com.google.javascript.jscomp.Compiler.MOTION_ITERATIONS_ERROR;
        java.lang.String str26 = diagnosticType25.toString();
        java.lang.String[] strArray27 = null;
        com.google.javascript.jscomp.JSError jSError28 = com.google.javascript.jscomp.JSError.make("", node22, diagnosticType25, strArray27);
        java.lang.String str29 = jSError28.toString();
        loggerErrorManager1.println(checkLevel7, jSError28);
        int int31 = loggerErrorManager1.getWarningCount();
        int int32 = loggerErrorManager1.getWarningCount();
        com.google.javascript.jscomp.Compiler compiler33 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager1);
        try {
            com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry34 = compiler33.getTypeRegistry();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + checkLevel7 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel7.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertNotNull(diagnosticType25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}" + "'", str26.equals("JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}"));
        org.junit.Assert.assertNotNull(jSError28);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "JSC_OPTIMIZE_LOOP_ERROR. Exceeded max number of code motion iterations: {0} at (unknown source) line (unknown line) : (unknown column)" + "'", str29.equals("JSC_OPTIMIZE_LOOP_ERROR. Exceeded max number of code motion iterations: {0} at (unknown source) line (unknown line) : (unknown column)"));
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test472");
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention0 = new com.google.javascript.jscomp.DefaultCodingConvention();
        com.google.javascript.rhino.Node node2 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node4 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node6 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node8 = new com.google.javascript.rhino.Node((int) '4');
        node6.addChildrenToBack(node8);
        node2.addChildAfter(node4, node8);
        com.google.javascript.rhino.Node node12 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node14 = new com.google.javascript.rhino.Node((int) '4');
        node12.addChildrenToBack(node14);
        com.google.javascript.rhino.Node node16 = node2.copyInformationFromForTree(node14);
        com.google.javascript.rhino.Node node18 = node2.getAncestor(1);
        com.google.javascript.rhino.Node node20 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node22 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node24 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node26 = new com.google.javascript.rhino.Node((int) '4');
        node24.addChildrenToBack(node26);
        node20.addChildAfter(node22, node26);
        com.google.javascript.rhino.Node node30 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node32 = new com.google.javascript.rhino.Node((int) '4');
        node30.addChildrenToBack(node32);
        com.google.javascript.rhino.Node node34 = node20.copyInformationFromForTree(node32);
        com.google.javascript.rhino.Node node36 = node20.getAncestor(1);
        node2.addChildToFront(node20);
        node2.setIsSyntheticBlock(true);
        int int40 = node2.getSourcePosition();
        java.lang.String str41 = defaultCodingConvention0.getSingletonGetterClassName(node2);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertNull(node18);
        org.junit.Assert.assertNotNull(node34);
        org.junit.Assert.assertNull(node36);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + (-1) + "'", int40 == (-1));
        org.junit.Assert.assertNull(str41);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test473");
        com.google.javascript.rhino.Node node1 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node3 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node5 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node7 = new com.google.javascript.rhino.Node((int) '4');
        node5.addChildrenToBack(node7);
        node1.addChildAfter(node3, node7);
        com.google.javascript.rhino.Node node11 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node((int) '4');
        node11.addChildrenToBack(node13);
        com.google.javascript.rhino.Node node15 = node1.copyInformationFromForTree(node13);
        com.google.javascript.rhino.Node node17 = node1.getAncestor(1);
        try {
            com.google.javascript.rhino.Node node18 = node17.cloneNode();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertNull(node17);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test474");
        com.google.javascript.jscomp.SourceFile sourceFile3 = com.google.javascript.jscomp.SourceFile.fromCode("", "Named type with empty name component", "hi!: hi!");
        org.junit.Assert.assertNotNull(sourceFile3);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test475");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node3 = new com.google.javascript.rhino.Node((int) (short) 1);
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newString("hi!");
        int int6 = node5.getCharno();
        com.google.javascript.rhino.Node node8 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node10 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node12 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node14 = new com.google.javascript.rhino.Node((int) '4');
        node12.addChildrenToBack(node14);
        node8.addChildAfter(node10, node14);
        com.google.javascript.rhino.Node node18 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node20 = new com.google.javascript.rhino.Node((int) '4');
        node18.addChildrenToBack(node20);
        com.google.javascript.rhino.Node node22 = node8.copyInformationFromForTree(node20);
        com.google.javascript.rhino.Node node23 = node8.cloneTree();
        com.google.javascript.rhino.Node node24 = node8.cloneTree();
        com.google.javascript.rhino.Node node26 = new com.google.javascript.rhino.Node((int) '4');
        node26.setLineno(36);
        com.google.javascript.rhino.Node[] nodeArray29 = new com.google.javascript.rhino.Node[] { node3, node5, node24, node26 };
        com.google.javascript.rhino.Node node32 = new com.google.javascript.rhino.Node(0, nodeArray29, 25, 14);
        com.google.javascript.rhino.Node node34 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node36 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node38 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node40 = new com.google.javascript.rhino.Node((int) '4');
        node38.addChildrenToBack(node40);
        node34.addChildAfter(node36, node40);
        com.google.javascript.rhino.Node node44 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node46 = new com.google.javascript.rhino.Node((int) '4');
        node44.addChildrenToBack(node46);
        com.google.javascript.rhino.Node node48 = node34.copyInformationFromForTree(node46);
        com.google.javascript.rhino.Node node49 = node34.cloneTree();
        com.google.javascript.rhino.Node node50 = node34.cloneTree();
        java.lang.String str51 = closureCodingConvention0.extractClassNameIfRequire(node32, node34);
        boolean boolean52 = node34.isVarArgs();
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertNotNull(nodeArray29);
        org.junit.Assert.assertNotNull(node48);
        org.junit.Assert.assertNotNull(node49);
        org.junit.Assert.assertNotNull(node50);
        org.junit.Assert.assertNull(str51);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test476");
        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray0 = new com.google.javascript.jscomp.WarningsGuard[] {};
        java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard> warningsGuardList1 = new java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList1, warningsGuardArray0);
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard3 = new com.google.javascript.jscomp.ComposeWarningsGuard((java.util.List<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList1);
        com.google.javascript.rhino.Node node6 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node8 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node10 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node12 = new com.google.javascript.rhino.Node((int) '4');
        node10.addChildrenToBack(node12);
        node6.addChildAfter(node8, node12);
        com.google.javascript.rhino.Node node16 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node18 = new com.google.javascript.rhino.Node((int) '4');
        node16.addChildrenToBack(node18);
        com.google.javascript.rhino.Node node20 = node6.copyInformationFromForTree(node18);
        com.google.javascript.jscomp.DiagnosticType diagnosticType21 = com.google.javascript.jscomp.Compiler.MOTION_ITERATIONS_ERROR;
        java.lang.String str22 = diagnosticType21.toString();
        java.lang.String[] strArray23 = null;
        com.google.javascript.jscomp.JSError jSError24 = com.google.javascript.jscomp.JSError.make("", node18, diagnosticType21, strArray23);
        com.google.javascript.jscomp.CheckLevel checkLevel25 = composeWarningsGuard3.level(jSError24);
        java.lang.String str26 = jSError24.description;
        com.google.javascript.jscomp.DiagnosticType diagnosticType27 = com.google.javascript.jscomp.Compiler.MOTION_ITERATIONS_ERROR;
        java.lang.String str28 = diagnosticType27.toString();
        com.google.javascript.jscomp.CheckLevel checkLevel29 = diagnosticType27.defaultLevel;
        java.io.PrintStream printStream30 = null;
        com.google.javascript.jscomp.Compiler compiler31 = new com.google.javascript.jscomp.Compiler(printStream30);
        compiler31.disableThreads();
        com.google.javascript.jscomp.PerformanceTracker performanceTracker33 = compiler31.tracker;
        com.google.javascript.jscomp.NodeTraversal.Callback callback34 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal35 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler31, callback34);
        com.google.javascript.jscomp.Compiler compiler36 = nodeTraversal35.getCompiler();
        com.google.javascript.jscomp.SourceExcerptProvider.SourceExcerpt sourceExcerpt37 = null;
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter38 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler36, sourceExcerpt37);
        try {
            java.lang.String str39 = jSError24.format(checkLevel29, (com.google.javascript.jscomp.MessageFormatter) lightweightMessageFormatter38);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(warningsGuardArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNotNull(diagnosticType21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}" + "'", str22.equals("JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}"));
        org.junit.Assert.assertNotNull(jSError24);
        org.junit.Assert.assertNull(checkLevel25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "Exceeded max number of code motion iterations: {0}" + "'", str26.equals("Exceeded max number of code motion iterations: {0}"));
        org.junit.Assert.assertNotNull(diagnosticType27);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}" + "'", str28.equals("JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}"));
        org.junit.Assert.assertTrue("'" + checkLevel29 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel29.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNull(performanceTracker33);
        org.junit.Assert.assertNotNull(compiler36);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test477");
        com.google.javascript.rhino.EcmaError ecmaError1 = com.google.javascript.rhino.ScriptRuntime.typeError("4");
        java.lang.String str2 = ecmaError1.getName();
        java.lang.String str3 = ecmaError1.getLineSource();
        org.junit.Assert.assertNotNull(ecmaError1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "TypeError" + "'", str2.equals("TypeError"));
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test478");
        java.io.InputStream inputStream1 = null;
        try {
            com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromInputStream("STRING hi!\n", inputStream1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test479");
        com.google.javascript.jscomp.SourceAst sourceAst0 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(sourceAst0, "", false);
        boolean boolean4 = compilerInput3.isExtern();
        java.lang.String str5 = compilerInput3.getName();
        com.google.javascript.jscomp.JSModule jSModule6 = compilerInput3.getModule();
        com.google.javascript.jscomp.JSModule jSModule7 = null;
        compilerInput3.setModule(jSModule7);
        try {
            compilerInput3.clearAst();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertNull(jSModule6);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test480");
        com.google.javascript.rhino.Node node1 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node3 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node5 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node7 = new com.google.javascript.rhino.Node((int) '4');
        node5.addChildrenToBack(node7);
        node1.addChildAfter(node3, node7);
        com.google.javascript.rhino.Node node11 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node((int) '4');
        node11.addChildrenToBack(node13);
        com.google.javascript.rhino.Node node15 = node1.copyInformationFromForTree(node13);
        com.google.javascript.rhino.Node node16 = node15.getLastChild();
        com.google.javascript.rhino.Node node18 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node20 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node22 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node24 = new com.google.javascript.rhino.Node((int) '4');
        node22.addChildrenToBack(node24);
        node18.addChildAfter(node20, node24);
        com.google.javascript.rhino.Node node28 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node30 = new com.google.javascript.rhino.Node((int) '4');
        node28.addChildrenToBack(node30);
        com.google.javascript.rhino.Node node32 = node18.copyInformationFromForTree(node30);
        node15.addChildToBack(node18);
        com.google.javascript.rhino.Node node35 = node15.getAncestor(150);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertNull(node16);
        org.junit.Assert.assertNotNull(node32);
        org.junit.Assert.assertNull(node35);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test481");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile4 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        java.io.Reader reader5 = jSSourceFile4.getCodeReader();
        com.google.javascript.jscomp.JSModule[] jSModuleArray6 = new com.google.javascript.jscomp.JSModule[] {};
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph7 = new com.google.javascript.jscomp.JSModuleGraph(jSModuleArray6);
        com.google.javascript.jscomp.CompilerOptions compilerOptions8 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions8.setLooseTypes(true);
        boolean boolean11 = compilerOptions8.collapseVariableDeclarations;
        compilerOptions8.moveFunctionDeclarations = false;
        boolean boolean14 = compilerOptions8.decomposeExpressions;
        com.google.javascript.jscomp.CheckLevel checkLevel15 = compilerOptions8.checkMissingGetCssNameLevel;
        com.google.javascript.jscomp.Result result16 = compiler1.compile(jSSourceFile4, jSModuleArray6, compilerOptions8);
        int int17 = compiler1.getErrorCount();
        int int18 = compiler1.getWarningCount();
        java.lang.String str21 = compiler1.getSourceLine("window", 30);
        com.google.javascript.rhino.Node node24 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node26 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node28 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node30 = new com.google.javascript.rhino.Node((int) '4');
        node28.addChildrenToBack(node30);
        node24.addChildAfter(node26, node30);
        com.google.javascript.rhino.Node node34 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node36 = new com.google.javascript.rhino.Node((int) '4');
        node34.addChildrenToBack(node36);
        com.google.javascript.rhino.Node node38 = node24.copyInformationFromForTree(node36);
        com.google.javascript.jscomp.DiagnosticType diagnosticType39 = com.google.javascript.jscomp.Compiler.MOTION_ITERATIONS_ERROR;
        java.lang.String str40 = diagnosticType39.toString();
        java.lang.String[] strArray41 = null;
        com.google.javascript.jscomp.JSError jSError42 = com.google.javascript.jscomp.JSError.make("", node36, diagnosticType39, strArray41);
        java.lang.String str43 = jSError42.description;
        java.lang.String str44 = jSError42.sourceName;
        com.google.javascript.jscomp.CheckLevel checkLevel45 = compiler1.getErrorLevel(jSError42);
        java.util.List<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList46 = null;
        java.io.PrintStream printStream47 = null;
        com.google.javascript.jscomp.Compiler compiler48 = new com.google.javascript.jscomp.Compiler(printStream47);
        java.io.PrintStream printStream49 = null;
        com.google.javascript.jscomp.Compiler compiler50 = new com.google.javascript.jscomp.Compiler(printStream49);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile53 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        java.io.Reader reader54 = jSSourceFile53.getCodeReader();
        com.google.javascript.jscomp.JSModule[] jSModuleArray55 = new com.google.javascript.jscomp.JSModule[] {};
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph56 = new com.google.javascript.jscomp.JSModuleGraph(jSModuleArray55);
        com.google.javascript.jscomp.CompilerOptions compilerOptions57 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions57.setLooseTypes(true);
        boolean boolean60 = compilerOptions57.collapseVariableDeclarations;
        compilerOptions57.moveFunctionDeclarations = false;
        boolean boolean63 = compilerOptions57.decomposeExpressions;
        com.google.javascript.jscomp.CheckLevel checkLevel64 = compilerOptions57.checkMissingGetCssNameLevel;
        com.google.javascript.jscomp.Result result65 = compiler50.compile(jSSourceFile53, jSModuleArray55, compilerOptions57);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile68 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile71 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        java.io.Reader reader72 = jSSourceFile71.getCodeReader();
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray73 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile53, jSSourceFile68, jSSourceFile71 };
        java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList74 = new java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile>();
        boolean boolean75 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList74, jSSourceFileArray73);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile78 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray79 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile78 };
        java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList80 = new java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile>();
        boolean boolean81 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList80, jSSourceFileArray79);
        com.google.javascript.jscomp.CompilerOptions compilerOptions82 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions82.setLooseTypes(true);
        boolean boolean85 = compilerOptions82.reserveRawExports;
        compilerOptions82.extractPrototypeMemberDeclarations = false;
        java.lang.String str88 = compilerOptions82.nameReferenceGraphPath;
        compilerOptions82.setSummaryDetailLevel(0);
        com.google.javascript.jscomp.Result result91 = compiler48.compile((java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList74, (java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList80, compilerOptions82);
        com.google.javascript.jscomp.CompilerOptions compilerOptions92 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions92.setLooseTypes(true);
        boolean boolean95 = compilerOptions92.reserveRawExports;
        com.google.javascript.jscomp.CheckLevel checkLevel96 = null;
        compilerOptions92.checkGlobalNamesLevel = checkLevel96;
        boolean boolean98 = compilerOptions92.shouldColorizeErrorOutput();
        try {
            compiler1.init(jSSourceFileList46, (java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList80, compilerOptions92);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile4);
        org.junit.Assert.assertNotNull(reader5);
        org.junit.Assert.assertNotNull(jSModuleArray6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + checkLevel15 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel15.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(result16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertNotNull(node38);
        org.junit.Assert.assertNotNull(diagnosticType39);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}" + "'", str40.equals("JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}"));
        org.junit.Assert.assertNotNull(jSError42);
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "Exceeded max number of code motion iterations: {0}" + "'", str43.equals("Exceeded max number of code motion iterations: {0}"));
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "" + "'", str44.equals(""));
        org.junit.Assert.assertNull(checkLevel45);
        org.junit.Assert.assertNotNull(jSSourceFile53);
        org.junit.Assert.assertNotNull(reader54);
        org.junit.Assert.assertNotNull(jSModuleArray55);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertTrue("'" + checkLevel64 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel64.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(result65);
        org.junit.Assert.assertNotNull(jSSourceFile68);
        org.junit.Assert.assertNotNull(jSSourceFile71);
        org.junit.Assert.assertNotNull(reader72);
        org.junit.Assert.assertNotNull(jSSourceFileArray73);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + true + "'", boolean75 == true);
        org.junit.Assert.assertNotNull(jSSourceFile78);
        org.junit.Assert.assertNotNull(jSSourceFileArray79);
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + true + "'", boolean81 == true);
        org.junit.Assert.assertTrue("'" + boolean85 + "' != '" + false + "'", boolean85 == false);
        org.junit.Assert.assertNull(str88);
        org.junit.Assert.assertNotNull(result91);
        org.junit.Assert.assertTrue("'" + boolean95 + "' != '" + false + "'", boolean95 == false);
        org.junit.Assert.assertTrue("'" + boolean98 + "' != '" + false + "'", boolean98 == false);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test482");
        com.google.javascript.jscomp.SourceAst sourceAst0 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(sourceAst0, "", false);
        boolean boolean4 = compilerInput3.isExtern();
        java.lang.String str5 = compilerInput3.getName();
        com.google.javascript.jscomp.JSModule jSModule6 = compilerInput3.getModule();
        com.google.javascript.jscomp.CompilerInput compilerInput9 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput3, "<No stack trace available>", false);
        try {
            compilerInput3.clearAst();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertNull(jSModule6);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test483");
        com.google.javascript.rhino.EcmaError ecmaError1 = com.google.javascript.rhino.ScriptRuntime.typeError("4");
        java.lang.String str2 = ecmaError1.getName();
        java.lang.Throwable[] throwableArray3 = ecmaError1.getSuppressed();
        java.lang.String str4 = ecmaError1.toString();
        java.lang.String str5 = ecmaError1.sourceName();
        java.lang.String str6 = ecmaError1.getErrorMessage();
        org.junit.Assert.assertNotNull(ecmaError1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "TypeError" + "'", str2.equals("TypeError"));
        org.junit.Assert.assertNotNull(throwableArray3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "com.google.javascript.rhino.EcmaError: TypeError: 4" + "'", str4.equals("com.google.javascript.rhino.EcmaError: TypeError: 4"));
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "4" + "'", str6.equals("4"));
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test484");
        com.google.javascript.rhino.Node node1 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node3 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node5 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node7 = new com.google.javascript.rhino.Node((int) '4');
        node5.addChildrenToBack(node7);
        node1.addChildAfter(node3, node7);
        com.google.javascript.rhino.Node node11 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node((int) '4');
        node11.addChildrenToBack(node13);
        com.google.javascript.rhino.Node node15 = node1.copyInformationFromForTree(node13);
        com.google.javascript.rhino.Node node17 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node18 = node1.copyInformationFromForTree(node17);
        boolean boolean19 = node17.isQualifiedName();
        try {
            java.lang.String str20 = node17.getString();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: INSTANCEOF is not a string node");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test485");
        com.google.javascript.rhino.Node node2 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node4 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node6 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node8 = new com.google.javascript.rhino.Node((int) '4');
        node6.addChildrenToBack(node8);
        node2.addChildAfter(node4, node8);
        com.google.javascript.rhino.Node node12 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node14 = new com.google.javascript.rhino.Node((int) '4');
        node12.addChildrenToBack(node14);
        com.google.javascript.rhino.Node node16 = node2.copyInformationFromForTree(node14);
        com.google.javascript.rhino.Node node18 = node2.getAncestor(1);
        com.google.javascript.rhino.Node node20 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node22 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node24 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node26 = new com.google.javascript.rhino.Node((int) '4');
        node24.addChildrenToBack(node26);
        node20.addChildAfter(node22, node26);
        com.google.javascript.rhino.Node node30 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node32 = new com.google.javascript.rhino.Node((int) '4');
        node30.addChildrenToBack(node32);
        com.google.javascript.rhino.Node node34 = node20.copyInformationFromForTree(node32);
        com.google.javascript.rhino.Node node36 = node20.getAncestor(1);
        node2.addChildToFront(node20);
        com.google.javascript.rhino.Node node38 = node2.getNext();
        com.google.javascript.rhino.Node node42 = com.google.javascript.rhino.Node.newNumber(0.0d, 31, 30);
        node42.putIntProp(3, (int) (short) -1);
        boolean boolean46 = node42.hasChildren();
        com.google.javascript.rhino.Node node47 = new com.google.javascript.rhino.Node((int) ' ', node2, node42);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertNull(node18);
        org.junit.Assert.assertNotNull(node34);
        org.junit.Assert.assertNull(node36);
        org.junit.Assert.assertNull(node38);
        org.junit.Assert.assertNotNull(node42);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test486");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setLooseTypes(true);
        boolean boolean3 = compilerOptions0.reserveRawExports;
        boolean boolean4 = compilerOptions0.flowSensitiveInlineVariables;
        compilerOptions0.rewriteFunctionExpressions = true;
        java.io.PrintStream printStream7 = null;
        com.google.javascript.jscomp.Compiler compiler8 = new com.google.javascript.jscomp.Compiler(printStream7);
        compiler8.disableThreads();
        com.google.javascript.jscomp.PerformanceTracker performanceTracker10 = compiler8.tracker;
        com.google.javascript.jscomp.NodeTraversal.Callback callback11 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal12 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler8, callback11);
        com.google.javascript.rhino.Node node14 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node16 = new com.google.javascript.rhino.Node((int) '4');
        node14.addChildrenToBack(node16);
        com.google.javascript.jscomp.DiagnosticType diagnosticType20 = com.google.javascript.jscomp.DiagnosticType.warning("hi!", "hi!");
        com.google.javascript.jscomp.DiagnosticType diagnosticType21 = com.google.javascript.jscomp.Compiler.MOTION_ITERATIONS_ERROR;
        int int22 = diagnosticType20.compareTo(diagnosticType21);
        java.lang.String[] strArray23 = com.google.javascript.rhino.ScriptRuntime.emptyStrings;
        com.google.javascript.jscomp.JSError jSError24 = nodeTraversal12.makeError(node16, diagnosticType20, strArray23);
        com.google.javascript.jscomp.CompilerOptions compilerOptions25 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions25.setLooseTypes(true);
        boolean boolean28 = compilerOptions25.collapseVariableDeclarations;
        boolean boolean29 = compilerOptions25.generateExports;
        com.google.javascript.jscomp.SourceMap.DetailLevel detailLevel30 = compilerOptions25.sourceMapDetailLevel;
        com.google.javascript.jscomp.CheckLevel checkLevel31 = null;
        compilerOptions25.brokenClosureRequiresLevel = checkLevel31;
        java.util.Set<java.lang.String> strSet33 = compilerOptions25.aliasableStrings;
        java.lang.RuntimeException runtimeException34 = com.google.javascript.rhino.ScriptRuntime.undefWriteError((java.lang.Object) compilerOptions0, (java.lang.Object) strArray23, (java.lang.Object) compilerOptions25);
        compilerOptions0.reserveRawExports = false;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(performanceTracker10);
        org.junit.Assert.assertNotNull(diagnosticType20);
        org.junit.Assert.assertNotNull(diagnosticType21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 30 + "'", int22 == 30);
        org.junit.Assert.assertNotNull(strArray23);
        org.junit.Assert.assertNotNull(jSError24);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(detailLevel30);
        org.junit.Assert.assertNotNull(strSet33);
        org.junit.Assert.assertNotNull(runtimeException34);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test487");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString(45, "", 20, (int) '4');
        com.google.javascript.rhino.Node node6 = new com.google.javascript.rhino.Node((int) (short) 1);
        com.google.javascript.rhino.Node node8 = new com.google.javascript.rhino.Node((int) (short) 1);
        node6.addChildrenToBack(node8);
        node4.addChildrenToFront(node6);
        com.google.javascript.rhino.Node node11 = node6.getParent();
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(node11);
    }

//    @Test
//    public void test488() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test488");
//        try {
//            com.google.javascript.rhino.Context.reportError("Not declared as a constructor", "com.google.javascript.rhino.EcmaError: TypeError: 4", 48, "JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}", (int) (short) 0);
//            org.junit.Assert.fail("Expected exception of type com.google.javascript.rhino.EvaluatorException; message: Not declared as a constructor (com.google.javascript.rhino.EcmaError: TypeError: 4#48)");
//        } catch (com.google.javascript.rhino.EvaluatorException e) {
//        }
//    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test489");
        java.util.logging.Logger logger0 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager1 = new com.google.javascript.jscomp.LoggerErrorManager(logger0);
        com.google.javascript.jscomp.CompilerOptions compilerOptions2 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions2.setLooseTypes(true);
        compilerOptions2.convertToDottedProperties = false;
        com.google.javascript.jscomp.CheckLevel checkLevel7 = compilerOptions2.reportMissingOverride;
        com.google.javascript.rhino.Node node10 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node12 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node14 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node16 = new com.google.javascript.rhino.Node((int) '4');
        node14.addChildrenToBack(node16);
        node10.addChildAfter(node12, node16);
        com.google.javascript.rhino.Node node20 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node22 = new com.google.javascript.rhino.Node((int) '4');
        node20.addChildrenToBack(node22);
        com.google.javascript.rhino.Node node24 = node10.copyInformationFromForTree(node22);
        com.google.javascript.jscomp.DiagnosticType diagnosticType25 = com.google.javascript.jscomp.Compiler.MOTION_ITERATIONS_ERROR;
        java.lang.String str26 = diagnosticType25.toString();
        java.lang.String[] strArray27 = null;
        com.google.javascript.jscomp.JSError jSError28 = com.google.javascript.jscomp.JSError.make("", node22, diagnosticType25, strArray27);
        java.lang.String str29 = jSError28.toString();
        loggerErrorManager1.println(checkLevel7, jSError28);
        int int31 = loggerErrorManager1.getWarningCount();
        double double32 = loggerErrorManager1.getTypedPercent();
        org.junit.Assert.assertTrue("'" + checkLevel7 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel7.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertNotNull(diagnosticType25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}" + "'", str26.equals("JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}"));
        org.junit.Assert.assertNotNull(jSError28);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "JSC_OPTIMIZE_LOOP_ERROR. Exceeded max number of code motion iterations: {0} at (unknown source) line (unknown line) : (unknown column)" + "'", str29.equals("JSC_OPTIMIZE_LOOP_ERROR. Exceeded max number of code motion iterations: {0} at (unknown source) line (unknown line) : (unknown column)"));
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test490");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.INVALID_CASTS;
        org.junit.Assert.assertNull(diagnosticGroup0);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test491");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.common.collect.Multimap<com.google.javascript.jscomp.CustomPassExecutionTime, com.google.javascript.jscomp.CompilerPass> customPassExecutionTimeMultimap1 = compilerOptions0.customPasses;
        com.google.javascript.jscomp.CheckLevel checkLevel2 = compilerOptions0.checkGlobalNamesLevel;
        com.google.javascript.jscomp.CodingConvention codingConvention3 = compilerOptions0.getCodingConvention();
        org.junit.Assert.assertNull(customPassExecutionTimeMultimap1);
        org.junit.Assert.assertTrue("'" + checkLevel2 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel2.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNull(codingConvention3);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test492");
        com.google.javascript.rhino.Node node1 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node3 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node5 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node7 = new com.google.javascript.rhino.Node((int) '4');
        node5.addChildrenToBack(node7);
        node1.addChildAfter(node3, node7);
        com.google.javascript.rhino.Node node11 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node((int) '4');
        node11.addChildrenToBack(node13);
        com.google.javascript.rhino.Node node15 = node1.copyInformationFromForTree(node13);
        node15.putBooleanProp(11, false);
        org.junit.Assert.assertNotNull(node15);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test493");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setLooseTypes(true);
        boolean boolean3 = compilerOptions0.reserveRawExports;
        compilerOptions0.extractPrototypeMemberDeclarations = false;
        boolean boolean6 = compilerOptions0.disambiguateProperties;
        com.google.javascript.jscomp.CheckLevel checkLevel7 = compilerOptions0.aggressiveVarCheck;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap8 = compilerOptions0.cssRenamingMap;
        com.google.javascript.jscomp.SourceMap.Format format9 = compilerOptions0.sourceMapFormat;
        java.lang.String str10 = compilerOptions0.nameReferenceReportPath;
        compilerOptions0.setProcessObjectPropertyString(false);
        compilerOptions0.optimizeArgumentsArray = false;
        java.util.Set<java.lang.String> strSet15 = compilerOptions0.stripNameSuffixes;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + checkLevel7 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel7.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNull(cssRenamingMap8);
        org.junit.Assert.assertNotNull(format9);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertNotNull(strSet15);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test494");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile4 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile7 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        java.io.Reader reader8 = jSSourceFile7.getCodeReader();
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray9 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile4, jSSourceFile7 };
        java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList10 = new java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile>();
        boolean boolean11 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList10, jSSourceFileArray9);
        com.google.javascript.jscomp.JSModule[] jSModuleArray12 = new com.google.javascript.jscomp.JSModule[] {};
        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList13 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
        boolean boolean14 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList13, jSModuleArray12);
        com.google.javascript.jscomp.CompilerOptions compilerOptions15 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions15.setLooseTypes(true);
        boolean boolean18 = compilerOptions15.reserveRawExports;
        compilerOptions15.extractPrototypeMemberDeclarations = false;
        java.lang.String str21 = compilerOptions15.nameReferenceGraphPath;
        compilerOptions15.computeFunctionSideEffects = true;
        com.google.javascript.jscomp.CompilerOptions compilerOptions24 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions24.setLooseTypes(true);
        compilerOptions24.convertToDottedProperties = false;
        com.google.javascript.jscomp.CheckLevel checkLevel29 = compilerOptions24.reportMissingOverride;
        compilerOptions15.brokenClosureRequiresLevel = checkLevel29;
        java.util.Set<java.lang.String> strSet31 = compilerOptions15.stripTypePrefixes;
        compilerOptions15.deadAssignmentElimination = false;
        compiler1.initModules((java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList10, (java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList13, compilerOptions15);
        com.google.javascript.jscomp.CompilerOptions compilerOptions35 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.common.collect.Multimap<com.google.javascript.jscomp.CustomPassExecutionTime, com.google.javascript.jscomp.CompilerPass> customPassExecutionTimeMultimap36 = compilerOptions35.customPasses;
        com.google.javascript.jscomp.CheckLevel checkLevel37 = compilerOptions35.checkGlobalNamesLevel;
        compilerOptions15.reportUnknownTypes = checkLevel37;
        org.junit.Assert.assertNotNull(jSSourceFile4);
        org.junit.Assert.assertNotNull(jSSourceFile7);
        org.junit.Assert.assertNotNull(reader8);
        org.junit.Assert.assertNotNull(jSSourceFileArray9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(jSModuleArray12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertTrue("'" + checkLevel29 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel29.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(strSet31);
        org.junit.Assert.assertNull(customPassExecutionTimeMultimap36);
        org.junit.Assert.assertTrue("'" + checkLevel37 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel37.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test495");
        com.google.javascript.rhino.Context context0 = new com.google.javascript.rhino.Context();
        context0.setGeneratingSource(true);
        int int3 = context0.getLanguageVersion();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test496");
        com.google.javascript.jscomp.SourceAst sourceAst0 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(sourceAst0, "", false);
        boolean boolean4 = compilerInput3.isExtern();
        java.lang.String str5 = compilerInput3.getName();
        com.google.javascript.jscomp.JSModule jSModule6 = compilerInput3.getModule();
        com.google.javascript.jscomp.CompilerInput compilerInput9 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput3, "<No stack trace available>", false);
        com.google.javascript.jscomp.SourceAst sourceAst10 = compilerInput9.getSourceAst();
        java.util.logging.Logger logger11 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager12 = new com.google.javascript.jscomp.LoggerErrorManager(logger11);
        com.google.javascript.jscomp.CompilerOptions compilerOptions13 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions13.setLooseTypes(true);
        compilerOptions13.convertToDottedProperties = false;
        com.google.javascript.jscomp.CheckLevel checkLevel18 = compilerOptions13.reportMissingOverride;
        com.google.javascript.rhino.Node node21 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node23 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node25 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node27 = new com.google.javascript.rhino.Node((int) '4');
        node25.addChildrenToBack(node27);
        node21.addChildAfter(node23, node27);
        com.google.javascript.rhino.Node node31 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node33 = new com.google.javascript.rhino.Node((int) '4');
        node31.addChildrenToBack(node33);
        com.google.javascript.rhino.Node node35 = node21.copyInformationFromForTree(node33);
        com.google.javascript.jscomp.DiagnosticType diagnosticType36 = com.google.javascript.jscomp.Compiler.MOTION_ITERATIONS_ERROR;
        java.lang.String str37 = diagnosticType36.toString();
        java.lang.String[] strArray38 = null;
        com.google.javascript.jscomp.JSError jSError39 = com.google.javascript.jscomp.JSError.make("", node33, diagnosticType36, strArray38);
        java.lang.String str40 = jSError39.toString();
        loggerErrorManager12.println(checkLevel18, jSError39);
        int int42 = loggerErrorManager12.getWarningCount();
        int int43 = loggerErrorManager12.getWarningCount();
        compilerInput9.setErrorManager((com.google.javascript.jscomp.ErrorManager) loggerErrorManager12);
        try {
            java.util.Collection<java.lang.String> strCollection45 = compilerInput9.getProvides();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Expected setCompiler to be called first");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertNull(jSModule6);
        org.junit.Assert.assertNotNull(sourceAst10);
        org.junit.Assert.assertTrue("'" + checkLevel18 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel18.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertNotNull(diagnosticType36);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}" + "'", str37.equals("JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}"));
        org.junit.Assert.assertNotNull(jSError39);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "JSC_OPTIMIZE_LOOP_ERROR. Exceeded max number of code motion iterations: {0} at (unknown source) line (unknown line) : (unknown column)" + "'", str40.equals("JSC_OPTIMIZE_LOOP_ERROR. Exceeded max number of code motion iterations: {0} at (unknown source) line (unknown line) : (unknown column)"));
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test497");
        com.google.javascript.rhino.Context context0 = new com.google.javascript.rhino.Context();
        com.google.javascript.rhino.ErrorReporter errorReporter1 = context0.getErrorReporter();
        boolean boolean2 = context0.isGeneratingDebugChanged();
        org.junit.Assert.assertNull(errorReporter1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test498");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.UNKNOWN_DEFINES;
        org.junit.Assert.assertNull(diagnosticGroup0);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test499");
        boolean boolean1 = com.google.javascript.rhino.ScriptRuntime.isJSLineTerminator(34);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test500");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setLooseTypes(true);
        boolean boolean3 = compilerOptions0.collapseVariableDeclarations;
        compilerOptions0.recordFunctionInformation = false;
        compilerOptions0.convertToDottedProperties = false;
        compilerOptions0.collapseVariableDeclarations = false;
        compilerOptions0.inlineGetters = false;
        compilerOptions0.prettyPrint = true;
        com.google.javascript.jscomp.CompilerOptions compilerOptions14 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions14.setLooseTypes(true);
        compilerOptions14.checkSuspiciousCode = false;
        compilerOptions14.setCollapsePropertiesOnExternTypes(false);
        compilerOptions14.disableRuntimeTypeCheck();
        compilerOptions14.skipAllCompilerPasses();
        com.google.javascript.jscomp.CompilerOptions compilerOptions23 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions23.flowSensitiveInlineVariables = false;
        compilerOptions23.optimizeCalls = true;
        com.google.javascript.jscomp.CheckLevel checkLevel28 = compilerOptions23.checkGlobalNamesLevel;
        compilerOptions14.checkGlobalNamesLevel = checkLevel28;
        compilerOptions0.checkUnreachableCode = checkLevel28;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + checkLevel28 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel28.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }
}

