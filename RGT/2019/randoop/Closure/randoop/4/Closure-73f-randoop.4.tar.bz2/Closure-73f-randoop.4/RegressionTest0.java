import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        int int0 = com.google.javascript.rhino.Context.VERSION_UNKNOWN;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + (-1) + "'", int0 == (-1));
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        int int0 = com.google.javascript.rhino.Node.FLAG_THIS_UNMODIFIED;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        int int0 = com.google.javascript.rhino.Node.MAX_COLUMN_NUMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4095 + "'", int0 == 4095);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        int int0 = com.google.javascript.rhino.Node.BRACELESS_TYPE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 40 + "'", int0 == 40);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        int int0 = com.google.javascript.rhino.Context.VERSION_1_0;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 100 + "'", int0 == 100);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        int int0 = com.google.javascript.rhino.Node.ISNUMBER_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 25 + "'", int0 == 25);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        int int0 = com.google.javascript.rhino.Node.POST_FLAG;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        int int0 = com.google.javascript.rhino.Node.IS_CONSTANT_NAME;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 42 + "'", int0 == 42);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        java.util.logging.Level level0 = null;
        com.google.javascript.jscomp.Compiler.setLoggingLevel(level0);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        int int0 = com.google.javascript.rhino.Node.NON_SPECIALCALL;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        com.google.javascript.rhino.Node node1 = null;
        com.google.javascript.rhino.Node node2 = null;
        com.google.javascript.rhino.Node node3 = null;
        com.google.javascript.rhino.Node node4 = null;
        try {
            com.google.javascript.rhino.Node node5 = new com.google.javascript.rhino.Node((int) (short) 1, node1, node2, node3, node4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        int int0 = com.google.javascript.rhino.Node.JSDOC_INFO_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 29 + "'", int0 == 29);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        com.google.javascript.jscomp.SourceAst sourceAst0 = null;
        try {
            com.google.javascript.jscomp.CompilerInput compilerInput1 = new com.google.javascript.jscomp.CompilerInput(sourceAst0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        try {
            com.google.javascript.rhino.EcmaError ecmaError2 = com.google.javascript.rhino.ScriptRuntime.typeError1("", "hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property ");
        } catch (java.lang.RuntimeException e) {
        }
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        com.google.javascript.jscomp.ErrorFormat errorFormat0 = com.google.javascript.jscomp.ErrorFormat.SINGLELINE;
        org.junit.Assert.assertNotNull(errorFormat0);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        java.lang.Double double0 = com.google.javascript.rhino.ScriptRuntime.NaNobj;
        org.junit.Assert.assertEquals((double) double0, Double.NaN, 0);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        try {
            com.google.javascript.rhino.EcmaError ecmaError2 = com.google.javascript.rhino.ScriptRuntime.typeError1("hi!", "");
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property hi!");
        } catch (java.lang.RuntimeException e) {
        }
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        com.google.javascript.rhino.Node node1 = null;
        try {
            com.google.javascript.rhino.Node node2 = new com.google.javascript.rhino.Node(29, node1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        int int0 = com.google.javascript.rhino.Node.PROPERTY_FLAG;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        boolean boolean1 = com.google.javascript.rhino.ScriptRuntime.isJSLineTerminator((int) (short) 0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        com.google.javascript.jscomp.DiagnosticGroups diagnosticGroups0 = new com.google.javascript.jscomp.DiagnosticGroups();
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        int int0 = com.google.javascript.rhino.Context.FEATURE_STRICT_VARS;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 8 + "'", int0 == 8);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        java.io.File file0 = null;
        java.nio.charset.Charset charset1 = null;
        try {
            com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromFile(file0, charset1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        com.google.javascript.jscomp.SourceExcerptProvider sourceExcerptProvider0 = null;
        try {
            com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter1 = new com.google.javascript.jscomp.LightweightMessageFormatter(sourceExcerptProvider0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        int int0 = com.google.javascript.rhino.Node.QUOTED_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 35 + "'", int0 == 35);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        int int0 = com.google.javascript.rhino.Context.FEATURE_NON_ECMA_GET_YEAR;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        int int0 = com.google.javascript.rhino.Context.VERSION_1_6;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 160 + "'", int0 == 160);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        com.google.javascript.rhino.Node node1 = null;
        com.google.javascript.rhino.Node node2 = null;
        com.google.javascript.rhino.Node node3 = null;
        com.google.javascript.rhino.Node node4 = null;
        try {
            com.google.javascript.rhino.Node node5 = new com.google.javascript.rhino.Node(35, node1, node2, node3, node4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        com.google.javascript.rhino.Context context0 = null;
        try {
            long long1 = com.google.javascript.rhino.ScriptRuntime.lastUint32Result(context0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        int int0 = com.google.javascript.rhino.Node.FLAG_ARGUMENTS_UNMODIFIED;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setLooseTypes(true);
        boolean boolean3 = compilerOptions0.reserveRawExports;
        compilerOptions0.extractPrototypeMemberDeclarations = false;
        java.lang.String str6 = compilerOptions0.nameReferenceGraphPath;
        compilerOptions0.debugFunctionSideEffectsPath = "";
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(str6);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        int int0 = com.google.javascript.rhino.Node.PARENTHESIZED_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 34 + "'", int0 == 34);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        com.google.javascript.jscomp.SourceAst sourceAst0 = null;
        try {
            com.google.javascript.jscomp.CompilerInput compilerInput2 = new com.google.javascript.jscomp.CompilerInput(sourceAst0, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        com.google.javascript.rhino.Node node1 = null;
        com.google.javascript.rhino.Node[] nodeArray2 = new com.google.javascript.rhino.Node[] { node1 };
        try {
            com.google.javascript.rhino.Node node3 = new com.google.javascript.rhino.Node((int) (byte) 0, nodeArray2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(nodeArray2);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        int int0 = com.google.javascript.rhino.Context.VERSION_1_4;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 140 + "'", int0 == 140);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        int int0 = com.google.javascript.rhino.Node.VAR_ARGS_NAME;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 29 + "'", int0 == 29);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        com.google.javascript.jscomp.JSModule[] jSModuleArray0 = new com.google.javascript.jscomp.JSModule[] {};
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph1 = new com.google.javascript.jscomp.JSModuleGraph(jSModuleArray0);
        com.google.javascript.jscomp.JSModule jSModule2 = null;
        com.google.javascript.jscomp.JSModule jSModule3 = null;
        try {
            boolean boolean4 = jSModuleGraph1.dependsOn(jSModule2, jSModule3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jSModuleArray0);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        com.google.javascript.jscomp.CompilerOptions compilerOptions1 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions1.setLooseTypes(true);
        compilerOptions1.convertToDottedProperties = false;
        com.google.javascript.jscomp.CompilerOptions compilerOptions6 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions6.setLooseTypes(true);
        boolean boolean9 = compilerOptions6.reserveRawExports;
        com.google.javascript.jscomp.CheckLevel checkLevel10 = null;
        compilerOptions6.checkUnreachableCode = checkLevel10;
        try {
            java.lang.String str12 = com.google.javascript.rhino.ScriptRuntime.getMessage2("hi!", (java.lang.Object) false, (java.lang.Object) compilerOptions6);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property hi!");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        int int0 = com.google.javascript.rhino.Node.CODEOFFSET_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 8 + "'", int0 == 8);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        int int0 = com.google.javascript.rhino.Context.FEATURE_DYNAMIC_SCOPE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 7 + "'", int0 == 7);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        int int0 = com.google.javascript.rhino.Node.RIGHT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setLooseTypes(true);
        boolean boolean3 = compilerOptions0.reserveRawExports;
        compilerOptions0.extractPrototypeMemberDeclarations = false;
        compilerOptions0.reserveRawExports = true;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        int int0 = com.google.javascript.rhino.Context.VERSION_DEFAULT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        int int0 = com.google.javascript.rhino.Context.FEATURE_PARENT_PROTO_PROPRTIES;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 5 + "'", int0 == 5);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        java.io.InputStream inputStream1 = null;
        try {
            com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromInputStream("", inputStream1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        int int0 = com.google.javascript.rhino.Node.TYPE_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 17 + "'", int0 == 17);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        int int0 = com.google.javascript.rhino.Node.IS_NAMESPACE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 45 + "'", int0 == 45);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        int int0 = com.google.javascript.rhino.Context.VERSION_1_2;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 120 + "'", int0 == 120);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setLooseTypes(true);
        boolean boolean3 = compilerOptions0.reserveRawExports;
        com.google.javascript.jscomp.CheckLevel checkLevel4 = null;
        compilerOptions0.checkUnreachableCode = checkLevel4;
        boolean boolean6 = compilerOptions0.devirtualizePrototypeMethods;
        java.lang.String[] strArray9 = new java.lang.String[] { "hi!", "" };
        java.util.LinkedHashSet<java.lang.String> strSet10 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean11 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet10, strArray9);
        compilerOptions0.setIdGenerators((java.util.Set<java.lang.String>) strSet10);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        com.google.javascript.rhino.Node node1 = new com.google.javascript.rhino.Node((int) '4');
        try {
            node1.setDouble(10.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: INSTANCEOF is not a string node");
        } catch (java.lang.UnsupportedOperationException e) {
        }
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = null;
        com.google.javascript.jscomp.DiagnosticGroups.CHECK_TYPES = diagnosticGroup0;
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        int int0 = com.google.javascript.rhino.Node.SIDE_EFFECTS_FLAGS_MASK;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 31 + "'", int0 == 31);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        com.google.javascript.rhino.Node node1 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node3 = new com.google.javascript.rhino.Node((int) '4');
        node1.addChildrenToBack(node3);
        com.google.javascript.rhino.Node node5 = null;
        try {
            node1.addChildToFront(node5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        java.lang.String str1 = com.google.javascript.rhino.ScriptRuntime.toString((java.lang.Object) 4);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "4" + "'", str1.equals("4"));
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        boolean boolean1 = com.google.javascript.rhino.Context.isValidOptimizationLevel(120);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        com.google.javascript.jscomp.CompilerOptions compilerOptions1 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions1.removeUnusedPrototypePropertiesInExterns = false;
        java.lang.RuntimeException runtimeException4 = com.google.javascript.rhino.ScriptRuntime.undefCallError((java.lang.Object) 0.0f, (java.lang.Object) false);
        org.junit.Assert.assertNotNull(runtimeException4);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        int int0 = com.google.javascript.rhino.Node.DEFAULT_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 14 + "'", int0 == 14);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        com.google.javascript.jscomp.SourceExcerptProvider sourceExcerptProvider0 = null;
        com.google.javascript.jscomp.SourceExcerptProvider.SourceExcerpt sourceExcerpt1 = null;
        try {
            com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter2 = new com.google.javascript.jscomp.LightweightMessageFormatter(sourceExcerptProvider0, sourceExcerpt1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        com.google.javascript.jscomp.CompilerOptions compilerOptions1 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions1.setLooseTypes(true);
        boolean boolean4 = compilerOptions1.collapseVariableDeclarations;
        compilerOptions1.setManageClosureDependencies(false);
        try {
            java.lang.String str7 = com.google.javascript.rhino.ScriptRuntime.getMessage1("", (java.lang.Object) compilerOptions1);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property ");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

//    @Test
//    public void test060() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test060");
//        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.STRICT_MODULE_DEP_CHECK;
//        com.google.javascript.jscomp.DiagnosticGroups.MISSING_PROPERTIES = diagnosticGroup0;
//        com.google.javascript.jscomp.JSError jSError2 = null;
//        try {
//            boolean boolean3 = diagnosticGroup0.matches(jSError2);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(diagnosticGroup0);
//    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        int int0 = com.google.javascript.rhino.Node.IS_OPTIONAL_PARAM;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 43 + "'", int0 == 43);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        com.google.javascript.jscomp.DiagnosticType diagnosticType2 = com.google.javascript.jscomp.DiagnosticType.warning("hi!", "4");
        org.junit.Assert.assertNotNull(diagnosticType2);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        int int0 = com.google.javascript.rhino.Node.BREAK_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setLooseTypes(true);
        boolean boolean3 = compilerOptions0.collapseVariableDeclarations;
        compilerOptions0.moveFunctionDeclarations = false;
        boolean boolean6 = compilerOptions0.decomposeExpressions;
        boolean boolean7 = compilerOptions0.smartNameRemoval;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

//    @Test
//    public void test065() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test065");
//        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.MISSING_PROPERTIES;
//        com.google.javascript.jscomp.DiagnosticGroups.UNDEFINED_VARIABLES = diagnosticGroup0;
//        org.junit.Assert.assertNotNull(diagnosticGroup0);
//    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        int int0 = com.google.javascript.rhino.Node.LEFT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        com.google.javascript.rhino.Node node0 = null;
        try {
            java.util.Collection<com.google.javascript.rhino.Node> nodeCollection1 = com.google.javascript.jscomp.NodeUtil.getVarsDeclaredInBranch(node0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        int int0 = com.google.javascript.rhino.Node.OPT_ARG_NAME;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 36 + "'", int0 == 36);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        int int0 = com.google.javascript.rhino.Node.INCRDECR_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 31 + "'", int0 == 31);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        java.lang.String str1 = com.google.javascript.rhino.jstype.ObjectType.createDelegateSuffix("");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "()" + "'", str1.equals("()"));
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        int int0 = com.google.javascript.rhino.Context.VERSION_1_5;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 150 + "'", int0 == 150);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        int int0 = com.google.javascript.rhino.Node.IS_DISPATCHER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 46 + "'", int0 == 46);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy0 = com.google.javascript.jscomp.PropertyRenamingPolicy.HEURISTIC;
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy0 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.HEURISTIC + "'", propertyRenamingPolicy0.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.HEURISTIC));
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        com.google.javascript.rhino.Node node2 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node4 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node6 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node8 = new com.google.javascript.rhino.Node((int) '4');
        node6.addChildrenToBack(node8);
        node2.addChildAfter(node4, node8);
        com.google.javascript.rhino.Node node12 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node14 = new com.google.javascript.rhino.Node((int) '4');
        node12.addChildrenToBack(node14);
        com.google.javascript.rhino.Node node16 = node2.copyInformationFromForTree(node14);
        com.google.javascript.rhino.Node node18 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node20 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node22 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node24 = new com.google.javascript.rhino.Node((int) '4');
        node22.addChildrenToBack(node24);
        node18.addChildAfter(node20, node24);
        com.google.javascript.rhino.Node node28 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node30 = new com.google.javascript.rhino.Node((int) '4');
        node28.addChildrenToBack(node30);
        com.google.javascript.rhino.Node node32 = node18.copyInformationFromForTree(node30);
        com.google.javascript.rhino.Node node33 = node32.getLastChild();
        com.google.javascript.rhino.Node node35 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node37 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node39 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node41 = new com.google.javascript.rhino.Node((int) '4');
        node39.addChildrenToBack(node41);
        node35.addChildAfter(node37, node41);
        com.google.javascript.rhino.Node node45 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node47 = new com.google.javascript.rhino.Node((int) '4');
        node45.addChildrenToBack(node47);
        com.google.javascript.rhino.Node node49 = node35.copyInformationFromForTree(node47);
        try {
            com.google.javascript.rhino.Node node50 = new com.google.javascript.rhino.Node(36, node14, node33, node35);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertNotNull(node32);
        org.junit.Assert.assertNull(node33);
        org.junit.Assert.assertNotNull(node49);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        com.google.javascript.jscomp.SourceAst sourceAst0 = null;
        try {
            com.google.javascript.jscomp.CompilerInput compilerInput2 = new com.google.javascript.jscomp.CompilerInput(sourceAst0, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        java.lang.String str0 = com.google.javascript.rhino.jstype.JSType.NOT_A_TYPE;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "Not declared as a type name" + "'", str0.equals("Not declared as a type name"));
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        java.lang.String str1 = com.google.javascript.rhino.jstype.ObjectType.createDelegateSuffix("// Input %num%");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "(// Input %num%)" + "'", str1.equals("(// Input %num%)"));
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        try {
            com.google.javascript.rhino.EcmaError ecmaError2 = com.google.javascript.rhino.ScriptRuntime.typeError1("(// Input %num%)", "hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property (// Input %num%)");
        } catch (java.lang.RuntimeException e) {
        }
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.VISIBILITY;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = null;
        com.google.javascript.jscomp.DiagnosticGroups.GLOBAL_THIS = diagnosticGroup0;
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setLooseTypes(true);
        boolean boolean3 = compilerOptions0.collapseVariableDeclarations;
        boolean boolean4 = compilerOptions0.generateExports;
        com.google.javascript.jscomp.SourceMap.DetailLevel detailLevel5 = compilerOptions0.sourceMapDetailLevel;
        boolean boolean6 = compilerOptions0.strictMessageReplacement;
        com.google.javascript.jscomp.CheckLevel checkLevel7 = null;
        compilerOptions0.checkMissingGetCssNameLevel = checkLevel7;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(detailLevel5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        try {
            com.google.javascript.rhino.EcmaError ecmaError4 = com.google.javascript.rhino.ScriptRuntime.typeError3("hi!", "hi!", "4", "4");
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property hi!");
        } catch (java.lang.RuntimeException e) {
        }
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        com.google.javascript.jscomp.SourceFile sourceFile1 = com.google.javascript.jscomp.SourceFile.fromFile("Not declared as a type name");
        org.junit.Assert.assertNotNull(sourceFile1);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        int int0 = com.google.javascript.rhino.Node.FIXUPS_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 9 + "'", int0 == 9);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        try {
            com.google.javascript.jscomp.JSError[] jSErrorArray2 = compiler1.getMessages();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        com.google.javascript.jscomp.CompilerOptions.TracerMode tracerMode0 = com.google.javascript.jscomp.CompilerOptions.TracerMode.OFF;
        org.junit.Assert.assertTrue("'" + tracerMode0 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TracerMode.OFF + "'", tracerMode0.equals(com.google.javascript.jscomp.CompilerOptions.TracerMode.OFF));
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        java.lang.String str0 = com.google.javascript.rhino.jstype.JSType.EMPTY_TYPE_COMPONENT;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "Named type with empty name component" + "'", str0.equals("Named type with empty name component"));
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        int int0 = com.google.javascript.rhino.Node.LABEL_ID_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        int int0 = com.google.javascript.rhino.Context.FEATURE_MEMBER_EXPR_AS_FUNCTION_NAME;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        try {
            boolean boolean2 = compiler1.acceptConstKeyword();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        int int0 = com.google.javascript.rhino.Node.LAST_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 49 + "'", int0 == 49);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        int int0 = com.google.javascript.rhino.Node.FLAG_NO_THROWS;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 8 + "'", int0 == 8);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        com.google.javascript.rhino.Node node1 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node3 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node5 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node7 = new com.google.javascript.rhino.Node((int) '4');
        node5.addChildrenToBack(node7);
        node1.addChildAfter(node3, node7);
        com.google.javascript.rhino.Node node10 = node7.getParent();
        com.google.javascript.rhino.Node node12 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node14 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node16 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node18 = new com.google.javascript.rhino.Node((int) '4');
        node16.addChildrenToBack(node18);
        node12.addChildAfter(node14, node18);
        com.google.javascript.rhino.Node node22 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node24 = new com.google.javascript.rhino.Node((int) '4');
        node22.addChildrenToBack(node24);
        com.google.javascript.rhino.Node node26 = node12.copyInformationFromForTree(node24);
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable27 = node26.siblings();
        com.google.javascript.rhino.Node node29 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node31 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node33 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node35 = new com.google.javascript.rhino.Node((int) '4');
        node33.addChildrenToBack(node35);
        node29.addChildAfter(node31, node35);
        com.google.javascript.rhino.Node node39 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node41 = new com.google.javascript.rhino.Node((int) '4');
        node39.addChildrenToBack(node41);
        com.google.javascript.rhino.Node node43 = node29.copyInformationFromForTree(node41);
        com.google.javascript.rhino.Node node45 = node29.getAncestor(1);
        com.google.javascript.rhino.Node node47 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node49 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node51 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node53 = new com.google.javascript.rhino.Node((int) '4');
        node51.addChildrenToBack(node53);
        node47.addChildAfter(node49, node53);
        com.google.javascript.rhino.Node node57 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node59 = new com.google.javascript.rhino.Node((int) '4');
        node57.addChildrenToBack(node59);
        com.google.javascript.rhino.Node node61 = node47.copyInformationFromForTree(node59);
        com.google.javascript.rhino.Node node63 = node47.getAncestor(1);
        node29.addChildToFront(node47);
        try {
            node10.addChildBefore(node26, node47);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: node is not a child");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertNotNull(nodeIterable27);
        org.junit.Assert.assertNotNull(node43);
        org.junit.Assert.assertNull(node45);
        org.junit.Assert.assertNotNull(node61);
        org.junit.Assert.assertNull(node63);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        com.google.javascript.rhino.jstype.JSType jSType0 = null;
        com.google.javascript.rhino.jstype.JSType jSType1 = null;
        boolean boolean2 = com.google.javascript.rhino.jstype.JSType.isEquivalent(jSType0, jSType1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setLooseTypes(true);
        boolean boolean3 = compilerOptions0.reserveRawExports;
        compilerOptions0.extractPrototypeMemberDeclarations = false;
        java.lang.String str6 = compilerOptions0.nameReferenceGraphPath;
        boolean boolean7 = compilerOptions0.markNoSideEffectCalls;
        com.google.javascript.jscomp.ErrorFormat errorFormat8 = compilerOptions0.errorFormat;
        boolean boolean9 = compilerOptions0.exportTestFunctions;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(errorFormat8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setLooseTypes(true);
        boolean boolean3 = compilerOptions0.reserveRawExports;
        compilerOptions0.inferTypesInGlobalScope = false;
        compilerOptions0.exportTestFunctions = false;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        java.io.Reader reader1 = null;
        try {
            com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromReader("hi!", reader1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newString("hi!");
        int int2 = node1.getSourcePosition();
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setLooseTypes(true);
        compilerOptions0.convertToDottedProperties = false;
        boolean boolean5 = compilerOptions0.removeTryCatchFinally;
        compilerOptions0.setOutputCharset("JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}");
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        compiler1.disableThreads();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile3 = null;
        try {
            com.google.javascript.rhino.Node node4 = compiler1.parse(jSSourceFile3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        int int0 = com.google.javascript.rhino.Node.SPECIAL_PROP_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 18 + "'", int0 == 18);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setLooseTypes(true);
        boolean boolean3 = compilerOptions0.collapseVariableDeclarations;
        boolean boolean4 = compilerOptions0.generateExports;
        com.google.javascript.jscomp.SourceMap.DetailLevel detailLevel5 = compilerOptions0.sourceMapDetailLevel;
        boolean boolean6 = compilerOptions0.strictMessageReplacement;
        compilerOptions0.instrumentationTemplate = "";
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(detailLevel5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        com.google.javascript.rhino.Node node1 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node3 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node5 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node7 = new com.google.javascript.rhino.Node((int) '4');
        node5.addChildrenToBack(node7);
        node1.addChildAfter(node3, node7);
        com.google.javascript.rhino.Node node11 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node((int) '4');
        node11.addChildrenToBack(node13);
        com.google.javascript.rhino.Node node15 = node1.copyInformationFromForTree(node13);
        com.google.javascript.rhino.Node node16 = node15.getLastChild();
        com.google.javascript.rhino.Node node18 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node20 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node22 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node24 = new com.google.javascript.rhino.Node((int) '4');
        node22.addChildrenToBack(node24);
        node18.addChildAfter(node20, node24);
        com.google.javascript.rhino.Node node28 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node30 = new com.google.javascript.rhino.Node((int) '4');
        node28.addChildrenToBack(node30);
        com.google.javascript.rhino.Node node32 = node18.copyInformationFromForTree(node30);
        node15.addChildToBack(node18);
        com.google.javascript.rhino.Node node35 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node37 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node39 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node41 = new com.google.javascript.rhino.Node((int) '4');
        node39.addChildrenToBack(node41);
        node35.addChildAfter(node37, node41);
        com.google.javascript.rhino.Node node44 = node35.cloneTree();
        try {
            com.google.javascript.rhino.Node node45 = node15.removeChildAfter(node44);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: prev is not a child of this node.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertNull(node16);
        org.junit.Assert.assertNotNull(node32);
        org.junit.Assert.assertNotNull(node44);
    }

//    @Test
//    public void test104() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test104");
//        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup3 = com.google.javascript.jscomp.DiagnosticGroups.MISSING_PROPERTIES;
//        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup4 = com.google.javascript.jscomp.DiagnosticGroups.STRICT_MODULE_DEP_CHECK;
//        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup5 = com.google.javascript.jscomp.DiagnosticGroups.STRICT_MODULE_DEP_CHECK;
//        com.google.javascript.jscomp.DiagnosticGroups.TYPE_INVALIDATION = diagnosticGroup5;
//        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup7 = com.google.javascript.jscomp.DiagnosticGroups.MISSING_PROPERTIES;
//        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup8 = com.google.javascript.jscomp.DiagnosticGroups.STRICT_MODULE_DEP_CHECK;
//        com.google.javascript.jscomp.DiagnosticGroups.MISSING_PROPERTIES = diagnosticGroup8;
//        com.google.javascript.jscomp.DiagnosticGroups.STRICT_MODULE_DEP_CHECK = diagnosticGroup8;
//        com.google.javascript.jscomp.DiagnosticGroup[] diagnosticGroupArray11 = new com.google.javascript.jscomp.DiagnosticGroup[] { diagnosticGroup3, diagnosticGroup4, diagnosticGroup5, diagnosticGroup7, diagnosticGroup8 };
//        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup12 = new com.google.javascript.jscomp.DiagnosticGroup("4", diagnosticGroupArray11);
//        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup13 = new com.google.javascript.jscomp.DiagnosticGroup("TypeError", diagnosticGroupArray11);
//        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup14 = new com.google.javascript.jscomp.DiagnosticGroup("// Input %num%", diagnosticGroupArray11);
//        org.junit.Assert.assertNotNull(diagnosticGroup3);
//        org.junit.Assert.assertNotNull(diagnosticGroup4);
//        org.junit.Assert.assertNotNull(diagnosticGroup5);
//        org.junit.Assert.assertNotNull(diagnosticGroup7);
//        org.junit.Assert.assertNotNull(diagnosticGroup8);
//        org.junit.Assert.assertNotNull(diagnosticGroupArray11);
//    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        try {
            com.google.javascript.rhino.EcmaError ecmaError4 = com.google.javascript.rhino.ScriptRuntime.typeError3("hi!", "", "(// Input %num%)", "(// Input %num%)");
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property hi!");
        } catch (java.lang.RuntimeException e) {
        }
    }

//    @Test
//    public void test106() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test106");
//        try {
//            java.lang.String str2 = com.google.javascript.rhino.ScriptRuntime.numberToString((double) 'a', (int) (short) 100);
//            org.junit.Assert.fail("Expected exception of type com.google.javascript.rhino.EvaluatorException; message: illegal radix 100.");
//        } catch (com.google.javascript.rhino.EvaluatorException e) {
//        }
//    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromCode("hi!", "hi!");
        java.lang.String str3 = sourceFile2.toString();
        sourceFile2.setOriginalPath("hi!");
        org.junit.Assert.assertNotNull(sourceFile2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "hi!" + "'", str3.equals("hi!"));
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy0 = com.google.javascript.jscomp.PropertyRenamingPolicy.OFF;
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy0 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.OFF + "'", propertyRenamingPolicy0.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.OFF));
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        try {
            compiler1.normalize();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setLooseTypes(true);
        compilerOptions0.checkSuspiciousCode = false;
        boolean boolean5 = compilerOptions0.removeDeadCode;
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        int int0 = com.google.javascript.rhino.Node.FREE_CALL;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 49 + "'", int0 == 49);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        java.lang.String str0 = com.google.javascript.rhino.Context.languageVersionProperty;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "language version" + "'", str0.equals("language version"));
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        int int0 = com.google.javascript.rhino.Node.REGEXP_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 12 + "'", int0 == 12);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        com.google.javascript.rhino.Node node1 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node3 = new com.google.javascript.rhino.Node((int) '4');
        node1.addChildrenToBack(node3);
        com.google.javascript.rhino.Node node5 = node1.getLastChild();
        java.lang.Appendable appendable6 = null;
        try {
            node5.appendStringTree(appendable6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node5);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        try {
            com.google.javascript.rhino.Context.checkOptimizationLevel(100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Optimization level outside [-1..9]: 100");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        compiler1.disableThreads();
        com.google.javascript.jscomp.PerformanceTracker performanceTracker3 = compiler1.tracker;
        try {
            compiler1.normalize();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(performanceTracker3);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        com.google.javascript.rhino.Node node1 = new com.google.javascript.rhino.Node((int) (short) 1);
        com.google.javascript.rhino.Node node3 = new com.google.javascript.rhino.Node((int) (short) 1);
        node1.addChildrenToBack(node3);
        try {
            node1.setDouble((double) 31);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: EOL is not a string node");
        } catch (java.lang.UnsupportedOperationException e) {
        }
    }

//    @Test
//    public void test118() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test118");
//        try {
//            com.google.javascript.rhino.Context.reportError("// Input %num%");
//            org.junit.Assert.fail("Expected exception of type com.google.javascript.rhino.EvaluatorException; message: // Input %num%");
//        } catch (com.google.javascript.rhino.EvaluatorException e) {
//        }
//    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        int int0 = com.google.javascript.rhino.Node.CASEARRAY_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 15 + "'", int0 == 15);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        compiler1.disableThreads();
        com.google.javascript.jscomp.PerformanceTracker performanceTracker3 = compiler1.tracker;
        try {
            java.lang.String str4 = compiler1.toSource();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(performanceTracker3);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        int int0 = com.google.javascript.rhino.Context.FEATURE_RESERVED_KEYWORD_AS_IDENTIFIER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        java.lang.String str2 = com.google.javascript.rhino.ScriptRuntime.numberToString((double) 30, 9);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "33" + "'", str2.equals("33"));
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        com.google.javascript.rhino.Context.checkLanguageVersion(160);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        try {
            java.lang.String str1 = com.google.javascript.rhino.ScriptRuntime.getMessage0("JSC_OPTIMIZE_LOOP_ERROR. Exceeded max number of code motion iterations: {0} at (unknown source) line (unknown line) : (unknown column)");
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property JSC_OPTIMIZE_LOOP_ERROR. Exceeded max number of code motion iterations: {0} at (unknown source) line (unknown line) : (unknown column)");
        } catch (java.lang.RuntimeException e) {
        }
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = null;
        com.google.javascript.jscomp.DiagnosticGroups.VISIBILITY = diagnosticGroup0;
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        com.google.javascript.rhino.Node node1 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node3 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node5 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node7 = new com.google.javascript.rhino.Node((int) '4');
        node5.addChildrenToBack(node7);
        node1.addChildAfter(node3, node7);
        com.google.javascript.rhino.Node node11 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node((int) '4');
        node11.addChildrenToBack(node13);
        com.google.javascript.rhino.Node node15 = node1.copyInformationFromForTree(node13);
        com.google.javascript.rhino.Node node17 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node18 = node1.copyInformationFromForTree(node17);
        try {
            node1.setDouble((double) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: INSTANCEOF is not a string node");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertNotNull(node18);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        compiler1.disableThreads();
        com.google.javascript.jscomp.PerformanceTracker performanceTracker3 = compiler1.tracker;
        try {
            com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry4 = compiler1.getTypeRegistry();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(performanceTracker3);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        int int0 = com.google.javascript.rhino.Node.TARGET_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        int int0 = com.google.javascript.rhino.Node.BOTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        com.google.javascript.jscomp.SourceAst sourceAst0 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(sourceAst0, "", false);
        com.google.javascript.jscomp.JSModule jSModule4 = compilerInput3.getModule();
        com.google.javascript.jscomp.JSModule jSModule5 = null;
        compilerInput3.setModule(jSModule5);
        com.google.javascript.jscomp.SourceFile sourceFile9 = com.google.javascript.jscomp.SourceFile.fromCode("hi!", "hi!");
        java.lang.String str10 = sourceFile9.getOriginalPath();
        try {
            compilerInput3.setSourceFile(sourceFile9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(jSModule4);
        org.junit.Assert.assertNotNull(sourceFile9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "hi!" + "'", str10.equals("hi!"));
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setLooseTypes(true);
        compilerOptions0.checkSuspiciousCode = false;
        com.google.common.collect.Multimap<com.google.javascript.jscomp.CustomPassExecutionTime, com.google.javascript.jscomp.CompilerPass> customPassExecutionTimeMultimap5 = compilerOptions0.customPasses;
        compilerOptions0.rewriteFunctionExpressions = true;
        compilerOptions0.optimizeCalls = false;
        compilerOptions0.aliasStringsBlacklist = "// Input %num%";
        org.junit.Assert.assertNull(customPassExecutionTimeMultimap5);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        compiler1.disableThreads();
        try {
            compiler1.processDefines();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        java.lang.String str0 = com.google.javascript.rhino.Context.errorReporterProperty;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "error reporter" + "'", str0.equals("error reporter"));
    }

//    @Test
//    public void test134() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test134");
//        try {
//            com.google.javascript.rhino.EvaluatorException evaluatorException5 = com.google.javascript.rhino.Context.reportRuntimeError("Exceeded max number of code motion iterations: {0}", "", (int) '4', "error reporter", 150);
//            org.junit.Assert.fail("Expected exception of type com.google.javascript.rhino.EvaluatorException; message: Exceeded max number of code motion iterations: {0} (#52)");
//        } catch (com.google.javascript.rhino.EvaluatorException e) {
//        }
//    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setLooseTypes(true);
        compilerOptions0.convertToDottedProperties = false;
        boolean boolean5 = compilerOptions0.removeTryCatchFinally;
        boolean boolean6 = compilerOptions0.groupVariableDeclarations;
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        int int0 = com.google.javascript.rhino.Context.FEATURE_STRICT_EVAL;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 9 + "'", int0 == 9);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setLooseTypes(true);
        boolean boolean3 = compilerOptions0.reserveRawExports;
        boolean boolean4 = compilerOptions0.flowSensitiveInlineVariables;
        compilerOptions0.checkTypedPropertyCalls = false;
        compilerOptions0.groupVariableDeclarations = true;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setLooseTypes(true);
        compilerOptions0.checkSuspiciousCode = false;
        com.google.common.collect.Multimap<com.google.javascript.jscomp.CustomPassExecutionTime, com.google.javascript.jscomp.CompilerPass> customPassExecutionTimeMultimap5 = compilerOptions0.customPasses;
        compilerOptions0.setRemoveAbstractMethods(false);
        compilerOptions0.setSummaryDetailLevel(17);
        org.junit.Assert.assertNull(customPassExecutionTimeMultimap5);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention0 = new com.google.javascript.jscomp.DefaultCodingConvention();
        java.lang.String str1 = defaultCodingConvention0.getDelegateSuperclassName();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = null;
        com.google.javascript.jscomp.Scope scope3 = null;
        com.google.javascript.rhino.jstype.ObjectType[] objectTypeArray4 = new com.google.javascript.rhino.jstype.ObjectType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.ObjectType> objectTypeList5 = new java.util.ArrayList<com.google.javascript.rhino.jstype.ObjectType>();
        boolean boolean6 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.ObjectType>) objectTypeList5, objectTypeArray4);
        defaultCodingConvention0.defineDelegateProxyPrototypeProperties(jSTypeRegistry2, scope3, (java.util.List<com.google.javascript.rhino.jstype.ObjectType>) objectTypeList5);
        com.google.javascript.rhino.Node node9 = new com.google.javascript.rhino.Node((int) (short) 1);
        com.google.javascript.rhino.Node node11 = new com.google.javascript.rhino.Node((int) (short) 1);
        node9.addChildrenToBack(node11);
        try {
            boolean boolean13 = defaultCodingConvention0.isOptionalParameter(node9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertNotNull(objectTypeArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.CONSTANT_PROPERTY;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        compiler1.disableThreads();
        com.google.javascript.jscomp.Compiler.IntermediateState intermediateState3 = compiler1.getState();
        try {
            boolean boolean4 = compiler1.hasErrors();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intermediateState3);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        try {
            java.lang.String str3 = com.google.javascript.rhino.ScriptRuntime.getMessage2("com.google.javascript.rhino.EcmaError: TypeError: 4", (java.lang.Object) 100L, (java.lang.Object) 49);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property com.google.javascript.rhino.EcmaError: TypeError: 4");
        } catch (java.lang.RuntimeException e) {
        }
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setLooseTypes(true);
        boolean boolean3 = compilerOptions0.reserveRawExports;
        boolean boolean4 = compilerOptions0.flowSensitiveInlineVariables;
        compilerOptions0.checkTypedPropertyCalls = false;
        com.google.javascript.jscomp.CompilerOptions compilerOptions7 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions7.setLooseTypes(true);
        boolean boolean10 = compilerOptions7.reserveRawExports;
        compilerOptions7.extractPrototypeMemberDeclarations = false;
        java.lang.String str13 = compilerOptions7.nameReferenceGraphPath;
        compilerOptions7.computeFunctionSideEffects = true;
        com.google.javascript.jscomp.CompilerOptions compilerOptions16 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions16.setLooseTypes(true);
        compilerOptions16.convertToDottedProperties = false;
        com.google.javascript.jscomp.CheckLevel checkLevel21 = compilerOptions16.reportMissingOverride;
        compilerOptions7.brokenClosureRequiresLevel = checkLevel21;
        java.util.Set<java.lang.String> strSet23 = compilerOptions7.stripTypePrefixes;
        compilerOptions0.aliasableStrings = strSet23;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertTrue("'" + checkLevel21 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel21.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(strSet23);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setLooseTypes(true);
        compilerOptions0.checkSuspiciousCode = false;
        compilerOptions0.setCollapsePropertiesOnExternTypes(false);
        compilerOptions0.disableRuntimeTypeCheck();
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap8 = compilerOptions0.cssRenamingMap;
        compilerOptions0.computeFunctionSideEffects = false;
        org.junit.Assert.assertNull(cssRenamingMap8);
    }

//    @Test
//    public void test145() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test145");
//        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.UNDEFINED_VARIABLES;
//        org.junit.Assert.assertNotNull(diagnosticGroup0);
//    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        java.io.InputStream inputStream1 = null;
        try {
            com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromInputStream("language version", inputStream1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setLooseTypes(true);
        compilerOptions0.checkSuspiciousCode = false;
        compilerOptions0.setCollapsePropertiesOnExternTypes(false);
        java.lang.String str7 = compilerOptions0.unaliasableGlobals;
        org.junit.Assert.assertNull(str7);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        int int0 = com.google.javascript.rhino.Node.FLAG_LOCAL_RESULTS;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 16 + "'", int0 == 16);
    }

//    @Test
//    public void test149() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test149");
//        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray0 = new com.google.javascript.jscomp.WarningsGuard[] {};
//        java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard> warningsGuardList1 = new java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard>();
//        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList1, warningsGuardArray0);
//        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard3 = new com.google.javascript.jscomp.ComposeWarningsGuard((java.util.List<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList1);
//        com.google.javascript.jscomp.JSError jSError4 = null;
//        com.google.javascript.jscomp.CheckLevel checkLevel5 = composeWarningsGuard3.level(jSError4);
//        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup6 = com.google.javascript.jscomp.DiagnosticGroups.EXTERNS_VALIDATION;
//        boolean boolean7 = composeWarningsGuard3.disables(diagnosticGroup6);
//        org.junit.Assert.assertNotNull(warningsGuardArray0);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertNull(checkLevel5);
//        org.junit.Assert.assertNotNull(diagnosticGroup6);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        int int0 = com.google.javascript.rhino.Node.LOCALCOUNT_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 21 + "'", int0 == 21);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setLooseTypes(true);
        boolean boolean3 = compilerOptions0.reserveRawExports;
        com.google.javascript.jscomp.CheckLevel checkLevel4 = null;
        compilerOptions0.checkUnreachableCode = checkLevel4;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy6 = null;
        compilerOptions0.variableRenaming = variableRenamingPolicy6;
        compilerOptions0.recordFunctionInformation = true;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        com.google.javascript.rhino.Context context0 = new com.google.javascript.rhino.Context();
        context0.addActivationName("com.google.javascript.rhino.EcmaError: TypeError: 4");
        try {
            context0.setLanguageVersion((int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Bad language version: 52");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        com.google.javascript.rhino.Node node2 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node4 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node6 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node8 = new com.google.javascript.rhino.Node((int) '4');
        node6.addChildrenToBack(node8);
        node2.addChildAfter(node4, node8);
        com.google.javascript.rhino.Node node11 = node2.cloneTree();
        com.google.javascript.jscomp.AnonymousFunctionNamingPolicy anonymousFunctionNamingPolicy13 = com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.UNMAPPED;
        com.google.javascript.jscomp.CompilerOptions compilerOptions14 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions14.setLooseTypes(true);
        boolean boolean17 = compilerOptions14.reserveRawExports;
        compilerOptions14.extractPrototypeMemberDeclarations = false;
        boolean boolean20 = compilerOptions14.exportTestFunctions;
        try {
            java.lang.String str21 = com.google.javascript.rhino.ScriptRuntime.getMessage4("error reporter", (java.lang.Object) node2, (java.lang.Object) 12, (java.lang.Object) anonymousFunctionNamingPolicy13, (java.lang.Object) boolean20);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property error reporter");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertTrue("'" + anonymousFunctionNamingPolicy13 + "' != '" + com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.UNMAPPED + "'", anonymousFunctionNamingPolicy13.equals(com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.UNMAPPED));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        com.google.javascript.jscomp.CompilerOptions.TweakProcessing tweakProcessing0 = com.google.javascript.jscomp.CompilerOptions.TweakProcessing.OFF;
        org.junit.Assert.assertTrue("'" + tweakProcessing0 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TweakProcessing.OFF + "'", tweakProcessing0.equals(com.google.javascript.jscomp.CompilerOptions.TweakProcessing.OFF));
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        int int0 = com.google.javascript.rhino.Node.DECR_FLAG;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        try {
            java.lang.String str1 = com.google.javascript.rhino.ScriptRuntime.getMessage0("Not declared as a type name");
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property Not declared as a type name");
        } catch (java.lang.RuntimeException e) {
        }
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.common.collect.Multimap<com.google.javascript.jscomp.CustomPassExecutionTime, com.google.javascript.jscomp.CompilerPass> customPassExecutionTimeMultimap1 = compilerOptions0.customPasses;
        com.google.javascript.jscomp.CheckLevel checkLevel2 = compilerOptions0.checkGlobalNamesLevel;
        compilerOptions0.checkUnusedPropertiesEarly = true;
        org.junit.Assert.assertNull(customPassExecutionTimeMultimap1);
        org.junit.Assert.assertTrue("'" + checkLevel2 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel2.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        com.google.javascript.jscomp.SourceAst sourceAst0 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(sourceAst0, "", false);
        try {
            java.lang.String str4 = compilerInput3.getPathRelativeToClosureBase();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: null");
        } catch (java.lang.UnsupportedOperationException e) {
        }
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        int int0 = com.google.javascript.rhino.Node.EMPTY_BLOCK;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 38 + "'", int0 == 38);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        int int0 = com.google.javascript.rhino.Context.FEATURE_TO_STRING_AS_SOURCE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeUnusedPrototypePropertiesInExterns = false;
        boolean boolean3 = compilerOptions0.markAsCompiled;
        boolean boolean4 = compilerOptions0.optimizeArgumentsArray;
        boolean boolean5 = compilerOptions0.moveFunctionDeclarations;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setLooseTypes(true);
        compilerOptions0.convertToDottedProperties = false;
        com.google.javascript.jscomp.CheckLevel checkLevel5 = compilerOptions0.reportMissingOverride;
        boolean boolean6 = compilerOptions0.aliasAllStrings;
        compilerOptions0.instrumentationTemplate = "hi!";
        boolean boolean9 = compilerOptions0.exportTestFunctions;
        java.util.Map<java.lang.String, com.google.javascript.rhino.Node> strMap10 = compilerOptions0.getDefineReplacements();
        compilerOptions0.unaliasableGlobals = "Not declared as a type name";
        org.junit.Assert.assertTrue("'" + checkLevel5 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel5.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(strMap10);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        com.google.javascript.jscomp.SourceAst sourceAst0 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(sourceAst0, "", false);
        com.google.javascript.jscomp.JSModule jSModule4 = compilerInput3.getModule();
        com.google.javascript.jscomp.JSModule jSModule5 = null;
        compilerInput3.setModule(jSModule5);
        try {
            com.google.javascript.jscomp.SourceFile sourceFile7 = compilerInput3.getSourceFile();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(jSModule4);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeUnusedPrototypePropertiesInExterns = false;
        compilerOptions0.removeUnusedLocalVars = false;
        compilerOptions0.checkMissingGetCssNameBlacklist = "JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}";
        compilerOptions0.allowLegacyJsMessages = false;
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        com.google.javascript.jscomp.DiagnosticType diagnosticType2 = com.google.javascript.jscomp.DiagnosticType.warning("hi!", "hi!");
        java.lang.String str3 = diagnosticType2.key;
        java.lang.String str4 = diagnosticType2.toString();
        java.lang.String str5 = diagnosticType2.toString();
        org.junit.Assert.assertNotNull(diagnosticType2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "hi!" + "'", str3.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "hi!: hi!" + "'", str4.equals("hi!: hi!"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!: hi!" + "'", str5.equals("hi!: hi!"));
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        long long1 = com.google.javascript.rhino.ScriptRuntime.testUint32String("TypeError");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1L) + "'", long1 == (-1L));
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        com.google.javascript.jscomp.SourceAst sourceAst0 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(sourceAst0, "", false);
        com.google.javascript.jscomp.JSModule jSModule4 = compilerInput3.getModule();
        com.google.javascript.jscomp.JSModule jSModule5 = null;
        compilerInput3.setModule(jSModule5);
        try {
            java.lang.String str7 = compilerInput3.getCode();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(jSModule4);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        int int0 = com.google.javascript.rhino.Node.NAME_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 33 + "'", int0 == 33);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        boolean boolean1 = com.google.javascript.rhino.Context.isValidOptimizationLevel(34);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        int int0 = com.google.javascript.rhino.Node.NO_SIDE_EFFECTS;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 15 + "'", int0 == 15);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        com.google.javascript.rhino.Context.checkOptimizationLevel(2);
    }

//    @Test
//    public void test172() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test172");
//        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.INTERNET_EXPLORER_CHECKS;
//        com.google.javascript.jscomp.DiagnosticGroups.CHECK_USELESS_CODE = diagnosticGroup0;
//        org.junit.Assert.assertNotNull(diagnosticGroup0);
//    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        com.google.javascript.rhino.Node node2 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node4 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node6 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node8 = new com.google.javascript.rhino.Node((int) '4');
        node6.addChildrenToBack(node8);
        node2.addChildAfter(node4, node8);
        com.google.javascript.rhino.Node node12 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node14 = new com.google.javascript.rhino.Node((int) '4');
        node12.addChildrenToBack(node14);
        com.google.javascript.rhino.Node node16 = node2.copyInformationFromForTree(node14);
        com.google.javascript.rhino.Node node17 = node16.getLastChild();
        com.google.javascript.rhino.Node node21 = new com.google.javascript.rhino.Node(30, 35, 8);
        com.google.javascript.rhino.Node node22 = node21.getLastChild();
        try {
            com.google.javascript.rhino.Node node23 = new com.google.javascript.rhino.Node((int) ' ', node17, node21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertNull(node17);
        org.junit.Assert.assertNull(node22);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        int int0 = com.google.javascript.rhino.jstype.JSType.ENUMDECL;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile4 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        java.io.Reader reader5 = jSSourceFile4.getCodeReader();
        com.google.javascript.jscomp.JSModule[] jSModuleArray6 = new com.google.javascript.jscomp.JSModule[] {};
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph7 = new com.google.javascript.jscomp.JSModuleGraph(jSModuleArray6);
        com.google.javascript.jscomp.CompilerOptions compilerOptions8 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions8.setLooseTypes(true);
        boolean boolean11 = compilerOptions8.collapseVariableDeclarations;
        compilerOptions8.moveFunctionDeclarations = false;
        boolean boolean14 = compilerOptions8.decomposeExpressions;
        com.google.javascript.jscomp.CheckLevel checkLevel15 = compilerOptions8.checkMissingGetCssNameLevel;
        com.google.javascript.jscomp.Result result16 = compiler1.compile(jSSourceFile4, jSModuleArray6, compilerOptions8);
        try {
            compiler1.processDefines();
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: INTERNAL COMPILER ERROR.\nPlease report this problem.\nnull");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile4);
        org.junit.Assert.assertNotNull(reader5);
        org.junit.Assert.assertNotNull(jSModuleArray6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + checkLevel15 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel15.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(result16);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        com.google.javascript.rhino.Context context0 = new com.google.javascript.rhino.Context();
        context0.setGeneratingSource(true);
        java.beans.PropertyChangeListener propertyChangeListener3 = null;
        try {
            context0.removePropertyChangeListener(propertyChangeListener3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention0 = new com.google.javascript.jscomp.DefaultCodingConvention();
        com.google.javascript.rhino.Node node2 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node4 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node6 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node8 = new com.google.javascript.rhino.Node((int) '4');
        node6.addChildrenToBack(node8);
        node2.addChildAfter(node4, node8);
        com.google.javascript.rhino.Node node11 = node8.getParent();
        java.lang.String str12 = defaultCodingConvention0.getSingletonGetterClassName(node11);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertNull(str12);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setLooseTypes(true);
        compilerOptions0.convertToDottedProperties = false;
        com.google.javascript.jscomp.CheckLevel checkLevel5 = compilerOptions0.reportMissingOverride;
        boolean boolean6 = compilerOptions0.aliasAllStrings;
        compilerOptions0.instrumentationTemplate = "hi!";
        boolean boolean9 = compilerOptions0.exportTestFunctions;
        java.util.Map<java.lang.String, com.google.javascript.rhino.Node> strMap10 = compilerOptions0.getDefineReplacements();
        boolean boolean11 = compilerOptions0.optimizeArgumentsArray;
        org.junit.Assert.assertTrue("'" + checkLevel5 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel5.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(strMap10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        com.google.javascript.jscomp.parsing.Config config3 = com.google.javascript.jscomp.parsing.ParserRunner.createConfig(true);
        com.google.javascript.jscomp.mozilla.rhino.ErrorReporter errorReporter4 = null;
        java.util.logging.Logger logger5 = null;
        try {
            com.google.javascript.rhino.Node node6 = com.google.javascript.jscomp.parsing.ParserRunner.parse("4", "JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}", config3, errorReporter4, logger5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(config3);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        int int0 = com.google.javascript.rhino.Context.FEATURE_WARNING_AS_ERROR;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 12 + "'", int0 == 12);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        compiler1.disableThreads();
        com.google.javascript.jscomp.PerformanceTracker performanceTracker3 = compiler1.tracker;
        com.google.javascript.jscomp.NodeTraversal.Callback callback4 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal5 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler1, callback4);
        try {
            compiler1.check();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(performanceTracker3);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setLooseTypes(true);
        boolean boolean3 = compilerOptions0.reserveRawExports;
        com.google.javascript.jscomp.CheckLevel checkLevel4 = null;
        compilerOptions0.checkUnreachableCode = checkLevel4;
        com.google.javascript.jscomp.MessageBundle messageBundle6 = compilerOptions0.messageBundle;
        java.lang.String str7 = compilerOptions0.sourceMapOutputPath;
        compilerOptions0.inlineConstantVars = false;
        compilerOptions0.inlineFunctions = false;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(messageBundle6);
        org.junit.Assert.assertNull(str7);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeUnusedPrototypePropertiesInExterns = false;
        compilerOptions0.removeUnusedLocalVars = false;
        compilerOptions0.ignoreCajaProperties = false;
        compilerOptions0.lineLengthThreshold((int) ' ');
        compilerOptions0.checkCaja = true;
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        com.google.javascript.rhino.Node node1 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node3 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node5 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node7 = new com.google.javascript.rhino.Node((int) '4');
        node5.addChildrenToBack(node7);
        node1.addChildAfter(node3, node7);
        com.google.javascript.rhino.Node node11 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node((int) '4');
        node11.addChildrenToBack(node13);
        com.google.javascript.rhino.Node node15 = node1.copyInformationFromForTree(node13);
        com.google.javascript.rhino.Node node16 = node1.cloneTree();
        com.google.javascript.rhino.Node node18 = new com.google.javascript.rhino.Node((int) '4');
        node16.addChildrenToBack(node18);
        boolean boolean20 = node18.isUnscopedQualifiedName();
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        int int0 = com.google.javascript.rhino.Node.TEMP_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 6 + "'", int0 == 6);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        java.lang.String str1 = com.google.javascript.rhino.Node.tokenToName(43);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "false" + "'", str1.equals("false"));
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setLooseTypes(true);
        boolean boolean3 = compilerOptions0.reserveRawExports;
        compilerOptions0.extractPrototypeMemberDeclarations = false;
        byte[] byteArray6 = compilerOptions0.inputPropertyMapSerialized;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(byteArray6);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setLooseTypes(true);
        compilerOptions0.convertToDottedProperties = false;
        com.google.javascript.jscomp.CheckLevel checkLevel5 = compilerOptions0.reportMissingOverride;
        compilerOptions0.checkTypes = false;
        org.junit.Assert.assertTrue("'" + checkLevel5 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel5.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

//    @Test
//    public void test189() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test189");
//        try {
//            com.google.javascript.rhino.Context.reportError("language version", "(// Input %num%)", 49, "JSC_OPTIMIZE_LOOP_ERROR. Exceeded max number of code motion iterations: {0} at (unknown source) line (unknown line) : (unknown column)", 4095);
//            org.junit.Assert.fail("Expected exception of type com.google.javascript.rhino.EvaluatorException; message: language version ((// Input %num%)#49)");
//        } catch (com.google.javascript.rhino.EvaluatorException e) {
//        }
//    }

//    @Test
//    public void test190() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test190");
//        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.CHECK_REGEXP;
//        org.junit.Assert.assertNotNull(diagnosticGroup0);
//    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setLooseTypes(true);
        compilerOptions0.checkSuspiciousCode = false;
        boolean boolean5 = compilerOptions0.convertToDottedProperties;
        boolean boolean6 = compilerOptions0.decomposeExpressions;
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        int int0 = com.google.javascript.rhino.Node.OBJECT_IDS_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + (-2) + "'", int0 == (-2));
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        com.google.javascript.rhino.Node node1 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node3 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node5 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node7 = new com.google.javascript.rhino.Node((int) '4');
        node5.addChildrenToBack(node7);
        node1.addChildAfter(node3, node7);
        com.google.javascript.rhino.Node node11 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node((int) '4');
        node11.addChildrenToBack(node13);
        com.google.javascript.rhino.Node node15 = node1.copyInformationFromForTree(node13);
        com.google.javascript.rhino.Node node16 = node15.getLastChild();
        com.google.javascript.rhino.Node node18 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node20 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node22 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node24 = new com.google.javascript.rhino.Node((int) '4');
        node22.addChildrenToBack(node24);
        node18.addChildAfter(node20, node24);
        com.google.javascript.rhino.Node node28 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node30 = new com.google.javascript.rhino.Node((int) '4');
        node28.addChildrenToBack(node30);
        com.google.javascript.rhino.Node node32 = node18.copyInformationFromForTree(node30);
        node15.addChildToBack(node18);
        com.google.javascript.rhino.jstype.JSType jSType34 = node18.getJSType();
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertNull(node16);
        org.junit.Assert.assertNotNull(node32);
        org.junit.Assert.assertNull(jSType34);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.flowSensitiveInlineVariables = false;
        compilerOptions0.optimizeCalls = true;
        compilerOptions0.inlineFunctions = true;
        boolean boolean7 = compilerOptions0.tightenTypes;
        compilerOptions0.flowSensitiveInlineVariables = true;
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        java.nio.charset.Charset charset1 = null;
        com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromFile("Exceeded max number of code motion iterations: {0}", charset1);
        org.junit.Assert.assertNotNull(sourceFile2);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        com.google.javascript.jscomp.AbstractCompiler abstractCompiler0 = null;
        com.google.javascript.rhino.Node node2 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node4 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node6 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node8 = new com.google.javascript.rhino.Node((int) '4');
        node6.addChildrenToBack(node8);
        node2.addChildAfter(node4, node8);
        com.google.javascript.rhino.Node node12 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node14 = new com.google.javascript.rhino.Node((int) '4');
        node12.addChildrenToBack(node14);
        com.google.javascript.rhino.Node node16 = node2.copyInformationFromForTree(node14);
        com.google.javascript.rhino.Node node18 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node19 = node2.copyInformationFromForTree(node18);
        com.google.javascript.jscomp.NodeTraversal.Callback callback20 = null;
        try {
            com.google.javascript.jscomp.NodeTraversal.traverse(abstractCompiler0, node18, callback20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertNotNull(node19);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        com.google.javascript.jscomp.SourceAst sourceAst0 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(sourceAst0, "", false);
        com.google.javascript.jscomp.JSModule jSModule4 = compilerInput3.getModule();
        com.google.javascript.jscomp.JSModule jSModule5 = null;
        compilerInput3.setModule(jSModule5);
        try {
            compilerInput3.clearAst();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(jSModule4);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        com.google.javascript.jscomp.CompilerOptions compilerOptions1 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions1.setLooseTypes(true);
        boolean boolean4 = compilerOptions1.collapseVariableDeclarations;
        compilerOptions1.moveFunctionDeclarations = false;
        boolean boolean7 = compilerOptions1.decomposeExpressions;
        boolean boolean8 = compilerOptions1.optimizeParameters;
        java.lang.String str9 = compilerOptions1.inputDelimiter;
        com.google.javascript.jscomp.ErrorFormat errorFormat10 = com.google.javascript.jscomp.ErrorFormat.LEGACY;
        java.lang.RuntimeException runtimeException11 = com.google.javascript.rhino.ScriptRuntime.undefWriteError((java.lang.Object) (short) 100, (java.lang.Object) str9, (java.lang.Object) errorFormat10);
        java.io.PrintStream printStream12 = null;
        com.google.javascript.jscomp.Compiler compiler13 = new com.google.javascript.jscomp.Compiler(printStream12);
        compiler13.disableThreads();
        com.google.javascript.jscomp.PerformanceTracker performanceTracker15 = compiler13.tracker;
        com.google.javascript.jscomp.MessageFormatter messageFormatter17 = errorFormat10.toFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler13, false);
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter18 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler13);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile21 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        java.io.Reader reader22 = jSSourceFile21.getCodeReader();
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray23 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile21 };
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray24 = null;
        com.google.javascript.jscomp.CompilerOptions compilerOptions25 = null;
        try {
            com.google.javascript.jscomp.Result result26 = compiler13.compile(jSSourceFileArray23, jSSourceFileArray24, compilerOptions25);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "// Input %num%" + "'", str9.equals("// Input %num%"));
        org.junit.Assert.assertNotNull(errorFormat10);
        org.junit.Assert.assertNotNull(runtimeException11);
        org.junit.Assert.assertNull(performanceTracker15);
        org.junit.Assert.assertNotNull(messageFormatter17);
        org.junit.Assert.assertNotNull(jSSourceFile21);
        org.junit.Assert.assertNotNull(reader22);
        org.junit.Assert.assertNotNull(jSSourceFileArray23);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        com.google.javascript.rhino.EcmaError ecmaError1 = com.google.javascript.rhino.ScriptRuntime.typeError("");
        int int2 = ecmaError1.getLineNumber();
        org.junit.Assert.assertNotNull(ecmaError1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        com.google.javascript.jscomp.SourceAst sourceAst0 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(sourceAst0, "", false);
        com.google.javascript.jscomp.JSModule jSModule4 = compilerInput3.getModule();
        com.google.javascript.jscomp.CompilerInput compilerInput7 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput3, "JSC_OPTIMIZE_LOOP_ERROR. Exceeded max number of code motion iterations: {0} at (unknown source) line (unknown line) : (unknown column)", false);
        com.google.javascript.jscomp.SourceFile sourceFile10 = com.google.javascript.jscomp.SourceFile.fromCode("hi!", "hi!");
        java.lang.String str11 = sourceFile10.toString();
        try {
            compilerInput7.setSourceFile(sourceFile10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(jSModule4);
        org.junit.Assert.assertNotNull(sourceFile10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "hi!" + "'", str11.equals("hi!"));
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setLooseTypes(true);
        compilerOptions0.convertToDottedProperties = false;
        com.google.javascript.jscomp.CheckLevel checkLevel5 = compilerOptions0.reportMissingOverride;
        boolean boolean6 = compilerOptions0.aliasAllStrings;
        com.google.javascript.jscomp.CompilerOptions compilerOptions7 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions7.setLooseTypes(true);
        boolean boolean10 = compilerOptions7.reserveRawExports;
        com.google.javascript.jscomp.CheckLevel checkLevel11 = null;
        compilerOptions7.checkUnreachableCode = checkLevel11;
        com.google.javascript.jscomp.MessageBundle messageBundle13 = compilerOptions7.messageBundle;
        java.lang.String str14 = compilerOptions7.sourceMapOutputPath;
        compilerOptions7.inlineConstantVars = false;
        com.google.javascript.jscomp.CheckLevel checkLevel17 = compilerOptions7.checkProvides;
        compilerOptions0.brokenClosureRequiresLevel = checkLevel17;
        org.junit.Assert.assertTrue("'" + checkLevel5 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel5.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNull(messageBundle13);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertTrue("'" + checkLevel17 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel17.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        compiler1.disableThreads();
        com.google.javascript.jscomp.PerformanceTracker performanceTracker3 = compiler1.tracker;
        com.google.javascript.jscomp.NodeTraversal.Callback callback4 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal5 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler1, callback4);
        com.google.javascript.rhino.Node node6 = null;
        com.google.javascript.jscomp.DiagnosticType diagnosticType9 = com.google.javascript.jscomp.DiagnosticType.error("", "33");
        java.lang.String[] strArray12 = new java.lang.String[] { "TypeError: 4", "TypeError" };
        try {
            nodeTraversal5.report(node6, diagnosticType9, strArray12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(performanceTracker3);
        org.junit.Assert.assertNotNull(diagnosticType9);
        org.junit.Assert.assertNotNull(strArray12);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        java.lang.String str1 = com.google.javascript.rhino.ScriptRuntime.escapeString("Not declared as a type name");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Not declared as a type name" + "'", str1.equals("Not declared as a type name"));
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        java.io.PrintStream printStream2 = null;
        com.google.javascript.jscomp.Compiler compiler3 = new com.google.javascript.jscomp.Compiler(printStream2);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile6 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        java.io.Reader reader7 = jSSourceFile6.getCodeReader();
        com.google.javascript.jscomp.JSModule[] jSModuleArray8 = new com.google.javascript.jscomp.JSModule[] {};
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph9 = new com.google.javascript.jscomp.JSModuleGraph(jSModuleArray8);
        com.google.javascript.jscomp.CompilerOptions compilerOptions10 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions10.setLooseTypes(true);
        boolean boolean13 = compilerOptions10.collapseVariableDeclarations;
        compilerOptions10.moveFunctionDeclarations = false;
        boolean boolean16 = compilerOptions10.decomposeExpressions;
        com.google.javascript.jscomp.CheckLevel checkLevel17 = compilerOptions10.checkMissingGetCssNameLevel;
        com.google.javascript.jscomp.Result result18 = compiler3.compile(jSSourceFile6, jSModuleArray8, compilerOptions10);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile21 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile24 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        java.io.Reader reader25 = jSSourceFile24.getCodeReader();
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray26 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile6, jSSourceFile21, jSSourceFile24 };
        java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList27 = new java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile>();
        boolean boolean28 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList27, jSSourceFileArray26);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile31 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray32 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile31 };
        java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList33 = new java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile>();
        boolean boolean34 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList33, jSSourceFileArray32);
        com.google.javascript.jscomp.CompilerOptions compilerOptions35 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions35.setLooseTypes(true);
        boolean boolean38 = compilerOptions35.reserveRawExports;
        compilerOptions35.extractPrototypeMemberDeclarations = false;
        java.lang.String str41 = compilerOptions35.nameReferenceGraphPath;
        compilerOptions35.setSummaryDetailLevel(0);
        com.google.javascript.jscomp.Result result44 = compiler1.compile((java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList27, (java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList33, compilerOptions35);
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter45 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler1);
        com.google.javascript.jscomp.ErrorManager errorManager46 = compiler1.getErrorManager();
        org.junit.Assert.assertNotNull(jSSourceFile6);
        org.junit.Assert.assertNotNull(reader7);
        org.junit.Assert.assertNotNull(jSModuleArray8);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + checkLevel17 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel17.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(result18);
        org.junit.Assert.assertNotNull(jSSourceFile21);
        org.junit.Assert.assertNotNull(jSSourceFile24);
        org.junit.Assert.assertNotNull(reader25);
        org.junit.Assert.assertNotNull(jSSourceFileArray26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(jSSourceFile31);
        org.junit.Assert.assertNotNull(jSSourceFileArray32);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNull(str41);
        org.junit.Assert.assertNotNull(result44);
        org.junit.Assert.assertNotNull(errorManager46);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention0 = new com.google.javascript.jscomp.DefaultCodingConvention();
        boolean boolean2 = defaultCodingConvention0.isConstant("hi!");
        java.lang.String str3 = defaultCodingConvention0.getExportSymbolFunction();
        java.lang.String str4 = defaultCodingConvention0.getDelegateSuperclassName();
        com.google.javascript.rhino.Node node5 = null;
        try {
            boolean boolean6 = defaultCodingConvention0.isVarArgsParameter(node5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        try {
            com.google.javascript.rhino.EcmaError ecmaError6 = com.google.javascript.rhino.ScriptRuntime.constructError("4", "// Input %num%", "Exceeded max number of code motion iterations: {0}", (-2), "33", 140);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: -2");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        int int0 = com.google.javascript.rhino.Node.ORIGINALNAME_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 39 + "'", int0 == 39);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        com.google.javascript.jscomp.SourceAst sourceAst0 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(sourceAst0, "", false);
        com.google.javascript.jscomp.JSModule jSModule4 = compilerInput3.getModule();
        com.google.javascript.jscomp.CompilerInput compilerInput7 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput3, "JSC_OPTIMIZE_LOOP_ERROR. Exceeded max number of code motion iterations: {0} at (unknown source) line (unknown line) : (unknown column)", false);
        com.google.javascript.jscomp.SourceFile.Generator generator9 = null;
        com.google.javascript.jscomp.SourceFile sourceFile10 = com.google.javascript.jscomp.SourceFile.fromGenerator("", generator9);
        try {
            compilerInput3.setSourceFile(sourceFile10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(jSModule4);
        org.junit.Assert.assertNotNull(sourceFile10);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        com.google.javascript.rhino.Context context0 = new com.google.javascript.rhino.Context();
        context0.setGeneratingSource(true);
        boolean boolean3 = context0.isGeneratingDebugChanged();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        int int0 = com.google.javascript.rhino.Node.CONTINUE_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        int int0 = com.google.javascript.rhino.Node.SIDE_EFFECTS_ALL;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        int int0 = com.google.javascript.rhino.Node.SIDE_EFFECT_FLAGS;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 41 + "'", int0 == 41);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        com.google.javascript.rhino.Node node1 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node3 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node5 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node7 = new com.google.javascript.rhino.Node((int) '4');
        node5.addChildrenToBack(node7);
        node1.addChildAfter(node3, node7);
        com.google.javascript.rhino.Node node11 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node((int) '4');
        node11.addChildrenToBack(node13);
        com.google.javascript.rhino.Node node15 = node1.copyInformationFromForTree(node13);
        com.google.javascript.rhino.Node node17 = new com.google.javascript.rhino.Node((int) '4');
        node17.setLineno(36);
        com.google.javascript.rhino.Node node20 = null;
        try {
            node15.addChildBefore(node17, node20);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The existing child node of the parent should not be null.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node15);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        try {
            com.google.javascript.rhino.EcmaError ecmaError4 = com.google.javascript.rhino.ScriptRuntime.typeError3("Named type with empty name component", "TypeError", "hi!: hi!", "");
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property Named type with empty name component");
        } catch (java.lang.RuntimeException e) {
        }
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        try {
            com.google.javascript.rhino.EcmaError ecmaError2 = com.google.javascript.rhino.ScriptRuntime.typeError1("()", "");
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property ()");
        } catch (java.lang.RuntimeException e) {
        }
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        java.nio.charset.Charset charset1 = null;
        com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromFile("()", charset1);
        org.junit.Assert.assertNotNull(sourceFile2);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        int int0 = com.google.javascript.rhino.Context.VERSION_1_1;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 110 + "'", int0 == 110);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        com.google.javascript.rhino.EcmaError ecmaError1 = com.google.javascript.rhino.ScriptRuntime.typeError("4");
        java.lang.String str2 = ecmaError1.details();
        java.lang.String str3 = ecmaError1.getName();
        org.junit.Assert.assertNotNull(ecmaError1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "TypeError: 4" + "'", str2.equals("TypeError: 4"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "TypeError" + "'", str3.equals("TypeError"));
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        com.google.javascript.jscomp.CheckLevel checkLevel0 = com.google.javascript.jscomp.CheckLevel.OFF;
        org.junit.Assert.assertTrue("'" + checkLevel0 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel0.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.NON_STANDARD_JSDOC;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        com.google.javascript.rhino.Node node1 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node3 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node5 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node7 = new com.google.javascript.rhino.Node((int) '4');
        node5.addChildrenToBack(node7);
        node1.addChildAfter(node3, node7);
        com.google.javascript.rhino.Node node11 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node((int) '4');
        node11.addChildrenToBack(node13);
        com.google.javascript.rhino.Node node15 = node1.copyInformationFromForTree(node13);
        com.google.javascript.rhino.Node node16 = node15.getLastChild();
        com.google.javascript.rhino.Node node18 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node20 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node22 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node24 = new com.google.javascript.rhino.Node((int) '4');
        node22.addChildrenToBack(node24);
        node18.addChildAfter(node20, node24);
        com.google.javascript.rhino.Node node28 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node30 = new com.google.javascript.rhino.Node((int) '4');
        node28.addChildrenToBack(node30);
        com.google.javascript.rhino.Node node32 = node18.copyInformationFromForTree(node30);
        node15.addChildToBack(node18);
        try {
            node15.setSideEffectFlags((int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: setIsNoSideEffectsCall only supports CALL and NEW nodes, got INSTANCEOF");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertNull(node16);
        org.junit.Assert.assertNotNull(node32);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        com.google.javascript.rhino.Node node1 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node3 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node5 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node7 = new com.google.javascript.rhino.Node((int) '4');
        node5.addChildrenToBack(node7);
        node1.addChildAfter(node3, node7);
        com.google.javascript.rhino.Node node11 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node((int) '4');
        node11.addChildrenToBack(node13);
        com.google.javascript.rhino.Node node15 = node1.copyInformationFromForTree(node13);
        com.google.javascript.rhino.Node node16 = node1.cloneTree();
        com.google.javascript.rhino.Node node17 = node1.cloneTree();
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.Node.newNumber((double) 100.0f);
        try {
            com.google.javascript.rhino.Node node20 = node17.removeChildAfter(node19);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: prev is not a child of this node.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(node19);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setLooseTypes(true);
        boolean boolean3 = compilerOptions0.reserveRawExports;
        com.google.javascript.jscomp.CheckLevel checkLevel4 = null;
        compilerOptions0.checkGlobalNamesLevel = checkLevel4;
        boolean boolean6 = compilerOptions0.convertToDottedProperties;
        compilerOptions0.removeUnusedVars = false;
        boolean boolean9 = compilerOptions0.checkDuplicateMessages;
        compilerOptions0.setAcceptConstKeyword(false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        com.google.javascript.rhino.Node node1 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node3 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node5 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node7 = new com.google.javascript.rhino.Node((int) '4');
        node5.addChildrenToBack(node7);
        node1.addChildAfter(node3, node7);
        com.google.javascript.rhino.Node node11 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node((int) '4');
        node11.addChildrenToBack(node13);
        com.google.javascript.rhino.Node node15 = node1.copyInformationFromForTree(node13);
        com.google.javascript.rhino.Node node16 = node1.cloneTree();
        com.google.javascript.rhino.Node node17 = node1.cloneTree();
        int int18 = node1.getSideEffectFlags();
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        com.google.javascript.jscomp.SourceMap.DetailLevel detailLevel0 = com.google.javascript.jscomp.SourceMap.DetailLevel.SYMBOLS;
        org.junit.Assert.assertNotNull(detailLevel0);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newNumber((double) 5, 21, 43);
        org.junit.Assert.assertNotNull(node3);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        com.google.javascript.rhino.jstype.JSType jSType0 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType1 = com.google.javascript.rhino.jstype.ObjectType.cast(jSType0);
        org.junit.Assert.assertNull(objectType1);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        com.google.javascript.rhino.Node node1 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node3 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node5 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node7 = new com.google.javascript.rhino.Node((int) '4');
        node5.addChildrenToBack(node7);
        node1.addChildAfter(node3, node7);
        com.google.javascript.rhino.Node node11 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node((int) '4');
        node11.addChildrenToBack(node13);
        com.google.javascript.rhino.Node node15 = node1.copyInformationFromForTree(node13);
        com.google.javascript.rhino.Node node17 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node18 = node1.copyInformationFromForTree(node17);
        com.google.javascript.rhino.JSDocInfo jSDocInfo19 = null;
        node17.setJSDocInfo(jSDocInfo19);
        com.google.javascript.rhino.Node node21 = node17.getParent();
        com.google.javascript.rhino.Node.SideEffectFlags sideEffectFlags22 = null;
        try {
            node17.setSideEffectFlags(sideEffectFlags22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNull(node21);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        int int0 = com.google.javascript.rhino.Node.DEBUGSOURCE_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 28 + "'", int0 == 28);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.flowSensitiveInlineVariables = false;
        compilerOptions0.optimizeCalls = true;
        compilerOptions0.inlineFunctions = true;
        boolean boolean7 = compilerOptions0.tightenTypes;
        compilerOptions0.checkDuplicateMessages = false;
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        int int0 = com.google.javascript.rhino.Node.FINALLY_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 20 + "'", int0 == 20);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        com.google.javascript.jscomp.SourceAst sourceAst0 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(sourceAst0, "", false);
        try {
            java.lang.String str5 = compilerInput3.getLine((int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile4 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        java.io.Reader reader5 = jSSourceFile4.getCodeReader();
        com.google.javascript.jscomp.JSModule[] jSModuleArray6 = new com.google.javascript.jscomp.JSModule[] {};
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph7 = new com.google.javascript.jscomp.JSModuleGraph(jSModuleArray6);
        com.google.javascript.jscomp.CompilerOptions compilerOptions8 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions8.setLooseTypes(true);
        boolean boolean11 = compilerOptions8.collapseVariableDeclarations;
        compilerOptions8.moveFunctionDeclarations = false;
        boolean boolean14 = compilerOptions8.decomposeExpressions;
        com.google.javascript.jscomp.CheckLevel checkLevel15 = compilerOptions8.checkMissingGetCssNameLevel;
        com.google.javascript.jscomp.Result result16 = compiler1.compile(jSSourceFile4, jSModuleArray6, compilerOptions8);
        com.google.javascript.jscomp.CompilerOptions.AliasTransformationHandler aliasTransformationHandler17 = null;
        compilerOptions8.setAliasTransformationHandler(aliasTransformationHandler17);
        com.google.javascript.jscomp.CheckLevel checkLevel19 = compilerOptions8.checkMissingReturn;
        org.junit.Assert.assertNotNull(jSSourceFile4);
        org.junit.Assert.assertNotNull(reader5);
        org.junit.Assert.assertNotNull(jSModuleArray6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + checkLevel15 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel15.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(result16);
        org.junit.Assert.assertTrue("'" + checkLevel19 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel19.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        java.io.PrintStream printStream2 = null;
        com.google.javascript.jscomp.Compiler compiler3 = new com.google.javascript.jscomp.Compiler(printStream2);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile6 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        java.io.Reader reader7 = jSSourceFile6.getCodeReader();
        com.google.javascript.jscomp.JSModule[] jSModuleArray8 = new com.google.javascript.jscomp.JSModule[] {};
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph9 = new com.google.javascript.jscomp.JSModuleGraph(jSModuleArray8);
        com.google.javascript.jscomp.CompilerOptions compilerOptions10 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions10.setLooseTypes(true);
        boolean boolean13 = compilerOptions10.collapseVariableDeclarations;
        compilerOptions10.moveFunctionDeclarations = false;
        boolean boolean16 = compilerOptions10.decomposeExpressions;
        com.google.javascript.jscomp.CheckLevel checkLevel17 = compilerOptions10.checkMissingGetCssNameLevel;
        com.google.javascript.jscomp.Result result18 = compiler3.compile(jSSourceFile6, jSModuleArray8, compilerOptions10);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile21 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile24 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        java.io.Reader reader25 = jSSourceFile24.getCodeReader();
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray26 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile6, jSSourceFile21, jSSourceFile24 };
        java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList27 = new java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile>();
        boolean boolean28 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList27, jSSourceFileArray26);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile31 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray32 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile31 };
        java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList33 = new java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile>();
        boolean boolean34 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList33, jSSourceFileArray32);
        com.google.javascript.jscomp.CompilerOptions compilerOptions35 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions35.setLooseTypes(true);
        boolean boolean38 = compilerOptions35.reserveRawExports;
        compilerOptions35.extractPrototypeMemberDeclarations = false;
        java.lang.String str41 = compilerOptions35.nameReferenceGraphPath;
        compilerOptions35.setSummaryDetailLevel(0);
        com.google.javascript.jscomp.Result result44 = compiler1.compile((java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList27, (java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList33, compilerOptions35);
        com.google.javascript.jscomp.JSError[] jSErrorArray45 = compiler1.getMessages();
        org.junit.Assert.assertNotNull(jSSourceFile6);
        org.junit.Assert.assertNotNull(reader7);
        org.junit.Assert.assertNotNull(jSModuleArray8);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + checkLevel17 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel17.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(result18);
        org.junit.Assert.assertNotNull(jSSourceFile21);
        org.junit.Assert.assertNotNull(jSSourceFile24);
        org.junit.Assert.assertNotNull(reader25);
        org.junit.Assert.assertNotNull(jSSourceFileArray26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(jSSourceFile31);
        org.junit.Assert.assertNotNull(jSSourceFileArray32);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNull(str41);
        org.junit.Assert.assertNotNull(result44);
        org.junit.Assert.assertNotNull(jSErrorArray45);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setLooseTypes(true);
        compilerOptions0.checkSuspiciousCode = false;
        compilerOptions0.disambiguateProperties = true;
        java.util.Map<java.lang.String, com.google.javascript.rhino.Node> strMap7 = compilerOptions0.getDefineReplacements();
        compilerOptions0.checkDuplicateMessages = false;
        java.lang.String str10 = compilerOptions0.unaliasableGlobals;
        org.junit.Assert.assertNotNull(strMap7);
        org.junit.Assert.assertNull(str10);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        int int0 = com.google.javascript.rhino.Node.VARIABLE_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 23 + "'", int0 == 23);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        compiler1.disableThreads();
        com.google.javascript.jscomp.PerformanceTracker performanceTracker3 = compiler1.tracker;
        com.google.javascript.jscomp.NodeTraversal.Callback callback4 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal5 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler1, callback4);
        java.io.PrintStream printStream6 = null;
        com.google.javascript.jscomp.Compiler compiler7 = new com.google.javascript.jscomp.Compiler(printStream6);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile10 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        java.io.Reader reader11 = jSSourceFile10.getCodeReader();
        com.google.javascript.jscomp.JSModule[] jSModuleArray12 = new com.google.javascript.jscomp.JSModule[] {};
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph13 = new com.google.javascript.jscomp.JSModuleGraph(jSModuleArray12);
        com.google.javascript.jscomp.CompilerOptions compilerOptions14 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions14.setLooseTypes(true);
        boolean boolean17 = compilerOptions14.collapseVariableDeclarations;
        compilerOptions14.moveFunctionDeclarations = false;
        boolean boolean20 = compilerOptions14.decomposeExpressions;
        com.google.javascript.jscomp.CheckLevel checkLevel21 = compilerOptions14.checkMissingGetCssNameLevel;
        com.google.javascript.jscomp.Result result22 = compiler7.compile(jSSourceFile10, jSModuleArray12, compilerOptions14);
        java.io.PrintStream printStream23 = null;
        com.google.javascript.jscomp.Compiler compiler24 = new com.google.javascript.jscomp.Compiler(printStream23);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile27 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        java.io.Reader reader28 = jSSourceFile27.getCodeReader();
        com.google.javascript.jscomp.JSModule[] jSModuleArray29 = new com.google.javascript.jscomp.JSModule[] {};
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph30 = new com.google.javascript.jscomp.JSModuleGraph(jSModuleArray29);
        com.google.javascript.jscomp.CompilerOptions compilerOptions31 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions31.setLooseTypes(true);
        boolean boolean34 = compilerOptions31.collapseVariableDeclarations;
        compilerOptions31.moveFunctionDeclarations = false;
        boolean boolean37 = compilerOptions31.decomposeExpressions;
        com.google.javascript.jscomp.CheckLevel checkLevel38 = compilerOptions31.checkMissingGetCssNameLevel;
        com.google.javascript.jscomp.Result result39 = compiler24.compile(jSSourceFile27, jSModuleArray29, compilerOptions31);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile42 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        java.io.PrintStream printStream43 = null;
        com.google.javascript.jscomp.Compiler compiler44 = new com.google.javascript.jscomp.Compiler(printStream43);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile47 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        java.io.Reader reader48 = jSSourceFile47.getCodeReader();
        com.google.javascript.jscomp.JSModule[] jSModuleArray49 = new com.google.javascript.jscomp.JSModule[] {};
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph50 = new com.google.javascript.jscomp.JSModuleGraph(jSModuleArray49);
        com.google.javascript.jscomp.CompilerOptions compilerOptions51 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions51.setLooseTypes(true);
        boolean boolean54 = compilerOptions51.collapseVariableDeclarations;
        compilerOptions51.moveFunctionDeclarations = false;
        boolean boolean57 = compilerOptions51.decomposeExpressions;
        com.google.javascript.jscomp.CheckLevel checkLevel58 = compilerOptions51.checkMissingGetCssNameLevel;
        com.google.javascript.jscomp.Result result59 = compiler44.compile(jSSourceFile47, jSModuleArray49, compilerOptions51);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile62 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile65 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        java.io.Reader reader66 = jSSourceFile65.getCodeReader();
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray67 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile10, jSSourceFile27, jSSourceFile42, jSSourceFile47, jSSourceFile62, jSSourceFile65 };
        java.io.PrintStream printStream68 = null;
        com.google.javascript.jscomp.Compiler compiler69 = new com.google.javascript.jscomp.Compiler(printStream68);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile72 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        java.io.Reader reader73 = jSSourceFile72.getCodeReader();
        com.google.javascript.jscomp.JSModule[] jSModuleArray74 = new com.google.javascript.jscomp.JSModule[] {};
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph75 = new com.google.javascript.jscomp.JSModuleGraph(jSModuleArray74);
        com.google.javascript.jscomp.CompilerOptions compilerOptions76 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions76.setLooseTypes(true);
        boolean boolean79 = compilerOptions76.collapseVariableDeclarations;
        compilerOptions76.moveFunctionDeclarations = false;
        boolean boolean82 = compilerOptions76.decomposeExpressions;
        com.google.javascript.jscomp.CheckLevel checkLevel83 = compilerOptions76.checkMissingGetCssNameLevel;
        com.google.javascript.jscomp.Result result84 = compiler69.compile(jSSourceFile72, jSModuleArray74, compilerOptions76);
        com.google.javascript.jscomp.CompilerOptions compilerOptions85 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions85.setLooseTypes(true);
        boolean boolean88 = compilerOptions85.collapseVariableDeclarations;
        compilerOptions85.setManageClosureDependencies(false);
        com.google.javascript.jscomp.Result result91 = compiler1.compile(jSSourceFileArray67, jSModuleArray74, compilerOptions85);
        com.google.javascript.jscomp.CompilerOptions compilerOptions92 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions92.setLooseTypes(true);
        boolean boolean95 = compilerOptions92.collapseVariableDeclarations;
        compilerOptions92.aliasExternals = true;
        com.google.javascript.jscomp.CheckLevel checkLevel98 = compilerOptions92.checkMissingGetCssNameLevel;
        compilerOptions85.checkMissingReturn = checkLevel98;
        org.junit.Assert.assertNull(performanceTracker3);
        org.junit.Assert.assertNotNull(jSSourceFile10);
        org.junit.Assert.assertNotNull(reader11);
        org.junit.Assert.assertNotNull(jSModuleArray12);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + checkLevel21 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel21.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(result22);
        org.junit.Assert.assertNotNull(jSSourceFile27);
        org.junit.Assert.assertNotNull(reader28);
        org.junit.Assert.assertNotNull(jSModuleArray29);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + checkLevel38 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel38.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(result39);
        org.junit.Assert.assertNotNull(jSSourceFile42);
        org.junit.Assert.assertNotNull(jSSourceFile47);
        org.junit.Assert.assertNotNull(reader48);
        org.junit.Assert.assertNotNull(jSModuleArray49);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertTrue("'" + checkLevel58 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel58.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(result59);
        org.junit.Assert.assertNotNull(jSSourceFile62);
        org.junit.Assert.assertNotNull(jSSourceFile65);
        org.junit.Assert.assertNotNull(reader66);
        org.junit.Assert.assertNotNull(jSSourceFileArray67);
        org.junit.Assert.assertNotNull(jSSourceFile72);
        org.junit.Assert.assertNotNull(reader73);
        org.junit.Assert.assertNotNull(jSModuleArray74);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
        org.junit.Assert.assertTrue("'" + checkLevel83 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel83.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(result84);
        org.junit.Assert.assertTrue("'" + boolean88 + "' != '" + false + "'", boolean88 == false);
        org.junit.Assert.assertNotNull(result91);
        org.junit.Assert.assertTrue("'" + boolean95 + "' != '" + false + "'", boolean95 == false);
        org.junit.Assert.assertTrue("'" + checkLevel98 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel98.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        com.google.javascript.rhino.Node node1 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node3 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node5 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node7 = new com.google.javascript.rhino.Node((int) '4');
        node5.addChildrenToBack(node7);
        node1.addChildAfter(node3, node7);
        com.google.javascript.rhino.Node node11 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node((int) '4');
        node11.addChildrenToBack(node13);
        com.google.javascript.rhino.Node node15 = node1.copyInformationFromForTree(node13);
        com.google.javascript.rhino.Node node16 = node15.getLastChild();
        com.google.javascript.rhino.Node node18 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node20 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node22 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node24 = new com.google.javascript.rhino.Node((int) '4');
        node22.addChildrenToBack(node24);
        node18.addChildAfter(node20, node24);
        com.google.javascript.rhino.Node node28 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node30 = new com.google.javascript.rhino.Node((int) '4');
        node28.addChildrenToBack(node30);
        com.google.javascript.rhino.Node node32 = node18.copyInformationFromForTree(node30);
        node15.addChildToBack(node18);
        com.google.javascript.rhino.Node node35 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node37 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node39 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node41 = new com.google.javascript.rhino.Node((int) '4');
        node39.addChildrenToBack(node41);
        node35.addChildAfter(node37, node41);
        com.google.javascript.rhino.Node node45 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node47 = new com.google.javascript.rhino.Node((int) '4');
        node45.addChildrenToBack(node47);
        com.google.javascript.rhino.Node node49 = node35.copyInformationFromForTree(node47);
        com.google.javascript.rhino.jstype.JSType jSType50 = null;
        node49.setJSType(jSType50);
        node15.addChildToFront(node49);
        com.google.javascript.rhino.Node node56 = com.google.javascript.rhino.Node.newString("Not declared as a type name", 120, 10);
        try {
            com.google.javascript.rhino.Node node57 = node49.removeChildAfter(node56);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: prev is not a child of this node.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertNull(node16);
        org.junit.Assert.assertNotNull(node32);
        org.junit.Assert.assertNotNull(node49);
        org.junit.Assert.assertNotNull(node56);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setLooseTypes(true);
        boolean boolean3 = compilerOptions0.collapseVariableDeclarations;
        compilerOptions0.recordFunctionInformation = false;
        compilerOptions0.convertToDottedProperties = false;
        compilerOptions0.prettyPrint = false;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        com.google.javascript.rhino.EcmaError ecmaError6 = com.google.javascript.rhino.ScriptRuntime.constructError("// Input %num%", "33", "4", 21, "JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}", 20);
        org.junit.Assert.assertNotNull(ecmaError6);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setLooseTypes(true);
        boolean boolean3 = compilerOptions0.collapseVariableDeclarations;
        compilerOptions0.moveFunctionDeclarations = false;
        boolean boolean6 = compilerOptions0.decomposeExpressions;
        compilerOptions0.recordFunctionInformation = true;
        com.google.javascript.jscomp.ErrorFormat errorFormat9 = compilerOptions0.errorFormat;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(errorFormat9);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        java.io.InputStream inputStream2 = null;
        try {
            com.google.javascript.jscomp.SourceFile sourceFile3 = com.google.javascript.jscomp.SourceFile.fromInputStream("Exceeded max number of code motion iterations: {0}", "33", inputStream2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        compiler1.disableThreads();
        com.google.javascript.jscomp.PerformanceTracker performanceTracker3 = compiler1.tracker;
        try {
            boolean boolean4 = compiler1.isIdeMode();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(performanceTracker3);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        com.google.javascript.jscomp.SourceMap.DetailLevel detailLevel0 = com.google.javascript.jscomp.SourceMap.DetailLevel.ALL;
        org.junit.Assert.assertNotNull(detailLevel0);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        com.google.javascript.rhino.Node node2 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node4 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node6 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node8 = new com.google.javascript.rhino.Node((int) '4');
        node6.addChildrenToBack(node8);
        node2.addChildAfter(node4, node8);
        com.google.javascript.rhino.Node node12 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node14 = new com.google.javascript.rhino.Node((int) '4');
        node12.addChildrenToBack(node14);
        com.google.javascript.rhino.Node node16 = node2.copyInformationFromForTree(node14);
        com.google.javascript.rhino.Node node17 = node2.cloneTree();
        try {
            java.lang.String str18 = com.google.javascript.rhino.ScriptRuntime.getMessage1("(// Input %num%)", (java.lang.Object) node17);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property (// Input %num%)");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertNotNull(node17);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        com.google.javascript.rhino.Node node1 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node3 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node5 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node7 = new com.google.javascript.rhino.Node((int) '4');
        node5.addChildrenToBack(node7);
        node1.addChildAfter(node3, node7);
        com.google.javascript.rhino.Node node10 = node7.getParent();
        com.google.javascript.rhino.jstype.JSType jSType11 = null;
        node10.setJSType(jSType11);
        com.google.javascript.rhino.Node node13 = node10.cloneNode();
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(node13);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        int int0 = com.google.javascript.rhino.Node.COLUMN_BITS;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 12 + "'", int0 == 12);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setLooseTypes(true);
        boolean boolean3 = compilerOptions0.reserveRawExports;
        boolean boolean4 = compilerOptions0.flowSensitiveInlineVariables;
        compilerOptions0.rewriteFunctionExpressions = true;
        compilerOptions0.setRemoveClosureAsserts(true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        com.google.javascript.jscomp.SourceAst sourceAst0 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(sourceAst0, "", false);
        boolean boolean4 = compilerInput3.isExtern();
        java.lang.String str5 = compilerInput3.getName();
        try {
            java.util.Collection<java.lang.String> strCollection6 = compilerInput3.getRequires();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Expected setErrorManager to be called first");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        com.google.javascript.jscomp.DiagnosticType diagnosticType0 = com.google.javascript.jscomp.Compiler.MOTION_ITERATIONS_ERROR;
        java.text.MessageFormat messageFormat1 = diagnosticType0.format;
        java.lang.String str2 = diagnosticType0.toString();
        org.junit.Assert.assertNotNull(diagnosticType0);
        org.junit.Assert.assertNotNull(messageFormat1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}" + "'", str2.equals("JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}"));
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setLooseTypes(true);
        compilerOptions0.checkSuspiciousCode = false;
        compilerOptions0.disambiguateProperties = true;
        java.util.Map<java.lang.String, com.google.javascript.rhino.Node> strMap7 = compilerOptions0.getDefineReplacements();
        com.google.javascript.jscomp.CheckLevel checkLevel8 = null;
        compilerOptions0.checkProvides = checkLevel8;
        compilerOptions0.removeUnusedVars = true;
        org.junit.Assert.assertNotNull(strMap7);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        com.google.javascript.rhino.Node node1 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node3 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node5 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node7 = new com.google.javascript.rhino.Node((int) '4');
        node5.addChildrenToBack(node7);
        node1.addChildAfter(node3, node7);
        com.google.javascript.rhino.Node node11 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node((int) '4');
        node11.addChildrenToBack(node13);
        com.google.javascript.rhino.Node node15 = node1.copyInformationFromForTree(node13);
        com.google.javascript.rhino.Node node17 = node1.getAncestor(1);
        com.google.javascript.rhino.Node node19 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node21 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node23 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node25 = new com.google.javascript.rhino.Node((int) '4');
        node23.addChildrenToBack(node25);
        node19.addChildAfter(node21, node25);
        com.google.javascript.rhino.Node node29 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node31 = new com.google.javascript.rhino.Node((int) '4');
        node29.addChildrenToBack(node31);
        com.google.javascript.rhino.Node node33 = node19.copyInformationFromForTree(node31);
        com.google.javascript.rhino.Node node35 = node19.getAncestor(1);
        node1.addChildToFront(node19);
        try {
            node1.setSideEffectFlags(42);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: setIsNoSideEffectsCall only supports CALL and NEW nodes, got INSTANCEOF");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertNull(node17);
        org.junit.Assert.assertNotNull(node33);
        org.junit.Assert.assertNull(node35);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        int int0 = com.google.javascript.rhino.Node.LOCAL_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 7 + "'", int0 == 7);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        com.google.javascript.rhino.Node node3 = new com.google.javascript.rhino.Node((int) (short) 1);
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newString("hi!");
        int int6 = node5.getCharno();
        com.google.javascript.rhino.Node node8 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node10 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node12 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node14 = new com.google.javascript.rhino.Node((int) '4');
        node12.addChildrenToBack(node14);
        node8.addChildAfter(node10, node14);
        com.google.javascript.rhino.Node node18 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node20 = new com.google.javascript.rhino.Node((int) '4');
        node18.addChildrenToBack(node20);
        com.google.javascript.rhino.Node node22 = node8.copyInformationFromForTree(node20);
        com.google.javascript.rhino.Node node23 = node8.cloneTree();
        com.google.javascript.rhino.Node node24 = node8.cloneTree();
        com.google.javascript.rhino.Node node26 = new com.google.javascript.rhino.Node((int) '4');
        node26.setLineno(36);
        com.google.javascript.rhino.Node[] nodeArray29 = new com.google.javascript.rhino.Node[] { node3, node5, node24, node26 };
        com.google.javascript.rhino.Node node32 = new com.google.javascript.rhino.Node(0, nodeArray29, 25, 14);
        try {
            com.google.javascript.rhino.Node node33 = new com.google.javascript.rhino.Node(0, nodeArray29);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: duplicate child");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertNotNull(nodeArray29);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        com.google.javascript.rhino.Node node3 = new com.google.javascript.rhino.Node(30, 35, 8);
        com.google.javascript.rhino.Node node4 = node3.getLastChild();
        try {
            com.google.javascript.rhino.Node node5 = node4.getNext();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(node4);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        java.io.PrintStream printStream2 = null;
        com.google.javascript.jscomp.Compiler compiler3 = new com.google.javascript.jscomp.Compiler(printStream2);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile6 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        java.io.Reader reader7 = jSSourceFile6.getCodeReader();
        com.google.javascript.jscomp.JSModule[] jSModuleArray8 = new com.google.javascript.jscomp.JSModule[] {};
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph9 = new com.google.javascript.jscomp.JSModuleGraph(jSModuleArray8);
        com.google.javascript.jscomp.CompilerOptions compilerOptions10 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions10.setLooseTypes(true);
        boolean boolean13 = compilerOptions10.collapseVariableDeclarations;
        compilerOptions10.moveFunctionDeclarations = false;
        boolean boolean16 = compilerOptions10.decomposeExpressions;
        com.google.javascript.jscomp.CheckLevel checkLevel17 = compilerOptions10.checkMissingGetCssNameLevel;
        com.google.javascript.jscomp.Result result18 = compiler3.compile(jSSourceFile6, jSModuleArray8, compilerOptions10);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile21 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile24 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        java.io.Reader reader25 = jSSourceFile24.getCodeReader();
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray26 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile6, jSSourceFile21, jSSourceFile24 };
        java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList27 = new java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile>();
        boolean boolean28 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList27, jSSourceFileArray26);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile31 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray32 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile31 };
        java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList33 = new java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile>();
        boolean boolean34 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList33, jSSourceFileArray32);
        com.google.javascript.jscomp.CompilerOptions compilerOptions35 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions35.setLooseTypes(true);
        boolean boolean38 = compilerOptions35.reserveRawExports;
        compilerOptions35.extractPrototypeMemberDeclarations = false;
        java.lang.String str41 = compilerOptions35.nameReferenceGraphPath;
        compilerOptions35.setSummaryDetailLevel(0);
        com.google.javascript.jscomp.Result result44 = compiler1.compile((java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList27, (java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList33, compilerOptions35);
        java.lang.String str45 = compilerOptions35.checkMissingGetCssNameBlacklist;
        compilerOptions35.crossModuleCodeMotion = true;
        compilerOptions35.setTweakToNumberLiteral("33", (int) (short) 100);
        org.junit.Assert.assertNotNull(jSSourceFile6);
        org.junit.Assert.assertNotNull(reader7);
        org.junit.Assert.assertNotNull(jSModuleArray8);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + checkLevel17 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel17.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(result18);
        org.junit.Assert.assertNotNull(jSSourceFile21);
        org.junit.Assert.assertNotNull(jSSourceFile24);
        org.junit.Assert.assertNotNull(reader25);
        org.junit.Assert.assertNotNull(jSSourceFileArray26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(jSSourceFile31);
        org.junit.Assert.assertNotNull(jSSourceFileArray32);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNull(str41);
        org.junit.Assert.assertNotNull(result44);
        org.junit.Assert.assertNull(str45);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        int int0 = com.google.javascript.rhino.Context.FEATURE_LOCATION_INFORMATION_IN_ERROR;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        int int0 = com.google.javascript.rhino.Node.SPECIALCALL_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 27 + "'", int0 == 27);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        com.google.javascript.jscomp.SourceAst sourceAst0 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(sourceAst0, "", false);
        com.google.javascript.jscomp.JSModule jSModule4 = compilerInput3.getModule();
        try {
            com.google.javascript.jscomp.Region region6 = compilerInput3.getRegion((int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(jSModule4);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setLooseTypes(true);
        boolean boolean3 = compilerOptions0.collapseVariableDeclarations;
        java.lang.String str4 = compilerOptions0.syntheticBlockStartMarker;
        java.lang.String str5 = com.google.javascript.rhino.ScriptRuntime.toString((java.lang.Object) str4);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "null" + "'", str5.equals("null"));
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        try {
            com.google.javascript.rhino.EcmaError ecmaError1 = com.google.javascript.rhino.ScriptRuntime.typeError0("Not declared as a type name");
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property Not declared as a type name");
        } catch (java.lang.RuntimeException e) {
        }
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        com.google.javascript.rhino.Node node1 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node3 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node5 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node7 = new com.google.javascript.rhino.Node((int) '4');
        node5.addChildrenToBack(node7);
        node1.addChildAfter(node3, node7);
        com.google.javascript.rhino.Node node11 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node((int) '4');
        node11.addChildrenToBack(node13);
        com.google.javascript.rhino.Node node15 = node1.copyInformationFromForTree(node13);
        com.google.javascript.rhino.Node node16 = node1.cloneTree();
        com.google.javascript.rhino.Node node20 = new com.google.javascript.rhino.Node(30, 35, 8);
        com.google.javascript.rhino.Node node21 = node20.getLastChild();
        node16.addChildToFront(node20);
        java.util.Collection<com.google.javascript.rhino.Node> nodeCollection23 = com.google.javascript.jscomp.NodeUtil.getVarsDeclaredInBranch(node16);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertNull(node21);
        org.junit.Assert.assertNotNull(nodeCollection23);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setLooseTypes(true);
        compilerOptions0.convertToDottedProperties = false;
        com.google.javascript.jscomp.CheckLevel checkLevel5 = compilerOptions0.reportMissingOverride;
        boolean boolean6 = compilerOptions0.aliasAllStrings;
        compilerOptions0.instrumentationTemplate = "hi!";
        boolean boolean9 = compilerOptions0.exportTestFunctions;
        java.lang.RuntimeException runtimeException10 = com.google.javascript.rhino.ScriptRuntime.notFunctionError((java.lang.Object) compilerOptions0);
        org.junit.Assert.assertTrue("'" + checkLevel5 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel5.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(runtimeException10);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        com.google.javascript.jscomp.AnonymousFunctionNamingPolicy anonymousFunctionNamingPolicy0 = com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.MAPPED;
        org.junit.Assert.assertTrue("'" + anonymousFunctionNamingPolicy0 + "' != '" + com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.MAPPED + "'", anonymousFunctionNamingPolicy0.equals(com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.MAPPED));
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setLooseTypes(true);
        compilerOptions0.convertToDottedProperties = false;
        com.google.javascript.jscomp.CheckLevel checkLevel5 = compilerOptions0.reportUnknownTypes;
        boolean boolean6 = compilerOptions0.optimizeReturns;
        compilerOptions0.convertToDottedProperties = true;
        compilerOptions0.syntheticBlockStartMarker = "(): error reporter";
        org.junit.Assert.assertTrue("'" + checkLevel5 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel5.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        java.util.logging.Logger logger0 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager1 = new com.google.javascript.jscomp.LoggerErrorManager(logger0);
        com.google.javascript.jscomp.CompilerOptions compilerOptions2 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions2.setLooseTypes(true);
        compilerOptions2.convertToDottedProperties = false;
        com.google.javascript.jscomp.CheckLevel checkLevel7 = compilerOptions2.reportUnknownTypes;
        com.google.javascript.rhino.Node node10 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node12 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node14 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node16 = new com.google.javascript.rhino.Node((int) '4');
        node14.addChildrenToBack(node16);
        node10.addChildAfter(node12, node16);
        com.google.javascript.rhino.Node node20 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node22 = new com.google.javascript.rhino.Node((int) '4');
        node20.addChildrenToBack(node22);
        com.google.javascript.rhino.Node node24 = node10.copyInformationFromForTree(node22);
        com.google.javascript.jscomp.DiagnosticType diagnosticType25 = com.google.javascript.jscomp.Compiler.MOTION_ITERATIONS_ERROR;
        java.lang.String str26 = diagnosticType25.toString();
        java.lang.String[] strArray27 = null;
        com.google.javascript.jscomp.JSError jSError28 = com.google.javascript.jscomp.JSError.make("", node22, diagnosticType25, strArray27);
        java.lang.String str29 = jSError28.toString();
        loggerErrorManager1.report(checkLevel7, jSError28);
        com.google.javascript.jscomp.JSError[] jSErrorArray31 = loggerErrorManager1.getWarnings();
        org.junit.Assert.assertTrue("'" + checkLevel7 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel7.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertNotNull(diagnosticType25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}" + "'", str26.equals("JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}"));
        org.junit.Assert.assertNotNull(jSError28);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "JSC_OPTIMIZE_LOOP_ERROR. Exceeded max number of code motion iterations: {0} at (unknown source) line (unknown line) : (unknown column)" + "'", str29.equals("JSC_OPTIMIZE_LOOP_ERROR. Exceeded max number of code motion iterations: {0} at (unknown source) line (unknown line) : (unknown column)"));
        org.junit.Assert.assertNotNull(jSErrorArray31);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.flowSensitiveInlineVariables = false;
        boolean boolean3 = compilerOptions0.lineBreak;
        java.lang.String str4 = compilerOptions0.aliasableGlobals;
        com.google.javascript.jscomp.CompilerOptions.TracerMode tracerMode5 = com.google.javascript.jscomp.CompilerOptions.TracerMode.FAST;
        compilerOptions0.tracer = tracerMode5;
        compilerOptions0.moveFunctionDeclarations = false;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + tracerMode5 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TracerMode.FAST + "'", tracerMode5.equals(com.google.javascript.jscomp.CompilerOptions.TracerMode.FAST));
    }

//    @Test
//    public void test268() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test268");
//        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.STRICT_MODULE_DEP_CHECK;
//        com.google.javascript.jscomp.DiagnosticGroups.MISSING_PROPERTIES = diagnosticGroup0;
//        com.google.javascript.jscomp.DiagnosticGroups.STRICT_MODULE_DEP_CHECK = diagnosticGroup0;
//        com.google.javascript.jscomp.DiagnosticGroups.CHECK_USELESS_CODE = diagnosticGroup0;
//        com.google.javascript.jscomp.DiagnosticGroups.TWEAKS = diagnosticGroup0;
//        org.junit.Assert.assertNotNull(diagnosticGroup0);
//    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        com.google.javascript.jscomp.SourceFile.Generator generator1 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("hi!: hi!", generator1);
        org.junit.Assert.assertNotNull(jSSourceFile2);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        int int0 = com.google.javascript.rhino.jstype.JSType.NOT_ENUMDECL;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setLooseTypes(true);
        boolean boolean3 = compilerOptions0.reserveRawExports;
        compilerOptions0.extractPrototypeMemberDeclarations = false;
        boolean boolean6 = compilerOptions0.disambiguateProperties;
        boolean boolean7 = compilerOptions0.rewriteFunctionExpressions;
        java.lang.String str8 = compilerOptions0.appNameStr;
        compilerOptions0.ideMode = false;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newString("hi!");
        boolean boolean2 = node1.isLocalResultCall();
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromCode("Named type with empty name component", "hi!");
        org.junit.Assert.assertNotNull(sourceFile2);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        com.google.javascript.rhino.Node node2 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node4 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node6 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node8 = new com.google.javascript.rhino.Node((int) '4');
        node6.addChildrenToBack(node8);
        node2.addChildAfter(node4, node8);
        com.google.javascript.rhino.Node node12 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node14 = new com.google.javascript.rhino.Node((int) '4');
        node12.addChildrenToBack(node14);
        com.google.javascript.rhino.Node node16 = node2.copyInformationFromForTree(node14);
        com.google.javascript.jscomp.DiagnosticType diagnosticType17 = com.google.javascript.jscomp.Compiler.MOTION_ITERATIONS_ERROR;
        java.lang.String str18 = diagnosticType17.toString();
        java.lang.String[] strArray19 = null;
        com.google.javascript.jscomp.JSError jSError20 = com.google.javascript.jscomp.JSError.make("", node14, diagnosticType17, strArray19);
        java.lang.String str21 = jSError20.description;
        java.lang.String str22 = jSError20.toString();
        java.lang.String str23 = jSError20.description;
        java.lang.String str24 = jSError20.description;
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertNotNull(diagnosticType17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}" + "'", str18.equals("JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}"));
        org.junit.Assert.assertNotNull(jSError20);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "Exceeded max number of code motion iterations: {0}" + "'", str21.equals("Exceeded max number of code motion iterations: {0}"));
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "JSC_OPTIMIZE_LOOP_ERROR. Exceeded max number of code motion iterations: {0} at (unknown source) line (unknown line) : (unknown column)" + "'", str22.equals("JSC_OPTIMIZE_LOOP_ERROR. Exceeded max number of code motion iterations: {0} at (unknown source) line (unknown line) : (unknown column)"));
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "Exceeded max number of code motion iterations: {0}" + "'", str23.equals("Exceeded max number of code motion iterations: {0}"));
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "Exceeded max number of code motion iterations: {0}" + "'", str24.equals("Exceeded max number of code motion iterations: {0}"));
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setLooseTypes(true);
        boolean boolean3 = compilerOptions0.reserveRawExports;
        compilerOptions0.extractPrototypeMemberDeclarations = false;
        boolean boolean6 = compilerOptions0.disambiguateProperties;
        com.google.javascript.jscomp.CheckLevel checkLevel7 = compilerOptions0.aggressiveVarCheck;
        compilerOptions0.setColorizeErrorOutput(true);
        java.lang.String str10 = compilerOptions0.nameReferenceGraphPath;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + checkLevel7 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel7.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNull(str10);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        com.google.javascript.rhino.Context context0 = new com.google.javascript.rhino.Context();
        context0.setGeneratingSource(true);
        java.lang.Object obj3 = context0.getDebuggerContextData();
        com.google.javascript.rhino.EcmaError ecmaError5 = com.google.javascript.rhino.ScriptRuntime.typeError("4");
        java.lang.String str6 = ecmaError5.getName();
        java.lang.String str7 = ecmaError5.lineSource();
        java.lang.String str8 = ecmaError5.toString();
        java.lang.String str9 = ecmaError5.lineSource();
        ecmaError5.initLineSource("com.google.javascript.rhino.EcmaError: TypeError: 4");
        context0.removeThreadLocal((java.lang.Object) ecmaError5);
        com.google.javascript.rhino.ErrorReporter errorReporter13 = null;
        try {
            com.google.javascript.rhino.ErrorReporter errorReporter14 = context0.setErrorReporter(errorReporter13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(obj3);
        org.junit.Assert.assertNotNull(ecmaError5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "TypeError" + "'", str6.equals("TypeError"));
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "com.google.javascript.rhino.EcmaError: TypeError: 4" + "'", str8.equals("com.google.javascript.rhino.EcmaError: TypeError: 4"));
        org.junit.Assert.assertNull(str9);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setLooseTypes(true);
        boolean boolean3 = compilerOptions0.reserveRawExports;
        com.google.javascript.jscomp.CheckLevel checkLevel4 = null;
        compilerOptions0.checkUnreachableCode = checkLevel4;
        boolean boolean6 = compilerOptions0.devirtualizePrototypeMethods;
        compilerOptions0.enableRuntimeTypeCheck("hi!: hi!");
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy0 = com.google.javascript.jscomp.VariableRenamingPolicy.ALL;
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy0 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.ALL + "'", variableRenamingPolicy0.equals(com.google.javascript.jscomp.VariableRenamingPolicy.ALL));
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        boolean boolean1 = com.google.javascript.rhino.Context.isValidOptimizationLevel((int) (short) -1);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        com.google.javascript.rhino.Node node1 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node3 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node5 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node7 = new com.google.javascript.rhino.Node((int) '4');
        node5.addChildrenToBack(node7);
        node1.addChildAfter(node3, node7);
        com.google.javascript.rhino.Node node11 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node((int) '4');
        node11.addChildrenToBack(node13);
        com.google.javascript.rhino.Node node15 = node1.copyInformationFromForTree(node13);
        com.google.javascript.rhino.Node node17 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node18 = node1.copyInformationFromForTree(node17);
        com.google.javascript.rhino.JSDocInfo jSDocInfo19 = null;
        node17.setJSDocInfo(jSDocInfo19);
        try {
            node17.setSideEffectFlags(49);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: setIsNoSideEffectsCall only supports CALL and NEW nodes, got INSTANCEOF");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertNotNull(node18);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setLooseTypes(true);
        boolean boolean3 = compilerOptions0.reserveRawExports;
        compilerOptions0.extractPrototypeMemberDeclarations = false;
        boolean boolean6 = compilerOptions0.disambiguateProperties;
        boolean boolean7 = compilerOptions0.rewriteFunctionExpressions;
        java.lang.String str8 = compilerOptions0.appNameStr;
        com.google.javascript.jscomp.CheckLevel checkLevel9 = compilerOptions0.aggressiveVarCheck;
        boolean boolean10 = compilerOptions0.printInputDelimiter;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + checkLevel9 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel9.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setLooseTypes(true);
        boolean boolean3 = compilerOptions0.collapseVariableDeclarations;
        compilerOptions0.moveFunctionDeclarations = false;
        boolean boolean6 = compilerOptions0.decomposeExpressions;
        boolean boolean7 = compilerOptions0.optimizeParameters;
        java.lang.String str8 = compilerOptions0.inputDelimiter;
        java.lang.String[] strArray10 = new java.lang.String[] { "hi!" };
        java.util.LinkedHashSet<java.lang.String> strSet11 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean12 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet11, strArray10);
        compilerOptions0.stripTypes = strSet11;
        compilerOptions0.markNoSideEffectCalls = false;
        boolean boolean16 = compilerOptions0.checkDuplicateMessages;
        boolean boolean17 = compilerOptions0.optimizeCalls;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "// Input %num%" + "'", str8.equals("// Input %num%"));
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setLooseTypes(true);
        boolean boolean3 = compilerOptions0.reserveRawExports;
        compilerOptions0.extractPrototypeMemberDeclarations = false;
        java.lang.String str6 = compilerOptions0.nameReferenceGraphPath;
        boolean boolean7 = compilerOptions0.markNoSideEffectCalls;
        boolean boolean8 = compilerOptions0.generateExports;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = null;
        com.google.javascript.jscomp.DiagnosticGroups.FILEOVERVIEW_JSDOC = diagnosticGroup0;
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        com.google.javascript.jscomp.SourceAst sourceAst0 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(sourceAst0, "", false);
        com.google.javascript.jscomp.JSModule jSModule4 = compilerInput3.getModule();
        try {
            java.lang.String str6 = compilerInput3.getLine(7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(jSModule4);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        boolean boolean1 = com.google.javascript.rhino.ScriptRuntime.isJSLineTerminator((int) 'a');
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.flowSensitiveInlineVariables = false;
        boolean boolean3 = compilerOptions0.lineBreak;
        boolean boolean4 = compilerOptions0.checkSuspiciousCode;
        compilerOptions0.disableRuntimeTypeCheck();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        compiler1.disableThreads();
        com.google.javascript.jscomp.PerformanceTracker performanceTracker3 = compiler1.tracker;
        try {
            compiler1.processDefines();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(performanceTracker3);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile4 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        java.io.Reader reader5 = jSSourceFile4.getCodeReader();
        com.google.javascript.jscomp.JSModule[] jSModuleArray6 = new com.google.javascript.jscomp.JSModule[] {};
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph7 = new com.google.javascript.jscomp.JSModuleGraph(jSModuleArray6);
        com.google.javascript.jscomp.CompilerOptions compilerOptions8 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions8.setLooseTypes(true);
        boolean boolean11 = compilerOptions8.collapseVariableDeclarations;
        compilerOptions8.moveFunctionDeclarations = false;
        boolean boolean14 = compilerOptions8.decomposeExpressions;
        com.google.javascript.jscomp.CheckLevel checkLevel15 = compilerOptions8.checkMissingGetCssNameLevel;
        com.google.javascript.jscomp.Result result16 = compiler1.compile(jSSourceFile4, jSModuleArray6, compilerOptions8);
        com.google.javascript.jscomp.Result result17 = compiler1.getResult();
        boolean boolean18 = compiler1.hasErrors();
        com.google.javascript.jscomp.SourceFile.Generator generator20 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile21 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("JSC_OPTIMIZE_LOOP_ERROR. Exceeded max number of code motion iterations: {0} at (unknown source) line (unknown line) : (unknown column)", generator20);
        com.google.javascript.jscomp.SourceFile.Generator generator23 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile24 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("JSC_OPTIMIZE_LOOP_ERROR. Exceeded max number of code motion iterations: {0} at (unknown source) line (unknown line) : (unknown column)", generator23);
        com.google.javascript.jscomp.CompilerOptions compilerOptions25 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions25.setLooseTypes(true);
        boolean boolean28 = compilerOptions25.reserveRawExports;
        compilerOptions25.extractPrototypeMemberDeclarations = false;
        java.lang.String str31 = compilerOptions25.nameReferenceGraphPath;
        compilerOptions25.computeFunctionSideEffects = true;
        com.google.javascript.jscomp.CompilerOptions compilerOptions34 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions34.setLooseTypes(true);
        compilerOptions34.convertToDottedProperties = false;
        com.google.javascript.jscomp.CheckLevel checkLevel39 = compilerOptions34.reportMissingOverride;
        compilerOptions25.brokenClosureRequiresLevel = checkLevel39;
        java.util.Set<java.lang.String> strSet41 = compilerOptions25.stripTypePrefixes;
        compilerOptions25.optimizeReturns = true;
        com.google.javascript.jscomp.Result result44 = compiler1.compile(jSSourceFile21, jSSourceFile24, compilerOptions25);
        java.lang.String str45 = jSSourceFile21.toString();
        org.junit.Assert.assertNotNull(jSSourceFile4);
        org.junit.Assert.assertNotNull(reader5);
        org.junit.Assert.assertNotNull(jSModuleArray6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + checkLevel15 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel15.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(result16);
        org.junit.Assert.assertNotNull(result17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(jSSourceFile21);
        org.junit.Assert.assertNotNull(jSSourceFile24);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNull(str31);
        org.junit.Assert.assertTrue("'" + checkLevel39 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel39.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(strSet41);
        org.junit.Assert.assertNotNull(result44);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "JSC_OPTIMIZE_LOOP_ERROR. Exceeded max number of code motion iterations: {0} at (unknown source) line (unknown line) : (unknown column)" + "'", str45.equals("JSC_OPTIMIZE_LOOP_ERROR. Exceeded max number of code motion iterations: {0} at (unknown source) line (unknown line) : (unknown column)"));
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        com.google.javascript.rhino.Node node1 = null;
        try {
            com.google.javascript.rhino.Node node2 = new com.google.javascript.rhino.Node(0, node1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setLooseTypes(true);
        boolean boolean3 = compilerOptions0.collapseVariableDeclarations;
        compilerOptions0.moveFunctionDeclarations = false;
        boolean boolean6 = compilerOptions0.decomposeExpressions;
        com.google.javascript.jscomp.CheckLevel checkLevel7 = compilerOptions0.checkMissingGetCssNameLevel;
        compilerOptions0.removeUnusedPrototypePropertiesInExterns = false;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + checkLevel7 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel7.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        com.google.javascript.rhino.EcmaError ecmaError1 = com.google.javascript.rhino.ScriptRuntime.typeError("(// Input %num%)");
        org.junit.Assert.assertNotNull(ecmaError1);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        compiler1.disableThreads();
        com.google.javascript.jscomp.Compiler.IntermediateState intermediateState3 = compiler1.getState();
        com.google.javascript.rhino.Node node4 = compiler1.getRoot();
        org.junit.Assert.assertNotNull(intermediateState3);
        org.junit.Assert.assertNull(node4);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setLooseTypes(true);
        boolean boolean3 = compilerOptions0.reserveRawExports;
        compilerOptions0.extractPrototypeMemberDeclarations = false;
        java.lang.String str6 = compilerOptions0.nameReferenceGraphPath;
        compilerOptions0.nameReferenceReportPath = "33";
        com.google.javascript.jscomp.CompilerOptions compilerOptions9 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions9.setLooseTypes(true);
        boolean boolean12 = compilerOptions9.reserveRawExports;
        compilerOptions9.extractPrototypeMemberDeclarations = false;
        boolean boolean15 = compilerOptions9.disambiguateProperties;
        boolean boolean16 = compilerOptions9.rewriteFunctionExpressions;
        java.lang.String str17 = compilerOptions9.appNameStr;
        com.google.javascript.jscomp.CheckLevel checkLevel18 = compilerOptions9.aggressiveVarCheck;
        compilerOptions0.checkMethods = checkLevel18;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
        org.junit.Assert.assertTrue("'" + checkLevel18 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel18.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setLooseTypes(true);
        boolean boolean3 = compilerOptions0.reserveRawExports;
        com.google.javascript.jscomp.CheckLevel checkLevel4 = null;
        compilerOptions0.checkUnreachableCode = checkLevel4;
        com.google.javascript.jscomp.CheckLevel checkLevel6 = compilerOptions0.reportUnknownTypes;
        boolean boolean7 = compilerOptions0.shouldColorizeErrorOutput();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + checkLevel6 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel6.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        com.google.javascript.jscomp.SourceAst sourceAst0 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(sourceAst0, "", false);
        boolean boolean4 = compilerInput3.isExtern();
        java.lang.String str5 = compilerInput3.getName();
        boolean boolean6 = compilerInput3.isExtern();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeUnusedPrototypePropertiesInExterns = false;
        boolean boolean3 = compilerOptions0.markAsCompiled;
        compilerOptions0.setDefineToBooleanLiteral("", true);
        boolean boolean7 = compilerOptions0.optimizeReturns;
        compilerOptions0.enableExternExports(true);
        boolean boolean10 = compilerOptions0.inlineLocalVariables;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setLooseTypes(true);
        boolean boolean3 = compilerOptions0.reserveRawExports;
        compilerOptions0.extractPrototypeMemberDeclarations = false;
        java.lang.String str6 = compilerOptions0.nameReferenceGraphPath;
        compilerOptions0.computeFunctionSideEffects = true;
        com.google.javascript.jscomp.CompilerOptions compilerOptions9 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions9.setLooseTypes(true);
        compilerOptions9.convertToDottedProperties = false;
        com.google.javascript.jscomp.CheckLevel checkLevel14 = compilerOptions9.reportMissingOverride;
        compilerOptions0.brokenClosureRequiresLevel = checkLevel14;
        java.util.Set<java.lang.String> strSet16 = compilerOptions0.stripTypePrefixes;
        compilerOptions0.optimizeReturns = true;
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention19 = new com.google.javascript.jscomp.DefaultCodingConvention();
        boolean boolean21 = defaultCodingConvention19.isConstant("hi!");
        java.lang.String str22 = defaultCodingConvention19.getExportSymbolFunction();
        compilerOptions0.setCodingConvention((com.google.javascript.jscomp.CodingConvention) defaultCodingConvention19);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + checkLevel14 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel14.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(strSet16);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNull(str22);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setLooseTypes(true);
        boolean boolean3 = compilerOptions0.reserveRawExports;
        compilerOptions0.extractPrototypeMemberDeclarations = false;
        boolean boolean6 = compilerOptions0.disambiguateProperties;
        com.google.javascript.jscomp.CheckLevel checkLevel7 = compilerOptions0.aggressiveVarCheck;
        compilerOptions0.decomposeExpressions = false;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + checkLevel7 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel7.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setLooseTypes(true);
        boolean boolean3 = compilerOptions0.collapseVariableDeclarations;
        compilerOptions0.aliasExternals = true;
        com.google.javascript.jscomp.CheckLevel checkLevel6 = compilerOptions0.reportMissingOverride;
        compilerOptions0.lineBreak = false;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + checkLevel6 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel6.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        com.google.javascript.jscomp.DiagnosticType[] diagnosticTypeArray0 = new com.google.javascript.jscomp.DiagnosticType[] {};
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup1 = new com.google.javascript.jscomp.DiagnosticGroup(diagnosticTypeArray0);
        com.google.javascript.jscomp.DiagnosticGroups.STRICT_MODULE_DEP_CHECK = diagnosticGroup1;
        org.junit.Assert.assertNotNull(diagnosticTypeArray0);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setLooseTypes(true);
        compilerOptions0.renamePrefix = "hi!";
        compilerOptions0.setRemoveClosureAsserts(true);
        compilerOptions0.syntheticBlockEndMarker = "hi!";
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setLooseTypes(true);
        boolean boolean3 = compilerOptions0.reserveRawExports;
        com.google.javascript.jscomp.CheckLevel checkLevel4 = null;
        compilerOptions0.checkUnreachableCode = checkLevel4;
        com.google.javascript.jscomp.MessageBundle messageBundle6 = compilerOptions0.messageBundle;
        java.lang.String str7 = compilerOptions0.sourceMapOutputPath;
        compilerOptions0.aliasKeywords = true;
        boolean boolean10 = compilerOptions0.checkUnusedPropertiesEarly;
        boolean boolean11 = compilerOptions0.checkDuplicateMessages;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(messageBundle6);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        compiler1.disableThreads();
        com.google.javascript.jscomp.PerformanceTracker performanceTracker3 = compiler1.tracker;
        com.google.javascript.jscomp.NodeTraversal.Callback callback4 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal5 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler1, callback4);
        java.io.PrintStream printStream6 = null;
        com.google.javascript.jscomp.Compiler compiler7 = new com.google.javascript.jscomp.Compiler(printStream6);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile10 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        java.io.Reader reader11 = jSSourceFile10.getCodeReader();
        com.google.javascript.jscomp.JSModule[] jSModuleArray12 = new com.google.javascript.jscomp.JSModule[] {};
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph13 = new com.google.javascript.jscomp.JSModuleGraph(jSModuleArray12);
        com.google.javascript.jscomp.CompilerOptions compilerOptions14 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions14.setLooseTypes(true);
        boolean boolean17 = compilerOptions14.collapseVariableDeclarations;
        compilerOptions14.moveFunctionDeclarations = false;
        boolean boolean20 = compilerOptions14.decomposeExpressions;
        com.google.javascript.jscomp.CheckLevel checkLevel21 = compilerOptions14.checkMissingGetCssNameLevel;
        com.google.javascript.jscomp.Result result22 = compiler7.compile(jSSourceFile10, jSModuleArray12, compilerOptions14);
        java.io.PrintStream printStream23 = null;
        com.google.javascript.jscomp.Compiler compiler24 = new com.google.javascript.jscomp.Compiler(printStream23);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile27 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        java.io.Reader reader28 = jSSourceFile27.getCodeReader();
        com.google.javascript.jscomp.JSModule[] jSModuleArray29 = new com.google.javascript.jscomp.JSModule[] {};
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph30 = new com.google.javascript.jscomp.JSModuleGraph(jSModuleArray29);
        com.google.javascript.jscomp.CompilerOptions compilerOptions31 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions31.setLooseTypes(true);
        boolean boolean34 = compilerOptions31.collapseVariableDeclarations;
        compilerOptions31.moveFunctionDeclarations = false;
        boolean boolean37 = compilerOptions31.decomposeExpressions;
        com.google.javascript.jscomp.CheckLevel checkLevel38 = compilerOptions31.checkMissingGetCssNameLevel;
        com.google.javascript.jscomp.Result result39 = compiler24.compile(jSSourceFile27, jSModuleArray29, compilerOptions31);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile42 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        java.io.PrintStream printStream43 = null;
        com.google.javascript.jscomp.Compiler compiler44 = new com.google.javascript.jscomp.Compiler(printStream43);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile47 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        java.io.Reader reader48 = jSSourceFile47.getCodeReader();
        com.google.javascript.jscomp.JSModule[] jSModuleArray49 = new com.google.javascript.jscomp.JSModule[] {};
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph50 = new com.google.javascript.jscomp.JSModuleGraph(jSModuleArray49);
        com.google.javascript.jscomp.CompilerOptions compilerOptions51 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions51.setLooseTypes(true);
        boolean boolean54 = compilerOptions51.collapseVariableDeclarations;
        compilerOptions51.moveFunctionDeclarations = false;
        boolean boolean57 = compilerOptions51.decomposeExpressions;
        com.google.javascript.jscomp.CheckLevel checkLevel58 = compilerOptions51.checkMissingGetCssNameLevel;
        com.google.javascript.jscomp.Result result59 = compiler44.compile(jSSourceFile47, jSModuleArray49, compilerOptions51);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile62 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile65 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        java.io.Reader reader66 = jSSourceFile65.getCodeReader();
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray67 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile10, jSSourceFile27, jSSourceFile42, jSSourceFile47, jSSourceFile62, jSSourceFile65 };
        java.io.PrintStream printStream68 = null;
        com.google.javascript.jscomp.Compiler compiler69 = new com.google.javascript.jscomp.Compiler(printStream68);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile72 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        java.io.Reader reader73 = jSSourceFile72.getCodeReader();
        com.google.javascript.jscomp.JSModule[] jSModuleArray74 = new com.google.javascript.jscomp.JSModule[] {};
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph75 = new com.google.javascript.jscomp.JSModuleGraph(jSModuleArray74);
        com.google.javascript.jscomp.CompilerOptions compilerOptions76 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions76.setLooseTypes(true);
        boolean boolean79 = compilerOptions76.collapseVariableDeclarations;
        compilerOptions76.moveFunctionDeclarations = false;
        boolean boolean82 = compilerOptions76.decomposeExpressions;
        com.google.javascript.jscomp.CheckLevel checkLevel83 = compilerOptions76.checkMissingGetCssNameLevel;
        com.google.javascript.jscomp.Result result84 = compiler69.compile(jSSourceFile72, jSModuleArray74, compilerOptions76);
        com.google.javascript.jscomp.CompilerOptions compilerOptions85 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions85.setLooseTypes(true);
        boolean boolean88 = compilerOptions85.collapseVariableDeclarations;
        compilerOptions85.setManageClosureDependencies(false);
        com.google.javascript.jscomp.Result result91 = compiler1.compile(jSSourceFileArray67, jSModuleArray74, compilerOptions85);
        compilerOptions85.debugFunctionSideEffectsPath = "Exceeded max number of code motion iterations: {0}";
        org.junit.Assert.assertNull(performanceTracker3);
        org.junit.Assert.assertNotNull(jSSourceFile10);
        org.junit.Assert.assertNotNull(reader11);
        org.junit.Assert.assertNotNull(jSModuleArray12);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + checkLevel21 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel21.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(result22);
        org.junit.Assert.assertNotNull(jSSourceFile27);
        org.junit.Assert.assertNotNull(reader28);
        org.junit.Assert.assertNotNull(jSModuleArray29);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + checkLevel38 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel38.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(result39);
        org.junit.Assert.assertNotNull(jSSourceFile42);
        org.junit.Assert.assertNotNull(jSSourceFile47);
        org.junit.Assert.assertNotNull(reader48);
        org.junit.Assert.assertNotNull(jSModuleArray49);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertTrue("'" + checkLevel58 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel58.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(result59);
        org.junit.Assert.assertNotNull(jSSourceFile62);
        org.junit.Assert.assertNotNull(jSSourceFile65);
        org.junit.Assert.assertNotNull(reader66);
        org.junit.Assert.assertNotNull(jSSourceFileArray67);
        org.junit.Assert.assertNotNull(jSSourceFile72);
        org.junit.Assert.assertNotNull(reader73);
        org.junit.Assert.assertNotNull(jSModuleArray74);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
        org.junit.Assert.assertTrue("'" + checkLevel83 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel83.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(result84);
        org.junit.Assert.assertTrue("'" + boolean88 + "' != '" + false + "'", boolean88 == false);
        org.junit.Assert.assertNotNull(result91);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile4 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        java.io.Reader reader5 = jSSourceFile4.getCodeReader();
        com.google.javascript.jscomp.JSModule[] jSModuleArray6 = new com.google.javascript.jscomp.JSModule[] {};
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph7 = new com.google.javascript.jscomp.JSModuleGraph(jSModuleArray6);
        com.google.javascript.jscomp.CompilerOptions compilerOptions8 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions8.setLooseTypes(true);
        boolean boolean11 = compilerOptions8.collapseVariableDeclarations;
        compilerOptions8.moveFunctionDeclarations = false;
        boolean boolean14 = compilerOptions8.decomposeExpressions;
        com.google.javascript.jscomp.CheckLevel checkLevel15 = compilerOptions8.checkMissingGetCssNameLevel;
        com.google.javascript.jscomp.Result result16 = compiler1.compile(jSSourceFile4, jSModuleArray6, compilerOptions8);
        com.google.javascript.jscomp.Result result17 = compiler1.getResult();
        boolean boolean18 = compiler1.hasErrors();
        com.google.javascript.rhino.Node node20 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node22 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node24 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node26 = new com.google.javascript.rhino.Node((int) '4');
        node24.addChildrenToBack(node26);
        node20.addChildAfter(node22, node26);
        com.google.javascript.rhino.Node node30 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node32 = new com.google.javascript.rhino.Node((int) '4');
        node30.addChildrenToBack(node32);
        com.google.javascript.rhino.Node node34 = node20.copyInformationFromForTree(node32);
        com.google.javascript.rhino.Node node36 = node20.getAncestor(1);
        com.google.javascript.rhino.Node node38 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node40 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node42 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node44 = new com.google.javascript.rhino.Node((int) '4');
        node42.addChildrenToBack(node44);
        node38.addChildAfter(node40, node44);
        com.google.javascript.rhino.Node node48 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node50 = new com.google.javascript.rhino.Node((int) '4');
        node48.addChildrenToBack(node50);
        com.google.javascript.rhino.Node node52 = node38.copyInformationFromForTree(node50);
        com.google.javascript.rhino.Node node54 = node38.getAncestor(1);
        node20.addChildToFront(node38);
        com.google.javascript.rhino.Node node56 = node20.getNext();
        com.google.javascript.rhino.Node node57 = node20.cloneTree();
        com.google.javascript.rhino.Node node59 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node61 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node63 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node65 = new com.google.javascript.rhino.Node((int) '4');
        node63.addChildrenToBack(node65);
        node59.addChildAfter(node61, node65);
        com.google.javascript.rhino.Node node69 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node71 = new com.google.javascript.rhino.Node((int) '4');
        node69.addChildrenToBack(node71);
        com.google.javascript.rhino.Node node73 = node59.copyInformationFromForTree(node71);
        com.google.javascript.rhino.Node node75 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node76 = node59.copyInformationFromForTree(node75);
        com.google.javascript.rhino.Node node77 = com.google.javascript.jscomp.NodeUtil.newExpr(node76);
        com.google.javascript.rhino.Node node78 = node20.copyInformationFrom(node77);
        com.google.javascript.jscomp.NodeTraversal.Callback callback79 = null;
        try {
            com.google.javascript.jscomp.NodeTraversal.traverse((com.google.javascript.jscomp.AbstractCompiler) compiler1, node78, callback79);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: INTERNAL COMPILER ERROR.\nPlease report this problem.\nnull");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile4);
        org.junit.Assert.assertNotNull(reader5);
        org.junit.Assert.assertNotNull(jSModuleArray6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + checkLevel15 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel15.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(result16);
        org.junit.Assert.assertNotNull(result17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(node34);
        org.junit.Assert.assertNull(node36);
        org.junit.Assert.assertNotNull(node52);
        org.junit.Assert.assertNull(node54);
        org.junit.Assert.assertNull(node56);
        org.junit.Assert.assertNotNull(node57);
        org.junit.Assert.assertNotNull(node73);
        org.junit.Assert.assertNotNull(node76);
        org.junit.Assert.assertNotNull(node77);
        org.junit.Assert.assertNotNull(node78);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setLooseTypes(true);
        boolean boolean3 = compilerOptions0.reserveRawExports;
        compilerOptions0.extractPrototypeMemberDeclarations = false;
        java.lang.String str6 = compilerOptions0.nameReferenceGraphPath;
        compilerOptions0.computeFunctionSideEffects = true;
        boolean boolean9 = compilerOptions0.smartNameRemoval;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        java.util.Collection<com.google.javascript.jscomp.CodingConvention.AssertionFunctionSpec> assertionFunctionSpecCollection1 = closureCodingConvention0.getAssertionFunctions();
        java.io.PrintStream printStream2 = null;
        com.google.javascript.jscomp.Compiler compiler3 = new com.google.javascript.jscomp.Compiler(printStream2);
        compiler3.disableThreads();
        com.google.javascript.jscomp.PerformanceTracker performanceTracker5 = compiler3.tracker;
        com.google.javascript.jscomp.NodeTraversal.Callback callback6 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal7 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler3, callback6);
        com.google.javascript.rhino.Node node9 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node11 = new com.google.javascript.rhino.Node((int) '4');
        node9.addChildrenToBack(node11);
        com.google.javascript.jscomp.DiagnosticType diagnosticType15 = com.google.javascript.jscomp.DiagnosticType.warning("hi!", "hi!");
        com.google.javascript.jscomp.DiagnosticType diagnosticType16 = com.google.javascript.jscomp.Compiler.MOTION_ITERATIONS_ERROR;
        int int17 = diagnosticType15.compareTo(diagnosticType16);
        java.lang.String[] strArray18 = com.google.javascript.rhino.ScriptRuntime.emptyStrings;
        com.google.javascript.jscomp.JSError jSError19 = nodeTraversal7.makeError(node11, diagnosticType15, strArray18);
        com.google.javascript.rhino.Node node21 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node23 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node25 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node27 = new com.google.javascript.rhino.Node((int) '4');
        node25.addChildrenToBack(node27);
        node21.addChildAfter(node23, node27);
        com.google.javascript.rhino.Node node31 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node33 = new com.google.javascript.rhino.Node((int) '4');
        node31.addChildrenToBack(node33);
        com.google.javascript.rhino.Node node35 = node21.copyInformationFromForTree(node33);
        com.google.javascript.rhino.Node node36 = node21.cloneTree();
        com.google.javascript.rhino.Node node38 = new com.google.javascript.rhino.Node((int) '4');
        node36.addChildrenToBack(node38);
        try {
            com.google.javascript.jscomp.CodingConvention.ObjectLiteralCast objectLiteralCast40 = closureCodingConvention0.getObjectLiteralCast(nodeTraversal7, node38);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(assertionFunctionSpecCollection1);
        org.junit.Assert.assertNull(performanceTracker5);
        org.junit.Assert.assertNotNull(diagnosticType15);
        org.junit.Assert.assertNotNull(diagnosticType16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 30 + "'", int17 == 30);
        org.junit.Assert.assertNotNull(strArray18);
        org.junit.Assert.assertNotNull(jSError19);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertNotNull(node36);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setLooseTypes(true);
        boolean boolean3 = compilerOptions0.reserveRawExports;
        com.google.javascript.jscomp.CheckLevel checkLevel4 = null;
        compilerOptions0.checkUnreachableCode = checkLevel4;
        com.google.javascript.jscomp.MessageBundle messageBundle6 = compilerOptions0.messageBundle;
        java.lang.String str7 = compilerOptions0.sourceMapOutputPath;
        compilerOptions0.enableExternExports(true);
        com.google.javascript.jscomp.CheckLevel checkLevel10 = compilerOptions0.reportUnknownTypes;
        compilerOptions0.setProcessObjectPropertyString(false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(messageBundle6);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + checkLevel10 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel10.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setLooseTypes(true);
        boolean boolean3 = compilerOptions0.collapseVariableDeclarations;
        compilerOptions0.moveFunctionDeclarations = false;
        compilerOptions0.setAcceptConstKeyword(false);
        boolean boolean8 = compilerOptions0.instrumentForCoverageOnly;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        com.google.javascript.rhino.EcmaError ecmaError2 = com.google.javascript.rhino.ScriptRuntime.constructError("language version", "// Input %num%");
        java.lang.String str3 = ecmaError2.getLineSource();
        org.junit.Assert.assertNotNull(ecmaError2);
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        com.google.javascript.rhino.Context context0 = new com.google.javascript.rhino.Context();
        int int1 = context0.getInstructionObserverThreshold();
        com.google.javascript.jscomp.CompilerOptions compilerOptions3 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions3.setLooseTypes(true);
        boolean boolean6 = compilerOptions3.collapseVariableDeclarations;
        compilerOptions3.moveFunctionDeclarations = false;
        boolean boolean9 = compilerOptions3.decomposeExpressions;
        boolean boolean10 = compilerOptions3.optimizeParameters;
        java.lang.String str11 = compilerOptions3.inputDelimiter;
        com.google.javascript.jscomp.ErrorFormat errorFormat12 = com.google.javascript.jscomp.ErrorFormat.LEGACY;
        java.lang.RuntimeException runtimeException13 = com.google.javascript.rhino.ScriptRuntime.undefWriteError((java.lang.Object) (short) 100, (java.lang.Object) str11, (java.lang.Object) errorFormat12);
        java.io.PrintStream printStream14 = null;
        com.google.javascript.jscomp.Compiler compiler15 = new com.google.javascript.jscomp.Compiler(printStream14);
        compiler15.disableThreads();
        com.google.javascript.jscomp.PerformanceTracker performanceTracker17 = compiler15.tracker;
        com.google.javascript.jscomp.MessageFormatter messageFormatter19 = errorFormat12.toFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler15, false);
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter20 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler15);
        java.util.logging.Logger logger21 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager22 = new com.google.javascript.jscomp.LoggerErrorManager((com.google.javascript.jscomp.MessageFormatter) lightweightMessageFormatter20, logger21);
        try {
            context0.unseal((java.lang.Object) lightweightMessageFormatter20);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "// Input %num%" + "'", str11.equals("// Input %num%"));
        org.junit.Assert.assertNotNull(errorFormat12);
        org.junit.Assert.assertNotNull(runtimeException13);
        org.junit.Assert.assertNull(performanceTracker17);
        org.junit.Assert.assertNotNull(messageFormatter19);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        com.google.javascript.rhino.Context context0 = new com.google.javascript.rhino.Context();
        context0.setCompileFunctionsWithDynamicScope(false);
        java.lang.Object obj3 = context0.getDebuggerContextData();
        context0.removeActivationName("false");
        org.junit.Assert.assertNull(obj3);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeUnusedPrototypePropertiesInExterns = false;
        compilerOptions0.removeUnusedLocalVars = false;
        compilerOptions0.ignoreCajaProperties = false;
        com.google.javascript.jscomp.CodingConvention codingConvention7 = compilerOptions0.getCodingConvention();
        compilerOptions0.setChainCalls(false);
        boolean boolean10 = compilerOptions0.checkSuspiciousCode;
        org.junit.Assert.assertNull(codingConvention7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromCode("hi!", "hi!");
        java.lang.String str4 = sourceFile2.getLine(0);
        org.junit.Assert.assertNotNull(sourceFile2);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        com.google.javascript.jscomp.SourceAst sourceAst0 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(sourceAst0, "", false);
        boolean boolean4 = compilerInput3.isExtern();
        java.lang.String str5 = compilerInput3.getName();
        com.google.javascript.jscomp.SourceAst sourceAst6 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput9 = new com.google.javascript.jscomp.CompilerInput(sourceAst6, "", false);
        com.google.javascript.jscomp.SourceAst sourceAst10 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput13 = new com.google.javascript.jscomp.CompilerInput(sourceAst10, "", false);
        boolean boolean14 = compilerInput13.isExtern();
        java.lang.String str15 = compilerInput13.getName();
        com.google.javascript.jscomp.SourceAst sourceAst16 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput19 = new com.google.javascript.jscomp.CompilerInput(sourceAst16, "", false);
        com.google.javascript.jscomp.JSModule jSModule20 = compilerInput19.getModule();
        com.google.javascript.jscomp.JSModule jSModule21 = null;
        compilerInput19.setModule(jSModule21);
        com.google.javascript.jscomp.deps.DependencyInfo[] dependencyInfoArray23 = new com.google.javascript.jscomp.deps.DependencyInfo[] { compilerInput3, compilerInput9, compilerInput13, compilerInput19 };
        java.util.ArrayList<com.google.javascript.jscomp.deps.DependencyInfo> dependencyInfoList24 = new java.util.ArrayList<com.google.javascript.jscomp.deps.DependencyInfo>();
        boolean boolean25 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.deps.DependencyInfo>) dependencyInfoList24, dependencyInfoArray23);
        try {
            com.google.javascript.jscomp.deps.SortedDependencies<com.google.javascript.jscomp.deps.DependencyInfo> dependencyInfoSortedDependencies26 = new com.google.javascript.jscomp.deps.SortedDependencies<com.google.javascript.jscomp.deps.DependencyInfo>((java.util.List<com.google.javascript.jscomp.deps.DependencyInfo>) dependencyInfoList24);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Expected setErrorManager to be called first");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
        org.junit.Assert.assertNull(jSModule20);
        org.junit.Assert.assertNotNull(dependencyInfoArray23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        com.google.javascript.rhino.Node node1 = new com.google.javascript.rhino.Node((int) (byte) 1);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        com.google.javascript.rhino.Context context0 = new com.google.javascript.rhino.Context();
        context0.setGeneratingSource(true);
        com.google.javascript.jscomp.CompilerOptions.TracerMode tracerMode3 = com.google.javascript.jscomp.CompilerOptions.TracerMode.FAST;
        context0.removeThreadLocal((java.lang.Object) tracerMode3);
        try {
            context0.setLanguageVersion(2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Bad language version: 2");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + tracerMode3 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TracerMode.FAST + "'", tracerMode3.equals(com.google.javascript.jscomp.CompilerOptions.TracerMode.FAST));
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        com.google.javascript.jscomp.SourceAst sourceAst0 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(sourceAst0, "", false);
        com.google.javascript.jscomp.JSModule jSModule4 = compilerInput3.getModule();
        com.google.javascript.jscomp.CompilerInput compilerInput7 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput3, "JSC_OPTIMIZE_LOOP_ERROR. Exceeded max number of code motion iterations: {0} at (unknown source) line (unknown line) : (unknown column)", false);
        try {
            java.lang.String str8 = compilerInput7.getPathRelativeToClosureBase();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: null");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNull(jSModule4);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        compiler1.disableThreads();
        com.google.javascript.jscomp.PerformanceTracker performanceTracker3 = compiler1.tracker;
        com.google.javascript.jscomp.NodeTraversal.Callback callback4 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal5 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler1, callback4);
        com.google.javascript.rhino.Node node7 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node9 = new com.google.javascript.rhino.Node((int) '4');
        node7.addChildrenToBack(node9);
        com.google.javascript.jscomp.DiagnosticType diagnosticType13 = com.google.javascript.jscomp.DiagnosticType.warning("hi!", "hi!");
        com.google.javascript.jscomp.DiagnosticType diagnosticType14 = com.google.javascript.jscomp.Compiler.MOTION_ITERATIONS_ERROR;
        int int15 = diagnosticType13.compareTo(diagnosticType14);
        java.lang.String[] strArray16 = com.google.javascript.rhino.ScriptRuntime.emptyStrings;
        com.google.javascript.jscomp.JSError jSError17 = nodeTraversal5.makeError(node9, diagnosticType13, strArray16);
        java.lang.RuntimeException runtimeException19 = com.google.javascript.rhino.ScriptRuntime.undefCallError((java.lang.Object) nodeTraversal5, (java.lang.Object) (byte) 1);
        try {
            com.google.javascript.jscomp.JSModule jSModule20 = nodeTraversal5.getModule();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(performanceTracker3);
        org.junit.Assert.assertNotNull(diagnosticType13);
        org.junit.Assert.assertNotNull(diagnosticType14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 30 + "'", int15 == 30);
        org.junit.Assert.assertNotNull(strArray16);
        org.junit.Assert.assertNotNull(jSError17);
        org.junit.Assert.assertNotNull(runtimeException19);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        com.google.javascript.rhino.Node node1 = new com.google.javascript.rhino.Node((int) '4');
        node1.setLineno(36);
        com.google.javascript.rhino.Node node4 = node1.cloneTree();
        node4.setLineno(110);
        org.junit.Assert.assertNotNull(node4);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        compiler1.disableThreads();
        com.google.javascript.jscomp.PerformanceTracker performanceTracker3 = compiler1.tracker;
        com.google.javascript.jscomp.NodeTraversal.Callback callback4 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal5 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler1, callback4);
        com.google.javascript.rhino.Node node7 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node9 = new com.google.javascript.rhino.Node((int) '4');
        node7.addChildrenToBack(node9);
        com.google.javascript.jscomp.DiagnosticType diagnosticType13 = com.google.javascript.jscomp.DiagnosticType.warning("hi!", "hi!");
        com.google.javascript.jscomp.DiagnosticType diagnosticType14 = com.google.javascript.jscomp.Compiler.MOTION_ITERATIONS_ERROR;
        int int15 = diagnosticType13.compareTo(diagnosticType14);
        java.lang.String[] strArray16 = com.google.javascript.rhino.ScriptRuntime.emptyStrings;
        com.google.javascript.jscomp.JSError jSError17 = nodeTraversal5.makeError(node9, diagnosticType13, strArray16);
        com.google.javascript.rhino.Node node19 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node21 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node23 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node25 = new com.google.javascript.rhino.Node((int) '4');
        node23.addChildrenToBack(node25);
        node19.addChildAfter(node21, node25);
        boolean boolean28 = node21.wasEmptyNode();
        try {
            nodeTraversal5.traverse(node21);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: INTERNAL COMPILER ERROR.\nPlease report this problem.\nnull");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNull(performanceTracker3);
        org.junit.Assert.assertNotNull(diagnosticType13);
        org.junit.Assert.assertNotNull(diagnosticType14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 30 + "'", int15 == 30);
        org.junit.Assert.assertNotNull(strArray16);
        org.junit.Assert.assertNotNull(jSError17);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        com.google.javascript.jscomp.SourceMap.Format format0 = com.google.javascript.jscomp.SourceMap.Format.DEFAULT;
        org.junit.Assert.assertNotNull(format0);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setLooseTypes(true);
        boolean boolean3 = compilerOptions0.collapseVariableDeclarations;
        boolean boolean4 = compilerOptions0.generateExports;
        com.google.javascript.jscomp.SourceMap.DetailLevel detailLevel5 = compilerOptions0.sourceMapDetailLevel;
        compilerOptions0.instrumentForCoverage = true;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(detailLevel5);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        com.google.javascript.jscomp.CompilerOptions compilerOptions1 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions1.setLooseTypes(true);
        boolean boolean4 = compilerOptions1.collapseVariableDeclarations;
        compilerOptions1.moveFunctionDeclarations = false;
        boolean boolean7 = compilerOptions1.decomposeExpressions;
        boolean boolean8 = compilerOptions1.optimizeParameters;
        java.lang.String str9 = compilerOptions1.inputDelimiter;
        com.google.javascript.jscomp.ErrorFormat errorFormat10 = com.google.javascript.jscomp.ErrorFormat.LEGACY;
        java.lang.RuntimeException runtimeException11 = com.google.javascript.rhino.ScriptRuntime.undefWriteError((java.lang.Object) (short) 100, (java.lang.Object) str9, (java.lang.Object) errorFormat10);
        java.io.PrintStream printStream12 = null;
        com.google.javascript.jscomp.Compiler compiler13 = new com.google.javascript.jscomp.Compiler(printStream12);
        compiler13.disableThreads();
        com.google.javascript.jscomp.PerformanceTracker performanceTracker15 = compiler13.tracker;
        com.google.javascript.jscomp.MessageFormatter messageFormatter17 = errorFormat10.toFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler13, false);
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter18 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler13);
        java.util.logging.Logger logger19 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager20 = new com.google.javascript.jscomp.LoggerErrorManager((com.google.javascript.jscomp.MessageFormatter) lightweightMessageFormatter18, logger19);
        loggerErrorManager20.setTypedPercent((double) 120);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "// Input %num%" + "'", str9.equals("// Input %num%"));
        org.junit.Assert.assertNotNull(errorFormat10);
        org.junit.Assert.assertNotNull(runtimeException11);
        org.junit.Assert.assertNull(performanceTracker15);
        org.junit.Assert.assertNotNull(messageFormatter17);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeUnusedPrototypePropertiesInExterns = false;
        boolean boolean3 = compilerOptions0.markAsCompiled;
        compilerOptions0.setDefineToBooleanLiteral("", true);
        compilerOptions0.rewriteFunctionExpressions = false;
        compilerOptions0.devirtualizePrototypeMethods = false;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention0 = new com.google.javascript.jscomp.DefaultCodingConvention();
        boolean boolean2 = defaultCodingConvention0.isExported("// Input %num%");
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry3 = null;
        com.google.javascript.jscomp.Scope scope4 = null;
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention5 = new com.google.javascript.jscomp.DefaultCodingConvention();
        java.lang.String str6 = defaultCodingConvention5.getDelegateSuperclassName();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry7 = null;
        com.google.javascript.jscomp.Scope scope8 = null;
        com.google.javascript.rhino.jstype.ObjectType[] objectTypeArray9 = new com.google.javascript.rhino.jstype.ObjectType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.ObjectType> objectTypeList10 = new java.util.ArrayList<com.google.javascript.rhino.jstype.ObjectType>();
        boolean boolean11 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.ObjectType>) objectTypeList10, objectTypeArray9);
        defaultCodingConvention5.defineDelegateProxyPrototypeProperties(jSTypeRegistry7, scope8, (java.util.List<com.google.javascript.rhino.jstype.ObjectType>) objectTypeList10);
        defaultCodingConvention0.defineDelegateProxyPrototypeProperties(jSTypeRegistry3, scope4, (java.util.List<com.google.javascript.rhino.jstype.ObjectType>) objectTypeList10);
        boolean boolean15 = defaultCodingConvention0.isSuperClassReference("hi!");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNotNull(objectTypeArray9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        com.google.javascript.jscomp.SourceAst sourceAst0 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(sourceAst0, "", false);
        com.google.javascript.jscomp.JSModule jSModule4 = compilerInput3.getModule();
        try {
            java.util.Collection<java.lang.String> strCollection5 = compilerInput3.getRequires();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Expected setErrorManager to be called first");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(jSModule4);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        try {
            com.google.javascript.rhino.EcmaError ecmaError4 = com.google.javascript.rhino.ScriptRuntime.typeError3("", "INSTANCEOF\n", "4", "null");
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property ");
        } catch (java.lang.RuntimeException e) {
        }
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        int int0 = com.google.javascript.rhino.Node.DIRECT_EVAL;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 48 + "'", int0 == 48);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention0 = new com.google.javascript.jscomp.DefaultCodingConvention();
        boolean boolean2 = defaultCodingConvention0.isExported("// Input %num%");
        com.google.javascript.rhino.Node node4 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node6 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node8 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node10 = new com.google.javascript.rhino.Node((int) '4');
        node8.addChildrenToBack(node10);
        node4.addChildAfter(node6, node10);
        com.google.javascript.rhino.Node node14 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node16 = new com.google.javascript.rhino.Node((int) '4');
        node14.addChildrenToBack(node16);
        com.google.javascript.rhino.Node node18 = node4.copyInformationFromForTree(node16);
        com.google.javascript.rhino.Node node19 = node4.cloneTree();
        com.google.javascript.rhino.Node node23 = new com.google.javascript.rhino.Node(30, 35, 8);
        com.google.javascript.rhino.Node node24 = node23.getLastChild();
        node19.addChildToFront(node23);
        java.lang.String str26 = defaultCodingConvention0.getSingletonGetterClassName(node23);
        boolean boolean29 = defaultCodingConvention0.isExported("error reporter", false);
        java.lang.String str30 = defaultCodingConvention0.getGlobalObject();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNull(node24);
        org.junit.Assert.assertNull(str26);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "window" + "'", str30.equals("window"));
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        com.google.javascript.rhino.Node node1 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node3 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node5 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node7 = new com.google.javascript.rhino.Node((int) '4');
        node5.addChildrenToBack(node7);
        node1.addChildAfter(node3, node7);
        com.google.javascript.rhino.Node node11 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node((int) '4');
        node11.addChildrenToBack(node13);
        com.google.javascript.rhino.Node node15 = node1.copyInformationFromForTree(node13);
        com.google.javascript.rhino.Node node16 = node1.cloneTree();
        try {
            node1.setQuotedString();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: FAILED ASSERTION");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertNotNull(node16);
    }

//    @Test
//    public void test332() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test332");
//        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.TYPE_INVALIDATION;
//        com.google.javascript.jscomp.DiagnosticGroups.VISIBILITY = diagnosticGroup0;
//        org.junit.Assert.assertNotNull(diagnosticGroup0);
//    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.common.collect.Multimap<com.google.javascript.jscomp.CustomPassExecutionTime, com.google.javascript.jscomp.CompilerPass> customPassExecutionTimeMultimap1 = compilerOptions0.customPasses;
        boolean boolean2 = compilerOptions0.extractPrototypeMemberDeclarations;
        org.junit.Assert.assertNull(customPassExecutionTimeMultimap1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        com.google.javascript.rhino.Node node1 = new com.google.javascript.rhino.Node((int) (short) 1);
        com.google.javascript.rhino.Node node3 = new com.google.javascript.rhino.Node((int) (short) 1);
        node1.addChildrenToBack(node3);
        node3.setLineno((int) (byte) 100);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setLooseTypes(true);
        boolean boolean3 = compilerOptions0.collapseVariableDeclarations;
        com.google.javascript.jscomp.SourceMap.DetailLevel detailLevel4 = compilerOptions0.sourceMapDetailLevel;
        boolean boolean5 = compilerOptions0.aliasAllStrings;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(detailLevel4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        try {
            com.google.javascript.jscomp.JSError[] jSErrorArray2 = compiler1.getErrors();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setLooseTypes(true);
        boolean boolean3 = compilerOptions0.reserveRawExports;
        com.google.javascript.jscomp.CheckLevel checkLevel4 = null;
        compilerOptions0.checkUnreachableCode = checkLevel4;
        boolean boolean6 = compilerOptions0.devirtualizePrototypeMethods;
        compilerOptions0.setColorizeErrorOutput(true);
        compilerOptions0.removeDeadCode = false;
        com.google.javascript.jscomp.CompilerOptions.AliasTransformationHandler aliasTransformationHandler11 = null;
        compilerOptions0.setAliasTransformationHandler(aliasTransformationHandler11);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        try {
            java.lang.String str2 = com.google.javascript.rhino.ScriptRuntime.escapeString("com.google.javascript.rhino.EcmaError: TypeError: 4", ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: FAILED ASSERTION");
        } catch (java.lang.IllegalStateException e) {
        }
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        com.google.javascript.jscomp.parsing.Config.LanguageMode languageMode1 = com.google.javascript.jscomp.parsing.Config.LanguageMode.ECMASCRIPT5_STRICT;
        com.google.javascript.jscomp.parsing.Config config3 = com.google.javascript.jscomp.parsing.ParserRunner.createConfig(false, languageMode1, true);
        org.junit.Assert.assertTrue("'" + languageMode1 + "' != '" + com.google.javascript.jscomp.parsing.Config.LanguageMode.ECMASCRIPT5_STRICT + "'", languageMode1.equals(com.google.javascript.jscomp.parsing.Config.LanguageMode.ECMASCRIPT5_STRICT));
        org.junit.Assert.assertNotNull(config3);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        java.lang.Object[] objArray0 = com.google.javascript.rhino.Context.emptyArgs;
        org.junit.Assert.assertNotNull(objArray0);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromCode("hi!", "hi!");
        java.lang.String str3 = sourceFile2.toString();
        java.lang.String str5 = sourceFile2.getLine(34);
        sourceFile2.setOriginalPath("Not declared as a type name");
        org.junit.Assert.assertNotNull(sourceFile2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "hi!" + "'", str3.equals("hi!"));
        org.junit.Assert.assertNull(str5);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        int int0 = com.google.javascript.rhino.Node.ENUM_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        int int0 = com.google.javascript.rhino.Node.DESCENDANTS_FLAG;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        com.google.javascript.rhino.EcmaError ecmaError1 = com.google.javascript.rhino.ScriptRuntime.typeError("4");
        java.lang.String str2 = ecmaError1.details();
        java.lang.String str3 = ecmaError1.sourceName();
        ecmaError1.initSourceName("window");
        org.junit.Assert.assertNotNull(ecmaError1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "TypeError: 4" + "'", str2.equals("TypeError: 4"));
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setLooseTypes(true);
        boolean boolean3 = compilerOptions0.reserveRawExports;
        compilerOptions0.extractPrototypeMemberDeclarations = false;
        com.google.javascript.jscomp.CheckLevel checkLevel6 = compilerOptions0.aggressiveVarCheck;
        compilerOptions0.inferTypesInGlobalScope = false;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + checkLevel6 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel6.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        com.google.javascript.jscomp.CompilerOptions compilerOptions1 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions1.setLooseTypes(true);
        boolean boolean4 = compilerOptions1.collapseVariableDeclarations;
        compilerOptions1.moveFunctionDeclarations = false;
        boolean boolean7 = compilerOptions1.decomposeExpressions;
        boolean boolean8 = compilerOptions1.optimizeParameters;
        java.lang.String str9 = compilerOptions1.inputDelimiter;
        com.google.javascript.jscomp.ErrorFormat errorFormat10 = com.google.javascript.jscomp.ErrorFormat.LEGACY;
        java.lang.RuntimeException runtimeException11 = com.google.javascript.rhino.ScriptRuntime.undefWriteError((java.lang.Object) (short) 100, (java.lang.Object) str9, (java.lang.Object) errorFormat10);
        java.io.PrintStream printStream12 = null;
        com.google.javascript.jscomp.Compiler compiler13 = new com.google.javascript.jscomp.Compiler(printStream12);
        compiler13.disableThreads();
        com.google.javascript.jscomp.PerformanceTracker performanceTracker15 = compiler13.tracker;
        com.google.javascript.jscomp.MessageFormatter messageFormatter17 = errorFormat10.toFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler13, false);
        try {
            com.google.javascript.jscomp.JSError[] jSErrorArray18 = compiler13.getMessages();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "// Input %num%" + "'", str9.equals("// Input %num%"));
        org.junit.Assert.assertNotNull(errorFormat10);
        org.junit.Assert.assertNotNull(runtimeException11);
        org.junit.Assert.assertNull(performanceTracker15);
        org.junit.Assert.assertNotNull(messageFormatter17);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        compiler1.disableThreads();
        com.google.javascript.jscomp.PerformanceTracker performanceTracker3 = compiler1.tracker;
        com.google.javascript.jscomp.NodeTraversal.Callback callback4 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal5 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler1, callback4);
        com.google.javascript.rhino.Node node7 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node9 = new com.google.javascript.rhino.Node((int) '4');
        node7.addChildrenToBack(node9);
        com.google.javascript.jscomp.DiagnosticType diagnosticType13 = com.google.javascript.jscomp.DiagnosticType.warning("hi!", "hi!");
        com.google.javascript.jscomp.DiagnosticType diagnosticType14 = com.google.javascript.jscomp.Compiler.MOTION_ITERATIONS_ERROR;
        int int15 = diagnosticType13.compareTo(diagnosticType14);
        java.lang.String[] strArray16 = com.google.javascript.rhino.ScriptRuntime.emptyStrings;
        com.google.javascript.jscomp.JSError jSError17 = nodeTraversal5.makeError(node9, diagnosticType13, strArray16);
        int int18 = jSError17.getCharno();
        org.junit.Assert.assertNull(performanceTracker3);
        org.junit.Assert.assertNotNull(diagnosticType13);
        org.junit.Assert.assertNotNull(diagnosticType14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 30 + "'", int15 == 30);
        org.junit.Assert.assertNotNull(strArray16);
        org.junit.Assert.assertNotNull(jSError17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile4 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        java.io.Reader reader5 = jSSourceFile4.getCodeReader();
        com.google.javascript.jscomp.JSModule[] jSModuleArray6 = new com.google.javascript.jscomp.JSModule[] {};
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph7 = new com.google.javascript.jscomp.JSModuleGraph(jSModuleArray6);
        com.google.javascript.jscomp.CompilerOptions compilerOptions8 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions8.setLooseTypes(true);
        boolean boolean11 = compilerOptions8.collapseVariableDeclarations;
        compilerOptions8.moveFunctionDeclarations = false;
        boolean boolean14 = compilerOptions8.decomposeExpressions;
        com.google.javascript.jscomp.CheckLevel checkLevel15 = compilerOptions8.checkMissingGetCssNameLevel;
        com.google.javascript.jscomp.Result result16 = compiler1.compile(jSSourceFile4, jSModuleArray6, compilerOptions8);
        com.google.javascript.jscomp.Result result17 = compiler1.getResult();
        boolean boolean18 = compiler1.hasErrors();
        com.google.javascript.jscomp.SourceFile.Generator generator20 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile21 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("JSC_OPTIMIZE_LOOP_ERROR. Exceeded max number of code motion iterations: {0} at (unknown source) line (unknown line) : (unknown column)", generator20);
        com.google.javascript.jscomp.SourceFile.Generator generator23 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile24 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("JSC_OPTIMIZE_LOOP_ERROR. Exceeded max number of code motion iterations: {0} at (unknown source) line (unknown line) : (unknown column)", generator23);
        com.google.javascript.jscomp.CompilerOptions compilerOptions25 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions25.setLooseTypes(true);
        boolean boolean28 = compilerOptions25.reserveRawExports;
        compilerOptions25.extractPrototypeMemberDeclarations = false;
        java.lang.String str31 = compilerOptions25.nameReferenceGraphPath;
        compilerOptions25.computeFunctionSideEffects = true;
        com.google.javascript.jscomp.CompilerOptions compilerOptions34 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions34.setLooseTypes(true);
        compilerOptions34.convertToDottedProperties = false;
        com.google.javascript.jscomp.CheckLevel checkLevel39 = compilerOptions34.reportMissingOverride;
        compilerOptions25.brokenClosureRequiresLevel = checkLevel39;
        java.util.Set<java.lang.String> strSet41 = compilerOptions25.stripTypePrefixes;
        compilerOptions25.optimizeReturns = true;
        com.google.javascript.jscomp.Result result44 = compiler1.compile(jSSourceFile21, jSSourceFile24, compilerOptions25);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile46 = com.google.javascript.jscomp.JSSourceFile.fromFile("(): error reporter");
        java.lang.String str47 = jSSourceFile46.toString();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile50 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        java.io.Reader reader51 = jSSourceFile50.getCodeReader();
        com.google.javascript.jscomp.CompilerOptions compilerOptions52 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions52.setLooseTypes(true);
        boolean boolean55 = compilerOptions52.reserveRawExports;
        boolean boolean56 = compilerOptions52.flowSensitiveInlineVariables;
        compilerOptions52.reserveRawExports = true;
        compilerOptions52.inferTypesInGlobalScope = false;
        boolean boolean61 = compilerOptions52.markNoSideEffectCalls;
        com.google.javascript.jscomp.CheckLevel checkLevel62 = compilerOptions52.checkProvides;
        com.google.javascript.jscomp.Result result63 = compiler1.compile(jSSourceFile46, jSSourceFile50, compilerOptions52);
        try {
            java.io.Reader reader64 = jSSourceFile46.getCodeReader();
            org.junit.Assert.fail("Expected exception of type java.io.FileNotFoundException; message: (): error reporter (No such file or directory)");
        } catch (java.io.FileNotFoundException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile4);
        org.junit.Assert.assertNotNull(reader5);
        org.junit.Assert.assertNotNull(jSModuleArray6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + checkLevel15 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel15.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(result16);
        org.junit.Assert.assertNotNull(result17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(jSSourceFile21);
        org.junit.Assert.assertNotNull(jSSourceFile24);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNull(str31);
        org.junit.Assert.assertTrue("'" + checkLevel39 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel39.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(strSet41);
        org.junit.Assert.assertNotNull(result44);
        org.junit.Assert.assertNotNull(jSSourceFile46);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "(): error reporter" + "'", str47.equals("(): error reporter"));
        org.junit.Assert.assertNotNull(jSSourceFile50);
        org.junit.Assert.assertNotNull(reader51);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertTrue("'" + checkLevel62 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel62.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(result63);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        compiler1.disableThreads();
        com.google.javascript.jscomp.PerformanceTracker performanceTracker3 = compiler1.tracker;
        com.google.javascript.jscomp.NodeTraversal.Callback callback4 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal5 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler1, callback4);
        com.google.javascript.rhino.Node node7 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node9 = new com.google.javascript.rhino.Node((int) '4');
        node7.addChildrenToBack(node9);
        com.google.javascript.jscomp.DiagnosticType diagnosticType13 = com.google.javascript.jscomp.DiagnosticType.warning("hi!", "hi!");
        com.google.javascript.jscomp.DiagnosticType diagnosticType14 = com.google.javascript.jscomp.Compiler.MOTION_ITERATIONS_ERROR;
        int int15 = diagnosticType13.compareTo(diagnosticType14);
        java.lang.String[] strArray16 = com.google.javascript.rhino.ScriptRuntime.emptyStrings;
        com.google.javascript.jscomp.JSError jSError17 = nodeTraversal5.makeError(node9, diagnosticType13, strArray16);
        java.lang.RuntimeException runtimeException19 = com.google.javascript.rhino.ScriptRuntime.undefCallError((java.lang.Object) nodeTraversal5, (java.lang.Object) (byte) 1);
        int int20 = nodeTraversal5.getLineNumber();
        com.google.javascript.rhino.Node node22 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node24 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node26 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node28 = new com.google.javascript.rhino.Node((int) '4');
        node26.addChildrenToBack(node28);
        node22.addChildAfter(node24, node28);
        com.google.javascript.rhino.Node node32 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node34 = new com.google.javascript.rhino.Node((int) '4');
        node32.addChildrenToBack(node34);
        com.google.javascript.rhino.Node node36 = node22.copyInformationFromForTree(node34);
        com.google.javascript.rhino.jstype.JSType jSType37 = null;
        node36.setJSType(jSType37);
        com.google.javascript.rhino.Node node42 = com.google.javascript.rhino.Node.newNumber(0.0d, 31, 30);
        com.google.javascript.rhino.Node node46 = com.google.javascript.rhino.Node.newNumber((double) 5, 21, 43);
        com.google.javascript.jscomp.CompilerOptions compilerOptions47 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions47.flowSensitiveInlineVariables = false;
        compilerOptions47.setDefineToBooleanLiteral("// Input %num%", false);
        com.google.javascript.rhino.Node node54 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node56 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node58 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node60 = new com.google.javascript.rhino.Node((int) '4');
        node58.addChildrenToBack(node60);
        node54.addChildAfter(node56, node60);
        com.google.javascript.rhino.Node node64 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node66 = new com.google.javascript.rhino.Node((int) '4');
        node64.addChildrenToBack(node66);
        com.google.javascript.rhino.Node node68 = node54.copyInformationFromForTree(node66);
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable69 = node68.siblings();
        java.lang.RuntimeException runtimeException70 = com.google.javascript.rhino.ScriptRuntime.notFunctionError((java.lang.Object) compilerOptions47, (java.lang.Object) node68);
        int int71 = node68.getLineno();
        com.google.javascript.rhino.Node node73 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node75 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node77 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node79 = new com.google.javascript.rhino.Node((int) '4');
        node77.addChildrenToBack(node79);
        node73.addChildAfter(node75, node79);
        com.google.javascript.rhino.Node node83 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node85 = new com.google.javascript.rhino.Node((int) '4');
        node83.addChildrenToBack(node85);
        com.google.javascript.rhino.Node node87 = node73.copyInformationFromForTree(node85);
        com.google.javascript.rhino.Node node89 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node90 = node73.copyInformationFromForTree(node89);
        com.google.javascript.rhino.Node[] nodeArray91 = new com.google.javascript.rhino.Node[] { node36, node42, node46, node68, node90 };
        try {
            nodeTraversal5.traverseRoots(nodeArray91);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: INTERNAL COMPILER ERROR.\nPlease report this problem.\nnull");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNull(performanceTracker3);
        org.junit.Assert.assertNotNull(diagnosticType13);
        org.junit.Assert.assertNotNull(diagnosticType14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 30 + "'", int15 == 30);
        org.junit.Assert.assertNotNull(strArray16);
        org.junit.Assert.assertNotNull(jSError17);
        org.junit.Assert.assertNotNull(runtimeException19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(node36);
        org.junit.Assert.assertNotNull(node42);
        org.junit.Assert.assertNotNull(node46);
        org.junit.Assert.assertNotNull(node68);
        org.junit.Assert.assertNotNull(nodeIterable69);
        org.junit.Assert.assertNotNull(runtimeException70);
        org.junit.Assert.assertTrue("'" + int71 + "' != '" + (-1) + "'", int71 == (-1));
        org.junit.Assert.assertNotNull(node87);
        org.junit.Assert.assertNotNull(node90);
        org.junit.Assert.assertNotNull(nodeArray91);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        com.google.javascript.rhino.Node node3 = new com.google.javascript.rhino.Node(30, 35, 8);
        com.google.javascript.rhino.Node node4 = node3.getLastChild();
        try {
            com.google.javascript.rhino.Node node6 = node4.getAncestor(38);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(node4);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile3 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        java.io.Reader reader4 = jSSourceFile3.getCodeReader();
        com.google.javascript.jscomp.SourceFile sourceFile5 = com.google.javascript.jscomp.SourceFile.fromReader("Not declared as a type name", reader4);
        java.io.Reader reader6 = sourceFile5.getCodeReader();
        com.google.javascript.jscomp.Region region8 = sourceFile5.getRegion((int) (short) 1);
        org.junit.Assert.assertNotNull(jSSourceFile3);
        org.junit.Assert.assertNotNull(reader4);
        org.junit.Assert.assertNotNull(sourceFile5);
        org.junit.Assert.assertNotNull(reader6);
        org.junit.Assert.assertNull(region8);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        try {
            java.lang.String str1 = com.google.javascript.rhino.ScriptRuntime.getMessage0("()");
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property ()");
        } catch (java.lang.RuntimeException e) {
        }
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        com.google.javascript.jscomp.SourceAst sourceAst0 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(sourceAst0, "", false);
        com.google.javascript.jscomp.JSModule jSModule4 = compilerInput3.getModule();
        com.google.javascript.jscomp.CompilerInput compilerInput7 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput3, "JSC_OPTIMIZE_LOOP_ERROR. Exceeded max number of code motion iterations: {0} at (unknown source) line (unknown line) : (unknown column)", false);
        try {
            java.lang.String str9 = compilerInput7.getLine(120);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(jSModule4);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        compiler1.disableThreads();
        com.google.javascript.jscomp.PerformanceTracker performanceTracker3 = compiler1.tracker;
        compiler1.disableThreads();
        try {
            compiler1.normalize();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(performanceTracker3);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        com.google.javascript.jscomp.DiagnosticType diagnosticType2 = com.google.javascript.jscomp.DiagnosticType.warning("hi!", "hi!");
        java.lang.String str3 = diagnosticType2.key;
        java.lang.String str4 = diagnosticType2.toString();
        java.lang.String str5 = diagnosticType2.key;
        com.google.javascript.jscomp.DiagnosticType diagnosticType8 = com.google.javascript.jscomp.DiagnosticType.warning("hi!", "hi!");
        java.lang.String str9 = diagnosticType8.key;
        java.lang.String str10 = diagnosticType8.toString();
        java.text.MessageFormat messageFormat11 = diagnosticType8.format;
        int int12 = diagnosticType2.compareTo(diagnosticType8);
        org.junit.Assert.assertNotNull(diagnosticType2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "hi!" + "'", str3.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "hi!: hi!" + "'", str4.equals("hi!: hi!"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        org.junit.Assert.assertNotNull(diagnosticType8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "hi!" + "'", str9.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "hi!: hi!" + "'", str10.equals("hi!: hi!"));
        org.junit.Assert.assertNotNull(messageFormat11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        java.io.File file0 = null;
        java.nio.charset.Charset charset1 = null;
        try {
            com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromFile(file0, charset1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        int int0 = com.google.javascript.rhino.Node.COLUMN_MASK;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4095 + "'", int0 == 4095);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setLooseTypes(true);
        boolean boolean3 = compilerOptions0.reserveRawExports;
        compilerOptions0.extractPrototypeMemberDeclarations = false;
        java.lang.String str6 = compilerOptions0.nameReferenceGraphPath;
        compilerOptions0.computeFunctionSideEffects = true;
        com.google.javascript.jscomp.CompilerOptions compilerOptions9 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions9.setLooseTypes(true);
        compilerOptions9.convertToDottedProperties = false;
        com.google.javascript.jscomp.CheckLevel checkLevel14 = compilerOptions9.reportMissingOverride;
        compilerOptions0.brokenClosureRequiresLevel = checkLevel14;
        java.util.Set<java.lang.String> strSet16 = compilerOptions0.stripTypePrefixes;
        compilerOptions0.optimizeReturns = true;
        compilerOptions0.allowLegacyJsMessages = false;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + checkLevel14 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel14.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(strSet16);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeUnusedPrototypePropertiesInExterns = false;
        java.lang.String[] strArray6 = new java.lang.String[] { "()", "4" };
        java.util.ArrayList<java.lang.String> strList7 = new java.util.ArrayList<java.lang.String>();
        boolean boolean8 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strList7, strArray6);
        compilerOptions0.setReplaceStringsConfiguration("JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}", (java.util.List<java.lang.String>) strList7);
        boolean boolean10 = compilerOptions0.removeTryCatchFinally;
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setLooseTypes(true);
        boolean boolean3 = compilerOptions0.reserveRawExports;
        compilerOptions0.extractPrototypeMemberDeclarations = false;
        boolean boolean6 = compilerOptions0.disambiguateProperties;
        com.google.javascript.jscomp.CheckLevel checkLevel7 = compilerOptions0.checkFunctions;
        java.lang.String str8 = compilerOptions0.nameReferenceGraphPath;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + checkLevel7 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel7.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNull(str8);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        com.google.javascript.rhino.Node node1 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node3 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node5 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node7 = new com.google.javascript.rhino.Node((int) '4');
        node5.addChildrenToBack(node7);
        node1.addChildAfter(node3, node7);
        com.google.javascript.rhino.Node node10 = node7.getParent();
        boolean boolean11 = node7.isLocalResultCall();
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention0 = new com.google.javascript.jscomp.DefaultCodingConvention();
        boolean boolean2 = defaultCodingConvention0.isExported("// Input %num%");
        com.google.javascript.rhino.Node node4 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node6 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node8 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node10 = new com.google.javascript.rhino.Node((int) '4');
        node8.addChildrenToBack(node10);
        node4.addChildAfter(node6, node10);
        com.google.javascript.rhino.Node node14 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node16 = new com.google.javascript.rhino.Node((int) '4');
        node14.addChildrenToBack(node16);
        com.google.javascript.rhino.Node node18 = node4.copyInformationFromForTree(node16);
        com.google.javascript.rhino.Node node19 = node4.cloneTree();
        com.google.javascript.rhino.Node node23 = new com.google.javascript.rhino.Node(30, 35, 8);
        com.google.javascript.rhino.Node node24 = node23.getLastChild();
        node19.addChildToFront(node23);
        java.lang.String str26 = defaultCodingConvention0.getSingletonGetterClassName(node23);
        boolean boolean29 = defaultCodingConvention0.isExported("error reporter", false);
        com.google.javascript.rhino.jstype.ObjectType objectType30 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType31 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType32 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType33 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType34 = null;
        defaultCodingConvention0.applyDelegateRelationship(objectType30, objectType31, objectType32, functionType33, functionType34);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNull(node24);
        org.junit.Assert.assertNull(str26);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        double double0 = com.google.javascript.rhino.ScriptRuntime.NaN;
        org.junit.Assert.assertEquals((double) double0, Double.NaN, 0);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        com.google.javascript.rhino.Node node1 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node3 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node5 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node7 = new com.google.javascript.rhino.Node((int) '4');
        node5.addChildrenToBack(node7);
        node1.addChildAfter(node3, node7);
        com.google.javascript.rhino.Node node11 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node((int) '4');
        node11.addChildrenToBack(node13);
        com.google.javascript.rhino.Node node15 = node1.copyInformationFromForTree(node13);
        com.google.javascript.rhino.Node node17 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node18 = node1.copyInformationFromForTree(node17);
        java.util.Set<java.lang.String> strSet19 = node18.getDirectives();
        try {
            com.google.javascript.rhino.Node node20 = node18.detachFromParent();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNull(strSet19);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        com.google.javascript.jscomp.CompilerOptions.TracerMode tracerMode0 = com.google.javascript.jscomp.CompilerOptions.TracerMode.ALL;
        org.junit.Assert.assertTrue("'" + tracerMode0 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TracerMode.ALL + "'", tracerMode0.equals(com.google.javascript.jscomp.CompilerOptions.TracerMode.ALL));
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        com.google.javascript.rhino.EcmaError ecmaError1 = com.google.javascript.rhino.ScriptRuntime.typeError("4");
        java.lang.String str2 = ecmaError1.getName();
        java.lang.String str3 = ecmaError1.lineSource();
        java.lang.String str4 = ecmaError1.toString();
        java.lang.String str5 = ecmaError1.lineSource();
        ecmaError1.initLineSource("language version");
        org.junit.Assert.assertNotNull(ecmaError1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "TypeError" + "'", str2.equals("TypeError"));
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "com.google.javascript.rhino.EcmaError: TypeError: 4" + "'", str4.equals("com.google.javascript.rhino.EcmaError: TypeError: 4"));
        org.junit.Assert.assertNull(str5);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString("Not declared as a type name", 120, 10);
        node3.setIsSyntheticBlock(true);
        org.junit.Assert.assertNotNull(node3);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        boolean boolean1 = com.google.javascript.rhino.Context.isValidLanguageVersion((int) '#');
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        java.lang.String str1 = com.google.javascript.rhino.jstype.ObjectType.createDelegateSuffix("<No stack trace available>");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "(<No stack trace available>)" + "'", str1.equals("(<No stack trace available>)"));
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        compiler1.disableThreads();
        com.google.javascript.jscomp.PerformanceTracker performanceTracker3 = compiler1.tracker;
        com.google.javascript.jscomp.NodeTraversal.Callback callback4 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal5 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler1, callback4);
        com.google.javascript.jscomp.Compiler compiler6 = nodeTraversal5.getCompiler();
        com.google.javascript.jscomp.SourceFile.Generator generator8 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile9 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("JSC_OPTIMIZE_LOOP_ERROR. Exceeded max number of code motion iterations: {0} at (unknown source) line (unknown line) : (unknown column)", generator8);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile11 = com.google.javascript.jscomp.JSSourceFile.fromFile("(): error reporter");
        java.lang.String str12 = jSSourceFile11.toString();
        com.google.javascript.jscomp.CompilerOptions compilerOptions13 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions13.removeUnusedPrototypePropertiesInExterns = false;
        compilerOptions13.removeUnusedLocalVars = false;
        compilerOptions13.reserveRawExports = false;
        try {
            com.google.javascript.jscomp.Result result20 = compiler6.compile(jSSourceFile9, jSSourceFile11, compilerOptions13);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: java.lang.NullPointerException");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNull(performanceTracker3);
        org.junit.Assert.assertNotNull(compiler6);
        org.junit.Assert.assertNotNull(jSSourceFile9);
        org.junit.Assert.assertNotNull(jSSourceFile11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "(): error reporter" + "'", str12.equals("(): error reporter"));
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.STRICT_MODULE_DEP_CHECK;
        com.google.javascript.jscomp.DiagnosticGroups.TYPE_INVALIDATION = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticGroups.GLOBAL_THIS = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticGroups.AMBIGUOUS_FUNCTION_DECL = diagnosticGroup0;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.GLOBAL_THIS;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        compiler1.disableThreads();
        com.google.javascript.jscomp.PerformanceTracker performanceTracker3 = compiler1.tracker;
        com.google.javascript.jscomp.NodeTraversal.Callback callback4 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal5 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler1, callback4);
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter6 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler1);
        com.google.javascript.jscomp.JSModule jSModule7 = null;
        try {
            java.lang.String str8 = compiler1.toSource(jSModule7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(performanceTracker3);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        com.google.javascript.rhino.EcmaError ecmaError1 = com.google.javascript.rhino.ScriptRuntime.typeError("4");
        java.lang.String str2 = ecmaError1.getName();
        java.lang.String str3 = ecmaError1.getErrorMessage();
        org.junit.Assert.assertNotNull(ecmaError1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "TypeError" + "'", str2.equals("TypeError"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "4" + "'", str3.equals("4"));
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        double double0 = com.google.javascript.rhino.ScriptRuntime.negativeZero;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + (-0.0d) + "'", double0 == (-0.0d));
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromCode("", "false");
        org.junit.Assert.assertNotNull(sourceFile2);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        com.google.javascript.rhino.EcmaError ecmaError2 = com.google.javascript.rhino.ScriptRuntime.constructError("()", "error reporter");
        java.lang.String str3 = ecmaError2.details();
        java.lang.String str4 = ecmaError2.getErrorMessage();
        org.junit.Assert.assertNotNull(ecmaError2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "(): error reporter" + "'", str3.equals("(): error reporter"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "error reporter" + "'", str4.equals("error reporter"));
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        com.google.javascript.rhino.Node node1 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node3 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node5 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node7 = new com.google.javascript.rhino.Node((int) '4');
        node5.addChildrenToBack(node7);
        node1.addChildAfter(node3, node7);
        com.google.javascript.rhino.Node node11 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node((int) '4');
        node11.addChildrenToBack(node13);
        com.google.javascript.rhino.Node node15 = node1.copyInformationFromForTree(node13);
        com.google.javascript.rhino.Node node17 = node1.getAncestor(1);
        try {
            double double18 = node17.getDouble();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertNull(node17);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        com.google.javascript.jscomp.SourceFile.Generator generator1 = null;
        com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromGenerator("(<No stack trace available>)", generator1);
        org.junit.Assert.assertNotNull(sourceFile2);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.STRICT_MODULE_DEP_CHECK;
        com.google.javascript.jscomp.DiagnosticGroups.MISSING_PROPERTIES = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticGroups.STRICT_MODULE_DEP_CHECK = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticGroups.INVALID_CASTS = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticType diagnosticType6 = com.google.javascript.jscomp.DiagnosticType.warning("hi!", "hi!");
        java.lang.String str7 = diagnosticType6.key;
        boolean boolean8 = diagnosticGroup0.matches(diagnosticType6);
        com.google.javascript.jscomp.DiagnosticGroups.CHECK_VARIABLES = diagnosticGroup0;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
        org.junit.Assert.assertNotNull(diagnosticType6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "hi!" + "'", str7.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.STRICT_MODULE_DEP_CHECK;
        com.google.javascript.jscomp.DiagnosticGroups.MISSING_PROPERTIES = diagnosticGroup0;
        com.google.javascript.rhino.Node node4 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node6 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node8 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node10 = new com.google.javascript.rhino.Node((int) '4');
        node8.addChildrenToBack(node10);
        node4.addChildAfter(node6, node10);
        com.google.javascript.rhino.Node node14 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node16 = new com.google.javascript.rhino.Node((int) '4');
        node14.addChildrenToBack(node16);
        com.google.javascript.rhino.Node node18 = node4.copyInformationFromForTree(node16);
        com.google.javascript.jscomp.DiagnosticType diagnosticType19 = com.google.javascript.jscomp.Compiler.MOTION_ITERATIONS_ERROR;
        java.lang.String str20 = diagnosticType19.toString();
        java.lang.String[] strArray21 = null;
        com.google.javascript.jscomp.JSError jSError22 = com.google.javascript.jscomp.JSError.make("", node16, diagnosticType19, strArray21);
        java.lang.String str23 = jSError22.description;
        java.lang.String str24 = jSError22.toString();
        java.lang.String str25 = jSError22.description;
        boolean boolean26 = diagnosticGroup0.matches(jSError22);
        java.lang.String str27 = diagnosticGroup0.toString();
        org.junit.Assert.assertNotNull(diagnosticGroup0);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNotNull(diagnosticType19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}" + "'", str20.equals("JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}"));
        org.junit.Assert.assertNotNull(jSError22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "Exceeded max number of code motion iterations: {0}" + "'", str23.equals("Exceeded max number of code motion iterations: {0}"));
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "JSC_OPTIMIZE_LOOP_ERROR. Exceeded max number of code motion iterations: {0} at (unknown source) line (unknown line) : (unknown column)" + "'", str24.equals("JSC_OPTIMIZE_LOOP_ERROR. Exceeded max number of code motion iterations: {0} at (unknown source) line (unknown line) : (unknown column)"));
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "Exceeded max number of code motion iterations: {0}" + "'", str25.equals("Exceeded max number of code motion iterations: {0}"));
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray0 = new com.google.javascript.jscomp.WarningsGuard[] {};
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard1 = new com.google.javascript.jscomp.ComposeWarningsGuard(warningsGuardArray0);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup2 = null;
        try {
            boolean boolean3 = composeWarningsGuard1.disables(diagnosticGroup2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(warningsGuardArray0);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setLooseTypes(true);
        compilerOptions0.checkSuspiciousCode = false;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap5 = null;
        compilerOptions0.cssRenamingMap = cssRenamingMap5;
        compilerOptions0.aliasableGlobals = "hi!: hi!";
        com.google.javascript.jscomp.CompilerOptions.TracerMode tracerMode9 = compilerOptions0.tracer;
        boolean boolean10 = compilerOptions0.coalesceVariableNames;
        org.junit.Assert.assertTrue("'" + tracerMode9 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TracerMode.OFF + "'", tracerMode9.equals(com.google.javascript.jscomp.CompilerOptions.TracerMode.OFF));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention0 = new com.google.javascript.jscomp.DefaultCodingConvention();
        boolean boolean2 = defaultCodingConvention0.isConstant("hi!");
        boolean boolean4 = defaultCodingConvention0.isConstant("Not declared as a type name");
        com.google.javascript.rhino.Node node6 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node8 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node10 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node12 = new com.google.javascript.rhino.Node((int) '4');
        node10.addChildrenToBack(node12);
        node6.addChildAfter(node8, node12);
        com.google.javascript.rhino.Node node16 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node18 = new com.google.javascript.rhino.Node((int) '4');
        node16.addChildrenToBack(node18);
        com.google.javascript.rhino.Node node20 = node6.copyInformationFromForTree(node18);
        com.google.javascript.rhino.Node node21 = node20.getLastChild();
        com.google.javascript.rhino.Node node23 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node25 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node27 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node29 = new com.google.javascript.rhino.Node((int) '4');
        node27.addChildrenToBack(node29);
        node23.addChildAfter(node25, node29);
        com.google.javascript.rhino.Node node33 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node35 = new com.google.javascript.rhino.Node((int) '4');
        node33.addChildrenToBack(node35);
        com.google.javascript.rhino.Node node37 = node23.copyInformationFromForTree(node35);
        node20.addChildToBack(node23);
        com.google.javascript.rhino.Node node40 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node42 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node44 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node46 = new com.google.javascript.rhino.Node((int) '4');
        node44.addChildrenToBack(node46);
        node40.addChildAfter(node42, node46);
        com.google.javascript.rhino.Node node50 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node52 = new com.google.javascript.rhino.Node((int) '4');
        node50.addChildrenToBack(node52);
        com.google.javascript.rhino.Node node54 = node40.copyInformationFromForTree(node52);
        com.google.javascript.rhino.jstype.JSType jSType55 = null;
        node54.setJSType(jSType55);
        node20.addChildToFront(node54);
        com.google.javascript.jscomp.CodingConvention.SubclassRelationship subclassRelationship58 = defaultCodingConvention0.getClassesDefinedByCall(node54);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNull(node21);
        org.junit.Assert.assertNotNull(node37);
        org.junit.Assert.assertNotNull(node54);
        org.junit.Assert.assertNull(subclassRelationship58);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        java.lang.String str1 = com.google.javascript.rhino.jstype.ObjectType.createDelegateSuffix("4");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "(4)" + "'", str1.equals("(4)"));
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        com.google.javascript.jscomp.CompilerOptions compilerOptions1 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions1.setLooseTypes(true);
        boolean boolean4 = compilerOptions1.reserveRawExports;
        com.google.javascript.jscomp.CheckLevel checkLevel5 = null;
        compilerOptions1.checkUnreachableCode = checkLevel5;
        com.google.javascript.jscomp.MessageBundle messageBundle7 = compilerOptions1.messageBundle;
        java.lang.String str8 = compilerOptions1.sourceMapOutputPath;
        com.google.javascript.jscomp.DiagnosticType diagnosticType9 = com.google.javascript.jscomp.Compiler.MOTION_ITERATIONS_ERROR;
        java.lang.String str10 = diagnosticType9.toString();
        com.google.javascript.jscomp.CheckLevel checkLevel11 = diagnosticType9.defaultLevel;
        compilerOptions1.checkGlobalThisLevel = checkLevel11;
        com.google.javascript.jscomp.DiagnosticType diagnosticType14 = com.google.javascript.jscomp.DiagnosticType.make("Not declared as a type name", checkLevel11, "");
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(messageBundle7);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(diagnosticType9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}" + "'", str10.equals("JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}"));
        org.junit.Assert.assertTrue("'" + checkLevel11 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel11.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticType14);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setLooseTypes(true);
        boolean boolean3 = compilerOptions0.collapseVariableDeclarations;
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention4 = new com.google.javascript.jscomp.DefaultCodingConvention();
        boolean boolean6 = defaultCodingConvention4.isExported("// Input %num%");
        boolean boolean8 = defaultCodingConvention4.isSuperClassReference("");
        com.google.javascript.rhino.Node node10 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node12 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node14 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node16 = new com.google.javascript.rhino.Node((int) '4');
        node14.addChildrenToBack(node16);
        node10.addChildAfter(node12, node16);
        boolean boolean19 = node12.wasEmptyNode();
        java.lang.String str20 = defaultCodingConvention4.identifyTypeDefAssign(node12);
        boolean boolean23 = defaultCodingConvention4.isExported("Exceeded max number of code motion iterations: {0}", false);
        boolean boolean26 = defaultCodingConvention4.isExported("Not declared as a type name", false);
        compilerOptions0.setCodingConvention((com.google.javascript.jscomp.CodingConvention) defaultCodingConvention4);
        java.lang.String str28 = defaultCodingConvention4.getAbstractMethodName();
        java.util.Collection<com.google.javascript.jscomp.CodingConvention.AssertionFunctionSpec> assertionFunctionSpecCollection29 = defaultCodingConvention4.getAssertionFunctions();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNull(str20);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNull(str28);
        org.junit.Assert.assertNotNull(assertionFunctionSpecCollection29);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        com.google.javascript.jscomp.ErrorFormat errorFormat0 = com.google.javascript.jscomp.ErrorFormat.MULTILINE;
        org.junit.Assert.assertNotNull(errorFormat0);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        com.google.javascript.rhino.Node node5 = new com.google.javascript.rhino.Node(30, 35, 8);
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable6 = node5.siblings();
        com.google.javascript.rhino.Node node9 = new com.google.javascript.rhino.Node(23, node5, 150, 0);
        com.google.javascript.rhino.Node node11 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node15 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node17 = new com.google.javascript.rhino.Node((int) '4');
        node15.addChildrenToBack(node17);
        node11.addChildAfter(node13, node17);
        com.google.javascript.rhino.Node node20 = node11.cloneTree();
        com.google.javascript.rhino.Node node23 = new com.google.javascript.rhino.Node((int) (short) 1);
        com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.Node.newString("hi!");
        int int26 = node25.getCharno();
        com.google.javascript.rhino.Node node28 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node30 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node32 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node34 = new com.google.javascript.rhino.Node((int) '4');
        node32.addChildrenToBack(node34);
        node28.addChildAfter(node30, node34);
        com.google.javascript.rhino.Node node38 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node40 = new com.google.javascript.rhino.Node((int) '4');
        node38.addChildrenToBack(node40);
        com.google.javascript.rhino.Node node42 = node28.copyInformationFromForTree(node40);
        com.google.javascript.rhino.Node node43 = node28.cloneTree();
        com.google.javascript.rhino.Node node44 = node28.cloneTree();
        com.google.javascript.rhino.Node node46 = new com.google.javascript.rhino.Node((int) '4');
        node46.setLineno(36);
        com.google.javascript.rhino.Node[] nodeArray49 = new com.google.javascript.rhino.Node[] { node23, node25, node44, node46 };
        com.google.javascript.rhino.Node node52 = new com.google.javascript.rhino.Node(0, nodeArray49, 25, 14);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder53 = node52.new FileLevelJsDocBuilder();
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention54 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node56 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node58 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node60 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node62 = new com.google.javascript.rhino.Node((int) '4');
        node60.addChildrenToBack(node62);
        node56.addChildAfter(node58, node62);
        com.google.javascript.rhino.Node node66 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node68 = new com.google.javascript.rhino.Node((int) '4');
        node66.addChildrenToBack(node68);
        com.google.javascript.rhino.Node node70 = node56.copyInformationFromForTree(node68);
        com.google.javascript.rhino.Node node71 = node70.getLastChild();
        com.google.javascript.rhino.Node node73 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node75 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node77 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node79 = new com.google.javascript.rhino.Node((int) '4');
        node77.addChildrenToBack(node79);
        node73.addChildAfter(node75, node79);
        com.google.javascript.rhino.Node node83 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node85 = new com.google.javascript.rhino.Node((int) '4');
        node83.addChildrenToBack(node85);
        com.google.javascript.rhino.Node node87 = node73.copyInformationFromForTree(node85);
        node70.addChildToBack(node73);
        com.google.javascript.rhino.Node node89 = node73.cloneNode();
        boolean boolean90 = closureCodingConvention54.isVarArgsParameter(node73);
        try {
            com.google.javascript.rhino.Node node91 = new com.google.javascript.rhino.Node(15, node9, node11, node52, node73);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(nodeIterable6);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
        org.junit.Assert.assertNotNull(node42);
        org.junit.Assert.assertNotNull(node43);
        org.junit.Assert.assertNotNull(node44);
        org.junit.Assert.assertNotNull(nodeArray49);
        org.junit.Assert.assertNotNull(node70);
        org.junit.Assert.assertNull(node71);
        org.junit.Assert.assertNotNull(node87);
        org.junit.Assert.assertNotNull(node89);
        org.junit.Assert.assertTrue("'" + boolean90 + "' != '" + false + "'", boolean90 == false);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        com.google.javascript.rhino.Node node1 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node3 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node5 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node7 = new com.google.javascript.rhino.Node((int) '4');
        node5.addChildrenToBack(node7);
        node1.addChildAfter(node3, node7);
        com.google.javascript.rhino.Node node11 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node((int) '4');
        node11.addChildrenToBack(node13);
        com.google.javascript.rhino.Node node15 = node1.copyInformationFromForTree(node13);
        com.google.javascript.rhino.Node node16 = node13.getNext();
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertNull(node16);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setLooseTypes(true);
        boolean boolean3 = compilerOptions0.reserveRawExports;
        compilerOptions0.extractPrototypeMemberDeclarations = false;
        com.google.javascript.jscomp.CheckLevel checkLevel6 = compilerOptions0.aggressiveVarCheck;
        boolean boolean7 = compilerOptions0.foldConstants;
        compilerOptions0.optimizeArgumentsArray = false;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + checkLevel6 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel6.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeUnusedPrototypePropertiesInExterns = false;
        compilerOptions0.labelRenaming = true;
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        com.google.javascript.rhino.Node node1 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node3 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node5 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node7 = new com.google.javascript.rhino.Node((int) '4');
        node5.addChildrenToBack(node7);
        node1.addChildAfter(node3, node7);
        com.google.javascript.rhino.Node node11 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node((int) '4');
        node11.addChildrenToBack(node13);
        com.google.javascript.rhino.Node node15 = node1.copyInformationFromForTree(node13);
        com.google.javascript.rhino.Node node17 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node18 = node1.copyInformationFromForTree(node17);
        java.util.Set<java.lang.String> strSet19 = null;
        node18.setDirectives(strSet19);
        try {
            node18.setQuotedString();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: FAILED ASSERTION");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertNotNull(node18);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        com.google.javascript.rhino.Node node1 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node3 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node5 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node7 = new com.google.javascript.rhino.Node((int) '4');
        node5.addChildrenToBack(node7);
        node1.addChildAfter(node3, node7);
        com.google.javascript.rhino.Node node11 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node15 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node17 = new com.google.javascript.rhino.Node((int) '4');
        node15.addChildrenToBack(node17);
        node11.addChildAfter(node13, node17);
        com.google.javascript.rhino.Node node20 = node11.cloneTree();
        boolean boolean21 = node20.isNoSideEffectsCall();
        com.google.javascript.rhino.JSDocInfo jSDocInfo22 = node20.getJSDocInfo();
        com.google.javascript.rhino.Node node23 = null;
        try {
            node3.addChildBefore(node20, node23);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The existing child node of the parent should not be null.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNull(jSDocInfo22);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        java.io.File file0 = null;
        try {
            com.google.javascript.jscomp.SourceFile sourceFile1 = com.google.javascript.jscomp.SourceFile.fromFile(file0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setLooseTypes(true);
        boolean boolean3 = compilerOptions0.collapseVariableDeclarations;
        compilerOptions0.moveFunctionDeclarations = false;
        boolean boolean6 = compilerOptions0.decomposeExpressions;
        boolean boolean7 = compilerOptions0.optimizeParameters;
        java.lang.String str8 = compilerOptions0.inputDelimiter;
        java.lang.String[] strArray10 = new java.lang.String[] { "hi!" };
        java.util.LinkedHashSet<java.lang.String> strSet11 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean12 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet11, strArray10);
        compilerOptions0.stripTypes = strSet11;
        byte[] byteArray14 = null;
        compilerOptions0.inputPropertyMapSerialized = byteArray14;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "// Input %num%" + "'", str8.equals("// Input %num%"));
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        try {
            com.google.javascript.rhino.Context.checkLanguageVersion((int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Bad language version: 35");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        compiler1.disableThreads();
        com.google.javascript.jscomp.PerformanceTracker performanceTracker3 = compiler1.tracker;
        com.google.javascript.jscomp.NodeTraversal.Callback callback4 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal5 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler1, callback4);
        com.google.javascript.jscomp.Compiler compiler6 = nodeTraversal5.getCompiler();
        java.util.List<com.google.javascript.rhino.Node> nodeList7 = null;
        try {
            nodeTraversal5.traverseRoots(nodeList7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(performanceTracker3);
        org.junit.Assert.assertNotNull(compiler6);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setLooseTypes(true);
        boolean boolean3 = compilerOptions0.reserveRawExports;
        compilerOptions0.extractPrototypeMemberDeclarations = false;
        com.google.javascript.jscomp.CheckLevel checkLevel6 = compilerOptions0.aggressiveVarCheck;
        boolean boolean7 = compilerOptions0.exportTestFunctions;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + checkLevel6 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel6.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        java.io.PrintStream printStream2 = null;
        com.google.javascript.jscomp.Compiler compiler3 = new com.google.javascript.jscomp.Compiler(printStream2);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile6 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        java.io.Reader reader7 = jSSourceFile6.getCodeReader();
        com.google.javascript.jscomp.JSModule[] jSModuleArray8 = new com.google.javascript.jscomp.JSModule[] {};
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph9 = new com.google.javascript.jscomp.JSModuleGraph(jSModuleArray8);
        com.google.javascript.jscomp.CompilerOptions compilerOptions10 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions10.setLooseTypes(true);
        boolean boolean13 = compilerOptions10.collapseVariableDeclarations;
        compilerOptions10.moveFunctionDeclarations = false;
        boolean boolean16 = compilerOptions10.decomposeExpressions;
        com.google.javascript.jscomp.CheckLevel checkLevel17 = compilerOptions10.checkMissingGetCssNameLevel;
        com.google.javascript.jscomp.Result result18 = compiler3.compile(jSSourceFile6, jSModuleArray8, compilerOptions10);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile21 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile24 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        java.io.Reader reader25 = jSSourceFile24.getCodeReader();
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray26 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile6, jSSourceFile21, jSSourceFile24 };
        java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList27 = new java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile>();
        boolean boolean28 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList27, jSSourceFileArray26);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile31 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray32 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile31 };
        java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList33 = new java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile>();
        boolean boolean34 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList33, jSSourceFileArray32);
        com.google.javascript.jscomp.CompilerOptions compilerOptions35 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions35.setLooseTypes(true);
        boolean boolean38 = compilerOptions35.reserveRawExports;
        compilerOptions35.extractPrototypeMemberDeclarations = false;
        java.lang.String str41 = compilerOptions35.nameReferenceGraphPath;
        compilerOptions35.setSummaryDetailLevel(0);
        com.google.javascript.jscomp.Result result44 = compiler1.compile((java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList27, (java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList33, compilerOptions35);
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter45 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler1);
        lightweightMessageFormatter45.setColorize(true);
        org.junit.Assert.assertNotNull(jSSourceFile6);
        org.junit.Assert.assertNotNull(reader7);
        org.junit.Assert.assertNotNull(jSModuleArray8);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + checkLevel17 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel17.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(result18);
        org.junit.Assert.assertNotNull(jSSourceFile21);
        org.junit.Assert.assertNotNull(jSSourceFile24);
        org.junit.Assert.assertNotNull(reader25);
        org.junit.Assert.assertNotNull(jSSourceFileArray26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(jSSourceFile31);
        org.junit.Assert.assertNotNull(jSSourceFileArray32);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNull(str41);
        org.junit.Assert.assertNotNull(result44);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        com.google.javascript.jscomp.parsing.Config.LanguageMode languageMode0 = com.google.javascript.jscomp.parsing.Config.LanguageMode.ECMASCRIPT3;
        org.junit.Assert.assertTrue("'" + languageMode0 + "' != '" + com.google.javascript.jscomp.parsing.Config.LanguageMode.ECMASCRIPT3 + "'", languageMode0.equals(com.google.javascript.jscomp.parsing.Config.LanguageMode.ECMASCRIPT3));
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        int int0 = com.google.javascript.rhino.Node.CATCH_SCOPE_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + (-1) + "'", int0 == (-1));
    }

//    @Test
//    public void test403() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test403");
//        com.google.javascript.rhino.Context context0 = com.google.javascript.rhino.Context.getCurrentContext();
//        org.junit.Assert.assertNull(context0);
//    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile4 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile7 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        java.io.Reader reader8 = jSSourceFile7.getCodeReader();
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray9 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile4, jSSourceFile7 };
        java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList10 = new java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile>();
        boolean boolean11 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList10, jSSourceFileArray9);
        com.google.javascript.jscomp.JSModule[] jSModuleArray12 = new com.google.javascript.jscomp.JSModule[] {};
        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList13 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
        boolean boolean14 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList13, jSModuleArray12);
        com.google.javascript.jscomp.CompilerOptions compilerOptions15 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions15.setLooseTypes(true);
        boolean boolean18 = compilerOptions15.reserveRawExports;
        compilerOptions15.extractPrototypeMemberDeclarations = false;
        java.lang.String str21 = compilerOptions15.nameReferenceGraphPath;
        compilerOptions15.computeFunctionSideEffects = true;
        com.google.javascript.jscomp.CompilerOptions compilerOptions24 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions24.setLooseTypes(true);
        compilerOptions24.convertToDottedProperties = false;
        com.google.javascript.jscomp.CheckLevel checkLevel29 = compilerOptions24.reportMissingOverride;
        compilerOptions15.brokenClosureRequiresLevel = checkLevel29;
        java.util.Set<java.lang.String> strSet31 = compilerOptions15.stripTypePrefixes;
        compilerOptions15.deadAssignmentElimination = false;
        compiler1.initModules((java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList10, (java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList13, compilerOptions15);
        java.util.List<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList35 = null;
        com.google.javascript.jscomp.JSModule[] jSModuleArray36 = new com.google.javascript.jscomp.JSModule[] {};
        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList37 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
        boolean boolean38 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList37, jSModuleArray36);
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph39 = new com.google.javascript.jscomp.JSModuleGraph((java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList37);
        com.google.javascript.jscomp.CompilerOptions compilerOptions40 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions40.setLooseTypes(true);
        compilerOptions40.convertToDottedProperties = false;
        com.google.javascript.jscomp.CheckLevel checkLevel45 = compilerOptions40.reportMissingOverride;
        boolean boolean46 = compilerOptions40.rewriteFunctionExpressions;
        try {
            compiler1.initModules(jSSourceFileList35, (java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList37, compilerOptions40);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile4);
        org.junit.Assert.assertNotNull(jSSourceFile7);
        org.junit.Assert.assertNotNull(reader8);
        org.junit.Assert.assertNotNull(jSSourceFileArray9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(jSModuleArray12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertTrue("'" + checkLevel29 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel29.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(strSet31);
        org.junit.Assert.assertNotNull(jSModuleArray36);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + checkLevel45 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel45.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        int int0 = com.google.javascript.rhino.Node.FUNCTION_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 5 + "'", int0 == 5);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setLooseTypes(true);
        compilerOptions0.renamePrefix = "hi!";
        compilerOptions0.checkControlStructures = false;
        boolean boolean7 = compilerOptions0.removeTryCatchFinally;
        boolean boolean8 = compilerOptions0.markAsCompiled;
        boolean boolean9 = compilerOptions0.removeTryCatchFinally;
        java.util.Set<java.lang.String> strSet10 = compilerOptions0.stripTypePrefixes;
        com.google.javascript.jscomp.CompilerOptions.AliasTransformationHandler aliasTransformationHandler11 = null;
        compilerOptions0.setAliasTransformationHandler(aliasTransformationHandler11);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(strSet10);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        com.google.javascript.rhino.Node node1 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node3 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node5 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node7 = new com.google.javascript.rhino.Node((int) '4');
        node5.addChildrenToBack(node7);
        node1.addChildAfter(node3, node7);
        com.google.javascript.rhino.Node node11 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node((int) '4');
        node11.addChildrenToBack(node13);
        com.google.javascript.rhino.Node node15 = node1.copyInformationFromForTree(node13);
        com.google.javascript.rhino.Node node16 = node1.cloneTree();
        com.google.javascript.rhino.Node node18 = new com.google.javascript.rhino.Node((int) '4');
        node16.addChildrenToBack(node18);
        try {
            node16.setQuotedString();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: FAILED ASSERTION");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertNotNull(node16);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        com.google.javascript.rhino.Node node1 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node3 = new com.google.javascript.rhino.Node((int) '4');
        node1.addChildrenToBack(node3);
        com.google.javascript.rhino.Node node5 = node1.getLastChild();
        try {
            double double6 = node5.getDouble();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: INSTANCEOF is not a number node");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(node5);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeUnusedPrototypePropertiesInExterns = false;
        boolean boolean3 = compilerOptions0.markAsCompiled;
        compilerOptions0.setDefineToBooleanLiteral("", true);
        boolean boolean7 = compilerOptions0.optimizeReturns;
        java.lang.String str8 = compilerOptions0.checkMissingGetCssNameBlacklist;
        com.google.javascript.jscomp.SourceMap.DetailLevel detailLevel9 = compilerOptions0.sourceMapDetailLevel;
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention10 = new com.google.javascript.jscomp.DefaultCodingConvention();
        boolean boolean12 = defaultCodingConvention10.isConstant("hi!");
        java.lang.String str13 = defaultCodingConvention10.getExportSymbolFunction();
        java.lang.String str14 = defaultCodingConvention10.getDelegateSuperclassName();
        compilerOptions0.setCodingConvention((com.google.javascript.jscomp.CodingConvention) defaultCodingConvention10);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(detailLevel9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertNull(str14);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        com.google.javascript.rhino.Node node1 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node3 = new com.google.javascript.rhino.Node((int) '4');
        node1.addChildrenToBack(node3);
        com.google.javascript.rhino.Node node5 = node1.getLastChild();
        node1.setLineno(7);
        boolean boolean8 = node1.hasMoreThanOneChild();
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setLooseTypes(true);
        boolean boolean3 = compilerOptions0.collapseVariableDeclarations;
        boolean boolean4 = compilerOptions0.aliasKeywords;
        com.google.javascript.jscomp.AnonymousFunctionNamingPolicy anonymousFunctionNamingPolicy5 = com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.UNMAPPED;
        compilerOptions0.anonymousFunctionNaming = anonymousFunctionNamingPolicy5;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + anonymousFunctionNamingPolicy5 + "' != '" + com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.UNMAPPED + "'", anonymousFunctionNamingPolicy5.equals(com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.UNMAPPED));
    }

//    @Test
//    public void test412() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test412");
//        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.EXTERNS_VALIDATION;
//        com.google.javascript.jscomp.DiagnosticGroups.NON_STANDARD_JSDOC = diagnosticGroup0;
//        com.google.javascript.jscomp.DiagnosticGroups.GLOBAL_THIS = diagnosticGroup0;
//        java.lang.String str3 = diagnosticGroup0.toString();
//        org.junit.Assert.assertNotNull(diagnosticGroup0);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "DiagnosticGroup<externsValidation>" + "'", str3.equals("DiagnosticGroup<externsValidation>"));
//    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setLooseTypes(true);
        boolean boolean3 = compilerOptions0.reserveRawExports;
        com.google.javascript.jscomp.CheckLevel checkLevel4 = null;
        compilerOptions0.checkUnreachableCode = checkLevel4;
        boolean boolean6 = compilerOptions0.devirtualizePrototypeMethods;
        boolean boolean7 = compilerOptions0.removeDeadCode;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setLooseTypes(true);
        boolean boolean3 = compilerOptions0.collapseVariableDeclarations;
        boolean boolean4 = compilerOptions0.generateExports;
        boolean boolean5 = compilerOptions0.checkTypes;
        compilerOptions0.setDefineToDoubleLiteral("error reporter", 0.0d);
        compilerOptions0.gatherCssNames = true;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

//    @Test
//    public void test415() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test415");
//        try {
//            com.google.javascript.rhino.Context.exit();
//            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Calling Context.exit without previous Context.enter");
//        } catch (java.lang.RuntimeException e) {
//        }
//    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeUnusedPrototypePropertiesInExterns = false;
        boolean boolean3 = compilerOptions0.markAsCompiled;
        compilerOptions0.setDefineToBooleanLiteral("", true);
        boolean boolean7 = compilerOptions0.optimizeReturns;
        compilerOptions0.enableExternExports(true);
        boolean boolean10 = compilerOptions0.crossModuleCodeMotion;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setLooseTypes(true);
        boolean boolean3 = compilerOptions0.reserveRawExports;
        com.google.javascript.jscomp.CheckLevel checkLevel4 = null;
        compilerOptions0.checkUnreachableCode = checkLevel4;
        com.google.javascript.jscomp.MessageBundle messageBundle6 = compilerOptions0.messageBundle;
        java.lang.String str7 = compilerOptions0.sourceMapOutputPath;
        compilerOptions0.aliasKeywords = true;
        boolean boolean10 = compilerOptions0.checkUnusedPropertiesEarly;
        com.google.javascript.jscomp.CheckLevel checkLevel11 = compilerOptions0.checkProvides;
        com.google.javascript.jscomp.SourceMap.DetailLevel detailLevel12 = compilerOptions0.sourceMapDetailLevel;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(messageBundle6);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + checkLevel11 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel11.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(detailLevel12);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        com.google.javascript.rhino.Node node1 = new com.google.javascript.rhino.Node((int) '4');
        node1.setLineno(36);
        com.google.javascript.rhino.Node node4 = node1.getParent();
        int int5 = node1.getChildCount();
        boolean boolean6 = node1.isSyntheticBlock();
        org.junit.Assert.assertNull(node4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        com.google.javascript.rhino.EcmaError ecmaError1 = com.google.javascript.rhino.ScriptRuntime.typeError("4");
        java.lang.String str2 = ecmaError1.getName();
        java.lang.Throwable[] throwableArray3 = ecmaError1.getSuppressed();
        java.lang.String str4 = com.google.javascript.rhino.ScriptRuntime.toString((java.lang.Object) throwableArray3);
        org.junit.Assert.assertNotNull(ecmaError1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "TypeError" + "'", str2.equals("TypeError"));
        org.junit.Assert.assertNotNull(throwableArray3);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        com.google.javascript.rhino.EvaluatorException evaluatorException3 = new com.google.javascript.rhino.EvaluatorException("hi!", "hi!", 0);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setLooseTypes(true);
        boolean boolean3 = compilerOptions0.reserveRawExports;
        com.google.javascript.jscomp.CheckLevel checkLevel4 = null;
        compilerOptions0.checkUnreachableCode = checkLevel4;
        boolean boolean6 = compilerOptions0.devirtualizePrototypeMethods;
        compilerOptions0.setColorizeErrorOutput(true);
        compilerOptions0.setTweakToNumberLiteral("language version", (int) (byte) 10);
        compilerOptions0.checkControlStructures = false;
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup14 = com.google.javascript.jscomp.DiagnosticGroups.STRICT_MODULE_DEP_CHECK;
        com.google.javascript.jscomp.DiagnosticGroups.MISSING_PROPERTIES = diagnosticGroup14;
        com.google.javascript.jscomp.DiagnosticGroups.CHECK_TYPES = diagnosticGroup14;
        com.google.javascript.jscomp.CheckLevel checkLevel17 = null;
        compilerOptions0.setWarningLevel(diagnosticGroup14, checkLevel17);
        com.google.javascript.jscomp.DiagnosticGroups.VISIBILITY = diagnosticGroup14;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(diagnosticGroup14);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        com.google.javascript.jscomp.SourceAst sourceAst0 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(sourceAst0, "", false);
        com.google.javascript.jscomp.JSModule jSModule4 = compilerInput3.getModule();
        try {
            compilerInput3.clearAst();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(jSModule4);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        int int0 = com.google.javascript.rhino.Node.TARGETBLOCK_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 22 + "'", int0 == 22);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile4 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        java.io.Reader reader5 = jSSourceFile4.getCodeReader();
        com.google.javascript.jscomp.JSModule[] jSModuleArray6 = new com.google.javascript.jscomp.JSModule[] {};
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph7 = new com.google.javascript.jscomp.JSModuleGraph(jSModuleArray6);
        com.google.javascript.jscomp.CompilerOptions compilerOptions8 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions8.setLooseTypes(true);
        boolean boolean11 = compilerOptions8.collapseVariableDeclarations;
        compilerOptions8.moveFunctionDeclarations = false;
        boolean boolean14 = compilerOptions8.decomposeExpressions;
        com.google.javascript.jscomp.CheckLevel checkLevel15 = compilerOptions8.checkMissingGetCssNameLevel;
        com.google.javascript.jscomp.Result result16 = compiler1.compile(jSSourceFile4, jSModuleArray6, compilerOptions8);
        compiler1.disableThreads();
        com.google.javascript.jscomp.Compiler.CodeBuilder codeBuilder18 = new com.google.javascript.jscomp.Compiler.CodeBuilder();
        com.google.javascript.rhino.Node node21 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node23 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node25 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node27 = new com.google.javascript.rhino.Node((int) '4');
        node25.addChildrenToBack(node27);
        node21.addChildAfter(node23, node27);
        com.google.javascript.rhino.Node node31 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node33 = new com.google.javascript.rhino.Node((int) '4');
        node31.addChildrenToBack(node33);
        com.google.javascript.rhino.Node node35 = node21.copyInformationFromForTree(node33);
        com.google.javascript.rhino.Node node36 = node21.cloneTree();
        com.google.javascript.rhino.Node node40 = new com.google.javascript.rhino.Node(30, 35, 8);
        com.google.javascript.rhino.Node node41 = node40.getLastChild();
        node36.addChildToFront(node40);
        com.google.javascript.rhino.Node.AncestorIterable ancestorIterable43 = node36.getAncestors();
        try {
            compiler1.toSource(codeBuilder18, 1, node36);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: java.lang.Error: Unknown type 52\nINSTANCEOF\n    NEW 35\n");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile4);
        org.junit.Assert.assertNotNull(reader5);
        org.junit.Assert.assertNotNull(jSModuleArray6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + checkLevel15 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel15.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(result16);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertNotNull(node36);
        org.junit.Assert.assertNull(node41);
        org.junit.Assert.assertNotNull(ancestorIterable43);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        try {
            java.lang.String str2 = com.google.javascript.rhino.ScriptRuntime.escapeString("false", '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: FAILED ASSERTION");
        } catch (java.lang.IllegalStateException e) {
        }
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile4 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile7 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        java.io.Reader reader8 = jSSourceFile7.getCodeReader();
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray9 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile4, jSSourceFile7 };
        java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList10 = new java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile>();
        boolean boolean11 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList10, jSSourceFileArray9);
        com.google.javascript.jscomp.JSModule[] jSModuleArray12 = new com.google.javascript.jscomp.JSModule[] {};
        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList13 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
        boolean boolean14 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList13, jSModuleArray12);
        com.google.javascript.jscomp.CompilerOptions compilerOptions15 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions15.setLooseTypes(true);
        boolean boolean18 = compilerOptions15.reserveRawExports;
        compilerOptions15.extractPrototypeMemberDeclarations = false;
        java.lang.String str21 = compilerOptions15.nameReferenceGraphPath;
        compilerOptions15.computeFunctionSideEffects = true;
        com.google.javascript.jscomp.CompilerOptions compilerOptions24 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions24.setLooseTypes(true);
        compilerOptions24.convertToDottedProperties = false;
        com.google.javascript.jscomp.CheckLevel checkLevel29 = compilerOptions24.reportMissingOverride;
        compilerOptions15.brokenClosureRequiresLevel = checkLevel29;
        java.util.Set<java.lang.String> strSet31 = compilerOptions15.stripTypePrefixes;
        compilerOptions15.deadAssignmentElimination = false;
        compiler1.initModules((java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList10, (java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList13, compilerOptions15);
        compiler1.disableThreads();
        java.util.logging.Logger logger36 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager37 = new com.google.javascript.jscomp.LoggerErrorManager(logger36);
        com.google.javascript.jscomp.CompilerOptions compilerOptions38 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.common.collect.Multimap<com.google.javascript.jscomp.CustomPassExecutionTime, com.google.javascript.jscomp.CompilerPass> customPassExecutionTimeMultimap39 = compilerOptions38.customPasses;
        com.google.javascript.jscomp.CheckLevel checkLevel40 = compilerOptions38.checkGlobalNamesLevel;
        com.google.javascript.rhino.Node node43 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node45 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node47 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node49 = new com.google.javascript.rhino.Node((int) '4');
        node47.addChildrenToBack(node49);
        node43.addChildAfter(node45, node49);
        com.google.javascript.rhino.Node node53 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node55 = new com.google.javascript.rhino.Node((int) '4');
        node53.addChildrenToBack(node55);
        com.google.javascript.rhino.Node node57 = node43.copyInformationFromForTree(node55);
        com.google.javascript.jscomp.DiagnosticType diagnosticType58 = com.google.javascript.jscomp.Compiler.MOTION_ITERATIONS_ERROR;
        java.lang.String str59 = diagnosticType58.toString();
        java.lang.String[] strArray60 = null;
        com.google.javascript.jscomp.JSError jSError61 = com.google.javascript.jscomp.JSError.make("", node55, diagnosticType58, strArray60);
        java.lang.String str62 = jSError61.toString();
        loggerErrorManager37.println(checkLevel40, jSError61);
        compiler1.report(jSError61);
        org.junit.Assert.assertNotNull(jSSourceFile4);
        org.junit.Assert.assertNotNull(jSSourceFile7);
        org.junit.Assert.assertNotNull(reader8);
        org.junit.Assert.assertNotNull(jSSourceFileArray9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(jSModuleArray12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertTrue("'" + checkLevel29 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel29.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(strSet31);
        org.junit.Assert.assertNull(customPassExecutionTimeMultimap39);
        org.junit.Assert.assertTrue("'" + checkLevel40 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel40.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(node57);
        org.junit.Assert.assertNotNull(diagnosticType58);
        org.junit.Assert.assertTrue("'" + str59 + "' != '" + "JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}" + "'", str59.equals("JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}"));
        org.junit.Assert.assertNotNull(jSError61);
        org.junit.Assert.assertTrue("'" + str62 + "' != '" + "JSC_OPTIMIZE_LOOP_ERROR. Exceeded max number of code motion iterations: {0} at (unknown source) line (unknown line) : (unknown column)" + "'", str62.equals("JSC_OPTIMIZE_LOOP_ERROR. Exceeded max number of code motion iterations: {0} at (unknown source) line (unknown line) : (unknown column)"));
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setLooseTypes(true);
        boolean boolean3 = compilerOptions0.reserveRawExports;
        boolean boolean4 = compilerOptions0.flowSensitiveInlineVariables;
        compilerOptions0.rewriteFunctionExpressions = true;
        java.io.PrintStream printStream7 = null;
        com.google.javascript.jscomp.Compiler compiler8 = new com.google.javascript.jscomp.Compiler(printStream7);
        compiler8.disableThreads();
        com.google.javascript.jscomp.PerformanceTracker performanceTracker10 = compiler8.tracker;
        com.google.javascript.jscomp.NodeTraversal.Callback callback11 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal12 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler8, callback11);
        com.google.javascript.rhino.Node node14 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node16 = new com.google.javascript.rhino.Node((int) '4');
        node14.addChildrenToBack(node16);
        com.google.javascript.jscomp.DiagnosticType diagnosticType20 = com.google.javascript.jscomp.DiagnosticType.warning("hi!", "hi!");
        com.google.javascript.jscomp.DiagnosticType diagnosticType21 = com.google.javascript.jscomp.Compiler.MOTION_ITERATIONS_ERROR;
        int int22 = diagnosticType20.compareTo(diagnosticType21);
        java.lang.String[] strArray23 = com.google.javascript.rhino.ScriptRuntime.emptyStrings;
        com.google.javascript.jscomp.JSError jSError24 = nodeTraversal12.makeError(node16, diagnosticType20, strArray23);
        com.google.javascript.jscomp.CompilerOptions compilerOptions25 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions25.setLooseTypes(true);
        boolean boolean28 = compilerOptions25.collapseVariableDeclarations;
        boolean boolean29 = compilerOptions25.generateExports;
        com.google.javascript.jscomp.SourceMap.DetailLevel detailLevel30 = compilerOptions25.sourceMapDetailLevel;
        com.google.javascript.jscomp.CheckLevel checkLevel31 = null;
        compilerOptions25.brokenClosureRequiresLevel = checkLevel31;
        java.util.Set<java.lang.String> strSet33 = compilerOptions25.aliasableStrings;
        java.lang.RuntimeException runtimeException34 = com.google.javascript.rhino.ScriptRuntime.undefWriteError((java.lang.Object) compilerOptions0, (java.lang.Object) strArray23, (java.lang.Object) compilerOptions25);
        compilerOptions0.aliasExternals = true;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(performanceTracker10);
        org.junit.Assert.assertNotNull(diagnosticType20);
        org.junit.Assert.assertNotNull(diagnosticType21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 30 + "'", int22 == 30);
        org.junit.Assert.assertNotNull(strArray23);
        org.junit.Assert.assertNotNull(jSError24);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(detailLevel30);
        org.junit.Assert.assertNotNull(strSet33);
        org.junit.Assert.assertNotNull(runtimeException34);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        com.google.javascript.rhino.Context context0 = new com.google.javascript.rhino.Context();
        context0.setCompileFunctionsWithDynamicScope(false);
        int int3 = context0.getOptimizationLevel();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        int int0 = com.google.javascript.rhino.Node.DIRECTCALL_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 26 + "'", int0 == 26);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setLooseTypes(true);
        compilerOptions0.renamePrefix = "hi!";
        java.lang.String str5 = compilerOptions0.locale;
        compilerOptions0.setNameAnonymousFunctionsOnly(false);
        com.google.javascript.jscomp.AnonymousFunctionNamingPolicy anonymousFunctionNamingPolicy8 = com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF;
        compilerOptions0.anonymousFunctionNaming = anonymousFunctionNamingPolicy8;
        com.google.javascript.jscomp.CompilerOptions compilerOptions10 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions10.setLooseTypes(true);
        boolean boolean13 = compilerOptions10.reserveRawExports;
        compilerOptions10.extractPrototypeMemberDeclarations = false;
        java.lang.String str16 = compilerOptions10.nameReferenceGraphPath;
        compilerOptions10.computeFunctionSideEffects = true;
        com.google.javascript.jscomp.CompilerOptions compilerOptions19 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions19.setLooseTypes(true);
        compilerOptions19.convertToDottedProperties = false;
        com.google.javascript.jscomp.CheckLevel checkLevel24 = compilerOptions19.reportMissingOverride;
        compilerOptions10.brokenClosureRequiresLevel = checkLevel24;
        java.util.Set<java.lang.String> strSet26 = compilerOptions10.stripTypePrefixes;
        compilerOptions0.aliasableStrings = strSet26;
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertTrue("'" + anonymousFunctionNamingPolicy8 + "' != '" + com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF + "'", anonymousFunctionNamingPolicy8.equals(com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertTrue("'" + checkLevel24 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel24.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(strSet26);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        com.google.javascript.jscomp.DiagnosticType diagnosticType0 = com.google.javascript.jscomp.Compiler.MOTION_ITERATIONS_ERROR;
        com.google.javascript.jscomp.DiagnosticType diagnosticType1 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        com.google.javascript.jscomp.DiagnosticType diagnosticType2 = com.google.javascript.jscomp.Compiler.MOTION_ITERATIONS_ERROR;
        java.lang.String str3 = diagnosticType2.toString();
        com.google.javascript.jscomp.DiagnosticType diagnosticType6 = com.google.javascript.jscomp.DiagnosticType.warning("hi!", "hi!");
        com.google.javascript.jscomp.DiagnosticType diagnosticType7 = com.google.javascript.jscomp.Compiler.MOTION_ITERATIONS_ERROR;
        int int8 = diagnosticType6.compareTo(diagnosticType7);
        com.google.javascript.jscomp.DiagnosticType[] diagnosticTypeArray9 = new com.google.javascript.jscomp.DiagnosticType[] { diagnosticType0, diagnosticType1, diagnosticType2, diagnosticType6 };
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup10 = new com.google.javascript.jscomp.DiagnosticGroup(diagnosticTypeArray9);
        com.google.javascript.jscomp.DiagnosticGroups.CHECK_TYPES = diagnosticGroup10;
        org.junit.Assert.assertNotNull(diagnosticType0);
        org.junit.Assert.assertNotNull(diagnosticType1);
        org.junit.Assert.assertNotNull(diagnosticType2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}" + "'", str3.equals("JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}"));
        org.junit.Assert.assertNotNull(diagnosticType6);
        org.junit.Assert.assertNotNull(diagnosticType7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 30 + "'", int8 == 30);
        org.junit.Assert.assertNotNull(diagnosticTypeArray9);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        long long1 = com.google.javascript.rhino.ScriptRuntime.testUint32String("");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1L) + "'", long1 == (-1L));
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        com.google.javascript.rhino.Node node1 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node3 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node5 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node7 = new com.google.javascript.rhino.Node((int) '4');
        node5.addChildrenToBack(node7);
        node1.addChildAfter(node3, node7);
        com.google.javascript.rhino.Node node11 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node((int) '4');
        node11.addChildrenToBack(node13);
        com.google.javascript.rhino.Node node15 = node1.copyInformationFromForTree(node13);
        com.google.javascript.rhino.Node node16 = node1.cloneTree();
        com.google.javascript.rhino.Node node20 = new com.google.javascript.rhino.Node(30, 35, 8);
        com.google.javascript.rhino.Node node21 = node20.getLastChild();
        node16.addChildToFront(node20);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder23 = node20.getJsDocBuilderForNode();
        fileLevelJsDocBuilder23.append("null");
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertNull(node21);
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder23);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        java.lang.String[] strArray0 = com.google.javascript.rhino.ScriptRuntime.emptyStrings;
        java.lang.Class<?> wildcardClass1 = strArray0.getClass();
        org.junit.Assert.assertNotNull(strArray0);
        org.junit.Assert.assertNotNull(wildcardClass1);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setLooseTypes(true);
        boolean boolean3 = compilerOptions0.reserveRawExports;
        compilerOptions0.extractPrototypeMemberDeclarations = false;
        boolean boolean6 = compilerOptions0.disambiguateProperties;
        com.google.javascript.jscomp.CheckLevel checkLevel7 = compilerOptions0.aggressiveVarCheck;
        compilerOptions0.labelRenaming = false;
        compilerOptions0.specializeInitialModule = true;
        compilerOptions0.checkCaja = false;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + checkLevel7 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel7.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray0 = new com.google.javascript.jscomp.WarningsGuard[] {};
        java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard> warningsGuardList1 = new java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList1, warningsGuardArray0);
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard3 = new com.google.javascript.jscomp.ComposeWarningsGuard((java.util.List<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList1);
        com.google.javascript.rhino.Node node6 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node8 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node10 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node12 = new com.google.javascript.rhino.Node((int) '4');
        node10.addChildrenToBack(node12);
        node6.addChildAfter(node8, node12);
        com.google.javascript.rhino.Node node16 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node18 = new com.google.javascript.rhino.Node((int) '4');
        node16.addChildrenToBack(node18);
        com.google.javascript.rhino.Node node20 = node6.copyInformationFromForTree(node18);
        com.google.javascript.jscomp.DiagnosticType diagnosticType21 = com.google.javascript.jscomp.Compiler.MOTION_ITERATIONS_ERROR;
        java.lang.String str22 = diagnosticType21.toString();
        java.lang.String[] strArray23 = null;
        com.google.javascript.jscomp.JSError jSError24 = com.google.javascript.jscomp.JSError.make("", node18, diagnosticType21, strArray23);
        com.google.javascript.jscomp.CheckLevel checkLevel25 = composeWarningsGuard3.level(jSError24);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup27 = com.google.javascript.jscomp.DiagnosticGroups.MISSING_PROPERTIES;
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup28 = com.google.javascript.jscomp.DiagnosticGroups.STRICT_MODULE_DEP_CHECK;
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup29 = com.google.javascript.jscomp.DiagnosticGroups.STRICT_MODULE_DEP_CHECK;
        com.google.javascript.jscomp.DiagnosticGroups.TYPE_INVALIDATION = diagnosticGroup29;
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup31 = com.google.javascript.jscomp.DiagnosticGroups.MISSING_PROPERTIES;
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup32 = com.google.javascript.jscomp.DiagnosticGroups.STRICT_MODULE_DEP_CHECK;
        com.google.javascript.jscomp.DiagnosticGroups.MISSING_PROPERTIES = diagnosticGroup32;
        com.google.javascript.jscomp.DiagnosticGroups.STRICT_MODULE_DEP_CHECK = diagnosticGroup32;
        com.google.javascript.jscomp.DiagnosticGroup[] diagnosticGroupArray35 = new com.google.javascript.jscomp.DiagnosticGroup[] { diagnosticGroup27, diagnosticGroup28, diagnosticGroup29, diagnosticGroup31, diagnosticGroup32 };
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup36 = new com.google.javascript.jscomp.DiagnosticGroup("4", diagnosticGroupArray35);
        com.google.javascript.jscomp.DiagnosticGroups.TYPE_INVALIDATION = diagnosticGroup36;
        boolean boolean38 = composeWarningsGuard3.enables(diagnosticGroup36);
        com.google.javascript.jscomp.CompilerOptions compilerOptions39 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions39.setLooseTypes(true);
        compilerOptions39.convertToDottedProperties = false;
        com.google.javascript.jscomp.CheckLevel checkLevel44 = compilerOptions39.reportMissingOverride;
        boolean boolean45 = compilerOptions39.aliasAllStrings;
        compilerOptions39.instrumentationTemplate = "hi!";
        boolean boolean48 = compilerOptions39.exportTestFunctions;
        java.util.Map<java.lang.String, com.google.javascript.rhino.Node> strMap49 = compilerOptions39.getDefineReplacements();
        java.lang.RuntimeException runtimeException50 = com.google.javascript.rhino.ScriptRuntime.undefReadError((java.lang.Object) composeWarningsGuard3, (java.lang.Object) strMap49);
        java.lang.String str51 = composeWarningsGuard3.toString();
        org.junit.Assert.assertNotNull(warningsGuardArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNotNull(diagnosticType21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}" + "'", str22.equals("JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}"));
        org.junit.Assert.assertNotNull(jSError24);
        org.junit.Assert.assertNull(checkLevel25);
        org.junit.Assert.assertNotNull(diagnosticGroup27);
        org.junit.Assert.assertNotNull(diagnosticGroup28);
        org.junit.Assert.assertNotNull(diagnosticGroup29);
        org.junit.Assert.assertNotNull(diagnosticGroup31);
        org.junit.Assert.assertNotNull(diagnosticGroup32);
        org.junit.Assert.assertNotNull(diagnosticGroupArray35);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + checkLevel44 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel44.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(strMap49);
        org.junit.Assert.assertNotNull(runtimeException50);
        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "" + "'", str51.equals(""));
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        int int0 = com.google.javascript.rhino.Node.SKIP_INDEXES_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 30 + "'", int0 == 30);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        com.google.javascript.rhino.Node node2 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node4 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node6 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node8 = new com.google.javascript.rhino.Node((int) '4');
        node6.addChildrenToBack(node8);
        node2.addChildAfter(node4, node8);
        com.google.javascript.rhino.Node node12 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node14 = new com.google.javascript.rhino.Node((int) '4');
        node12.addChildrenToBack(node14);
        com.google.javascript.rhino.Node node16 = node2.copyInformationFromForTree(node14);
        com.google.javascript.jscomp.DiagnosticType diagnosticType17 = com.google.javascript.jscomp.Compiler.MOTION_ITERATIONS_ERROR;
        java.lang.String str18 = diagnosticType17.toString();
        java.lang.String[] strArray19 = null;
        com.google.javascript.jscomp.JSError jSError20 = com.google.javascript.jscomp.JSError.make("", node14, diagnosticType17, strArray19);
        java.lang.String str21 = jSError20.description;
        java.lang.String str22 = jSError20.toString();
        java.lang.String str23 = jSError20.description;
        com.google.javascript.rhino.Node node26 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node28 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node30 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node32 = new com.google.javascript.rhino.Node((int) '4');
        node30.addChildrenToBack(node32);
        node26.addChildAfter(node28, node32);
        com.google.javascript.rhino.Node node36 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node38 = new com.google.javascript.rhino.Node((int) '4');
        node36.addChildrenToBack(node38);
        com.google.javascript.rhino.Node node40 = node26.copyInformationFromForTree(node38);
        com.google.javascript.jscomp.DiagnosticType diagnosticType41 = com.google.javascript.jscomp.Compiler.MOTION_ITERATIONS_ERROR;
        java.lang.String str42 = diagnosticType41.toString();
        java.lang.String[] strArray43 = null;
        com.google.javascript.jscomp.JSError jSError44 = com.google.javascript.jscomp.JSError.make("", node38, diagnosticType41, strArray43);
        java.lang.String str45 = jSError44.description;
        java.lang.String str46 = jSError44.sourceName;
        com.google.javascript.jscomp.CheckLevel checkLevel47 = jSError44.level;
        com.google.javascript.jscomp.MessageFormatter messageFormatter48 = null;
        try {
            java.lang.String str49 = jSError20.format(checkLevel47, messageFormatter48);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertNotNull(diagnosticType17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}" + "'", str18.equals("JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}"));
        org.junit.Assert.assertNotNull(jSError20);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "Exceeded max number of code motion iterations: {0}" + "'", str21.equals("Exceeded max number of code motion iterations: {0}"));
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "JSC_OPTIMIZE_LOOP_ERROR. Exceeded max number of code motion iterations: {0} at (unknown source) line (unknown line) : (unknown column)" + "'", str22.equals("JSC_OPTIMIZE_LOOP_ERROR. Exceeded max number of code motion iterations: {0} at (unknown source) line (unknown line) : (unknown column)"));
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "Exceeded max number of code motion iterations: {0}" + "'", str23.equals("Exceeded max number of code motion iterations: {0}"));
        org.junit.Assert.assertNotNull(node40);
        org.junit.Assert.assertNotNull(diagnosticType41);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}" + "'", str42.equals("JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}"));
        org.junit.Assert.assertNotNull(jSError44);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "Exceeded max number of code motion iterations: {0}" + "'", str45.equals("Exceeded max number of code motion iterations: {0}"));
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "" + "'", str46.equals(""));
        org.junit.Assert.assertTrue("'" + checkLevel47 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel47.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        java.io.InputStream inputStream2 = null;
        try {
            com.google.javascript.jscomp.SourceFile sourceFile3 = com.google.javascript.jscomp.SourceFile.fromInputStream("error reporter", "<No stack trace available>", inputStream2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        com.google.javascript.rhino.Context context0 = new com.google.javascript.rhino.Context();
        context0.setGeneratingSource(true);
        com.google.javascript.jscomp.CompilerOptions.TracerMode tracerMode3 = com.google.javascript.jscomp.CompilerOptions.TracerMode.FAST;
        context0.removeThreadLocal((java.lang.Object) tracerMode3);
        boolean boolean5 = context0.isGeneratingSource();
        java.util.Locale locale6 = context0.getLocale();
        context0.setInstructionObserverThreshold(4095);
        org.junit.Assert.assertTrue("'" + tracerMode3 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TracerMode.FAST + "'", tracerMode3.equals(com.google.javascript.jscomp.CompilerOptions.TracerMode.FAST));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(locale6);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        compiler1.disableThreads();
        com.google.javascript.jscomp.PerformanceTracker performanceTracker3 = compiler1.tracker;
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter4 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler1);
        com.google.javascript.jscomp.CompilerOptions compilerOptions8 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions8.setLooseTypes(true);
        boolean boolean11 = compilerOptions8.reserveRawExports;
        compilerOptions8.extractPrototypeMemberDeclarations = false;
        java.lang.String str14 = compilerOptions8.nameReferenceGraphPath;
        compilerOptions8.computeFunctionSideEffects = true;
        com.google.javascript.jscomp.CompilerOptions compilerOptions17 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions17.setLooseTypes(true);
        compilerOptions17.convertToDottedProperties = false;
        com.google.javascript.jscomp.CheckLevel checkLevel22 = compilerOptions17.reportMissingOverride;
        compilerOptions8.brokenClosureRequiresLevel = checkLevel22;
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup24 = com.google.javascript.jscomp.DiagnosticGroups.STRICT_MODULE_DEP_CHECK;
        com.google.javascript.jscomp.DiagnosticGroups.MISSING_PROPERTIES = diagnosticGroup24;
        com.google.javascript.jscomp.DiagnosticGroups.STRICT_MODULE_DEP_CHECK = diagnosticGroup24;
        com.google.javascript.jscomp.DiagnosticGroups.INVALID_CASTS = diagnosticGroup24;
        com.google.javascript.jscomp.DiagnosticType diagnosticType30 = com.google.javascript.jscomp.DiagnosticType.warning("hi!", "hi!");
        java.lang.String str31 = diagnosticType30.key;
        boolean boolean32 = diagnosticGroup24.matches(diagnosticType30);
        java.io.PrintStream printStream33 = null;
        com.google.javascript.jscomp.Compiler compiler34 = new com.google.javascript.jscomp.Compiler(printStream33);
        compiler34.disableThreads();
        com.google.javascript.jscomp.PerformanceTracker performanceTracker36 = compiler34.tracker;
        com.google.javascript.jscomp.NodeTraversal.Callback callback37 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal38 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler34, callback37);
        com.google.javascript.rhino.Node node40 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node42 = new com.google.javascript.rhino.Node((int) '4');
        node40.addChildrenToBack(node42);
        com.google.javascript.jscomp.DiagnosticType diagnosticType46 = com.google.javascript.jscomp.DiagnosticType.warning("hi!", "hi!");
        com.google.javascript.jscomp.DiagnosticType diagnosticType47 = com.google.javascript.jscomp.Compiler.MOTION_ITERATIONS_ERROR;
        int int48 = diagnosticType46.compareTo(diagnosticType47);
        java.lang.String[] strArray49 = com.google.javascript.rhino.ScriptRuntime.emptyStrings;
        com.google.javascript.jscomp.JSError jSError50 = nodeTraversal38.makeError(node42, diagnosticType46, strArray49);
        com.google.javascript.jscomp.JSError jSError51 = com.google.javascript.jscomp.JSError.make("// Input %num%", 110, 16, checkLevel22, diagnosticType30, strArray49);
        try {
            java.lang.String str52 = lightweightMessageFormatter4.formatWarning(jSError51);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(performanceTracker3);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertTrue("'" + checkLevel22 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel22.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(diagnosticGroup24);
        org.junit.Assert.assertNotNull(diagnosticType30);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "hi!" + "'", str31.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNull(performanceTracker36);
        org.junit.Assert.assertNotNull(diagnosticType46);
        org.junit.Assert.assertNotNull(diagnosticType47);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 30 + "'", int48 == 30);
        org.junit.Assert.assertNotNull(strArray49);
        org.junit.Assert.assertNotNull(jSError50);
        org.junit.Assert.assertNotNull(jSError51);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        com.google.javascript.jscomp.SourceAst sourceAst0 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(sourceAst0, "", false);
        com.google.javascript.jscomp.JSModule jSModule4 = compilerInput3.getModule();
        com.google.javascript.jscomp.CompilerInput compilerInput7 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput3, "JSC_OPTIMIZE_LOOP_ERROR. Exceeded max number of code motion iterations: {0} at (unknown source) line (unknown line) : (unknown column)", false);
        try {
            compilerInput3.clearAst();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(jSModule4);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        com.google.javascript.rhino.EvaluatorException evaluatorException1 = new com.google.javascript.rhino.EvaluatorException("language version");
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        java.io.InputStream inputStream1 = null;
        try {
            com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromInputStream("Exceeded max number of code motion iterations: {0}", inputStream1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        java.io.PrintStream printStream2 = null;
        com.google.javascript.jscomp.Compiler compiler3 = new com.google.javascript.jscomp.Compiler(printStream2);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile6 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        java.io.Reader reader7 = jSSourceFile6.getCodeReader();
        com.google.javascript.jscomp.JSModule[] jSModuleArray8 = new com.google.javascript.jscomp.JSModule[] {};
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph9 = new com.google.javascript.jscomp.JSModuleGraph(jSModuleArray8);
        com.google.javascript.jscomp.CompilerOptions compilerOptions10 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions10.setLooseTypes(true);
        boolean boolean13 = compilerOptions10.collapseVariableDeclarations;
        compilerOptions10.moveFunctionDeclarations = false;
        boolean boolean16 = compilerOptions10.decomposeExpressions;
        com.google.javascript.jscomp.CheckLevel checkLevel17 = compilerOptions10.checkMissingGetCssNameLevel;
        com.google.javascript.jscomp.Result result18 = compiler3.compile(jSSourceFile6, jSModuleArray8, compilerOptions10);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile21 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile24 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        java.io.Reader reader25 = jSSourceFile24.getCodeReader();
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray26 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile6, jSSourceFile21, jSSourceFile24 };
        java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList27 = new java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile>();
        boolean boolean28 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList27, jSSourceFileArray26);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile31 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray32 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile31 };
        java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList33 = new java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile>();
        boolean boolean34 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList33, jSSourceFileArray32);
        com.google.javascript.jscomp.CompilerOptions compilerOptions35 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions35.setLooseTypes(true);
        boolean boolean38 = compilerOptions35.reserveRawExports;
        compilerOptions35.extractPrototypeMemberDeclarations = false;
        java.lang.String str41 = compilerOptions35.nameReferenceGraphPath;
        compilerOptions35.setSummaryDetailLevel(0);
        com.google.javascript.jscomp.Result result44 = compiler1.compile((java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList27, (java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList33, compilerOptions35);
        boolean boolean45 = compiler1.hasErrors();
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter46 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler1);
        org.junit.Assert.assertNotNull(jSSourceFile6);
        org.junit.Assert.assertNotNull(reader7);
        org.junit.Assert.assertNotNull(jSModuleArray8);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + checkLevel17 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel17.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(result18);
        org.junit.Assert.assertNotNull(jSSourceFile21);
        org.junit.Assert.assertNotNull(jSSourceFile24);
        org.junit.Assert.assertNotNull(reader25);
        org.junit.Assert.assertNotNull(jSSourceFileArray26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(jSSourceFile31);
        org.junit.Assert.assertNotNull(jSSourceFileArray32);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNull(str41);
        org.junit.Assert.assertNotNull(result44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        com.google.javascript.jscomp.DiagnosticType diagnosticType2 = com.google.javascript.jscomp.DiagnosticType.error("com.google.javascript.rhino.EcmaError: TypeError: 4", "hi!: hi!");
        org.junit.Assert.assertNotNull(diagnosticType2);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        java.io.PrintStream printStream2 = null;
        com.google.javascript.jscomp.Compiler compiler3 = new com.google.javascript.jscomp.Compiler(printStream2);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile6 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        java.io.Reader reader7 = jSSourceFile6.getCodeReader();
        com.google.javascript.jscomp.JSModule[] jSModuleArray8 = new com.google.javascript.jscomp.JSModule[] {};
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph9 = new com.google.javascript.jscomp.JSModuleGraph(jSModuleArray8);
        com.google.javascript.jscomp.CompilerOptions compilerOptions10 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions10.setLooseTypes(true);
        boolean boolean13 = compilerOptions10.collapseVariableDeclarations;
        compilerOptions10.moveFunctionDeclarations = false;
        boolean boolean16 = compilerOptions10.decomposeExpressions;
        com.google.javascript.jscomp.CheckLevel checkLevel17 = compilerOptions10.checkMissingGetCssNameLevel;
        com.google.javascript.jscomp.Result result18 = compiler3.compile(jSSourceFile6, jSModuleArray8, compilerOptions10);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile21 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile24 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        java.io.Reader reader25 = jSSourceFile24.getCodeReader();
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray26 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile6, jSSourceFile21, jSSourceFile24 };
        java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList27 = new java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile>();
        boolean boolean28 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList27, jSSourceFileArray26);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile31 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray32 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile31 };
        java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList33 = new java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile>();
        boolean boolean34 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList33, jSSourceFileArray32);
        com.google.javascript.jscomp.CompilerOptions compilerOptions35 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions35.setLooseTypes(true);
        boolean boolean38 = compilerOptions35.reserveRawExports;
        compilerOptions35.extractPrototypeMemberDeclarations = false;
        java.lang.String str41 = compilerOptions35.nameReferenceGraphPath;
        compilerOptions35.setSummaryDetailLevel(0);
        com.google.javascript.jscomp.Result result44 = compiler1.compile((java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList27, (java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList33, compilerOptions35);
        java.lang.String str45 = compilerOptions35.checkMissingGetCssNameBlacklist;
        boolean boolean46 = compilerOptions35.rewriteFunctionExpressions;
        boolean boolean47 = compilerOptions35.checkSuspiciousCode;
        org.junit.Assert.assertNotNull(jSSourceFile6);
        org.junit.Assert.assertNotNull(reader7);
        org.junit.Assert.assertNotNull(jSModuleArray8);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + checkLevel17 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel17.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(result18);
        org.junit.Assert.assertNotNull(jSSourceFile21);
        org.junit.Assert.assertNotNull(jSSourceFile24);
        org.junit.Assert.assertNotNull(reader25);
        org.junit.Assert.assertNotNull(jSSourceFileArray26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(jSSourceFile31);
        org.junit.Assert.assertNotNull(jSSourceFileArray32);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNull(str41);
        org.junit.Assert.assertNotNull(result44);
        org.junit.Assert.assertNull(str45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setLooseTypes(true);
        boolean boolean3 = compilerOptions0.reserveRawExports;
        compilerOptions0.extractPrototypeMemberDeclarations = false;
        boolean boolean6 = compilerOptions0.disambiguateProperties;
        com.google.javascript.jscomp.CheckLevel checkLevel7 = compilerOptions0.aggressiveVarCheck;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap8 = compilerOptions0.cssRenamingMap;
        com.google.javascript.jscomp.SourceMap.Format format9 = compilerOptions0.sourceMapFormat;
        java.lang.String str10 = compilerOptions0.nameReferenceReportPath;
        compilerOptions0.setProcessObjectPropertyString(false);
        boolean boolean13 = compilerOptions0.inlineLocalFunctions;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + checkLevel7 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel7.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNull(cssRenamingMap8);
        org.junit.Assert.assertNotNull(format9);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setLooseTypes(true);
        boolean boolean3 = compilerOptions0.reserveRawExports;
        compilerOptions0.extractPrototypeMemberDeclarations = false;
        compilerOptions0.checkMissingGetCssNameBlacklist = "4";
        compilerOptions0.locale = "error reporter";
        compilerOptions0.crossModuleMethodMotion = false;
        compilerOptions0.skipAllCompilerPasses();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        com.google.javascript.rhino.Node node2 = new com.google.javascript.rhino.Node((int) '4');
        node2.setLineno(36);
        com.google.javascript.rhino.Node node5 = node2.getParent();
        int int6 = node2.getChildCount();
        com.google.javascript.jscomp.DiagnosticType diagnosticType9 = com.google.javascript.jscomp.DiagnosticType.warning("hi!", "hi!");
        java.lang.String str10 = diagnosticType9.key;
        java.lang.String str11 = diagnosticType9.toString();
        java.io.PrintStream printStream12 = null;
        com.google.javascript.jscomp.Compiler compiler13 = new com.google.javascript.jscomp.Compiler(printStream12);
        compiler13.disableThreads();
        com.google.javascript.jscomp.PerformanceTracker performanceTracker15 = compiler13.tracker;
        com.google.javascript.jscomp.NodeTraversal.Callback callback16 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal17 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler13, callback16);
        com.google.javascript.rhino.Node node19 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node21 = new com.google.javascript.rhino.Node((int) '4');
        node19.addChildrenToBack(node21);
        com.google.javascript.jscomp.DiagnosticType diagnosticType25 = com.google.javascript.jscomp.DiagnosticType.warning("hi!", "hi!");
        com.google.javascript.jscomp.DiagnosticType diagnosticType26 = com.google.javascript.jscomp.Compiler.MOTION_ITERATIONS_ERROR;
        int int27 = diagnosticType25.compareTo(diagnosticType26);
        java.lang.String[] strArray28 = com.google.javascript.rhino.ScriptRuntime.emptyStrings;
        com.google.javascript.jscomp.JSError jSError29 = nodeTraversal17.makeError(node21, diagnosticType25, strArray28);
        com.google.javascript.jscomp.JSError jSError30 = com.google.javascript.jscomp.JSError.make("language version", node2, diagnosticType9, strArray28);
        com.google.javascript.jscomp.CompilerOptions compilerOptions31 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions31.flowSensitiveInlineVariables = false;
        compilerOptions31.setDefineToBooleanLiteral("// Input %num%", false);
        com.google.javascript.rhino.Node node38 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node40 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node42 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node44 = new com.google.javascript.rhino.Node((int) '4');
        node42.addChildrenToBack(node44);
        node38.addChildAfter(node40, node44);
        com.google.javascript.rhino.Node node48 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node50 = new com.google.javascript.rhino.Node((int) '4');
        node48.addChildrenToBack(node50);
        com.google.javascript.rhino.Node node52 = node38.copyInformationFromForTree(node50);
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable53 = node52.siblings();
        java.lang.RuntimeException runtimeException54 = com.google.javascript.rhino.ScriptRuntime.notFunctionError((java.lang.Object) compilerOptions31, (java.lang.Object) node52);
        try {
            node2.removeChild(node52);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(node5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(diagnosticType9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "hi!" + "'", str10.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "hi!: hi!" + "'", str11.equals("hi!: hi!"));
        org.junit.Assert.assertNull(performanceTracker15);
        org.junit.Assert.assertNotNull(diagnosticType25);
        org.junit.Assert.assertNotNull(diagnosticType26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 30 + "'", int27 == 30);
        org.junit.Assert.assertNotNull(strArray28);
        org.junit.Assert.assertNotNull(jSError29);
        org.junit.Assert.assertNotNull(jSError30);
        org.junit.Assert.assertNotNull(node52);
        org.junit.Assert.assertNotNull(nodeIterable53);
        org.junit.Assert.assertNotNull(runtimeException54);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile4 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        java.io.Reader reader5 = jSSourceFile4.getCodeReader();
        com.google.javascript.jscomp.JSModule[] jSModuleArray6 = new com.google.javascript.jscomp.JSModule[] {};
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph7 = new com.google.javascript.jscomp.JSModuleGraph(jSModuleArray6);
        com.google.javascript.jscomp.CompilerOptions compilerOptions8 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions8.setLooseTypes(true);
        boolean boolean11 = compilerOptions8.collapseVariableDeclarations;
        compilerOptions8.moveFunctionDeclarations = false;
        boolean boolean14 = compilerOptions8.decomposeExpressions;
        com.google.javascript.jscomp.CheckLevel checkLevel15 = compilerOptions8.checkMissingGetCssNameLevel;
        com.google.javascript.jscomp.Result result16 = compiler1.compile(jSSourceFile4, jSModuleArray6, compilerOptions8);
        com.google.javascript.jscomp.Result result17 = compiler1.getResult();
        boolean boolean18 = compiler1.hasErrors();
        com.google.javascript.jscomp.SourceFile.Generator generator20 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile21 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("JSC_OPTIMIZE_LOOP_ERROR. Exceeded max number of code motion iterations: {0} at (unknown source) line (unknown line) : (unknown column)", generator20);
        com.google.javascript.jscomp.SourceFile.Generator generator23 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile24 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("JSC_OPTIMIZE_LOOP_ERROR. Exceeded max number of code motion iterations: {0} at (unknown source) line (unknown line) : (unknown column)", generator23);
        com.google.javascript.jscomp.CompilerOptions compilerOptions25 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions25.setLooseTypes(true);
        boolean boolean28 = compilerOptions25.reserveRawExports;
        compilerOptions25.extractPrototypeMemberDeclarations = false;
        java.lang.String str31 = compilerOptions25.nameReferenceGraphPath;
        compilerOptions25.computeFunctionSideEffects = true;
        com.google.javascript.jscomp.CompilerOptions compilerOptions34 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions34.setLooseTypes(true);
        compilerOptions34.convertToDottedProperties = false;
        com.google.javascript.jscomp.CheckLevel checkLevel39 = compilerOptions34.reportMissingOverride;
        compilerOptions25.brokenClosureRequiresLevel = checkLevel39;
        java.util.Set<java.lang.String> strSet41 = compilerOptions25.stripTypePrefixes;
        compilerOptions25.optimizeReturns = true;
        com.google.javascript.jscomp.Result result44 = compiler1.compile(jSSourceFile21, jSSourceFile24, compilerOptions25);
        java.lang.String str45 = jSSourceFile21.getOriginalPath();
        try {
            java.lang.String str47 = jSSourceFile21.getLine(4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile4);
        org.junit.Assert.assertNotNull(reader5);
        org.junit.Assert.assertNotNull(jSModuleArray6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + checkLevel15 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel15.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(result16);
        org.junit.Assert.assertNotNull(result17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(jSSourceFile21);
        org.junit.Assert.assertNotNull(jSSourceFile24);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNull(str31);
        org.junit.Assert.assertTrue("'" + checkLevel39 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel39.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(strSet41);
        org.junit.Assert.assertNotNull(result44);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "JSC_OPTIMIZE_LOOP_ERROR. Exceeded max number of code motion iterations: {0} at (unknown source) line (unknown line) : (unknown column)" + "'", str45.equals("JSC_OPTIMIZE_LOOP_ERROR. Exceeded max number of code motion iterations: {0} at (unknown source) line (unknown line) : (unknown column)"));
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setLooseTypes(true);
        compilerOptions0.convertToDottedProperties = false;
        com.google.javascript.jscomp.CheckLevel checkLevel5 = compilerOptions0.reportMissingOverride;
        boolean boolean6 = compilerOptions0.aliasAllStrings;
        java.lang.Class<?> wildcardClass7 = compilerOptions0.getClass();
        java.lang.String str8 = compilerOptions0.syntheticBlockStartMarker;
        org.junit.Assert.assertTrue("'" + checkLevel5 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel5.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNull(str8);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setLooseTypes(true);
        boolean boolean3 = compilerOptions0.collapseVariableDeclarations;
        boolean boolean4 = compilerOptions0.generateExports;
        com.google.javascript.jscomp.SourceMap.DetailLevel detailLevel5 = compilerOptions0.sourceMapDetailLevel;
        compilerOptions0.rewriteFunctionExpressions = true;
        com.google.javascript.jscomp.CheckLevel checkLevel8 = compilerOptions0.checkFunctions;
        compilerOptions0.flowSensitiveInlineVariables = true;
        com.google.javascript.jscomp.CompilerOptions compilerOptions11 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions11.setLooseTypes(true);
        boolean boolean14 = compilerOptions11.collapseVariableDeclarations;
        boolean boolean15 = compilerOptions11.generateExports;
        com.google.javascript.jscomp.SourceMap.DetailLevel detailLevel16 = compilerOptions11.sourceMapDetailLevel;
        compilerOptions0.sourceMapDetailLevel = detailLevel16;
        java.util.Set<java.lang.String> strSet18 = compilerOptions0.stripNameSuffixes;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(detailLevel5);
        org.junit.Assert.assertTrue("'" + checkLevel8 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel8.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(detailLevel16);
        org.junit.Assert.assertNotNull(strSet18);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        try {
            com.google.javascript.rhino.EcmaError ecmaError6 = com.google.javascript.rhino.ScriptRuntime.constructError("Not declared as a type name", "goog.global", "", 27, "4", (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: -1");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setLooseTypes(true);
        compilerOptions0.checkSuspiciousCode = false;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap5 = null;
        compilerOptions0.cssRenamingMap = cssRenamingMap5;
        compilerOptions0.aliasableGlobals = "hi!: hi!";
        com.google.javascript.jscomp.CompilerOptions.TracerMode tracerMode9 = compilerOptions0.tracer;
        com.google.javascript.jscomp.CompilerOptions compilerOptions10 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions10.setLooseTypes(true);
        boolean boolean13 = compilerOptions10.reserveRawExports;
        compilerOptions10.extractPrototypeMemberDeclarations = false;
        compilerOptions10.checkMissingGetCssNameBlacklist = "4";
        compilerOptions10.setTweakToStringLiteral("", "com.google.javascript.rhino.EcmaError: TypeError: 4");
        java.util.Set<java.lang.String> strSet21 = compilerOptions10.stripNameSuffixes;
        compilerOptions0.setIdGenerators(strSet21);
        com.google.javascript.jscomp.CompilerOptions compilerOptions23 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions23.setLooseTypes(true);
        boolean boolean26 = compilerOptions23.collapseVariableDeclarations;
        boolean boolean27 = compilerOptions23.generateExports;
        com.google.javascript.jscomp.SourceMap.DetailLevel detailLevel28 = compilerOptions23.sourceMapDetailLevel;
        com.google.javascript.jscomp.CheckLevel checkLevel29 = null;
        compilerOptions23.brokenClosureRequiresLevel = checkLevel29;
        java.util.Set<java.lang.String> strSet31 = compilerOptions23.aliasableStrings;
        compilerOptions0.stripTypePrefixes = strSet31;
        org.junit.Assert.assertTrue("'" + tracerMode9 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TracerMode.OFF + "'", tracerMode9.equals(com.google.javascript.jscomp.CompilerOptions.TracerMode.OFF));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(strSet21);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(detailLevel28);
        org.junit.Assert.assertNotNull(strSet31);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setLooseTypes(true);
        compilerOptions0.renamePrefix = "hi!";
        java.lang.String str5 = compilerOptions0.locale;
        compilerOptions0.setNameAnonymousFunctionsOnly(false);
        boolean boolean8 = compilerOptions0.decomposeExpressions;
        boolean boolean9 = compilerOptions0.checkUnusedPropertiesEarly;
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setLooseTypes(true);
        boolean boolean3 = compilerOptions0.collapseVariableDeclarations;
        compilerOptions0.recordFunctionInformation = false;
        compilerOptions0.optimizeReturns = false;
        compilerOptions0.instrumentForCoverage = false;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        java.io.PrintStream printStream2 = null;
        com.google.javascript.jscomp.Compiler compiler3 = new com.google.javascript.jscomp.Compiler(printStream2);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile6 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        java.io.Reader reader7 = jSSourceFile6.getCodeReader();
        com.google.javascript.jscomp.JSModule[] jSModuleArray8 = new com.google.javascript.jscomp.JSModule[] {};
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph9 = new com.google.javascript.jscomp.JSModuleGraph(jSModuleArray8);
        com.google.javascript.jscomp.CompilerOptions compilerOptions10 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions10.setLooseTypes(true);
        boolean boolean13 = compilerOptions10.collapseVariableDeclarations;
        compilerOptions10.moveFunctionDeclarations = false;
        boolean boolean16 = compilerOptions10.decomposeExpressions;
        com.google.javascript.jscomp.CheckLevel checkLevel17 = compilerOptions10.checkMissingGetCssNameLevel;
        com.google.javascript.jscomp.Result result18 = compiler3.compile(jSSourceFile6, jSModuleArray8, compilerOptions10);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile21 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile24 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        java.io.Reader reader25 = jSSourceFile24.getCodeReader();
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray26 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile6, jSSourceFile21, jSSourceFile24 };
        java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList27 = new java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile>();
        boolean boolean28 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList27, jSSourceFileArray26);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile31 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray32 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile31 };
        java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList33 = new java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile>();
        boolean boolean34 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList33, jSSourceFileArray32);
        com.google.javascript.jscomp.CompilerOptions compilerOptions35 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions35.setLooseTypes(true);
        boolean boolean38 = compilerOptions35.reserveRawExports;
        compilerOptions35.extractPrototypeMemberDeclarations = false;
        java.lang.String str41 = compilerOptions35.nameReferenceGraphPath;
        compilerOptions35.setSummaryDetailLevel(0);
        com.google.javascript.jscomp.Result result44 = compiler1.compile((java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList27, (java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList33, compilerOptions35);
        int int45 = compiler1.getWarningCount();
        com.google.javascript.jscomp.PerformanceTracker performanceTracker46 = compiler1.tracker;
        boolean boolean47 = compiler1.isTypeCheckingEnabled();
        try {
            compiler1.check();
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: INTERNAL COMPILER ERROR.\nPlease report this problem.\nnull");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile6);
        org.junit.Assert.assertNotNull(reader7);
        org.junit.Assert.assertNotNull(jSModuleArray8);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + checkLevel17 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel17.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(result18);
        org.junit.Assert.assertNotNull(jSSourceFile21);
        org.junit.Assert.assertNotNull(jSSourceFile24);
        org.junit.Assert.assertNotNull(reader25);
        org.junit.Assert.assertNotNull(jSSourceFileArray26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(jSSourceFile31);
        org.junit.Assert.assertNotNull(jSSourceFileArray32);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNull(str41);
        org.junit.Assert.assertNotNull(result44);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 0 + "'", int45 == 0);
        org.junit.Assert.assertNull(performanceTracker46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        com.google.javascript.jscomp.CompilerOptions compilerOptions1 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions1.setLooseTypes(true);
        boolean boolean4 = compilerOptions1.collapseVariableDeclarations;
        compilerOptions1.moveFunctionDeclarations = false;
        boolean boolean7 = compilerOptions1.decomposeExpressions;
        boolean boolean8 = compilerOptions1.optimizeParameters;
        java.lang.String str9 = compilerOptions1.inputDelimiter;
        com.google.javascript.jscomp.ErrorFormat errorFormat10 = com.google.javascript.jscomp.ErrorFormat.LEGACY;
        java.lang.RuntimeException runtimeException11 = com.google.javascript.rhino.ScriptRuntime.undefWriteError((java.lang.Object) (short) 100, (java.lang.Object) str9, (java.lang.Object) errorFormat10);
        java.io.PrintStream printStream12 = null;
        com.google.javascript.jscomp.Compiler compiler13 = new com.google.javascript.jscomp.Compiler(printStream12);
        compiler13.disableThreads();
        com.google.javascript.jscomp.PerformanceTracker performanceTracker15 = compiler13.tracker;
        com.google.javascript.jscomp.MessageFormatter messageFormatter17 = errorFormat10.toFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler13, false);
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter18 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler13);
        com.google.javascript.jscomp.PassConfig passConfig19 = null;
        try {
            compiler13.setPassConfig(passConfig19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "// Input %num%" + "'", str9.equals("// Input %num%"));
        org.junit.Assert.assertNotNull(errorFormat10);
        org.junit.Assert.assertNotNull(runtimeException11);
        org.junit.Assert.assertNull(performanceTracker15);
        org.junit.Assert.assertNotNull(messageFormatter17);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setLooseTypes(true);
        boolean boolean3 = compilerOptions0.collapseVariableDeclarations;
        boolean boolean4 = compilerOptions0.generateExports;
        com.google.javascript.jscomp.SourceMap.DetailLevel detailLevel5 = compilerOptions0.sourceMapDetailLevel;
        compilerOptions0.rewriteFunctionExpressions = true;
        com.google.javascript.jscomp.CheckLevel checkLevel8 = compilerOptions0.checkFunctions;
        com.google.javascript.jscomp.SourceMap.Format format9 = compilerOptions0.sourceMapFormat;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(detailLevel5);
        org.junit.Assert.assertTrue("'" + checkLevel8 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel8.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(format9);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setLooseTypes(true);
        compilerOptions0.convertToDottedProperties = false;
        com.google.javascript.jscomp.CheckLevel checkLevel5 = compilerOptions0.reportMissingOverride;
        boolean boolean6 = compilerOptions0.aliasAllStrings;
        boolean boolean7 = compilerOptions0.flowSensitiveInlineVariables;
        boolean boolean8 = compilerOptions0.crossModuleCodeMotion;
        com.google.javascript.jscomp.CompilerOptions compilerOptions9 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions9.removeUnusedPrototypePropertiesInExterns = false;
        java.lang.String[] strArray15 = new java.lang.String[] { "()", "4" };
        java.util.ArrayList<java.lang.String> strList16 = new java.util.ArrayList<java.lang.String>();
        boolean boolean17 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strList16, strArray15);
        compilerOptions9.setReplaceStringsConfiguration("JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}", (java.util.List<java.lang.String>) strList16);
        compilerOptions0.setManageClosureDependencies((java.util.List<java.lang.String>) strList16);
        org.junit.Assert.assertTrue("'" + checkLevel5 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel5.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(strArray15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setLooseTypes(true);
        boolean boolean3 = compilerOptions0.reserveRawExports;
        compilerOptions0.extractPrototypeMemberDeclarations = false;
        boolean boolean6 = compilerOptions0.disambiguateProperties;
        boolean boolean7 = compilerOptions0.rewriteFunctionExpressions;
        java.lang.String str8 = compilerOptions0.appNameStr;
        boolean boolean9 = compilerOptions0.checkSymbols;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setLooseTypes(true);
        boolean boolean3 = compilerOptions0.reserveRawExports;
        com.google.javascript.jscomp.CheckLevel checkLevel4 = null;
        compilerOptions0.checkUnreachableCode = checkLevel4;
        boolean boolean6 = compilerOptions0.devirtualizePrototypeMethods;
        compilerOptions0.gatherCssNames = false;
        compilerOptions0.aliasableGlobals = "goog.global";
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention0 = new com.google.javascript.jscomp.DefaultCodingConvention();
        boolean boolean2 = defaultCodingConvention0.isExported("// Input %num%");
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry3 = null;
        com.google.javascript.jscomp.Scope scope4 = null;
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention5 = new com.google.javascript.jscomp.DefaultCodingConvention();
        java.lang.String str6 = defaultCodingConvention5.getDelegateSuperclassName();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry7 = null;
        com.google.javascript.jscomp.Scope scope8 = null;
        com.google.javascript.rhino.jstype.ObjectType[] objectTypeArray9 = new com.google.javascript.rhino.jstype.ObjectType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.ObjectType> objectTypeList10 = new java.util.ArrayList<com.google.javascript.rhino.jstype.ObjectType>();
        boolean boolean11 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.ObjectType>) objectTypeList10, objectTypeArray9);
        defaultCodingConvention5.defineDelegateProxyPrototypeProperties(jSTypeRegistry7, scope8, (java.util.List<com.google.javascript.rhino.jstype.ObjectType>) objectTypeList10);
        defaultCodingConvention0.defineDelegateProxyPrototypeProperties(jSTypeRegistry3, scope4, (java.util.List<com.google.javascript.rhino.jstype.ObjectType>) objectTypeList10);
        java.lang.String str14 = defaultCodingConvention0.getExportPropertyFunction();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNotNull(objectTypeArray9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNull(str14);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention0 = new com.google.javascript.jscomp.DefaultCodingConvention();
        boolean boolean2 = defaultCodingConvention0.isExported("// Input %num%");
        boolean boolean4 = defaultCodingConvention0.isSuperClassReference("");
        com.google.javascript.rhino.Node node6 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node8 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node10 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node12 = new com.google.javascript.rhino.Node((int) '4');
        node10.addChildrenToBack(node12);
        node6.addChildAfter(node8, node12);
        boolean boolean15 = node8.wasEmptyNode();
        java.lang.String str16 = defaultCodingConvention0.identifyTypeDefAssign(node8);
        com.google.javascript.jscomp.CompilerOptions compilerOptions17 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions17.setLooseTypes(true);
        boolean boolean20 = compilerOptions17.reserveRawExports;
        compilerOptions17.extractPrototypeMemberDeclarations = false;
        java.lang.String str23 = compilerOptions17.nameReferenceGraphPath;
        compilerOptions17.computeFunctionSideEffects = true;
        com.google.javascript.jscomp.CompilerOptions compilerOptions26 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions26.setLooseTypes(true);
        compilerOptions26.convertToDottedProperties = false;
        com.google.javascript.jscomp.CheckLevel checkLevel31 = compilerOptions26.reportMissingOverride;
        compilerOptions17.brokenClosureRequiresLevel = checkLevel31;
        com.google.javascript.jscomp.CompilerOptions.TracerMode tracerMode33 = compilerOptions17.tracer;
        java.lang.Object obj34 = null;
        java.lang.RuntimeException runtimeException35 = com.google.javascript.rhino.ScriptRuntime.undefWriteError((java.lang.Object) defaultCodingConvention0, (java.lang.Object) tracerMode33, obj34);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNull(str23);
        org.junit.Assert.assertTrue("'" + checkLevel31 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel31.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + tracerMode33 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TracerMode.OFF + "'", tracerMode33.equals(com.google.javascript.jscomp.CompilerOptions.TracerMode.OFF));
        org.junit.Assert.assertNotNull(runtimeException35);
    }

//    @Test
//    public void test466() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test466");
//        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.TWEAKS;
//        com.google.javascript.jscomp.DiagnosticGroups.TWEAKS = diagnosticGroup0;
//        java.lang.String str2 = diagnosticGroup0.toString();
//        org.junit.Assert.assertNotNull(diagnosticGroup0);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "DiagnosticGroup<strictModuleDepCheck>" + "'", str2.equals("DiagnosticGroup<strictModuleDepCheck>"));
//    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setLooseTypes(true);
        compilerOptions0.checkSuspiciousCode = false;
        com.google.javascript.jscomp.CheckLevel checkLevel5 = compilerOptions0.checkRequires;
        compilerOptions0.removeUnusedPrototypeProperties = true;
        compilerOptions0.skipAllCompilerPasses();
        org.junit.Assert.assertTrue("'" + checkLevel5 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel5.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.DEPRECATED;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        try {
            com.google.javascript.rhino.EvaluatorException evaluatorException3 = new com.google.javascript.rhino.EvaluatorException("DiagnosticGroup<strictModuleDepCheck>", "// Input %num%", (-2));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: -2");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test470() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test470");
//        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray0 = new com.google.javascript.jscomp.WarningsGuard[] {};
//        java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard> warningsGuardList1 = new java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard>();
//        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList1, warningsGuardArray0);
//        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard3 = new com.google.javascript.jscomp.ComposeWarningsGuard((java.util.List<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList1);
//        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard4 = new com.google.javascript.jscomp.ComposeWarningsGuard((java.util.List<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList1);
//        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup5 = com.google.javascript.jscomp.DiagnosticGroups.CHECK_USELESS_CODE;
//        com.google.javascript.jscomp.DiagnosticGroups.AMBIGUOUS_FUNCTION_DECL = diagnosticGroup5;
//        com.google.javascript.jscomp.DiagnosticGroups.VISIBILITY = diagnosticGroup5;
//        boolean boolean8 = composeWarningsGuard4.enables(diagnosticGroup5);
//        com.google.javascript.rhino.Node node11 = new com.google.javascript.rhino.Node((int) '4');
//        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node((int) '4');
//        com.google.javascript.rhino.Node node15 = new com.google.javascript.rhino.Node((int) '4');
//        com.google.javascript.rhino.Node node17 = new com.google.javascript.rhino.Node((int) '4');
//        node15.addChildrenToBack(node17);
//        node11.addChildAfter(node13, node17);
//        com.google.javascript.rhino.Node node21 = new com.google.javascript.rhino.Node((int) '4');
//        com.google.javascript.rhino.Node node23 = new com.google.javascript.rhino.Node((int) '4');
//        node21.addChildrenToBack(node23);
//        com.google.javascript.rhino.Node node25 = node11.copyInformationFromForTree(node23);
//        com.google.javascript.jscomp.DiagnosticType diagnosticType26 = com.google.javascript.jscomp.Compiler.MOTION_ITERATIONS_ERROR;
//        java.lang.String str27 = diagnosticType26.toString();
//        java.lang.String[] strArray28 = null;
//        com.google.javascript.jscomp.JSError jSError29 = com.google.javascript.jscomp.JSError.make("", node23, diagnosticType26, strArray28);
//        java.lang.String str30 = jSError29.description;
//        java.lang.String str31 = jSError29.sourceName;
//        com.google.javascript.jscomp.CheckLevel checkLevel32 = jSError29.level;
//        com.google.javascript.jscomp.CheckLevel checkLevel33 = composeWarningsGuard4.level(jSError29);
//        org.junit.Assert.assertNotNull(warningsGuardArray0);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertNotNull(diagnosticGroup5);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertNotNull(node25);
//        org.junit.Assert.assertNotNull(diagnosticType26);
//        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}" + "'", str27.equals("JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}"));
//        org.junit.Assert.assertNotNull(jSError29);
//        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "Exceeded max number of code motion iterations: {0}" + "'", str30.equals("Exceeded max number of code motion iterations: {0}"));
//        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "" + "'", str31.equals(""));
//        org.junit.Assert.assertTrue("'" + checkLevel32 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel32.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
//        org.junit.Assert.assertNull(checkLevel33);
//    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setLooseTypes(true);
        boolean boolean3 = compilerOptions0.collapseVariableDeclarations;
        compilerOptions0.recordFunctionInformation = false;
        compilerOptions0.optimizeReturns = false;
        com.google.javascript.jscomp.SourceMap.Format format8 = null;
        compilerOptions0.sourceMapFormat = format8;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setLooseTypes(true);
        compilerOptions0.checkSuspiciousCode = false;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap5 = null;
        compilerOptions0.cssRenamingMap = cssRenamingMap5;
        compilerOptions0.aliasableGlobals = "hi!: hi!";
        boolean boolean9 = compilerOptions0.removeTryCatchFinally;
        com.google.javascript.jscomp.CheckLevel checkLevel10 = compilerOptions0.checkMissingGetCssNameLevel;
        compilerOptions0.crossModuleMethodMotion = false;
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + checkLevel10 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel10.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile4 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        java.io.Reader reader5 = jSSourceFile4.getCodeReader();
        com.google.javascript.jscomp.JSModule[] jSModuleArray6 = new com.google.javascript.jscomp.JSModule[] {};
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph7 = new com.google.javascript.jscomp.JSModuleGraph(jSModuleArray6);
        com.google.javascript.jscomp.CompilerOptions compilerOptions8 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions8.setLooseTypes(true);
        boolean boolean11 = compilerOptions8.collapseVariableDeclarations;
        compilerOptions8.moveFunctionDeclarations = false;
        boolean boolean14 = compilerOptions8.decomposeExpressions;
        com.google.javascript.jscomp.CheckLevel checkLevel15 = compilerOptions8.checkMissingGetCssNameLevel;
        com.google.javascript.jscomp.Result result16 = compiler1.compile(jSSourceFile4, jSModuleArray6, compilerOptions8);
        com.google.javascript.jscomp.Result result17 = compiler1.getResult();
        boolean boolean18 = compiler1.hasErrors();
        com.google.javascript.jscomp.SourceFile.Generator generator20 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile21 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("JSC_OPTIMIZE_LOOP_ERROR. Exceeded max number of code motion iterations: {0} at (unknown source) line (unknown line) : (unknown column)", generator20);
        com.google.javascript.jscomp.SourceFile.Generator generator23 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile24 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("JSC_OPTIMIZE_LOOP_ERROR. Exceeded max number of code motion iterations: {0} at (unknown source) line (unknown line) : (unknown column)", generator23);
        com.google.javascript.jscomp.CompilerOptions compilerOptions25 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions25.setLooseTypes(true);
        boolean boolean28 = compilerOptions25.reserveRawExports;
        compilerOptions25.extractPrototypeMemberDeclarations = false;
        java.lang.String str31 = compilerOptions25.nameReferenceGraphPath;
        compilerOptions25.computeFunctionSideEffects = true;
        com.google.javascript.jscomp.CompilerOptions compilerOptions34 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions34.setLooseTypes(true);
        compilerOptions34.convertToDottedProperties = false;
        com.google.javascript.jscomp.CheckLevel checkLevel39 = compilerOptions34.reportMissingOverride;
        compilerOptions25.brokenClosureRequiresLevel = checkLevel39;
        java.util.Set<java.lang.String> strSet41 = compilerOptions25.stripTypePrefixes;
        compilerOptions25.optimizeReturns = true;
        com.google.javascript.jscomp.Result result44 = compiler1.compile(jSSourceFile21, jSSourceFile24, compilerOptions25);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile46 = com.google.javascript.jscomp.JSSourceFile.fromFile("(): error reporter");
        java.lang.String str47 = jSSourceFile46.toString();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile50 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        java.io.Reader reader51 = jSSourceFile50.getCodeReader();
        com.google.javascript.jscomp.CompilerOptions compilerOptions52 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions52.setLooseTypes(true);
        boolean boolean55 = compilerOptions52.reserveRawExports;
        boolean boolean56 = compilerOptions52.flowSensitiveInlineVariables;
        compilerOptions52.reserveRawExports = true;
        compilerOptions52.inferTypesInGlobalScope = false;
        boolean boolean61 = compilerOptions52.markNoSideEffectCalls;
        com.google.javascript.jscomp.CheckLevel checkLevel62 = compilerOptions52.checkProvides;
        com.google.javascript.jscomp.Result result63 = compiler1.compile(jSSourceFile46, jSSourceFile50, compilerOptions52);
        boolean boolean64 = compilerOptions52.optimizeReturns;
        org.junit.Assert.assertNotNull(jSSourceFile4);
        org.junit.Assert.assertNotNull(reader5);
        org.junit.Assert.assertNotNull(jSModuleArray6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + checkLevel15 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel15.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(result16);
        org.junit.Assert.assertNotNull(result17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(jSSourceFile21);
        org.junit.Assert.assertNotNull(jSSourceFile24);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNull(str31);
        org.junit.Assert.assertTrue("'" + checkLevel39 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel39.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(strSet41);
        org.junit.Assert.assertNotNull(result44);
        org.junit.Assert.assertNotNull(jSSourceFile46);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "(): error reporter" + "'", str47.equals("(): error reporter"));
        org.junit.Assert.assertNotNull(jSSourceFile50);
        org.junit.Assert.assertNotNull(reader51);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertTrue("'" + checkLevel62 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel62.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(result63);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        com.google.javascript.rhino.Node node1 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node3 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node5 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node7 = new com.google.javascript.rhino.Node((int) '4');
        node5.addChildrenToBack(node7);
        node1.addChildAfter(node3, node7);
        com.google.javascript.rhino.Node node11 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node((int) '4');
        node11.addChildrenToBack(node13);
        com.google.javascript.rhino.Node node15 = node1.copyInformationFromForTree(node13);
        int int16 = node1.getChildCount();
        com.google.javascript.rhino.Node node17 = node1.getFirstChild();
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNull(node17);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        com.google.javascript.jscomp.SourceFile sourceFile1 = com.google.javascript.jscomp.SourceFile.fromFile("goog.global");
        try {
            java.io.Reader reader2 = sourceFile1.getCodeReader();
            org.junit.Assert.fail("Expected exception of type java.io.FileNotFoundException; message: goog.global (No such file or directory)");
        } catch (java.io.FileNotFoundException e) {
        }
        org.junit.Assert.assertNotNull(sourceFile1);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention0 = new com.google.javascript.jscomp.DefaultCodingConvention();
        boolean boolean2 = defaultCodingConvention0.isExported("// Input %num%");
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry3 = null;
        com.google.javascript.jscomp.Scope scope4 = null;
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention5 = new com.google.javascript.jscomp.DefaultCodingConvention();
        java.lang.String str6 = defaultCodingConvention5.getDelegateSuperclassName();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry7 = null;
        com.google.javascript.jscomp.Scope scope8 = null;
        com.google.javascript.rhino.jstype.ObjectType[] objectTypeArray9 = new com.google.javascript.rhino.jstype.ObjectType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.ObjectType> objectTypeList10 = new java.util.ArrayList<com.google.javascript.rhino.jstype.ObjectType>();
        boolean boolean11 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.ObjectType>) objectTypeList10, objectTypeArray9);
        defaultCodingConvention5.defineDelegateProxyPrototypeProperties(jSTypeRegistry7, scope8, (java.util.List<com.google.javascript.rhino.jstype.ObjectType>) objectTypeList10);
        defaultCodingConvention0.defineDelegateProxyPrototypeProperties(jSTypeRegistry3, scope4, (java.util.List<com.google.javascript.rhino.jstype.ObjectType>) objectTypeList10);
        java.io.PrintStream printStream14 = null;
        com.google.javascript.jscomp.Compiler compiler15 = new com.google.javascript.jscomp.Compiler(printStream14);
        compiler15.disableThreads();
        com.google.javascript.jscomp.PerformanceTracker performanceTracker17 = compiler15.tracker;
        com.google.javascript.jscomp.NodeTraversal.Callback callback18 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal19 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler15, callback18);
        com.google.javascript.rhino.Node node21 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node23 = new com.google.javascript.rhino.Node((int) '4');
        node21.addChildrenToBack(node23);
        com.google.javascript.jscomp.DiagnosticType diagnosticType27 = com.google.javascript.jscomp.DiagnosticType.warning("hi!", "hi!");
        com.google.javascript.jscomp.DiagnosticType diagnosticType28 = com.google.javascript.jscomp.Compiler.MOTION_ITERATIONS_ERROR;
        int int29 = diagnosticType27.compareTo(diagnosticType28);
        java.lang.String[] strArray30 = com.google.javascript.rhino.ScriptRuntime.emptyStrings;
        com.google.javascript.jscomp.JSError jSError31 = nodeTraversal19.makeError(node23, diagnosticType27, strArray30);
        java.util.List<java.lang.String> strList32 = defaultCodingConvention0.identifyTypeDeclarationCall(node23);
        com.google.javascript.rhino.Node node34 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node36 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node38 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node40 = new com.google.javascript.rhino.Node((int) '4');
        node38.addChildrenToBack(node40);
        node34.addChildAfter(node36, node40);
        com.google.javascript.rhino.Node node44 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node46 = new com.google.javascript.rhino.Node((int) '4');
        node44.addChildrenToBack(node46);
        com.google.javascript.rhino.Node node48 = node34.copyInformationFromForTree(node46);
        com.google.javascript.jscomp.CodingConvention.SubclassRelationship subclassRelationship49 = defaultCodingConvention0.getClassesDefinedByCall(node48);
        java.util.Collection<com.google.javascript.rhino.Node> nodeCollection50 = com.google.javascript.jscomp.NodeUtil.getVarsDeclaredInBranch(node48);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNotNull(objectTypeArray9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNull(performanceTracker17);
        org.junit.Assert.assertNotNull(diagnosticType27);
        org.junit.Assert.assertNotNull(diagnosticType28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 30 + "'", int29 == 30);
        org.junit.Assert.assertNotNull(strArray30);
        org.junit.Assert.assertNotNull(jSError31);
        org.junit.Assert.assertNull(strList32);
        org.junit.Assert.assertNotNull(node48);
        org.junit.Assert.assertNull(subclassRelationship49);
        org.junit.Assert.assertNotNull(nodeCollection50);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setLooseTypes(true);
        boolean boolean3 = compilerOptions0.reserveRawExports;
        compilerOptions0.extractPrototypeMemberDeclarations = false;
        com.google.javascript.jscomp.CheckLevel checkLevel6 = compilerOptions0.checkProvides;
        compilerOptions0.setRemoveAbstractMethods(true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + checkLevel6 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel6.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node3 = new com.google.javascript.rhino.Node((int) (short) 1);
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newString("hi!");
        int int6 = node5.getCharno();
        com.google.javascript.rhino.Node node8 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node10 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node12 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node14 = new com.google.javascript.rhino.Node((int) '4');
        node12.addChildrenToBack(node14);
        node8.addChildAfter(node10, node14);
        com.google.javascript.rhino.Node node18 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node20 = new com.google.javascript.rhino.Node((int) '4');
        node18.addChildrenToBack(node20);
        com.google.javascript.rhino.Node node22 = node8.copyInformationFromForTree(node20);
        com.google.javascript.rhino.Node node23 = node8.cloneTree();
        com.google.javascript.rhino.Node node24 = node8.cloneTree();
        com.google.javascript.rhino.Node node26 = new com.google.javascript.rhino.Node((int) '4');
        node26.setLineno(36);
        com.google.javascript.rhino.Node[] nodeArray29 = new com.google.javascript.rhino.Node[] { node3, node5, node24, node26 };
        com.google.javascript.rhino.Node node32 = new com.google.javascript.rhino.Node(0, nodeArray29, 25, 14);
        com.google.javascript.rhino.Node node34 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node36 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node38 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node40 = new com.google.javascript.rhino.Node((int) '4');
        node38.addChildrenToBack(node40);
        node34.addChildAfter(node36, node40);
        com.google.javascript.rhino.Node node44 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node46 = new com.google.javascript.rhino.Node((int) '4');
        node44.addChildrenToBack(node46);
        com.google.javascript.rhino.Node node48 = node34.copyInformationFromForTree(node46);
        com.google.javascript.rhino.Node node49 = node34.cloneTree();
        com.google.javascript.rhino.Node node50 = node34.cloneTree();
        java.lang.String str51 = closureCodingConvention0.extractClassNameIfRequire(node32, node34);
        boolean boolean52 = node34.isQuotedString();
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertNotNull(nodeArray29);
        org.junit.Assert.assertNotNull(node48);
        org.junit.Assert.assertNotNull(node49);
        org.junit.Assert.assertNotNull(node50);
        org.junit.Assert.assertNull(str51);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        com.google.javascript.rhino.Node node1 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node3 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node5 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node7 = new com.google.javascript.rhino.Node((int) '4');
        node5.addChildrenToBack(node7);
        node1.addChildAfter(node3, node7);
        com.google.javascript.rhino.Node node11 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node((int) '4');
        node11.addChildrenToBack(node13);
        com.google.javascript.rhino.Node node15 = node1.copyInformationFromForTree(node13);
        com.google.javascript.rhino.jstype.JSType jSType16 = null;
        node15.setJSType(jSType16);
        boolean boolean18 = node15.isOptionalArg();
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        java.lang.String str1 = com.google.javascript.rhino.jstype.ObjectType.createDelegateSuffix("language version");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "(language version)" + "'", str1.equals("(language version)"));
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        com.google.javascript.rhino.Node node1 = new com.google.javascript.rhino.Node(23);
        com.google.javascript.rhino.Node.SideEffectFlags sideEffectFlags2 = null;
        try {
            node1.setSideEffectFlags(sideEffectFlags2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        com.google.javascript.jscomp.CompilerOptions.TweakProcessing tweakProcessing0 = com.google.javascript.jscomp.CompilerOptions.TweakProcessing.STRIP;
        org.junit.Assert.assertTrue("'" + tweakProcessing0 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TweakProcessing.STRIP + "'", tweakProcessing0.equals(com.google.javascript.jscomp.CompilerOptions.TweakProcessing.STRIP));
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setLooseTypes(true);
        boolean boolean3 = compilerOptions0.collapseVariableDeclarations;
        compilerOptions0.moveFunctionDeclarations = false;
        boolean boolean6 = compilerOptions0.decomposeExpressions;
        boolean boolean7 = compilerOptions0.optimizeParameters;
        java.lang.String str8 = compilerOptions0.inputDelimiter;
        java.lang.String[] strArray10 = new java.lang.String[] { "hi!" };
        java.util.LinkedHashSet<java.lang.String> strSet11 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean12 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet11, strArray10);
        compilerOptions0.stripTypes = strSet11;
        compilerOptions0.markNoSideEffectCalls = false;
        boolean boolean16 = compilerOptions0.checkDuplicateMessages;
        com.google.javascript.jscomp.CompilerOptions compilerOptions17 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions17.setLooseTypes(true);
        compilerOptions17.checkSuspiciousCode = false;
        boolean boolean22 = compilerOptions17.convertToDottedProperties;
        compilerOptions17.recordFunctionInformation = false;
        com.google.javascript.jscomp.CompilerOptions compilerOptions25 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions25.setLooseTypes(true);
        boolean boolean28 = compilerOptions25.reserveRawExports;
        compilerOptions25.extractPrototypeMemberDeclarations = false;
        java.lang.String str31 = compilerOptions25.nameReferenceGraphPath;
        boolean boolean32 = compilerOptions25.markNoSideEffectCalls;
        com.google.javascript.jscomp.ErrorFormat errorFormat33 = compilerOptions25.errorFormat;
        compilerOptions17.errorFormat = errorFormat33;
        compilerOptions0.errorFormat = errorFormat33;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "// Input %num%" + "'", str8.equals("// Input %num%"));
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNull(str31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(errorFormat33);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setLooseTypes(true);
        compilerOptions0.checkSuspiciousCode = false;
        com.google.common.collect.Multimap<com.google.javascript.jscomp.CustomPassExecutionTime, com.google.javascript.jscomp.CompilerPass> customPassExecutionTimeMultimap5 = compilerOptions0.customPasses;
        compilerOptions0.inlineLocalFunctions = false;
        com.google.common.collect.Multimap<com.google.javascript.jscomp.CustomPassExecutionTime, com.google.javascript.jscomp.CompilerPass> customPassExecutionTimeMultimap8 = compilerOptions0.customPasses;
        com.google.javascript.jscomp.ErrorFormat errorFormat9 = com.google.javascript.jscomp.ErrorFormat.SOURCELESS;
        compilerOptions0.errorFormat = errorFormat9;
        compilerOptions0.disableRuntimeTypeCheck();
        org.junit.Assert.assertNull(customPassExecutionTimeMultimap5);
        org.junit.Assert.assertNull(customPassExecutionTimeMultimap8);
        org.junit.Assert.assertNotNull(errorFormat9);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        com.google.javascript.rhino.Node node1 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node3 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node5 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node7 = new com.google.javascript.rhino.Node((int) '4');
        node5.addChildrenToBack(node7);
        node1.addChildAfter(node3, node7);
        com.google.javascript.rhino.Node node11 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node((int) '4');
        node11.addChildrenToBack(node13);
        com.google.javascript.rhino.Node node15 = node1.copyInformationFromForTree(node13);
        com.google.javascript.rhino.Node node17 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node18 = node1.copyInformationFromForTree(node17);
        com.google.javascript.rhino.Node node20 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node22 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node24 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node26 = new com.google.javascript.rhino.Node((int) '4');
        node24.addChildrenToBack(node26);
        node20.addChildAfter(node22, node26);
        com.google.javascript.rhino.Node node30 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node32 = new com.google.javascript.rhino.Node((int) '4');
        node30.addChildrenToBack(node32);
        com.google.javascript.rhino.Node node34 = node20.copyInformationFromForTree(node32);
        com.google.javascript.rhino.jstype.JSType jSType35 = null;
        node34.setJSType(jSType35);
        com.google.javascript.rhino.Node node38 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node40 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node42 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node44 = new com.google.javascript.rhino.Node((int) '4');
        node42.addChildrenToBack(node44);
        node38.addChildAfter(node40, node44);
        com.google.javascript.rhino.Node node48 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node50 = new com.google.javascript.rhino.Node((int) '4');
        node48.addChildrenToBack(node50);
        com.google.javascript.rhino.Node node52 = node38.copyInformationFromForTree(node50);
        node17.addChildAfter(node34, node50);
        boolean boolean54 = node17.isVarArgs();
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNotNull(node34);
        org.junit.Assert.assertNotNull(node52);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newNumber((double) 4095, (int) (short) 10, 18);
        org.junit.Assert.assertNotNull(node3);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setLooseTypes(true);
        compilerOptions0.checkSuspiciousCode = false;
        boolean boolean5 = compilerOptions0.convertToDottedProperties;
        compilerOptions0.setGenerateExports(false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        com.google.javascript.rhino.Context context0 = new com.google.javascript.rhino.Context();
        context0.setGeneratingSource(true);
        java.lang.Object obj3 = context0.getDebuggerContextData();
        boolean boolean4 = context0.hasCompileFunctionsWithDynamicScope();
        try {
            context0.setLanguageVersion(39);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Bad language version: 39");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(obj3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        compiler1.disableThreads();
        com.google.javascript.jscomp.PerformanceTracker performanceTracker3 = compiler1.tracker;
        com.google.javascript.jscomp.NodeTraversal.Callback callback4 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal5 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler1, callback4);
        java.io.PrintStream printStream6 = null;
        com.google.javascript.jscomp.Compiler compiler7 = new com.google.javascript.jscomp.Compiler(printStream6);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile10 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        java.io.Reader reader11 = jSSourceFile10.getCodeReader();
        com.google.javascript.jscomp.JSModule[] jSModuleArray12 = new com.google.javascript.jscomp.JSModule[] {};
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph13 = new com.google.javascript.jscomp.JSModuleGraph(jSModuleArray12);
        com.google.javascript.jscomp.CompilerOptions compilerOptions14 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions14.setLooseTypes(true);
        boolean boolean17 = compilerOptions14.collapseVariableDeclarations;
        compilerOptions14.moveFunctionDeclarations = false;
        boolean boolean20 = compilerOptions14.decomposeExpressions;
        com.google.javascript.jscomp.CheckLevel checkLevel21 = compilerOptions14.checkMissingGetCssNameLevel;
        com.google.javascript.jscomp.Result result22 = compiler7.compile(jSSourceFile10, jSModuleArray12, compilerOptions14);
        java.io.PrintStream printStream23 = null;
        com.google.javascript.jscomp.Compiler compiler24 = new com.google.javascript.jscomp.Compiler(printStream23);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile27 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        java.io.Reader reader28 = jSSourceFile27.getCodeReader();
        com.google.javascript.jscomp.JSModule[] jSModuleArray29 = new com.google.javascript.jscomp.JSModule[] {};
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph30 = new com.google.javascript.jscomp.JSModuleGraph(jSModuleArray29);
        com.google.javascript.jscomp.CompilerOptions compilerOptions31 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions31.setLooseTypes(true);
        boolean boolean34 = compilerOptions31.collapseVariableDeclarations;
        compilerOptions31.moveFunctionDeclarations = false;
        boolean boolean37 = compilerOptions31.decomposeExpressions;
        com.google.javascript.jscomp.CheckLevel checkLevel38 = compilerOptions31.checkMissingGetCssNameLevel;
        com.google.javascript.jscomp.Result result39 = compiler24.compile(jSSourceFile27, jSModuleArray29, compilerOptions31);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile42 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        java.io.PrintStream printStream43 = null;
        com.google.javascript.jscomp.Compiler compiler44 = new com.google.javascript.jscomp.Compiler(printStream43);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile47 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        java.io.Reader reader48 = jSSourceFile47.getCodeReader();
        com.google.javascript.jscomp.JSModule[] jSModuleArray49 = new com.google.javascript.jscomp.JSModule[] {};
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph50 = new com.google.javascript.jscomp.JSModuleGraph(jSModuleArray49);
        com.google.javascript.jscomp.CompilerOptions compilerOptions51 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions51.setLooseTypes(true);
        boolean boolean54 = compilerOptions51.collapseVariableDeclarations;
        compilerOptions51.moveFunctionDeclarations = false;
        boolean boolean57 = compilerOptions51.decomposeExpressions;
        com.google.javascript.jscomp.CheckLevel checkLevel58 = compilerOptions51.checkMissingGetCssNameLevel;
        com.google.javascript.jscomp.Result result59 = compiler44.compile(jSSourceFile47, jSModuleArray49, compilerOptions51);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile62 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile65 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        java.io.Reader reader66 = jSSourceFile65.getCodeReader();
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray67 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile10, jSSourceFile27, jSSourceFile42, jSSourceFile47, jSSourceFile62, jSSourceFile65 };
        java.io.PrintStream printStream68 = null;
        com.google.javascript.jscomp.Compiler compiler69 = new com.google.javascript.jscomp.Compiler(printStream68);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile72 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        java.io.Reader reader73 = jSSourceFile72.getCodeReader();
        com.google.javascript.jscomp.JSModule[] jSModuleArray74 = new com.google.javascript.jscomp.JSModule[] {};
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph75 = new com.google.javascript.jscomp.JSModuleGraph(jSModuleArray74);
        com.google.javascript.jscomp.CompilerOptions compilerOptions76 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions76.setLooseTypes(true);
        boolean boolean79 = compilerOptions76.collapseVariableDeclarations;
        compilerOptions76.moveFunctionDeclarations = false;
        boolean boolean82 = compilerOptions76.decomposeExpressions;
        com.google.javascript.jscomp.CheckLevel checkLevel83 = compilerOptions76.checkMissingGetCssNameLevel;
        com.google.javascript.jscomp.Result result84 = compiler69.compile(jSSourceFile72, jSModuleArray74, compilerOptions76);
        com.google.javascript.jscomp.CompilerOptions compilerOptions85 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions85.setLooseTypes(true);
        boolean boolean88 = compilerOptions85.collapseVariableDeclarations;
        compilerOptions85.setManageClosureDependencies(false);
        com.google.javascript.jscomp.Result result91 = compiler1.compile(jSSourceFileArray67, jSModuleArray74, compilerOptions85);
        com.google.javascript.jscomp.CodingConvention codingConvention92 = compiler1.getCodingConvention();
        com.google.javascript.rhino.Node node96 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode(codingConvention92, "language version", 0, 27);
        org.junit.Assert.assertNull(performanceTracker3);
        org.junit.Assert.assertNotNull(jSSourceFile10);
        org.junit.Assert.assertNotNull(reader11);
        org.junit.Assert.assertNotNull(jSModuleArray12);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + checkLevel21 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel21.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(result22);
        org.junit.Assert.assertNotNull(jSSourceFile27);
        org.junit.Assert.assertNotNull(reader28);
        org.junit.Assert.assertNotNull(jSModuleArray29);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + checkLevel38 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel38.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(result39);
        org.junit.Assert.assertNotNull(jSSourceFile42);
        org.junit.Assert.assertNotNull(jSSourceFile47);
        org.junit.Assert.assertNotNull(reader48);
        org.junit.Assert.assertNotNull(jSModuleArray49);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertTrue("'" + checkLevel58 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel58.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(result59);
        org.junit.Assert.assertNotNull(jSSourceFile62);
        org.junit.Assert.assertNotNull(jSSourceFile65);
        org.junit.Assert.assertNotNull(reader66);
        org.junit.Assert.assertNotNull(jSSourceFileArray67);
        org.junit.Assert.assertNotNull(jSSourceFile72);
        org.junit.Assert.assertNotNull(reader73);
        org.junit.Assert.assertNotNull(jSModuleArray74);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
        org.junit.Assert.assertTrue("'" + checkLevel83 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel83.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(result84);
        org.junit.Assert.assertTrue("'" + boolean88 + "' != '" + false + "'", boolean88 == false);
        org.junit.Assert.assertNotNull(result91);
        org.junit.Assert.assertNotNull(codingConvention92);
        org.junit.Assert.assertNotNull(node96);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setLooseTypes(true);
        boolean boolean3 = compilerOptions0.reserveRawExports;
        compilerOptions0.extractPrototypeMemberDeclarations = false;
        com.google.javascript.jscomp.CheckLevel checkLevel6 = compilerOptions0.checkProvides;
        boolean boolean7 = compilerOptions0.checkUnusedPropertiesEarly;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + checkLevel6 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel6.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile1 = com.google.javascript.jscomp.JSSourceFile.fromFile("(): error reporter");
        java.lang.String str2 = jSSourceFile1.toString();
        com.google.javascript.jscomp.Region region4 = jSSourceFile1.getRegion(150);
        org.junit.Assert.assertNotNull(jSSourceFile1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "(): error reporter" + "'", str2.equals("(): error reporter"));
        org.junit.Assert.assertNull(region4);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        com.google.javascript.rhino.EvaluatorException evaluatorException1 = new com.google.javascript.rhino.EvaluatorException("DiagnosticGroup<externsValidation>");
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.STRICT_MODULE_DEP_CHECK;
        com.google.javascript.jscomp.DiagnosticGroups.MISSING_PROPERTIES = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticGroups.CHECK_TYPES = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticGroups.INTERNET_EXPLORER_CHECKS = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticGroups.CHECK_VARIABLES = diagnosticGroup0;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setLooseTypes(true);
        boolean boolean3 = compilerOptions0.reserveRawExports;
        com.google.javascript.jscomp.CheckLevel checkLevel4 = null;
        compilerOptions0.checkUnreachableCode = checkLevel4;
        com.google.javascript.jscomp.MessageBundle messageBundle6 = compilerOptions0.messageBundle;
        java.lang.String str7 = compilerOptions0.sourceMapOutputPath;
        compilerOptions0.aliasKeywords = true;
        compilerOptions0.optimizeArgumentsArray = true;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(messageBundle6);
        org.junit.Assert.assertNull(str7);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        com.google.javascript.rhino.Context context0 = new com.google.javascript.rhino.Context();
        context0.setGeneratingSource(true);
        java.lang.Object obj3 = context0.getDebuggerContextData();
        context0.setGeneratingSource(true);
        int int6 = context0.getOptimizationLevel();
        org.junit.Assert.assertNull(obj3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup1 = com.google.javascript.jscomp.DiagnosticGroups.MISSING_PROPERTIES;
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup2 = com.google.javascript.jscomp.DiagnosticGroups.STRICT_MODULE_DEP_CHECK;
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup3 = com.google.javascript.jscomp.DiagnosticGroups.STRICT_MODULE_DEP_CHECK;
        com.google.javascript.jscomp.DiagnosticGroups.TYPE_INVALIDATION = diagnosticGroup3;
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup5 = com.google.javascript.jscomp.DiagnosticGroups.MISSING_PROPERTIES;
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup6 = com.google.javascript.jscomp.DiagnosticGroups.STRICT_MODULE_DEP_CHECK;
        com.google.javascript.jscomp.DiagnosticGroups.MISSING_PROPERTIES = diagnosticGroup6;
        com.google.javascript.jscomp.DiagnosticGroups.STRICT_MODULE_DEP_CHECK = diagnosticGroup6;
        com.google.javascript.jscomp.DiagnosticGroup[] diagnosticGroupArray9 = new com.google.javascript.jscomp.DiagnosticGroup[] { diagnosticGroup1, diagnosticGroup2, diagnosticGroup3, diagnosticGroup5, diagnosticGroup6 };
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup10 = new com.google.javascript.jscomp.DiagnosticGroup("4", diagnosticGroupArray9);
        com.google.javascript.jscomp.DiagnosticGroups.TYPE_INVALIDATION = diagnosticGroup10;
        com.google.javascript.jscomp.DiagnosticGroups.FILEOVERVIEW_JSDOC = diagnosticGroup10;
        com.google.javascript.rhino.Node node15 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node17 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node19 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node21 = new com.google.javascript.rhino.Node((int) '4');
        node19.addChildrenToBack(node21);
        node15.addChildAfter(node17, node21);
        com.google.javascript.rhino.Node node25 = new com.google.javascript.rhino.Node((int) '4');
        com.google.javascript.rhino.Node node27 = new com.google.javascript.rhino.Node((int) '4');
        node25.addChildrenToBack(node27);
        com.google.javascript.rhino.Node node29 = node15.copyInformationFromForTree(node27);
        com.google.javascript.jscomp.DiagnosticType diagnosticType30 = com.google.javascript.jscomp.Compiler.MOTION_ITERATIONS_ERROR;
        java.lang.String str31 = diagnosticType30.toString();
        java.lang.String[] strArray32 = null;
        com.google.javascript.jscomp.JSError jSError33 = com.google.javascript.jscomp.JSError.make("", node27, diagnosticType30, strArray32);
        java.lang.String str34 = jSError33.description;
        java.lang.String str35 = jSError33.toString();
        boolean boolean36 = diagnosticGroup10.matches(jSError33);
        java.lang.String str37 = jSError33.description;
        int int38 = jSError33.lineNumber;
        org.junit.Assert.assertNotNull(diagnosticGroup1);
        org.junit.Assert.assertNotNull(diagnosticGroup2);
        org.junit.Assert.assertNotNull(diagnosticGroup3);
        org.junit.Assert.assertNotNull(diagnosticGroup5);
        org.junit.Assert.assertNotNull(diagnosticGroup6);
        org.junit.Assert.assertNotNull(diagnosticGroupArray9);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNotNull(diagnosticType30);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}" + "'", str31.equals("JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}"));
        org.junit.Assert.assertNotNull(jSError33);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "Exceeded max number of code motion iterations: {0}" + "'", str34.equals("Exceeded max number of code motion iterations: {0}"));
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "JSC_OPTIMIZE_LOOP_ERROR. Exceeded max number of code motion iterations: {0} at (unknown source) line (unknown line) : (unknown column)" + "'", str35.equals("JSC_OPTIMIZE_LOOP_ERROR. Exceeded max number of code motion iterations: {0} at (unknown source) line (unknown line) : (unknown column)"));
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "Exceeded max number of code motion iterations: {0}" + "'", str37.equals("Exceeded max number of code motion iterations: {0}"));
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + (-1) + "'", int38 == (-1));
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile4 = com.google.javascript.jscomp.JSSourceFile.fromCode("hi!", "");
        java.io.Reader reader5 = jSSourceFile4.getCodeReader();
        com.google.javascript.jscomp.JSModule[] jSModuleArray6 = new com.google.javascript.jscomp.JSModule[] {};
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph7 = new com.google.javascript.jscomp.JSModuleGraph(jSModuleArray6);
        com.google.javascript.jscomp.CompilerOptions compilerOptions8 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions8.setLooseTypes(true);
        boolean boolean11 = compilerOptions8.collapseVariableDeclarations;
        compilerOptions8.moveFunctionDeclarations = false;
        boolean boolean14 = compilerOptions8.decomposeExpressions;
        com.google.javascript.jscomp.CheckLevel checkLevel15 = compilerOptions8.checkMissingGetCssNameLevel;
        com.google.javascript.jscomp.Result result16 = compiler1.compile(jSSourceFile4, jSModuleArray6, compilerOptions8);
        int int17 = compiler1.getErrorCount();
        int int18 = compiler1.getWarningCount();
        com.google.javascript.rhino.Node node19 = compiler1.getRoot();
        org.junit.Assert.assertNotNull(jSSourceFile4);
        org.junit.Assert.assertNotNull(reader5);
        org.junit.Assert.assertNotNull(jSModuleArray6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + checkLevel15 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel15.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(result16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNull(node19);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setLooseTypes(true);
        boolean boolean3 = compilerOptions0.reserveRawExports;
        com.google.javascript.jscomp.CheckLevel checkLevel4 = null;
        compilerOptions0.checkUnreachableCode = checkLevel4;
        com.google.javascript.jscomp.CheckLevel checkLevel6 = compilerOptions0.reportUnknownTypes;
        compilerOptions0.rewriteFunctionExpressions = true;
        compilerOptions0.gatherCssNames = false;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + checkLevel6 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel6.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        compiler1.disableThreads();
        try {
            com.google.javascript.jscomp.Region region5 = compiler1.getSourceRegion("goog.global", (int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = null;
        com.google.javascript.jscomp.DiagnosticGroups.TYPE_INVALIDATION = diagnosticGroup0;
    }
}

