import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        java.lang.String str0 = com.google.javascript.rhino.jstype.JSType.UNKNOWN_NAME;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "Unknown class name" + "'", str0.equals("Unknown class name"));
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        try {
            java.lang.String str3 = com.google.javascript.rhino.ScriptRuntime.getMessage2("Unknown class name", (java.lang.Object) "Unknown class name", (java.lang.Object) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property Unknown class name");
        } catch (java.lang.RuntimeException e) {
        }
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        int int0 = com.google.javascript.rhino.Context.VERSION_1_5;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 150 + "'", int0 == 150);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        int int0 = com.google.javascript.rhino.Node.TARGET_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        com.google.javascript.jscomp.ErrorManager errorManager0 = null;
        try {
            com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(errorManager0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: the error manager cannot be null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        int int0 = com.google.javascript.rhino.Node.BRACELESS_TYPE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 40 + "'", int0 == 40);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = null;
        com.google.javascript.jscomp.DiagnosticGroups.DEPRECATED = diagnosticGroup0;
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        com.google.javascript.rhino.jstype.JSType jSType0 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType1 = com.google.javascript.rhino.jstype.ObjectType.cast(jSType0);
        org.junit.Assert.assertNull(objectType1);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup1 = null;
        com.google.javascript.jscomp.DiagnosticGroup[] diagnosticGroupArray2 = new com.google.javascript.jscomp.DiagnosticGroup[] { diagnosticGroup1 };
        try {
            com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup3 = new com.google.javascript.jscomp.DiagnosticGroup("hi!", diagnosticGroupArray2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(diagnosticGroupArray2);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        com.google.javascript.jscomp.DiagnosticGroups diagnosticGroups0 = new com.google.javascript.jscomp.DiagnosticGroups();
    }

//    @Test
//    public void test011() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test011");
//        try {
//            com.google.javascript.rhino.Context.exit();
//            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Calling Context.exit without previous Context.enter");
//        } catch (java.lang.RuntimeException e) {
//        }
//    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        com.google.javascript.jscomp.CodingConvention codingConvention0 = null;
        try {
            com.google.javascript.rhino.Node node4 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode(codingConvention0, "hi!", 0, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        int int0 = com.google.javascript.rhino.Node.DIRECTCALL_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 26 + "'", int0 == 26);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        try {
            com.google.javascript.rhino.EcmaError ecmaError4 = com.google.javascript.rhino.ScriptRuntime.typeError3("hi!", "", "Unknown class name", "hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property hi!");
        } catch (java.lang.RuntimeException e) {
        }
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.jscomp.NodeTraversal nodeTraversal1 = null;
        com.google.javascript.rhino.Node node2 = null;
        try {
            com.google.javascript.jscomp.CodingConvention.ObjectLiteralCast objectLiteralCast3 = closureCodingConvention0.getObjectLiteralCast(nodeTraversal1, node2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        int int0 = com.google.javascript.rhino.Context.VERSION_1_4;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 140 + "'", int0 == 140);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.FILEOVERVIEW_JSDOC;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy0 = com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC;
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy0 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC + "'", propertyRenamingPolicy0.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC));
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        int int0 = com.google.javascript.rhino.Node.MEMBER_TYPE_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 32 + "'", int0 == 32);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        java.io.File file0 = null;
        try {
            com.google.javascript.jscomp.SourceFile sourceFile1 = com.google.javascript.jscomp.SourceFile.fromFile(file0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        com.google.javascript.rhino.Node node1 = null;
        com.google.javascript.rhino.Node node2 = null;
        com.google.javascript.rhino.Node node3 = null;
        try {
            com.google.javascript.rhino.Node node4 = new com.google.javascript.rhino.Node((int) (short) 100, node1, node2, node3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile1 = null;
        try {
            com.google.javascript.rhino.Node node2 = compiler0.parse(jSSourceFile1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        int int0 = com.google.javascript.rhino.Context.VERSION_DEFAULT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        int int0 = com.google.javascript.rhino.Node.LEFT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        int int0 = com.google.javascript.rhino.jstype.JSType.ENUMDECL;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        int int0 = com.google.javascript.rhino.Node.FREE_CALL;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 49 + "'", int0 == 49);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        com.google.javascript.jscomp.SourceMap.DetailLevel detailLevel0 = com.google.javascript.jscomp.SourceMap.DetailLevel.SYMBOLS;
        com.google.javascript.rhino.Node node1 = null;
        try {
            boolean boolean2 = detailLevel0.apply(node1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(detailLevel0);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        int int0 = com.google.javascript.rhino.Context.FEATURE_TO_STRING_AS_SOURCE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        boolean boolean1 = com.google.javascript.rhino.Context.isValidOptimizationLevel(1);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        int int0 = com.google.javascript.rhino.Node.OPT_ARG_NAME;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 36 + "'", int0 == 36);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        int int0 = com.google.javascript.rhino.Node.QUOTED_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 35 + "'", int0 == 35);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        com.google.javascript.jscomp.AnonymousFunctionNamingPolicy anonymousFunctionNamingPolicy0 = com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF;
        org.junit.Assert.assertTrue("'" + anonymousFunctionNamingPolicy0 + "' != '" + com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF + "'", anonymousFunctionNamingPolicy0.equals(com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF));
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node1 = null;
        boolean boolean2 = closureCodingConvention0.isVarArgsParameter(node1);
        com.google.javascript.rhino.jstype.ObjectType objectType3 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType4 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType5 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType6 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType7 = null;
        closureCodingConvention0.applyDelegateRelationship(objectType3, objectType4, objectType5, functionType6, functionType7);
        com.google.javascript.rhino.jstype.FunctionType functionType9 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType10 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType11 = null;
        closureCodingConvention0.applySubclassRelationship(functionType9, functionType10, subclassType11);
        com.google.javascript.rhino.Node node13 = null;
        try {
            java.lang.String str14 = closureCodingConvention0.identifyTypeDefAssign(node13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray1 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = null;
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray3 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile2 };
        com.google.javascript.jscomp.CompilerOptions compilerOptions4 = null;
        try {
            com.google.javascript.jscomp.Result result5 = compiler0.compile(jSSourceFileArray1, jSSourceFileArray3, compilerOptions4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFileArray3);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = null;
        com.google.javascript.jscomp.DiagnosticGroups.GLOBAL_THIS = diagnosticGroup0;
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        int int0 = com.google.javascript.rhino.Node.LAST_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 49 + "'", int0 == 49);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.Compiler.CodeBuilder codeBuilder1 = null;
        com.google.javascript.rhino.Node node3 = null;
        try {
            compiler0.toSource(codeBuilder1, (int) (byte) 100, node3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        com.google.javascript.jscomp.SourceMap.Format format0 = com.google.javascript.jscomp.SourceMap.Format.DEFAULT;
        org.junit.Assert.assertNotNull(format0);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        com.google.javascript.jscomp.AbstractCompiler abstractCompiler0 = null;
        com.google.javascript.jscomp.NodeTraversal.Callback callback1 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal2 = new com.google.javascript.jscomp.NodeTraversal(abstractCompiler0, callback1);
        com.google.javascript.rhino.Node node3 = null;
        com.google.javascript.jscomp.DiagnosticType diagnosticType7 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        com.google.javascript.jscomp.CheckLevel checkLevel8 = diagnosticType7.defaultLevel;
        com.google.javascript.jscomp.DiagnosticType diagnosticType9 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        com.google.javascript.jscomp.DiagnosticType diagnosticType10 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray12 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError13 = com.google.javascript.jscomp.JSError.make(diagnosticType10, strArray12);
        com.google.javascript.jscomp.DiagnosticType diagnosticType14 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray16 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError17 = com.google.javascript.jscomp.JSError.make(diagnosticType14, strArray16);
        com.google.javascript.jscomp.JSError jSError18 = com.google.javascript.jscomp.JSError.make(diagnosticType10, strArray16);
        com.google.javascript.jscomp.JSError jSError19 = com.google.javascript.jscomp.JSError.make("", 32, (int) (short) -1, checkLevel8, diagnosticType9, strArray16);
        com.google.javascript.jscomp.DiagnosticType diagnosticType20 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        com.google.javascript.jscomp.DiagnosticType diagnosticType21 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray23 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError24 = com.google.javascript.jscomp.JSError.make(diagnosticType21, strArray23);
        com.google.javascript.jscomp.DiagnosticType diagnosticType25 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray27 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError28 = com.google.javascript.jscomp.JSError.make(diagnosticType25, strArray27);
        com.google.javascript.jscomp.JSError jSError29 = com.google.javascript.jscomp.JSError.make(diagnosticType21, strArray27);
        try {
            com.google.javascript.jscomp.JSError jSError30 = nodeTraversal2.makeError(node3, checkLevel8, diagnosticType20, strArray27);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(diagnosticType7);
        org.junit.Assert.assertTrue("'" + checkLevel8 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel8.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticType9);
        org.junit.Assert.assertNotNull(diagnosticType10);
        org.junit.Assert.assertNotNull(strArray12);
        org.junit.Assert.assertNotNull(jSError13);
        org.junit.Assert.assertNotNull(diagnosticType14);
        org.junit.Assert.assertNotNull(strArray16);
        org.junit.Assert.assertNotNull(jSError17);
        org.junit.Assert.assertNotNull(jSError18);
        org.junit.Assert.assertNotNull(jSError19);
        org.junit.Assert.assertNotNull(diagnosticType20);
        org.junit.Assert.assertNotNull(diagnosticType21);
        org.junit.Assert.assertNotNull(strArray23);
        org.junit.Assert.assertNotNull(jSError24);
        org.junit.Assert.assertNotNull(diagnosticType25);
        org.junit.Assert.assertNotNull(strArray27);
        org.junit.Assert.assertNotNull(jSError28);
        org.junit.Assert.assertNotNull(jSError29);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        int int0 = com.google.javascript.rhino.Node.SPECIALCALL_WITH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        java.lang.String str0 = com.google.javascript.rhino.Context.languageVersionProperty;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "language version" + "'", str0.equals("language version"));
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        int int0 = com.google.javascript.rhino.Context.FEATURE_STRICT_MODE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 11 + "'", int0 == 11);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention1 = new com.google.javascript.jscomp.ClosureCodingConvention();
        java.lang.String str2 = closureCodingConvention1.getExportPropertyFunction();
        boolean boolean4 = closureCodingConvention1.isPrivate("");
        java.lang.RuntimeException runtimeException5 = com.google.javascript.rhino.ScriptRuntime.undefCallError((java.lang.Object) 11, (java.lang.Object) "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "goog.exportProperty" + "'", str2.equals("goog.exportProperty"));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(runtimeException5);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node[] nodeArray1 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList2 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean3 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList2, nodeArray1);
        com.google.javascript.jscomp.NodeTraversal.Callback callback4 = null;
        com.google.javascript.jscomp.NodeTraversal.traverseRoots((com.google.javascript.jscomp.AbstractCompiler) compiler0, (java.util.List<com.google.javascript.rhino.Node>) nodeList2, callback4);
        try {
            compiler0.rebuildInputsFromModules();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(nodeArray1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        boolean boolean1 = com.google.javascript.rhino.ScriptRuntime.isJSLineTerminator(40);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node[] nodeArray1 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList2 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean3 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList2, nodeArray1);
        com.google.javascript.jscomp.NodeTraversal.Callback callback4 = null;
        com.google.javascript.jscomp.NodeTraversal.traverseRoots((com.google.javascript.jscomp.AbstractCompiler) compiler0, (java.util.List<com.google.javascript.rhino.Node>) nodeList2, callback4);
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter6 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler0);
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray7 = new com.google.javascript.jscomp.JSSourceFile[] {};
        java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList8 = new java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile>();
        boolean boolean9 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList8, jSSourceFileArray7);
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray10 = new com.google.javascript.jscomp.JSSourceFile[] {};
        java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList11 = new java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile>();
        boolean boolean12 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList11, jSSourceFileArray10);
        com.google.javascript.jscomp.CompilerOptions compilerOptions13 = null;
        try {
            com.google.javascript.jscomp.Result result14 = compiler0.compile((java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList8, (java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList11, compilerOptions13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(nodeArray1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(jSSourceFileArray7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(jSSourceFileArray10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray1 = new com.google.javascript.jscomp.JSSourceFile[] {};
        java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList2 = new java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile>();
        boolean boolean3 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList2, jSSourceFileArray1);
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray4 = new com.google.javascript.jscomp.JSSourceFile[] {};
        java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList5 = new java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile>();
        boolean boolean6 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList5, jSSourceFileArray4);
        com.google.javascript.jscomp.CompilerOptions compilerOptions7 = null;
        try {
            compiler0.init((java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList2, (java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList5, compilerOptions7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFileArray1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(jSSourceFileArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        java.io.File file0 = null;
        java.nio.charset.Charset charset1 = null;
        try {
            com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromFile(file0, charset1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        java.lang.String str0 = com.google.javascript.rhino.jstype.JSType.NOT_A_CLASS;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "Not declared as a constructor" + "'", str0.equals("Not declared as a constructor"));
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        int int0 = com.google.javascript.rhino.Node.FLAG_THIS_UNMODIFIED;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        int int0 = com.google.javascript.rhino.Node.IS_CONSTANT_NAME;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 42 + "'", int0 == 42);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.Scope scope1 = compiler0.getTopScope();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = null;
        try {
            com.google.javascript.rhino.Node node3 = compiler0.parse(jSSourceFile2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(scope1);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        int int0 = com.google.javascript.rhino.Node.RIGHT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        int int0 = com.google.javascript.rhino.Node.USES_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 11 + "'", int0 == 11);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        int int0 = com.google.javascript.rhino.Node.DEBUGSOURCE_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 28 + "'", int0 == 28);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.GLOBAL_THIS;
        org.junit.Assert.assertNull(diagnosticGroup0);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        try {
            com.google.javascript.rhino.Context.reportWarning("Not declared as a constructor", "language version", 150, "goog.exportProperty", 2);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: No Context associated with current Thread");
        } catch (java.lang.RuntimeException e) {
        }
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        java.lang.String str1 = closureCodingConvention0.getExportPropertyFunction();
        boolean boolean3 = closureCodingConvention0.isPrivate("");
        boolean boolean5 = closureCodingConvention0.isPrivate("hi!");
        java.lang.String str6 = closureCodingConvention0.getAbstractMethodName();
        com.google.javascript.jscomp.AbstractCompiler abstractCompiler7 = null;
        com.google.javascript.jscomp.NodeTraversal.Callback callback8 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal9 = new com.google.javascript.jscomp.NodeTraversal(abstractCompiler7, callback8);
        boolean boolean10 = nodeTraversal9.hasScope();
        com.google.javascript.rhino.Node node11 = null;
        try {
            com.google.javascript.jscomp.CodingConvention.ObjectLiteralCast objectLiteralCast12 = closureCodingConvention0.getObjectLiteralCast(nodeTraversal9, node11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "goog.exportProperty" + "'", str1.equals("goog.exportProperty"));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "goog.abstractMethod" + "'", str6.equals("goog.abstractMethod"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node[] nodeArray1 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList2 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean3 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList2, nodeArray1);
        com.google.javascript.jscomp.NodeTraversal.Callback callback4 = null;
        com.google.javascript.jscomp.NodeTraversal.traverseRoots((com.google.javascript.jscomp.AbstractCompiler) compiler0, (java.util.List<com.google.javascript.rhino.Node>) nodeList2, callback4);
        try {
            boolean boolean6 = compiler0.isTypeCheckingEnabled();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(nodeArray1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        com.google.javascript.jscomp.AbstractCompiler abstractCompiler0 = null;
        com.google.javascript.jscomp.NodeTraversal.Callback callback1 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal2 = new com.google.javascript.jscomp.NodeTraversal(abstractCompiler0, callback1);
        com.google.javascript.jscomp.Compiler compiler3 = nodeTraversal2.getCompiler();
        com.google.javascript.rhino.Node node4 = null;
        com.google.javascript.rhino.Node[] nodeArray5 = new com.google.javascript.rhino.Node[] { node4 };
        try {
            nodeTraversal2.traverseRoots(nodeArray5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(compiler3);
        org.junit.Assert.assertNotNull(nodeArray5);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        int int0 = com.google.javascript.rhino.Node.TEMP_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 6 + "'", int0 == 6);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        com.google.javascript.jscomp.AbstractCompiler abstractCompiler0 = null;
        com.google.javascript.jscomp.NodeTraversal.Callback callback1 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal2 = new com.google.javascript.jscomp.NodeTraversal(abstractCompiler0, callback1);
        com.google.javascript.jscomp.Compiler compiler3 = nodeTraversal2.getCompiler();
        java.util.List<com.google.javascript.rhino.Node> nodeList4 = null;
        try {
            nodeTraversal2.traverseRoots(nodeList4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(compiler3);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        int int0 = com.google.javascript.rhino.Context.VERSION_1_0;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 100 + "'", int0 == 100);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        int int0 = com.google.javascript.rhino.Context.FEATURE_WARNING_AS_ERROR;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 12 + "'", int0 == 12);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node[] nodeArray1 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList2 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean3 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList2, nodeArray1);
        com.google.javascript.jscomp.NodeTraversal.Callback callback4 = null;
        com.google.javascript.jscomp.NodeTraversal.traverseRoots((com.google.javascript.jscomp.AbstractCompiler) compiler0, (java.util.List<com.google.javascript.rhino.Node>) nodeList2, callback4);
        try {
            com.google.javascript.jscomp.CompilerInput compilerInput7 = compiler0.getInput("goog.abstractMethod");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(nodeArray1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        com.google.javascript.jscomp.AbstractCompiler abstractCompiler0 = null;
        com.google.javascript.jscomp.NodeTraversal.Callback callback1 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal2 = new com.google.javascript.jscomp.NodeTraversal(abstractCompiler0, callback1);
        boolean boolean3 = nodeTraversal2.hasScope();
        com.google.javascript.rhino.Node node4 = null;
        com.google.javascript.jscomp.CheckLevel checkLevel5 = com.google.javascript.jscomp.CheckLevel.ERROR;
        com.google.javascript.jscomp.DiagnosticType diagnosticType9 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        com.google.javascript.jscomp.CheckLevel checkLevel10 = diagnosticType9.defaultLevel;
        com.google.javascript.jscomp.DiagnosticType diagnosticType11 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        com.google.javascript.jscomp.DiagnosticType diagnosticType12 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray14 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError15 = com.google.javascript.jscomp.JSError.make(diagnosticType12, strArray14);
        com.google.javascript.jscomp.DiagnosticType diagnosticType16 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray18 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError19 = com.google.javascript.jscomp.JSError.make(diagnosticType16, strArray18);
        com.google.javascript.jscomp.JSError jSError20 = com.google.javascript.jscomp.JSError.make(diagnosticType12, strArray18);
        com.google.javascript.jscomp.JSError jSError21 = com.google.javascript.jscomp.JSError.make("", 32, (int) (short) -1, checkLevel10, diagnosticType11, strArray18);
        java.lang.String[] strArray22 = new java.lang.String[] {};
        try {
            com.google.javascript.jscomp.JSError jSError23 = nodeTraversal2.makeError(node4, checkLevel5, diagnosticType11, strArray22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + checkLevel5 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel5.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticType9);
        org.junit.Assert.assertTrue("'" + checkLevel10 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel10.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticType11);
        org.junit.Assert.assertNotNull(diagnosticType12);
        org.junit.Assert.assertNotNull(strArray14);
        org.junit.Assert.assertNotNull(jSError15);
        org.junit.Assert.assertNotNull(diagnosticType16);
        org.junit.Assert.assertNotNull(strArray18);
        org.junit.Assert.assertNotNull(jSError19);
        org.junit.Assert.assertNotNull(jSError20);
        org.junit.Assert.assertNotNull(jSError21);
        org.junit.Assert.assertNotNull(strArray22);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = null;
        com.google.javascript.jscomp.DiagnosticGroups.CHECK_USELESS_CODE = diagnosticGroup0;
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        int int0 = com.google.javascript.rhino.Node.CODEOFFSET_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 8 + "'", int0 == 8);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        com.google.javascript.jscomp.ErrorFormat errorFormat0 = com.google.javascript.jscomp.ErrorFormat.LEGACY;
        org.junit.Assert.assertNotNull(errorFormat0);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        int int0 = com.google.javascript.rhino.Node.SIDE_EFFECT_FLAGS;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 41 + "'", int0 == 41);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        boolean boolean1 = com.google.javascript.rhino.Context.isValidOptimizationLevel((int) ' ');
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        java.lang.String str1 = closureCodingConvention0.getExportPropertyFunction();
        boolean boolean3 = closureCodingConvention0.isPrivate("");
        boolean boolean5 = closureCodingConvention0.isPrivate("hi!");
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString((int) (short) 0, "");
        boolean boolean9 = closureCodingConvention0.isOptionalParameter(node8);
        try {
            node8.setDouble(0.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: EOF  is not a string node");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "goog.exportProperty" + "'", str1.equals("goog.exportProperty"));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        int int0 = com.google.javascript.rhino.Node.LOCAL_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 7 + "'", int0 == 7);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        com.google.javascript.jscomp.parsing.Config.LanguageMode languageMode0 = com.google.javascript.jscomp.parsing.Config.LanguageMode.ECMASCRIPT3;
        org.junit.Assert.assertTrue("'" + languageMode0 + "' != '" + com.google.javascript.jscomp.parsing.Config.LanguageMode.ECMASCRIPT3 + "'", languageMode0.equals(com.google.javascript.jscomp.parsing.Config.LanguageMode.ECMASCRIPT3));
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        java.io.InputStream inputStream2 = null;
        try {
            com.google.javascript.jscomp.SourceFile sourceFile3 = com.google.javascript.jscomp.SourceFile.fromInputStream("<No stack trace available>", "goog.abstractMethod", inputStream2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node1 = null;
        boolean boolean2 = closureCodingConvention0.isVarArgsParameter(node1);
        com.google.javascript.rhino.jstype.ObjectType objectType3 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType4 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType5 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType6 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType7 = null;
        closureCodingConvention0.applyDelegateRelationship(objectType3, objectType4, objectType5, functionType6, functionType7);
        com.google.javascript.rhino.jstype.FunctionType functionType9 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType10 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType11 = null;
        closureCodingConvention0.applySubclassRelationship(functionType9, functionType10, subclassType11);
        boolean boolean14 = closureCodingConvention0.isValidEnumKey("hi!");
        com.google.javascript.rhino.Node node15 = null;
        try {
            boolean boolean16 = closureCodingConvention0.isPropertyTestFunction(node15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        java.lang.String str0 = com.google.javascript.rhino.Context.errorReporterProperty;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "error reporter" + "'", str0.equals("error reporter"));
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node[] nodeArray1 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList2 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean3 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList2, nodeArray1);
        com.google.javascript.jscomp.NodeTraversal.Callback callback4 = null;
        com.google.javascript.jscomp.NodeTraversal.traverseRoots((com.google.javascript.jscomp.AbstractCompiler) compiler0, (java.util.List<com.google.javascript.rhino.Node>) nodeList2, callback4);
        com.google.javascript.jscomp.PerformanceTracker performanceTracker6 = compiler0.tracker;
        com.google.javascript.jscomp.SourceExcerptProvider.SourceExcerpt sourceExcerpt7 = null;
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter8 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler0, sourceExcerpt7);
        com.google.javascript.jscomp.PassConfig passConfig9 = null;
        try {
            compiler0.setPassConfig(passConfig9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(nodeArray1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(performanceTracker6);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.CHECK_USELESS_CODE;
        com.google.javascript.jscomp.DiagnosticGroups.GLOBAL_THIS = diagnosticGroup0;
        org.junit.Assert.assertNull(diagnosticGroup0);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        try {
            com.google.javascript.rhino.EcmaError ecmaError1 = com.google.javascript.rhino.ScriptRuntime.typeError0("goog.abstractMethod");
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property goog.abstractMethod");
        } catch (java.lang.RuntimeException e) {
        }
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention2 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node3 = null;
        boolean boolean4 = closureCodingConvention2.isVarArgsParameter(node3);
        com.google.javascript.rhino.jstype.ObjectType objectType5 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType6 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType7 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType8 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType9 = null;
        closureCodingConvention2.applyDelegateRelationship(objectType5, objectType6, objectType7, functionType8, functionType9);
        com.google.javascript.rhino.Node node12 = new com.google.javascript.rhino.Node((int) (short) 10);
        java.lang.Object obj14 = node12.getProp((int) (short) 1);
        try {
            java.lang.String str16 = com.google.javascript.rhino.ScriptRuntime.getMessage4("error reporter", (java.lang.Object) (short) 1, (java.lang.Object) functionType8, obj14, (java.lang.Object) 42);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property error reporter");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(obj14);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        com.google.javascript.jscomp.CompilerOptions.TracerMode tracerMode0 = com.google.javascript.jscomp.CompilerOptions.TracerMode.FAST;
        org.junit.Assert.assertTrue("'" + tracerMode0 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TracerMode.FAST + "'", tracerMode0.equals(com.google.javascript.jscomp.CompilerOptions.TracerMode.FAST));
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        int int0 = com.google.javascript.rhino.Node.SPECIALCALL_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 27 + "'", int0 == 27);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        int int0 = com.google.javascript.rhino.Node.LASTUSE_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 24 + "'", int0 == 24);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        int int0 = com.google.javascript.rhino.Context.FEATURE_PARENT_PROTO_PROPRTIES;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 5 + "'", int0 == 5);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node[] nodeArray1 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList2 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean3 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList2, nodeArray1);
        com.google.javascript.jscomp.NodeTraversal.Callback callback4 = null;
        com.google.javascript.jscomp.NodeTraversal.traverseRoots((com.google.javascript.jscomp.AbstractCompiler) compiler0, (java.util.List<com.google.javascript.rhino.Node>) nodeList2, callback4);
        try {
            boolean boolean6 = compiler0.hasErrors();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(nodeArray1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        int int0 = com.google.javascript.rhino.Node.DESCENDANTS_FLAG;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        java.io.InputStream inputStream1 = null;
        try {
            com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromInputStream("goog.exportProperty", inputStream1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        java.lang.String str1 = com.google.javascript.rhino.jstype.ObjectType.createDelegateSuffix("JSC_NODE_TRAVERSAL_ERROR.  at (unknown source) line (unknown line) : (unknown column)");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "(JSC_NODE_TRAVERSAL_ERROR.  at (unknown source) line (unknown line) : (unknown column))" + "'", str1.equals("(JSC_NODE_TRAVERSAL_ERROR.  at (unknown source) line (unknown line) : (unknown column))"));
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        java.io.Reader reader1 = null;
        try {
            com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromReader("JSC_NODE_TRAVERSAL_ERROR.  at (unknown source) line (unknown line) : (unknown column)", reader1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        com.google.javascript.jscomp.AnonymousFunctionNamingPolicy anonymousFunctionNamingPolicy0 = com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.MAPPED;
        org.junit.Assert.assertTrue("'" + anonymousFunctionNamingPolicy0 + "' != '" + com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.MAPPED + "'", anonymousFunctionNamingPolicy0.equals(com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.MAPPED));
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        java.lang.String str2 = com.google.javascript.rhino.ScriptRuntime.numberToString((double) (byte) 100, 2);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1100100" + "'", str2.equals("1100100"));
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.CompilerOptions compilerOptions1 = null;
        try {
            compiler0.initOptions(compilerOptions1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        com.google.javascript.jscomp.SourceMap.DetailLevel detailLevel0 = com.google.javascript.jscomp.SourceMap.DetailLevel.SYMBOLS;
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString((int) (short) 0, "");
        node3.setVarArgs(true);
        boolean boolean6 = detailLevel0.apply(node3);
        try {
            double double7 = node3.getDouble();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: EOF  [jsdoc_info: 1] is not a number node");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(detailLevel0);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node[] nodeArray1 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList2 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean3 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList2, nodeArray1);
        com.google.javascript.jscomp.NodeTraversal.Callback callback4 = null;
        com.google.javascript.jscomp.NodeTraversal.traverseRoots((com.google.javascript.jscomp.AbstractCompiler) compiler0, (java.util.List<com.google.javascript.rhino.Node>) nodeList2, callback4);
        com.google.javascript.jscomp.PerformanceTracker performanceTracker6 = compiler0.tracker;
        try {
            com.google.javascript.jscomp.JSError[] jSErrorArray7 = compiler0.getMessages();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(nodeArray1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(performanceTracker6);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node[] nodeArray1 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList2 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean3 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList2, nodeArray1);
        com.google.javascript.jscomp.NodeTraversal.Callback callback4 = null;
        com.google.javascript.jscomp.NodeTraversal.traverseRoots((com.google.javascript.jscomp.AbstractCompiler) compiler0, (java.util.List<com.google.javascript.rhino.Node>) nodeList2, callback4);
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter6 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler0);
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray7 = new com.google.javascript.jscomp.JSSourceFile[] {};
        java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList8 = new java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile>();
        boolean boolean9 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList8, jSSourceFileArray7);
        java.util.List<com.google.javascript.jscomp.JSModule> jSModuleList10 = null;
        com.google.javascript.jscomp.CompilerOptions compilerOptions11 = null;
        try {
            com.google.javascript.jscomp.Result result12 = compiler0.compileModules((java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList8, jSModuleList10, compilerOptions11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(nodeArray1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(jSSourceFileArray7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        int int0 = com.google.javascript.rhino.Node.MAX_COLUMN_NUMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4095 + "'", int0 == 4095);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString("language version");
        int int4 = node3.getLineno();
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.Node.newString((int) (short) 0, "");
        com.google.javascript.rhino.Node[] nodeArray8 = new com.google.javascript.rhino.Node[] { node3, node7 };
        com.google.javascript.rhino.Node node11 = new com.google.javascript.rhino.Node((int) (short) 100, nodeArray8, 40, 0);
        try {
            com.google.javascript.rhino.Node node14 = new com.google.javascript.rhino.Node((int) (byte) 1, nodeArray8, 36, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: duplicate child");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertNotNull(nodeArray8);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        com.google.javascript.jscomp.DiagnosticType diagnosticType0 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray2 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError3 = com.google.javascript.jscomp.JSError.make(diagnosticType0, strArray2);
        java.lang.String str4 = diagnosticType0.key;
        org.junit.Assert.assertNotNull(diagnosticType0);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(jSError3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "JSC_NODE_TRAVERSAL_ERROR" + "'", str4.equals("JSC_NODE_TRAVERSAL_ERROR"));
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node[] nodeArray1 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList2 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean3 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList2, nodeArray1);
        com.google.javascript.jscomp.NodeTraversal.Callback callback4 = null;
        com.google.javascript.jscomp.NodeTraversal.traverseRoots((com.google.javascript.jscomp.AbstractCompiler) compiler0, (java.util.List<com.google.javascript.rhino.Node>) nodeList2, callback4);
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter6 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler0);
        try {
            int int7 = compiler0.getErrorCount();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(nodeArray1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy0 = com.google.javascript.jscomp.VariableRenamingPolicy.ALL;
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy0 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.ALL + "'", variableRenamingPolicy0.equals(com.google.javascript.jscomp.VariableRenamingPolicy.ALL));
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        int int0 = com.google.javascript.rhino.Node.NO_SIDE_EFFECTS;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 15 + "'", int0 == 15);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        int int0 = com.google.javascript.rhino.Context.VERSION_UNKNOWN;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + (-1) + "'", int0 == (-1));
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node[] nodeArray1 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList2 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean3 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList2, nodeArray1);
        com.google.javascript.jscomp.NodeTraversal.Callback callback4 = null;
        com.google.javascript.jscomp.NodeTraversal.traverseRoots((com.google.javascript.jscomp.AbstractCompiler) compiler0, (java.util.List<com.google.javascript.rhino.Node>) nodeList2, callback4);
        com.google.javascript.jscomp.PerformanceTracker performanceTracker6 = compiler0.tracker;
        com.google.javascript.jscomp.SourceExcerptProvider.SourceExcerpt sourceExcerpt7 = null;
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter8 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler0, sourceExcerpt7);
        com.google.javascript.jscomp.DiagnosticType diagnosticType12 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        com.google.javascript.jscomp.CheckLevel checkLevel13 = diagnosticType12.defaultLevel;
        com.google.javascript.jscomp.DiagnosticType diagnosticType14 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        com.google.javascript.jscomp.DiagnosticType diagnosticType15 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray17 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError18 = com.google.javascript.jscomp.JSError.make(diagnosticType15, strArray17);
        com.google.javascript.jscomp.DiagnosticType diagnosticType19 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray21 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError22 = com.google.javascript.jscomp.JSError.make(diagnosticType19, strArray21);
        com.google.javascript.jscomp.JSError jSError23 = com.google.javascript.jscomp.JSError.make(diagnosticType15, strArray21);
        com.google.javascript.jscomp.JSError jSError24 = com.google.javascript.jscomp.JSError.make("", 32, (int) (short) -1, checkLevel13, diagnosticType14, strArray21);
        try {
            java.lang.String str25 = lightweightMessageFormatter8.formatWarning(jSError24);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(nodeArray1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(performanceTracker6);
        org.junit.Assert.assertNotNull(diagnosticType12);
        org.junit.Assert.assertTrue("'" + checkLevel13 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel13.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticType14);
        org.junit.Assert.assertNotNull(diagnosticType15);
        org.junit.Assert.assertNotNull(strArray17);
        org.junit.Assert.assertNotNull(jSError18);
        org.junit.Assert.assertNotNull(diagnosticType19);
        org.junit.Assert.assertNotNull(strArray21);
        org.junit.Assert.assertNotNull(jSError22);
        org.junit.Assert.assertNotNull(jSError23);
        org.junit.Assert.assertNotNull(jSError24);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        try {
            com.google.javascript.rhino.EcmaError ecmaError1 = com.google.javascript.rhino.ScriptRuntime.typeError0("language version");
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property language version");
        } catch (java.lang.RuntimeException e) {
        }
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        java.lang.String str1 = closureCodingConvention0.getExportPropertyFunction();
        boolean boolean3 = closureCodingConvention0.isPrivate("");
        boolean boolean5 = closureCodingConvention0.isPrivate("hi!");
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString((int) (short) 0, "");
        boolean boolean9 = closureCodingConvention0.isOptionalParameter(node8);
        com.google.javascript.rhino.Node node10 = null;
        try {
            java.util.List<java.lang.String> strList11 = closureCodingConvention0.identifyTypeDeclarationCall(node10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "goog.exportProperty" + "'", str1.equals("goog.exportProperty"));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        int int0 = com.google.javascript.rhino.Node.CONTINUE_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        com.google.javascript.rhino.Node node2 = new com.google.javascript.rhino.Node((int) (short) 10);
        java.lang.Object obj4 = node2.getProp((int) (short) 1);
        boolean boolean5 = node2.hasMoreThanOneChild();
        com.google.javascript.rhino.Node node7 = new com.google.javascript.rhino.Node((int) (short) 10);
        java.lang.Object obj9 = node7.getProp((int) (short) 1);
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString((int) (short) 0, "");
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable13 = node12.siblings();
        com.google.javascript.rhino.Node node14 = new com.google.javascript.rhino.Node((-1), node2, node7, node12);
        com.google.javascript.rhino.JSDocInfo jSDocInfo15 = null;
        node7.setJSDocInfo(jSDocInfo15);
        try {
            double double17 = node7.getDouble();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: BITXOR is not a number node");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNull(obj4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(obj9);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(nodeIterable13);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        com.google.javascript.jscomp.mozilla.rhino.ast.AstRoot astRoot0 = null;
        com.google.javascript.jscomp.parsing.Config config2 = null;
        com.google.javascript.jscomp.mozilla.rhino.ErrorReporter errorReporter3 = null;
        try {
            com.google.javascript.rhino.Node node4 = com.google.javascript.jscomp.parsing.IRFactory.transformTree(astRoot0, "Node tree inequality:\nTree1:\nSTRING language version\n\n\nTree2:\nEOF \n\n\nSubtree1: STRING language version\n\n\nSubtree2: EOF \n", config2, errorReporter3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = null;
        com.google.javascript.jscomp.DiagnosticGroups.NON_STANDARD_JSDOC = diagnosticGroup0;
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        int int0 = com.google.javascript.rhino.Node.BOTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node[] nodeArray1 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList2 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean3 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList2, nodeArray1);
        com.google.javascript.jscomp.NodeTraversal.Callback callback4 = null;
        com.google.javascript.jscomp.NodeTraversal.traverseRoots((com.google.javascript.jscomp.AbstractCompiler) compiler0, (java.util.List<com.google.javascript.rhino.Node>) nodeList2, callback4);
        com.google.javascript.jscomp.PerformanceTracker performanceTracker6 = compiler0.tracker;
        com.google.javascript.jscomp.SourceExcerptProvider.SourceExcerpt sourceExcerpt7 = null;
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter8 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler0, sourceExcerpt7);
        com.google.javascript.rhino.Node node11 = new com.google.javascript.rhino.Node((int) (short) 10);
        java.lang.Object obj13 = node11.getProp((int) (short) 1);
        boolean boolean14 = node11.hasMoreThanOneChild();
        com.google.javascript.rhino.Node node16 = new com.google.javascript.rhino.Node((int) (short) 10);
        java.lang.Object obj18 = node16.getProp((int) (short) 1);
        com.google.javascript.rhino.Node node21 = com.google.javascript.rhino.Node.newString((int) (short) 0, "");
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable22 = node21.siblings();
        com.google.javascript.rhino.Node node23 = new com.google.javascript.rhino.Node((-1), node11, node16, node21);
        boolean boolean24 = node21.wasEmptyNode();
        com.google.javascript.jscomp.NodeTraversal.Callback callback25 = null;
        try {
            com.google.javascript.jscomp.NodeTraversal.traverse((com.google.javascript.jscomp.AbstractCompiler) compiler0, node21, callback25);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: INTERNAL COMPILER ERROR.\nPlease report this problem.\nnull");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(nodeArray1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(performanceTracker6);
        org.junit.Assert.assertNull(obj13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNull(obj18);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertNotNull(nodeIterable22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        int int0 = com.google.javascript.rhino.Node.ENUM_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        com.google.javascript.rhino.Node node1 = null;
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString((int) (short) 0, "");
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable5 = node4.siblings();
        boolean boolean6 = node4.isNoSideEffectsCall();
        java.lang.String str7 = node4.getString();
        com.google.javascript.rhino.Node node9 = new com.google.javascript.rhino.Node((int) (short) 10);
        java.lang.Object obj11 = node9.getProp((int) (short) 1);
        com.google.javascript.rhino.JSDocInfo jSDocInfo12 = node9.getJSDocInfo();
        com.google.javascript.rhino.Node node14 = new com.google.javascript.rhino.Node((int) (short) 10);
        java.lang.Object obj16 = node14.getProp((int) (short) 1);
        com.google.javascript.rhino.JSDocInfo jSDocInfo17 = node14.getJSDocInfo();
        try {
            com.google.javascript.rhino.Node node18 = new com.google.javascript.rhino.Node(49, node1, node4, node9, node14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(nodeIterable5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertNull(obj11);
        org.junit.Assert.assertNull(jSDocInfo12);
        org.junit.Assert.assertNull(obj16);
        org.junit.Assert.assertNull(jSDocInfo17);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        int int0 = com.google.javascript.rhino.Node.ATTRIBUTE_FLAG;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        int int0 = com.google.javascript.rhino.Node.VARIABLE_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 23 + "'", int0 == 23);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        int int0 = com.google.javascript.rhino.Context.FEATURE_LOCATION_INFORMATION_IN_ERROR;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newString("language version");
        int int2 = node1.getLineno();
        node1.setSourcePositionForTree(41);
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        com.google.javascript.jscomp.AbstractCompiler abstractCompiler0 = null;
        com.google.javascript.jscomp.NodeTraversal.Callback callback1 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal2 = new com.google.javascript.jscomp.NodeTraversal(abstractCompiler0, callback1);
        com.google.javascript.jscomp.Compiler compiler3 = nodeTraversal2.getCompiler();
        try {
            com.google.javascript.jscomp.JSModule jSModule4 = nodeTraversal2.getModule();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(compiler3);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        int int0 = com.google.javascript.rhino.Node.LOCALCOUNT_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 21 + "'", int0 == 21);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newString("language version");
        int int2 = node1.getLineno();
        int int4 = node1.getIntProp(24);
        com.google.javascript.rhino.Node.SideEffectFlags sideEffectFlags5 = null;
        try {
            node1.setSideEffectFlags(sideEffectFlags5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.FILEOVERVIEW_JSDOC;
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup1 = com.google.javascript.jscomp.DiagnosticGroups.CHECK_VARIABLES;
        com.google.javascript.jscomp.DiagnosticGroups.CONSTANT_PROPERTY = diagnosticGroup1;
        com.google.javascript.jscomp.DiagnosticGroup[] diagnosticGroupArray3 = new com.google.javascript.jscomp.DiagnosticGroup[] { diagnosticGroup0, diagnosticGroup1 };
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup4 = new com.google.javascript.jscomp.DiagnosticGroup(diagnosticGroupArray3);
        com.google.javascript.jscomp.DiagnosticGroups.TYPE_INVALIDATION = diagnosticGroup4;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
        org.junit.Assert.assertNotNull(diagnosticGroup1);
        org.junit.Assert.assertNotNull(diagnosticGroupArray3);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        com.google.javascript.jscomp.DiagnosticType diagnosticType3 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        com.google.javascript.jscomp.CheckLevel checkLevel4 = diagnosticType3.defaultLevel;
        com.google.javascript.jscomp.DiagnosticType diagnosticType5 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        com.google.javascript.jscomp.DiagnosticType diagnosticType6 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray8 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError9 = com.google.javascript.jscomp.JSError.make(diagnosticType6, strArray8);
        com.google.javascript.jscomp.DiagnosticType diagnosticType10 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray12 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError13 = com.google.javascript.jscomp.JSError.make(diagnosticType10, strArray12);
        com.google.javascript.jscomp.JSError jSError14 = com.google.javascript.jscomp.JSError.make(diagnosticType6, strArray12);
        com.google.javascript.jscomp.JSError jSError15 = com.google.javascript.jscomp.JSError.make("", 32, (int) (short) -1, checkLevel4, diagnosticType5, strArray12);
        java.lang.String str16 = jSError15.toString();
        org.junit.Assert.assertNotNull(diagnosticType3);
        org.junit.Assert.assertTrue("'" + checkLevel4 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel4.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticType5);
        org.junit.Assert.assertNotNull(diagnosticType6);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertNotNull(jSError9);
        org.junit.Assert.assertNotNull(diagnosticType10);
        org.junit.Assert.assertNotNull(strArray12);
        org.junit.Assert.assertNotNull(jSError13);
        org.junit.Assert.assertNotNull(jSError14);
        org.junit.Assert.assertNotNull(jSError15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "JSC_NODE_TRAVERSAL_ERROR.  at (unknown source) line 32 : (unknown column)" + "'", str16.equals("JSC_NODE_TRAVERSAL_ERROR.  at (unknown source) line 32 : (unknown column)"));
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        com.google.javascript.jscomp.mozilla.rhino.ast.AstRoot astRoot0 = null;
        com.google.javascript.jscomp.parsing.Config config2 = null;
        com.google.javascript.jscomp.mozilla.rhino.ErrorReporter errorReporter3 = null;
        try {
            com.google.javascript.rhino.Node node4 = com.google.javascript.jscomp.parsing.IRFactory.transformTree(astRoot0, "Unknown class name", config2, errorReporter3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromFile("error reporter");
        com.google.javascript.jscomp.JsAst jsAst3 = new com.google.javascript.jscomp.JsAst((com.google.javascript.jscomp.SourceFile) jSSourceFile2);
        com.google.javascript.jscomp.JSModule jSModule4 = null;
        com.google.javascript.jscomp.JSModule[] jSModuleArray5 = new com.google.javascript.jscomp.JSModule[] { jSModule4 };
        com.google.javascript.jscomp.CompilerOptions compilerOptions6 = null;
        try {
            com.google.javascript.jscomp.Result result7 = compiler0.compile(jSSourceFile2, jSModuleArray5, compilerOptions6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile2);
        org.junit.Assert.assertNotNull(jSModuleArray5);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.Scope scope1 = compiler0.getTopScope();
        com.google.javascript.rhino.Node node2 = compiler0.getRoot();
        com.google.javascript.jscomp.JSModule jSModule3 = null;
        try {
            java.lang.String[] strArray4 = compiler0.toSourceArray(jSModule3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(scope1);
        org.junit.Assert.assertNull(node2);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node1 = null;
        boolean boolean2 = closureCodingConvention0.isVarArgsParameter(node1);
        com.google.javascript.rhino.jstype.ObjectType objectType3 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType4 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType5 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType6 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType7 = null;
        closureCodingConvention0.applyDelegateRelationship(objectType3, objectType4, objectType5, functionType6, functionType7);
        com.google.javascript.rhino.jstype.FunctionType functionType9 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType10 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType11 = null;
        closureCodingConvention0.applySubclassRelationship(functionType9, functionType10, subclassType11);
        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.Node.newString("Unknown class name", 8, 7);
        com.google.javascript.rhino.Node node17 = null;
        try {
            java.lang.String str18 = closureCodingConvention0.extractClassNameIfProvide(node16, node17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(node16);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        com.google.javascript.rhino.EvaluatorException evaluatorException1 = new com.google.javascript.rhino.EvaluatorException("hi!");
        evaluatorException1.initLineSource("");
        try {
            evaluatorException1.initLineNumber(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        com.google.javascript.jscomp.AbstractCompiler abstractCompiler0 = null;
        com.google.javascript.jscomp.NodeTraversal.Callback callback1 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal2 = new com.google.javascript.jscomp.NodeTraversal(abstractCompiler0, callback1);
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newString((int) (short) 0, "");
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable6 = node5.siblings();
        node5.detachChildren();
        try {
            nodeTraversal2.traverse(node5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNotNull(nodeIterable6);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node[] nodeArray1 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList2 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean3 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList2, nodeArray1);
        com.google.javascript.jscomp.NodeTraversal.Callback callback4 = null;
        com.google.javascript.jscomp.NodeTraversal.traverseRoots((com.google.javascript.jscomp.AbstractCompiler) compiler0, (java.util.List<com.google.javascript.rhino.Node>) nodeList2, callback4);
        com.google.javascript.jscomp.PerformanceTracker performanceTracker6 = compiler0.tracker;
        com.google.javascript.jscomp.SourceExcerptProvider.SourceExcerpt sourceExcerpt7 = null;
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter8 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler0, sourceExcerpt7);
        try {
            boolean boolean9 = compiler0.hasErrors();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(nodeArray1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(performanceTracker6);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        int int0 = com.google.javascript.rhino.Context.VERSION_1_1;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 110 + "'", int0 == 110);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node[] nodeArray1 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList2 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean3 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList2, nodeArray1);
        com.google.javascript.jscomp.NodeTraversal.Callback callback4 = null;
        com.google.javascript.jscomp.NodeTraversal.traverseRoots((com.google.javascript.jscomp.AbstractCompiler) compiler0, (java.util.List<com.google.javascript.rhino.Node>) nodeList2, callback4);
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter6 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler0);
        com.google.javascript.jscomp.DiagnosticType diagnosticType7 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        com.google.javascript.jscomp.CheckLevel checkLevel8 = diagnosticType7.defaultLevel;
        java.lang.String[] strArray11 = new java.lang.String[] { "JSC_NODE_TRAVERSAL_ERROR.  at (unknown source) line (unknown line) : (unknown column)", "language version" };
        com.google.javascript.jscomp.JSError jSError12 = com.google.javascript.jscomp.JSError.make(diagnosticType7, strArray11);
        java.lang.String str13 = lightweightMessageFormatter6.formatWarning(jSError12);
        com.google.javascript.jscomp.CheckLevel checkLevel14 = null;
        com.google.javascript.jscomp.Compiler compiler15 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node[] nodeArray16 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList17 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean18 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList17, nodeArray16);
        com.google.javascript.jscomp.NodeTraversal.Callback callback19 = null;
        com.google.javascript.jscomp.NodeTraversal.traverseRoots((com.google.javascript.jscomp.AbstractCompiler) compiler15, (java.util.List<com.google.javascript.rhino.Node>) nodeList17, callback19);
        com.google.javascript.jscomp.PerformanceTracker performanceTracker21 = compiler15.tracker;
        com.google.javascript.jscomp.SourceExcerptProvider.SourceExcerpt sourceExcerpt22 = null;
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter23 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler15, sourceExcerpt22);
        try {
            java.lang.String str24 = jSError12.format(checkLevel14, (com.google.javascript.jscomp.MessageFormatter) lightweightMessageFormatter23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(nodeArray1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(diagnosticType7);
        org.junit.Assert.assertTrue("'" + checkLevel8 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel8.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(strArray11);
        org.junit.Assert.assertNotNull(jSError12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "WARNING - JSC_NODE_TRAVERSAL_ERROR.  at (unknown source) line (unknown line) : (unknown column)\n" + "'", str13.equals("WARNING - JSC_NODE_TRAVERSAL_ERROR.  at (unknown source) line (unknown line) : (unknown column)\n"));
        org.junit.Assert.assertNotNull(nodeArray16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNull(performanceTracker21);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        com.google.javascript.rhino.EvaluatorException evaluatorException3 = new com.google.javascript.rhino.EvaluatorException("", "<No stack trace available>", (int) (short) 100);
        java.lang.RuntimeException runtimeException5 = com.google.javascript.rhino.ScriptRuntime.notFunctionError((java.lang.Object) '4');
        evaluatorException3.addSuppressed((java.lang.Throwable) runtimeException5);
        try {
            evaluatorException3.initLineNumber(3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(runtimeException5);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node[] nodeArray1 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList2 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean3 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList2, nodeArray1);
        com.google.javascript.jscomp.NodeTraversal.Callback callback4 = null;
        com.google.javascript.jscomp.NodeTraversal.traverseRoots((com.google.javascript.jscomp.AbstractCompiler) compiler0, (java.util.List<com.google.javascript.rhino.Node>) nodeList2, callback4);
        com.google.javascript.jscomp.PerformanceTracker performanceTracker6 = compiler0.tracker;
        com.google.javascript.jscomp.SourceExcerptProvider.SourceExcerpt sourceExcerpt7 = null;
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter8 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler0, sourceExcerpt7);
        try {
            com.google.javascript.jscomp.CompilerInput compilerInput10 = compiler0.newExternInput("");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(nodeArray1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(performanceTracker6);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        com.google.javascript.jscomp.AbstractCompiler abstractCompiler0 = null;
        com.google.javascript.jscomp.NodeTraversal.Callback callback1 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal2 = new com.google.javascript.jscomp.NodeTraversal(abstractCompiler0, callback1);
        boolean boolean3 = nodeTraversal2.hasScope();
        try {
            com.google.javascript.jscomp.JSModule jSModule4 = nodeTraversal2.getModule();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        int int0 = com.google.javascript.rhino.Node.SPECIALCALL_EVAL;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        try {
            com.google.javascript.rhino.Context.reportWarning("language version", "1100100", (int) (byte) 1, "<No stack trace available>", 27);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: No Context associated with current Thread");
        } catch (java.lang.RuntimeException e) {
        }
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newString("language version");
        node1.setQuotedString();
        com.google.javascript.rhino.Node node3 = null;
        com.google.javascript.rhino.Node node6 = new com.google.javascript.rhino.Node((int) (short) 10);
        java.lang.Object obj8 = node6.getProp((int) (short) 1);
        boolean boolean9 = node6.hasMoreThanOneChild();
        com.google.javascript.rhino.Node node11 = new com.google.javascript.rhino.Node((int) (short) 10);
        java.lang.Object obj13 = node11.getProp((int) (short) 1);
        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.Node.newString((int) (short) 0, "");
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable17 = node16.siblings();
        com.google.javascript.rhino.Node node18 = new com.google.javascript.rhino.Node((-1), node6, node11, node16);
        try {
            node1.replaceChildAfter(node3, node6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertNull(obj8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(obj13);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertNotNull(nodeIterable17);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node[] nodeArray1 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList2 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean3 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList2, nodeArray1);
        com.google.javascript.jscomp.NodeTraversal.Callback callback4 = null;
        com.google.javascript.jscomp.NodeTraversal.traverseRoots((com.google.javascript.jscomp.AbstractCompiler) compiler0, (java.util.List<com.google.javascript.rhino.Node>) nodeList2, callback4);
        com.google.javascript.jscomp.PerformanceTracker performanceTracker6 = compiler0.tracker;
        com.google.javascript.jscomp.SourceExcerptProvider.SourceExcerpt sourceExcerpt7 = null;
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter8 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler0, sourceExcerpt7);
        com.google.javascript.jscomp.Compiler.IntermediateState intermediateState9 = compiler0.getState();
        try {
            com.google.javascript.jscomp.Result result10 = compiler0.getResult();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(nodeArray1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(performanceTracker6);
        org.junit.Assert.assertNotNull(intermediateState9);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        int int0 = com.google.javascript.rhino.Node.COLUMN_MASK;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4095 + "'", int0 == 4095);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        int int0 = com.google.javascript.rhino.Context.VERSION_1_2;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 120 + "'", int0 == 120);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        int int0 = com.google.javascript.rhino.Node.POST_FLAG;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.Node.newString("language version");
        int int3 = node2.getLineno();
        int int5 = node2.getIntProp(24);
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.Node.newString("language version");
        int int8 = node7.getLineno();
        int int10 = node7.getIntProp(24);
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString("language version");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention13 = new com.google.javascript.jscomp.ClosureCodingConvention();
        java.lang.String str14 = closureCodingConvention13.getExportPropertyFunction();
        boolean boolean16 = closureCodingConvention13.isPrivate("");
        boolean boolean18 = closureCodingConvention13.isPrivate("hi!");
        java.lang.String str19 = closureCodingConvention13.getDelegateSuperclassName();
        com.google.javascript.rhino.Node node22 = new com.google.javascript.rhino.Node((int) (short) 10);
        java.lang.Object obj24 = node22.getProp((int) (short) 1);
        boolean boolean25 = node22.hasMoreThanOneChild();
        com.google.javascript.rhino.Node node27 = new com.google.javascript.rhino.Node((int) (short) 10);
        java.lang.Object obj29 = node27.getProp((int) (short) 1);
        com.google.javascript.rhino.Node node32 = com.google.javascript.rhino.Node.newString((int) (short) 0, "");
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable33 = node32.siblings();
        com.google.javascript.rhino.Node node34 = new com.google.javascript.rhino.Node((-1), node22, node27, node32);
        boolean boolean35 = closureCodingConvention13.isVarArgsParameter(node22);
        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray37 = new com.google.javascript.jscomp.WarningsGuard[] {};
        java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard> warningsGuardList38 = new java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard>();
        boolean boolean39 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList38, warningsGuardArray37);
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard40 = new com.google.javascript.jscomp.ComposeWarningsGuard((java.util.List<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList38);
        node22.putProp(5, (java.lang.Object) composeWarningsGuard40);
        try {
            com.google.javascript.rhino.Node node42 = new com.google.javascript.rhino.Node((int) (short) -1, node2, node7, node12, node22);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "goog.exportProperty" + "'", str14.equals("goog.exportProperty"));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNull(str19);
        org.junit.Assert.assertNull(obj24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNull(obj29);
        org.junit.Assert.assertNotNull(node32);
        org.junit.Assert.assertNotNull(nodeIterable33);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(warningsGuardArray37);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        boolean boolean1 = com.google.javascript.rhino.ScriptRuntime.isJSLineTerminator(3);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

//    @Test
//    public void test145() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test145");
//        com.google.javascript.rhino.Context context0 = com.google.javascript.rhino.Context.getCurrentContext();
//        org.junit.Assert.assertNull(context0);
//    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy0 = com.google.javascript.jscomp.PropertyRenamingPolicy.UNSPECIFIED;
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy0 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.UNSPECIFIED + "'", propertyRenamingPolicy0.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.UNSPECIFIED));
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        int int0 = com.google.javascript.rhino.Node.FINALLY_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 20 + "'", int0 == 20);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newNumber((double) 1L, 0, 1);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder4 = node3.getJsDocBuilderForNode();
        fileLevelJsDocBuilder4.append("hi!");
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder4);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        int int0 = com.google.javascript.rhino.Node.INCRDECR_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 31 + "'", int0 == 31);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newString("language version");
        com.google.javascript.rhino.Node node2 = null;
        try {
            node1.addChildrenToFront(node2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node1);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        try {
            java.lang.String str2 = com.google.javascript.rhino.ScriptRuntime.escapeString("Node tree inequality:\nTree1:\nSTRING language version\n\n\nTree2:\nEOF \n\n\nSubtree1: STRING language version\n\n\nSubtree2: EOF \n", '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: FAILED ASSERTION");
        } catch (java.lang.IllegalStateException e) {
        }
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        int int0 = com.google.javascript.rhino.Context.FEATURE_STRICT_EVAL;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 9 + "'", int0 == 9);
    }

//    @Test
//    public void test153() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test153");
//        try {
//            com.google.javascript.rhino.EvaluatorException evaluatorException1 = com.google.javascript.rhino.Context.reportRuntimeError("JSC_NODE_TRAVERSAL_ERROR");
//            org.junit.Assert.fail("Expected exception of type com.google.javascript.rhino.EvaluatorException; message: JSC_NODE_TRAVERSAL_ERROR");
//        } catch (com.google.javascript.rhino.EvaluatorException e) {
//        }
//    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node[] nodeArray1 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList2 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean3 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList2, nodeArray1);
        com.google.javascript.jscomp.NodeTraversal.Callback callback4 = null;
        com.google.javascript.jscomp.NodeTraversal.traverseRoots((com.google.javascript.jscomp.AbstractCompiler) compiler0, (java.util.List<com.google.javascript.rhino.Node>) nodeList2, callback4);
        com.google.javascript.jscomp.PerformanceTracker performanceTracker6 = compiler0.tracker;
        com.google.javascript.jscomp.SourceExcerptProvider.SourceExcerpt sourceExcerpt7 = null;
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter8 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler0, sourceExcerpt7);
        com.google.javascript.jscomp.Compiler.IntermediateState intermediateState9 = compiler0.getState();
        try {
            com.google.javascript.jscomp.CompilerInput compilerInput11 = compiler0.getInput("JSC_NODE_TRAVERSAL_ERROR.  at (unknown source) line 32 : (unknown column)");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(nodeArray1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(performanceTracker6);
        org.junit.Assert.assertNotNull(intermediateState9);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.FILEOVERVIEW_JSDOC;
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup1 = com.google.javascript.jscomp.DiagnosticGroups.CHECK_VARIABLES;
        com.google.javascript.jscomp.DiagnosticGroups.CONSTANT_PROPERTY = diagnosticGroup1;
        com.google.javascript.jscomp.DiagnosticGroup[] diagnosticGroupArray3 = new com.google.javascript.jscomp.DiagnosticGroup[] { diagnosticGroup0, diagnosticGroup1 };
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup4 = new com.google.javascript.jscomp.DiagnosticGroup(diagnosticGroupArray3);
        com.google.javascript.jscomp.DiagnosticGroups.DEPRECATED = diagnosticGroup4;
        com.google.javascript.jscomp.DiagnosticGroups.VISIBILITY = diagnosticGroup4;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
        org.junit.Assert.assertNotNull(diagnosticGroup1);
        org.junit.Assert.assertNotNull(diagnosticGroupArray3);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        com.google.javascript.jscomp.AbstractCompiler abstractCompiler0 = null;
        com.google.javascript.jscomp.NodeTraversal.Callback callback1 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal2 = new com.google.javascript.jscomp.NodeTraversal(abstractCompiler0, callback1);
        com.google.javascript.rhino.Node node3 = nodeTraversal2.getCurrentNode();
        com.google.javascript.jscomp.SourceMap.DetailLevel detailLevel4 = com.google.javascript.jscomp.SourceMap.DetailLevel.SYMBOLS;
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.Node.newString((int) (short) 0, "");
        node7.setVarArgs(true);
        boolean boolean10 = detailLevel4.apply(node7);
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString("language version");
        int int13 = node12.getLineno();
        node12.setSourcePositionForTree(41);
        com.google.javascript.jscomp.SourceMap.DetailLevel detailLevel16 = com.google.javascript.jscomp.SourceMap.DetailLevel.ALL;
        com.google.javascript.rhino.Node node19 = new com.google.javascript.rhino.Node((int) (short) 10);
        java.lang.Object obj21 = node19.getProp((int) (short) 1);
        boolean boolean22 = node19.hasMoreThanOneChild();
        com.google.javascript.rhino.Node node24 = new com.google.javascript.rhino.Node((int) (short) 10);
        java.lang.Object obj26 = node24.getProp((int) (short) 1);
        com.google.javascript.rhino.Node node29 = com.google.javascript.rhino.Node.newString((int) (short) 0, "");
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable30 = node29.siblings();
        com.google.javascript.rhino.Node node31 = new com.google.javascript.rhino.Node((-1), node19, node24, node29);
        com.google.javascript.rhino.JSDocInfo jSDocInfo32 = null;
        node24.setJSDocInfo(jSDocInfo32);
        boolean boolean34 = detailLevel16.apply(node24);
        com.google.javascript.rhino.Node node36 = com.google.javascript.rhino.Node.newString("language version");
        int int37 = node36.getLineno();
        node36.removeProp(7);
        com.google.javascript.rhino.Node node41 = com.google.javascript.rhino.Node.newString("language version");
        com.google.javascript.rhino.Node node43 = com.google.javascript.rhino.Node.newString("language version");
        int int44 = node43.getLineno();
        int int46 = node43.getIntProp(24);
        com.google.javascript.rhino.Node[] nodeArray47 = new com.google.javascript.rhino.Node[] { node7, node12, node24, node36, node41, node43 };
        try {
            nodeTraversal2.traverseRoots(nodeArray47);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(node3);
        org.junit.Assert.assertNotNull(detailLevel4);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertNotNull(detailLevel16);
        org.junit.Assert.assertNull(obj21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNull(obj26);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNotNull(nodeIterable30);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertNotNull(node36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + (-1) + "'", int37 == (-1));
        org.junit.Assert.assertNotNull(node41);
        org.junit.Assert.assertNotNull(node43);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + (-1) + "'", int44 == (-1));
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 0 + "'", int46 == 0);
        org.junit.Assert.assertNotNull(nodeArray47);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        double double0 = com.google.javascript.rhino.ScriptRuntime.NaN;
        org.junit.Assert.assertEquals((double) double0, Double.NaN, 0);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        int int0 = com.google.javascript.rhino.Node.JSDOC_INFO_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 29 + "'", int0 == 29);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        java.lang.Double double0 = com.google.javascript.rhino.ScriptRuntime.NaNobj;
        org.junit.Assert.assertEquals((double) double0, Double.NaN, 0);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node[] nodeArray1 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList2 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean3 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList2, nodeArray1);
        com.google.javascript.jscomp.NodeTraversal.Callback callback4 = null;
        com.google.javascript.jscomp.NodeTraversal.traverseRoots((com.google.javascript.jscomp.AbstractCompiler) compiler0, (java.util.List<com.google.javascript.rhino.Node>) nodeList2, callback4);
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter6 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler0);
        compiler0.reportCodeChange();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile8 = null;
        try {
            com.google.javascript.rhino.Node node9 = compiler0.parse(jSSourceFile8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(nodeArray1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        java.io.InputStream inputStream1 = null;
        try {
            com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromInputStream("", inputStream1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node[] nodeArray1 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList2 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean3 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList2, nodeArray1);
        com.google.javascript.jscomp.NodeTraversal.Callback callback4 = null;
        com.google.javascript.jscomp.NodeTraversal.traverseRoots((com.google.javascript.jscomp.AbstractCompiler) compiler0, (java.util.List<com.google.javascript.rhino.Node>) nodeList2, callback4);
        com.google.javascript.jscomp.PerformanceTracker performanceTracker6 = compiler0.tracker;
        com.google.javascript.jscomp.SourceExcerptProvider.SourceExcerpt sourceExcerpt7 = null;
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter8 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler0, sourceExcerpt7);
        try {
            com.google.javascript.jscomp.CodingConvention codingConvention9 = compiler0.getCodingConvention();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(nodeArray1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(performanceTracker6);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newNumber((double) '#', 49, (int) ' ');
        org.junit.Assert.assertNotNull(node3);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile3 = com.google.javascript.jscomp.JSSourceFile.fromFile("error reporter");
        com.google.javascript.jscomp.JsAst jsAst4 = new com.google.javascript.jscomp.JsAst((com.google.javascript.jscomp.SourceFile) jSSourceFile3);
        java.lang.RuntimeException runtimeException5 = com.google.javascript.rhino.ScriptRuntime.undefCallError((java.lang.Object) 1.0d, (java.lang.Object) jSSourceFile3);
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray6 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile3 };
        java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList7 = new java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile>();
        boolean boolean8 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList7, jSSourceFileArray6);
        java.nio.charset.Charset charset10 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile11 = com.google.javascript.jscomp.JSSourceFile.fromFile("WARNING - JSC_NODE_TRAVERSAL_ERROR.  at (unknown source) line (unknown line) : (unknown column)\n", charset10);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile13 = com.google.javascript.jscomp.JSSourceFile.fromFile("error reporter");
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray14 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile11, jSSourceFile13 };
        java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList15 = new java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile>();
        boolean boolean16 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList15, jSSourceFileArray14);
        com.google.javascript.jscomp.CompilerOptions compilerOptions17 = null;
        try {
            compiler0.init((java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList7, (java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList15, compilerOptions17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile3);
        org.junit.Assert.assertNotNull(runtimeException5);
        org.junit.Assert.assertNotNull(jSSourceFileArray6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(jSSourceFile11);
        org.junit.Assert.assertNotNull(jSSourceFile13);
        org.junit.Assert.assertNotNull(jSSourceFileArray14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.Node.newString("language version");
        int int3 = node2.getLineno();
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString((int) (short) 0, "");
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable7 = node6.siblings();
        boolean boolean8 = node6.isNoSideEffectsCall();
        java.lang.String str9 = node2.checkTreeEquals(node6);
        node2.setIsSyntheticBlock(true);
        com.google.javascript.rhino.Node node12 = node2.removeFirstChild();
        com.google.javascript.jscomp.DiagnosticType diagnosticType13 = null;
        com.google.javascript.jscomp.DiagnosticType diagnosticType14 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray16 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError17 = com.google.javascript.jscomp.JSError.make(diagnosticType14, strArray16);
        com.google.javascript.jscomp.DiagnosticType diagnosticType18 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray20 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError21 = com.google.javascript.jscomp.JSError.make(diagnosticType18, strArray20);
        com.google.javascript.jscomp.JSError jSError22 = com.google.javascript.jscomp.JSError.make(diagnosticType14, strArray20);
        try {
            com.google.javascript.jscomp.JSError jSError23 = com.google.javascript.jscomp.JSError.make("JSC_NODE_TRAVERSAL_ERROR: {0}", node12, diagnosticType13, strArray20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(nodeIterable7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Node tree inequality:\nTree1:\nSTRING language version\n\n\nTree2:\nEOF \n\n\nSubtree1: STRING language version\n\n\nSubtree2: EOF \n" + "'", str9.equals("Node tree inequality:\nTree1:\nSTRING language version\n\n\nTree2:\nEOF \n\n\nSubtree1: STRING language version\n\n\nSubtree2: EOF \n"));
        org.junit.Assert.assertNull(node12);
        org.junit.Assert.assertNotNull(diagnosticType14);
        org.junit.Assert.assertNotNull(strArray16);
        org.junit.Assert.assertNotNull(jSError17);
        org.junit.Assert.assertNotNull(diagnosticType18);
        org.junit.Assert.assertNotNull(strArray20);
        org.junit.Assert.assertNotNull(jSError21);
        org.junit.Assert.assertNotNull(jSError22);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        java.lang.String str0 = com.google.javascript.rhino.jstype.JSType.EMPTY_TYPE_COMPONENT;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "Named type with empty name component" + "'", str0.equals("Named type with empty name component"));
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        java.io.InputStream inputStream1 = null;
        try {
            com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromInputStream("WARNING - JSC_NODE_TRAVERSAL_ERROR.  at (unknown source) line (unknown line) : (unknown column)\n", inputStream1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile1 = com.google.javascript.jscomp.JSSourceFile.fromFile("error reporter");
        com.google.javascript.jscomp.JsAst jsAst2 = new com.google.javascript.jscomp.JsAst((com.google.javascript.jscomp.SourceFile) jSSourceFile1);
        com.google.javascript.jscomp.CompilerInput compilerInput4 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) jsAst2, false);
        com.google.javascript.jscomp.SourceAst sourceAst5 = compilerInput4.getSourceAst();
        com.google.javascript.jscomp.SourceFile sourceFile6 = compilerInput4.getSourceFile();
        java.lang.String str7 = sourceFile6.getName();
        org.junit.Assert.assertNotNull(jSSourceFile1);
        org.junit.Assert.assertNotNull(sourceAst5);
        org.junit.Assert.assertNotNull(sourceFile6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "error reporter" + "'", str7.equals("error reporter"));
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        com.google.javascript.rhino.Node node1 = new com.google.javascript.rhino.Node((int) (short) 10);
        java.lang.Object obj3 = node1.getProp((int) (short) 1);
        com.google.javascript.rhino.JSDocInfo jSDocInfo4 = node1.getJSDocInfo();
        java.lang.String str5 = node1.toString();
        com.google.javascript.rhino.Node node6 = node1.getNext();
        org.junit.Assert.assertNull(obj3);
        org.junit.Assert.assertNull(jSDocInfo4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "BITXOR" + "'", str5.equals("BITXOR"));
        org.junit.Assert.assertNull(node6);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.Node.newString("language version");
        int int3 = node2.getLineno();
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString((int) (short) 0, "");
        com.google.javascript.rhino.Node[] nodeArray7 = new com.google.javascript.rhino.Node[] { node2, node6 };
        com.google.javascript.rhino.Node node10 = new com.google.javascript.rhino.Node((int) (short) 100, nodeArray7, 40, 0);
        try {
            node10.setString("WARNING - JSC_NODE_TRAVERSAL_ERROR.  at (unknown source) line (unknown line) : (unknown column)\n");
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: OR 40 is not a string node");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(nodeArray7);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy0 = com.google.javascript.jscomp.VariableRenamingPolicy.OFF;
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy0 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.OFF + "'", variableRenamingPolicy0.equals(com.google.javascript.jscomp.VariableRenamingPolicy.OFF));
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        java.lang.String str1 = closureCodingConvention0.getExportPropertyFunction();
        boolean boolean3 = closureCodingConvention0.isPrivate("");
        boolean boolean5 = closureCodingConvention0.isPrivate("hi!");
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString((int) (short) 0, "");
        boolean boolean9 = closureCodingConvention0.isOptionalParameter(node8);
        com.google.javascript.rhino.Node node10 = null;
        try {
            boolean boolean11 = closureCodingConvention0.isPropertyTestFunction(node10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "goog.exportProperty" + "'", str1.equals("goog.exportProperty"));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString(26, "error reporter", (int) (short) 100, 3);
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable5 = node4.children();
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(nodeIterable5);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        com.google.javascript.jscomp.SourceMap.Format format0 = com.google.javascript.jscomp.SourceMap.Format.LEGACY;
        org.junit.Assert.assertNotNull(format0);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node[] nodeArray1 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList2 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean3 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList2, nodeArray1);
        com.google.javascript.jscomp.NodeTraversal.Callback callback4 = null;
        com.google.javascript.jscomp.NodeTraversal.traverseRoots((com.google.javascript.jscomp.AbstractCompiler) compiler0, (java.util.List<com.google.javascript.rhino.Node>) nodeList2, callback4);
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter6 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler0);
        try {
            int int7 = compiler0.getWarningCount();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(nodeArray1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node[] nodeArray1 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList2 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean3 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList2, nodeArray1);
        com.google.javascript.jscomp.NodeTraversal.Callback callback4 = null;
        com.google.javascript.jscomp.NodeTraversal.traverseRoots((com.google.javascript.jscomp.AbstractCompiler) compiler0, (java.util.List<com.google.javascript.rhino.Node>) nodeList2, callback4);
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter6 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler0);
        compiler0.reportCodeChange();
        com.google.javascript.jscomp.DiagnosticType diagnosticType11 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        com.google.javascript.jscomp.CheckLevel checkLevel12 = diagnosticType11.defaultLevel;
        com.google.javascript.jscomp.DiagnosticType diagnosticType13 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        com.google.javascript.jscomp.DiagnosticType diagnosticType14 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray16 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError17 = com.google.javascript.jscomp.JSError.make(diagnosticType14, strArray16);
        com.google.javascript.jscomp.DiagnosticType diagnosticType18 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray20 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError21 = com.google.javascript.jscomp.JSError.make(diagnosticType18, strArray20);
        com.google.javascript.jscomp.JSError jSError22 = com.google.javascript.jscomp.JSError.make(diagnosticType14, strArray20);
        com.google.javascript.jscomp.JSError jSError23 = com.google.javascript.jscomp.JSError.make("", 32, (int) (short) -1, checkLevel12, diagnosticType13, strArray20);
        try {
            com.google.javascript.jscomp.CheckLevel checkLevel24 = compiler0.getErrorLevel(jSError23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(nodeArray1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(diagnosticType11);
        org.junit.Assert.assertTrue("'" + checkLevel12 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel12.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticType13);
        org.junit.Assert.assertNotNull(diagnosticType14);
        org.junit.Assert.assertNotNull(strArray16);
        org.junit.Assert.assertNotNull(jSError17);
        org.junit.Assert.assertNotNull(diagnosticType18);
        org.junit.Assert.assertNotNull(strArray20);
        org.junit.Assert.assertNotNull(jSError21);
        org.junit.Assert.assertNotNull(jSError22);
        org.junit.Assert.assertNotNull(jSError23);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node1 = null;
        boolean boolean2 = closureCodingConvention0.isVarArgsParameter(node1);
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString("language version");
        int int5 = node4.getLineno();
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString((int) (short) 0, "");
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable9 = node8.siblings();
        boolean boolean10 = node8.isNoSideEffectsCall();
        java.lang.String str11 = node4.checkTreeEquals(node8);
        try {
            com.google.javascript.jscomp.CodingConvention.SubclassRelationship subclassRelationship12 = closureCodingConvention0.getClassesDefinedByCall(node8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNotNull(nodeIterable9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Node tree inequality:\nTree1:\nSTRING language version\n\n\nTree2:\nEOF \n\n\nSubtree1: STRING language version\n\n\nSubtree2: EOF \n" + "'", str11.equals("Node tree inequality:\nTree1:\nSTRING language version\n\n\nTree2:\nEOF \n\n\nSubtree1: STRING language version\n\n\nSubtree2: EOF \n"));
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        int int0 = com.google.javascript.rhino.Node.VARS_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node[] nodeArray1 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList2 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean3 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList2, nodeArray1);
        com.google.javascript.jscomp.NodeTraversal.Callback callback4 = null;
        com.google.javascript.jscomp.NodeTraversal.traverseRoots((com.google.javascript.jscomp.AbstractCompiler) compiler0, (java.util.List<com.google.javascript.rhino.Node>) nodeList2, callback4);
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter6 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler0);
        compiler0.reportCodeChange();
        com.google.javascript.jscomp.DiagnosticType diagnosticType11 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        com.google.javascript.jscomp.CheckLevel checkLevel12 = diagnosticType11.defaultLevel;
        com.google.javascript.jscomp.DiagnosticType diagnosticType13 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        com.google.javascript.jscomp.DiagnosticType diagnosticType14 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray16 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError17 = com.google.javascript.jscomp.JSError.make(diagnosticType14, strArray16);
        com.google.javascript.jscomp.DiagnosticType diagnosticType18 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray20 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError21 = com.google.javascript.jscomp.JSError.make(diagnosticType18, strArray20);
        com.google.javascript.jscomp.JSError jSError22 = com.google.javascript.jscomp.JSError.make(diagnosticType14, strArray20);
        com.google.javascript.jscomp.JSError jSError23 = com.google.javascript.jscomp.JSError.make("", 32, (int) (short) -1, checkLevel12, diagnosticType13, strArray20);
        try {
            compiler0.report(jSError23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(nodeArray1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(diagnosticType11);
        org.junit.Assert.assertTrue("'" + checkLevel12 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel12.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticType13);
        org.junit.Assert.assertNotNull(diagnosticType14);
        org.junit.Assert.assertNotNull(strArray16);
        org.junit.Assert.assertNotNull(jSError17);
        org.junit.Assert.assertNotNull(diagnosticType18);
        org.junit.Assert.assertNotNull(strArray20);
        org.junit.Assert.assertNotNull(jSError21);
        org.junit.Assert.assertNotNull(jSError22);
        org.junit.Assert.assertNotNull(jSError23);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        int int0 = com.google.javascript.rhino.Context.VERSION_1_6;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 160 + "'", int0 == 160);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        java.util.List<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList2 = null;
        com.google.javascript.jscomp.JSModule[] jSModuleArray3 = new com.google.javascript.jscomp.JSModule[] {};
        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList4 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
        boolean boolean5 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList4, jSModuleArray3);
        com.google.javascript.jscomp.CompilerOptions compilerOptions6 = null;
        try {
            compiler1.initModules(jSSourceFileList2, (java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList4, compilerOptions6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jSModuleArray3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile1 = com.google.javascript.jscomp.JSSourceFile.fromFile("error reporter");
        com.google.javascript.jscomp.JsAst jsAst2 = new com.google.javascript.jscomp.JsAst((com.google.javascript.jscomp.SourceFile) jSSourceFile1);
        com.google.javascript.jscomp.CompilerInput compilerInput4 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) jsAst2, false);
        com.google.javascript.jscomp.SourceFile sourceFile5 = jsAst2.getSourceFile();
        jsAst2.clearAst();
        org.junit.Assert.assertNotNull(jSSourceFile1);
        org.junit.Assert.assertNotNull(sourceFile5);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        int int0 = com.google.javascript.rhino.Node.PARENTHESIZED_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 34 + "'", int0 == 34);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        int int0 = com.google.javascript.rhino.Context.FEATURE_STRICT_VARS;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 8 + "'", int0 == 8);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        int int0 = com.google.javascript.rhino.Node.NON_SPECIALCALL;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        com.google.javascript.rhino.Node node3 = new com.google.javascript.rhino.Node((int) (short) 10);
        java.lang.Object obj5 = node3.getProp((int) (short) 1);
        boolean boolean6 = node3.hasMoreThanOneChild();
        com.google.javascript.rhino.Node node7 = node3.getLastChild();
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString("language version");
        int int10 = node9.getLineno();
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString((int) (short) 0, "");
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable14 = node13.siblings();
        boolean boolean15 = node13.isNoSideEffectsCall();
        java.lang.String str16 = node9.checkTreeEquals(node13);
        com.google.javascript.rhino.Node node17 = new com.google.javascript.rhino.Node(110, node3, node9);
        try {
            com.google.javascript.rhino.Node node18 = new com.google.javascript.rhino.Node(8, node9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: new child has existing parent");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(obj5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(node7);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(nodeIterable14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Node tree inequality:\nTree1:\nSTRING language version\n\n\nTree2:\nEOF \n\n\nSubtree1: STRING language version\n\n\nSubtree2: EOF \n" + "'", str16.equals("Node tree inequality:\nTree1:\nSTRING language version\n\n\nTree2:\nEOF \n\n\nSubtree1: STRING language version\n\n\nSubtree2: EOF \n"));
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.EXTERNS_VALIDATION;
        com.google.javascript.jscomp.DiagnosticGroups.CHECK_USELESS_CODE = diagnosticGroup0;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        com.google.javascript.jscomp.CheckLevel checkLevel0 = com.google.javascript.jscomp.CheckLevel.OFF;
        org.junit.Assert.assertTrue("'" + checkLevel0 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel0.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newNumber((double) 1L, 0, 1);
        com.google.javascript.rhino.Node node5 = new com.google.javascript.rhino.Node(42, node4);
        boolean boolean6 = node5.isLocalResultCall();
        com.google.javascript.rhino.Node node7 = node5.cloneNode();
        com.google.javascript.rhino.Node node8 = null;
        try {
            com.google.javascript.rhino.Node node9 = node5.copyInformationFrom(node8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(node7);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node1 = null;
        boolean boolean2 = closureCodingConvention0.isVarArgsParameter(node1);
        boolean boolean5 = closureCodingConvention0.isExported("Not declared as a constructor", true);
        com.google.javascript.rhino.jstype.FunctionType functionType6 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType7 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType8 = null;
        try {
            closureCodingConvention0.applySingletonGetter(functionType6, functionType7, objectType8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        java.util.logging.Logger logger0 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager1 = new com.google.javascript.jscomp.LoggerErrorManager(logger0);
        loggerErrorManager1.setTypedPercent((double) (short) 1);
        com.google.javascript.jscomp.CheckLevel checkLevel4 = com.google.javascript.jscomp.CheckLevel.ERROR;
        com.google.javascript.jscomp.DiagnosticType diagnosticType5 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        com.google.javascript.jscomp.CheckLevel checkLevel6 = diagnosticType5.defaultLevel;
        java.lang.String[] strArray9 = new java.lang.String[] { "JSC_NODE_TRAVERSAL_ERROR.  at (unknown source) line (unknown line) : (unknown column)", "language version" };
        com.google.javascript.jscomp.JSError jSError10 = com.google.javascript.jscomp.JSError.make(diagnosticType5, strArray9);
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention11 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node12 = null;
        boolean boolean13 = closureCodingConvention11.isVarArgsParameter(node12);
        java.lang.RuntimeException runtimeException16 = com.google.javascript.rhino.ScriptRuntime.undefWriteError((java.lang.Object) boolean13, (java.lang.Object) (-1.0f), (java.lang.Object) 0);
        boolean boolean17 = jSError10.equals((java.lang.Object) (-1.0f));
        try {
            loggerErrorManager1.println(checkLevel4, jSError10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + checkLevel4 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel4.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticType5);
        org.junit.Assert.assertTrue("'" + checkLevel6 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel6.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertNotNull(jSError10);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(runtimeException16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        int int0 = com.google.javascript.rhino.Node.DECR_FLAG;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node[] nodeArray1 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList2 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean3 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList2, nodeArray1);
        com.google.javascript.jscomp.NodeTraversal.Callback callback4 = null;
        com.google.javascript.jscomp.NodeTraversal.traverseRoots((com.google.javascript.jscomp.AbstractCompiler) compiler0, (java.util.List<com.google.javascript.rhino.Node>) nodeList2, callback4);
        com.google.javascript.jscomp.PerformanceTracker performanceTracker6 = compiler0.tracker;
        com.google.javascript.jscomp.SourceExcerptProvider.SourceExcerpt sourceExcerpt7 = null;
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter8 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler0, sourceExcerpt7);
        com.google.javascript.jscomp.Compiler.IntermediateState intermediateState9 = compiler0.getState();
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray10 = new com.google.javascript.jscomp.JSSourceFile[] {};
        java.nio.charset.Charset charset12 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile13 = com.google.javascript.jscomp.JSSourceFile.fromFile("JSC_NODE_TRAVERSAL_ERROR", charset12);
        java.lang.String str14 = jSSourceFile13.getOriginalPath();
        java.nio.charset.Charset charset16 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile17 = com.google.javascript.jscomp.JSSourceFile.fromFile("WARNING - JSC_NODE_TRAVERSAL_ERROR.  at (unknown source) line (unknown line) : (unknown column)\n", charset16);
        java.nio.charset.Charset charset19 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile20 = com.google.javascript.jscomp.JSSourceFile.fromFile("JSC_NODE_TRAVERSAL_ERROR", charset19);
        java.nio.charset.Charset charset22 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile23 = com.google.javascript.jscomp.JSSourceFile.fromFile("WARNING - JSC_NODE_TRAVERSAL_ERROR.  at (unknown source) line (unknown line) : (unknown column)\n", charset22);
        java.nio.charset.Charset charset25 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile26 = com.google.javascript.jscomp.JSSourceFile.fromFile("WARNING - JSC_NODE_TRAVERSAL_ERROR.  at (unknown source) line (unknown line) : (unknown column)\n", charset25);
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray27 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile13, jSSourceFile17, jSSourceFile20, jSSourceFile23, jSSourceFile26 };
        com.google.javascript.jscomp.CompilerOptions compilerOptions28 = null;
        try {
            compiler0.init(jSSourceFileArray10, jSSourceFileArray27, compilerOptions28);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(nodeArray1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(performanceTracker6);
        org.junit.Assert.assertNotNull(intermediateState9);
        org.junit.Assert.assertNotNull(jSSourceFileArray10);
        org.junit.Assert.assertNotNull(jSSourceFile13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "JSC_NODE_TRAVERSAL_ERROR" + "'", str14.equals("JSC_NODE_TRAVERSAL_ERROR"));
        org.junit.Assert.assertNotNull(jSSourceFile17);
        org.junit.Assert.assertNotNull(jSSourceFile20);
        org.junit.Assert.assertNotNull(jSSourceFile23);
        org.junit.Assert.assertNotNull(jSSourceFile26);
        org.junit.Assert.assertNotNull(jSSourceFileArray27);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        com.google.javascript.rhino.Context context0 = null;
        try {
            long long1 = com.google.javascript.rhino.ScriptRuntime.lastUint32Result(context0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        int int0 = com.google.javascript.rhino.Node.SYNTHETIC_BLOCK_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 37 + "'", int0 == 37);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.INTERNET_EXPLORER_CHECKS;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        java.lang.String str1 = closureCodingConvention0.getExportPropertyFunction();
        boolean boolean3 = closureCodingConvention0.isPrivate("");
        boolean boolean5 = closureCodingConvention0.isPrivate("hi!");
        java.lang.String str6 = closureCodingConvention0.getAbstractMethodName();
        com.google.javascript.rhino.jstype.ObjectType objectType7 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType8 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType9 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType10 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType11 = null;
        closureCodingConvention0.applyDelegateRelationship(objectType7, objectType8, objectType9, functionType10, functionType11);
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.Node.newString("language version");
        int int15 = node14.getLineno();
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.Node.newString((int) (short) 0, "");
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable19 = node18.siblings();
        boolean boolean20 = node18.isNoSideEffectsCall();
        java.lang.String str21 = node14.checkTreeEquals(node18);
        try {
            java.util.List<java.lang.String> strList22 = closureCodingConvention0.identifyTypeDeclarationCall(node14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "goog.exportProperty" + "'", str1.equals("goog.exportProperty"));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "goog.abstractMethod" + "'", str6.equals("goog.abstractMethod"));
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNotNull(nodeIterable19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "Node tree inequality:\nTree1:\nSTRING language version\n\n\nTree2:\nEOF \n\n\nSubtree1: STRING language version\n\n\nSubtree2: EOF \n" + "'", str21.equals("Node tree inequality:\nTree1:\nSTRING language version\n\n\nTree2:\nEOF \n\n\nSubtree1: STRING language version\n\n\nSubtree2: EOF \n"));
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.FILEOVERVIEW_JSDOC;
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup1 = com.google.javascript.jscomp.DiagnosticGroups.CHECK_VARIABLES;
        com.google.javascript.jscomp.DiagnosticGroups.CONSTANT_PROPERTY = diagnosticGroup1;
        com.google.javascript.jscomp.DiagnosticGroup[] diagnosticGroupArray3 = new com.google.javascript.jscomp.DiagnosticGroup[] { diagnosticGroup0, diagnosticGroup1 };
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup4 = new com.google.javascript.jscomp.DiagnosticGroup(diagnosticGroupArray3);
        com.google.javascript.jscomp.DiagnosticGroups.DEPRECATED = diagnosticGroup4;
        com.google.javascript.jscomp.DiagnosticGroups.GLOBAL_THIS = diagnosticGroup4;
        com.google.javascript.jscomp.DiagnosticType diagnosticType7 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray9 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError10 = com.google.javascript.jscomp.JSError.make(diagnosticType7, strArray9);
        java.lang.String str11 = jSError10.toString();
        boolean boolean12 = diagnosticGroup4.matches(jSError10);
        com.google.javascript.jscomp.DiagnosticGroups.EXTERNS_VALIDATION = diagnosticGroup4;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
        org.junit.Assert.assertNotNull(diagnosticGroup1);
        org.junit.Assert.assertNotNull(diagnosticGroupArray3);
        org.junit.Assert.assertNotNull(diagnosticType7);
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertNotNull(jSError10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "JSC_NODE_TRAVERSAL_ERROR.  at (unknown source) line (unknown line) : (unknown column)" + "'", str11.equals("JSC_NODE_TRAVERSAL_ERROR.  at (unknown source) line (unknown line) : (unknown column)"));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node1 = null;
        boolean boolean2 = closureCodingConvention0.isVarArgsParameter(node1);
        com.google.javascript.rhino.jstype.FunctionType functionType3 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType4 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType5 = null;
        try {
            closureCodingConvention0.applySingletonGetter(functionType3, functionType4, objectType5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        java.io.File file0 = null;
        try {
            com.google.javascript.jscomp.JSSourceFile jSSourceFile1 = com.google.javascript.jscomp.JSSourceFile.fromFile(file0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString("Unknown class name", 8, 7);
        try {
            int int5 = node3.getExistingIntProp(120);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: FAILED ASSERTION");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(node3);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        int int0 = com.google.javascript.rhino.Node.ORIGINALNAME_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 39 + "'", int0 == 39);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        java.nio.charset.Charset charset1 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset1);
        try {
            java.lang.String str3 = jSSourceFile2.getCode();
            org.junit.Assert.fail("Expected exception of type java.io.FileNotFoundException; message:  (No such file or directory)");
        } catch (java.io.FileNotFoundException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile2);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        com.google.javascript.rhino.EvaluatorException evaluatorException1 = new com.google.javascript.rhino.EvaluatorException("hi!");
        int int2 = evaluatorException1.lineNumber();
        java.lang.String str3 = evaluatorException1.sourceName();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        com.google.javascript.rhino.EvaluatorException evaluatorException1 = new com.google.javascript.rhino.EvaluatorException("");
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        try {
            com.google.javascript.rhino.Context.reportWarning("", "Named type with empty name component", 21, "JSC_NODE_TRAVERSAL_ERROR: {0}", 37);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: No Context associated with current Thread");
        } catch (java.lang.RuntimeException e) {
        }
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        int int0 = com.google.javascript.rhino.Node.TYPE_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 17 + "'", int0 == 17);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        com.google.javascript.rhino.Node node1 = new com.google.javascript.rhino.Node((int) (byte) 0);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        com.google.javascript.jscomp.AbstractCompiler abstractCompiler0 = null;
        com.google.javascript.jscomp.NodeTraversal.Callback callback1 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal2 = new com.google.javascript.jscomp.NodeTraversal(abstractCompiler0, callback1);
        boolean boolean3 = nodeTraversal2.hasScope();
        try {
            com.google.javascript.jscomp.CompilerInput compilerInput4 = nodeTraversal2.getInput();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        com.google.javascript.rhino.Node.SideEffectFlags sideEffectFlags0 = new com.google.javascript.rhino.Node.SideEffectFlags();
        sideEffectFlags0.setReturnsTainted();
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        com.google.javascript.jscomp.SourceMap.DetailLevel detailLevel0 = com.google.javascript.jscomp.SourceMap.DetailLevel.SYMBOLS;
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString((int) (short) 0, "");
        node3.setVarArgs(true);
        boolean boolean6 = detailLevel0.apply(node3);
        com.google.javascript.rhino.Node node7 = null;
        try {
            node3.removeChild(node7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(detailLevel0);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        java.nio.charset.Charset charset1 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromFile("JSC_NODE_TRAVERSAL_ERROR", charset1);
        java.lang.String str3 = jSSourceFile2.getOriginalPath();
        try {
            java.lang.String str4 = jSSourceFile2.getCode();
            org.junit.Assert.fail("Expected exception of type java.io.FileNotFoundException; message: JSC_NODE_TRAVERSAL_ERROR (No such file or directory)");
        } catch (java.io.FileNotFoundException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "JSC_NODE_TRAVERSAL_ERROR" + "'", str3.equals("JSC_NODE_TRAVERSAL_ERROR"));
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        com.google.javascript.rhino.Node node2 = new com.google.javascript.rhino.Node((int) (short) 10);
        java.lang.Object obj4 = node2.getProp((int) (short) 1);
        boolean boolean5 = node2.hasMoreThanOneChild();
        com.google.javascript.rhino.Node node7 = new com.google.javascript.rhino.Node((int) (short) 10);
        java.lang.Object obj9 = node7.getProp((int) (short) 1);
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString((int) (short) 0, "");
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable13 = node12.siblings();
        com.google.javascript.rhino.Node node14 = new com.google.javascript.rhino.Node((-1), node2, node7, node12);
        try {
            node2.setString("WARNING - JSC_NODE_TRAVERSAL_ERROR.  at (unknown source) line (unknown line) : (unknown column)\n");
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: BITXOR is not a string node");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNull(obj4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(obj9);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(nodeIterable13);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        int int0 = com.google.javascript.rhino.Node.PROPERTY_FLAG;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.Node.newString((int) (short) 0, "");
        node2.setVarArgs(true);
        com.google.javascript.rhino.Node node5 = node2.getParent();
        com.google.javascript.rhino.Node node6 = node2.getNext();
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention7 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node8 = null;
        boolean boolean9 = closureCodingConvention7.isVarArgsParameter(node8);
        com.google.javascript.rhino.jstype.ObjectType objectType10 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType11 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType12 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType13 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType14 = null;
        closureCodingConvention7.applyDelegateRelationship(objectType10, objectType11, objectType12, functionType13, functionType14);
        com.google.javascript.rhino.jstype.FunctionType functionType16 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType17 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType18 = null;
        closureCodingConvention7.applySubclassRelationship(functionType16, functionType17, subclassType18);
        boolean boolean21 = closureCodingConvention7.isValidEnumKey("hi!");
        com.google.javascript.rhino.Node node23 = new com.google.javascript.rhino.Node((int) (short) 10);
        java.lang.Object obj25 = node23.getProp((int) (short) 1);
        com.google.javascript.rhino.Node node28 = new com.google.javascript.rhino.Node((int) (short) 10);
        java.lang.Object obj30 = node28.getProp((int) (short) 1);
        boolean boolean31 = node28.hasMoreThanOneChild();
        com.google.javascript.rhino.Node node33 = new com.google.javascript.rhino.Node((int) (short) 10);
        java.lang.Object obj35 = node33.getProp((int) (short) 1);
        com.google.javascript.rhino.Node node38 = com.google.javascript.rhino.Node.newString((int) (short) 0, "");
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable39 = node38.siblings();
        com.google.javascript.rhino.Node node40 = new com.google.javascript.rhino.Node((-1), node28, node33, node38);
        boolean boolean41 = node38.wasEmptyNode();
        java.lang.String str42 = closureCodingConvention7.extractClassNameIfProvide(node23, node38);
        try {
            com.google.javascript.rhino.Node node43 = node2.getChildBefore(node38);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertNull(node5);
        org.junit.Assert.assertNull(node6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNull(obj25);
        org.junit.Assert.assertNull(obj30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNull(obj35);
        org.junit.Assert.assertNotNull(node38);
        org.junit.Assert.assertNotNull(nodeIterable39);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNull(str42);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        com.google.javascript.rhino.EvaluatorException evaluatorException3 = new com.google.javascript.rhino.EvaluatorException("", "<No stack trace available>", (int) (short) 100);
        java.io.FilenameFilter filenameFilter4 = null;
        java.lang.String str5 = evaluatorException3.getScriptStackTrace(filenameFilter4);
        java.lang.String str6 = evaluatorException3.details();
        java.lang.String str7 = evaluatorException3.details();
        try {
            evaluatorException3.initSourceName("Not declared as a constructor");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "<No stack trace available>" + "'", str5.equals("<No stack trace available>"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        int int0 = com.google.javascript.rhino.Node.VAR_ARGS_NAME;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 29 + "'", int0 == 29);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        java.nio.charset.Charset charset1 = null;
        com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromFile("Node tree inequality:\nTree1:\nSTRING language version\n\n\nTree2:\nEOF \n\n\nSubtree1: STRING language version\n\n\nSubtree2: EOF \n", charset1);
        org.junit.Assert.assertNotNull(sourceFile2);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        java.lang.String str1 = closureCodingConvention0.getExportPropertyFunction();
        boolean boolean3 = closureCodingConvention0.isPrivate("");
        boolean boolean5 = closureCodingConvention0.isPrivate("hi!");
        java.lang.String str6 = closureCodingConvention0.getAbstractMethodName();
        boolean boolean8 = closureCodingConvention0.isExported("language version");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention9 = new com.google.javascript.jscomp.ClosureCodingConvention();
        java.lang.String str10 = closureCodingConvention9.getExportPropertyFunction();
        boolean boolean12 = closureCodingConvention9.isPrivate("");
        boolean boolean14 = closureCodingConvention9.isPrivate("hi!");
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newString((int) (short) 0, "");
        boolean boolean18 = closureCodingConvention9.isOptionalParameter(node17);
        java.lang.String str19 = closureCodingConvention0.identifyTypeDefAssign(node17);
        com.google.javascript.rhino.Node node24 = com.google.javascript.rhino.Node.newNumber((double) 1L, 0, 1);
        com.google.javascript.rhino.Node node25 = new com.google.javascript.rhino.Node(42, node24);
        boolean boolean26 = node25.isLocalResultCall();
        com.google.javascript.rhino.JSDocInfo jSDocInfo27 = null;
        node25.setJSDocInfo(jSDocInfo27);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder29 = node25.new FileLevelJsDocBuilder();
        java.lang.String str30 = closureCodingConvention0.getSingletonGetterClassName(node25);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "goog.exportProperty" + "'", str1.equals("goog.exportProperty"));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "goog.abstractMethod" + "'", str6.equals("goog.abstractMethod"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "goog.exportProperty" + "'", str10.equals("goog.exportProperty"));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNull(str19);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNull(str30);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile1 = com.google.javascript.jscomp.JSSourceFile.fromFile("error reporter");
        com.google.javascript.jscomp.JsAst jsAst2 = new com.google.javascript.jscomp.JsAst((com.google.javascript.jscomp.SourceFile) jSSourceFile1);
        com.google.javascript.jscomp.CompilerInput compilerInput4 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) jsAst2, false);
        com.google.javascript.jscomp.SourceAst sourceAst5 = compilerInput4.getSourceAst();
        com.google.javascript.jscomp.SourceFile sourceFile6 = compilerInput4.getSourceFile();
        java.nio.charset.Charset charset8 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile9 = com.google.javascript.jscomp.JSSourceFile.fromFile("JSC_NODE_TRAVERSAL_ERROR", charset8);
        com.google.javascript.jscomp.JsAst jsAst10 = new com.google.javascript.jscomp.JsAst((com.google.javascript.jscomp.SourceFile) jSSourceFile9);
        try {
            compilerInput4.setSourceFile((com.google.javascript.jscomp.SourceFile) jSSourceFile9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile1);
        org.junit.Assert.assertNotNull(sourceAst5);
        org.junit.Assert.assertNotNull(sourceFile6);
        org.junit.Assert.assertNotNull(jSSourceFile9);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        com.google.javascript.jscomp.parsing.Config.LanguageMode languageMode3 = com.google.javascript.jscomp.parsing.Config.LanguageMode.ECMASCRIPT5;
        com.google.javascript.jscomp.parsing.Config config5 = com.google.javascript.jscomp.parsing.ParserRunner.createConfig(true, languageMode3, false);
        com.google.javascript.jscomp.mozilla.rhino.ErrorReporter errorReporter6 = null;
        java.util.logging.Logger logger7 = null;
        try {
            com.google.javascript.rhino.Node node8 = com.google.javascript.jscomp.parsing.ParserRunner.parse("Node tree inequality:\nTree1:\nBITXOR\n\n\nTree2:\nEOF \n\n\nSubtree1: BITXOR\n\n\nSubtree2: EOF \n", "Unknown class name", config5, errorReporter6, logger7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + languageMode3 + "' != '" + com.google.javascript.jscomp.parsing.Config.LanguageMode.ECMASCRIPT5 + "'", languageMode3.equals(com.google.javascript.jscomp.parsing.Config.LanguageMode.ECMASCRIPT5));
        org.junit.Assert.assertNotNull(config5);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        try {
            java.lang.String str1 = com.google.javascript.rhino.ScriptRuntime.getMessage0("");
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property ");
        } catch (java.lang.RuntimeException e) {
        }
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        com.google.javascript.jscomp.ErrorFormat errorFormat0 = com.google.javascript.jscomp.ErrorFormat.SINGLELINE;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node[] nodeArray2 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList3 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean4 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList3, nodeArray2);
        com.google.javascript.jscomp.NodeTraversal.Callback callback5 = null;
        com.google.javascript.jscomp.NodeTraversal.traverseRoots((com.google.javascript.jscomp.AbstractCompiler) compiler1, (java.util.List<com.google.javascript.rhino.Node>) nodeList3, callback5);
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter7 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler1);
        com.google.javascript.jscomp.SourceMap sourceMap8 = compiler1.getSourceMap();
        com.google.javascript.jscomp.MessageFormatter messageFormatter10 = errorFormat0.toFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler1, false);
        try {
            compiler1.processDefines();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(errorFormat0);
        org.junit.Assert.assertNotNull(nodeArray2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(sourceMap8);
        org.junit.Assert.assertNotNull(messageFormatter10);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        com.google.javascript.rhino.Node node1 = new com.google.javascript.rhino.Node((int) (short) 10);
        java.lang.String str5 = node1.toString(true, false, true);
        boolean boolean6 = node1.isSyntheticBlock();
        try {
            java.lang.String str7 = node1.getString();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: BITXOR is not a string node");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "BITXOR" + "'", str5.equals("BITXOR"));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        int int0 = com.google.javascript.rhino.Node.IS_NAMESPACE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 45 + "'", int0 == 45);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.FILEOVERVIEW_JSDOC;
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup1 = com.google.javascript.jscomp.DiagnosticGroups.CHECK_VARIABLES;
        com.google.javascript.jscomp.DiagnosticGroups.CONSTANT_PROPERTY = diagnosticGroup1;
        com.google.javascript.jscomp.DiagnosticGroup[] diagnosticGroupArray3 = new com.google.javascript.jscomp.DiagnosticGroup[] { diagnosticGroup0, diagnosticGroup1 };
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup4 = new com.google.javascript.jscomp.DiagnosticGroup(diagnosticGroupArray3);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup5 = new com.google.javascript.jscomp.DiagnosticGroup(diagnosticGroupArray3);
        com.google.javascript.jscomp.DiagnosticGroups.AMBIGUOUS_FUNCTION_DECL = diagnosticGroup5;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
        org.junit.Assert.assertNotNull(diagnosticGroup1);
        org.junit.Assert.assertNotNull(diagnosticGroupArray3);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        java.lang.Object obj0 = null;
        java.lang.RuntimeException runtimeException2 = com.google.javascript.rhino.ScriptRuntime.undefCallError(obj0, (java.lang.Object) 10L);
        org.junit.Assert.assertNotNull(runtimeException2);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        com.google.javascript.rhino.Context context0 = new com.google.javascript.rhino.Context();
        try {
            context0.setLanguageVersion(10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Bad language version: 10");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        int int0 = com.google.javascript.rhino.Node.ISNUMBER_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 25 + "'", int0 == 25);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        com.google.javascript.jscomp.SourceExcerptProvider sourceExcerptProvider0 = null;
        try {
            com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter1 = new com.google.javascript.jscomp.LightweightMessageFormatter(sourceExcerptProvider0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node[] nodeArray1 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList2 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean3 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList2, nodeArray1);
        com.google.javascript.jscomp.NodeTraversal.Callback callback4 = null;
        com.google.javascript.jscomp.NodeTraversal.traverseRoots((com.google.javascript.jscomp.AbstractCompiler) compiler0, (java.util.List<com.google.javascript.rhino.Node>) nodeList2, callback4);
        try {
            java.lang.String str8 = compiler0.getSourceLine("Not declared as a constructor", 23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(nodeArray1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node[] nodeArray1 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList2 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean3 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList2, nodeArray1);
        com.google.javascript.jscomp.NodeTraversal.Callback callback4 = null;
        com.google.javascript.jscomp.NodeTraversal.traverseRoots((com.google.javascript.jscomp.AbstractCompiler) compiler0, (java.util.List<com.google.javascript.rhino.Node>) nodeList2, callback4);
        com.google.javascript.jscomp.PerformanceTracker performanceTracker6 = compiler0.tracker;
        com.google.javascript.jscomp.SourceExcerptProvider.SourceExcerpt sourceExcerpt7 = null;
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter8 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler0, sourceExcerpt7);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile10 = com.google.javascript.jscomp.JSSourceFile.fromFile("error reporter");
        java.nio.charset.Charset charset12 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile13 = com.google.javascript.jscomp.JSSourceFile.fromFile("Node tree inequality:\nTree1:\nSTRING language version\n\n\nTree2:\nEOF \n\n\nSubtree1: STRING language version\n\n\nSubtree2: EOF \n", charset12);
        java.nio.charset.Charset charset15 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile16 = com.google.javascript.jscomp.JSSourceFile.fromFile("Node tree inequality:\nTree1:\nSTRING language version\n\n\nTree2:\nEOF \n\n\nSubtree1: STRING language version\n\n\nSubtree2: EOF \n", charset15);
        java.nio.charset.Charset charset18 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile19 = com.google.javascript.jscomp.JSSourceFile.fromFile("WARNING - JSC_NODE_TRAVERSAL_ERROR.  at (unknown source) line (unknown line) : (unknown column)\n", charset18);
        java.nio.charset.Charset charset21 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile22 = com.google.javascript.jscomp.JSSourceFile.fromFile("JSC_NODE_TRAVERSAL_ERROR", charset21);
        java.lang.String str23 = jSSourceFile22.getOriginalPath();
        java.lang.String str24 = jSSourceFile22.toString();
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray25 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile10, jSSourceFile13, jSSourceFile16, jSSourceFile19, jSSourceFile22 };
        java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList26 = new java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile>();
        boolean boolean27 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList26, jSSourceFileArray25);
        java.nio.charset.Charset charset29 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile30 = com.google.javascript.jscomp.JSSourceFile.fromFile("JSC_NODE_TRAVERSAL_ERROR", charset29);
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray31 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile30 };
        java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList32 = new java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile>();
        boolean boolean33 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList32, jSSourceFileArray31);
        com.google.javascript.jscomp.CompilerOptions compilerOptions34 = null;
        try {
            com.google.javascript.jscomp.Result result35 = compiler0.compile((java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList26, (java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList32, compilerOptions34);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(nodeArray1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(performanceTracker6);
        org.junit.Assert.assertNotNull(jSSourceFile10);
        org.junit.Assert.assertNotNull(jSSourceFile13);
        org.junit.Assert.assertNotNull(jSSourceFile16);
        org.junit.Assert.assertNotNull(jSSourceFile19);
        org.junit.Assert.assertNotNull(jSSourceFile22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "JSC_NODE_TRAVERSAL_ERROR" + "'", str23.equals("JSC_NODE_TRAVERSAL_ERROR"));
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "JSC_NODE_TRAVERSAL_ERROR" + "'", str24.equals("JSC_NODE_TRAVERSAL_ERROR"));
        org.junit.Assert.assertNotNull(jSSourceFileArray25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertNotNull(jSSourceFile30);
        org.junit.Assert.assertNotNull(jSSourceFileArray31);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.FILEOVERVIEW_JSDOC;
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup1 = com.google.javascript.jscomp.DiagnosticGroups.CHECK_VARIABLES;
        com.google.javascript.jscomp.DiagnosticGroups.CONSTANT_PROPERTY = diagnosticGroup1;
        com.google.javascript.jscomp.DiagnosticGroup[] diagnosticGroupArray3 = new com.google.javascript.jscomp.DiagnosticGroup[] { diagnosticGroup0, diagnosticGroup1 };
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup4 = new com.google.javascript.jscomp.DiagnosticGroup(diagnosticGroupArray3);
        com.google.javascript.jscomp.DiagnosticGroups.DEPRECATED = diagnosticGroup4;
        com.google.javascript.jscomp.DiagnosticGroups.GLOBAL_THIS = diagnosticGroup4;
        com.google.javascript.jscomp.DiagnosticType diagnosticType7 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray9 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError10 = com.google.javascript.jscomp.JSError.make(diagnosticType7, strArray9);
        java.lang.String str11 = jSError10.toString();
        boolean boolean12 = diagnosticGroup4.matches(jSError10);
        int int13 = jSError10.getCharno();
        org.junit.Assert.assertNotNull(diagnosticGroup0);
        org.junit.Assert.assertNotNull(diagnosticGroup1);
        org.junit.Assert.assertNotNull(diagnosticGroupArray3);
        org.junit.Assert.assertNotNull(diagnosticType7);
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertNotNull(jSError10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "JSC_NODE_TRAVERSAL_ERROR.  at (unknown source) line (unknown line) : (unknown column)" + "'", str11.equals("JSC_NODE_TRAVERSAL_ERROR.  at (unknown source) line (unknown line) : (unknown column)"));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        com.google.javascript.rhino.EcmaError ecmaError6 = com.google.javascript.rhino.ScriptRuntime.constructError("BITXOR", "goog.exportProperty", "", 150, "", 0);
        java.lang.String str7 = ecmaError6.getLineSource();
        java.lang.String str8 = ecmaError6.sourceName();
        java.lang.String str9 = ecmaError6.getScriptStackTrace();
        java.lang.String str10 = ecmaError6.getErrorMessage();
        org.junit.Assert.assertNotNull(ecmaError6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "<No stack trace available>" + "'", str9.equals("<No stack trace available>"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "goog.exportProperty" + "'", str10.equals("goog.exportProperty"));
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        com.google.javascript.jscomp.SourceFile sourceFile3 = com.google.javascript.jscomp.SourceFile.fromCode("language version", "JSC_NODE_TRAVERSAL_ERROR: {0}", "");
        org.junit.Assert.assertNotNull(sourceFile3);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        com.google.javascript.jscomp.DiagnosticType diagnosticType3 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        com.google.javascript.jscomp.CheckLevel checkLevel4 = diagnosticType3.defaultLevel;
        com.google.javascript.jscomp.DiagnosticType diagnosticType7 = com.google.javascript.jscomp.DiagnosticType.warning("", "");
        java.lang.String[] strArray8 = null;
        com.google.javascript.jscomp.JSError jSError9 = com.google.javascript.jscomp.JSError.make("Named type with empty name component", (int) (short) 0, 20, checkLevel4, diagnosticType7, strArray8);
        java.lang.String str10 = jSError9.sourceName;
        org.junit.Assert.assertNotNull(diagnosticType3);
        org.junit.Assert.assertTrue("'" + checkLevel4 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel4.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticType7);
        org.junit.Assert.assertNotNull(jSError9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Named type with empty name component" + "'", str10.equals("Named type with empty name component"));
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node[] nodeArray1 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList2 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean3 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList2, nodeArray1);
        com.google.javascript.jscomp.NodeTraversal.Callback callback4 = null;
        com.google.javascript.jscomp.NodeTraversal.traverseRoots((com.google.javascript.jscomp.AbstractCompiler) compiler0, (java.util.List<com.google.javascript.rhino.Node>) nodeList2, callback4);
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter6 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler0);
        com.google.javascript.jscomp.SourceMap sourceMap7 = compiler0.getSourceMap();
        try {
            com.google.javascript.jscomp.Result result8 = compiler0.getResult();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(nodeArray1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(sourceMap7);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        java.io.InputStream inputStream1 = null;
        try {
            com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromInputStream("1100100", inputStream1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node[] nodeArray1 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList2 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean3 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList2, nodeArray1);
        com.google.javascript.jscomp.NodeTraversal.Callback callback4 = null;
        com.google.javascript.jscomp.NodeTraversal.traverseRoots((com.google.javascript.jscomp.AbstractCompiler) compiler0, (java.util.List<com.google.javascript.rhino.Node>) nodeList2, callback4);
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter6 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler0);
        com.google.javascript.jscomp.SourceMap sourceMap7 = compiler0.getSourceMap();
        try {
            boolean boolean8 = compiler0.acceptConstKeyword();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(nodeArray1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(sourceMap7);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        com.google.javascript.jscomp.AbstractCompiler abstractCompiler0 = null;
        com.google.javascript.jscomp.NodeTraversal.Callback callback1 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal2 = new com.google.javascript.jscomp.NodeTraversal(abstractCompiler0, callback1);
        com.google.javascript.jscomp.Compiler compiler3 = nodeTraversal2.getCompiler();
        com.google.javascript.rhino.Node node6 = new com.google.javascript.rhino.Node((int) (short) 10);
        java.lang.String str10 = node6.toString(true, false, true);
        boolean boolean11 = node6.isSyntheticBlock();
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.Node.newString((int) (short) 0, "");
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable15 = node14.siblings();
        node14.detachChildren();
        com.google.javascript.rhino.Node node19 = new com.google.javascript.rhino.Node((int) ' ', node6, node14, 0, (int) (short) 1);
        com.google.javascript.jscomp.CheckLevel checkLevel20 = null;
        com.google.javascript.jscomp.DiagnosticType diagnosticType21 = null;
        java.lang.String[] strArray27 = new java.lang.String[] { "language version", "error reporter", "WARNING - JSC_NODE_TRAVERSAL_ERROR.  at (unknown source) line (unknown line) : (unknown column)\n", "1100100", "Unknown class name" };
        try {
            com.google.javascript.jscomp.JSError jSError28 = nodeTraversal2.makeError(node14, checkLevel20, diagnosticType21, strArray27);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(compiler3);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "BITXOR" + "'", str10.equals("BITXOR"));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNotNull(nodeIterable15);
        org.junit.Assert.assertNotNull(strArray27);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        int int0 = com.google.javascript.rhino.Node.LABEL_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 19 + "'", int0 == 19);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        java.lang.String str1 = closureCodingConvention0.getExportPropertyFunction();
        boolean boolean3 = closureCodingConvention0.isPrivate("");
        boolean boolean5 = closureCodingConvention0.isPrivate("hi!");
        java.lang.String str6 = closureCodingConvention0.getDelegateSuperclassName();
        com.google.javascript.rhino.Node node9 = new com.google.javascript.rhino.Node((int) (short) 10);
        java.lang.Object obj11 = node9.getProp((int) (short) 1);
        boolean boolean12 = node9.hasMoreThanOneChild();
        com.google.javascript.rhino.Node node14 = new com.google.javascript.rhino.Node((int) (short) 10);
        java.lang.Object obj16 = node14.getProp((int) (short) 1);
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.Node.newString((int) (short) 0, "");
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable20 = node19.siblings();
        com.google.javascript.rhino.Node node21 = new com.google.javascript.rhino.Node((-1), node9, node14, node19);
        boolean boolean22 = closureCodingConvention0.isVarArgsParameter(node9);
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention23 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node24 = null;
        boolean boolean25 = closureCodingConvention23.isVarArgsParameter(node24);
        com.google.javascript.rhino.jstype.ObjectType objectType26 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType27 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType28 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType29 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType30 = null;
        closureCodingConvention23.applyDelegateRelationship(objectType26, objectType27, objectType28, functionType29, functionType30);
        com.google.javascript.rhino.jstype.FunctionType functionType32 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType33 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType34 = null;
        closureCodingConvention23.applySubclassRelationship(functionType32, functionType33, subclassType34);
        boolean boolean37 = closureCodingConvention23.isValidEnumKey("hi!");
        com.google.javascript.rhino.Node node39 = new com.google.javascript.rhino.Node((int) (short) 10);
        java.lang.Object obj41 = node39.getProp((int) (short) 1);
        com.google.javascript.rhino.Node node44 = new com.google.javascript.rhino.Node((int) (short) 10);
        java.lang.Object obj46 = node44.getProp((int) (short) 1);
        boolean boolean47 = node44.hasMoreThanOneChild();
        com.google.javascript.rhino.Node node49 = new com.google.javascript.rhino.Node((int) (short) 10);
        java.lang.Object obj51 = node49.getProp((int) (short) 1);
        com.google.javascript.rhino.Node node54 = com.google.javascript.rhino.Node.newString((int) (short) 0, "");
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable55 = node54.siblings();
        com.google.javascript.rhino.Node node56 = new com.google.javascript.rhino.Node((-1), node44, node49, node54);
        boolean boolean57 = node54.wasEmptyNode();
        java.lang.String str58 = closureCodingConvention23.extractClassNameIfProvide(node39, node54);
        java.lang.String[] strArray80 = new java.lang.String[] { "(JSC_NODE_TRAVERSAL_ERROR.  at (unknown source) line (unknown line) : (unknown column))", "JSC_NODE_TRAVERSAL_ERROR", "1100100", "Named type with empty name component", "goog.global", "error reporter", "goog.global", "hi!", "JSC_NODE_TRAVERSAL_ERROR: {0}", "Unknown class name", "language version", "goog.abstractMethod", "error reporter", "JSC_NODE_TRAVERSAL_ERROR: {0}", "WARNING - JSC_NODE_TRAVERSAL_ERROR.  at (unknown source) line (unknown line) : (unknown column)\n", "BITXOR", "Node tree inequality:\nTree1:\nSTRING language version\n\n\nTree2:\nEOF \n\n\nSubtree1: STRING language version\n\n\nSubtree2: EOF \n", "goog.global", "goog.exportProperty", "<No stack trace available>", "<No stack trace available>" };
        java.util.LinkedHashSet<java.lang.String> strSet81 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean82 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet81, strArray80);
        node54.setDirectives((java.util.Set<java.lang.String>) strSet81);
        node9.setDirectives((java.util.Set<java.lang.String>) strSet81);
        int int85 = node9.getType();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "goog.exportProperty" + "'", str1.equals("goog.exportProperty"));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNull(obj11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNull(obj16);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNotNull(nodeIterable20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertNull(obj41);
        org.junit.Assert.assertNull(obj46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNull(obj51);
        org.junit.Assert.assertNotNull(node54);
        org.junit.Assert.assertNotNull(nodeIterable55);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertNull(str58);
        org.junit.Assert.assertNotNull(strArray80);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + true + "'", boolean82 == true);
        org.junit.Assert.assertTrue("'" + int85 + "' != '" + 10 + "'", int85 == 10);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node[] nodeArray1 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList2 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean3 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList2, nodeArray1);
        com.google.javascript.jscomp.NodeTraversal.Callback callback4 = null;
        com.google.javascript.jscomp.NodeTraversal.traverseRoots((com.google.javascript.jscomp.AbstractCompiler) compiler0, (java.util.List<com.google.javascript.rhino.Node>) nodeList2, callback4);
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter6 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler0);
        compiler0.reportCodeChange();
        com.google.javascript.jscomp.Compiler compiler8 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node[] nodeArray9 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList10 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean11 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList10, nodeArray9);
        com.google.javascript.jscomp.NodeTraversal.Callback callback12 = null;
        com.google.javascript.jscomp.NodeTraversal.traverseRoots((com.google.javascript.jscomp.AbstractCompiler) compiler8, (java.util.List<com.google.javascript.rhino.Node>) nodeList10, callback12);
        com.google.javascript.jscomp.PerformanceTracker performanceTracker14 = compiler8.tracker;
        com.google.javascript.jscomp.SourceExcerptProvider.SourceExcerpt sourceExcerpt15 = null;
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter16 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler8, sourceExcerpt15);
        com.google.javascript.jscomp.Compiler.IntermediateState intermediateState17 = compiler8.getState();
        compiler0.setState(intermediateState17);
        com.google.javascript.jscomp.JSModule jSModule19 = null;
        try {
            java.lang.String[] strArray20 = compiler0.toSourceArray(jSModule19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(nodeArray1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(nodeArray9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNull(performanceTracker14);
        org.junit.Assert.assertNotNull(intermediateState17);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        com.google.javascript.jscomp.SourceMap.DetailLevel detailLevel1 = com.google.javascript.jscomp.SourceMap.DetailLevel.SYMBOLS;
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString((int) (short) 0, "");
        node4.setVarArgs(true);
        boolean boolean7 = detailLevel1.apply(node4);
        boolean boolean8 = node4.isVarArgs();
        com.google.javascript.jscomp.SourceMap.DetailLevel detailLevel9 = com.google.javascript.jscomp.SourceMap.DetailLevel.SYMBOLS;
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString((int) (short) 0, "");
        node12.setVarArgs(true);
        boolean boolean15 = detailLevel9.apply(node12);
        boolean boolean16 = node12.isVarArgs();
        com.google.javascript.rhino.Node node19 = new com.google.javascript.rhino.Node(0, node4, node12, 36, 140);
        com.google.javascript.rhino.Node node22 = new com.google.javascript.rhino.Node((int) (short) 10);
        java.lang.Object obj24 = node22.getProp((int) (short) 1);
        boolean boolean25 = node22.hasMoreThanOneChild();
        com.google.javascript.rhino.Node node26 = node22.getLastChild();
        com.google.javascript.rhino.Node node28 = com.google.javascript.rhino.Node.newString("language version");
        int int29 = node28.getLineno();
        com.google.javascript.rhino.Node node32 = com.google.javascript.rhino.Node.newString((int) (short) 0, "");
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable33 = node32.siblings();
        boolean boolean34 = node32.isNoSideEffectsCall();
        java.lang.String str35 = node28.checkTreeEquals(node32);
        com.google.javascript.rhino.Node node36 = new com.google.javascript.rhino.Node(110, node22, node28);
        com.google.javascript.rhino.Node node38 = node36.getAncestor((int) (byte) 0);
        com.google.javascript.rhino.Node node41 = com.google.javascript.rhino.Node.newString("language version");
        int int42 = node41.getLineno();
        com.google.javascript.rhino.Node node45 = com.google.javascript.rhino.Node.newString((int) (short) 0, "");
        com.google.javascript.rhino.Node[] nodeArray46 = new com.google.javascript.rhino.Node[] { node41, node45 };
        com.google.javascript.rhino.Node node49 = new com.google.javascript.rhino.Node((int) (short) 100, nodeArray46, 40, 0);
        try {
            node12.replaceChildAfter(node36, node49);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: prev is not a child of this node.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(detailLevel1);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(detailLevel9);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNull(obj24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNull(node26);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
        org.junit.Assert.assertNotNull(node32);
        org.junit.Assert.assertNotNull(nodeIterable33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "Node tree inequality:\nTree1:\nSTRING language version\n\n\nTree2:\nEOF \n\n\nSubtree1: STRING language version\n\n\nSubtree2: EOF \n" + "'", str35.equals("Node tree inequality:\nTree1:\nSTRING language version\n\n\nTree2:\nEOF \n\n\nSubtree1: STRING language version\n\n\nSubtree2: EOF \n"));
        org.junit.Assert.assertNotNull(node38);
        org.junit.Assert.assertNotNull(node41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + (-1) + "'", int42 == (-1));
        org.junit.Assert.assertNotNull(node45);
        org.junit.Assert.assertNotNull(nodeArray46);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        com.google.javascript.rhino.EvaluatorException evaluatorException3 = new com.google.javascript.rhino.EvaluatorException("", "<No stack trace available>", (int) (short) 100);
        java.io.FilenameFilter filenameFilter4 = null;
        java.lang.String str5 = evaluatorException3.getScriptStackTrace(filenameFilter4);
        try {
            evaluatorException3.initLineNumber(160);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "<No stack trace available>" + "'", str5.equals("<No stack trace available>"));
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile1 = com.google.javascript.jscomp.JSSourceFile.fromFile("error reporter");
        com.google.javascript.jscomp.JsAst jsAst2 = new com.google.javascript.jscomp.JsAst((com.google.javascript.jscomp.SourceFile) jSSourceFile1);
        com.google.javascript.jscomp.CompilerInput compilerInput4 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) jsAst2, false);
        try {
            java.lang.String str5 = compilerInput4.getCode();
            org.junit.Assert.fail("Expected exception of type java.io.FileNotFoundException; message: error reporter (No such file or directory)");
        } catch (java.io.FileNotFoundException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile1);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = null;
        com.google.javascript.jscomp.DiagnosticGroups.CHECK_TYPES = diagnosticGroup0;
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.FILEOVERVIEW_JSDOC;
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup1 = com.google.javascript.jscomp.DiagnosticGroups.CHECK_VARIABLES;
        com.google.javascript.jscomp.DiagnosticGroups.CONSTANT_PROPERTY = diagnosticGroup1;
        com.google.javascript.jscomp.DiagnosticGroup[] diagnosticGroupArray3 = new com.google.javascript.jscomp.DiagnosticGroup[] { diagnosticGroup0, diagnosticGroup1 };
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup4 = new com.google.javascript.jscomp.DiagnosticGroup(diagnosticGroupArray3);
        com.google.javascript.jscomp.DiagnosticGroups.DEPRECATED = diagnosticGroup4;
        com.google.javascript.jscomp.DiagnosticGroups.GLOBAL_THIS = diagnosticGroup4;
        com.google.javascript.jscomp.DiagnosticType diagnosticType7 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray9 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError10 = com.google.javascript.jscomp.JSError.make(diagnosticType7, strArray9);
        java.lang.String str11 = jSError10.toString();
        boolean boolean12 = diagnosticGroup4.matches(jSError10);
        com.google.javascript.jscomp.DiagnosticType diagnosticType15 = com.google.javascript.jscomp.DiagnosticType.warning("", "");
        com.google.javascript.jscomp.CheckLevel checkLevel16 = diagnosticType15.level;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile18 = com.google.javascript.jscomp.JSSourceFile.fromFile("error reporter");
        com.google.javascript.jscomp.JsAst jsAst19 = new com.google.javascript.jscomp.JsAst((com.google.javascript.jscomp.SourceFile) jSSourceFile18);
        com.google.javascript.jscomp.CompilerInput compilerInput21 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) jsAst19, false);
        com.google.javascript.jscomp.Compiler compiler22 = new com.google.javascript.jscomp.Compiler();
        compilerInput21.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler22);
        com.google.javascript.jscomp.DiagnosticType diagnosticType24 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray26 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError27 = com.google.javascript.jscomp.JSError.make(diagnosticType24, strArray26);
        com.google.javascript.jscomp.DiagnosticType diagnosticType28 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray30 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError31 = com.google.javascript.jscomp.JSError.make(diagnosticType28, strArray30);
        com.google.javascript.jscomp.JSError jSError32 = com.google.javascript.jscomp.JSError.make(diagnosticType24, strArray30);
        com.google.javascript.jscomp.CheckLevel checkLevel33 = compiler22.getErrorLevel(jSError32);
        com.google.javascript.jscomp.SourceExcerptProvider.SourceExcerpt sourceExcerpt34 = null;
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter35 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler22, sourceExcerpt34);
        try {
            java.lang.String str36 = jSError10.format(checkLevel16, (com.google.javascript.jscomp.MessageFormatter) lightweightMessageFormatter35);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(diagnosticGroup0);
        org.junit.Assert.assertNotNull(diagnosticGroup1);
        org.junit.Assert.assertNotNull(diagnosticGroupArray3);
        org.junit.Assert.assertNotNull(diagnosticType7);
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertNotNull(jSError10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "JSC_NODE_TRAVERSAL_ERROR.  at (unknown source) line (unknown line) : (unknown column)" + "'", str11.equals("JSC_NODE_TRAVERSAL_ERROR.  at (unknown source) line (unknown line) : (unknown column)"));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(diagnosticType15);
        org.junit.Assert.assertTrue("'" + checkLevel16 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel16.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
        org.junit.Assert.assertNotNull(jSSourceFile18);
        org.junit.Assert.assertNotNull(diagnosticType24);
        org.junit.Assert.assertNotNull(strArray26);
        org.junit.Assert.assertNotNull(jSError27);
        org.junit.Assert.assertNotNull(diagnosticType28);
        org.junit.Assert.assertNotNull(strArray30);
        org.junit.Assert.assertNotNull(jSError31);
        org.junit.Assert.assertNotNull(jSError32);
        org.junit.Assert.assertNull(checkLevel33);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile1 = com.google.javascript.jscomp.JSSourceFile.fromFile("error reporter");
        com.google.javascript.jscomp.JsAst jsAst2 = new com.google.javascript.jscomp.JsAst((com.google.javascript.jscomp.SourceFile) jSSourceFile1);
        com.google.javascript.jscomp.CompilerInput compilerInput4 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) jsAst2, false);
        com.google.javascript.jscomp.Compiler compiler5 = new com.google.javascript.jscomp.Compiler();
        compilerInput4.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler5);
        com.google.javascript.jscomp.DiagnosticType diagnosticType7 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray9 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError10 = com.google.javascript.jscomp.JSError.make(diagnosticType7, strArray9);
        com.google.javascript.jscomp.DiagnosticType diagnosticType11 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray13 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError14 = com.google.javascript.jscomp.JSError.make(diagnosticType11, strArray13);
        com.google.javascript.jscomp.JSError jSError15 = com.google.javascript.jscomp.JSError.make(diagnosticType7, strArray13);
        com.google.javascript.jscomp.CheckLevel checkLevel16 = compiler5.getErrorLevel(jSError15);
        com.google.javascript.jscomp.SourceExcerptProvider.SourceExcerpt sourceExcerpt17 = null;
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter18 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler5, sourceExcerpt17);
        java.util.List<com.google.javascript.rhino.Node> nodeList19 = null;
        com.google.javascript.jscomp.NodeTraversal.Callback callback20 = null;
        try {
            com.google.javascript.jscomp.NodeTraversal.traverseRoots((com.google.javascript.jscomp.AbstractCompiler) compiler5, nodeList19, callback20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile1);
        org.junit.Assert.assertNotNull(diagnosticType7);
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertNotNull(jSError10);
        org.junit.Assert.assertNotNull(diagnosticType11);
        org.junit.Assert.assertNotNull(strArray13);
        org.junit.Assert.assertNotNull(jSError14);
        org.junit.Assert.assertNotNull(jSError15);
        org.junit.Assert.assertNull(checkLevel16);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        int int0 = com.google.javascript.rhino.Node.IS_VAR_ARGS_PARAM;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 44 + "'", int0 == 44);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        java.util.logging.Logger logger0 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager1 = new com.google.javascript.jscomp.LoggerErrorManager(logger0);
        com.google.javascript.jscomp.DiagnosticType diagnosticType2 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray4 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError5 = com.google.javascript.jscomp.JSError.make(diagnosticType2, strArray4);
        com.google.javascript.jscomp.CheckLevel checkLevel6 = diagnosticType2.level;
        com.google.javascript.jscomp.AbstractCompiler abstractCompiler7 = null;
        com.google.javascript.jscomp.NodeTraversal.Callback callback8 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal9 = new com.google.javascript.jscomp.NodeTraversal(abstractCompiler7, callback8);
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.Node.newString("language version");
        com.google.javascript.jscomp.DiagnosticType diagnosticType12 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        com.google.javascript.jscomp.CheckLevel checkLevel13 = diagnosticType12.defaultLevel;
        com.google.javascript.jscomp.DiagnosticType diagnosticType14 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray16 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError17 = com.google.javascript.jscomp.JSError.make(diagnosticType14, strArray16);
        com.google.javascript.jscomp.JSError jSError18 = nodeTraversal9.makeError(node11, diagnosticType12, strArray16);
        try {
            loggerErrorManager1.println(checkLevel6, jSError18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(diagnosticType2);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(jSError5);
        org.junit.Assert.assertTrue("'" + checkLevel6 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel6.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertNotNull(diagnosticType12);
        org.junit.Assert.assertTrue("'" + checkLevel13 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel13.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticType14);
        org.junit.Assert.assertNotNull(strArray16);
        org.junit.Assert.assertNotNull(jSError17);
        org.junit.Assert.assertNotNull(jSError18);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        java.lang.String str1 = closureCodingConvention0.getExportPropertyFunction();
        boolean boolean3 = closureCodingConvention0.isPrivate("");
        boolean boolean5 = closureCodingConvention0.isPrivate("hi!");
        java.lang.String str6 = closureCodingConvention0.getDelegateSuperclassName();
        com.google.javascript.rhino.Node node9 = new com.google.javascript.rhino.Node((int) (short) 10);
        java.lang.Object obj11 = node9.getProp((int) (short) 1);
        boolean boolean12 = node9.hasMoreThanOneChild();
        com.google.javascript.rhino.Node node14 = new com.google.javascript.rhino.Node((int) (short) 10);
        java.lang.Object obj16 = node14.getProp((int) (short) 1);
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.Node.newString((int) (short) 0, "");
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable20 = node19.siblings();
        com.google.javascript.rhino.Node node21 = new com.google.javascript.rhino.Node((-1), node9, node14, node19);
        boolean boolean22 = closureCodingConvention0.isVarArgsParameter(node9);
        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray24 = new com.google.javascript.jscomp.WarningsGuard[] {};
        java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard> warningsGuardList25 = new java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard>();
        boolean boolean26 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList25, warningsGuardArray24);
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard27 = new com.google.javascript.jscomp.ComposeWarningsGuard((java.util.List<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList25);
        node9.putProp(5, (java.lang.Object) composeWarningsGuard27);
        com.google.javascript.jscomp.DiagnosticType diagnosticType29 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray31 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError32 = com.google.javascript.jscomp.JSError.make(diagnosticType29, strArray31);
        com.google.javascript.jscomp.DiagnosticType diagnosticType33 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        com.google.javascript.jscomp.DiagnosticType diagnosticType34 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray36 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError37 = com.google.javascript.jscomp.JSError.make(diagnosticType34, strArray36);
        com.google.javascript.jscomp.DiagnosticType[] diagnosticTypeArray38 = new com.google.javascript.jscomp.DiagnosticType[] { diagnosticType29, diagnosticType33, diagnosticType34 };
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup39 = new com.google.javascript.jscomp.DiagnosticGroup(diagnosticTypeArray38);
        com.google.javascript.jscomp.DiagnosticType diagnosticType40 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray42 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError43 = com.google.javascript.jscomp.JSError.make(diagnosticType40, strArray42);
        java.lang.Class<?> wildcardClass44 = diagnosticType40.getClass();
        com.google.javascript.jscomp.DiagnosticType diagnosticType47 = com.google.javascript.jscomp.DiagnosticType.warning("", "");
        com.google.javascript.jscomp.CheckLevel checkLevel48 = diagnosticType47.level;
        diagnosticType40.level = checkLevel48;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard50 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup39, checkLevel48);
        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray51 = new com.google.javascript.jscomp.WarningsGuard[] { composeWarningsGuard27, diagnosticGroupWarningsGuard50 };
        java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard> warningsGuardList52 = new java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard>();
        boolean boolean53 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList52, warningsGuardArray51);
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard54 = new com.google.javascript.jscomp.ComposeWarningsGuard((java.util.List<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList52);
        java.lang.String str55 = composeWarningsGuard54.toString();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "goog.exportProperty" + "'", str1.equals("goog.exportProperty"));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNull(obj11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNull(obj16);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNotNull(nodeIterable20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(warningsGuardArray24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(diagnosticType29);
        org.junit.Assert.assertNotNull(strArray31);
        org.junit.Assert.assertNotNull(jSError32);
        org.junit.Assert.assertNotNull(diagnosticType33);
        org.junit.Assert.assertNotNull(diagnosticType34);
        org.junit.Assert.assertNotNull(strArray36);
        org.junit.Assert.assertNotNull(jSError37);
        org.junit.Assert.assertNotNull(diagnosticTypeArray38);
        org.junit.Assert.assertNotNull(diagnosticType40);
        org.junit.Assert.assertNotNull(strArray42);
        org.junit.Assert.assertNotNull(jSError43);
        org.junit.Assert.assertNotNull(wildcardClass44);
        org.junit.Assert.assertNotNull(diagnosticType47);
        org.junit.Assert.assertTrue("'" + checkLevel48 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel48.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
        org.junit.Assert.assertNotNull(warningsGuardArray51);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + true + "'", boolean53 == true);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromFile("error reporter");
        com.google.javascript.jscomp.JsAst jsAst3 = new com.google.javascript.jscomp.JsAst((com.google.javascript.jscomp.SourceFile) jSSourceFile2);
        java.lang.RuntimeException runtimeException4 = com.google.javascript.rhino.ScriptRuntime.undefCallError((java.lang.Object) 1.0d, (java.lang.Object) jSSourceFile2);
        try {
            java.io.Reader reader5 = jSSourceFile2.getCodeReader();
            org.junit.Assert.fail("Expected exception of type java.io.FileNotFoundException; message: error reporter (No such file or directory)");
        } catch (java.io.FileNotFoundException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile2);
        org.junit.Assert.assertNotNull(runtimeException4);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node[] nodeArray1 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList2 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean3 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList2, nodeArray1);
        com.google.javascript.jscomp.NodeTraversal.Callback callback4 = null;
        com.google.javascript.jscomp.NodeTraversal.traverseRoots((com.google.javascript.jscomp.AbstractCompiler) compiler0, (java.util.List<com.google.javascript.rhino.Node>) nodeList2, callback4);
        com.google.javascript.jscomp.PerformanceTracker performanceTracker6 = compiler0.tracker;
        com.google.javascript.jscomp.SourceExcerptProvider.SourceExcerpt sourceExcerpt7 = null;
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter8 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler0, sourceExcerpt7);
        java.util.logging.Logger logger9 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager10 = new com.google.javascript.jscomp.LoggerErrorManager((com.google.javascript.jscomp.MessageFormatter) lightweightMessageFormatter8, logger9);
        com.google.javascript.jscomp.DiagnosticType diagnosticType14 = com.google.javascript.jscomp.DiagnosticType.warning("", "");
        com.google.javascript.jscomp.CheckLevel checkLevel15 = diagnosticType14.level;
        com.google.javascript.jscomp.DiagnosticType diagnosticType17 = com.google.javascript.jscomp.DiagnosticType.make("", checkLevel15, "");
        com.google.javascript.jscomp.JSError jSError18 = null;
        try {
            loggerErrorManager10.report(checkLevel15, jSError18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(nodeArray1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(performanceTracker6);
        org.junit.Assert.assertNotNull(diagnosticType14);
        org.junit.Assert.assertTrue("'" + checkLevel15 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel15.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
        org.junit.Assert.assertNotNull(diagnosticType17);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = null;
        com.google.javascript.jscomp.DiagnosticGroups.VISIBILITY = diagnosticGroup0;
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        int int0 = com.google.javascript.rhino.Node.FLAG_GLOBAL_STATE_UNMODIFIED;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        com.google.javascript.jscomp.SourceFile.Generator generator1 = null;
        com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromGenerator("1100100", generator1);
        try {
            java.io.Reader reader3 = sourceFile2.getCodeReader();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(sourceFile2);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node[] nodeArray1 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList2 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean3 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList2, nodeArray1);
        com.google.javascript.jscomp.NodeTraversal.Callback callback4 = null;
        com.google.javascript.jscomp.NodeTraversal.traverseRoots((com.google.javascript.jscomp.AbstractCompiler) compiler0, (java.util.List<com.google.javascript.rhino.Node>) nodeList2, callback4);
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter6 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler0);
        com.google.javascript.jscomp.JSModule jSModule7 = null;
        try {
            java.lang.String str8 = compiler0.toSource(jSModule7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(nodeArray1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.EXTERNS_VALIDATION;
        com.google.javascript.jscomp.DiagnosticGroups.INTERNET_EXPLORER_CHECKS = diagnosticGroup0;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        int int0 = com.google.javascript.rhino.Node.FLAG_NO_THROWS;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 8 + "'", int0 == 8);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.FILEOVERVIEW_JSDOC;
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup1 = com.google.javascript.jscomp.DiagnosticGroups.CHECK_VARIABLES;
        com.google.javascript.jscomp.DiagnosticGroups.CONSTANT_PROPERTY = diagnosticGroup1;
        com.google.javascript.jscomp.DiagnosticGroup[] diagnosticGroupArray3 = new com.google.javascript.jscomp.DiagnosticGroup[] { diagnosticGroup0, diagnosticGroup1 };
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup4 = new com.google.javascript.jscomp.DiagnosticGroup(diagnosticGroupArray3);
        com.google.javascript.jscomp.DiagnosticGroups.DEPRECATED = diagnosticGroup4;
        com.google.javascript.jscomp.DiagnosticGroups.GLOBAL_THIS = diagnosticGroup4;
        com.google.javascript.jscomp.DiagnosticType diagnosticType7 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray9 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError10 = com.google.javascript.jscomp.JSError.make(diagnosticType7, strArray9);
        java.lang.String str11 = jSError10.toString();
        boolean boolean12 = diagnosticGroup4.matches(jSError10);
        int int13 = jSError10.lineNumber;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
        org.junit.Assert.assertNotNull(diagnosticGroup1);
        org.junit.Assert.assertNotNull(diagnosticGroupArray3);
        org.junit.Assert.assertNotNull(diagnosticType7);
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertNotNull(jSError10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "JSC_NODE_TRAVERSAL_ERROR.  at (unknown source) line (unknown line) : (unknown column)" + "'", str11.equals("JSC_NODE_TRAVERSAL_ERROR.  at (unknown source) line (unknown line) : (unknown column)"));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        com.google.javascript.jscomp.ErrorFormat errorFormat0 = com.google.javascript.jscomp.ErrorFormat.MULTILINE;
        org.junit.Assert.assertNotNull(errorFormat0);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.Scope scope1 = compiler0.getTopScope();
        com.google.javascript.jscomp.CompilerOptions compilerOptions2 = null;
        try {
            compiler0.initOptions(compilerOptions2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(scope1);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        java.nio.charset.Charset charset3 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile4 = com.google.javascript.jscomp.JSSourceFile.fromFile("WARNING - JSC_NODE_TRAVERSAL_ERROR.  at (unknown source) line (unknown line) : (unknown column)\n", charset3);
        com.google.javascript.jscomp.JSModule jSModule5 = null;
        com.google.javascript.jscomp.JSModule[] jSModuleArray6 = new com.google.javascript.jscomp.JSModule[] { jSModule5 };
        com.google.javascript.jscomp.CompilerOptions compilerOptions7 = null;
        try {
            com.google.javascript.jscomp.Result result8 = compiler1.compile(jSSourceFile4, jSModuleArray6, compilerOptions7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile4);
        org.junit.Assert.assertNotNull(jSModuleArray6);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        java.lang.String str1 = com.google.javascript.rhino.ScriptRuntime.escapeString("JSC_NODE_TRAVERSAL_ERROR");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "JSC_NODE_TRAVERSAL_ERROR" + "'", str1.equals("JSC_NODE_TRAVERSAL_ERROR"));
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        try {
            java.lang.String str2 = com.google.javascript.rhino.ScriptRuntime.escapeString("<No stack trace available>", 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: FAILED ASSERTION");
        } catch (java.lang.IllegalStateException e) {
        }
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node[] nodeArray1 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList2 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean3 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList2, nodeArray1);
        com.google.javascript.jscomp.NodeTraversal.Callback callback4 = null;
        com.google.javascript.jscomp.NodeTraversal.traverseRoots((com.google.javascript.jscomp.AbstractCompiler) compiler0, (java.util.List<com.google.javascript.rhino.Node>) nodeList2, callback4);
        com.google.javascript.jscomp.PerformanceTracker performanceTracker6 = compiler0.tracker;
        com.google.javascript.jscomp.SourceExcerptProvider.SourceExcerpt sourceExcerpt7 = null;
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter8 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler0, sourceExcerpt7);
        com.google.javascript.jscomp.Compiler.IntermediateState intermediateState9 = compiler0.getState();
        try {
            int int10 = compiler0.getErrorCount();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(nodeArray1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(performanceTracker6);
        org.junit.Assert.assertNotNull(intermediateState9);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        com.google.javascript.rhino.Context context0 = new com.google.javascript.rhino.Context();
        context0.setGeneratingSource(true);
        int int3 = context0.getInstructionObserverThreshold();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        com.google.javascript.jscomp.DiagnosticType diagnosticType2 = com.google.javascript.jscomp.DiagnosticType.error("BITXOR", "(JSC_NODE_TRAVERSAL_ERROR.  at (unknown source) line (unknown line) : (unknown column))");
        java.lang.String str3 = diagnosticType2.key;
        org.junit.Assert.assertNotNull(diagnosticType2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "BITXOR" + "'", str3.equals("BITXOR"));
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        java.lang.String str1 = closureCodingConvention0.getExportPropertyFunction();
        boolean boolean3 = closureCodingConvention0.isPrivate("");
        boolean boolean5 = closureCodingConvention0.isPrivate("hi!");
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString((int) (short) 0, "");
        boolean boolean9 = closureCodingConvention0.isOptionalParameter(node8);
        java.util.Collection<com.google.javascript.jscomp.CodingConvention.AssertionFunctionSpec> assertionFunctionSpecCollection10 = closureCodingConvention0.getAssertionFunctions();
        com.google.javascript.rhino.Node node12 = new com.google.javascript.rhino.Node((int) (byte) 100);
        boolean boolean13 = closureCodingConvention0.isOptionalParameter(node12);
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newNumber(0.0d, 35, 40);
        try {
            boolean boolean18 = closureCodingConvention0.isPropertyTestFunction(node17);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "goog.exportProperty" + "'", str1.equals("goog.exportProperty"));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(assertionFunctionSpecCollection10);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(node17);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        com.google.javascript.rhino.EcmaError ecmaError6 = com.google.javascript.rhino.ScriptRuntime.constructError("BITXOR", "goog.exportProperty", "", 150, "", 0);
        java.lang.String str7 = ecmaError6.getLineSource();
        java.lang.String str8 = ecmaError6.sourceName();
        java.lang.String str9 = ecmaError6.getScriptStackTrace();
        try {
            ecmaError6.initLineSource("Not declared as a constructor");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(ecmaError6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "<No stack trace available>" + "'", str9.equals("<No stack trace available>"));
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.CHECK_VARIABLES;
        com.google.javascript.jscomp.DiagnosticGroups.ACCESS_CONTROLS = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticGroups.CHECK_USELESS_CODE = diagnosticGroup0;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        com.google.javascript.rhino.Node node3 = new com.google.javascript.rhino.Node((int) (short) 10);
        java.lang.Object obj5 = node3.getProp((int) (short) 1);
        boolean boolean6 = node3.hasMoreThanOneChild();
        com.google.javascript.rhino.Node node8 = new com.google.javascript.rhino.Node((int) (short) 10);
        java.lang.Object obj10 = node8.getProp((int) (short) 1);
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString((int) (short) 0, "");
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable14 = node13.siblings();
        com.google.javascript.rhino.Node node15 = new com.google.javascript.rhino.Node((-1), node3, node8, node13);
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.Node.newString((int) (short) 0, "");
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable19 = node18.siblings();
        boolean boolean20 = node18.isNoSideEffectsCall();
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newString((int) (short) 0, "");
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable24 = node23.siblings();
        boolean boolean25 = node23.isNoSideEffectsCall();
        java.lang.String str26 = node23.getString();
        java.util.Collection<com.google.javascript.rhino.Node> nodeCollection27 = com.google.javascript.jscomp.NodeUtil.getVarsDeclaredInBranch(node23);
        com.google.javascript.rhino.Node node32 = com.google.javascript.rhino.Node.newNumber((double) 1L, 0, 1);
        com.google.javascript.rhino.Node node33 = new com.google.javascript.rhino.Node(42, node32);
        boolean boolean34 = node33.isLocalResultCall();
        try {
            com.google.javascript.rhino.Node node35 = new com.google.javascript.rhino.Node(31, node13, node18, node23, node33);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(obj5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(obj10);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(nodeIterable14);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNotNull(nodeIterable19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(nodeIterable24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "" + "'", str26.equals(""));
        org.junit.Assert.assertNotNull(nodeCollection27);
        org.junit.Assert.assertNotNull(node32);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        com.google.javascript.jscomp.AbstractCompiler abstractCompiler0 = null;
        com.google.javascript.jscomp.NodeTraversal.Callback callback1 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal2 = new com.google.javascript.jscomp.NodeTraversal(abstractCompiler0, callback1);
        com.google.javascript.rhino.Node node3 = nodeTraversal2.getCurrentNode();
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString("language version");
        int int7 = node6.getLineno();
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString((int) (short) 0, "");
        com.google.javascript.rhino.Node[] nodeArray11 = new com.google.javascript.rhino.Node[] { node6, node10 };
        com.google.javascript.rhino.Node node14 = new com.google.javascript.rhino.Node((int) (short) 100, nodeArray11, 40, 0);
        try {
            nodeTraversal2.traverseRoots(nodeArray11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(node3);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(nodeArray11);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        int int0 = com.google.javascript.rhino.Node.SIDE_EFFECTS_ALL;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        com.google.javascript.jscomp.DiagnosticType diagnosticType0 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        com.google.javascript.jscomp.CheckLevel checkLevel1 = diagnosticType0.defaultLevel;
        java.lang.String[] strArray4 = new java.lang.String[] { "JSC_NODE_TRAVERSAL_ERROR.  at (unknown source) line (unknown line) : (unknown column)", "language version" };
        com.google.javascript.jscomp.JSError jSError5 = com.google.javascript.jscomp.JSError.make(diagnosticType0, strArray4);
        com.google.javascript.jscomp.DiagnosticType diagnosticType6 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        int int7 = diagnosticType0.compareTo(diagnosticType6);
        org.junit.Assert.assertNotNull(diagnosticType0);
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(jSError5);
        org.junit.Assert.assertNotNull(diagnosticType6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node[] nodeArray1 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList2 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean3 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList2, nodeArray1);
        com.google.javascript.jscomp.NodeTraversal.Callback callback4 = null;
        com.google.javascript.jscomp.NodeTraversal.traverseRoots((com.google.javascript.jscomp.AbstractCompiler) compiler0, (java.util.List<com.google.javascript.rhino.Node>) nodeList2, callback4);
        com.google.javascript.jscomp.PerformanceTracker performanceTracker6 = compiler0.tracker;
        com.google.javascript.jscomp.SourceExcerptProvider.SourceExcerpt sourceExcerpt7 = null;
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter8 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler0, sourceExcerpt7);
        java.util.logging.Logger logger9 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager10 = new com.google.javascript.jscomp.LoggerErrorManager((com.google.javascript.jscomp.MessageFormatter) lightweightMessageFormatter8, logger9);
        java.util.logging.Logger logger11 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager12 = new com.google.javascript.jscomp.LoggerErrorManager((com.google.javascript.jscomp.MessageFormatter) lightweightMessageFormatter8, logger11);
        org.junit.Assert.assertNotNull(nodeArray1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(performanceTracker6);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        java.lang.String str1 = closureCodingConvention0.getExportPropertyFunction();
        boolean boolean3 = closureCodingConvention0.isPrivate("");
        boolean boolean5 = closureCodingConvention0.isPrivate("hi!");
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString((int) (short) 0, "");
        boolean boolean9 = closureCodingConvention0.isOptionalParameter(node8);
        try {
            double double10 = node8.getDouble();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: EOF  is not a number node");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "goog.exportProperty" + "'", str1.equals("goog.exportProperty"));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        try {
            com.google.javascript.rhino.EcmaError ecmaError1 = com.google.javascript.rhino.ScriptRuntime.typeError0("JSC_NODE_TRAVERSAL_ERROR.  at (unknown source) line (unknown line) : (unknown column)");
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property JSC_NODE_TRAVERSAL_ERROR.  at (unknown source) line (unknown line) : (unknown column)");
        } catch (java.lang.RuntimeException e) {
        }
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.Compiler.IntermediateState intermediateState2 = compiler1.getState();
        com.google.javascript.jscomp.Compiler compiler3 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node[] nodeArray4 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList5 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean6 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList5, nodeArray4);
        com.google.javascript.jscomp.NodeTraversal.Callback callback7 = null;
        com.google.javascript.jscomp.NodeTraversal.traverseRoots((com.google.javascript.jscomp.AbstractCompiler) compiler3, (java.util.List<com.google.javascript.rhino.Node>) nodeList5, callback7);
        com.google.javascript.jscomp.PerformanceTracker performanceTracker9 = compiler3.tracker;
        com.google.javascript.jscomp.SourceExcerptProvider.SourceExcerpt sourceExcerpt10 = null;
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter11 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler3, sourceExcerpt10);
        java.util.logging.Logger logger12 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager13 = new com.google.javascript.jscomp.LoggerErrorManager((com.google.javascript.jscomp.MessageFormatter) lightweightMessageFormatter11, logger12);
        compiler1.setErrorManager((com.google.javascript.jscomp.ErrorManager) loggerErrorManager13);
        int int15 = loggerErrorManager13.getWarningCount();
        org.junit.Assert.assertNotNull(intermediateState2);
        org.junit.Assert.assertNotNull(nodeArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(performanceTracker9);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        try {
            com.google.javascript.rhino.EcmaError ecmaError3 = com.google.javascript.rhino.ScriptRuntime.typeError2("JSC_NODE_TRAVERSAL_ERROR", "language version", "Node tree inequality:\nTree1:\nSTRING language version\n\n\nTree2:\nEOF \n\n\nSubtree1: STRING language version\n\n\nSubtree2: EOF \n");
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property JSC_NODE_TRAVERSAL_ERROR");
        } catch (java.lang.RuntimeException e) {
        }
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        com.google.javascript.jscomp.parsing.Config.LanguageMode languageMode1 = com.google.javascript.jscomp.parsing.Config.LanguageMode.ECMASCRIPT5;
        java.lang.RuntimeException runtimeException2 = com.google.javascript.rhino.ScriptRuntime.undefCallError((java.lang.Object) "goog.abstractMethod", (java.lang.Object) languageMode1);
        org.junit.Assert.assertTrue("'" + languageMode1 + "' != '" + com.google.javascript.jscomp.parsing.Config.LanguageMode.ECMASCRIPT5 + "'", languageMode1.equals(com.google.javascript.jscomp.parsing.Config.LanguageMode.ECMASCRIPT5));
        org.junit.Assert.assertNotNull(runtimeException2);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node[] nodeArray1 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList2 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean3 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList2, nodeArray1);
        com.google.javascript.jscomp.NodeTraversal.Callback callback4 = null;
        com.google.javascript.jscomp.NodeTraversal.traverseRoots((com.google.javascript.jscomp.AbstractCompiler) compiler0, (java.util.List<com.google.javascript.rhino.Node>) nodeList2, callback4);
        com.google.javascript.jscomp.PerformanceTracker performanceTracker6 = compiler0.tracker;
        com.google.javascript.jscomp.SourceExcerptProvider.SourceExcerpt sourceExcerpt7 = null;
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter8 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler0, sourceExcerpt7);
        try {
            com.google.javascript.jscomp.CompilerInput compilerInput10 = compiler0.newExternInput("TypeError: <No stack trace available>");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(nodeArray1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(performanceTracker6);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.INVALID_CASTS;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        java.lang.String str2 = com.google.javascript.rhino.ScriptRuntime.numberToString((double) 8, (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "8" + "'", str2.equals("8"));
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        com.google.javascript.rhino.EvaluatorException evaluatorException1 = new com.google.javascript.rhino.EvaluatorException("hi!");
        int int2 = evaluatorException1.columnNumber();
        int int3 = evaluatorException1.lineNumber();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = null;
        com.google.javascript.jscomp.DiagnosticGroups.TYPE_INVALIDATION = diagnosticGroup0;
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.FILEOVERVIEW_JSDOC;
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup1 = com.google.javascript.jscomp.DiagnosticGroups.CHECK_VARIABLES;
        com.google.javascript.jscomp.DiagnosticGroups.CONSTANT_PROPERTY = diagnosticGroup1;
        com.google.javascript.jscomp.DiagnosticGroup[] diagnosticGroupArray3 = new com.google.javascript.jscomp.DiagnosticGroup[] { diagnosticGroup0, diagnosticGroup1 };
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup4 = new com.google.javascript.jscomp.DiagnosticGroup(diagnosticGroupArray3);
        com.google.javascript.jscomp.DiagnosticGroups.DEPRECATED = diagnosticGroup4;
        com.google.javascript.jscomp.DiagnosticType diagnosticType6 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray8 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError9 = com.google.javascript.jscomp.JSError.make(diagnosticType6, strArray8);
        boolean boolean10 = diagnosticGroup4.matches(diagnosticType6);
        java.text.MessageFormat messageFormat11 = diagnosticType6.format;
        com.google.javascript.jscomp.DiagnosticType diagnosticType15 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        com.google.javascript.jscomp.CheckLevel checkLevel16 = diagnosticType15.defaultLevel;
        com.google.javascript.jscomp.DiagnosticType diagnosticType17 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray19 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError20 = com.google.javascript.jscomp.JSError.make(diagnosticType17, strArray19);
        com.google.javascript.jscomp.DiagnosticType diagnosticType21 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray23 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError24 = com.google.javascript.jscomp.JSError.make(diagnosticType21, strArray23);
        com.google.javascript.jscomp.JSError jSError25 = com.google.javascript.jscomp.JSError.make(diagnosticType17, strArray23);
        com.google.javascript.jscomp.JSError jSError26 = com.google.javascript.jscomp.JSError.make("JSC_NODE_TRAVERSAL_ERROR.  at (unknown source) line 32 : (unknown column)", 0, 32, diagnosticType15, strArray23);
        java.lang.RuntimeException runtimeException27 = com.google.javascript.rhino.ScriptRuntime.notFunctionError((java.lang.Object) messageFormat11, (java.lang.Object) 0);
        org.junit.Assert.assertNotNull(diagnosticGroup0);
        org.junit.Assert.assertNotNull(diagnosticGroup1);
        org.junit.Assert.assertNotNull(diagnosticGroupArray3);
        org.junit.Assert.assertNotNull(diagnosticType6);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertNotNull(jSError9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(messageFormat11);
        org.junit.Assert.assertNotNull(diagnosticType15);
        org.junit.Assert.assertTrue("'" + checkLevel16 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel16.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticType17);
        org.junit.Assert.assertNotNull(strArray19);
        org.junit.Assert.assertNotNull(jSError20);
        org.junit.Assert.assertNotNull(diagnosticType21);
        org.junit.Assert.assertNotNull(strArray23);
        org.junit.Assert.assertNotNull(jSError24);
        org.junit.Assert.assertNotNull(jSError25);
        org.junit.Assert.assertNotNull(jSError26);
        org.junit.Assert.assertNotNull(runtimeException27);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        com.google.javascript.jscomp.AbstractCompiler abstractCompiler0 = null;
        com.google.javascript.jscomp.NodeTraversal.Callback callback1 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal2 = new com.google.javascript.jscomp.NodeTraversal(abstractCompiler0, callback1);
        com.google.javascript.jscomp.Compiler compiler3 = nodeTraversal2.getCompiler();
        com.google.javascript.rhino.Node node5 = new com.google.javascript.rhino.Node((int) (short) 10);
        java.lang.Object obj7 = node5.getProp((int) (short) 1);
        com.google.javascript.rhino.JSDocInfo jSDocInfo8 = node5.getJSDocInfo();
        com.google.javascript.jscomp.DiagnosticType diagnosticType9 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray11 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError12 = com.google.javascript.jscomp.JSError.make(diagnosticType9, strArray11);
        com.google.javascript.jscomp.DiagnosticType diagnosticType13 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray15 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError16 = com.google.javascript.jscomp.JSError.make(diagnosticType13, strArray15);
        com.google.javascript.jscomp.JSError jSError17 = com.google.javascript.jscomp.JSError.make(diagnosticType9, strArray15);
        java.lang.String[] strArray18 = null;
        try {
            nodeTraversal2.report(node5, diagnosticType9, strArray18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(compiler3);
        org.junit.Assert.assertNull(obj7);
        org.junit.Assert.assertNull(jSDocInfo8);
        org.junit.Assert.assertNotNull(diagnosticType9);
        org.junit.Assert.assertNotNull(strArray11);
        org.junit.Assert.assertNotNull(jSError12);
        org.junit.Assert.assertNotNull(diagnosticType13);
        org.junit.Assert.assertNotNull(strArray15);
        org.junit.Assert.assertNotNull(jSError16);
        org.junit.Assert.assertNotNull(jSError17);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        java.lang.String str1 = closureCodingConvention0.getExportPropertyFunction();
        boolean boolean3 = closureCodingConvention0.isPrivate("");
        boolean boolean5 = closureCodingConvention0.isPrivate("hi!");
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString((int) (short) 0, "");
        node8.setVarArgs(true);
        com.google.javascript.rhino.Node node11 = node8.getParent();
        com.google.javascript.rhino.Node node12 = node8.getNext();
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship13 = closureCodingConvention0.getDelegateRelationship(node8);
        com.google.javascript.rhino.jstype.FunctionType functionType14 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType15 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType16 = null;
        closureCodingConvention0.applySubclassRelationship(functionType14, functionType15, subclassType16);
        com.google.javascript.jscomp.AbstractCompiler abstractCompiler18 = null;
        com.google.javascript.jscomp.NodeTraversal.Callback callback19 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal20 = new com.google.javascript.jscomp.NodeTraversal(abstractCompiler18, callback19);
        com.google.javascript.rhino.Node node22 = com.google.javascript.rhino.Node.newString("language version");
        com.google.javascript.jscomp.DiagnosticType diagnosticType23 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        com.google.javascript.jscomp.CheckLevel checkLevel24 = diagnosticType23.defaultLevel;
        com.google.javascript.jscomp.DiagnosticType diagnosticType25 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray27 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError28 = com.google.javascript.jscomp.JSError.make(diagnosticType25, strArray27);
        com.google.javascript.jscomp.JSError jSError29 = nodeTraversal20.makeError(node22, diagnosticType23, strArray27);
        com.google.javascript.jscomp.Scope scope30 = nodeTraversal20.getScope();
        com.google.javascript.rhino.Node node34 = com.google.javascript.rhino.Node.newNumber((double) 1L, 0, 1);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder35 = node34.getJsDocBuilderForNode();
        com.google.javascript.rhino.Node node36 = node34.getLastSibling();
        com.google.javascript.rhino.Node node38 = new com.google.javascript.rhino.Node((int) (short) 10);
        java.lang.String str42 = node38.toString(true, false, true);
        boolean boolean43 = node38.isSyntheticBlock();
        com.google.javascript.rhino.Node node44 = node36.copyInformationFromForTree(node38);
        try {
            com.google.javascript.jscomp.CodingConvention.ObjectLiteralCast objectLiteralCast45 = closureCodingConvention0.getObjectLiteralCast(nodeTraversal20, node38);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "goog.exportProperty" + "'", str1.equals("goog.exportProperty"));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNull(node11);
        org.junit.Assert.assertNull(node12);
        org.junit.Assert.assertNull(delegateRelationship13);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertNotNull(diagnosticType23);
        org.junit.Assert.assertTrue("'" + checkLevel24 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel24.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticType25);
        org.junit.Assert.assertNotNull(strArray27);
        org.junit.Assert.assertNotNull(jSError28);
        org.junit.Assert.assertNotNull(jSError29);
        org.junit.Assert.assertNull(scope30);
        org.junit.Assert.assertNotNull(node34);
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder35);
        org.junit.Assert.assertNotNull(node36);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "BITXOR" + "'", str42.equals("BITXOR"));
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(node44);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        java.lang.String str1 = closureCodingConvention0.getExportPropertyFunction();
        boolean boolean3 = closureCodingConvention0.isPrivate("");
        boolean boolean5 = closureCodingConvention0.isPrivate("hi!");
        java.lang.String str6 = closureCodingConvention0.getDelegateSuperclassName();
        com.google.javascript.rhino.Node node9 = new com.google.javascript.rhino.Node((int) (short) 10);
        java.lang.Object obj11 = node9.getProp((int) (short) 1);
        boolean boolean12 = node9.hasMoreThanOneChild();
        com.google.javascript.rhino.Node node14 = new com.google.javascript.rhino.Node((int) (short) 10);
        java.lang.Object obj16 = node14.getProp((int) (short) 1);
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.Node.newString((int) (short) 0, "");
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable20 = node19.siblings();
        com.google.javascript.rhino.Node node21 = new com.google.javascript.rhino.Node((-1), node9, node14, node19);
        boolean boolean22 = closureCodingConvention0.isVarArgsParameter(node9);
        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray24 = new com.google.javascript.jscomp.WarningsGuard[] {};
        java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard> warningsGuardList25 = new java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard>();
        boolean boolean26 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList25, warningsGuardArray24);
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard27 = new com.google.javascript.jscomp.ComposeWarningsGuard((java.util.List<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList25);
        node9.putProp(5, (java.lang.Object) composeWarningsGuard27);
        boolean boolean29 = node9.isOptionalArg();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "goog.exportProperty" + "'", str1.equals("goog.exportProperty"));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNull(obj11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNull(obj16);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNotNull(nodeIterable20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(warningsGuardArray24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile1 = com.google.javascript.jscomp.JSSourceFile.fromFile("error reporter");
        com.google.javascript.jscomp.JsAst jsAst2 = new com.google.javascript.jscomp.JsAst((com.google.javascript.jscomp.SourceFile) jSSourceFile1);
        com.google.javascript.jscomp.CompilerInput compilerInput4 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) jsAst2, false);
        com.google.javascript.jscomp.Compiler compiler5 = new com.google.javascript.jscomp.Compiler();
        compilerInput4.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler5);
        com.google.javascript.jscomp.Compiler compiler7 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node[] nodeArray8 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList9 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean10 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList9, nodeArray8);
        com.google.javascript.jscomp.NodeTraversal.Callback callback11 = null;
        com.google.javascript.jscomp.NodeTraversal.traverseRoots((com.google.javascript.jscomp.AbstractCompiler) compiler7, (java.util.List<com.google.javascript.rhino.Node>) nodeList9, callback11);
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter13 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler7);
        compilerInput4.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler7);
        java.util.logging.Logger logger15 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager16 = new com.google.javascript.jscomp.LoggerErrorManager(logger15);
        com.google.javascript.jscomp.JSError[] jSErrorArray17 = loggerErrorManager16.getErrors();
        compiler7.setErrorManager((com.google.javascript.jscomp.ErrorManager) loggerErrorManager16);
        java.nio.charset.Charset charset20 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile21 = com.google.javascript.jscomp.JSSourceFile.fromFile("JSC_NODE_TRAVERSAL_ERROR", charset20);
        com.google.javascript.jscomp.JsAst jsAst22 = new com.google.javascript.jscomp.JsAst((com.google.javascript.jscomp.SourceFile) jSSourceFile21);
        java.nio.charset.Charset charset24 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile25 = com.google.javascript.jscomp.JSSourceFile.fromFile("JSC_NODE_TRAVERSAL_ERROR", charset24);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile27 = com.google.javascript.jscomp.JSSourceFile.fromFile("error reporter");
        java.nio.charset.Charset charset29 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile30 = com.google.javascript.jscomp.JSSourceFile.fromFile("JSC_NODE_TRAVERSAL_ERROR", charset29);
        com.google.javascript.jscomp.JsAst jsAst31 = new com.google.javascript.jscomp.JsAst((com.google.javascript.jscomp.SourceFile) jSSourceFile30);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile34 = com.google.javascript.jscomp.JSSourceFile.fromFile("error reporter");
        com.google.javascript.jscomp.JsAst jsAst35 = new com.google.javascript.jscomp.JsAst((com.google.javascript.jscomp.SourceFile) jSSourceFile34);
        java.lang.RuntimeException runtimeException36 = com.google.javascript.rhino.ScriptRuntime.undefCallError((java.lang.Object) 1.0d, (java.lang.Object) jSSourceFile34);
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray37 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile21, jSSourceFile25, jSSourceFile27, jSSourceFile30, jSSourceFile34 };
        java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList38 = new java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile>();
        boolean boolean39 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList38, jSSourceFileArray37);
        com.google.javascript.jscomp.JSModule[] jSModuleArray40 = new com.google.javascript.jscomp.JSModule[] {};
        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList41 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
        boolean boolean42 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList41, jSModuleArray40);
        com.google.javascript.jscomp.CompilerOptions compilerOptions43 = null;
        try {
            com.google.javascript.jscomp.Result result44 = compiler7.compileModules((java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList38, (java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList41, compilerOptions43);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile1);
        org.junit.Assert.assertNotNull(nodeArray8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(jSErrorArray17);
        org.junit.Assert.assertNotNull(jSSourceFile21);
        org.junit.Assert.assertNotNull(jSSourceFile25);
        org.junit.Assert.assertNotNull(jSSourceFile27);
        org.junit.Assert.assertNotNull(jSSourceFile30);
        org.junit.Assert.assertNotNull(jSSourceFile34);
        org.junit.Assert.assertNotNull(runtimeException36);
        org.junit.Assert.assertNotNull(jSSourceFileArray37);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertNotNull(jSModuleArray40);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newNumber((double) 1L, 0, 1);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder4 = node3.getJsDocBuilderForNode();
        boolean boolean5 = node3.isNoSideEffectsCall();
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString((int) (short) 0, "");
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable4 = node3.siblings();
        try {
            java.lang.String str5 = com.google.javascript.rhino.ScriptRuntime.getMessage1("BITXOR", (java.lang.Object) node3);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property BITXOR");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(nodeIterable4);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.Node.newString("language version");
        boolean boolean3 = node2.hasChildren();
        try {
            java.lang.String str4 = com.google.javascript.rhino.ScriptRuntime.getMessage1("Named type with empty name component", (java.lang.Object) boolean3);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property Named type with empty name component");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        com.google.javascript.rhino.Node node2 = new com.google.javascript.rhino.Node((int) (short) 10);
        java.lang.Object obj4 = node2.getProp((int) (short) 1);
        boolean boolean5 = node2.hasMoreThanOneChild();
        com.google.javascript.rhino.Node node7 = new com.google.javascript.rhino.Node((int) (short) 10);
        java.lang.Object obj9 = node7.getProp((int) (short) 1);
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString((int) (short) 0, "");
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable13 = node12.siblings();
        com.google.javascript.rhino.Node node14 = new com.google.javascript.rhino.Node((-1), node2, node7, node12);
        com.google.javascript.rhino.JSDocInfo jSDocInfo15 = null;
        node7.setJSDocInfo(jSDocInfo15);
        com.google.javascript.jscomp.SourceMap.DetailLevel detailLevel17 = com.google.javascript.jscomp.SourceMap.DetailLevel.ALL;
        com.google.javascript.rhino.Node node20 = new com.google.javascript.rhino.Node((int) (short) 10);
        java.lang.Object obj22 = node20.getProp((int) (short) 1);
        boolean boolean23 = node20.hasMoreThanOneChild();
        com.google.javascript.rhino.Node node25 = new com.google.javascript.rhino.Node((int) (short) 10);
        java.lang.Object obj27 = node25.getProp((int) (short) 1);
        com.google.javascript.rhino.Node node30 = com.google.javascript.rhino.Node.newString((int) (short) 0, "");
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable31 = node30.siblings();
        com.google.javascript.rhino.Node node32 = new com.google.javascript.rhino.Node((-1), node20, node25, node30);
        com.google.javascript.rhino.JSDocInfo jSDocInfo33 = null;
        node25.setJSDocInfo(jSDocInfo33);
        boolean boolean35 = detailLevel17.apply(node25);
        try {
            node7.addChildrenToBack(node25);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(obj4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(obj9);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(nodeIterable13);
        org.junit.Assert.assertNotNull(detailLevel17);
        org.junit.Assert.assertNull(obj22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNull(obj27);
        org.junit.Assert.assertNotNull(node30);
        org.junit.Assert.assertNotNull(nodeIterable31);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        com.google.javascript.rhino.EcmaError ecmaError6 = com.google.javascript.rhino.ScriptRuntime.constructError("BITXOR", "goog.exportProperty", "", 150, "", 0);
        java.lang.String str7 = ecmaError6.getLineSource();
        java.lang.String str8 = ecmaError6.sourceName();
        java.lang.String str9 = ecmaError6.getSourceName();
        java.lang.String str10 = ecmaError6.getSourceName();
        org.junit.Assert.assertNotNull(ecmaError6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node[] nodeArray1 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList2 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean3 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList2, nodeArray1);
        com.google.javascript.jscomp.NodeTraversal.Callback callback4 = null;
        com.google.javascript.jscomp.NodeTraversal.traverseRoots((com.google.javascript.jscomp.AbstractCompiler) compiler0, (java.util.List<com.google.javascript.rhino.Node>) nodeList2, callback4);
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter6 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler0);
        com.google.javascript.jscomp.SourceMap sourceMap7 = compiler0.getSourceMap();
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter8 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler0);
        com.google.javascript.jscomp.PerformanceTracker performanceTracker9 = compiler0.tracker;
        org.junit.Assert.assertNotNull(nodeArray1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(sourceMap7);
        org.junit.Assert.assertNull(performanceTracker9);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        java.io.InputStream inputStream2 = null;
        try {
            com.google.javascript.jscomp.SourceFile sourceFile3 = com.google.javascript.jscomp.SourceFile.fromInputStream("Node tree inequality:\nTree1:\nBITXOR\n\n\nTree2:\nEOF \n\n\nSubtree1: BITXOR\n\n\nSubtree2: EOF \n", "JSC_NODE_TRAVERSAL_ERROR.  at (unknown source) line 32 : (unknown column)", inputStream2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newNumber((double) 1L, 0, 1);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder4 = node3.getJsDocBuilderForNode();
        com.google.javascript.rhino.Node node5 = node3.getLastSibling();
        com.google.javascript.rhino.Node node7 = new com.google.javascript.rhino.Node((int) (short) 10);
        java.lang.String str11 = node7.toString(true, false, true);
        boolean boolean12 = node7.isSyntheticBlock();
        com.google.javascript.rhino.Node node13 = node5.copyInformationFromForTree(node7);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder14 = node7.getJsDocBuilderForNode();
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder4);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "BITXOR" + "'", str11.equals("BITXOR"));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder14);
    }

//    @Test
//    public void test301() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test301");
//        try {
//            com.google.javascript.rhino.Context.reportError("BITXOR", "JSC_NODE_TRAVERSAL_ERROR.  at (unknown source) line (unknown line) : (unknown column)", 39, "Node tree inequality:\nTree1:\nSTRING language version\n\n\nTree2:\nEOF \n\n\nSubtree1: STRING language version\n\n\nSubtree2: EOF \n", (int) (byte) 0);
//            org.junit.Assert.fail("Expected exception of type com.google.javascript.rhino.EvaluatorException; message: BITXOR (JSC_NODE_TRAVERSAL_ERROR.  at (unknown source) line (unknown line) : (unknown column)#39)");
//        } catch (com.google.javascript.rhino.EvaluatorException e) {
//        }
//    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.AMBIGUOUS_FUNCTION_DECL;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup1 = com.google.javascript.jscomp.DiagnosticGroups.FILEOVERVIEW_JSDOC;
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup2 = com.google.javascript.jscomp.DiagnosticGroups.CHECK_VARIABLES;
        com.google.javascript.jscomp.DiagnosticGroups.CONSTANT_PROPERTY = diagnosticGroup2;
        com.google.javascript.jscomp.DiagnosticGroup[] diagnosticGroupArray4 = new com.google.javascript.jscomp.DiagnosticGroup[] { diagnosticGroup1, diagnosticGroup2 };
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup5 = new com.google.javascript.jscomp.DiagnosticGroup(diagnosticGroupArray4);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup6 = new com.google.javascript.jscomp.DiagnosticGroup(diagnosticGroupArray4);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup7 = new com.google.javascript.jscomp.DiagnosticGroup("goog.exportProperty", diagnosticGroupArray4);
        org.junit.Assert.assertNotNull(diagnosticGroup1);
        org.junit.Assert.assertNotNull(diagnosticGroup2);
        org.junit.Assert.assertNotNull(diagnosticGroupArray4);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromCode("WARNING - JSC_NODE_TRAVERSAL_ERROR.  at (unknown source) line (unknown line) : (unknown column)\n", "JSC_NODE_TRAVERSAL_ERROR: {0}");
        org.junit.Assert.assertNotNull(jSSourceFile2);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile1 = com.google.javascript.jscomp.JSSourceFile.fromFile("error reporter");
        com.google.javascript.jscomp.JsAst jsAst2 = new com.google.javascript.jscomp.JsAst((com.google.javascript.jscomp.SourceFile) jSSourceFile1);
        com.google.javascript.jscomp.SourceFile sourceFile3 = jsAst2.getSourceFile();
        jsAst2.clearAst();
        com.google.javascript.jscomp.CompilerInput compilerInput6 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) jsAst2, false);
        org.junit.Assert.assertNotNull(jSSourceFile1);
        org.junit.Assert.assertNotNull(sourceFile3);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile1 = com.google.javascript.jscomp.JSSourceFile.fromFile("error reporter");
        com.google.javascript.jscomp.JsAst jsAst2 = new com.google.javascript.jscomp.JsAst((com.google.javascript.jscomp.SourceFile) jSSourceFile1);
        com.google.javascript.jscomp.CompilerInput compilerInput4 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) jsAst2, false);
        com.google.javascript.jscomp.Compiler compiler5 = new com.google.javascript.jscomp.Compiler();
        compilerInput4.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler5);
        com.google.javascript.jscomp.Compiler compiler7 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node[] nodeArray8 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList9 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean10 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList9, nodeArray8);
        com.google.javascript.jscomp.NodeTraversal.Callback callback11 = null;
        com.google.javascript.jscomp.NodeTraversal.traverseRoots((com.google.javascript.jscomp.AbstractCompiler) compiler7, (java.util.List<com.google.javascript.rhino.Node>) nodeList9, callback11);
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter13 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler7);
        compilerInput4.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler7);
        java.nio.charset.Charset charset16 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile17 = com.google.javascript.jscomp.JSSourceFile.fromFile("Node tree inequality:\nTree1:\nSTRING language version\n\n\nTree2:\nEOF \n\n\nSubtree1: STRING language version\n\n\nSubtree2: EOF \n", charset16);
        com.google.javascript.jscomp.JSModule jSModule18 = null;
        com.google.javascript.jscomp.JSModule[] jSModuleArray19 = new com.google.javascript.jscomp.JSModule[] { jSModule18 };
        com.google.javascript.jscomp.CompilerOptions compilerOptions20 = null;
        try {
            com.google.javascript.jscomp.Result result21 = compiler7.compile(jSSourceFile17, jSModuleArray19, compilerOptions20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile1);
        org.junit.Assert.assertNotNull(nodeArray8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(jSSourceFile17);
        org.junit.Assert.assertNotNull(jSModuleArray19);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node[] nodeArray1 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList2 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean3 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList2, nodeArray1);
        com.google.javascript.jscomp.NodeTraversal.Callback callback4 = null;
        com.google.javascript.jscomp.NodeTraversal.traverseRoots((com.google.javascript.jscomp.AbstractCompiler) compiler0, (java.util.List<com.google.javascript.rhino.Node>) nodeList2, callback4);
        try {
            com.google.javascript.jscomp.JSError[] jSErrorArray6 = compiler0.getWarnings();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(nodeArray1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString("language version");
        com.google.javascript.jscomp.DiagnosticType diagnosticType6 = com.google.javascript.jscomp.DiagnosticType.error("BITXOR", "(JSC_NODE_TRAVERSAL_ERROR.  at (unknown source) line (unknown line) : (unknown column))");
        com.google.javascript.jscomp.DiagnosticType diagnosticType7 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray9 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError10 = com.google.javascript.jscomp.JSError.make(diagnosticType7, strArray9);
        com.google.javascript.jscomp.JSError jSError11 = com.google.javascript.jscomp.JSError.make("JSC_NODE_TRAVERSAL_ERROR: {0}", node3, diagnosticType6, strArray9);
        com.google.javascript.rhino.Node node14 = new com.google.javascript.rhino.Node((int) (short) 10);
        java.lang.Object obj16 = node14.getProp((int) (short) 1);
        boolean boolean17 = node14.hasMoreThanOneChild();
        com.google.javascript.rhino.Node node19 = new com.google.javascript.rhino.Node((int) (short) 10);
        java.lang.Object obj21 = node19.getProp((int) (short) 1);
        com.google.javascript.rhino.Node node24 = com.google.javascript.rhino.Node.newString((int) (short) 0, "");
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable25 = node24.siblings();
        com.google.javascript.rhino.Node node26 = new com.google.javascript.rhino.Node((-1), node14, node19, node24);
        com.google.javascript.rhino.JSDocInfo jSDocInfo27 = null;
        node19.setJSDocInfo(jSDocInfo27);
        com.google.javascript.rhino.Node node31 = com.google.javascript.rhino.Node.newString("language version");
        int int32 = node31.getLineno();
        com.google.javascript.rhino.Node node35 = com.google.javascript.rhino.Node.newString((int) (short) 0, "");
        com.google.javascript.rhino.Node[] nodeArray36 = new com.google.javascript.rhino.Node[] { node31, node35 };
        com.google.javascript.rhino.Node node39 = new com.google.javascript.rhino.Node((int) (short) 100, nodeArray36, 40, 0);
        int int40 = node39.getType();
        try {
            com.google.javascript.rhino.Node node41 = new com.google.javascript.rhino.Node(9, node3, node19, node39);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(diagnosticType6);
        org.junit.Assert.assertNotNull(diagnosticType7);
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertNotNull(jSError10);
        org.junit.Assert.assertNotNull(jSError11);
        org.junit.Assert.assertNull(obj16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNull(obj21);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertNotNull(nodeIterable25);
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-1) + "'", int32 == (-1));
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertNotNull(nodeArray36);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 100 + "'", int40 == 100);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        java.lang.String str1 = closureCodingConvention0.getExportPropertyFunction();
        boolean boolean3 = closureCodingConvention0.isPrivate("");
        boolean boolean5 = closureCodingConvention0.isPrivate("hi!");
        java.lang.String str6 = closureCodingConvention0.getAbstractMethodName();
        boolean boolean8 = closureCodingConvention0.isExported("language version");
        com.google.javascript.rhino.Node node9 = null;
        boolean boolean10 = closureCodingConvention0.isVarArgsParameter(node9);
        com.google.javascript.jscomp.AbstractCompiler abstractCompiler11 = null;
        com.google.javascript.jscomp.NodeTraversal.Callback callback12 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal13 = new com.google.javascript.jscomp.NodeTraversal(abstractCompiler11, callback12);
        com.google.javascript.rhino.Node node14 = nodeTraversal13.getCurrentNode();
        java.lang.String str15 = nodeTraversal13.getSourceName();
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.Node.newNumber((double) 1L, 0, 1);
        com.google.javascript.rhino.Node node21 = new com.google.javascript.rhino.Node(42, node20);
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention22 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node23 = null;
        boolean boolean24 = closureCodingConvention22.isVarArgsParameter(node23);
        com.google.javascript.rhino.jstype.ObjectType objectType25 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType26 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType27 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType28 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType29 = null;
        closureCodingConvention22.applyDelegateRelationship(objectType25, objectType26, objectType27, functionType28, functionType29);
        com.google.javascript.rhino.jstype.FunctionType functionType31 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType32 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType33 = null;
        closureCodingConvention22.applySubclassRelationship(functionType31, functionType32, subclassType33);
        boolean boolean36 = closureCodingConvention22.isValidEnumKey("hi!");
        com.google.javascript.rhino.Node node38 = new com.google.javascript.rhino.Node((int) (short) 10);
        java.lang.Object obj40 = node38.getProp((int) (short) 1);
        com.google.javascript.rhino.Node node43 = new com.google.javascript.rhino.Node((int) (short) 10);
        java.lang.Object obj45 = node43.getProp((int) (short) 1);
        boolean boolean46 = node43.hasMoreThanOneChild();
        com.google.javascript.rhino.Node node48 = new com.google.javascript.rhino.Node((int) (short) 10);
        java.lang.Object obj50 = node48.getProp((int) (short) 1);
        com.google.javascript.rhino.Node node53 = com.google.javascript.rhino.Node.newString((int) (short) 0, "");
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable54 = node53.siblings();
        com.google.javascript.rhino.Node node55 = new com.google.javascript.rhino.Node((-1), node43, node48, node53);
        boolean boolean56 = node53.wasEmptyNode();
        java.lang.String str57 = closureCodingConvention22.extractClassNameIfProvide(node38, node53);
        boolean boolean58 = node21.hasChild(node38);
        try {
            com.google.javascript.jscomp.CodingConvention.ObjectLiteralCast objectLiteralCast59 = closureCodingConvention0.getObjectLiteralCast(nodeTraversal13, node21);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "goog.exportProperty" + "'", str1.equals("goog.exportProperty"));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "goog.abstractMethod" + "'", str6.equals("goog.abstractMethod"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNull(node14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertNull(obj40);
        org.junit.Assert.assertNull(obj45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNull(obj50);
        org.junit.Assert.assertNotNull(node53);
        org.junit.Assert.assertNotNull(nodeIterable54);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertNull(str57);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        com.google.javascript.rhino.EcmaError ecmaError6 = com.google.javascript.rhino.ScriptRuntime.constructError("BITXOR", "goog.exportProperty", "", 150, "", 0);
        java.lang.String str7 = ecmaError6.getLineSource();
        java.lang.String str8 = ecmaError6.getLineSource();
        org.junit.Assert.assertNotNull(ecmaError6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        int int0 = com.google.javascript.rhino.Node.TARGETBLOCK_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 22 + "'", int0 == 22);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        long long1 = com.google.javascript.rhino.ScriptRuntime.testUint32String("8");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 8L + "'", long1 == 8L);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        try {
            com.google.javascript.rhino.Context.reportWarning("goog.exportProperty");
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: No Context associated with current Thread");
        } catch (java.lang.RuntimeException e) {
        }
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        int int0 = com.google.javascript.rhino.Node.BREAK_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        com.google.javascript.rhino.Node node1 = null;
        com.google.javascript.rhino.Node node2 = null;
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newNumber(0.0d, 35, 40);
        node6.removeProp(8);
        boolean boolean10 = node6.getBooleanProp(45);
        try {
            com.google.javascript.rhino.Node node11 = new com.google.javascript.rhino.Node(0, node1, node2, node6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        com.google.javascript.rhino.Node node3 = new com.google.javascript.rhino.Node((int) (short) 10);
        java.lang.Object obj5 = node3.getProp((int) (short) 1);
        boolean boolean6 = node3.hasMoreThanOneChild();
        com.google.javascript.rhino.Node node8 = new com.google.javascript.rhino.Node((int) (short) 10);
        java.lang.Object obj10 = node8.getProp((int) (short) 1);
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString((int) (short) 0, "");
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable14 = node13.siblings();
        com.google.javascript.rhino.Node node15 = new com.google.javascript.rhino.Node((-1), node3, node8, node13);
        node3.detachChildren();
        com.google.javascript.jscomp.SourceMap.DetailLevel detailLevel17 = com.google.javascript.jscomp.SourceMap.DetailLevel.SYMBOLS;
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.Node.newString((int) (short) 0, "");
        node20.setVarArgs(true);
        boolean boolean23 = detailLevel17.apply(node20);
        com.google.javascript.rhino.Node node28 = com.google.javascript.rhino.Node.newNumber((double) 1L, 0, 1);
        com.google.javascript.rhino.Node node29 = new com.google.javascript.rhino.Node(42, node28);
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention30 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node31 = null;
        boolean boolean32 = closureCodingConvention30.isVarArgsParameter(node31);
        com.google.javascript.rhino.jstype.ObjectType objectType33 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType34 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType35 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType36 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType37 = null;
        closureCodingConvention30.applyDelegateRelationship(objectType33, objectType34, objectType35, functionType36, functionType37);
        com.google.javascript.rhino.jstype.FunctionType functionType39 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType40 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType41 = null;
        closureCodingConvention30.applySubclassRelationship(functionType39, functionType40, subclassType41);
        boolean boolean44 = closureCodingConvention30.isValidEnumKey("hi!");
        com.google.javascript.rhino.Node node46 = new com.google.javascript.rhino.Node((int) (short) 10);
        java.lang.Object obj48 = node46.getProp((int) (short) 1);
        com.google.javascript.rhino.Node node51 = new com.google.javascript.rhino.Node((int) (short) 10);
        java.lang.Object obj53 = node51.getProp((int) (short) 1);
        boolean boolean54 = node51.hasMoreThanOneChild();
        com.google.javascript.rhino.Node node56 = new com.google.javascript.rhino.Node((int) (short) 10);
        java.lang.Object obj58 = node56.getProp((int) (short) 1);
        com.google.javascript.rhino.Node node61 = com.google.javascript.rhino.Node.newString((int) (short) 0, "");
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable62 = node61.siblings();
        com.google.javascript.rhino.Node node63 = new com.google.javascript.rhino.Node((-1), node51, node56, node61);
        boolean boolean64 = node61.wasEmptyNode();
        java.lang.String str65 = closureCodingConvention30.extractClassNameIfProvide(node46, node61);
        boolean boolean66 = node29.hasChild(node46);
        try {
            com.google.javascript.rhino.Node node69 = new com.google.javascript.rhino.Node(8, node3, node20, node46, (int) ' ', 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(obj5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(obj10);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(nodeIterable14);
        org.junit.Assert.assertNotNull(detailLevel17);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
        org.junit.Assert.assertNull(obj48);
        org.junit.Assert.assertNull(obj53);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNull(obj58);
        org.junit.Assert.assertNotNull(node61);
        org.junit.Assert.assertNotNull(nodeIterable62);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertNull(str65);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        com.google.javascript.rhino.Node.SideEffectFlags sideEffectFlags0 = new com.google.javascript.rhino.Node.SideEffectFlags();
        sideEffectFlags0.setAllFlags();
        sideEffectFlags0.clearAllFlags();
        sideEffectFlags0.setMutatesThis();
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        int int0 = com.google.javascript.rhino.Node.EMPTY_BLOCK;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 38 + "'", int0 == 38);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        com.google.javascript.rhino.EvaluatorException evaluatorException1 = new com.google.javascript.rhino.EvaluatorException("hi!");
        evaluatorException1.initLineSource("");
        java.lang.String str4 = evaluatorException1.getScriptStackTrace();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "<No stack trace available>" + "'", str4.equals("<No stack trace available>"));
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        com.google.javascript.rhino.Context context0 = new com.google.javascript.rhino.Context();
        context0.addActivationName("goog.abstractMethod");
        com.google.javascript.rhino.ScriptRuntime.storeUint32Result(context0, (long) 100);
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        try {
            context0.addPropertyChangeListener(propertyChangeListener5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        java.lang.String str1 = com.google.javascript.rhino.jstype.ObjectType.createDelegateSuffix("goog.exportProperty");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "(goog.exportProperty)" + "'", str1.equals("(goog.exportProperty)"));
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        com.google.javascript.rhino.jstype.JSType jSType0 = null;
        com.google.javascript.rhino.jstype.JSType jSType1 = null;
        boolean boolean2 = com.google.javascript.rhino.jstype.JSType.isEquivalent(jSType0, jSType1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        com.google.javascript.jscomp.parsing.Config config2 = null;
        com.google.javascript.jscomp.mozilla.rhino.ErrorReporter errorReporter3 = null;
        java.util.logging.Logger logger4 = null;
        try {
            com.google.javascript.rhino.Node node5 = com.google.javascript.jscomp.parsing.ParserRunner.parse("error reporter", "JSC_NODE_TRAVERSAL_ERROR.  at (unknown source) line (unknown line) : (unknown column)", config2, errorReporter3, logger4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.FILEOVERVIEW_JSDOC;
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup1 = com.google.javascript.jscomp.DiagnosticGroups.CHECK_VARIABLES;
        com.google.javascript.jscomp.DiagnosticGroups.CONSTANT_PROPERTY = diagnosticGroup1;
        com.google.javascript.jscomp.DiagnosticGroup[] diagnosticGroupArray3 = new com.google.javascript.jscomp.DiagnosticGroup[] { diagnosticGroup0, diagnosticGroup1 };
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup4 = new com.google.javascript.jscomp.DiagnosticGroup(diagnosticGroupArray3);
        com.google.javascript.jscomp.DiagnosticGroups.CONSTANT_PROPERTY = diagnosticGroup4;
        com.google.javascript.jscomp.DiagnosticGroups.CHECK_TYPES = diagnosticGroup4;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
        org.junit.Assert.assertNotNull(diagnosticGroup1);
        org.junit.Assert.assertNotNull(diagnosticGroupArray3);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        com.google.javascript.rhino.EvaluatorException evaluatorException4 = new com.google.javascript.rhino.EvaluatorException("", "<No stack trace available>", (int) (short) 100);
        java.lang.RuntimeException runtimeException6 = com.google.javascript.rhino.ScriptRuntime.notFunctionError((java.lang.Object) '4');
        evaluatorException4.addSuppressed((java.lang.Throwable) runtimeException6);
        com.google.javascript.rhino.Node node10 = new com.google.javascript.rhino.Node((int) (short) 10);
        java.lang.Object obj12 = node10.getProp((int) (short) 1);
        boolean boolean13 = node10.hasMoreThanOneChild();
        com.google.javascript.rhino.Node node14 = node10.getLastChild();
        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.Node.newString("language version");
        int int17 = node16.getLineno();
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.Node.newString((int) (short) 0, "");
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable21 = node20.siblings();
        boolean boolean22 = node20.isNoSideEffectsCall();
        java.lang.String str23 = node16.checkTreeEquals(node20);
        com.google.javascript.rhino.Node node24 = new com.google.javascript.rhino.Node(110, node10, node16);
        com.google.javascript.rhino.Node node26 = node24.getAncestor((int) (byte) 0);
        java.lang.RuntimeException runtimeException27 = com.google.javascript.rhino.ScriptRuntime.notFunctionError((java.lang.Object) runtimeException6, (java.lang.Object) node26);
        com.google.javascript.rhino.Node node29 = new com.google.javascript.rhino.Node((int) (short) 10);
        com.google.javascript.rhino.Node node34 = com.google.javascript.rhino.Node.newNumber((double) 1L, 0, 1);
        com.google.javascript.rhino.Node node35 = new com.google.javascript.rhino.Node(42, node34);
        com.google.javascript.rhino.Node node38 = new com.google.javascript.rhino.Node(17, node26, node29, node35, 49, 45);
        try {
            int int40 = node38.getExistingIntProp(10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: FAILED ASSERTION");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(runtimeException6);
        org.junit.Assert.assertNull(obj12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNull(node14);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNotNull(nodeIterable21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "Node tree inequality:\nTree1:\nSTRING language version\n\n\nTree2:\nEOF \n\n\nSubtree1: STRING language version\n\n\nSubtree2: EOF \n" + "'", str23.equals("Node tree inequality:\nTree1:\nSTRING language version\n\n\nTree2:\nEOF \n\n\nSubtree1: STRING language version\n\n\nSubtree2: EOF \n"));
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertNotNull(runtimeException27);
        org.junit.Assert.assertNotNull(node34);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node1 = null;
        boolean boolean2 = closureCodingConvention0.isVarArgsParameter(node1);
        java.lang.String str3 = closureCodingConvention0.getGlobalObject();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "goog.global" + "'", str3.equals("goog.global"));
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newNumber((double) 1L, 0, 1);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder4 = node3.getJsDocBuilderForNode();
        int int6 = node3.getIntProp((int) '4');
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node[] nodeArray2 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList3 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean4 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList3, nodeArray2);
        com.google.javascript.jscomp.NodeTraversal.Callback callback5 = null;
        com.google.javascript.jscomp.NodeTraversal.traverseRoots((com.google.javascript.jscomp.AbstractCompiler) compiler1, (java.util.List<com.google.javascript.rhino.Node>) nodeList3, callback5);
        com.google.javascript.rhino.Node node9 = new com.google.javascript.rhino.Node((int) (short) 10);
        java.lang.Object obj11 = node9.getProp((int) (short) 1);
        boolean boolean12 = node9.hasMoreThanOneChild();
        com.google.javascript.rhino.Node node14 = new com.google.javascript.rhino.Node((int) (short) 10);
        java.lang.Object obj16 = node14.getProp((int) (short) 1);
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.Node.newString((int) (short) 0, "");
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable20 = node19.siblings();
        com.google.javascript.rhino.Node node21 = new com.google.javascript.rhino.Node((-1), node9, node14, node19);
        com.google.javascript.rhino.Node node26 = com.google.javascript.rhino.Node.newNumber((double) 1L, 0, 1);
        com.google.javascript.rhino.Node node27 = new com.google.javascript.rhino.Node(42, node26);
        try {
            java.lang.String str28 = com.google.javascript.rhino.ScriptRuntime.getMessage3("TypeError: <No stack trace available>", (java.lang.Object) compiler1, (java.lang.Object) node14, (java.lang.Object) node26);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property TypeError: <No stack trace available>");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(nodeArray2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(obj11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNull(obj16);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNotNull(nodeIterable20);
        org.junit.Assert.assertNotNull(node26);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        int int0 = com.google.javascript.rhino.Context.FEATURE_DYNAMIC_SCOPE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 7 + "'", int0 == 7);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node[] nodeArray1 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList2 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean3 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList2, nodeArray1);
        com.google.javascript.jscomp.NodeTraversal.Callback callback4 = null;
        com.google.javascript.jscomp.NodeTraversal.traverseRoots((com.google.javascript.jscomp.AbstractCompiler) compiler0, (java.util.List<com.google.javascript.rhino.Node>) nodeList2, callback4);
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter6 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler0);
        try {
            com.google.javascript.jscomp.JSError[] jSErrorArray7 = compiler0.getMessages();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(nodeArray1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        java.io.InputStream inputStream1 = null;
        try {
            com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromInputStream("JSC_NODE_TRAVERSAL_ERROR.  at (unknown source) line (unknown line) : (unknown column)", inputStream1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        try {
            com.google.javascript.rhino.EcmaError ecmaError3 = com.google.javascript.rhino.ScriptRuntime.typeError2("", "JSC_NODE_TRAVERSAL_ERROR.  at (unknown source) line 32 : (unknown column)", "<No stack trace available>");
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property ");
        } catch (java.lang.RuntimeException e) {
        }
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        com.google.javascript.jscomp.SourceMap.DetailLevel detailLevel1 = com.google.javascript.jscomp.SourceMap.DetailLevel.SYMBOLS;
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString((int) (short) 0, "");
        node4.setVarArgs(true);
        boolean boolean7 = detailLevel1.apply(node4);
        boolean boolean8 = node4.isVarArgs();
        com.google.javascript.jscomp.SourceMap.DetailLevel detailLevel9 = com.google.javascript.jscomp.SourceMap.DetailLevel.SYMBOLS;
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString((int) (short) 0, "");
        node12.setVarArgs(true);
        boolean boolean15 = detailLevel9.apply(node12);
        boolean boolean16 = node12.isVarArgs();
        com.google.javascript.rhino.Node node19 = new com.google.javascript.rhino.Node(0, node4, node12, 36, 140);
        boolean boolean20 = node12.hasChildren();
        java.lang.Appendable appendable21 = null;
        try {
            node12.appendStringTree(appendable21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(detailLevel1);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(detailLevel9);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile1 = com.google.javascript.jscomp.JSSourceFile.fromFile("error reporter");
        com.google.javascript.jscomp.JsAst jsAst2 = new com.google.javascript.jscomp.JsAst((com.google.javascript.jscomp.SourceFile) jSSourceFile1);
        com.google.javascript.jscomp.CompilerInput compilerInput4 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) jsAst2, false);
        com.google.javascript.jscomp.SourceFile sourceFile5 = jsAst2.getSourceFile();
        java.lang.String str7 = sourceFile5.getLine(1);
        org.junit.Assert.assertNotNull(jSSourceFile1);
        org.junit.Assert.assertNotNull(sourceFile5);
        org.junit.Assert.assertNull(str7);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        int int0 = com.google.javascript.rhino.Node.SIDE_EFFECTS_FLAGS_MASK;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 31 + "'", int0 == 31);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        int int0 = com.google.javascript.rhino.Node.SOURCENAME_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 16 + "'", int0 == 16);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        com.google.javascript.rhino.EvaluatorException evaluatorException3 = new com.google.javascript.rhino.EvaluatorException("", "<No stack trace available>", (int) (short) 100);
        java.io.FilenameFilter filenameFilter4 = null;
        java.lang.String str5 = evaluatorException3.getScriptStackTrace(filenameFilter4);
        java.lang.String str6 = evaluatorException3.getScriptStackTrace();
        java.lang.String str7 = evaluatorException3.sourceName();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "<No stack trace available>" + "'", str5.equals("<No stack trace available>"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "<No stack trace available>" + "'", str6.equals("<No stack trace available>"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "<No stack trace available>" + "'", str7.equals("<No stack trace available>"));
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        boolean boolean1 = com.google.javascript.rhino.ScriptRuntime.isJSLineTerminator((int) (byte) -1);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        java.nio.charset.Charset charset1 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset1);
        com.google.javascript.jscomp.Region region4 = jSSourceFile2.getRegion(2);
        org.junit.Assert.assertNotNull(jSSourceFile2);
        org.junit.Assert.assertNull(region4);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        com.google.javascript.jscomp.DiagnosticType diagnosticType0 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray2 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError3 = com.google.javascript.jscomp.JSError.make(diagnosticType0, strArray2);
        java.lang.String str4 = jSError3.toString();
        java.lang.String str5 = jSError3.description;
        org.junit.Assert.assertNotNull(diagnosticType0);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(jSError3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "JSC_NODE_TRAVERSAL_ERROR.  at (unknown source) line (unknown line) : (unknown column)" + "'", str4.equals("JSC_NODE_TRAVERSAL_ERROR.  at (unknown source) line (unknown line) : (unknown column)"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        java.lang.String str1 = closureCodingConvention0.getExportPropertyFunction();
        boolean boolean3 = closureCodingConvention0.isPrivate("");
        com.google.javascript.rhino.jstype.FunctionType functionType4 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType5 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType6 = null;
        closureCodingConvention0.applySubclassRelationship(functionType4, functionType5, subclassType6);
        com.google.javascript.rhino.Node node8 = null;
        boolean boolean9 = closureCodingConvention0.isOptionalParameter(node8);
        com.google.javascript.rhino.Node node12 = new com.google.javascript.rhino.Node((int) (short) 10);
        java.lang.String str16 = node12.toString(true, false, true);
        boolean boolean17 = node12.isSyntheticBlock();
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.Node.newString((int) (short) 0, "");
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable21 = node20.siblings();
        node20.detachChildren();
        com.google.javascript.rhino.Node node25 = new com.google.javascript.rhino.Node((int) ' ', node12, node20, 0, (int) (short) 1);
        try {
            java.lang.String str26 = closureCodingConvention0.getSingletonGetterClassName(node20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "goog.exportProperty" + "'", str1.equals("goog.exportProperty"));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "BITXOR" + "'", str16.equals("BITXOR"));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNotNull(nodeIterable21);
    }

//    @Test
//    public void test342() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test342");
//        try {
//            com.google.javascript.rhino.EvaluatorException evaluatorException5 = com.google.javascript.rhino.Context.reportRuntimeError("Unknown class name", "Not declared as a constructor", 41, "(JSC_NODE_TRAVERSAL_ERROR.  at (unknown source) line (unknown line) : (unknown column))", 24);
//            org.junit.Assert.fail("Expected exception of type com.google.javascript.rhino.EvaluatorException; message: Unknown class name (Not declared as a constructor#41)");
//        } catch (com.google.javascript.rhino.EvaluatorException e) {
//        }
//    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = null;
        com.google.javascript.jscomp.DiagnosticGroups.CONSTANT_PROPERTY = diagnosticGroup0;
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newNumber(0.0d, 35, 40);
        node3.removeProp(8);
        com.google.javascript.rhino.Node node6 = null;
        try {
            com.google.javascript.rhino.Node node7 = node3.removeChildAfter(node6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node3);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.Node.newString("language version");
        node2.setQuotedString();
        com.google.javascript.rhino.Node node4 = node2.cloneTree();
        com.google.javascript.jscomp.NodeTraversal.Callback callback5 = null;
        try {
            com.google.javascript.jscomp.NodeTraversal.traverse((com.google.javascript.jscomp.AbstractCompiler) compiler0, node2, callback5);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: INTERNAL COMPILER ERROR.\nPlease report this problem.\nnull");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertNotNull(node4);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        com.google.javascript.rhino.Context context0 = new com.google.javascript.rhino.Context();
        com.google.javascript.rhino.ErrorReporter errorReporter1 = null;
        try {
            com.google.javascript.rhino.ErrorReporter errorReporter2 = context0.setErrorReporter(errorReporter1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test347() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test347");
//        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.UNKNOWN_DEFINES;
//        org.junit.Assert.assertNotNull(diagnosticGroup0);
//    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        com.google.javascript.jscomp.AbstractCompiler abstractCompiler0 = null;
        com.google.javascript.jscomp.NodeTraversal.Callback callback1 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal2 = new com.google.javascript.jscomp.NodeTraversal(abstractCompiler0, callback1);
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString("language version");
        com.google.javascript.jscomp.DiagnosticType diagnosticType5 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        com.google.javascript.jscomp.CheckLevel checkLevel6 = diagnosticType5.defaultLevel;
        com.google.javascript.jscomp.DiagnosticType diagnosticType7 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray9 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError10 = com.google.javascript.jscomp.JSError.make(diagnosticType7, strArray9);
        com.google.javascript.jscomp.JSError jSError11 = nodeTraversal2.makeError(node4, diagnosticType5, strArray9);
        com.google.javascript.jscomp.DiagnosticType diagnosticType12 = null;
        try {
            int int13 = diagnosticType5.compareTo(diagnosticType12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(diagnosticType5);
        org.junit.Assert.assertTrue("'" + checkLevel6 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel6.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticType7);
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertNotNull(jSError10);
        org.junit.Assert.assertNotNull(jSError11);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        int int0 = com.google.javascript.rhino.Node.CASES_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 13 + "'", int0 == 13);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.Compiler.IntermediateState intermediateState2 = compiler1.getState();
        com.google.javascript.jscomp.Compiler compiler3 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node[] nodeArray4 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList5 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean6 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList5, nodeArray4);
        com.google.javascript.jscomp.NodeTraversal.Callback callback7 = null;
        com.google.javascript.jscomp.NodeTraversal.traverseRoots((com.google.javascript.jscomp.AbstractCompiler) compiler3, (java.util.List<com.google.javascript.rhino.Node>) nodeList5, callback7);
        com.google.javascript.jscomp.PerformanceTracker performanceTracker9 = compiler3.tracker;
        com.google.javascript.jscomp.SourceExcerptProvider.SourceExcerpt sourceExcerpt10 = null;
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter11 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler3, sourceExcerpt10);
        java.util.logging.Logger logger12 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager13 = new com.google.javascript.jscomp.LoggerErrorManager((com.google.javascript.jscomp.MessageFormatter) lightweightMessageFormatter11, logger12);
        compiler1.setErrorManager((com.google.javascript.jscomp.ErrorManager) loggerErrorManager13);
        loggerErrorManager13.generateReport();
        org.junit.Assert.assertNotNull(intermediateState2);
        org.junit.Assert.assertNotNull(nodeArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(performanceTracker9);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node[] nodeArray1 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList2 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean3 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList2, nodeArray1);
        com.google.javascript.jscomp.NodeTraversal.Callback callback4 = null;
        com.google.javascript.jscomp.NodeTraversal.traverseRoots((com.google.javascript.jscomp.AbstractCompiler) compiler0, (java.util.List<com.google.javascript.rhino.Node>) nodeList2, callback4);
        com.google.javascript.jscomp.PerformanceTracker performanceTracker6 = compiler0.tracker;
        com.google.javascript.jscomp.SourceExcerptProvider.SourceExcerpt sourceExcerpt7 = null;
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter8 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler0, sourceExcerpt7);
        try {
            java.lang.String[] strArray9 = compiler0.toSourceArray();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(nodeArray1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(performanceTracker6);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        com.google.javascript.jscomp.AbstractCompiler abstractCompiler0 = null;
        com.google.javascript.jscomp.NodeTraversal.Callback callback1 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal2 = new com.google.javascript.jscomp.NodeTraversal(abstractCompiler0, callback1);
        boolean boolean3 = nodeTraversal2.hasScope();
        try {
            com.google.javascript.rhino.Node node4 = nodeTraversal2.getScopeRoot();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

//    @Test
//    public void test353() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test353");
//        try {
//            com.google.javascript.rhino.Context.reportError("(goog.exportProperty)", "8", 21, "goog.abstractMethod", 39);
//            org.junit.Assert.fail("Expected exception of type com.google.javascript.rhino.EvaluatorException; message: (goog.exportProperty) (8#21)");
//        } catch (com.google.javascript.rhino.EvaluatorException e) {
//        }
//    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile1 = com.google.javascript.jscomp.JSSourceFile.fromFile("error reporter");
        com.google.javascript.jscomp.JsAst jsAst2 = new com.google.javascript.jscomp.JsAst((com.google.javascript.jscomp.SourceFile) jSSourceFile1);
        com.google.javascript.jscomp.CompilerInput compilerInput4 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) jsAst2, false);
        com.google.javascript.jscomp.Compiler compiler5 = new com.google.javascript.jscomp.Compiler();
        compilerInput4.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler5);
        com.google.javascript.jscomp.Compiler compiler7 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node[] nodeArray8 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList9 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean10 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList9, nodeArray8);
        com.google.javascript.jscomp.NodeTraversal.Callback callback11 = null;
        com.google.javascript.jscomp.NodeTraversal.traverseRoots((com.google.javascript.jscomp.AbstractCompiler) compiler7, (java.util.List<com.google.javascript.rhino.Node>) nodeList9, callback11);
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter13 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler7);
        compilerInput4.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler7);
        java.util.logging.Logger logger15 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager16 = new com.google.javascript.jscomp.LoggerErrorManager(logger15);
        com.google.javascript.jscomp.JSError[] jSErrorArray17 = loggerErrorManager16.getErrors();
        compiler7.setErrorManager((com.google.javascript.jscomp.ErrorManager) loggerErrorManager16);
        com.google.javascript.jscomp.SourceMap sourceMap19 = compiler7.getSourceMap();
        java.nio.charset.Charset charset21 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile22 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset21);
        java.nio.charset.Charset charset24 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile25 = com.google.javascript.jscomp.JSSourceFile.fromFile("Node tree inequality:\nTree1:\nSTRING language version\n\n\nTree2:\nEOF \n\n\nSubtree1: STRING language version\n\n\nSubtree2: EOF \n", charset24);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile28 = com.google.javascript.jscomp.JSSourceFile.fromCode("WARNING - JSC_NODE_TRAVERSAL_ERROR.  at (unknown source) line (unknown line) : (unknown column)\n", "JSC_NODE_TRAVERSAL_ERROR: {0}");
        java.nio.charset.Charset charset30 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile31 = com.google.javascript.jscomp.JSSourceFile.fromFile("JSC_NODE_TRAVERSAL_ERROR", charset30);
        java.lang.String str32 = jSSourceFile31.getOriginalPath();
        java.lang.String str33 = jSSourceFile31.toString();
        java.nio.charset.Charset charset35 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile36 = com.google.javascript.jscomp.JSSourceFile.fromFile("JSC_NODE_TRAVERSAL_ERROR", charset35);
        java.lang.String str37 = jSSourceFile36.getOriginalPath();
        java.lang.String str38 = jSSourceFile36.toString();
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray39 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile22, jSSourceFile25, jSSourceFile28, jSSourceFile31, jSSourceFile36 };
        java.nio.charset.Charset charset41 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile42 = com.google.javascript.jscomp.JSSourceFile.fromFile("JSC_NODE_TRAVERSAL_ERROR", charset41);
        java.lang.String str43 = jSSourceFile42.getOriginalPath();
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray44 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile42 };
        com.google.javascript.jscomp.CompilerOptions compilerOptions45 = null;
        try {
            com.google.javascript.jscomp.Result result46 = compiler7.compile(jSSourceFileArray39, jSSourceFileArray44, compilerOptions45);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile1);
        org.junit.Assert.assertNotNull(nodeArray8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(jSErrorArray17);
        org.junit.Assert.assertNull(sourceMap19);
        org.junit.Assert.assertNotNull(jSSourceFile22);
        org.junit.Assert.assertNotNull(jSSourceFile25);
        org.junit.Assert.assertNotNull(jSSourceFile28);
        org.junit.Assert.assertNotNull(jSSourceFile31);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "JSC_NODE_TRAVERSAL_ERROR" + "'", str32.equals("JSC_NODE_TRAVERSAL_ERROR"));
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "JSC_NODE_TRAVERSAL_ERROR" + "'", str33.equals("JSC_NODE_TRAVERSAL_ERROR"));
        org.junit.Assert.assertNotNull(jSSourceFile36);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "JSC_NODE_TRAVERSAL_ERROR" + "'", str37.equals("JSC_NODE_TRAVERSAL_ERROR"));
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "JSC_NODE_TRAVERSAL_ERROR" + "'", str38.equals("JSC_NODE_TRAVERSAL_ERROR"));
        org.junit.Assert.assertNotNull(jSSourceFileArray39);
        org.junit.Assert.assertNotNull(jSSourceFile42);
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "JSC_NODE_TRAVERSAL_ERROR" + "'", str43.equals("JSC_NODE_TRAVERSAL_ERROR"));
        org.junit.Assert.assertNotNull(jSSourceFileArray44);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        com.google.javascript.rhino.Node node1 = null;
        try {
            com.google.javascript.rhino.Node node4 = new com.google.javascript.rhino.Node(0, node1, (int) (byte) 100, (int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        java.util.List<com.google.javascript.jscomp.WarningsGuard> warningsGuardList0 = null;
        try {
            com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard1 = new com.google.javascript.jscomp.ComposeWarningsGuard(warningsGuardList0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        com.google.javascript.jscomp.AbstractCompiler abstractCompiler0 = null;
        com.google.javascript.jscomp.NodeTraversal.Callback callback1 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal2 = new com.google.javascript.jscomp.NodeTraversal(abstractCompiler0, callback1);
        boolean boolean3 = nodeTraversal2.hasScope();
        com.google.javascript.jscomp.Compiler compiler4 = nodeTraversal2.getCompiler();
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.Node.newString("language version");
        int int8 = node7.getLineno();
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.Node.newString((int) (short) 0, "");
        com.google.javascript.rhino.Node[] nodeArray12 = new com.google.javascript.rhino.Node[] { node7, node11 };
        com.google.javascript.rhino.Node node15 = new com.google.javascript.rhino.Node((int) (short) 100, nodeArray12, 40, 0);
        try {
            nodeTraversal2.traverseRoots(nodeArray12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(compiler4);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertNotNull(nodeArray12);
    }

//    @Test
//    public void test358() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test358");
//        try {
//            com.google.javascript.rhino.Context.reportError("", "8", (int) (byte) 1, "JSC_NODE_TRAVERSAL_ERROR.  at (unknown source) line (unknown line) : (unknown column)", 13);
//            org.junit.Assert.fail("Expected exception of type com.google.javascript.rhino.EvaluatorException; message:  (8#1)");
//        } catch (com.google.javascript.rhino.EvaluatorException e) {
//        }
//    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        com.google.javascript.rhino.Node node2 = new com.google.javascript.rhino.Node((int) (short) 10);
        java.lang.Object obj4 = node2.getProp((int) (short) 1);
        boolean boolean5 = node2.hasMoreThanOneChild();
        com.google.javascript.rhino.Node node7 = new com.google.javascript.rhino.Node((int) (short) 10);
        java.lang.Object obj9 = node7.getProp((int) (short) 1);
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString((int) (short) 0, "");
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable13 = node12.siblings();
        com.google.javascript.rhino.Node node14 = new com.google.javascript.rhino.Node((-1), node2, node7, node12);
        boolean boolean15 = node12.wasEmptyNode();
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable16 = node12.children();
        org.junit.Assert.assertNull(obj4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(obj9);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(nodeIterable13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(nodeIterable16);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString(4, "(goog.exportProperty)", 31, (int) '#');
        org.junit.Assert.assertNotNull(node4);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        java.lang.String str1 = closureCodingConvention0.getExportPropertyFunction();
        boolean boolean3 = closureCodingConvention0.isPrivate("");
        boolean boolean5 = closureCodingConvention0.isPrivate("hi!");
        java.lang.String str6 = closureCodingConvention0.getDelegateSuperclassName();
        com.google.javascript.rhino.Node node9 = new com.google.javascript.rhino.Node((int) (short) 10);
        java.lang.Object obj11 = node9.getProp((int) (short) 1);
        boolean boolean12 = node9.hasMoreThanOneChild();
        com.google.javascript.rhino.Node node14 = new com.google.javascript.rhino.Node((int) (short) 10);
        java.lang.Object obj16 = node14.getProp((int) (short) 1);
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.Node.newString((int) (short) 0, "");
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable20 = node19.siblings();
        com.google.javascript.rhino.Node node21 = new com.google.javascript.rhino.Node((-1), node9, node14, node19);
        boolean boolean22 = closureCodingConvention0.isVarArgsParameter(node9);
        java.lang.String str23 = closureCodingConvention0.getExportPropertyFunction();
        com.google.javascript.jscomp.AbstractCompiler abstractCompiler24 = null;
        com.google.javascript.jscomp.NodeTraversal.Callback callback25 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal26 = new com.google.javascript.jscomp.NodeTraversal(abstractCompiler24, callback25);
        com.google.javascript.rhino.Node node27 = nodeTraversal26.getCurrentNode();
        com.google.javascript.rhino.Node node29 = com.google.javascript.rhino.Node.newString("language version");
        int int30 = node29.getLineno();
        int int32 = node29.getIntProp(24);
        boolean boolean33 = node29.isQuotedString();
        try {
            com.google.javascript.jscomp.CodingConvention.ObjectLiteralCast objectLiteralCast34 = closureCodingConvention0.getObjectLiteralCast(nodeTraversal26, node29);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "goog.exportProperty" + "'", str1.equals("goog.exportProperty"));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNull(obj11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNull(obj16);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNotNull(nodeIterable20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "goog.exportProperty" + "'", str23.equals("goog.exportProperty"));
        org.junit.Assert.assertNull(node27);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node1 = null;
        boolean boolean2 = closureCodingConvention0.isVarArgsParameter(node1);
        com.google.javascript.rhino.Node node4 = new com.google.javascript.rhino.Node((int) (short) 10);
        java.lang.Object obj6 = node4.getProp((int) (short) 1);
        com.google.javascript.rhino.jstype.JSType jSType7 = null;
        node4.setJSType(jSType7);
        boolean boolean9 = node4.hasOneChild();
        boolean boolean10 = closureCodingConvention0.isVarArgsParameter(node4);
        int int11 = node4.getChildCount();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(obj6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        com.google.javascript.rhino.Node.SideEffectFlags sideEffectFlags0 = new com.google.javascript.rhino.Node.SideEffectFlags();
        sideEffectFlags0.setAllFlags();
        sideEffectFlags0.clearAllFlags();
        sideEffectFlags0.clearSideEffectFlags();
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        com.google.javascript.rhino.Context.checkLanguageVersion(0);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        java.io.InputStream inputStream1 = null;
        try {
            com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromInputStream("JSC_NODE_TRAVERSAL_ERROR.  at (unknown source) line (unknown line) : (unknown column)", inputStream1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        com.google.javascript.jscomp.SourceMap.Format format0 = com.google.javascript.jscomp.SourceMap.Format.EXPERIMENTIAL;
        org.junit.Assert.assertNotNull(format0);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        try {
            com.google.javascript.rhino.EcmaError ecmaError4 = com.google.javascript.rhino.ScriptRuntime.typeError3("goog.abstractMethod", "(goog.exportProperty)", "Node tree inequality:\nTree1:\nBITXOR\n\n\nTree2:\nEOF \n\n\nSubtree1: BITXOR\n\n\nSubtree2: EOF \n", "Node tree inequality:\nTree1:\nBITXOR\n\n\nTree2:\nEOF \n\n\nSubtree1: BITXOR\n\n\nSubtree2: EOF \n");
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property goog.abstractMethod");
        } catch (java.lang.RuntimeException e) {
        }
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.Scope scope1 = compiler0.getTopScope();
        com.google.javascript.rhino.Node node2 = compiler0.getRoot();
        com.google.javascript.jscomp.PassConfig passConfig3 = null;
        try {
            compiler0.setPassConfig(passConfig3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(scope1);
        org.junit.Assert.assertNull(node2);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.Node.newString((int) (short) 0, "");
        node2.setVarArgs(true);
        com.google.javascript.rhino.Node node5 = node2.getParent();
        try {
            int int7 = node2.getExistingIntProp((int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: FAILED ASSERTION");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertNull(node5);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        java.lang.String str1 = closureCodingConvention0.getExportPropertyFunction();
        boolean boolean3 = closureCodingConvention0.isPrivate("");
        boolean boolean5 = closureCodingConvention0.isPrivate("hi!");
        java.lang.String str6 = closureCodingConvention0.getDelegateSuperclassName();
        com.google.javascript.rhino.Node node9 = new com.google.javascript.rhino.Node((int) (short) 10);
        java.lang.Object obj11 = node9.getProp((int) (short) 1);
        boolean boolean12 = node9.hasMoreThanOneChild();
        com.google.javascript.rhino.Node node14 = new com.google.javascript.rhino.Node((int) (short) 10);
        java.lang.Object obj16 = node14.getProp((int) (short) 1);
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.Node.newString((int) (short) 0, "");
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable20 = node19.siblings();
        com.google.javascript.rhino.Node node21 = new com.google.javascript.rhino.Node((-1), node9, node14, node19);
        boolean boolean22 = closureCodingConvention0.isVarArgsParameter(node9);
        com.google.javascript.jscomp.AbstractCompiler abstractCompiler23 = null;
        com.google.javascript.jscomp.NodeTraversal.Callback callback24 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal25 = new com.google.javascript.jscomp.NodeTraversal(abstractCompiler23, callback24);
        com.google.javascript.rhino.Node node27 = com.google.javascript.rhino.Node.newString("language version");
        int int28 = node27.getLineno();
        node27.setType(32);
        try {
            com.google.javascript.jscomp.CodingConvention.ObjectLiteralCast objectLiteralCast31 = closureCodingConvention0.getObjectLiteralCast(nodeTraversal25, node27);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "goog.exportProperty" + "'", str1.equals("goog.exportProperty"));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNull(obj11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNull(obj16);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNotNull(nodeIterable20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(node27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1) + "'", int28 == (-1));
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        java.lang.String[] strArray0 = com.google.javascript.rhino.ScriptRuntime.emptyStrings;
        org.junit.Assert.assertNotNull(strArray0);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        com.google.javascript.rhino.EcmaError ecmaError6 = com.google.javascript.rhino.ScriptRuntime.constructError("BITXOR", "goog.exportProperty", "", 150, "", 0);
        java.lang.String str7 = ecmaError6.getLineSource();
        java.lang.String str8 = ecmaError6.sourceName();
        java.lang.String str9 = ecmaError6.getScriptStackTrace();
        java.lang.String str10 = ecmaError6.toString();
        org.junit.Assert.assertNotNull(ecmaError6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "<No stack trace available>" + "'", str9.equals("<No stack trace available>"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "com.google.javascript.rhino.EcmaError: BITXOR: goog.exportProperty (#150)" + "'", str10.equals("com.google.javascript.rhino.EcmaError: BITXOR: goog.exportProperty (#150)"));
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        int int0 = com.google.javascript.rhino.Node.FLAG_ARGUMENTS_UNMODIFIED;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        boolean boolean1 = com.google.javascript.rhino.Context.isValidLanguageVersion(26);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        long long1 = com.google.javascript.rhino.ScriptRuntime.testUint32String("Named type with empty name component");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1L) + "'", long1 == (-1L));
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        java.lang.String str1 = closureCodingConvention0.getExportPropertyFunction();
        boolean boolean3 = closureCodingConvention0.isPrivate("");
        boolean boolean5 = closureCodingConvention0.isPrivate("hi!");
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString((int) (short) 0, "");
        node8.setVarArgs(true);
        com.google.javascript.rhino.Node node11 = node8.getParent();
        com.google.javascript.rhino.Node node12 = node8.getNext();
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship13 = closureCodingConvention0.getDelegateRelationship(node8);
        com.google.javascript.rhino.jstype.FunctionType functionType14 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType15 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType16 = null;
        closureCodingConvention0.applySubclassRelationship(functionType14, functionType15, subclassType16);
        com.google.javascript.rhino.Node node20 = new com.google.javascript.rhino.Node((int) (short) 10);
        java.lang.Object obj22 = node20.getProp((int) (short) 1);
        boolean boolean23 = node20.hasMoreThanOneChild();
        com.google.javascript.rhino.Node node24 = node20.getLastChild();
        com.google.javascript.rhino.Node node26 = com.google.javascript.rhino.Node.newString("language version");
        int int27 = node26.getLineno();
        com.google.javascript.rhino.Node node30 = com.google.javascript.rhino.Node.newString((int) (short) 0, "");
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable31 = node30.siblings();
        boolean boolean32 = node30.isNoSideEffectsCall();
        java.lang.String str33 = node26.checkTreeEquals(node30);
        com.google.javascript.rhino.Node node34 = new com.google.javascript.rhino.Node(110, node20, node26);
        com.google.javascript.rhino.Node node36 = node34.getAncestor((int) (byte) 0);
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship37 = closureCodingConvention0.getDelegateRelationship(node36);
        com.google.javascript.rhino.Node node39 = new com.google.javascript.rhino.Node((int) (short) 10);
        java.lang.Object obj41 = node39.getProp((int) (short) 1);
        com.google.javascript.rhino.JSDocInfo jSDocInfo42 = node39.getJSDocInfo();
        try {
            java.lang.String str43 = closureCodingConvention0.getSingletonGetterClassName(node39);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "goog.exportProperty" + "'", str1.equals("goog.exportProperty"));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNull(node11);
        org.junit.Assert.assertNull(node12);
        org.junit.Assert.assertNull(delegateRelationship13);
        org.junit.Assert.assertNull(obj22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNull(node24);
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
        org.junit.Assert.assertNotNull(node30);
        org.junit.Assert.assertNotNull(nodeIterable31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "Node tree inequality:\nTree1:\nSTRING language version\n\n\nTree2:\nEOF \n\n\nSubtree1: STRING language version\n\n\nSubtree2: EOF \n" + "'", str33.equals("Node tree inequality:\nTree1:\nSTRING language version\n\n\nTree2:\nEOF \n\n\nSubtree1: STRING language version\n\n\nSubtree2: EOF \n"));
        org.junit.Assert.assertNotNull(node36);
        org.junit.Assert.assertNull(delegateRelationship37);
        org.junit.Assert.assertNull(obj41);
        org.junit.Assert.assertNull(jSDocInfo42);
    }

//    @Test
//    public void test377() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test377");
//        try {
//            com.google.javascript.rhino.EvaluatorException evaluatorException5 = com.google.javascript.rhino.Context.reportRuntimeError("Node tree inequality:\nTree1:\nBITXOR\n\n\nTree2:\nEOF \n\n\nSubtree1: BITXOR\n\n\nSubtree2: EOF \n", "(JSC_NODE_TRAVERSAL_ERROR.  at (unknown source) line (unknown line) : (unknown column))", (int) '4', "", 110);
//            org.junit.Assert.fail("Expected exception of type com.google.javascript.rhino.EvaluatorException; message: Node tree inequality:\nTree1:\nBITXOR\n\n\nTree2:\nEOF \n\n\nSubtree1: BITXOR\n\n\nSubtree2: EOF \n ((JSC_NODE_TRAVERSAL_ERROR.  at (unknown source) line (unknown line) : (unknown column))#52)");
//        } catch (com.google.javascript.rhino.EvaluatorException e) {
//        }
//    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        com.google.javascript.rhino.Context context0 = new com.google.javascript.rhino.Context();
        context0.addActivationName("goog.abstractMethod");
        boolean boolean3 = context0.hasCompileFunctionsWithDynamicScope();
        int int4 = context0.getLanguageVersion();
        java.lang.Object obj6 = context0.getThreadLocal((java.lang.Object) 6);
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        try {
            context0.addPropertyChangeListener(propertyChangeListener7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNull(obj6);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        int int0 = com.google.javascript.rhino.Context.FEATURE_MEMBER_EXPR_AS_FUNCTION_NAME;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        int int0 = com.google.javascript.rhino.Node.SKIP_INDEXES_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 30 + "'", int0 == 30);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        com.google.javascript.rhino.EvaluatorException evaluatorException1 = new com.google.javascript.rhino.EvaluatorException("hi!");
        int int2 = evaluatorException1.columnNumber();
        int int3 = evaluatorException1.columnNumber();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        java.nio.charset.Charset charset1 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromFile("WARNING - JSC_NODE_TRAVERSAL_ERROR.  at (unknown source) line (unknown line) : (unknown column)\n", charset1);
        try {
            java.lang.String str3 = jSSourceFile2.getCode();
            org.junit.Assert.fail("Expected exception of type java.io.FileNotFoundException; message: WARNING - JSC_NODE_TRAVERSAL_ERROR.  at (unknown source) line (unknown line) : (unknown column)\n (No such file or directory)");
        } catch (java.io.FileNotFoundException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile2);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        java.io.InputStream inputStream2 = null;
        try {
            com.google.javascript.jscomp.SourceFile sourceFile3 = com.google.javascript.jscomp.SourceFile.fromInputStream("language version", "language version", inputStream2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        com.google.javascript.jscomp.AbstractCompiler abstractCompiler0 = null;
        com.google.javascript.jscomp.NodeTraversal.Callback callback1 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal2 = new com.google.javascript.jscomp.NodeTraversal(abstractCompiler0, callback1);
        com.google.javascript.rhino.Node node3 = nodeTraversal2.getCurrentNode();
        java.lang.String str4 = nodeTraversal2.getSourceName();
        try {
            com.google.javascript.rhino.Node node5 = nodeTraversal2.getScopeRoot();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(node3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        int int0 = com.google.javascript.rhino.Node.CASEARRAY_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 15 + "'", int0 == 15);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile1 = com.google.javascript.jscomp.JSSourceFile.fromFile("JSC_NODE_TRAVERSAL_ERROR.  at (unknown source) line (unknown line) : (unknown column)");
        org.junit.Assert.assertNotNull(jSSourceFile1);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        com.google.javascript.jscomp.SourceMap.DetailLevel detailLevel2 = com.google.javascript.jscomp.SourceMap.DetailLevel.SYMBOLS;
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newString((int) (short) 0, "");
        node5.setVarArgs(true);
        boolean boolean8 = detailLevel2.apply(node5);
        boolean boolean9 = node5.isVarArgs();
        com.google.javascript.jscomp.SourceMap.DetailLevel detailLevel10 = com.google.javascript.jscomp.SourceMap.DetailLevel.SYMBOLS;
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString((int) (short) 0, "");
        node13.setVarArgs(true);
        boolean boolean16 = detailLevel10.apply(node13);
        boolean boolean17 = node13.isVarArgs();
        com.google.javascript.rhino.Node node20 = new com.google.javascript.rhino.Node(0, node5, node13, 36, 140);
        boolean boolean21 = node13.hasChildren();
        int int22 = node13.getSideEffectFlags();
        try {
            com.google.javascript.rhino.Node node23 = new com.google.javascript.rhino.Node(40, node13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: new child has existing parent");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(detailLevel2);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(detailLevel10);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString(4, "language version", 7, 3);
        org.junit.Assert.assertNotNull(node4);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        com.google.javascript.rhino.EcmaError ecmaError6 = com.google.javascript.rhino.ScriptRuntime.constructError("WARNING - JSC_NODE_TRAVERSAL_ERROR.  at (unknown source) line (unknown line) : (unknown column)\n", "", "Unknown class name", 4, "goog.exportProperty", 34);
        int int7 = ecmaError6.getLineNumber();
        org.junit.Assert.assertNotNull(ecmaError6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 4 + "'", int7 == 4);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile1 = com.google.javascript.jscomp.JSSourceFile.fromFile("error reporter");
        com.google.javascript.jscomp.JsAst jsAst2 = new com.google.javascript.jscomp.JsAst((com.google.javascript.jscomp.SourceFile) jSSourceFile1);
        com.google.javascript.jscomp.CompilerInput compilerInput4 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) jsAst2, false);
        com.google.javascript.jscomp.Compiler compiler5 = new com.google.javascript.jscomp.Compiler();
        compilerInput4.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler5);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile8 = com.google.javascript.jscomp.JSSourceFile.fromFile("error reporter");
        com.google.javascript.jscomp.JsAst jsAst9 = new com.google.javascript.jscomp.JsAst((com.google.javascript.jscomp.SourceFile) jSSourceFile8);
        com.google.javascript.jscomp.CompilerInput compilerInput11 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) jsAst9, false);
        com.google.javascript.jscomp.Compiler compiler12 = new com.google.javascript.jscomp.Compiler();
        compilerInput11.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler12);
        com.google.javascript.jscomp.Compiler compiler14 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node[] nodeArray15 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList16 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean17 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList16, nodeArray15);
        com.google.javascript.jscomp.NodeTraversal.Callback callback18 = null;
        com.google.javascript.jscomp.NodeTraversal.traverseRoots((com.google.javascript.jscomp.AbstractCompiler) compiler14, (java.util.List<com.google.javascript.rhino.Node>) nodeList16, callback18);
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter20 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler14);
        compilerInput11.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler14);
        java.util.logging.Logger logger22 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager23 = new com.google.javascript.jscomp.LoggerErrorManager(logger22);
        com.google.javascript.jscomp.JSError[] jSErrorArray24 = loggerErrorManager23.getErrors();
        compiler14.setErrorManager((com.google.javascript.jscomp.ErrorManager) loggerErrorManager23);
        compilerInput4.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler14);
        java.util.Collection<java.lang.String> strCollection27 = compilerInput4.getRequires();
        org.junit.Assert.assertNotNull(jSSourceFile1);
        org.junit.Assert.assertNotNull(jSSourceFile8);
        org.junit.Assert.assertNotNull(nodeArray15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(jSErrorArray24);
        org.junit.Assert.assertNotNull(strCollection27);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        com.google.javascript.jscomp.DiagnosticType diagnosticType0 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray2 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError3 = com.google.javascript.jscomp.JSError.make(diagnosticType0, strArray2);
        com.google.javascript.jscomp.DiagnosticType diagnosticType4 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        com.google.javascript.jscomp.DiagnosticType diagnosticType5 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray7 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError8 = com.google.javascript.jscomp.JSError.make(diagnosticType5, strArray7);
        com.google.javascript.jscomp.DiagnosticType[] diagnosticTypeArray9 = new com.google.javascript.jscomp.DiagnosticType[] { diagnosticType0, diagnosticType4, diagnosticType5 };
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup10 = new com.google.javascript.jscomp.DiagnosticGroup(diagnosticTypeArray9);
        com.google.javascript.jscomp.DiagnosticType diagnosticType11 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray13 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError14 = com.google.javascript.jscomp.JSError.make(diagnosticType11, strArray13);
        java.lang.Class<?> wildcardClass15 = diagnosticType11.getClass();
        com.google.javascript.jscomp.DiagnosticType diagnosticType18 = com.google.javascript.jscomp.DiagnosticType.warning("", "");
        com.google.javascript.jscomp.CheckLevel checkLevel19 = diagnosticType18.level;
        diagnosticType11.level = checkLevel19;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard21 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup10, checkLevel19);
        com.google.javascript.jscomp.DiagnosticGroups.TYPE_INVALIDATION = diagnosticGroup10;
        com.google.javascript.jscomp.DiagnosticGroups.TWEAKS = diagnosticGroup10;
        com.google.javascript.jscomp.DiagnosticGroups.INTERNET_EXPLORER_CHECKS = diagnosticGroup10;
        org.junit.Assert.assertNotNull(diagnosticType0);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(jSError3);
        org.junit.Assert.assertNotNull(diagnosticType4);
        org.junit.Assert.assertNotNull(diagnosticType5);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertNotNull(jSError8);
        org.junit.Assert.assertNotNull(diagnosticTypeArray9);
        org.junit.Assert.assertNotNull(diagnosticType11);
        org.junit.Assert.assertNotNull(strArray13);
        org.junit.Assert.assertNotNull(jSError14);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(diagnosticType18);
        org.junit.Assert.assertTrue("'" + checkLevel19 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel19.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node[] nodeArray1 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList2 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean3 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList2, nodeArray1);
        com.google.javascript.jscomp.NodeTraversal.Callback callback4 = null;
        com.google.javascript.jscomp.NodeTraversal.traverseRoots((com.google.javascript.jscomp.AbstractCompiler) compiler0, (java.util.List<com.google.javascript.rhino.Node>) nodeList2, callback4);
        com.google.javascript.jscomp.PerformanceTracker performanceTracker6 = compiler0.tracker;
        com.google.javascript.jscomp.SourceExcerptProvider.SourceExcerpt sourceExcerpt7 = null;
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter8 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler0, sourceExcerpt7);
        com.google.javascript.jscomp.Compiler.IntermediateState intermediateState9 = compiler0.getState();
        com.google.javascript.jscomp.Compiler.IntermediateState intermediateState10 = compiler0.getState();
        com.google.javascript.jscomp.ErrorManager errorManager11 = compiler0.getErrorManager();
        try {
            com.google.javascript.jscomp.CompilerInput compilerInput13 = compiler0.newExternInput("");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(nodeArray1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(performanceTracker6);
        org.junit.Assert.assertNotNull(intermediateState9);
        org.junit.Assert.assertNotNull(intermediateState10);
        org.junit.Assert.assertNotNull(errorManager11);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node[] nodeArray1 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList2 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean3 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList2, nodeArray1);
        com.google.javascript.jscomp.NodeTraversal.Callback callback4 = null;
        com.google.javascript.jscomp.NodeTraversal.traverseRoots((com.google.javascript.jscomp.AbstractCompiler) compiler0, (java.util.List<com.google.javascript.rhino.Node>) nodeList2, callback4);
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter6 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler0);
        try {
            com.google.javascript.jscomp.CompilerInput compilerInput8 = compiler0.getInput("<No stack trace available>");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(nodeArray1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        com.google.javascript.jscomp.Compiler.CodeBuilder codeBuilder0 = new com.google.javascript.jscomp.Compiler.CodeBuilder();
        int int1 = codeBuilder0.getLength();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        com.google.javascript.rhino.Node.SideEffectFlags sideEffectFlags0 = new com.google.javascript.rhino.Node.SideEffectFlags();
        sideEffectFlags0.setAllFlags();
        int int2 = sideEffectFlags0.valueOf();
        sideEffectFlags0.setMutatesGlobalState();
        sideEffectFlags0.setMutatesThis();
        sideEffectFlags0.setMutatesThis();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        try {
            com.google.javascript.rhino.Context.reportWarning("");
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: No Context associated with current Thread");
        } catch (java.lang.RuntimeException e) {
        }
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        com.google.javascript.rhino.EvaluatorException evaluatorException1 = new com.google.javascript.rhino.EvaluatorException("hi!");
        evaluatorException1.initSourceName("WARNING - JSC_NODE_TRAVERSAL_ERROR.  at (unknown source) line (unknown line) : (unknown column)\n");
        java.lang.String str4 = evaluatorException1.toString();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "com.google.javascript.rhino.EvaluatorException: hi!" + "'", str4.equals("com.google.javascript.rhino.EvaluatorException: hi!"));
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node[] nodeArray1 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList2 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean3 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList2, nodeArray1);
        com.google.javascript.jscomp.NodeTraversal.Callback callback4 = null;
        com.google.javascript.jscomp.NodeTraversal.traverseRoots((com.google.javascript.jscomp.AbstractCompiler) compiler0, (java.util.List<com.google.javascript.rhino.Node>) nodeList2, callback4);
        com.google.javascript.jscomp.PerformanceTracker performanceTracker6 = compiler0.tracker;
        com.google.javascript.jscomp.SourceExcerptProvider.SourceExcerpt sourceExcerpt7 = null;
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter8 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler0, sourceExcerpt7);
        com.google.javascript.jscomp.Compiler.IntermediateState intermediateState9 = compiler0.getState();
        com.google.javascript.jscomp.Compiler.IntermediateState intermediateState10 = compiler0.getState();
        com.google.javascript.jscomp.ErrorManager errorManager11 = compiler0.getErrorManager();
        java.io.PrintStream printStream12 = null;
        com.google.javascript.jscomp.Compiler compiler13 = new com.google.javascript.jscomp.Compiler(printStream12);
        com.google.javascript.jscomp.Compiler.IntermediateState intermediateState14 = compiler13.getState();
        com.google.javascript.jscomp.Compiler compiler15 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node[] nodeArray16 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList17 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean18 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList17, nodeArray16);
        com.google.javascript.jscomp.NodeTraversal.Callback callback19 = null;
        com.google.javascript.jscomp.NodeTraversal.traverseRoots((com.google.javascript.jscomp.AbstractCompiler) compiler15, (java.util.List<com.google.javascript.rhino.Node>) nodeList17, callback19);
        com.google.javascript.jscomp.PerformanceTracker performanceTracker21 = compiler15.tracker;
        com.google.javascript.jscomp.SourceExcerptProvider.SourceExcerpt sourceExcerpt22 = null;
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter23 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler15, sourceExcerpt22);
        java.util.logging.Logger logger24 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager25 = new com.google.javascript.jscomp.LoggerErrorManager((com.google.javascript.jscomp.MessageFormatter) lightweightMessageFormatter23, logger24);
        compiler13.setErrorManager((com.google.javascript.jscomp.ErrorManager) loggerErrorManager25);
        compiler0.setErrorManager((com.google.javascript.jscomp.ErrorManager) loggerErrorManager25);
        com.google.javascript.jscomp.Result result28 = compiler0.getResult();
        org.junit.Assert.assertNotNull(nodeArray1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(performanceTracker6);
        org.junit.Assert.assertNotNull(intermediateState9);
        org.junit.Assert.assertNotNull(intermediateState10);
        org.junit.Assert.assertNotNull(errorManager11);
        org.junit.Assert.assertNotNull(intermediateState14);
        org.junit.Assert.assertNotNull(nodeArray16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNull(performanceTracker21);
        org.junit.Assert.assertNotNull(result28);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node[] nodeArray1 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList2 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean3 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList2, nodeArray1);
        com.google.javascript.jscomp.NodeTraversal.Callback callback4 = null;
        com.google.javascript.jscomp.NodeTraversal.traverseRoots((com.google.javascript.jscomp.AbstractCompiler) compiler0, (java.util.List<com.google.javascript.rhino.Node>) nodeList2, callback4);
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter6 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler0);
        com.google.javascript.jscomp.SourceMap sourceMap7 = compiler0.getSourceMap();
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter8 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler0);
        com.google.javascript.jscomp.PassConfig passConfig9 = null;
        try {
            compiler0.setPassConfig(passConfig9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(nodeArray1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(sourceMap7);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        java.nio.charset.Charset charset1 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromFile("<No stack trace available>", charset1);
        jSSourceFile2.clearCachedSource();
        org.junit.Assert.assertNotNull(jSSourceFile2);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node[] nodeArray2 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList3 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean4 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList3, nodeArray2);
        com.google.javascript.jscomp.NodeTraversal.Callback callback5 = null;
        com.google.javascript.jscomp.NodeTraversal.traverseRoots((com.google.javascript.jscomp.AbstractCompiler) compiler1, (java.util.List<com.google.javascript.rhino.Node>) nodeList3, callback5);
        com.google.javascript.jscomp.NodeTraversal.Callback callback7 = null;
        com.google.javascript.jscomp.NodeTraversal.traverseRoots((com.google.javascript.jscomp.AbstractCompiler) compiler0, (java.util.List<com.google.javascript.rhino.Node>) nodeList3, callback7);
        com.google.javascript.jscomp.JSModule jSModule9 = null;
        try {
            java.lang.String str10 = compiler0.toSource(jSModule9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(nodeArray2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile1 = com.google.javascript.jscomp.JSSourceFile.fromFile("error reporter");
        com.google.javascript.jscomp.JsAst jsAst2 = new com.google.javascript.jscomp.JsAst((com.google.javascript.jscomp.SourceFile) jSSourceFile1);
        com.google.javascript.jscomp.CompilerInput compilerInput4 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) jsAst2, false);
        com.google.javascript.jscomp.Compiler compiler5 = new com.google.javascript.jscomp.Compiler();
        compilerInput4.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler5);
        com.google.javascript.jscomp.Compiler compiler7 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node[] nodeArray8 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList9 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean10 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList9, nodeArray8);
        com.google.javascript.jscomp.NodeTraversal.Callback callback11 = null;
        com.google.javascript.jscomp.NodeTraversal.traverseRoots((com.google.javascript.jscomp.AbstractCompiler) compiler7, (java.util.List<com.google.javascript.rhino.Node>) nodeList9, callback11);
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter13 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler7);
        compilerInput4.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler7);
        java.util.logging.Logger logger15 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager16 = new com.google.javascript.jscomp.LoggerErrorManager(logger15);
        com.google.javascript.jscomp.JSError[] jSErrorArray17 = loggerErrorManager16.getErrors();
        compiler7.setErrorManager((com.google.javascript.jscomp.ErrorManager) loggerErrorManager16);
        try {
            compiler7.rebuildInputsFromModules();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile1);
        org.junit.Assert.assertNotNull(nodeArray8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(jSErrorArray17);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy0 = com.google.javascript.jscomp.PropertyRenamingPolicy.ALL_UNQUOTED;
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy0 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.ALL_UNQUOTED + "'", propertyRenamingPolicy0.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.ALL_UNQUOTED));
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        java.io.InputStream inputStream1 = null;
        try {
            com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromInputStream("", inputStream1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromFile("error reporter");
        com.google.javascript.jscomp.JsAst jsAst3 = new com.google.javascript.jscomp.JsAst((com.google.javascript.jscomp.SourceFile) jSSourceFile2);
        com.google.javascript.jscomp.SourceFile sourceFile4 = jsAst3.getSourceFile();
        jsAst3.clearAst();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile7 = com.google.javascript.jscomp.JSSourceFile.fromFile("error reporter");
        com.google.javascript.jscomp.JsAst jsAst8 = new com.google.javascript.jscomp.JsAst((com.google.javascript.jscomp.SourceFile) jSSourceFile7);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup9 = com.google.javascript.jscomp.DiagnosticGroups.CHECK_VARIABLES;
        com.google.javascript.jscomp.DiagnosticGroups.CONSTANT_PROPERTY = diagnosticGroup9;
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup11 = com.google.javascript.jscomp.DiagnosticGroups.VISIBILITY;
        try {
            java.lang.String str12 = com.google.javascript.rhino.ScriptRuntime.getMessage4("Node tree inequality:\nTree1:\nSTRING language version\n\n\nTree2:\nEOF \n\n\nSubtree1: STRING language version\n\n\nSubtree2: EOF \n", (java.lang.Object) jsAst3, (java.lang.Object) jSSourceFile7, (java.lang.Object) diagnosticGroup9, (java.lang.Object) diagnosticGroup11);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property Node tree inequality:\nTree1:\nSTRING language version\n\n\nTree2:\nEOF \n\n\nSubtree1: STRING language version\n\n\nSubtree2: EOF \n");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile2);
        org.junit.Assert.assertNotNull(sourceFile4);
        org.junit.Assert.assertNotNull(jSSourceFile7);
        org.junit.Assert.assertNotNull(diagnosticGroup9);
        org.junit.Assert.assertNull(diagnosticGroup11);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        int int0 = com.google.javascript.rhino.Node.NAME_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 33 + "'", int0 == 33);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node1 = null;
        boolean boolean2 = closureCodingConvention0.isVarArgsParameter(node1);
        com.google.javascript.rhino.jstype.ObjectType objectType3 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType4 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType5 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType6 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType7 = null;
        closureCodingConvention0.applyDelegateRelationship(objectType3, objectType4, objectType5, functionType6, functionType7);
        com.google.javascript.rhino.jstype.FunctionType functionType9 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType10 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType11 = null;
        closureCodingConvention0.applySubclassRelationship(functionType9, functionType10, subclassType11);
        java.util.Collection<com.google.javascript.jscomp.CodingConvention.AssertionFunctionSpec> assertionFunctionSpecCollection13 = closureCodingConvention0.getAssertionFunctions();
        com.google.javascript.rhino.Node node14 = null;
        try {
            java.util.List<java.lang.String> strList15 = closureCodingConvention0.identifyTypeDeclarationCall(node14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(assertionFunctionSpecCollection13);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        com.google.javascript.jscomp.mozilla.rhino.ast.AstRoot astRoot0 = null;
        com.google.javascript.jscomp.parsing.Config.LanguageMode languageMode3 = com.google.javascript.jscomp.parsing.Config.LanguageMode.ECMASCRIPT5;
        com.google.javascript.jscomp.parsing.Config config5 = com.google.javascript.jscomp.parsing.ParserRunner.createConfig(true, languageMode3, false);
        com.google.javascript.jscomp.mozilla.rhino.ErrorReporter errorReporter6 = null;
        try {
            com.google.javascript.rhino.Node node7 = com.google.javascript.jscomp.parsing.IRFactory.transformTree(astRoot0, "JSC_NODE_TRAVERSAL_ERROR: {0}", config5, errorReporter6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + languageMode3 + "' != '" + com.google.javascript.jscomp.parsing.Config.LanguageMode.ECMASCRIPT5 + "'", languageMode3.equals(com.google.javascript.jscomp.parsing.Config.LanguageMode.ECMASCRIPT5));
        org.junit.Assert.assertNotNull(config5);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node1 = null;
        boolean boolean2 = closureCodingConvention0.isVarArgsParameter(node1);
        com.google.javascript.rhino.jstype.ObjectType objectType3 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType4 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType5 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType6 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType7 = null;
        closureCodingConvention0.applyDelegateRelationship(objectType3, objectType4, objectType5, functionType6, functionType7);
        com.google.javascript.rhino.jstype.FunctionType functionType9 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType10 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType11 = null;
        closureCodingConvention0.applySubclassRelationship(functionType9, functionType10, subclassType11);
        boolean boolean14 = closureCodingConvention0.isValidEnumKey("hi!");
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newString("language version");
        int int18 = node17.getLineno();
        com.google.javascript.rhino.Node node21 = com.google.javascript.rhino.Node.newString((int) (short) 0, "");
        com.google.javascript.rhino.Node[] nodeArray22 = new com.google.javascript.rhino.Node[] { node17, node21 };
        com.google.javascript.rhino.Node node25 = new com.google.javascript.rhino.Node((int) (short) 100, nodeArray22, 40, 0);
        java.util.List<java.lang.String> strList26 = closureCodingConvention0.identifyTypeDeclarationCall(node25);
        com.google.javascript.rhino.jstype.FunctionType functionType27 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType28 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType29 = null;
        try {
            closureCodingConvention0.applySingletonGetter(functionType27, functionType28, objectType29);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertNotNull(nodeArray22);
        org.junit.Assert.assertNull(strList26);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        com.google.javascript.rhino.EcmaError ecmaError6 = com.google.javascript.rhino.ScriptRuntime.constructError("BITXOR", "goog.exportProperty", "", 150, "", 0);
        java.lang.String str7 = ecmaError6.getLineSource();
        java.lang.String str8 = ecmaError6.sourceName();
        java.lang.String str9 = ecmaError6.lineSource();
        org.junit.Assert.assertNotNull(ecmaError6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromCode("hi!", "JSC_NODE_TRAVERSAL_ERROR.  at (unknown source) line 32 : (unknown column)");
        com.google.javascript.jscomp.Region region4 = sourceFile2.getRegion((int) (byte) -1);
        org.junit.Assert.assertNotNull(sourceFile2);
        org.junit.Assert.assertNotNull(region4);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newString("language version");
        boolean boolean2 = node1.hasChildren();
        java.util.Collection<com.google.javascript.rhino.Node> nodeCollection3 = com.google.javascript.jscomp.NodeUtil.getVarsDeclaredInBranch(node1);
        java.lang.String str4 = node1.getString();
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(nodeCollection3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "language version" + "'", str4.equals("language version"));
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        com.google.javascript.rhino.EvaluatorException evaluatorException1 = new com.google.javascript.rhino.EvaluatorException("hi!");
        java.lang.RuntimeException runtimeException2 = com.google.javascript.rhino.ScriptRuntime.notFunctionError((java.lang.Object) evaluatorException1);
        java.lang.String str3 = evaluatorException1.sourceName();
        org.junit.Assert.assertNotNull(runtimeException2);
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        com.google.javascript.rhino.EvaluatorException evaluatorException1 = new com.google.javascript.rhino.EvaluatorException("Node tree inequality:\nTree1:\nBITXOR\n\n\nTree2:\nEOF \n\n\nSubtree1: BITXOR\n\n\nSubtree2: EOF \n");
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node[] nodeArray1 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList2 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean3 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList2, nodeArray1);
        com.google.javascript.jscomp.NodeTraversal.Callback callback4 = null;
        com.google.javascript.jscomp.NodeTraversal.traverseRoots((com.google.javascript.jscomp.AbstractCompiler) compiler0, (java.util.List<com.google.javascript.rhino.Node>) nodeList2, callback4);
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter6 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler0);
        com.google.javascript.jscomp.SourceMap sourceMap7 = compiler0.getSourceMap();
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter8 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler0);
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray9 = new com.google.javascript.jscomp.JSSourceFile[] {};
        com.google.javascript.jscomp.JSModule jSModule10 = null;
        com.google.javascript.jscomp.JSModule[] jSModuleArray11 = new com.google.javascript.jscomp.JSModule[] { jSModule10 };
        com.google.javascript.jscomp.CompilerOptions compilerOptions12 = null;
        try {
            compiler0.init(jSSourceFileArray9, jSModuleArray11, compilerOptions12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(nodeArray1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(sourceMap7);
        org.junit.Assert.assertNotNull(jSSourceFileArray9);
        org.junit.Assert.assertNotNull(jSModuleArray11);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile1 = com.google.javascript.jscomp.JSSourceFile.fromFile("error reporter");
        com.google.javascript.jscomp.JsAst jsAst2 = new com.google.javascript.jscomp.JsAst((com.google.javascript.jscomp.SourceFile) jSSourceFile1);
        com.google.javascript.jscomp.CompilerInput compilerInput4 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) jsAst2, false);
        com.google.javascript.jscomp.Compiler compiler5 = new com.google.javascript.jscomp.Compiler();
        compilerInput4.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler5);
        com.google.javascript.jscomp.DiagnosticType diagnosticType7 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray9 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError10 = com.google.javascript.jscomp.JSError.make(diagnosticType7, strArray9);
        com.google.javascript.jscomp.DiagnosticType diagnosticType11 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray13 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError14 = com.google.javascript.jscomp.JSError.make(diagnosticType11, strArray13);
        com.google.javascript.jscomp.JSError jSError15 = com.google.javascript.jscomp.JSError.make(diagnosticType7, strArray13);
        com.google.javascript.jscomp.CheckLevel checkLevel16 = compiler5.getErrorLevel(jSError15);
        com.google.javascript.jscomp.SourceExcerptProvider.SourceExcerpt sourceExcerpt17 = null;
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter18 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler5, sourceExcerpt17);
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter19 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler5);
        try {
            com.google.javascript.jscomp.Region region22 = compiler5.getSourceRegion("<No stack trace available>", 45);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile1);
        org.junit.Assert.assertNotNull(diagnosticType7);
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertNotNull(jSError10);
        org.junit.Assert.assertNotNull(diagnosticType11);
        org.junit.Assert.assertNotNull(strArray13);
        org.junit.Assert.assertNotNull(jSError14);
        org.junit.Assert.assertNotNull(jSError15);
        org.junit.Assert.assertNull(checkLevel16);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        com.google.javascript.rhino.Context context0 = new com.google.javascript.rhino.Context();
        context0.addActivationName("goog.abstractMethod");
        long long3 = com.google.javascript.rhino.ScriptRuntime.lastUint32Result(context0);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        try {
            context0.addPropertyChangeListener(propertyChangeListener4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        java.lang.String str1 = com.google.javascript.rhino.Node.tokenToName((int) (byte) 0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "eof" + "'", str1.equals("eof"));
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString("Unknown class name", 8, 7);
        java.util.Collection<com.google.javascript.rhino.Node> nodeCollection4 = com.google.javascript.jscomp.NodeUtil.getVarsDeclaredInBranch(node3);
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention5 = new com.google.javascript.jscomp.ClosureCodingConvention();
        java.lang.String str6 = closureCodingConvention5.getExportPropertyFunction();
        boolean boolean8 = closureCodingConvention5.isPrivate("");
        boolean boolean10 = closureCodingConvention5.isPrivate("hi!");
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString((int) (short) 0, "");
        boolean boolean14 = closureCodingConvention5.isOptionalParameter(node13);
        java.util.Collection<com.google.javascript.jscomp.CodingConvention.AssertionFunctionSpec> assertionFunctionSpecCollection15 = closureCodingConvention5.getAssertionFunctions();
        com.google.javascript.rhino.Node node17 = new com.google.javascript.rhino.Node((int) (byte) 100);
        boolean boolean18 = closureCodingConvention5.isOptionalParameter(node17);
        java.lang.String str19 = node3.checkTreeEquals(node17);
        boolean boolean21 = node17.getBooleanProp(23);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(nodeCollection4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "goog.exportProperty" + "'", str6.equals("goog.exportProperty"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(assertionFunctionSpecCollection15);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "Node tree inequality:\nTree1:\nSTRING Unknown class name 8\n\n\nTree2:\nOR\n\n\nSubtree1: STRING Unknown class name 8\n\n\nSubtree2: OR\n" + "'", str19.equals("Node tree inequality:\nTree1:\nSTRING Unknown class name 8\n\n\nTree2:\nOR\n\n\nSubtree1: STRING Unknown class name 8\n\n\nSubtree2: OR\n"));
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromFile("error reporter");
        com.google.javascript.jscomp.JsAst jsAst3 = new com.google.javascript.jscomp.JsAst((com.google.javascript.jscomp.SourceFile) jSSourceFile2);
        java.lang.RuntimeException runtimeException4 = com.google.javascript.rhino.ScriptRuntime.undefCallError((java.lang.Object) 1.0d, (java.lang.Object) jSSourceFile2);
        try {
            java.lang.String str5 = jSSourceFile2.getCode();
            org.junit.Assert.fail("Expected exception of type java.io.FileNotFoundException; message: error reporter (No such file or directory)");
        } catch (java.io.FileNotFoundException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile2);
        org.junit.Assert.assertNotNull(runtimeException4);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        try {
            java.lang.String str2 = com.google.javascript.rhino.ScriptRuntime.escapeString("eof", ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: FAILED ASSERTION");
        } catch (java.lang.IllegalStateException e) {
        }
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.Compiler.IntermediateState intermediateState2 = compiler1.getState();
        com.google.javascript.jscomp.Compiler compiler3 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node[] nodeArray4 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList5 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean6 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList5, nodeArray4);
        com.google.javascript.jscomp.NodeTraversal.Callback callback7 = null;
        com.google.javascript.jscomp.NodeTraversal.traverseRoots((com.google.javascript.jscomp.AbstractCompiler) compiler3, (java.util.List<com.google.javascript.rhino.Node>) nodeList5, callback7);
        com.google.javascript.jscomp.PerformanceTracker performanceTracker9 = compiler3.tracker;
        com.google.javascript.jscomp.SourceExcerptProvider.SourceExcerpt sourceExcerpt10 = null;
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter11 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler3, sourceExcerpt10);
        java.util.logging.Logger logger12 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager13 = new com.google.javascript.jscomp.LoggerErrorManager((com.google.javascript.jscomp.MessageFormatter) lightweightMessageFormatter11, logger12);
        compiler1.setErrorManager((com.google.javascript.jscomp.ErrorManager) loggerErrorManager13);
        com.google.javascript.jscomp.Compiler.CodeBuilder codeBuilder15 = null;
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.Node.newString("language version");
        int int19 = node18.getLineno();
        com.google.javascript.rhino.Node node22 = com.google.javascript.rhino.Node.newString((int) (short) 0, "");
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable23 = node22.siblings();
        boolean boolean24 = node22.isNoSideEffectsCall();
        java.lang.String str25 = node18.checkTreeEquals(node22);
        node18.setIsSyntheticBlock(true);
        try {
            compiler1.toSource(codeBuilder15, (int) (byte) 100, node18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intermediateState2);
        org.junit.Assert.assertNotNull(nodeArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(performanceTracker9);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertNotNull(nodeIterable23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "Node tree inequality:\nTree1:\nSTRING language version\n\n\nTree2:\nEOF \n\n\nSubtree1: STRING language version\n\n\nSubtree2: EOF \n" + "'", str25.equals("Node tree inequality:\nTree1:\nSTRING language version\n\n\nTree2:\nEOF \n\n\nSubtree1: STRING language version\n\n\nSubtree2: EOF \n"));
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention0 = new com.google.javascript.jscomp.DefaultCodingConvention();
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        int int0 = com.google.javascript.rhino.Node.OBJECT_IDS_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + (-2) + "'", int0 == (-2));
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        com.google.javascript.rhino.EvaluatorException evaluatorException3 = new com.google.javascript.rhino.EvaluatorException("goog.abstractMethod", "Unknown class name", (int) (byte) 100);
        java.lang.String str4 = evaluatorException3.details();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "goog.abstractMethod" + "'", str4.equals("goog.abstractMethod"));
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        com.google.javascript.rhino.Context context0 = new com.google.javascript.rhino.Context();
        context0.addActivationName("goog.abstractMethod");
        boolean boolean3 = context0.hasCompileFunctionsWithDynamicScope();
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        try {
            context0.removePropertyChangeListener(propertyChangeListener4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        com.google.javascript.jscomp.SourceFile sourceFile1 = com.google.javascript.jscomp.SourceFile.fromFile("Not declared as a constructor");
        java.lang.String str2 = sourceFile1.getOriginalPath();
        org.junit.Assert.assertNotNull(sourceFile1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Not declared as a constructor" + "'", str2.equals("Not declared as a constructor"));
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString(22, "", 29, (int) (byte) 1);
        org.junit.Assert.assertNotNull(node4);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        com.google.javascript.jscomp.DiagnosticType diagnosticType0 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray2 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError3 = com.google.javascript.jscomp.JSError.make(diagnosticType0, strArray2);
        com.google.javascript.jscomp.DiagnosticType diagnosticType4 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        com.google.javascript.jscomp.DiagnosticType diagnosticType5 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray7 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError8 = com.google.javascript.jscomp.JSError.make(diagnosticType5, strArray7);
        com.google.javascript.jscomp.DiagnosticType[] diagnosticTypeArray9 = new com.google.javascript.jscomp.DiagnosticType[] { diagnosticType0, diagnosticType4, diagnosticType5 };
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup10 = new com.google.javascript.jscomp.DiagnosticGroup(diagnosticTypeArray9);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup11 = new com.google.javascript.jscomp.DiagnosticGroup(diagnosticTypeArray9);
        com.google.javascript.jscomp.DiagnosticGroups.INVALID_CASTS = diagnosticGroup11;
        org.junit.Assert.assertNotNull(diagnosticType0);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(jSError3);
        org.junit.Assert.assertNotNull(diagnosticType4);
        org.junit.Assert.assertNotNull(diagnosticType5);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertNotNull(jSError8);
        org.junit.Assert.assertNotNull(diagnosticTypeArray9);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        com.google.javascript.jscomp.ErrorFormat errorFormat0 = com.google.javascript.jscomp.ErrorFormat.SINGLELINE;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node[] nodeArray2 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList3 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean4 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList3, nodeArray2);
        com.google.javascript.jscomp.NodeTraversal.Callback callback5 = null;
        com.google.javascript.jscomp.NodeTraversal.traverseRoots((com.google.javascript.jscomp.AbstractCompiler) compiler1, (java.util.List<com.google.javascript.rhino.Node>) nodeList3, callback5);
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter7 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler1);
        com.google.javascript.jscomp.SourceMap sourceMap8 = compiler1.getSourceMap();
        com.google.javascript.jscomp.MessageFormatter messageFormatter10 = errorFormat0.toFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler1, false);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile12 = com.google.javascript.jscomp.JSSourceFile.fromFile("JSC_NODE_TRAVERSAL_ERROR.  at (unknown source) line (unknown line) : (unknown column)");
        java.nio.charset.Charset charset14 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile15 = com.google.javascript.jscomp.JSSourceFile.fromFile("JSC_NODE_TRAVERSAL_ERROR", charset14);
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray16 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile12, jSSourceFile15 };
        com.google.javascript.jscomp.JSModule jSModule17 = null;
        com.google.javascript.jscomp.JSModule[] jSModuleArray18 = new com.google.javascript.jscomp.JSModule[] { jSModule17 };
        com.google.javascript.jscomp.CompilerOptions compilerOptions19 = null;
        try {
            com.google.javascript.jscomp.Result result20 = compiler1.compile(jSSourceFileArray16, jSModuleArray18, compilerOptions19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(errorFormat0);
        org.junit.Assert.assertNotNull(nodeArray2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(sourceMap8);
        org.junit.Assert.assertNotNull(messageFormatter10);
        org.junit.Assert.assertNotNull(jSSourceFile12);
        org.junit.Assert.assertNotNull(jSSourceFile15);
        org.junit.Assert.assertNotNull(jSSourceFileArray16);
        org.junit.Assert.assertNotNull(jSModuleArray18);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        java.util.logging.Level level0 = null;
        com.google.javascript.jscomp.Compiler.setLoggingLevel(level0);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node[] nodeArray2 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList3 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean4 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList3, nodeArray2);
        com.google.javascript.jscomp.NodeTraversal.Callback callback5 = null;
        com.google.javascript.jscomp.NodeTraversal.traverseRoots((com.google.javascript.jscomp.AbstractCompiler) compiler1, (java.util.List<com.google.javascript.rhino.Node>) nodeList3, callback5);
        com.google.javascript.jscomp.NodeTraversal.Callback callback7 = null;
        com.google.javascript.jscomp.NodeTraversal.traverseRoots((com.google.javascript.jscomp.AbstractCompiler) compiler0, (java.util.List<com.google.javascript.rhino.Node>) nodeList3, callback7);
        try {
            com.google.javascript.jscomp.CompilerInput compilerInput10 = compiler0.newExternInput("Not declared as a constructor");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(nodeArray2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.FILEOVERVIEW_JSDOC;
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup1 = com.google.javascript.jscomp.DiagnosticGroups.CHECK_VARIABLES;
        com.google.javascript.jscomp.DiagnosticGroups.CONSTANT_PROPERTY = diagnosticGroup1;
        com.google.javascript.jscomp.DiagnosticGroup[] diagnosticGroupArray3 = new com.google.javascript.jscomp.DiagnosticGroup[] { diagnosticGroup0, diagnosticGroup1 };
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup4 = new com.google.javascript.jscomp.DiagnosticGroup(diagnosticGroupArray3);
        com.google.javascript.jscomp.DiagnosticGroups.DEPRECATED = diagnosticGroup4;
        com.google.javascript.jscomp.DiagnosticGroups.GLOBAL_THIS = diagnosticGroup4;
        com.google.javascript.jscomp.DiagnosticType diagnosticType7 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray9 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError10 = com.google.javascript.jscomp.JSError.make(diagnosticType7, strArray9);
        java.lang.String str11 = jSError10.toString();
        boolean boolean12 = diagnosticGroup4.matches(jSError10);
        java.lang.String str13 = jSError10.description;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
        org.junit.Assert.assertNotNull(diagnosticGroup1);
        org.junit.Assert.assertNotNull(diagnosticGroupArray3);
        org.junit.Assert.assertNotNull(diagnosticType7);
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertNotNull(jSError10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "JSC_NODE_TRAVERSAL_ERROR.  at (unknown source) line (unknown line) : (unknown column)" + "'", str11.equals("JSC_NODE_TRAVERSAL_ERROR.  at (unknown source) line (unknown line) : (unknown column)"));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.NON_STANDARD_JSDOC;
        org.junit.Assert.assertNull(diagnosticGroup0);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        com.google.javascript.rhino.EvaluatorException evaluatorException1 = new com.google.javascript.rhino.EvaluatorException("com.google.javascript.rhino.EvaluatorException: hi!");
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        com.google.javascript.jscomp.CompilerOptions.TweakProcessing tweakProcessing0 = com.google.javascript.jscomp.CompilerOptions.TweakProcessing.CHECK;
        boolean boolean1 = tweakProcessing0.shouldStrip();
        boolean boolean2 = tweakProcessing0.isOn();
        org.junit.Assert.assertTrue("'" + tweakProcessing0 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TweakProcessing.CHECK + "'", tweakProcessing0.equals(com.google.javascript.jscomp.CompilerOptions.TweakProcessing.CHECK));
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        java.util.logging.Logger logger0 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager1 = new com.google.javascript.jscomp.LoggerErrorManager(logger0);
        int int2 = loggerErrorManager1.getWarningCount();
        com.google.javascript.jscomp.JSError[] jSErrorArray3 = loggerErrorManager1.getWarnings();
        loggerErrorManager1.generateReport();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(jSErrorArray3);
    }

//    @Test
//    public void test438() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test438");
//        try {
//            java.lang.String str2 = com.google.javascript.rhino.ScriptRuntime.numberToString((double) (-1.0f), 0);
//            org.junit.Assert.fail("Expected exception of type com.google.javascript.rhino.EvaluatorException; message: illegal radix 0.");
//        } catch (com.google.javascript.rhino.EvaluatorException e) {
//        }
//    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile1 = com.google.javascript.jscomp.JSSourceFile.fromFile("error reporter");
        com.google.javascript.jscomp.JsAst jsAst2 = new com.google.javascript.jscomp.JsAst((com.google.javascript.jscomp.SourceFile) jSSourceFile1);
        com.google.javascript.jscomp.CompilerInput compilerInput4 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) jsAst2, false);
        com.google.javascript.jscomp.Compiler compiler5 = new com.google.javascript.jscomp.Compiler();
        compilerInput4.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler5);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile8 = com.google.javascript.jscomp.JSSourceFile.fromFile("error reporter");
        com.google.javascript.jscomp.JsAst jsAst9 = new com.google.javascript.jscomp.JsAst((com.google.javascript.jscomp.SourceFile) jSSourceFile8);
        com.google.javascript.jscomp.CompilerInput compilerInput11 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) jsAst9, false);
        com.google.javascript.jscomp.Compiler compiler12 = new com.google.javascript.jscomp.Compiler();
        compilerInput11.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler12);
        com.google.javascript.jscomp.Compiler compiler14 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node[] nodeArray15 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList16 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean17 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList16, nodeArray15);
        com.google.javascript.jscomp.NodeTraversal.Callback callback18 = null;
        com.google.javascript.jscomp.NodeTraversal.traverseRoots((com.google.javascript.jscomp.AbstractCompiler) compiler14, (java.util.List<com.google.javascript.rhino.Node>) nodeList16, callback18);
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter20 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler14);
        compilerInput11.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler14);
        java.util.logging.Logger logger22 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager23 = new com.google.javascript.jscomp.LoggerErrorManager(logger22);
        com.google.javascript.jscomp.JSError[] jSErrorArray24 = loggerErrorManager23.getErrors();
        compiler14.setErrorManager((com.google.javascript.jscomp.ErrorManager) loggerErrorManager23);
        compilerInput4.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler14);
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray27 = null;
        com.google.javascript.jscomp.Compiler compiler28 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node[] nodeArray29 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList30 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean31 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList30, nodeArray29);
        com.google.javascript.jscomp.NodeTraversal.Callback callback32 = null;
        com.google.javascript.jscomp.NodeTraversal.traverseRoots((com.google.javascript.jscomp.AbstractCompiler) compiler28, (java.util.List<com.google.javascript.rhino.Node>) nodeList30, callback32);
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter34 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler28);
        java.nio.charset.Charset charset36 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile37 = com.google.javascript.jscomp.JSSourceFile.fromFile("JSC_NODE_TRAVERSAL_ERROR", charset36);
        java.lang.String str38 = jSSourceFile37.getOriginalPath();
        com.google.javascript.rhino.Node node39 = compiler28.parse(jSSourceFile37);
        com.google.javascript.jscomp.JsAst jsAst40 = new com.google.javascript.jscomp.JsAst((com.google.javascript.jscomp.SourceFile) jSSourceFile37);
        com.google.javascript.jscomp.CompilerInput compilerInput42 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile37, false);
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray43 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile37 };
        com.google.javascript.jscomp.CompilerOptions compilerOptions44 = null;
        try {
            compiler14.init(jSSourceFileArray27, jSSourceFileArray43, compilerOptions44);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile1);
        org.junit.Assert.assertNotNull(jSSourceFile8);
        org.junit.Assert.assertNotNull(nodeArray15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(jSErrorArray24);
        org.junit.Assert.assertNotNull(nodeArray29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(jSSourceFile37);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "JSC_NODE_TRAVERSAL_ERROR" + "'", str38.equals("JSC_NODE_TRAVERSAL_ERROR"));
        org.junit.Assert.assertNull(node39);
        org.junit.Assert.assertNotNull(jSSourceFileArray43);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        try {
            com.google.javascript.rhino.Context.reportWarning("Unknown class name");
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: No Context associated with current Thread");
        } catch (java.lang.RuntimeException e) {
        }
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node[] nodeArray1 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList2 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean3 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList2, nodeArray1);
        com.google.javascript.jscomp.NodeTraversal.Callback callback4 = null;
        com.google.javascript.jscomp.NodeTraversal.traverseRoots((com.google.javascript.jscomp.AbstractCompiler) compiler0, (java.util.List<com.google.javascript.rhino.Node>) nodeList2, callback4);
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter6 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler0);
        com.google.javascript.jscomp.SourceMap sourceMap7 = compiler0.getSourceMap();
        com.google.javascript.jscomp.Compiler compiler8 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node[] nodeArray9 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList10 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean11 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList10, nodeArray9);
        com.google.javascript.jscomp.NodeTraversal.Callback callback12 = null;
        com.google.javascript.jscomp.NodeTraversal.traverseRoots((com.google.javascript.jscomp.AbstractCompiler) compiler8, (java.util.List<com.google.javascript.rhino.Node>) nodeList10, callback12);
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter14 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler8);
        java.nio.charset.Charset charset16 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile17 = com.google.javascript.jscomp.JSSourceFile.fromFile("JSC_NODE_TRAVERSAL_ERROR", charset16);
        java.lang.String str18 = jSSourceFile17.getOriginalPath();
        com.google.javascript.rhino.Node node19 = compiler8.parse(jSSourceFile17);
        com.google.javascript.jscomp.JsAst jsAst20 = new com.google.javascript.jscomp.JsAst((com.google.javascript.jscomp.SourceFile) jSSourceFile17);
        java.nio.charset.Charset charset22 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile23 = com.google.javascript.jscomp.JSSourceFile.fromFile("JSC_NODE_TRAVERSAL_ERROR", charset22);
        com.google.javascript.jscomp.JsAst jsAst24 = new com.google.javascript.jscomp.JsAst((com.google.javascript.jscomp.SourceFile) jSSourceFile23);
        com.google.javascript.jscomp.CompilerOptions compilerOptions25 = null;
        try {
            com.google.javascript.jscomp.Result result26 = compiler0.compile(jSSourceFile17, jSSourceFile23, compilerOptions25);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(nodeArray1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(sourceMap7);
        org.junit.Assert.assertNotNull(nodeArray9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(jSSourceFile17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "JSC_NODE_TRAVERSAL_ERROR" + "'", str18.equals("JSC_NODE_TRAVERSAL_ERROR"));
        org.junit.Assert.assertNull(node19);
        org.junit.Assert.assertNotNull(jSSourceFile23);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        com.google.javascript.rhino.Context context0 = new com.google.javascript.rhino.Context();
        context0.addActivationName("goog.abstractMethod");
        boolean boolean3 = context0.hasCompileFunctionsWithDynamicScope();
        int int4 = context0.getLanguageVersion();
        int int5 = context0.getOptimizationLevel();
        context0.removeActivationName("language version");
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.UNDEFINED_VARIABLES;
        java.lang.Class<?> wildcardClass1 = diagnosticGroup0.getClass();
        com.google.javascript.jscomp.DiagnosticGroups.AMBIGUOUS_FUNCTION_DECL = diagnosticGroup0;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
        org.junit.Assert.assertNotNull(wildcardClass1);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        java.lang.String str1 = closureCodingConvention0.getExportPropertyFunction();
        boolean boolean3 = closureCodingConvention0.isPrivate("");
        boolean boolean5 = closureCodingConvention0.isPrivate("hi!");
        java.lang.String str6 = closureCodingConvention0.getDelegateSuperclassName();
        com.google.javascript.jscomp.AbstractCompiler abstractCompiler7 = null;
        com.google.javascript.jscomp.NodeTraversal.Callback callback8 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal9 = new com.google.javascript.jscomp.NodeTraversal(abstractCompiler7, callback8);
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.Node.newNumber((double) 1L, 0, 1);
        com.google.javascript.rhino.Node node15 = new com.google.javascript.rhino.Node(42, node14);
        com.google.javascript.rhino.Node node16 = node15.cloneTree();
        try {
            com.google.javascript.jscomp.CodingConvention.ObjectLiteralCast objectLiteralCast17 = closureCodingConvention0.getObjectLiteralCast(nodeTraversal9, node15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "goog.exportProperty" + "'", str1.equals("goog.exportProperty"));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNotNull(node16);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile1 = com.google.javascript.jscomp.JSSourceFile.fromFile("error reporter");
        com.google.javascript.jscomp.JsAst jsAst2 = new com.google.javascript.jscomp.JsAst((com.google.javascript.jscomp.SourceFile) jSSourceFile1);
        com.google.javascript.jscomp.CompilerInput compilerInput4 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) jsAst2, false);
        com.google.javascript.jscomp.Compiler compiler5 = new com.google.javascript.jscomp.Compiler();
        compilerInput4.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler5);
        com.google.javascript.jscomp.DiagnosticType diagnosticType7 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray9 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError10 = com.google.javascript.jscomp.JSError.make(diagnosticType7, strArray9);
        com.google.javascript.jscomp.DiagnosticType diagnosticType11 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray13 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError14 = com.google.javascript.jscomp.JSError.make(diagnosticType11, strArray13);
        com.google.javascript.jscomp.JSError jSError15 = com.google.javascript.jscomp.JSError.make(diagnosticType7, strArray13);
        com.google.javascript.jscomp.CheckLevel checkLevel16 = compiler5.getErrorLevel(jSError15);
        com.google.javascript.jscomp.PerformanceTracker performanceTracker17 = null;
        compiler5.tracker = performanceTracker17;
        com.google.javascript.jscomp.ErrorManager errorManager19 = compiler5.getErrorManager();
        org.junit.Assert.assertNotNull(jSSourceFile1);
        org.junit.Assert.assertNotNull(diagnosticType7);
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertNotNull(jSError10);
        org.junit.Assert.assertNotNull(diagnosticType11);
        org.junit.Assert.assertNotNull(strArray13);
        org.junit.Assert.assertNotNull(jSError14);
        org.junit.Assert.assertNotNull(jSError15);
        org.junit.Assert.assertNull(checkLevel16);
        org.junit.Assert.assertNotNull(errorManager19);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        com.google.javascript.jscomp.SourceMap.DetailLevel detailLevel1 = com.google.javascript.jscomp.SourceMap.DetailLevel.SYMBOLS;
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString((int) (short) 0, "");
        node4.setVarArgs(true);
        boolean boolean7 = detailLevel1.apply(node4);
        boolean boolean8 = node4.isVarArgs();
        com.google.javascript.rhino.JSDocInfo jSDocInfo9 = null;
        node4.setJSDocInfo(jSDocInfo9);
        com.google.javascript.jscomp.SourceMap.DetailLevel detailLevel12 = com.google.javascript.jscomp.SourceMap.DetailLevel.SYMBOLS;
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.Node.newString((int) (short) 0, "");
        node15.setVarArgs(true);
        boolean boolean18 = detailLevel12.apply(node15);
        boolean boolean19 = node15.isVarArgs();
        com.google.javascript.jscomp.SourceMap.DetailLevel detailLevel20 = com.google.javascript.jscomp.SourceMap.DetailLevel.SYMBOLS;
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newString((int) (short) 0, "");
        node23.setVarArgs(true);
        boolean boolean26 = detailLevel20.apply(node23);
        boolean boolean27 = node23.isVarArgs();
        com.google.javascript.rhino.Node node30 = new com.google.javascript.rhino.Node(0, node15, node23, 36, 140);
        com.google.javascript.rhino.Node node32 = new com.google.javascript.rhino.Node((int) (short) 10);
        java.lang.Object obj34 = node32.getProp((int) (short) 1);
        try {
            com.google.javascript.rhino.Node node37 = new com.google.javascript.rhino.Node((int) (short) 10, node4, node23, node32, 34, 32);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(detailLevel1);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(detailLevel12);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(detailLevel20);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertNull(obj34);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        int int0 = com.google.javascript.rhino.Context.FEATURE_E4X;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 6 + "'", int0 == 6);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile1 = com.google.javascript.jscomp.JSSourceFile.fromFile("error reporter");
        com.google.javascript.jscomp.JsAst jsAst2 = new com.google.javascript.jscomp.JsAst((com.google.javascript.jscomp.SourceFile) jSSourceFile1);
        com.google.javascript.jscomp.CompilerInput compilerInput4 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) jsAst2, false);
        boolean boolean5 = compilerInput4.isExtern();
        boolean boolean6 = compilerInput4.isExtern();
        com.google.javascript.jscomp.SourceAst sourceAst7 = compilerInput4.getSourceAst();
        java.nio.charset.Charset charset9 = null;
        com.google.javascript.jscomp.SourceFile sourceFile10 = com.google.javascript.jscomp.SourceFile.fromFile("Unknown class name", charset9);
        try {
            compilerInput4.setSourceFile(sourceFile10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(sourceAst7);
        org.junit.Assert.assertNotNull(sourceFile10);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node[] nodeArray1 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList2 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean3 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList2, nodeArray1);
        com.google.javascript.jscomp.NodeTraversal.Callback callback4 = null;
        com.google.javascript.jscomp.NodeTraversal.traverseRoots((com.google.javascript.jscomp.AbstractCompiler) compiler0, (java.util.List<com.google.javascript.rhino.Node>) nodeList2, callback4);
        com.google.javascript.jscomp.PerformanceTracker performanceTracker6 = compiler0.tracker;
        com.google.javascript.jscomp.SourceExcerptProvider.SourceExcerpt sourceExcerpt7 = null;
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter8 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler0, sourceExcerpt7);
        com.google.javascript.jscomp.Compiler.IntermediateState intermediateState9 = compiler0.getState();
        com.google.javascript.jscomp.Compiler.IntermediateState intermediateState10 = compiler0.getState();
        com.google.javascript.jscomp.ErrorManager errorManager11 = compiler0.getErrorManager();
        java.io.PrintStream printStream12 = null;
        com.google.javascript.jscomp.Compiler compiler13 = new com.google.javascript.jscomp.Compiler(printStream12);
        com.google.javascript.jscomp.Compiler.IntermediateState intermediateState14 = compiler13.getState();
        com.google.javascript.jscomp.Compiler compiler15 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node[] nodeArray16 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList17 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean18 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList17, nodeArray16);
        com.google.javascript.jscomp.NodeTraversal.Callback callback19 = null;
        com.google.javascript.jscomp.NodeTraversal.traverseRoots((com.google.javascript.jscomp.AbstractCompiler) compiler15, (java.util.List<com.google.javascript.rhino.Node>) nodeList17, callback19);
        com.google.javascript.jscomp.PerformanceTracker performanceTracker21 = compiler15.tracker;
        com.google.javascript.jscomp.SourceExcerptProvider.SourceExcerpt sourceExcerpt22 = null;
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter23 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler15, sourceExcerpt22);
        java.util.logging.Logger logger24 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager25 = new com.google.javascript.jscomp.LoggerErrorManager((com.google.javascript.jscomp.MessageFormatter) lightweightMessageFormatter23, logger24);
        compiler13.setErrorManager((com.google.javascript.jscomp.ErrorManager) loggerErrorManager25);
        compiler0.setErrorManager((com.google.javascript.jscomp.ErrorManager) loggerErrorManager25);
        try {
            compiler0.processDefines();
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: INTERNAL COMPILER ERROR.\nPlease report this problem.\nnull");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(nodeArray1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(performanceTracker6);
        org.junit.Assert.assertNotNull(intermediateState9);
        org.junit.Assert.assertNotNull(intermediateState10);
        org.junit.Assert.assertNotNull(errorManager11);
        org.junit.Assert.assertNotNull(intermediateState14);
        org.junit.Assert.assertNotNull(nodeArray16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNull(performanceTracker21);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node1 = null;
        boolean boolean2 = closureCodingConvention0.isVarArgsParameter(node1);
        com.google.javascript.rhino.jstype.ObjectType objectType3 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType4 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType5 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType6 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType7 = null;
        closureCodingConvention0.applyDelegateRelationship(objectType3, objectType4, objectType5, functionType6, functionType7);
        com.google.javascript.rhino.jstype.FunctionType functionType9 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType10 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType11 = null;
        closureCodingConvention0.applySubclassRelationship(functionType9, functionType10, subclassType11);
        java.lang.String str13 = closureCodingConvention0.getExportSymbolFunction();
        com.google.javascript.jscomp.AbstractCompiler abstractCompiler14 = null;
        com.google.javascript.jscomp.NodeTraversal.Callback callback15 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal16 = new com.google.javascript.jscomp.NodeTraversal(abstractCompiler14, callback15);
        com.google.javascript.jscomp.Compiler compiler17 = nodeTraversal16.getCompiler();
        com.google.javascript.rhino.Node node18 = nodeTraversal16.getEnclosingFunction();
        com.google.javascript.rhino.Node node21 = new com.google.javascript.rhino.Node((int) (short) 10);
        java.lang.Object obj23 = node21.getProp((int) (short) 1);
        boolean boolean24 = node21.hasMoreThanOneChild();
        com.google.javascript.rhino.Node node26 = new com.google.javascript.rhino.Node((int) (short) 10);
        java.lang.Object obj28 = node26.getProp((int) (short) 1);
        com.google.javascript.rhino.Node node31 = com.google.javascript.rhino.Node.newString((int) (short) 0, "");
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable32 = node31.siblings();
        com.google.javascript.rhino.Node node33 = new com.google.javascript.rhino.Node((-1), node21, node26, node31);
        node21.detachChildren();
        com.google.javascript.rhino.Node node36 = com.google.javascript.rhino.Node.newString("language version");
        int int37 = node36.getLineno();
        com.google.javascript.rhino.Node node40 = com.google.javascript.rhino.Node.newString((int) (short) 0, "");
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable41 = node40.siblings();
        boolean boolean42 = node40.isNoSideEffectsCall();
        java.lang.String str43 = node36.checkTreeEquals(node40);
        java.lang.String str44 = node21.checkTreeEquals(node40);
        try {
            com.google.javascript.jscomp.CodingConvention.ObjectLiteralCast objectLiteralCast45 = closureCodingConvention0.getObjectLiteralCast(nodeTraversal16, node40);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "goog.exportSymbol" + "'", str13.equals("goog.exportSymbol"));
        org.junit.Assert.assertNull(compiler17);
        org.junit.Assert.assertNull(node18);
        org.junit.Assert.assertNull(obj23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNull(obj28);
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertNotNull(nodeIterable32);
        org.junit.Assert.assertNotNull(node36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + (-1) + "'", int37 == (-1));
        org.junit.Assert.assertNotNull(node40);
        org.junit.Assert.assertNotNull(nodeIterable41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "Node tree inequality:\nTree1:\nSTRING language version\n\n\nTree2:\nEOF \n\n\nSubtree1: STRING language version\n\n\nSubtree2: EOF \n" + "'", str43.equals("Node tree inequality:\nTree1:\nSTRING language version\n\n\nTree2:\nEOF \n\n\nSubtree1: STRING language version\n\n\nSubtree2: EOF \n"));
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "Node tree inequality:\nTree1:\nBITXOR\n\n\nTree2:\nEOF \n\n\nSubtree1: BITXOR\n\n\nSubtree2: EOF \n" + "'", str44.equals("Node tree inequality:\nTree1:\nBITXOR\n\n\nTree2:\nEOF \n\n\nSubtree1: BITXOR\n\n\nSubtree2: EOF \n"));
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString(26, "error reporter", (int) (short) 100, 3);
        node4.setString("BITXOR");
        org.junit.Assert.assertNotNull(node4);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        java.lang.Object[] objArray0 = com.google.javascript.rhino.ScriptRuntime.emptyArgs;
        org.junit.Assert.assertNotNull(objArray0);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        java.lang.String str1 = com.google.javascript.rhino.ScriptRuntime.escapeString("com.google.javascript.rhino.EcmaError: BITXOR: goog.exportProperty (#150)");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "com.google.javascript.rhino.EcmaError: BITXOR: goog.exportProperty (#150)" + "'", str1.equals("com.google.javascript.rhino.EcmaError: BITXOR: goog.exportProperty (#150)"));
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node[] nodeArray1 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList2 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean3 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList2, nodeArray1);
        com.google.javascript.jscomp.NodeTraversal.Callback callback4 = null;
        com.google.javascript.jscomp.NodeTraversal.traverseRoots((com.google.javascript.jscomp.AbstractCompiler) compiler0, (java.util.List<com.google.javascript.rhino.Node>) nodeList2, callback4);
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter6 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler0);
        compiler0.reportCodeChange();
        com.google.javascript.jscomp.Compiler compiler8 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node[] nodeArray9 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList10 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean11 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList10, nodeArray9);
        com.google.javascript.jscomp.NodeTraversal.Callback callback12 = null;
        com.google.javascript.jscomp.NodeTraversal.traverseRoots((com.google.javascript.jscomp.AbstractCompiler) compiler8, (java.util.List<com.google.javascript.rhino.Node>) nodeList10, callback12);
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter14 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler8);
        java.nio.charset.Charset charset16 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile17 = com.google.javascript.jscomp.JSSourceFile.fromFile("JSC_NODE_TRAVERSAL_ERROR", charset16);
        java.lang.String str18 = jSSourceFile17.getOriginalPath();
        com.google.javascript.rhino.Node node19 = compiler8.parse(jSSourceFile17);
        com.google.javascript.jscomp.JsAst jsAst20 = new com.google.javascript.jscomp.JsAst((com.google.javascript.jscomp.SourceFile) jSSourceFile17);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile22 = com.google.javascript.jscomp.JSSourceFile.fromFile("error reporter");
        com.google.javascript.jscomp.JsAst jsAst23 = new com.google.javascript.jscomp.JsAst((com.google.javascript.jscomp.SourceFile) jSSourceFile22);
        java.nio.charset.Charset charset25 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile26 = com.google.javascript.jscomp.JSSourceFile.fromFile("<No stack trace available>", charset25);
        jSSourceFile26.clearCachedSource();
        java.nio.charset.Charset charset29 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile30 = com.google.javascript.jscomp.JSSourceFile.fromFile("(JSC_NODE_TRAVERSAL_ERROR.  at (unknown source) line (unknown line) : (unknown column))", charset29);
        java.nio.charset.Charset charset32 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile33 = com.google.javascript.jscomp.JSSourceFile.fromFile("JSC_NODE_TRAVERSAL_ERROR", charset32);
        java.lang.String str34 = jSSourceFile33.getOriginalPath();
        java.lang.String str35 = jSSourceFile33.toString();
        java.nio.charset.Charset charset37 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile38 = com.google.javascript.jscomp.JSSourceFile.fromFile("JSC_NODE_TRAVERSAL_ERROR", charset37);
        com.google.javascript.jscomp.JsAst jsAst39 = new com.google.javascript.jscomp.JsAst((com.google.javascript.jscomp.SourceFile) jSSourceFile38);
        com.google.javascript.jscomp.Compiler compiler40 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node[] nodeArray41 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList42 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean43 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList42, nodeArray41);
        com.google.javascript.jscomp.NodeTraversal.Callback callback44 = null;
        com.google.javascript.jscomp.NodeTraversal.traverseRoots((com.google.javascript.jscomp.AbstractCompiler) compiler40, (java.util.List<com.google.javascript.rhino.Node>) nodeList42, callback44);
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter46 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler40);
        java.nio.charset.Charset charset48 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile49 = com.google.javascript.jscomp.JSSourceFile.fromFile("JSC_NODE_TRAVERSAL_ERROR", charset48);
        java.lang.String str50 = jSSourceFile49.getOriginalPath();
        com.google.javascript.rhino.Node node51 = compiler40.parse(jSSourceFile49);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile53 = com.google.javascript.jscomp.JSSourceFile.fromFile("error reporter");
        java.nio.charset.Charset charset55 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile56 = com.google.javascript.jscomp.JSSourceFile.fromFile("<No stack trace available>", charset55);
        jSSourceFile56.clearCachedSource();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile59 = com.google.javascript.jscomp.JSSourceFile.fromFile("error reporter");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile61 = com.google.javascript.jscomp.JSSourceFile.fromFile("error reporter");
        java.nio.charset.Charset charset63 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile64 = com.google.javascript.jscomp.JSSourceFile.fromFile("(JSC_NODE_TRAVERSAL_ERROR.  at (unknown source) line (unknown line) : (unknown column))", charset63);
        java.nio.charset.Charset charset66 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile67 = com.google.javascript.jscomp.JSSourceFile.fromFile("<No stack trace available>", charset66);
        jSSourceFile67.clearCachedSource();
        java.nio.charset.Charset charset70 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile71 = com.google.javascript.jscomp.JSSourceFile.fromFile("JSC_NODE_TRAVERSAL_ERROR", charset70);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile74 = com.google.javascript.jscomp.JSSourceFile.fromFile("error reporter");
        com.google.javascript.jscomp.JsAst jsAst75 = new com.google.javascript.jscomp.JsAst((com.google.javascript.jscomp.SourceFile) jSSourceFile74);
        java.lang.RuntimeException runtimeException76 = com.google.javascript.rhino.ScriptRuntime.undefCallError((java.lang.Object) 1.0d, (java.lang.Object) jSSourceFile74);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile78 = com.google.javascript.jscomp.JSSourceFile.fromFile("error reporter");
        java.nio.charset.Charset charset80 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile81 = com.google.javascript.jscomp.JSSourceFile.fromFile("JSC_NODE_TRAVERSAL_ERROR", charset80);
        com.google.javascript.jscomp.JsAst jsAst82 = new com.google.javascript.jscomp.JsAst((com.google.javascript.jscomp.SourceFile) jSSourceFile81);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile84 = com.google.javascript.jscomp.JSSourceFile.fromFile("error reporter");
        com.google.javascript.jscomp.JsAst jsAst85 = new com.google.javascript.jscomp.JsAst((com.google.javascript.jscomp.SourceFile) jSSourceFile84);
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray86 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile17, jSSourceFile22, jSSourceFile26, jSSourceFile30, jSSourceFile33, jSSourceFile38, jSSourceFile49, jSSourceFile53, jSSourceFile56, jSSourceFile59, jSSourceFile61, jSSourceFile64, jSSourceFile67, jSSourceFile71, jSSourceFile74, jSSourceFile78, jSSourceFile81, jSSourceFile84 };
        java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList87 = new java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile>();
        boolean boolean88 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList87, jSSourceFileArray86);
        com.google.javascript.jscomp.JSModule[] jSModuleArray89 = new com.google.javascript.jscomp.JSModule[] {};
        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList90 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
        boolean boolean91 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList90, jSModuleArray89);
        com.google.javascript.jscomp.CompilerOptions compilerOptions92 = null;
        try {
            compiler0.initModules((java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList87, (java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList90, compilerOptions92);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(nodeArray1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(nodeArray9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(jSSourceFile17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "JSC_NODE_TRAVERSAL_ERROR" + "'", str18.equals("JSC_NODE_TRAVERSAL_ERROR"));
        org.junit.Assert.assertNull(node19);
        org.junit.Assert.assertNotNull(jSSourceFile22);
        org.junit.Assert.assertNotNull(jSSourceFile26);
        org.junit.Assert.assertNotNull(jSSourceFile30);
        org.junit.Assert.assertNotNull(jSSourceFile33);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "JSC_NODE_TRAVERSAL_ERROR" + "'", str34.equals("JSC_NODE_TRAVERSAL_ERROR"));
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "JSC_NODE_TRAVERSAL_ERROR" + "'", str35.equals("JSC_NODE_TRAVERSAL_ERROR"));
        org.junit.Assert.assertNotNull(jSSourceFile38);
        org.junit.Assert.assertNotNull(nodeArray41);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(jSSourceFile49);
        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "JSC_NODE_TRAVERSAL_ERROR" + "'", str50.equals("JSC_NODE_TRAVERSAL_ERROR"));
        org.junit.Assert.assertNull(node51);
        org.junit.Assert.assertNotNull(jSSourceFile53);
        org.junit.Assert.assertNotNull(jSSourceFile56);
        org.junit.Assert.assertNotNull(jSSourceFile59);
        org.junit.Assert.assertNotNull(jSSourceFile61);
        org.junit.Assert.assertNotNull(jSSourceFile64);
        org.junit.Assert.assertNotNull(jSSourceFile67);
        org.junit.Assert.assertNotNull(jSSourceFile71);
        org.junit.Assert.assertNotNull(jSSourceFile74);
        org.junit.Assert.assertNotNull(runtimeException76);
        org.junit.Assert.assertNotNull(jSSourceFile78);
        org.junit.Assert.assertNotNull(jSSourceFile81);
        org.junit.Assert.assertNotNull(jSSourceFile84);
        org.junit.Assert.assertNotNull(jSSourceFileArray86);
        org.junit.Assert.assertTrue("'" + boolean88 + "' != '" + true + "'", boolean88 == true);
        org.junit.Assert.assertNotNull(jSModuleArray89);
        org.junit.Assert.assertTrue("'" + boolean91 + "' != '" + false + "'", boolean91 == false);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        java.lang.String str1 = closureCodingConvention0.getExportPropertyFunction();
        boolean boolean3 = closureCodingConvention0.isPrivate("");
        boolean boolean5 = closureCodingConvention0.isPrivate("hi!");
        com.google.javascript.rhino.Node node8 = new com.google.javascript.rhino.Node((int) (short) 10);
        java.lang.Object obj10 = node8.getProp((int) (short) 1);
        boolean boolean11 = node8.hasMoreThanOneChild();
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node((int) (short) 10);
        java.lang.Object obj15 = node13.getProp((int) (short) 1);
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.Node.newString((int) (short) 0, "");
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable19 = node18.siblings();
        com.google.javascript.rhino.Node node20 = new com.google.javascript.rhino.Node((-1), node8, node13, node18);
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention21 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node22 = null;
        boolean boolean23 = closureCodingConvention21.isVarArgsParameter(node22);
        com.google.javascript.rhino.jstype.ObjectType objectType24 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType25 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType26 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType27 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType28 = null;
        closureCodingConvention21.applyDelegateRelationship(objectType24, objectType25, objectType26, functionType27, functionType28);
        com.google.javascript.rhino.jstype.FunctionType functionType30 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType31 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType32 = null;
        closureCodingConvention21.applySubclassRelationship(functionType30, functionType31, subclassType32);
        boolean boolean35 = closureCodingConvention21.isValidEnumKey("hi!");
        com.google.javascript.rhino.Node node37 = new com.google.javascript.rhino.Node((int) (short) 10);
        java.lang.Object obj39 = node37.getProp((int) (short) 1);
        com.google.javascript.rhino.Node node42 = new com.google.javascript.rhino.Node((int) (short) 10);
        java.lang.Object obj44 = node42.getProp((int) (short) 1);
        boolean boolean45 = node42.hasMoreThanOneChild();
        com.google.javascript.rhino.Node node47 = new com.google.javascript.rhino.Node((int) (short) 10);
        java.lang.Object obj49 = node47.getProp((int) (short) 1);
        com.google.javascript.rhino.Node node52 = com.google.javascript.rhino.Node.newString((int) (short) 0, "");
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable53 = node52.siblings();
        com.google.javascript.rhino.Node node54 = new com.google.javascript.rhino.Node((-1), node42, node47, node52);
        boolean boolean55 = node52.wasEmptyNode();
        java.lang.String str56 = closureCodingConvention21.extractClassNameIfProvide(node37, node52);
        com.google.javascript.rhino.Node node57 = node8.copyInformationFromForTree(node37);
        boolean boolean58 = closureCodingConvention0.isOptionalParameter(node37);
        com.google.javascript.rhino.jstype.FunctionType functionType59 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType60 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType61 = null;
        closureCodingConvention0.applySubclassRelationship(functionType59, functionType60, subclassType61);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "goog.exportProperty" + "'", str1.equals("goog.exportProperty"));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(obj10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNull(obj15);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNotNull(nodeIterable19);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertNull(obj39);
        org.junit.Assert.assertNull(obj44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNull(obj49);
        org.junit.Assert.assertNotNull(node52);
        org.junit.Assert.assertNotNull(nodeIterable53);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNull(str56);
        org.junit.Assert.assertNotNull(node57);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        com.google.javascript.jscomp.ErrorFormat errorFormat0 = com.google.javascript.jscomp.ErrorFormat.SINGLELINE;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node[] nodeArray2 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList3 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean4 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList3, nodeArray2);
        com.google.javascript.jscomp.NodeTraversal.Callback callback5 = null;
        com.google.javascript.jscomp.NodeTraversal.traverseRoots((com.google.javascript.jscomp.AbstractCompiler) compiler1, (java.util.List<com.google.javascript.rhino.Node>) nodeList3, callback5);
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter7 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler1);
        com.google.javascript.jscomp.SourceMap sourceMap8 = compiler1.getSourceMap();
        com.google.javascript.jscomp.MessageFormatter messageFormatter10 = errorFormat0.toFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler1, false);
        try {
            compiler1.parse();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(errorFormat0);
        org.junit.Assert.assertNotNull(nodeArray2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(sourceMap8);
        org.junit.Assert.assertNotNull(messageFormatter10);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        com.google.javascript.jscomp.DiagnosticType diagnosticType0 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray2 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError3 = com.google.javascript.jscomp.JSError.make(diagnosticType0, strArray2);
        com.google.javascript.jscomp.DiagnosticType diagnosticType4 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        com.google.javascript.jscomp.DiagnosticType diagnosticType5 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray7 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError8 = com.google.javascript.jscomp.JSError.make(diagnosticType5, strArray7);
        com.google.javascript.jscomp.DiagnosticType[] diagnosticTypeArray9 = new com.google.javascript.jscomp.DiagnosticType[] { diagnosticType0, diagnosticType4, diagnosticType5 };
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup10 = new com.google.javascript.jscomp.DiagnosticGroup(diagnosticTypeArray9);
        com.google.javascript.jscomp.DiagnosticType diagnosticType11 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray13 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError14 = com.google.javascript.jscomp.JSError.make(diagnosticType11, strArray13);
        java.lang.Class<?> wildcardClass15 = diagnosticType11.getClass();
        com.google.javascript.jscomp.DiagnosticType diagnosticType18 = com.google.javascript.jscomp.DiagnosticType.warning("", "");
        com.google.javascript.jscomp.CheckLevel checkLevel19 = diagnosticType18.level;
        diagnosticType11.level = checkLevel19;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard21 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup10, checkLevel19);
        java.lang.String str22 = diagnosticGroupWarningsGuard21.toString();
        java.lang.String str23 = diagnosticGroupWarningsGuard21.toString();
        org.junit.Assert.assertNotNull(diagnosticType0);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(jSError3);
        org.junit.Assert.assertNotNull(diagnosticType4);
        org.junit.Assert.assertNotNull(diagnosticType5);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertNotNull(jSError8);
        org.junit.Assert.assertNotNull(diagnosticTypeArray9);
        org.junit.Assert.assertNotNull(diagnosticType11);
        org.junit.Assert.assertNotNull(strArray13);
        org.junit.Assert.assertNotNull(jSError14);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(diagnosticType18);
        org.junit.Assert.assertTrue("'" + checkLevel19 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel19.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newNumber((double) 7);
        org.junit.Assert.assertNotNull(node1);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        try {
            com.google.javascript.rhino.Context.reportWarning("", "goog.exportProperty", (-2), "BITXOR", 160);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: No Context associated with current Thread");
        } catch (java.lang.RuntimeException e) {
        }
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        com.google.javascript.jscomp.DiagnosticType diagnosticType0 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray2 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError3 = com.google.javascript.jscomp.JSError.make(diagnosticType0, strArray2);
        com.google.javascript.jscomp.CheckLevel checkLevel4 = diagnosticType0.level;
        java.lang.String str5 = diagnosticType0.toString();
        java.lang.String str6 = diagnosticType0.toString();
        java.lang.RuntimeException runtimeException7 = com.google.javascript.rhino.ScriptRuntime.notFunctionError((java.lang.Object) diagnosticType0);
        org.junit.Assert.assertNotNull(diagnosticType0);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(jSError3);
        org.junit.Assert.assertTrue("'" + checkLevel4 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel4.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "JSC_NODE_TRAVERSAL_ERROR: {0}" + "'", str5.equals("JSC_NODE_TRAVERSAL_ERROR: {0}"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "JSC_NODE_TRAVERSAL_ERROR: {0}" + "'", str6.equals("JSC_NODE_TRAVERSAL_ERROR: {0}"));
        org.junit.Assert.assertNotNull(runtimeException7);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node1 = null;
        boolean boolean2 = closureCodingConvention0.isVarArgsParameter(node1);
        com.google.javascript.rhino.jstype.ObjectType objectType3 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType4 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType5 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType6 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType7 = null;
        closureCodingConvention0.applyDelegateRelationship(objectType3, objectType4, objectType5, functionType6, functionType7);
        com.google.javascript.rhino.jstype.FunctionType functionType9 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType10 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType11 = null;
        closureCodingConvention0.applySubclassRelationship(functionType9, functionType10, subclassType11);
        java.lang.String str13 = closureCodingConvention0.getExportSymbolFunction();
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.Node.newString("language version");
        int int16 = node15.getLineno();
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.Node.newString((int) (short) 0, "");
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable20 = node19.siblings();
        boolean boolean21 = node19.isNoSideEffectsCall();
        java.lang.String str22 = node15.checkTreeEquals(node19);
        node15.setIsSyntheticBlock(true);
        com.google.javascript.rhino.Node node25 = node15.removeFirstChild();
        try {
            boolean boolean26 = closureCodingConvention0.isPropertyTestFunction(node25);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "goog.exportSymbol" + "'", str13.equals("goog.exportSymbol"));
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNotNull(nodeIterable20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "Node tree inequality:\nTree1:\nSTRING language version\n\n\nTree2:\nEOF \n\n\nSubtree1: STRING language version\n\n\nSubtree2: EOF \n" + "'", str22.equals("Node tree inequality:\nTree1:\nSTRING language version\n\n\nTree2:\nEOF \n\n\nSubtree1: STRING language version\n\n\nSubtree2: EOF \n"));
        org.junit.Assert.assertNull(node25);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        com.google.javascript.jscomp.DiagnosticType[] diagnosticTypeArray0 = null;
        try {
            com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup1 = new com.google.javascript.jscomp.DiagnosticGroup(diagnosticTypeArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromCode("JSC_NODE_TRAVERSAL_ERROR", "com.google.javascript.rhino.EvaluatorException: hi!");
        org.junit.Assert.assertNotNull(sourceFile2);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        com.google.javascript.rhino.Node.SideEffectFlags sideEffectFlags1 = new com.google.javascript.rhino.Node.SideEffectFlags(35);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node[] nodeArray2 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList3 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean4 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList3, nodeArray2);
        com.google.javascript.jscomp.NodeTraversal.Callback callback5 = null;
        com.google.javascript.jscomp.NodeTraversal.traverseRoots((com.google.javascript.jscomp.AbstractCompiler) compiler1, (java.util.List<com.google.javascript.rhino.Node>) nodeList3, callback5);
        com.google.javascript.jscomp.NodeTraversal.Callback callback7 = null;
        com.google.javascript.jscomp.NodeTraversal.traverseRoots((com.google.javascript.jscomp.AbstractCompiler) compiler0, (java.util.List<com.google.javascript.rhino.Node>) nodeList3, callback7);
        try {
            com.google.javascript.jscomp.JSError[] jSErrorArray9 = compiler0.getWarnings();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(nodeArray2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

//    @Test
//    public void test466() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test466");
//        try {
//            com.google.javascript.rhino.EvaluatorException evaluatorException5 = com.google.javascript.rhino.Context.reportRuntimeError("goog.abstractMethod", "eof", 0, "hi!", 32);
//            org.junit.Assert.fail("Expected exception of type com.google.javascript.rhino.EvaluatorException; message: goog.abstractMethod");
//        } catch (com.google.javascript.rhino.EvaluatorException e) {
//        }
//    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        java.util.logging.Logger logger0 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager1 = new com.google.javascript.jscomp.LoggerErrorManager(logger0);
        int int2 = loggerErrorManager1.getWarningCount();
        com.google.javascript.jscomp.DiagnosticType diagnosticType6 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        com.google.javascript.jscomp.CheckLevel checkLevel7 = diagnosticType6.defaultLevel;
        com.google.javascript.jscomp.DiagnosticType diagnosticType8 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray10 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError11 = com.google.javascript.jscomp.JSError.make(diagnosticType8, strArray10);
        com.google.javascript.jscomp.DiagnosticType diagnosticType12 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray14 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError15 = com.google.javascript.jscomp.JSError.make(diagnosticType12, strArray14);
        com.google.javascript.jscomp.JSError jSError16 = com.google.javascript.jscomp.JSError.make(diagnosticType8, strArray14);
        com.google.javascript.jscomp.JSError jSError17 = com.google.javascript.jscomp.JSError.make("JSC_NODE_TRAVERSAL_ERROR.  at (unknown source) line 32 : (unknown column)", 0, 32, diagnosticType6, strArray14);
        com.google.javascript.jscomp.CheckLevel checkLevel18 = jSError17.level;
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention19 = new com.google.javascript.jscomp.ClosureCodingConvention();
        java.lang.String str20 = closureCodingConvention19.getExportPropertyFunction();
        boolean boolean22 = closureCodingConvention19.isPrivate("");
        boolean boolean24 = closureCodingConvention19.isPrivate("hi!");
        java.lang.String str25 = closureCodingConvention19.getDelegateSuperclassName();
        com.google.javascript.rhino.Node node28 = new com.google.javascript.rhino.Node((int) (short) 10);
        java.lang.Object obj30 = node28.getProp((int) (short) 1);
        boolean boolean31 = node28.hasMoreThanOneChild();
        com.google.javascript.rhino.Node node33 = new com.google.javascript.rhino.Node((int) (short) 10);
        java.lang.Object obj35 = node33.getProp((int) (short) 1);
        com.google.javascript.rhino.Node node38 = com.google.javascript.rhino.Node.newString((int) (short) 0, "");
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable39 = node38.siblings();
        com.google.javascript.rhino.Node node40 = new com.google.javascript.rhino.Node((-1), node28, node33, node38);
        boolean boolean41 = closureCodingConvention19.isVarArgsParameter(node28);
        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray43 = new com.google.javascript.jscomp.WarningsGuard[] {};
        java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard> warningsGuardList44 = new java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard>();
        boolean boolean45 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList44, warningsGuardArray43);
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard46 = new com.google.javascript.jscomp.ComposeWarningsGuard((java.util.List<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList44);
        node28.putProp(5, (java.lang.Object) composeWarningsGuard46);
        com.google.javascript.jscomp.DiagnosticType diagnosticType51 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray53 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError54 = com.google.javascript.jscomp.JSError.make(diagnosticType51, strArray53);
        com.google.javascript.jscomp.DiagnosticType diagnosticType55 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        com.google.javascript.jscomp.DiagnosticType diagnosticType56 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray58 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError59 = com.google.javascript.jscomp.JSError.make(diagnosticType56, strArray58);
        com.google.javascript.jscomp.DiagnosticType[] diagnosticTypeArray60 = new com.google.javascript.jscomp.DiagnosticType[] { diagnosticType51, diagnosticType55, diagnosticType56 };
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup61 = new com.google.javascript.jscomp.DiagnosticGroup(diagnosticTypeArray60);
        com.google.javascript.jscomp.DiagnosticType diagnosticType62 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray64 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError65 = com.google.javascript.jscomp.JSError.make(diagnosticType62, strArray64);
        java.lang.Class<?> wildcardClass66 = diagnosticType62.getClass();
        com.google.javascript.jscomp.DiagnosticType diagnosticType69 = com.google.javascript.jscomp.DiagnosticType.warning("", "");
        com.google.javascript.jscomp.CheckLevel checkLevel70 = diagnosticType69.level;
        diagnosticType62.level = checkLevel70;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard72 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup61, checkLevel70);
        com.google.javascript.jscomp.DiagnosticType diagnosticType73 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        com.google.javascript.jscomp.AbstractCompiler abstractCompiler74 = null;
        com.google.javascript.jscomp.NodeTraversal.Callback callback75 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal76 = new com.google.javascript.jscomp.NodeTraversal(abstractCompiler74, callback75);
        com.google.javascript.rhino.Node node78 = com.google.javascript.rhino.Node.newString("language version");
        com.google.javascript.jscomp.DiagnosticType diagnosticType79 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        com.google.javascript.jscomp.CheckLevel checkLevel80 = diagnosticType79.defaultLevel;
        com.google.javascript.jscomp.DiagnosticType diagnosticType81 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray83 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError84 = com.google.javascript.jscomp.JSError.make(diagnosticType81, strArray83);
        com.google.javascript.jscomp.JSError jSError85 = nodeTraversal76.makeError(node78, diagnosticType79, strArray83);
        com.google.javascript.jscomp.JSError jSError86 = com.google.javascript.jscomp.JSError.make("goog.abstractMethod", (int) (short) -1, 8, checkLevel70, diagnosticType73, strArray83);
        com.google.javascript.jscomp.CheckLevel checkLevel87 = composeWarningsGuard46.level(jSError86);
        loggerErrorManager1.report(checkLevel18, jSError86);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(diagnosticType6);
        org.junit.Assert.assertTrue("'" + checkLevel7 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel7.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticType8);
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertNotNull(jSError11);
        org.junit.Assert.assertNotNull(diagnosticType12);
        org.junit.Assert.assertNotNull(strArray14);
        org.junit.Assert.assertNotNull(jSError15);
        org.junit.Assert.assertNotNull(jSError16);
        org.junit.Assert.assertNotNull(jSError17);
        org.junit.Assert.assertTrue("'" + checkLevel18 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel18.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "goog.exportProperty" + "'", str20.equals("goog.exportProperty"));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNull(str25);
        org.junit.Assert.assertNull(obj30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNull(obj35);
        org.junit.Assert.assertNotNull(node38);
        org.junit.Assert.assertNotNull(nodeIterable39);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(warningsGuardArray43);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(diagnosticType51);
        org.junit.Assert.assertNotNull(strArray53);
        org.junit.Assert.assertNotNull(jSError54);
        org.junit.Assert.assertNotNull(diagnosticType55);
        org.junit.Assert.assertNotNull(diagnosticType56);
        org.junit.Assert.assertNotNull(strArray58);
        org.junit.Assert.assertNotNull(jSError59);
        org.junit.Assert.assertNotNull(diagnosticTypeArray60);
        org.junit.Assert.assertNotNull(diagnosticType62);
        org.junit.Assert.assertNotNull(strArray64);
        org.junit.Assert.assertNotNull(jSError65);
        org.junit.Assert.assertNotNull(wildcardClass66);
        org.junit.Assert.assertNotNull(diagnosticType69);
        org.junit.Assert.assertTrue("'" + checkLevel70 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel70.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
        org.junit.Assert.assertNotNull(diagnosticType73);
        org.junit.Assert.assertNotNull(node78);
        org.junit.Assert.assertNotNull(diagnosticType79);
        org.junit.Assert.assertTrue("'" + checkLevel80 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel80.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticType81);
        org.junit.Assert.assertNotNull(strArray83);
        org.junit.Assert.assertNotNull(jSError84);
        org.junit.Assert.assertNotNull(jSError85);
        org.junit.Assert.assertNotNull(jSError86);
        org.junit.Assert.assertNull(checkLevel87);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node[] nodeArray1 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList2 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean3 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList2, nodeArray1);
        com.google.javascript.jscomp.NodeTraversal.Callback callback4 = null;
        com.google.javascript.jscomp.NodeTraversal.traverseRoots((com.google.javascript.jscomp.AbstractCompiler) compiler0, (java.util.List<com.google.javascript.rhino.Node>) nodeList2, callback4);
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter6 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler0);
        java.nio.charset.Charset charset8 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile9 = com.google.javascript.jscomp.JSSourceFile.fromFile("JSC_NODE_TRAVERSAL_ERROR", charset8);
        java.lang.String str10 = jSSourceFile9.getOriginalPath();
        com.google.javascript.rhino.Node node11 = compiler0.parse(jSSourceFile9);
        com.google.javascript.jscomp.JsAst jsAst12 = new com.google.javascript.jscomp.JsAst((com.google.javascript.jscomp.SourceFile) jSSourceFile9);
        com.google.javascript.jscomp.CompilerInput compilerInput14 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile9, false);
        try {
            java.util.Collection<java.lang.String> strCollection15 = compilerInput14.getRequires();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Expected setErrorManager to be called first");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(nodeArray1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(jSSourceFile9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "JSC_NODE_TRAVERSAL_ERROR" + "'", str10.equals("JSC_NODE_TRAVERSAL_ERROR"));
        org.junit.Assert.assertNull(node11);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node[] nodeArray1 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList2 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean3 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList2, nodeArray1);
        com.google.javascript.jscomp.NodeTraversal.Callback callback4 = null;
        com.google.javascript.jscomp.NodeTraversal.traverseRoots((com.google.javascript.jscomp.AbstractCompiler) compiler0, (java.util.List<com.google.javascript.rhino.Node>) nodeList2, callback4);
        com.google.javascript.jscomp.PerformanceTracker performanceTracker6 = compiler0.tracker;
        com.google.javascript.jscomp.SourceExcerptProvider.SourceExcerpt sourceExcerpt7 = null;
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter8 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler0, sourceExcerpt7);
        com.google.javascript.jscomp.Compiler.IntermediateState intermediateState9 = compiler0.getState();
        com.google.javascript.jscomp.ErrorManager errorManager10 = compiler0.getErrorManager();
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention11 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node12 = null;
        boolean boolean13 = closureCodingConvention11.isVarArgsParameter(node12);
        com.google.javascript.rhino.jstype.ObjectType objectType14 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType15 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType16 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType17 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType18 = null;
        closureCodingConvention11.applyDelegateRelationship(objectType14, objectType15, objectType16, functionType17, functionType18);
        com.google.javascript.rhino.jstype.FunctionType functionType20 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType21 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType22 = null;
        closureCodingConvention11.applySubclassRelationship(functionType20, functionType21, subclassType22);
        java.util.Collection<com.google.javascript.jscomp.CodingConvention.AssertionFunctionSpec> assertionFunctionSpecCollection24 = closureCodingConvention11.getAssertionFunctions();
        boolean boolean26 = closureCodingConvention11.isExported("JSC_NODE_TRAVERSAL_ERROR.  at (unknown source) line (unknown line) : (unknown column)");
        java.lang.String str27 = closureCodingConvention11.getDelegateSuperclassName();
        com.google.javascript.rhino.Node node28 = null;
        com.google.javascript.rhino.Node node31 = com.google.javascript.rhino.Node.newString((int) (short) 0, "");
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable32 = node31.siblings();
        boolean boolean33 = node31.isNoSideEffectsCall();
        java.lang.String str34 = node31.getString();
        java.util.Collection<com.google.javascript.rhino.Node> nodeCollection35 = com.google.javascript.jscomp.NodeUtil.getVarsDeclaredInBranch(node31);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder36 = node31.new FileLevelJsDocBuilder();
        java.lang.String str37 = closureCodingConvention11.extractClassNameIfRequire(node28, node31);
        com.google.javascript.jscomp.NodeTraversal.Callback callback38 = null;
        try {
            com.google.javascript.jscomp.NodeTraversal.traverse((com.google.javascript.jscomp.AbstractCompiler) compiler0, node28, callback38);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: INTERNAL COMPILER ERROR.\nPlease report this problem.\nnull");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(nodeArray1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(performanceTracker6);
        org.junit.Assert.assertNotNull(intermediateState9);
        org.junit.Assert.assertNotNull(errorManager10);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(assertionFunctionSpecCollection24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNull(str27);
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertNotNull(nodeIterable32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "" + "'", str34.equals(""));
        org.junit.Assert.assertNotNull(nodeCollection35);
        org.junit.Assert.assertNull(str37);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile1 = com.google.javascript.jscomp.JSSourceFile.fromFile("error reporter");
        com.google.javascript.jscomp.JsAst jsAst2 = new com.google.javascript.jscomp.JsAst((com.google.javascript.jscomp.SourceFile) jSSourceFile1);
        com.google.javascript.jscomp.CompilerInput compilerInput4 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) jsAst2, false);
        com.google.javascript.jscomp.Compiler compiler5 = new com.google.javascript.jscomp.Compiler();
        compilerInput4.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler5);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile8 = com.google.javascript.jscomp.JSSourceFile.fromFile("error reporter");
        com.google.javascript.jscomp.JsAst jsAst9 = new com.google.javascript.jscomp.JsAst((com.google.javascript.jscomp.SourceFile) jSSourceFile8);
        com.google.javascript.jscomp.CompilerInput compilerInput11 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) jsAst9, false);
        com.google.javascript.jscomp.Compiler compiler12 = new com.google.javascript.jscomp.Compiler();
        compilerInput11.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler12);
        com.google.javascript.jscomp.Compiler compiler14 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node[] nodeArray15 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList16 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean17 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList16, nodeArray15);
        com.google.javascript.jscomp.NodeTraversal.Callback callback18 = null;
        com.google.javascript.jscomp.NodeTraversal.traverseRoots((com.google.javascript.jscomp.AbstractCompiler) compiler14, (java.util.List<com.google.javascript.rhino.Node>) nodeList16, callback18);
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter20 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler14);
        compilerInput11.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler14);
        java.util.logging.Logger logger22 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager23 = new com.google.javascript.jscomp.LoggerErrorManager(logger22);
        com.google.javascript.jscomp.JSError[] jSErrorArray24 = loggerErrorManager23.getErrors();
        compiler14.setErrorManager((com.google.javascript.jscomp.ErrorManager) loggerErrorManager23);
        compilerInput4.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler14);
        java.lang.String str27 = compilerInput4.getName();
        try {
            java.lang.String str28 = compilerInput4.getCode();
            org.junit.Assert.fail("Expected exception of type java.io.FileNotFoundException; message: error reporter (No such file or directory)");
        } catch (java.io.FileNotFoundException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile1);
        org.junit.Assert.assertNotNull(jSSourceFile8);
        org.junit.Assert.assertNotNull(nodeArray15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(jSErrorArray24);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "error reporter" + "'", str27.equals("error reporter"));
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        int int0 = com.google.javascript.rhino.Node.FUNCTION_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 5 + "'", int0 == 5);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        int int0 = com.google.javascript.rhino.Node.IS_DISPATCHER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 46 + "'", int0 == 46);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        java.lang.String str1 = closureCodingConvention0.getExportPropertyFunction();
        boolean boolean3 = closureCodingConvention0.isPrivate("");
        boolean boolean5 = closureCodingConvention0.isPrivate("hi!");
        java.lang.String str6 = closureCodingConvention0.getAbstractMethodName();
        boolean boolean8 = closureCodingConvention0.isExported("language version");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention9 = new com.google.javascript.jscomp.ClosureCodingConvention();
        java.lang.String str10 = closureCodingConvention9.getExportPropertyFunction();
        boolean boolean12 = closureCodingConvention9.isPrivate("");
        boolean boolean14 = closureCodingConvention9.isPrivate("hi!");
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newString((int) (short) 0, "");
        boolean boolean18 = closureCodingConvention9.isOptionalParameter(node17);
        java.lang.String str19 = closureCodingConvention0.identifyTypeDefAssign(node17);
        com.google.javascript.rhino.Node node20 = com.google.javascript.jscomp.NodeUtil.newExpr(node17);
        int int21 = node20.getCharno();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "goog.exportProperty" + "'", str1.equals("goog.exportProperty"));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "goog.abstractMethod" + "'", str6.equals("goog.abstractMethod"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "goog.exportProperty" + "'", str10.equals("goog.exportProperty"));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNull(str19);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        java.util.logging.Logger logger0 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager1 = new com.google.javascript.jscomp.LoggerErrorManager(logger0);
        int int2 = loggerErrorManager1.getErrorCount();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.UNDEFINED_VARIABLES;
        com.google.javascript.jscomp.DiagnosticGroups.FILEOVERVIEW_JSDOC = diagnosticGroup0;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile0 = null;
        try {
            com.google.javascript.jscomp.CompilerInput compilerInput1 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newString("language version");
        node1.setQuotedString();
        int int3 = node1.getCharno();
        com.google.javascript.rhino.Node node4 = node1.getNext();
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNull(node4);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node1 = null;
        boolean boolean2 = closureCodingConvention0.isVarArgsParameter(node1);
        boolean boolean5 = closureCodingConvention0.isExported("Not declared as a constructor", true);
        boolean boolean7 = closureCodingConvention0.isConstantKey("JSC_NODE_TRAVERSAL_ERROR");
        boolean boolean9 = closureCodingConvention0.isExported(": ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        int int0 = com.google.javascript.rhino.Context.FEATURE_NON_ECMA_GET_YEAR;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray0 = new com.google.javascript.jscomp.WarningsGuard[] {};
        java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard> warningsGuardList1 = new java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList1, warningsGuardArray0);
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard3 = new com.google.javascript.jscomp.ComposeWarningsGuard((java.util.List<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList1);
        com.google.javascript.jscomp.DiagnosticType diagnosticType4 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        com.google.javascript.jscomp.CheckLevel checkLevel5 = diagnosticType4.defaultLevel;
        java.lang.String[] strArray8 = new java.lang.String[] { "JSC_NODE_TRAVERSAL_ERROR.  at (unknown source) line (unknown line) : (unknown column)", "language version" };
        com.google.javascript.jscomp.JSError jSError9 = com.google.javascript.jscomp.JSError.make(diagnosticType4, strArray8);
        com.google.javascript.jscomp.CheckLevel checkLevel10 = composeWarningsGuard3.level(jSError9);
        java.lang.String str11 = jSError9.toString();
        org.junit.Assert.assertNotNull(warningsGuardArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(diagnosticType4);
        org.junit.Assert.assertTrue("'" + checkLevel5 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel5.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertNotNull(jSError9);
        org.junit.Assert.assertNull(checkLevel10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "JSC_NODE_TRAVERSAL_ERROR. JSC_NODE_TRAVERSAL_ERROR.  at (unknown source) line (unknown line) : (unknown column) at (unknown source) line (unknown line) : (unknown column)" + "'", str11.equals("JSC_NODE_TRAVERSAL_ERROR. JSC_NODE_TRAVERSAL_ERROR.  at (unknown source) line (unknown line) : (unknown column) at (unknown source) line (unknown line) : (unknown column)"));
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        java.lang.Object[] objArray0 = com.google.javascript.rhino.Context.emptyArgs;
        org.junit.Assert.assertNotNull(objArray0);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.Compiler.IntermediateState intermediateState2 = compiler1.getState();
        com.google.javascript.jscomp.Compiler compiler3 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node[] nodeArray4 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList5 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean6 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList5, nodeArray4);
        com.google.javascript.jscomp.NodeTraversal.Callback callback7 = null;
        com.google.javascript.jscomp.NodeTraversal.traverseRoots((com.google.javascript.jscomp.AbstractCompiler) compiler3, (java.util.List<com.google.javascript.rhino.Node>) nodeList5, callback7);
        com.google.javascript.jscomp.PerformanceTracker performanceTracker9 = compiler3.tracker;
        com.google.javascript.jscomp.SourceExcerptProvider.SourceExcerpt sourceExcerpt10 = null;
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter11 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler3, sourceExcerpt10);
        java.util.logging.Logger logger12 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager13 = new com.google.javascript.jscomp.LoggerErrorManager((com.google.javascript.jscomp.MessageFormatter) lightweightMessageFormatter11, logger12);
        compiler1.setErrorManager((com.google.javascript.jscomp.ErrorManager) loggerErrorManager13);
        try {
            java.lang.String str15 = compiler1.toSource();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intermediateState2);
        org.junit.Assert.assertNotNull(nodeArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(performanceTracker9);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile3 = com.google.javascript.jscomp.JSSourceFile.fromFile("error reporter");
        com.google.javascript.jscomp.JsAst jsAst4 = new com.google.javascript.jscomp.JsAst((com.google.javascript.jscomp.SourceFile) jSSourceFile3);
        com.google.javascript.jscomp.CompilerInput compilerInput6 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) jsAst4, false);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile8 = com.google.javascript.jscomp.JSSourceFile.fromFile("error reporter");
        com.google.javascript.jscomp.JsAst jsAst9 = new com.google.javascript.jscomp.JsAst((com.google.javascript.jscomp.SourceFile) jSSourceFile8);
        com.google.javascript.jscomp.CompilerInput compilerInput11 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) jsAst9, false);
        com.google.javascript.jscomp.SourceAst sourceAst12 = compilerInput11.getSourceAst();
        com.google.javascript.jscomp.JSModule jSModule13 = null;
        compilerInput11.setModule(jSModule13);
        try {
            java.lang.String str15 = com.google.javascript.rhino.ScriptRuntime.getMessage3("Node tree inequality:\nTree1:\nBITXOR\n\n\nTree2:\nEOF \n\n\nSubtree1: BITXOR\n\n\nSubtree2: EOF \n", (java.lang.Object) (-2), (java.lang.Object) compilerInput6, (java.lang.Object) compilerInput11);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property Node tree inequality:\nTree1:\nBITXOR\n\n\nTree2:\nEOF \n\n\nSubtree1: BITXOR\n\n\nSubtree2: EOF \n");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile3);
        org.junit.Assert.assertNotNull(jSSourceFile8);
        org.junit.Assert.assertNotNull(sourceAst12);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString((int) (short) 0, "");
        node3.setVarArgs(true);
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable6 = node3.children();
        java.lang.RuntimeException runtimeException7 = com.google.javascript.rhino.ScriptRuntime.notFunctionError((java.lang.Object) "JSC_NODE_TRAVERSAL_ERROR: {0}", (java.lang.Object) node3);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(nodeIterable6);
        org.junit.Assert.assertNotNull(runtimeException7);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.Node.newString((int) (short) 0, "");
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable3 = node2.siblings();
        node2.detachChildren();
        java.lang.Object obj5 = null;
        java.lang.RuntimeException runtimeException6 = com.google.javascript.rhino.ScriptRuntime.notFunctionError((java.lang.Object) node2, obj5);
        node2.setIsSyntheticBlock(false);
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertNotNull(nodeIterable3);
        org.junit.Assert.assertNotNull(runtimeException6);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        com.google.javascript.jscomp.ErrorFormat errorFormat0 = com.google.javascript.jscomp.ErrorFormat.SINGLELINE;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node[] nodeArray2 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList3 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean4 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList3, nodeArray2);
        com.google.javascript.jscomp.NodeTraversal.Callback callback5 = null;
        com.google.javascript.jscomp.NodeTraversal.traverseRoots((com.google.javascript.jscomp.AbstractCompiler) compiler1, (java.util.List<com.google.javascript.rhino.Node>) nodeList3, callback5);
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter7 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler1);
        com.google.javascript.jscomp.SourceMap sourceMap8 = compiler1.getSourceMap();
        com.google.javascript.jscomp.MessageFormatter messageFormatter10 = errorFormat0.toFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler1, false);
        try {
            com.google.javascript.jscomp.JSError[] jSErrorArray11 = compiler1.getMessages();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(errorFormat0);
        org.junit.Assert.assertNotNull(nodeArray2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(sourceMap8);
        org.junit.Assert.assertNotNull(messageFormatter10);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        com.google.javascript.rhino.EvaluatorException evaluatorException1 = new com.google.javascript.rhino.EvaluatorException("(JSC_NODE_TRAVERSAL_ERROR.  at (unknown source) line (unknown line) : (unknown column))");
        int int2 = evaluatorException1.lineNumber();
        java.lang.String str3 = evaluatorException1.lineSource();
        java.lang.Throwable[] throwableArray4 = evaluatorException1.getSuppressed();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNotNull(throwableArray4);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        com.google.javascript.rhino.Context context0 = new com.google.javascript.rhino.Context();
        context0.addActivationName("goog.abstractMethod");
        com.google.javascript.rhino.ScriptRuntime.storeUint32Result(context0, (long) 100);
        java.lang.Object obj5 = context0.getDebuggerContextData();
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        try {
            context0.removePropertyChangeListener(propertyChangeListener6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(obj5);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        com.google.javascript.rhino.EvaluatorException evaluatorException1 = new com.google.javascript.rhino.EvaluatorException("error reporter");
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.Node.newString((int) (short) 0, "");
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable3 = node2.siblings();
        com.google.javascript.rhino.jstype.JSType jSType4 = null;
        node2.setJSType(jSType4);
        try {
            com.google.javascript.rhino.Node node7 = node2.getChildAtIndex(32);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertNotNull(nodeIterable3);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        com.google.javascript.jscomp.AbstractCompiler abstractCompiler0 = null;
        com.google.javascript.jscomp.NodeTraversal.Callback callback1 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal2 = new com.google.javascript.jscomp.NodeTraversal(abstractCompiler0, callback1);
        com.google.javascript.jscomp.Compiler compiler3 = nodeTraversal2.getCompiler();
        com.google.javascript.rhino.Node node4 = nodeTraversal2.getEnclosingFunction();
        com.google.javascript.rhino.Node node7 = new com.google.javascript.rhino.Node((int) (short) 10);
        java.lang.Object obj9 = node7.getProp((int) (short) 1);
        boolean boolean10 = node7.hasMoreThanOneChild();
        com.google.javascript.rhino.Node node12 = new com.google.javascript.rhino.Node((int) (short) 10);
        java.lang.Object obj14 = node12.getProp((int) (short) 1);
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newString((int) (short) 0, "");
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable18 = node17.siblings();
        com.google.javascript.rhino.Node node19 = new com.google.javascript.rhino.Node((-1), node7, node12, node17);
        com.google.javascript.jscomp.DiagnosticType diagnosticType20 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray22 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError23 = com.google.javascript.jscomp.JSError.make(diagnosticType20, strArray22);
        com.google.javascript.jscomp.CheckLevel checkLevel24 = diagnosticType20.level;
        java.lang.String str25 = diagnosticType20.toString();
        java.lang.String str26 = diagnosticType20.toString();
        com.google.javascript.rhino.Node node29 = com.google.javascript.rhino.Node.newString("language version");
        com.google.javascript.jscomp.DiagnosticType diagnosticType32 = com.google.javascript.jscomp.DiagnosticType.error("BITXOR", "(JSC_NODE_TRAVERSAL_ERROR.  at (unknown source) line (unknown line) : (unknown column))");
        com.google.javascript.jscomp.DiagnosticType diagnosticType33 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray35 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError36 = com.google.javascript.jscomp.JSError.make(diagnosticType33, strArray35);
        com.google.javascript.jscomp.JSError jSError37 = com.google.javascript.jscomp.JSError.make("JSC_NODE_TRAVERSAL_ERROR: {0}", node29, diagnosticType32, strArray35);
        com.google.javascript.jscomp.JSError jSError38 = nodeTraversal2.makeError(node12, diagnosticType20, strArray35);
        com.google.javascript.jscomp.CheckLevel checkLevel39 = diagnosticType20.level;
        org.junit.Assert.assertNull(compiler3);
        org.junit.Assert.assertNull(node4);
        org.junit.Assert.assertNull(obj9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNull(obj14);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(nodeIterable18);
        org.junit.Assert.assertNotNull(diagnosticType20);
        org.junit.Assert.assertNotNull(strArray22);
        org.junit.Assert.assertNotNull(jSError23);
        org.junit.Assert.assertTrue("'" + checkLevel24 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel24.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "JSC_NODE_TRAVERSAL_ERROR: {0}" + "'", str25.equals("JSC_NODE_TRAVERSAL_ERROR: {0}"));
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "JSC_NODE_TRAVERSAL_ERROR: {0}" + "'", str26.equals("JSC_NODE_TRAVERSAL_ERROR: {0}"));
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNotNull(diagnosticType32);
        org.junit.Assert.assertNotNull(diagnosticType33);
        org.junit.Assert.assertNotNull(strArray35);
        org.junit.Assert.assertNotNull(jSError36);
        org.junit.Assert.assertNotNull(jSError37);
        org.junit.Assert.assertNotNull(jSError38);
        org.junit.Assert.assertTrue("'" + checkLevel39 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel39.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node[] nodeArray1 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList2 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean3 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList2, nodeArray1);
        com.google.javascript.jscomp.NodeTraversal.Callback callback4 = null;
        com.google.javascript.jscomp.NodeTraversal.traverseRoots((com.google.javascript.jscomp.AbstractCompiler) compiler0, (java.util.List<com.google.javascript.rhino.Node>) nodeList2, callback4);
        com.google.javascript.jscomp.PerformanceTracker performanceTracker6 = compiler0.tracker;
        com.google.javascript.jscomp.SourceExcerptProvider.SourceExcerpt sourceExcerpt7 = null;
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter8 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler0, sourceExcerpt7);
        com.google.javascript.jscomp.Compiler.IntermediateState intermediateState9 = compiler0.getState();
        com.google.javascript.jscomp.Compiler.IntermediateState intermediateState10 = compiler0.getState();
        java.nio.charset.Charset charset12 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile13 = com.google.javascript.jscomp.JSSourceFile.fromFile("JSC_NODE_TRAVERSAL_ERROR", charset12);
        com.google.javascript.jscomp.JsAst jsAst14 = new com.google.javascript.jscomp.JsAst((com.google.javascript.jscomp.SourceFile) jSSourceFile13);
        com.google.javascript.jscomp.JSModule[] jSModuleArray15 = new com.google.javascript.jscomp.JSModule[] {};
        com.google.javascript.jscomp.CompilerOptions compilerOptions16 = null;
        try {
            com.google.javascript.jscomp.Result result17 = compiler0.compile(jSSourceFile13, jSModuleArray15, compilerOptions16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(nodeArray1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(performanceTracker6);
        org.junit.Assert.assertNotNull(intermediateState9);
        org.junit.Assert.assertNotNull(intermediateState10);
        org.junit.Assert.assertNotNull(jSSourceFile13);
        org.junit.Assert.assertNotNull(jSModuleArray15);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        com.google.javascript.rhino.Node node1 = new com.google.javascript.rhino.Node((int) (short) 10);
        java.lang.Object obj3 = node1.getProp((int) (short) 1);
        com.google.javascript.rhino.JSDocInfo jSDocInfo4 = node1.getJSDocInfo();
        node1.setIsSyntheticBlock(false);
        com.google.javascript.rhino.jstype.JSType jSType7 = node1.getJSType();
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString((int) (short) 0, "");
        node10.setVarArgs(true);
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.Node.newString((int) (short) 0, "");
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable16 = node15.siblings();
        boolean boolean17 = node15.isNoSideEffectsCall();
        java.lang.String str18 = node15.getString();
        java.util.Collection<com.google.javascript.rhino.Node> nodeCollection19 = com.google.javascript.jscomp.NodeUtil.getVarsDeclaredInBranch(node15);
        com.google.javascript.rhino.Node node24 = com.google.javascript.rhino.Node.newNumber((double) 1L, 0, 1);
        com.google.javascript.rhino.Node node25 = new com.google.javascript.rhino.Node(42, node24);
        boolean boolean26 = node25.isLocalResultCall();
        com.google.javascript.rhino.JSDocInfo jSDocInfo27 = null;
        node25.setJSDocInfo(jSDocInfo27);
        boolean boolean29 = node15.isEquivalentTo(node25);
        try {
            node1.addChildBefore(node10, node25);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(obj3);
        org.junit.Assert.assertNull(jSDocInfo4);
        org.junit.Assert.assertNull(jSType7);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertNotNull(nodeIterable16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "" + "'", str18.equals(""));
        org.junit.Assert.assertNotNull(nodeCollection19);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention1 = new com.google.javascript.jscomp.ClosureCodingConvention();
        java.lang.String str2 = closureCodingConvention1.getExportPropertyFunction();
        boolean boolean4 = closureCodingConvention1.isPrivate("");
        boolean boolean6 = closureCodingConvention1.isPrivate("hi!");
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString((int) (short) 0, "");
        boolean boolean10 = closureCodingConvention1.isOptionalParameter(node9);
        java.util.Collection<com.google.javascript.jscomp.CodingConvention.AssertionFunctionSpec> assertionFunctionSpecCollection11 = closureCodingConvention1.getAssertionFunctions();
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node((int) (byte) 100);
        boolean boolean14 = closureCodingConvention1.isOptionalParameter(node13);
        com.google.javascript.rhino.Node node17 = new com.google.javascript.rhino.Node((int) (short) 10);
        java.lang.Object obj19 = node17.getProp((int) (short) 1);
        boolean boolean20 = node17.hasMoreThanOneChild();
        com.google.javascript.rhino.Node node22 = new com.google.javascript.rhino.Node((int) (short) 10);
        java.lang.Object obj24 = node22.getProp((int) (short) 1);
        com.google.javascript.rhino.Node node27 = com.google.javascript.rhino.Node.newString((int) (short) 0, "");
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable28 = node27.siblings();
        com.google.javascript.rhino.Node node29 = new com.google.javascript.rhino.Node((-1), node17, node22, node27);
        com.google.javascript.rhino.Node node32 = com.google.javascript.rhino.Node.newString((int) (short) 0, "");
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable33 = node32.siblings();
        boolean boolean34 = node32.isNoSideEffectsCall();
        java.lang.String str35 = node32.getString();
        java.util.Collection<com.google.javascript.rhino.Node> nodeCollection36 = com.google.javascript.jscomp.NodeUtil.getVarsDeclaredInBranch(node32);
        node27.addChildrenToFront(node32);
        try {
            com.google.javascript.rhino.Node node38 = new com.google.javascript.rhino.Node(41, node13, node27);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: second new child has existing parent");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "goog.exportProperty" + "'", str2.equals("goog.exportProperty"));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(assertionFunctionSpecCollection11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNull(obj19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNull(obj24);
        org.junit.Assert.assertNotNull(node27);
        org.junit.Assert.assertNotNull(nodeIterable28);
        org.junit.Assert.assertNotNull(node32);
        org.junit.Assert.assertNotNull(nodeIterable33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "" + "'", str35.equals(""));
        org.junit.Assert.assertNotNull(nodeCollection36);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node1 = null;
        boolean boolean2 = closureCodingConvention0.isVarArgsParameter(node1);
        com.google.javascript.rhino.jstype.ObjectType objectType3 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType4 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType5 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType6 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType7 = null;
        closureCodingConvention0.applyDelegateRelationship(objectType3, objectType4, objectType5, functionType6, functionType7);
        com.google.javascript.rhino.jstype.FunctionType functionType9 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType10 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType11 = null;
        closureCodingConvention0.applySubclassRelationship(functionType9, functionType10, subclassType11);
        java.util.Collection<com.google.javascript.jscomp.CodingConvention.AssertionFunctionSpec> assertionFunctionSpecCollection13 = closureCodingConvention0.getAssertionFunctions();
        boolean boolean15 = closureCodingConvention0.isExported("JSC_NODE_TRAVERSAL_ERROR.  at (unknown source) line (unknown line) : (unknown column)");
        java.util.Collection<com.google.javascript.jscomp.CodingConvention.AssertionFunctionSpec> assertionFunctionSpecCollection16 = closureCodingConvention0.getAssertionFunctions();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(assertionFunctionSpecCollection13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(assertionFunctionSpecCollection16);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        int int0 = com.google.javascript.rhino.Node.REGEXP_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 12 + "'", int0 == 12);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        com.google.javascript.rhino.Node.SideEffectFlags sideEffectFlags0 = new com.google.javascript.rhino.Node.SideEffectFlags();
        sideEffectFlags0.setMutatesThis();
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        com.google.javascript.rhino.Context context0 = new com.google.javascript.rhino.Context();
        context0.addActivationName("goog.abstractMethod");
        com.google.javascript.rhino.ScriptRuntime.storeUint32Result(context0, (long) 100);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile6 = com.google.javascript.jscomp.JSSourceFile.fromFile("error reporter");
        com.google.javascript.jscomp.JsAst jsAst7 = new com.google.javascript.jscomp.JsAst((com.google.javascript.jscomp.SourceFile) jSSourceFile6);
        com.google.javascript.jscomp.CompilerInput compilerInput9 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) jsAst7, false);
        com.google.javascript.jscomp.Compiler compiler10 = new com.google.javascript.jscomp.Compiler();
        compilerInput9.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler10);
        com.google.javascript.jscomp.Compiler compiler12 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node[] nodeArray13 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList14 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean15 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList14, nodeArray13);
        com.google.javascript.jscomp.NodeTraversal.Callback callback16 = null;
        com.google.javascript.jscomp.NodeTraversal.traverseRoots((com.google.javascript.jscomp.AbstractCompiler) compiler12, (java.util.List<com.google.javascript.rhino.Node>) nodeList14, callback16);
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter18 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler12);
        compilerInput9.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler12);
        int int20 = compiler12.getWarningCount();
        try {
            context0.unseal((java.lang.Object) int20);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile6);
        org.junit.Assert.assertNotNull(nodeArray13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        com.google.javascript.rhino.Context context0 = new com.google.javascript.rhino.Context();
        java.util.Locale locale1 = context0.getLocale();
        com.google.javascript.rhino.Node node3 = new com.google.javascript.rhino.Node((int) (short) 10);
        java.lang.String str7 = node3.toString(true, false, true);
        boolean boolean8 = node3.hasOneChild();
        context0.seal((java.lang.Object) boolean8);
        org.junit.Assert.assertNotNull(locale1);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "BITXOR" + "'", str7.equals("BITXOR"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        int int0 = com.google.javascript.rhino.Node.DIRECTIVES;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 47 + "'", int0 == 47);
    }
}

